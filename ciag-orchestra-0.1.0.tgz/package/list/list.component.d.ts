import * as i0 from "@angular/core";
export interface ListItem {
    id: string;
    label: string;
    description?: string;
    disabled?: boolean;
    selected?: boolean;
}
export declare class ListComponent {
    readonly items: import("@angular/core").InputSignal<ListItem[]>;
    readonly label: import("@angular/core").InputSignal<string>;
    readonly selection: import("@angular/core").InputSignal<"none" | "single" | "multiple">;
    readonly itemSelect: import("@angular/core").OutputEmitterRef<ListItem>;
    select(item: ListItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListComponent, "orc-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; }, never, never, true, never>;
}
