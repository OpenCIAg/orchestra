import { BadgeSize, BadgeStatus, BadgeVariant } from './badge.types';
import * as i0 from "@angular/core";
export declare class BadgeComponent {
    readonly variant: import("@angular/core").InputSignal<BadgeVariant>;
    readonly status: import("@angular/core").InputSignal<BadgeStatus>;
    readonly size: import("@angular/core").InputSignal<BadgeSize>;
    readonly text: import("@angular/core").InputSignal<string>;
    readonly count: import("@angular/core").InputSignal<number | undefined>;
    readonly maxCount: import("@angular/core").InputSignal<number>;
    readonly dot: import("@angular/core").InputSignal<boolean>;
    readonly showDefaultIcon: import("@angular/core").InputSignal<boolean>;
    readonly dismissible: import("@angular/core").InputSignal<boolean>;
    readonly pill: import("@angular/core").InputSignal<boolean>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly dismiss: import("@angular/core").OutputEmitterRef<MouseEvent>;
    readonly displayValue: import("@angular/core").Signal<string>;
    readonly normalizedStatus: import("@angular/core").Signal<string>;
    readonly isDotOnly: import("@angular/core").Signal<boolean>;
    readonly accessibleLabel: import("@angular/core").Signal<string>;
    onDismissClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "orc-badge", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "maxCount": { "alias": "maxCount"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; "showDefaultIcon": { "alias": "showDefaultIcon"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "pill": { "alias": "pill"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "dismiss": "dismiss"; }, never, ["[badge-icon-left], [badgeIconLeft]", "*", "[badge-icon-right], [badgeIconRight]"], true, never>;
}
