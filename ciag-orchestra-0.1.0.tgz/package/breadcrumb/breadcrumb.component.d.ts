import { BreadcrumbItemComponent } from './breadcrumb-item.component';
import { BreadcrumbItemData, BreadcrumbVariant } from './breadcrumb.types';
import * as i0 from "@angular/core";
export interface ProcessedBreadcrumbItem extends Partial<BreadcrumbItemData> {
    label: string;
    isEllipsis: boolean;
    isLast: boolean;
    originalIndex: number;
}
export declare class BreadcrumbComponent {
    readonly items: import("@angular/core").InputSignal<BreadcrumbItemData[] | undefined>;
    readonly separator: import("@angular/core").InputSignal<string>;
    readonly variant: import("@angular/core").InputSignal<BreadcrumbVariant>;
    readonly maxItems: import("@angular/core").InputSignal<number | undefined>;
    readonly itemsBeforeCollapse: import("@angular/core").InputSignal<number>;
    readonly itemsAfterCollapse: import("@angular/core").InputSignal<number>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly itemClick: import("@angular/core").OutputEmitterRef<{
        item: BreadcrumbItemData;
        index: number;
    }>;
    readonly breadcrumbItems: import("@angular/core").Signal<readonly BreadcrumbItemComponent[]>;
    readonly isExpanded: import("@angular/core").WritableSignal<boolean>;
    readonly processedItems: import("@angular/core").Signal<ProcessedBreadcrumbItem[]>;
    expand(): void;
    onItemClicked(item: ProcessedBreadcrumbItem, index: number, event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "orc-breadcrumb", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "maxItems": { "alias": "maxItems"; "required": false; "isSignal": true; }; "itemsBeforeCollapse": { "alias": "itemsBeforeCollapse"; "required": false; "isSignal": true; }; "itemsAfterCollapse": { "alias": "itemsAfterCollapse"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, ["breadcrumbItems"], ["*"], true, never>;
}
