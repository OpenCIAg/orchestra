import * as i0 from "@angular/core";
export declare class BreadcrumbItemComponent {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly routerLink: import("@angular/core").InputSignal<string | any[] | undefined>;
    readonly href: import("@angular/core").InputSignal<string | undefined>;
    readonly active: import("@angular/core").InputSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    readonly icon: import("@angular/core").InputSignal<string | undefined>;
    readonly itemClick: import("@angular/core").OutputEmitterRef<MouseEvent>;
    readonly hasLink: import("@angular/core").Signal<boolean>;
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbItemComponent, "orc-breadcrumb-item", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "routerLink": { "alias": "routerLink"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, never, ["*", "*", "*", "*"], true, never>;
}
