import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component, HostBinding } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

function LoadingSpinnerComponent_ng_template_0__svg_svg_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "circle", 11)(2, "circle", 12);
    i0.ɵɵelementEnd();
} }
function LoadingSpinnerComponent_ng_template_0_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵelement(1, "div", 14)(2, "div", 14)(3, "div", 14)(4, "div", 14)(5, "div", 14)(6, "div", 14)(7, "div", 14)(8, "div", 14);
    i0.ɵɵelementEnd();
} }
function LoadingSpinnerComponent_ng_template_0_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 15);
    i0.ɵɵelement(1, "span", 16)(2, "span", 16)(3, "span", 16);
    i0.ɵɵelementEnd();
} }
function LoadingSpinnerComponent_ng_template_0_span_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.text());
} }
function LoadingSpinnerComponent_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3)(1, "div", 4);
    i0.ɵɵtemplate(2, LoadingSpinnerComponent_ng_template_0__svg_svg_2_Template, 3, 0, "svg", 5)(3, LoadingSpinnerComponent_ng_template_0_div_3_Template, 9, 0, "div", 6)(4, LoadingSpinnerComponent_ng_template_0_div_4_Template, 4, 0, "div", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, LoadingSpinnerComponent_ng_template_0_span_5_Template, 2, 1, "span", 8);
    i0.ɵɵelementStart(6, "span", 9);
    i0.ɵɵtext(7);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-spinner-container--bottom", ctx_r0.textPosition() === "bottom");
    i0.ɵɵattribute("aria-label", ctx_r0.ariaLabel());
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("width", ctx_r0.customSizeCss())("height", ctx_r0.customSizeCss());
    i0.ɵɵclassProp("orc-spinner--sm", ctx_r0.size() === "sm")("orc-spinner--md", ctx_r0.size() === "md")("orc-spinner--lg", ctx_r0.size() === "lg")("orc-spinner--primary", ctx_r0.variant() === "primary")("orc-spinner--secondary", ctx_r0.variant() === "secondary")("orc-spinner--neutral", ctx_r0.variant() === "neutral")("orc-spinner--white", ctx_r0.variant() === "white");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.type() === "ring");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.type() === "star");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.type() === "dots");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.text());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.ariaLabel());
} }
function LoadingSpinnerComponent_div_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function LoadingSpinnerComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 18);
    i0.ɵɵtemplate(1, LoadingSpinnerComponent_div_2_ng_container_1_Template, 1, 0, "ng-container", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    const spinnerContent_r2 = i0.ɵɵreference(1);
    i0.ɵɵclassProp("orc-spinner-overlay--backdrop", ctx_r0.backdrop());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", spinnerContent_r2);
} }
function LoadingSpinnerComponent_ng_template_3_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function LoadingSpinnerComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, LoadingSpinnerComponent_ng_template_3_ng_container_0_Template, 1, 0, "ng-container", 19);
} if (rf & 2) {
    i0.ɵɵnextContext();
    const spinnerContent_r2 = i0.ɵɵreference(1);
    i0.ɵɵproperty("ngTemplateOutlet", spinnerContent_r2);
} }
class LoadingSpinnerComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    size = input('md');
    customSize = input('');
    variant = input('primary');
    type = input('ring');
    text = input('');
    textPosition = input('right');
    fullScreen = input(false);
    backdrop = input(true);
    ariaLabel = input('Carregando...');
    get isFullScreen() {
        return this.fullScreen();
    }
    customSizeCss = computed(() => {
        const s = this.customSize();
        if (!s)
            return null;
        return typeof s === 'number' ? `${s}px` : s;
    });
    static ɵfac = function LoadingSpinnerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LoadingSpinnerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LoadingSpinnerComponent, selectors: [["orc-spinner"]], hostVars: 2, hostBindings: function LoadingSpinnerComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵclassProp("orc-spinner--fullscreen-host", ctx.isFullScreen);
        } }, inputs: { size: [1, "size"], customSize: [1, "customSize"], variant: [1, "variant"], type: [1, "type"], text: [1, "text"], textPosition: [1, "textPosition"], fullScreen: [1, "fullScreen"], backdrop: [1, "backdrop"], ariaLabel: [1, "ariaLabel"] }, decls: 5, vars: 2, consts: [["spinnerContent", ""], ["inlineSpinner", ""], ["class", "orc-spinner-overlay", 3, "orc-spinner-overlay--backdrop", 4, "ngIf", "ngIfElse"], ["role", "status", "aria-busy", "true", "aria-live", "polite", 1, "orc-spinner-container"], ["aria-hidden", "true", 1, "orc-spinner"], ["class", "orc-spinner__ring", "viewBox", "0 0 32 32", "fill", "none", 4, "ngIf"], ["class", "orc-spinner__star", 4, "ngIf"], ["class", "orc-spinner__dots", 4, "ngIf"], ["class", "orc-spinner-text", 4, "ngIf"], [1, "sr-only"], ["viewBox", "0 0 32 32", "fill", "none", 1, "orc-spinner__ring"], ["cx", "16", "cy", "16", "r", "13", "stroke-width", "3", 1, "orc-spinner__ring__track"], ["cx", "16", "cy", "16", "r", "13", "stroke-width", "3"], [1, "orc-spinner__star"], [1, "orc-spinner__star__bar"], [1, "orc-spinner__dots"], [1, "orc-spinner__dots__dot"], [1, "orc-spinner-text"], [1, "orc-spinner-overlay"], [4, "ngTemplateOutlet"]], template: function LoadingSpinnerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, LoadingSpinnerComponent_ng_template_0_Template, 8, 26, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(2, LoadingSpinnerComponent_div_2_Template, 2, 3, "div", 2)(3, LoadingSpinnerComponent_ng_template_3_Template, 1, 1, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            const inlineSpinner_r3 = i0.ɵɵreference(4);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.fullScreen())("ngIfElse", inlineSpinner_r3);
        } }, dependencies: [CommonModule, i1.NgIf, i1.NgTemplateOutlet], styles: ["[_nghost-%COMP%]{display:inline-flex;vertical-align:middle}.orc-spinner--fullscreen-host[_nghost-%COMP%]{display:block}.orc-spinner-overlay[_ngcontent-%COMP%]{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center}.orc-spinner-overlay--backdrop[_ngcontent-%COMP%]{background-color:#ffffffbf;backdrop-filter:blur(4px)}.orc-spinner-container[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:10px;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-spinner-container--bottom[_ngcontent-%COMP%]{flex-direction:column;text-align:center;gap:8px}.orc-spinner[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;position:relative;flex-shrink:0}.orc-spinner--sm[_ngcontent-%COMP%]{width:16px;height:16px}.orc-spinner--md[_ngcontent-%COMP%]{width:24px;height:24px}.orc-spinner--lg[_ngcontent-%COMP%]{width:40px;height:40px}.orc-spinner--primary[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-spinner--secondary[_ngcontent-%COMP%]{color:var(--orc-color-azul-royal, #0406AB)}.orc-spinner--neutral[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414)}.orc-spinner--white[_ngcontent-%COMP%]{color:#fff}.orc-spinner__ring[_ngcontent-%COMP%]{width:100%;height:100%;animation:_ngcontent-%COMP%_orcSpinnerRotate .8s linear infinite}.orc-spinner__ring[_ngcontent-%COMP%]   circle[_ngcontent-%COMP%]{fill:none;stroke:currentColor;stroke-linecap:round;stroke-dasharray:80;stroke-dashoffset:60}.orc-spinner__ring__track[_ngcontent-%COMP%]{opacity:.2;stroke:currentColor;stroke-dasharray:none;stroke-dashoffset:0}.orc-spinner__star[_ngcontent-%COMP%]{width:100%;height:100%;position:relative;animation:_ngcontent-%COMP%_orcSpinnerStep 1s steps(8) infinite}.orc-spinner__star__bar[_ngcontent-%COMP%]{position:absolute;left:45%;top:0;width:10%;height:28%;background-color:currentColor;border-radius:9999px;transform-origin:50% 180%;opacity:.15}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(1){transform:rotate(0);opacity:.25}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(2){transform:rotate(45deg);opacity:.35}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(3){transform:rotate(90deg);opacity:.45}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(4){transform:rotate(135deg);opacity:.55}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(5){transform:rotate(180deg);opacity:.65}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(6){transform:rotate(225deg);opacity:.75}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(7){transform:rotate(270deg);opacity:.85}.orc-spinner__star__bar[_ngcontent-%COMP%]:nth-child(8){transform:rotate(315deg);opacity:.95}.orc-spinner__dots[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:4px;width:100%;height:100%}.orc-spinner__dots__dot[_ngcontent-%COMP%]{width:25%;height:25%;background-color:currentColor;border-radius:50%;animation:_ngcontent-%COMP%_orcSpinnerPulse 1.2s ease-in-out infinite}.orc-spinner__dots__dot[_ngcontent-%COMP%]:nth-child(1){animation-delay:0s}.orc-spinner__dots__dot[_ngcontent-%COMP%]:nth-child(2){animation-delay:.2s}.orc-spinner__dots__dot[_ngcontent-%COMP%]:nth-child(3){animation-delay:.4s}.orc-spinner-text[_ngcontent-%COMP%]{font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);-webkit-user-select:none;user-select:none}.orc-spinner--white[_ngcontent-%COMP%] + .orc-spinner-text[_ngcontent-%COMP%]{color:#fff}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes _ngcontent-%COMP%_orcSpinnerRotate{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes _ngcontent-%COMP%_orcSpinnerStep{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes _ngcontent-%COMP%_orcSpinnerPulse{0%,80%,to{transform:scale(.6);opacity:.35}40%{transform:scale(1);opacity:1}}@media(prefers-reduced-motion:reduce){.orc-spinner__ring[_ngcontent-%COMP%], .orc-spinner__star[_ngcontent-%COMP%], .orc-spinner__dots__dot[_ngcontent-%COMP%]{animation-duration:2.5s}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LoadingSpinnerComponent, [{
        type: Component,
        args: [{ selector: 'orc-spinner', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #spinnerContent>\n  <div\n    class=\"orc-spinner-container\"\n    [class.orc-spinner-container--bottom]=\"textPosition() === 'bottom'\"\n    role=\"status\"\n    aria-busy=\"true\"\n    aria-live=\"polite\"\n    [attr.aria-label]=\"ariaLabel()\"\n  >\n    <!-- Visual Spinner Element -->\n    <div\n      class=\"orc-spinner\"\n      [class.orc-spinner--sm]=\"size() === 'sm'\"\n      [class.orc-spinner--md]=\"size() === 'md'\"\n      [class.orc-spinner--lg]=\"size() === 'lg'\"\n      [class.orc-spinner--primary]=\"variant() === 'primary'\"\n      [class.orc-spinner--secondary]=\"variant() === 'secondary'\"\n      [class.orc-spinner--neutral]=\"variant() === 'neutral'\"\n      [class.orc-spinner--white]=\"variant() === 'white'\"\n      [style.width]=\"customSizeCss()\"\n      [style.height]=\"customSizeCss()\"\n      aria-hidden=\"true\"\n    >\n      <!-- Ring / Rollin SVG -->\n      <svg\n        *ngIf=\"type() === 'ring'\"\n        class=\"orc-spinner__ring\"\n        viewBox=\"0 0 32 32\"\n        fill=\"none\"\n      >\n        <circle\n          class=\"orc-spinner__ring__track\"\n          cx=\"16\"\n          cy=\"16\"\n          r=\"13\"\n          stroke-width=\"3\"\n        />\n        <circle\n          cx=\"16\"\n          cy=\"16\"\n          r=\"13\"\n          stroke-width=\"3\"\n        />\n      </svg>\n\n      <!-- Star / Radial Petals -->\n      <div *ngIf=\"type() === 'star'\" class=\"orc-spinner__star\">\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n        <div class=\"orc-spinner__star__bar\"></div>\n      </div>\n\n      <!-- Dots Spinner -->\n      <div *ngIf=\"type() === 'dots'\" class=\"orc-spinner__dots\">\n        <span class=\"orc-spinner__dots__dot\"></span>\n        <span class=\"orc-spinner__dots__dot\"></span>\n        <span class=\"orc-spinner__dots__dot\"></span>\n      </div>\n    </div>\n\n    <!-- Text description -->\n    <span *ngIf=\"text()\" class=\"orc-spinner-text\">{{ text() }}</span>\n\n    <!-- Screen Reader Fallback -->\n    <span class=\"sr-only\">{{ ariaLabel() }}</span>\n  </div>\n</ng-template>\n\n<!-- FullScreen Overlay Mode or Inline Mode -->\n<div\n  *ngIf=\"fullScreen(); else inlineSpinner\"\n  class=\"orc-spinner-overlay\"\n  [class.orc-spinner-overlay--backdrop]=\"backdrop()\"\n>\n  <ng-container *ngTemplateOutlet=\"spinnerContent\"></ng-container>\n</div>\n\n<ng-template #inlineSpinner>\n  <ng-container *ngTemplateOutlet=\"spinnerContent\"></ng-container>\n</ng-template>\n", styles: [":host{display:inline-flex;vertical-align:middle}:host(.orc-spinner--fullscreen-host){display:block}.orc-spinner-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center}.orc-spinner-overlay--backdrop{background-color:#ffffffbf;backdrop-filter:blur(4px)}.orc-spinner-container{display:inline-flex;align-items:center;justify-content:center;gap:10px;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-spinner-container--bottom{flex-direction:column;text-align:center;gap:8px}.orc-spinner{display:inline-flex;align-items:center;justify-content:center;position:relative;flex-shrink:0}.orc-spinner--sm{width:16px;height:16px}.orc-spinner--md{width:24px;height:24px}.orc-spinner--lg{width:40px;height:40px}.orc-spinner--primary{color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-spinner--secondary{color:var(--orc-color-azul-royal, #0406AB)}.orc-spinner--neutral{color:var(--orc-font-main, #141414)}.orc-spinner--white{color:#fff}.orc-spinner__ring{width:100%;height:100%;animation:orcSpinnerRotate .8s linear infinite}.orc-spinner__ring circle{fill:none;stroke:currentColor;stroke-linecap:round;stroke-dasharray:80;stroke-dashoffset:60}.orc-spinner__ring__track{opacity:.2;stroke:currentColor;stroke-dasharray:none;stroke-dashoffset:0}.orc-spinner__star{width:100%;height:100%;position:relative;animation:orcSpinnerStep 1s steps(8) infinite}.orc-spinner__star__bar{position:absolute;left:45%;top:0;width:10%;height:28%;background-color:currentColor;border-radius:9999px;transform-origin:50% 180%;opacity:.15}.orc-spinner__star__bar:nth-child(1){transform:rotate(0);opacity:.25}.orc-spinner__star__bar:nth-child(2){transform:rotate(45deg);opacity:.35}.orc-spinner__star__bar:nth-child(3){transform:rotate(90deg);opacity:.45}.orc-spinner__star__bar:nth-child(4){transform:rotate(135deg);opacity:.55}.orc-spinner__star__bar:nth-child(5){transform:rotate(180deg);opacity:.65}.orc-spinner__star__bar:nth-child(6){transform:rotate(225deg);opacity:.75}.orc-spinner__star__bar:nth-child(7){transform:rotate(270deg);opacity:.85}.orc-spinner__star__bar:nth-child(8){transform:rotate(315deg);opacity:.95}.orc-spinner__dots{display:inline-flex;align-items:center;justify-content:center;gap:4px;width:100%;height:100%}.orc-spinner__dots__dot{width:25%;height:25%;background-color:currentColor;border-radius:50%;animation:orcSpinnerPulse 1.2s ease-in-out infinite}.orc-spinner__dots__dot:nth-child(1){animation-delay:0s}.orc-spinner__dots__dot:nth-child(2){animation-delay:.2s}.orc-spinner__dots__dot:nth-child(3){animation-delay:.4s}.orc-spinner-text{font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);-webkit-user-select:none;user-select:none}.orc-spinner--white+.orc-spinner-text{color:#fff}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes orcSpinnerRotate{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes orcSpinnerStep{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes orcSpinnerPulse{0%,80%,to{transform:scale(.6);opacity:.35}40%{transform:scale(1);opacity:1}}@media(prefers-reduced-motion:reduce){.orc-spinner__ring,.orc-spinner__star,.orc-spinner__dots__dot{animation-duration:2.5s}}\n"] }]
    }], null, { isFullScreen: [{
            type: HostBinding,
            args: ['class.orc-spinner--fullscreen-host']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(LoadingSpinnerComponent, { className: "LoadingSpinnerComponent", filePath: "spinner.component.ts", lineNumber: 24 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { LoadingSpinnerComponent };
//# sourceMappingURL=ciag-orchestra-spinner.mjs.map
