import * as i0 from '@angular/core';
import { model, input, signal, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

function DatePickerComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function DatePickerComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.error());
} }
function DatePickerComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.helperText());
} }
class DatePickerComponent {
    value = model('');
    label = input('');
    min = input('');
    max = input('');
    helperText = input('');
    error = input('');
    required = input(false);
    disabled = input(false);
    cvaDisabled = signal(false);
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) { this.value.set(value ?? ''); }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(value) { this.cvaDisabled.set(value); }
    update(event) { const value = event.target.value; this.value.set(value); this.onChange(value); }
    touch() { this.onTouched(); }
    static ɵfac = function DatePickerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DatePickerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DatePickerComponent, selectors: [["orc-date-picker"]], inputs: { value: [1, "value"], label: [1, "label"], min: [1, "min"], max: [1, "max"], helperText: [1, "helperText"], error: [1, "error"], required: [1, "required"], disabled: [1, "disabled"] }, outputs: { value: "valueChange" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DatePickerComponent), multi: true }])], decls: 7, vars: 9, consts: [[1, "orc-date-picker"], [1, "orc-date-picker__label"], ["aria-hidden", "true"], ["type", "date", 3, "input", "blur", "value", "min", "max", "required", "disabled"], ["role", "alert", 1, "orc-date-picker__error"], [1, "orc-date-picker__help"]], template: function DatePickerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "label", 0)(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵtemplate(3, DatePickerComponent_Conditional_3_Template, 2, 0, "span", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "input", 3);
            i0.ɵɵlistener("input", function DatePickerComponent_Template_input_input_4_listener($event) { return ctx.update($event); })("blur", function DatePickerComponent_Template_input_blur_4_listener() { return ctx.touch(); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, DatePickerComponent_Conditional_5_Template, 2, 1, "span", 4)(6, DatePickerComponent_Conditional_6_Template, 2, 1, "span", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1("", ctx.label(), " ");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.required() ? 3 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("value", ctx.value())("min", ctx.min())("max", ctx.max())("required", ctx.required())("disabled", ctx.disabled() || ctx.cvaDisabled());
            i0.ɵɵattribute("aria-invalid", ctx.error() ? "true" : null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.error() ? 5 : ctx.helperText() ? 6 : -1);
        } }, styles: [".orc-date-picker[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-date-picker__label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.orc-date-picker[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{min-height:2.5rem;padding:0 var(--space-3);color:var(--text-primary);background:var(--orc-fill-input);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-date-picker[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:2px}.orc-date-picker__help[_ngcontent-%COMP%], .orc-date-picker__error[_ngcontent-%COMP%]{font-size:.75rem;color:var(--text-secondary)}.orc-date-picker__error[_ngcontent-%COMP%]{color:var(--color-error)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DatePickerComponent, [{
        type: Component,
        args: [{ selector: 'orc-date-picker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DatePickerComponent), multi: true }], template: "<label class=\"orc-date-picker\"><span class=\"orc-date-picker__label\">{{label()}} @if(required()){<span aria-hidden=\"true\">*</span>}</span><input type=\"date\" [value]=\"value()\" [min]=\"min()\" [max]=\"max()\" [required]=\"required()\" [disabled]=\"disabled() || cvaDisabled()\" [attr.aria-invalid]=\"error() ? 'true' : null\" (input)=\"update($event)\" (blur)=\"touch()\">@if(error()){<span class=\"orc-date-picker__error\" role=\"alert\">{{error()}}</span>}@else if(helperText()){<span class=\"orc-date-picker__help\">{{helperText()}}</span>}</label>\n", styles: [".orc-date-picker{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-date-picker__label{font-size:.875rem;font-weight:600}.orc-date-picker input{min-height:2.5rem;padding:0 var(--space-3);color:var(--text-primary);background:var(--orc-fill-input);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-date-picker input:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:2px}.orc-date-picker__help,.orc-date-picker__error{font-size:.75rem;color:var(--text-secondary)}.orc-date-picker__error{color:var(--color-error)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DatePickerComponent, { className: "DatePickerComponent", filePath: "date-picker.component.ts", lineNumber: 4 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { DatePickerComponent };
//# sourceMappingURL=ciag-orchestra-date-picker.mjs.map
