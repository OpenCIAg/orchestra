import * as i0 from '@angular/core';
import { InjectionToken, input, booleanAttribute, output, viewChild, inject, computed, signal, ChangeDetectionStrategy, Component, model, forwardRef } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const ORC_RADIO_GROUP = new InjectionToken('ORC_RADIO_GROUP');

const _c0$1 = ["nativeInput"];
const _c1 = ["*", "*"];
function RadioButtonComponent_span_6_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function RadioButtonComponent_span_6_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.description(), " ");
} }
function RadioButtonComponent_span_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtemplate(1, RadioButtonComponent_span_6_span_1_Template, 2, 1, "span", 8);
    i0.ɵɵprojection(2);
    i0.ɵɵtemplate(3, RadioButtonComponent_span_6_span_3_Template, 2, 1, "span", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.description());
} }
function RadioButtonComponent_span_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
} }
let nextUniqueId = 0;
class RadioButtonComponent {
    // Inputs (Signals API)
    value = input(undefined);
    label = input('');
    description = input('');
    disabled = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    name = input('');
    id = input('');
    ariaLabel = input('');
    // Outputs (Signals API)
    select = output();
    // Element reference ao input nativo para foco acessível
    inputElement = viewChild('nativeInput');
    // ID interno único
    uniqueId = `orc-radio-${++nextUniqueId}`;
    // Injeção desacoplada via InjectionToken
    radioGroup = inject(ORC_RADIO_GROUP, { optional: true });
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.id() || this.uniqueId);
    effectiveName = computed(() => {
        if (this.name())
            return this.name();
        if (this.radioGroup)
            return this.radioGroup.name();
        return this.uniqueId;
    });
    isDisabled = computed(() => {
        return this.disabled() || (this.radioGroup ? this.radioGroup.isDisabled() : false);
    });
    isError = computed(() => {
        return this.error() || (this.radioGroup ? this.radioGroup.isError() : false);
    });
    standaloneChecked = signal(false);
    isChecked = computed(() => {
        if (this.radioGroup) {
            return this.radioGroup.value() === this.value();
        }
        return this.standaloneChecked();
    });
    // Roving tabindex para acessibilidade WCAG
    tabIndex = computed(() => {
        if (this.isDisabled())
            return -1;
        if (!this.radioGroup)
            return 0;
        if (this.isChecked())
            return 0;
        if (!this.radioGroup.hasSelectedRadio() && this.radioGroup.isFirstEnabled(this)) {
            return 0;
        }
        return -1;
    });
    ngOnInit() {
        if (this.radioGroup) {
            this.radioGroup.registerRadio(this);
        }
    }
    ngOnDestroy() {
        if (this.radioGroup) {
            this.radioGroup.unregisterRadio(this);
        }
    }
    onSelect(event) {
        if (this.isDisabled()) {
            event?.preventDefault();
            return;
        }
        if (this.radioGroup) {
            this.radioGroup.select(this.value());
        }
        else {
            this.standaloneChecked.set(true);
        }
        this.select.emit(this.value());
    }
    onKeyDown(event) {
        if (this.radioGroup) {
            this.radioGroup.handleKeydown(event, this);
        }
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = function RadioButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RadioButtonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RadioButtonComponent, selectors: [["orc-radio-button"]], viewQuery: function RadioButtonComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.inputElement, _c0$1, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { value: [1, "value"], label: [1, "label"], description: [1, "description"], disabled: [1, "disabled"], error: [1, "error"], name: [1, "name"], id: [1, "id"], ariaLabel: [1, "ariaLabel"] }, outputs: { select: "select" }, ngContentSelectors: _c1, decls: 8, vars: 19, consts: [["nativeInput", ""], [1, "orc-radio"], ["type", "radio", 1, "orc-radio__native-input", 3, "change", "keydown", "id", "name", "value", "checked", "disabled", "tabindex"], ["aria-hidden", "true", 1, "orc-radio__box"], [1, "orc-radio__circle"], [1, "orc-radio__dot"], ["class", "orc-radio__content", 4, "ngIf"], [1, "orc-radio__content"], ["class", "orc-radio__label", 4, "ngIf"], ["class", "orc-radio__description", 4, "ngIf"], [1, "orc-radio__label"], [1, "orc-radio__description"]], template: function RadioButtonComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "label", 1)(1, "input", 2, 0);
            i0.ɵɵlistener("change", function RadioButtonComponent_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSelect($event)); })("keydown", function RadioButtonComponent_Template_input_keydown_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeyDown($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "span", 3)(4, "span", 4);
            i0.ɵɵelement(5, "span", 5);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(6, RadioButtonComponent_span_6_Template, 4, 2, "span", 6)(7, RadioButtonComponent_span_7_Template, 2, 0, "span", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-radio--checked", ctx.isChecked())("orc-radio--disabled", ctx.isDisabled())("orc-radio--error", ctx.isError());
            i0.ɵɵattribute("for", ctx.effectiveId());
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.effectiveName())("value", ctx.value())("checked", ctx.isChecked())("disabled", ctx.isDisabled())("tabindex", ctx.tabIndex());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-checked", ctx.isChecked())("aria-disabled", ctx.isDisabled())("aria-invalid", ctx.isError());
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("ngIf", ctx.label() || ctx.description());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.label() && !ctx.description());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-radio[_ngcontent-%COMP%]{display:inline-flex;align-items:flex-start;gap:var(--space-2, .5rem);position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.4}.orc-radio__native-input[_ngcontent-%COMP%]{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-radio__box[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:24px;height:24px;flex-shrink:0;position:relative;border-radius:var(--radius-full, 9999px);transition:background-color var(--transition-fast, .12s ease)}.orc-radio__circle[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:var(--radius-full, 9999px);border:2px solid #58595b;background-color:transparent;transition:border-color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease);position:relative;box-sizing:border-box}.orc-radio__dot[_ngcontent-%COMP%]{width:10px;height:10px;border-radius:var(--radius-full, 9999px);background-color:var(--orc-color-azul-eletrico, #1c6aed);transform:scale(0);opacity:0;transition:transform var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease)}.orc-radio__content[_ngcontent-%COMP%]{display:flex;flex-direction:column;padding-top:1.5px}.orc-radio__label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:400;color:var(--orc-font-main, #141414);line-height:1.45;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-radio__description[_ngcontent-%COMP%]{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-radio[_ngcontent-%COMP%]:hover:not(.orc-radio--disabled)   .orc-radio__circle[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-radio[_ngcontent-%COMP%]   .orc-radio__native-input[_ngcontent-%COMP%]:focus-visible + .orc-radio__box[_ngcontent-%COMP%]{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-radio--checked[_ngcontent-%COMP%]   .orc-radio__circle[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-radio--checked[_ngcontent-%COMP%]   .orc-radio__dot[_ngcontent-%COMP%]{transform:scale(1);opacity:1}.orc-radio--checked[_ngcontent-%COMP%]   .orc-radio__label[_ngcontent-%COMP%]{font-weight:500;color:var(--orc-font-main, #141414)}.orc-radio--error[_ngcontent-%COMP%]   .orc-radio__circle[_ngcontent-%COMP%]{border-color:var(--color-error, #fb2c36)!important}.orc-radio--error[_ngcontent-%COMP%]   .orc-radio__dot[_ngcontent-%COMP%]{background-color:var(--color-error, #fb2c36)!important}.orc-radio--error[_ngcontent-%COMP%]   .orc-radio__label[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}.orc-radio--error[_ngcontent-%COMP%]   .orc-radio__native-input[_ngcontent-%COMP%]:focus-visible + .orc-radio__box[_ngcontent-%COMP%]{outline-color:var(--color-error, #fb2c36)}.orc-radio--disabled[_ngcontent-%COMP%]{cursor:not-allowed;opacity:.45}.orc-radio--disabled[_ngcontent-%COMP%]   .orc-radio__circle[_ngcontent-%COMP%]{border-color:var(--orc-border, #d9d9d9);background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-radio--disabled[_ngcontent-%COMP%]   .orc-radio__dot[_ngcontent-%COMP%]{background-color:var(--orc-font-secondary, #666666)}.orc-radio--disabled[_ngcontent-%COMP%]   .orc-radio__label[_ngcontent-%COMP%], .orc-radio--disabled[_ngcontent-%COMP%]   .orc-radio__description[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RadioButtonComponent, [{
        type: Component,
        args: [{ selector: 'orc-radio-button', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<label\n  class=\"orc-radio\"\n  [class.orc-radio--checked]=\"isChecked()\"\n  [class.orc-radio--disabled]=\"isDisabled()\"\n  [class.orc-radio--error]=\"isError()\"\n  [attr.for]=\"effectiveId()\"\n>\n  <!-- Visually hidden native radio input for complete a11y and form integration -->\n  <input\n    #nativeInput\n    type=\"radio\"\n    class=\"orc-radio__native-input\"\n    [id]=\"effectiveId()\"\n    [name]=\"effectiveName()\"\n    [value]=\"value()\"\n    [checked]=\"isChecked()\"\n    [disabled]=\"isDisabled()\"\n    [tabindex]=\"tabIndex()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-checked]=\"isChecked()\"\n    [attr.aria-disabled]=\"isDisabled()\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onSelect($event)\"\n    (keydown)=\"onKeyDown($event)\"\n  />\n\n  <!-- Visual Custom Radio matching Figma 32:18402 -->\n  <span class=\"orc-radio__box\" aria-hidden=\"true\">\n    <span class=\"orc-radio__circle\">\n      <span class=\"orc-radio__dot\"></span>\n    </span>\n  </span>\n\n  <!-- Label and Description -->\n  <span class=\"orc-radio__content\" *ngIf=\"label() || description()\">\n    <span class=\"orc-radio__label\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-radio__description\" *ngIf=\"description()\">\n      {{ description() }}\n    </span>\n  </span>\n  <span class=\"orc-radio__content\" *ngIf=\"!label() && !description()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-radio{display:inline-flex;align-items:flex-start;gap:var(--space-2, .5rem);position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.4}.orc-radio__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-radio__box{display:flex;align-items:center;justify-content:center;width:24px;height:24px;flex-shrink:0;position:relative;border-radius:var(--radius-full, 9999px);transition:background-color var(--transition-fast, .12s ease)}.orc-radio__circle{display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:var(--radius-full, 9999px);border:2px solid #58595b;background-color:transparent;transition:border-color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease);position:relative;box-sizing:border-box}.orc-radio__dot{width:10px;height:10px;border-radius:var(--radius-full, 9999px);background-color:var(--orc-color-azul-eletrico, #1c6aed);transform:scale(0);opacity:0;transition:transform var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease)}.orc-radio__content{display:flex;flex-direction:column;padding-top:1.5px}.orc-radio__label{font-size:.875rem;font-weight:400;color:var(--orc-font-main, #141414);line-height:1.45;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-radio__description{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-radio:hover:not(.orc-radio--disabled) .orc-radio__circle{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-radio .orc-radio__native-input:focus-visible+.orc-radio__box{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-radio--checked .orc-radio__circle{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-radio--checked .orc-radio__dot{transform:scale(1);opacity:1}.orc-radio--checked .orc-radio__label{font-weight:500;color:var(--orc-font-main, #141414)}.orc-radio--error .orc-radio__circle{border-color:var(--color-error, #fb2c36)!important}.orc-radio--error .orc-radio__dot{background-color:var(--color-error, #fb2c36)!important}.orc-radio--error .orc-radio__label{color:var(--color-error, #fb2c36)}.orc-radio--error .orc-radio__native-input:focus-visible+.orc-radio__box{outline-color:var(--color-error, #fb2c36)}.orc-radio--disabled{cursor:not-allowed;opacity:.45}.orc-radio--disabled .orc-radio__circle{border-color:var(--orc-border, #d9d9d9);background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-radio--disabled .orc-radio__dot{background-color:var(--orc-font-secondary, #666666)}.orc-radio--disabled .orc-radio__label,.orc-radio--disabled .orc-radio__description{color:var(--orc-font-secondary, #666666)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RadioButtonComponent, { className: "RadioButtonComponent", filePath: "radio-button.component.ts", lineNumber: 28 }); })();

const _c0 = ["*"];
function RadioGroupComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.labelId);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label(), " ");
} }
function RadioGroupComponent_p_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.hintId);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.hint(), " ");
} }
function RadioGroupComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.errorId);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.errorMessage(), " ");
} }
let nextGroupUniqueId = 0;
class RadioGroupComponent {
    // Inputs (Signals API)
    name = input(`orc-radio-group-${++nextGroupUniqueId}`);
    layout = input('vertical');
    disabled = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    errorMessage = input('');
    label = input('');
    hint = input('');
    ariaLabel = input('');
    // Model & Outputs (Signals API)
    value = model(null);
    valueChange = output();
    // Estado interno
    cvaDisabled = signal(false);
    radios = signal([]);
    // Identificadores de acessibilidade
    groupId = `orc-radio-group-${nextGroupUniqueId}`;
    labelId = `${this.groupId}-label`;
    hintId = `${this.groupId}-hint`;
    errorId = `${this.groupId}-error`;
    isDisabled = computed(() => this.disabled() || this.cvaDisabled());
    isError = computed(() => this.error());
    // Callbacks do ControlValueAccessor
    onChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        this.value.set(val);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    registerRadio(radio) {
        this.radios.update((list) => [...list, radio]);
    }
    unregisterRadio(radio) {
        this.radios.update((list) => list.filter((r) => r !== radio));
    }
    select(val) {
        if (this.isDisabled())
            return;
        if (this.value() !== val) {
            this.value.set(val);
            this.onChange(val);
            this.valueChange.emit(val);
        }
        this.onTouched();
    }
    hasSelectedRadio() {
        const currentVal = this.value();
        return this.radios().some((r) => r.value() === currentVal);
    }
    isFirstEnabled(radio) {
        const enabledRadios = this.radios().filter((r) => !r.isDisabled());
        return enabledRadios.length > 0 && enabledRadios[0] === radio;
    }
    // Navegação WCAG por setas do teclado
    handleKeydown(event, currentRadio) {
        const enabledRadios = this.radios().filter((r) => !r.isDisabled());
        if (enabledRadios.length <= 1)
            return;
        const currentIndex = enabledRadios.indexOf(currentRadio);
        if (currentIndex === -1)
            return;
        let nextIndex = -1;
        switch (event.key) {
            case 'ArrowDown':
            case 'ArrowRight':
                nextIndex = (currentIndex + 1) % enabledRadios.length;
                break;
            case 'ArrowUp':
            case 'ArrowLeft':
                nextIndex = (currentIndex - 1 + enabledRadios.length) % enabledRadios.length;
                break;
            default:
                return;
        }
        event.preventDefault();
        const targetRadio = enabledRadios[nextIndex];
        if (targetRadio) {
            this.select(targetRadio.value());
            targetRadio.focus();
        }
    }
    static ɵfac = function RadioGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RadioGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RadioGroupComponent, selectors: [["orc-radio-group"]], inputs: { name: [1, "name"], layout: [1, "layout"], disabled: [1, "disabled"], error: [1, "error"], errorMessage: [1, "errorMessage"], label: [1, "label"], hint: [1, "hint"], ariaLabel: [1, "ariaLabel"], value: [1, "value"] }, outputs: { value: "valueChange", valueChange: "valueChange" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => RadioGroupComponent),
                    multi: true,
                },
                {
                    provide: ORC_RADIO_GROUP,
                    useExisting: forwardRef(() => RadioGroupComponent),
                },
            ])], ngContentSelectors: _c0, decls: 6, vars: 15, consts: [["role", "radiogroup", 1, "orc-radio-group"], ["class", "orc-radio-group__label", 3, "id", 4, "ngIf"], ["class", "orc-radio-group__hint", 3, "id", 4, "ngIf"], [1, "orc-radio-group__options"], ["class", "orc-radio-group__error-message", "role", "alert", 3, "id", 4, "ngIf"], [1, "orc-radio-group__label", 3, "id"], [1, "orc-radio-group__hint", 3, "id"], ["role", "alert", 1, "orc-radio-group__error-message", 3, "id"]], template: function RadioGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, RadioGroupComponent_div_1_Template, 2, 2, "div", 1)(2, RadioGroupComponent_p_2_Template, 2, 2, "p", 2);
            i0.ɵɵelementStart(3, "div", 3);
            i0.ɵɵprojection(4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, RadioGroupComponent_div_5_Template, 2, 2, "div", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-radio-group--horizontal", ctx.layout() === "horizontal")("orc-radio-group--vertical", ctx.layout() === "vertical")("orc-radio-group--disabled", ctx.isDisabled())("orc-radio-group--error", ctx.isError());
            i0.ɵɵattribute("aria-labelledby", ctx.label() ? ctx.labelId : null)("aria-label", !ctx.label() && ctx.ariaLabel() ? ctx.ariaLabel() : null)("aria-describedby", ctx.isError() && ctx.errorMessage() ? ctx.errorId : ctx.hint() ? ctx.hintId : null)("aria-invalid", ctx.isError());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.hint());
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isError() && ctx.errorMessage());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:block}.orc-radio-group[_ngcontent-%COMP%]{display:flex;flex-direction:column;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-radio-group__label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__hint[_ngcontent-%COMP%]{font-size:.8125rem;color:var(--orc-font-secondary, #666666);margin-top:calc(-1 * var(--space-1, .25rem));margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__options[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:10px}.orc-radio-group--horizontal[_ngcontent-%COMP%]   .orc-radio-group__options[_ngcontent-%COMP%]{flex-direction:row;flex-wrap:wrap;align-items:center;gap:var(--space-6, 1.5rem)}.orc-radio-group__error-message[_ngcontent-%COMP%]{font-size:.8125rem;font-weight:500;color:var(--color-error, #fb2c36);margin-top:var(--space-2, .5rem);display:flex;align-items:center;gap:var(--space-1, .25rem)}.orc-radio-group--disabled[_ngcontent-%COMP%]   .orc-radio-group__label[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RadioGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-radio-group', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => RadioGroupComponent),
                        multi: true,
                    },
                    {
                        provide: ORC_RADIO_GROUP,
                        useExisting: forwardRef(() => RadioGroupComponent),
                    },
                ], template: "<div\n  class=\"orc-radio-group\"\n  [class.orc-radio-group--horizontal]=\"layout() === 'horizontal'\"\n  [class.orc-radio-group--vertical]=\"layout() === 'vertical'\"\n  [class.orc-radio-group--disabled]=\"isDisabled()\"\n  [class.orc-radio-group--error]=\"isError()\"\n  role=\"radiogroup\"\n  [attr.aria-labelledby]=\"label() ? labelId : null\"\n  [attr.aria-label]=\"!label() && ariaLabel() ? ariaLabel() : null\"\n  [attr.aria-describedby]=\"isError() && errorMessage() ? errorId : (hint() ? hintId : null)\"\n  [attr.aria-invalid]=\"isError()\"\n>\n  <!-- Group Label / Header -->\n  <div *ngIf=\"label()\" class=\"orc-radio-group__label\" [id]=\"labelId\">\n    {{ label() }}\n  </div>\n\n  <!-- Optional Hint -->\n  <p *ngIf=\"hint()\" class=\"orc-radio-group__hint\" [id]=\"hintId\">\n    {{ hint() }}\n  </p>\n\n  <!-- Options Container with Column or Row layout -->\n  <div class=\"orc-radio-group__options\">\n    <ng-content></ng-content>\n  </div>\n\n  <!-- Error Message -->\n  <div\n    *ngIf=\"isError() && errorMessage()\"\n    class=\"orc-radio-group__error-message\"\n    [id]=\"errorId\"\n    role=\"alert\"\n  >\n    {{ errorMessage() }}\n  </div>\n</div>\n", styles: [":host{display:block}.orc-radio-group{display:flex;flex-direction:column;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-radio-group__label{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__hint{font-size:.8125rem;color:var(--orc-font-secondary, #666666);margin-top:calc(-1 * var(--space-1, .25rem));margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__options{display:flex;flex-direction:column;gap:10px}.orc-radio-group--horizontal .orc-radio-group__options{flex-direction:row;flex-wrap:wrap;align-items:center;gap:var(--space-6, 1.5rem)}.orc-radio-group__error-message{font-size:.8125rem;font-weight:500;color:var(--color-error, #fb2c36);margin-top:var(--space-2, .5rem);display:flex;align-items:center;gap:var(--space-1, .25rem)}.orc-radio-group--disabled .orc-radio-group__label{color:var(--orc-font-secondary, #666666)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RadioGroupComponent, { className: "RadioGroupComponent", filePath: "radio-group.component.ts", lineNumber: 37 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ORC_RADIO_GROUP, RadioButtonComponent, RadioGroupComponent };
//# sourceMappingURL=ciag-orchestra-radio.mjs.map
