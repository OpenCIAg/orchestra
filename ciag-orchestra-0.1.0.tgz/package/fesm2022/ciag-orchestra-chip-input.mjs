import * as i0 from '@angular/core';
import { input, booleanAttribute, numberAttribute, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { InputComponent } from '@ciag/orchestra/input';
import { BadgeComponent } from '@ciag/orchestra/badge';

function ChipInputComponent_For_5_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "orc-badge", 7);
    i0.ɵɵlistener("dismiss", function ChipInputComponent_For_5_Template_orc_badge_dismiss_0_listener() { const $index_r4 = i0.ɵɵrestoreView(_r3).$index; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.removeChip($index_r4)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const chip_r6 = ctx.$implicit;
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵproperty("pill", false)("size", ctx_r4.size() === "lg" ? "md" : "sm")("dismissible", !ctx_r4.effectiveDisabled() && !ctx_r4.readonly());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", chip_r6, " ");
} }
function ChipInputComponent_Conditional_6_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 9);
    i0.ɵɵlistener("mousedown", function ChipInputComponent_Conditional_6_For_2_Template_li_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r7); return i0.ɵɵresetView($event.preventDefault()); })("click", function ChipInputComponent_Conditional_6_For_2_Template_li_click_0_listener() { const suggestion_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r4 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r4.selectSuggestion(suggestion_r8)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const suggestion_r8 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", suggestion_r8, " ");
} }
function ChipInputComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 5);
    i0.ɵɵrepeaterCreate(1, ChipInputComponent_Conditional_6_For_2_Template, 2, 1, "li", 8, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r4.filteredSuggestions());
} }
class ChipInputComponent {
    // ── Inputs ──────────────────────────────────────────────────
    id = input('');
    label = input('');
    placeholder = input('Digite e pressione Enter...');
    helperText = input('');
    errorMessage = input('');
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    size = input('md');
    // Chip specific config
    allowDuplicates = input(false, { transform: booleanAttribute });
    maxChips = input(undefined, {
        transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined),
    });
    separatorKeyCodes = input(['Enter', ',', ' ']);
    suggestions = input([]);
    // ── Outputs ─────────────────────────────────────────────────
    chipsChange = output();
    maxReached = output();
    // ── Estado Interno ──────────────────────────────────────────
    value = signal([]);
    inputValue = signal('');
    a11yMessage = signal('');
    cvaDisabled = signal(false);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    status = computed(() => this.errorMessage() ? 'error' : 'default');
    filteredSuggestions = computed(() => {
        const term = this.inputValue().toLowerCase().trim();
        if (!term)
            return [];
        return this.suggestions()
            .filter(s => s.toLowerCase().includes(term))
            .filter(s => !this.value().includes(s)); // Evita sugerir chips já adicionados
    });
    isSuggestionsVisible = computed(() => {
        return this.filteredSuggestions().length > 0 && !this.effectiveDisabled() && !this.readonly();
    });
    // ── ControlValueAccessor ───────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        if (Array.isArray(val)) {
            this.value.set([...val]);
        }
        else {
            this.value.set([]);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers ────────────────────────────────────────────────
    onInputChange(val) {
        this.inputValue.set(String(val));
    }
    onKeydown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const currentInput = this.inputValue().trim();
        // Adicionar Chip
        if (this.separatorKeyCodes().includes(event.key)) {
            event.preventDefault();
            if (currentInput) {
                this.addChip(currentInput);
            }
        }
        // Remover último Chip no Backspace se input estiver vazio
        if (event.key === 'Backspace' && currentInput === '' && this.value().length > 0) {
            this.removeChip(this.value().length - 1);
        }
    }
    onPaste(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const clipboardData = event.clipboardData;
        const pastedText = clipboardData?.getData('text');
        if (pastedText) {
            event.preventDefault();
            // Separar por vírgula ou quebra de linha
            const items = pastedText.split(/[\n,]+/).map(item => item.trim()).filter(item => item.length > 0);
            items.forEach(item => this.addChip(item, true));
            this.updateFormAndEmit();
        }
    }
    onBlur() {
        this.onTouched();
        const currentInput = this.inputValue().trim();
        if (currentInput) {
            this.addChip(currentInput);
        }
    }
    // ── Lógica de Chips ─────────────────────────────────────────
    selectSuggestion(item) {
        this.addChip(item);
    }
    addChip(item, skipEmit = false) {
        const max = this.maxChips();
        const current = this.value();
        if (max !== undefined && current.length >= max) {
            this.maxReached.emit();
            return;
        }
        if (!this.allowDuplicates() && current.includes(item)) {
            return; // Previne duplicatas
        }
        this.value.update(arr => [...arr, item]);
        this.inputValue.set('');
        // Atualiza A11y
        this.a11yMessage.set(`Item ${item} adicionado.`);
        if (!skipEmit) {
            this.updateFormAndEmit();
        }
    }
    removeChip(index) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const current = this.value();
        const removedItem = current[index];
        this.value.update(arr => arr.filter((_, i) => i !== index));
        this.a11yMessage.set(`Item ${removedItem} removido.`);
        this.updateFormAndEmit();
    }
    updateFormAndEmit() {
        const currentVal = this.value();
        this.onChange(currentVal);
        this.chipsChange.emit(currentVal);
    }
    static ɵfac = function ChipInputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChipInputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChipInputComponent, selectors: [["orc-chip-input"]], inputs: { id: [1, "id"], label: [1, "label"], placeholder: [1, "placeholder"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], disabled: [1, "disabled"], readonly: [1, "readonly"], size: [1, "size"], allowDuplicates: [1, "allowDuplicates"], maxChips: [1, "maxChips"], separatorKeyCodes: [1, "separatorKeyCodes"], suggestions: [1, "suggestions"] }, outputs: { chipsChange: "chipsChange", maxReached: "maxReached" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => ChipInputComponent),
                    multi: true,
                },
            ])], decls: 9, vars: 12, consts: [["orcInput", ""], [1, "orc-chip-input"], [3, "inputChange", "keydown", "paste", "blur", "id", "label", "helperText", "errorMessage", "disabled", "readonly", "size", "placeholder", "status", "value"], ["orcPrefix", "", 1, "orc-chip-list", 3, "click"], ["variant", "soft", "status", "primary", 1, "orc-chip-item", 3, "pill", "size", "dismissible"], ["role", "listbox", 1, "orc-chip-suggestions"], ["aria-live", "polite", 1, "sr-only"], ["variant", "soft", "status", "primary", 1, "orc-chip-item", 3, "dismiss", "pill", "size", "dismissible"], ["role", "option", 1, "orc-chip-suggestion-item"], ["role", "option", 1, "orc-chip-suggestion-item", 3, "mousedown", "click"]], template: function ChipInputComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "orc-input", 2, 0);
            i0.ɵɵlistener("inputChange", function ChipInputComponent_Template_orc_input_inputChange_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onInputChange($event)); })("keydown", function ChipInputComponent_Template_orc_input_keydown_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeydown($event)); })("paste", function ChipInputComponent_Template_orc_input_paste_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onPaste($event)); })("blur", function ChipInputComponent_Template_orc_input_blur_1_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur()); });
            i0.ɵɵelementStart(3, "div", 3);
            i0.ɵɵlistener("click", function ChipInputComponent_Template_div_click_3_listener() { i0.ɵɵrestoreView(_r1); const orcInput_r2 = i0.ɵɵreference(2); return i0.ɵɵresetView(orcInput_r2.focusNative()); });
            i0.ɵɵrepeaterCreate(4, ChipInputComponent_For_5_Template, 2, 4, "orc-badge", 4, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(6, ChipInputComponent_Conditional_6_Template, 3, 0, "ul", 5);
            i0.ɵɵelementStart(7, "div", 6);
            i0.ɵɵtext(8);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.id())("label", ctx.label())("helperText", ctx.helperText())("errorMessage", ctx.errorMessage())("disabled", ctx.effectiveDisabled())("readonly", ctx.readonly())("size", ctx.size())("placeholder", ctx.value().length > 0 ? "" : ctx.placeholder())("status", ctx.status())("value", ctx.inputValue());
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.value());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.isSuggestionsVisible() ? 6 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", ctx.a11yMessage(), " ");
        } }, dependencies: [CommonModule, InputComponent, BadgeComponent], styles: ["@charset \"UTF-8\";[_nghost-%COMP%]{display:block;width:100%}.orc-chip-input[_ngcontent-%COMP%]{width:100%;position:relative}.orc-chip-input[_ngcontent-%COMP%]     .orc-input-box{flex-wrap:wrap;height:auto!important;padding-top:4px;padding-bottom:4px;gap:4px 8px}.orc-chip-input[_ngcontent-%COMP%]     .orc-input__slot--prefix{flex-wrap:wrap;gap:6px;max-width:100%}.orc-chip-input[_ngcontent-%COMP%]     .orc-input__native{min-width:120px;flex:1 1 auto;padding:4px 0}.orc-chip-list[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.orc-chip-item[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_fadeIn .2s ease}.orc-chip-suggestions[_ngcontent-%COMP%]{position:absolute;top:100%;left:0;width:100%;max-height:220px;overflow-y:auto;background:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:8px;box-shadow:0 4px 12px #0000001a;margin-top:4px;padding:4px 0;list-style:none;z-index:1000}.orc-chip-suggestion-item[_ngcontent-%COMP%]{padding:8px 12px;font-size:14px;cursor:pointer;color:var(--orc-font-main, #141414);transition:background-color var(--transition-fast, .2s ease)}.orc-chip-suggestion-item[_ngcontent-%COMP%]:hover{background:var(--orc-highlight-cinza-claro, #ededed)}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes _ngcontent-%COMP%_fadeIn{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChipInputComponent, [{
        type: Component,
        args: [{ selector: 'orc-chip-input', standalone: true, imports: [CommonModule, InputComponent, BadgeComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => ChipInputComponent),
                        multi: true,
                    },
                ], template: "<div class=\"orc-chip-input\">\n  <!-- Utilizamos o InputComponent estritamente como container -->\n  <orc-input\n    #orcInput\n    [id]=\"id()\"\n    [label]=\"label()\"\n    [helperText]=\"helperText()\"\n    [errorMessage]=\"errorMessage()\"\n    [disabled]=\"effectiveDisabled()\"\n    [readonly]=\"readonly()\"\n    [size]=\"size()\"\n    [placeholder]=\"value().length > 0 ? '' : placeholder()\"\n    [status]=\"status()\"\n    [value]=\"inputValue()\"\n    (inputChange)=\"onInputChange($event)\"\n    (keydown)=\"onKeydown($event)\"\n    (paste)=\"onPaste($event)\"\n    (blur)=\"onBlur()\"\n  >\n    <!-- Slot de Prefixo: Renderiza as Tags internamente -->\n    <div orcPrefix class=\"orc-chip-list\" (click)=\"orcInput.focusNative()\">\n      @for (chip of value(); track $index) {\n        <orc-badge\n          variant=\"soft\"\n          status=\"primary\"\n          [pill]=\"false\"\n          [size]=\"size() === 'lg' ? 'md' : 'sm'\"\n          [dismissible]=\"!effectiveDisabled() && !readonly()\"\n          (dismiss)=\"removeChip($index)\"\n          class=\"orc-chip-item\"\n        >\n          {{ chip }}\n        </orc-badge>\n      }\n    </div>\n  </orc-input>\n\n  <!-- Autocomplete Dropdown / Sugest\u00F5es -->\n  @if (isSuggestionsVisible()) {\n    <ul class=\"orc-chip-suggestions\" role=\"listbox\">\n      @for (suggestion of filteredSuggestions(); track suggestion) {\n        <li\n          class=\"orc-chip-suggestion-item\"\n          role=\"option\"\n          (mousedown)=\"$event.preventDefault()\" \n          (click)=\"selectSuggestion(suggestion)\"\n        >\n          {{ suggestion }}\n        </li>\n      }\n    </ul>\n  }\n\n  <!-- Regi\u00E3o para Leitores de Tela (Acessibilidade) -->\n  <div aria-live=\"polite\" class=\"sr-only\">\n    {{ a11yMessage() }}\n  </div>\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;width:100%}.orc-chip-input{width:100%;position:relative}.orc-chip-input ::ng-deep .orc-input-box{flex-wrap:wrap;height:auto!important;padding-top:4px;padding-bottom:4px;gap:4px 8px}.orc-chip-input ::ng-deep .orc-input__slot--prefix{flex-wrap:wrap;gap:6px;max-width:100%}.orc-chip-input ::ng-deep .orc-input__native{min-width:120px;flex:1 1 auto;padding:4px 0}.orc-chip-list{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.orc-chip-item{animation:fadeIn .2s ease}.orc-chip-suggestions{position:absolute;top:100%;left:0;width:100%;max-height:220px;overflow-y:auto;background:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:8px;box-shadow:0 4px 12px #0000001a;margin-top:4px;padding:4px 0;list-style:none;z-index:1000}.orc-chip-suggestion-item{padding:8px 12px;font-size:14px;cursor:pointer;color:var(--orc-font-main, #141414);transition:background-color var(--transition-fast, .2s ease)}.orc-chip-suggestion-item:hover{background:var(--orc-highlight-cinza-claro, #ededed)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes fadeIn{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ChipInputComponent, { className: "ChipInputComponent", filePath: "chip-input.component.ts", lineNumber: 32 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ChipInputComponent };
//# sourceMappingURL=ciag-orchestra-chip-input.mjs.map
