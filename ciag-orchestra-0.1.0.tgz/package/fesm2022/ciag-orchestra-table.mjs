import * as i0 from '@angular/core';
import { inject, TemplateRef, Directive, input, booleanAttribute, contentChild, model, output, contentChildren, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { CheckboxComponent } from '@ciag/orchestra/checkbox';
import { PaginatorComponent } from '@ciag/orchestra/paginator';
import { SkeletonComponent } from '@ciag/orchestra/skeleton';

class CellDefDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = function CellDefDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CellDefDirective)(); };
    static ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: CellDefDirective, selectors: [["", "orcCellDef", ""], ["", "appCellDef", ""]] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CellDefDirective, [{
        type: Directive,
        args: [{
                selector: '[orcCellDef], [appCellDef]',
                standalone: true,
            }]
    }], null, null); })();
class HeaderCellDefDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = function HeaderCellDefDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || HeaderCellDefDirective)(); };
    static ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: HeaderCellDefDirective, selectors: [["", "orcHeaderCellDef", ""], ["", "appHeaderCellDef", ""]] });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HeaderCellDefDirective, [{
        type: Directive,
        args: [{
                selector: '[orcHeaderCellDef], [appHeaderCellDef]',
                standalone: true,
            }]
    }], null, null); })();

class ColumnDirective {
    /** Chave do objeto que identifica a propriedade da coluna */
    key = input.required();
    /** Título do cabeçalho da coluna */
    header = input('');
    /** Habilita ordenação para esta coluna */
    sortable = input(false, { transform: booleanAttribute });
    /** Largura customizada da coluna (ex: '120px', '20%') */
    width = input('');
    /** Alinhamento do conteúdo: 'left' | 'center' | 'right' */
    align = input('left');
    /** Template customizado de corpo da célula */
    cellTemplate = contentChild(CellDefDirective);
    /** Template customizado de cabeçalho da coluna */
    headerTemplate = contentChild(HeaderCellDefDirective);
    static ɵfac = function ColumnDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ColumnDirective)(); };
    static ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: ColumnDirective, selectors: [["orc-column"], ["app-column"]], contentQueries: function ColumnDirective_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.cellTemplate, CellDefDirective, 5);
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.headerTemplate, HeaderCellDefDirective, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(2);
        } }, inputs: { key: [1, "key"], header: [1, "header"], sortable: [1, "sortable"], width: [1, "width"], align: [1, "align"] } });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnDirective, [{
        type: Directive,
        args: [{
                selector: 'orc-column, app-column',
                standalone: true,
            }]
    }], null, null); })();

const _c0 = a0 => ({ column: a0 });
const _c1 = (a0, a1, a2, a3, a4) => ({ $implicit: a0, row: a1, index: a2, column: a3, value: a4 });
const _forTrack0 = ($index, $item) => $item.key();
function _forTrack1($index, $item) { return this.getRowId($item); }
function TableComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "th", 5)(1, "orc-checkbox", 10);
    i0.ɵɵlistener("change", function TableComponent_Conditional_5_Template_orc_checkbox_change_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggleSelectAll($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r1.isAllSelected())("indeterminate", ctx_r1.isSomeSelected());
} }
function TableComponent_For_7_Conditional_1_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function TableComponent_For_7_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, TableComponent_For_7_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 13);
} if (rf & 2) {
    const col_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("ngTemplateOutlet", ctx.templateRef)("ngTemplateOutletContext", i0.ɵɵpureFunction1(2, _c0, col_r4));
} }
function TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 18);
    i0.ɵɵelement(1, "path", 19);
    i0.ɵɵelementEnd();
} }
function TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 18);
    i0.ɵɵelement(1, "path", 20);
    i0.ɵɵelementEnd();
} }
function TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Conditional_0_Template, 2, 0, ":svg:svg", 18)(1, TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Conditional_1_Template, 2, 0, ":svg:svg", 18);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵconditional(ctx_r1.sortDirection() === "asc" ? 0 : ctx_r1.sortDirection() === "desc" ? 1 : -1);
} }
function TableComponent_For_7_Conditional_2_Conditional_3_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 21);
    i0.ɵɵelementEnd();
} }
function TableComponent_For_7_Conditional_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtemplate(1, TableComponent_For_7_Conditional_2_Conditional_3_Conditional_1_Template, 2, 1)(2, TableComponent_For_7_Conditional_2_Conditional_3_Conditional_2_Template, 2, 0, ":svg:svg", 17);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r4 = i0.ɵɵnextContext(2).$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.sortColumn() === col_r4.key() ? 1 : 2);
} }
function TableComponent_For_7_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14)(1, "span", 15);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, TableComponent_For_7_Conditional_2_Conditional_3_Template, 3, 1, "span", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵstyleProp("justify-content", col_r4.align() === "center" ? "center" : col_r4.align() === "right" ? "flex-end" : "flex-start");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(col_r4.header());
    i0.ɵɵadvance();
    i0.ɵɵconditional(col_r4.sortable() ? 3 : -1);
} }
function TableComponent_For_7_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "th", 11);
    i0.ɵɵlistener("click", function TableComponent_For_7_Template_th_click_0_listener() { const col_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleSort(col_r4.key(), col_r4.sortable())); })("keydown.enter", function TableComponent_For_7_Template_th_keydown_enter_0_listener() { const col_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleSort(col_r4.key(), col_r4.sortable())); })("keydown.space", function TableComponent_For_7_Template_th_keydown_space_0_listener($event) { const col_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(); ctx_r1.handleSort(col_r4.key(), col_r4.sortable()); return i0.ɵɵresetView($event.preventDefault()); });
    i0.ɵɵtemplate(1, TableComponent_For_7_Conditional_1_Template, 1, 4, "ng-container")(2, TableComponent_For_7_Conditional_2_Template, 4, 4, "div", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_16_0;
    const col_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("width", col_r4.width() || null)("text-align", col_r4.align());
    i0.ɵɵclassProp("orc-table__th--sortable", col_r4.sortable())("orc-table__th--sorted", ctx_r1.sortColumn() === col_r4.key());
    i0.ɵɵproperty("tabindex", col_r4.sortable() ? 0 : -1);
    i0.ɵɵattribute("aria-sort", ctx_r1.getAriaSort(col_r4.key(), col_r4.sortable()));
    i0.ɵɵadvance();
    i0.ɵɵconditional((tmp_16_0 = col_r4.headerTemplate()) ? 1 : 2, tmp_16_0);
} }
function TableComponent_Conditional_9_For_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 23);
    i0.ɵɵelement(1, "orc-skeleton", 25);
    i0.ɵɵelementEnd();
} }
function TableComponent_Conditional_9_For_1_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 24);
    i0.ɵɵelement(1, "orc-skeleton", 26);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r5 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("width", col_r5.key() === "id" ? "40px" : "75%");
} }
function TableComponent_Conditional_9_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr", 22);
    i0.ɵɵtemplate(1, TableComponent_Conditional_9_For_1_Conditional_1_Template, 2, 0, "td", 23);
    i0.ɵɵrepeaterCreate(2, TableComponent_Conditional_9_For_1_For_3_Template, 2, 1, "td", 24, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.selectable() ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.declaredColumns());
} }
function TableComponent_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, TableComponent_Conditional_9_For_1_Template, 4, 1, "tr", 22, i0.ɵɵrepeaterTrackByIdentity);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r1.getSkeletonArray());
} }
function TableComponent_Conditional_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr", 8)(1, "td", 27)(2, "div", 28)(3, "div", 29);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(4, "svg", 30);
    i0.ɵɵelement(5, "rect", 31)(6, "line", 32)(7, "line", 33);
    i0.ɵɵelementEnd()();
    i0.ɵɵnamespaceHTML();
    i0.ɵɵelementStart(8, "h4", 34);
    i0.ɵɵtext(9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "p", 35);
    i0.ɵɵtext(11);
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵattribute("colspan", ctx_r1.declaredColumns().length + (ctx_r1.selectable() ? 1 : 0));
    i0.ɵɵadvance(8);
    i0.ɵɵtextInterpolate(ctx_r1.emptyTitle());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.emptyMessage());
} }
function TableComponent_Conditional_11_For_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 39);
    i0.ɵɵlistener("click", function TableComponent_Conditional_11_For_1_Conditional_2_Template_td_click_0_listener($event) { i0.ɵɵrestoreView(_r8); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(1, "orc-checkbox", 40);
    i0.ɵɵlistener("change", function TableComponent_Conditional_11_For_1_Conditional_2_Template_orc_checkbox_change_1_listener($event) { i0.ɵɵrestoreView(_r8); const row_r7 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.toggleRowSelect(row_r7, $event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ɵ$index_89_r9 = i0.ɵɵnextContext().$index;
    const selected_r10 = i0.ɵɵreadContextLet(0);
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", selected_r10)("ariaLabel", "Selecionar linha " + (ɵ$index_89_r9 + 1));
} }
function TableComponent_Conditional_11_For_1_For_4_Conditional_1_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function TableComponent_Conditional_11_For_1_For_4_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, TableComponent_Conditional_11_For_1_For_4_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 13);
} if (rf & 2) {
    const col_r11 = i0.ɵɵnextContext().$implicit;
    const ctx_r11 = i0.ɵɵnextContext();
    const row_r7 = ctx_r11.$implicit;
    const ɵ$index_89_r9 = ctx_r11.$index;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngTemplateOutlet", ctx.templateRef)("ngTemplateOutletContext", i0.ɵɵpureFunction5(2, _c1, row_r7, row_r7, ɵ$index_89_r9, col_r11, ctx_r1.getCellValue(row_r7, col_r11.key())));
} }
function TableComponent_Conditional_11_For_1_For_4_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 41);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r11 = i0.ɵɵnextContext().$implicit;
    const row_r7 = i0.ɵɵnextContext().$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.getCellValue(row_r7, col_r11.key()));
} }
function TableComponent_Conditional_11_For_1_For_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 24);
    i0.ɵɵtemplate(1, TableComponent_Conditional_11_For_1_For_4_Conditional_1_Template, 1, 8, "ng-container")(2, TableComponent_Conditional_11_For_1_For_4_Conditional_2_Template, 2, 1, "span", 41);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_24_0;
    const col_r11 = ctx.$implicit;
    i0.ɵɵstyleProp("text-align", col_r11.align());
    i0.ɵɵadvance();
    i0.ɵɵconditional((tmp_24_0 = col_r11.cellTemplate()) ? 1 : 2, tmp_24_0);
} }
function TableComponent_Conditional_11_For_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵdeclareLet(0);
    i0.ɵɵelementStart(1, "tr", 37);
    i0.ɵɵlistener("click", function TableComponent_Conditional_11_For_1_Template_tr_click_1_listener() { const row_r7 = i0.ɵɵrestoreView(_r6).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.handleRowClick(row_r7)); });
    i0.ɵɵtemplate(2, TableComponent_Conditional_11_For_1_Conditional_2_Template, 2, 2, "td", 23);
    i0.ɵɵrepeaterCreate(3, TableComponent_Conditional_11_For_1_For_4_Template, 3, 3, "td", 38, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r7 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    const selected_r13 = i0.ɵɵstoreLet(ctx_r1.isRowSelected(row_r7));
    i0.ɵɵadvance();
    i0.ɵɵclassProp("orc-table__row--selected", selected_r13);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.selectable() ? 2 : -1);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.declaredColumns());
} }
function TableComponent_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, TableComponent_Conditional_11_For_1_Template, 5, 4, "tr", 36, _forTrack1, true);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r1.displayData());
} }
function TableComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 9)(1, "orc-paginator", 42);
    i0.ɵɵtwoWayListener("pageSizeChange", function TableComponent_Conditional_12_Template_orc_paginator_pageSizeChange_1_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.pageSize, $event) || (ctx_r1.pageSize = $event); return i0.ɵɵresetView($event); })("currentPageChange", function TableComponent_Conditional_12_Template_orc_paginator_currentPageChange_1_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.currentPage, $event) || (ctx_r1.currentPage = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("totalItems", ctx_r1.effectiveTotalItems());
    i0.ɵɵtwoWayProperty("pageSize", ctx_r1.pageSize)("currentPage", ctx_r1.currentPage);
    i0.ɵɵproperty("pageSizeOptions", ctx_r1.pageSizeOptions())("showPageSizeSelector", true);
} }
class TableComponent {
    // ── Inputs de Dados e Configuração ────────────────────────
    /** Dados a serem exibidos na tabela */
    data = input([]);
    /** Configuração direta de colunas (alternativa ao uso de <orc-column>) */
    columnsConfig = input(undefined);
    /** Propriedade identificadora única de cada linha (padrão: 'id') */
    rowKey = input('id');
    // ── Seleção de Linhas ─────────────────────────────────────
    /** Habilita seleção de linhas com checkbox na primeira coluna */
    selectable = input(false, { transform: booleanAttribute });
    /** Linhas selecionadas (Two-Way Binding) */
    selectedRows = model([]);
    /** Evento emitido quando a seleção muda */
    selectionChange = output();
    // ── Ordenação ─────────────────────────────────────────────
    /** Chave da coluna ordenada atualmente */
    sortColumn = model('');
    /** Direção da ordenação atual: 'asc' | 'desc' | 'none' */
    sortDirection = model('none');
    /** Evento emitido quando o usuário clica para ordenar uma coluna */
    sortChange = output();
    // ── Estilos e Variantes Visuais (Figma Spec) ───────────────
    /** Linhas zebradas alternadas */
    striped = input(false, { transform: booleanAttribute });
    /** Bordas ao redor da tabela e células */
    bordered = input(true, { transform: booleanAttribute });
    /** Realce visual no hover sobre as linhas */
    hoverable = input(true, { transform: booleanAttribute });
    // ── Estados de Carregamento e Vazio ───────────────────────
    /** Exibe estado de carregamento com Skeletons */
    loading = input(false, { transform: booleanAttribute });
    /** Quantidade de linhas skeleton a renderizar durante loading */
    loadingRowsCount = input(5);
    /** Título principal do estado vazio */
    emptyTitle = input('Nenhum dado encontrado');
    /** Mensagem descritiva do estado vazio */
    emptyMessage = input('Não há registros para serem exibidos no momento.');
    // ── Paginação Integrada ────────────────────────────────────
    /** Habilita rodapé com PaginatorComponent integrado */
    paginated = input(false, { transform: booleanAttribute });
    /** Quantidade de itens por página (Two-Way Binding) */
    pageSize = model(5);
    /** Página atual (1-indexed, Two-Way Binding) */
    currentPage = model(1);
    /** Total de itens para paginação do lado do servidor (se omitido, usa data().length) */
    totalItems = input(undefined);
    /** Opções de tamanho de página */
    pageSizeOptions = input([5, 10, 20, 50]);
    // ── Evento de Clique na Linha ─────────────────────────────
    rowClick = output();
    // ── Diretivas Filhas (<orc-column>) ───────────────────────
    declaredColumns = contentChildren(ColumnDirective);
    // ── Computeds ─────────────────────────────────────────────
    effectiveTotalItems = computed(() => {
        const custom = this.totalItems();
        return custom !== undefined ? custom : this.data().length;
    });
    /** Dados ordenados localmente */
    sortedData = computed(() => {
        const raw = [...this.data()];
        const col = this.sortColumn();
        const dir = this.sortDirection();
        if (!col || dir === 'none') {
            return raw;
        }
        return raw.sort((a, b) => {
            const valA = a?.[col];
            const valB = b?.[col];
            if (valA === valB)
                return 0;
            if (valA === null || valA === undefined)
                return 1;
            if (valB === null || valB === undefined)
                return -1;
            let comparison = 0;
            if (typeof valA === 'string' && typeof valB === 'string') {
                comparison = valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' });
            }
            else {
                comparison = valA < valB ? -1 : 1;
            }
            return dir === 'asc' ? comparison : -comparison;
        });
    });
    /** Dados exibidos na página atual */
    displayData = computed(() => {
        const sorted = this.sortedData();
        if (!this.paginated()) {
            return sorted;
        }
        const page = Math.max(1, this.currentPage());
        const size = Math.max(1, this.pageSize());
        const start = (page - 1) * size;
        return sorted.slice(start, start + size);
    });
    /** Verifica se todas as linhas da página atual estão selecionadas */
    isAllSelected = computed(() => {
        const current = this.displayData();
        if (current.length === 0)
            return false;
        const selected = this.selectedRows();
        return current.every(row => this.isRowSelected(row, selected));
    });
    /** Verifica se parte das linhas está selecionada (estado indeterminado) */
    isSomeSelected = computed(() => {
        const current = this.displayData();
        if (current.length === 0)
            return false;
        const selected = this.selectedRows();
        const selectedCount = current.filter(row => this.isRowSelected(row, selected)).length;
        return selectedCount > 0 && selectedCount < current.length;
    });
    // ── Métodos de Ação ───────────────────────────────────────
    getRowId(row) {
        const key = this.rowKey();
        return row?.[key] !== undefined ? row[key] : row;
    }
    isRowSelected(row, selected = this.selectedRows()) {
        const id = this.getRowId(row);
        return selected.some(item => this.getRowId(item) === id);
    }
    toggleRowSelect(row, event) {
        const checked = typeof event === 'boolean' ? event : event.checked;
        const current = [...this.selectedRows()];
        const id = this.getRowId(row);
        const index = current.findIndex(item => this.getRowId(item) === id);
        if (checked && index === -1) {
            current.push(row);
        }
        else if (!checked && index !== -1) {
            current.splice(index, 1);
        }
        this.selectedRows.set(current);
        this.selectionChange.emit(current);
    }
    toggleSelectAll(event) {
        const checked = typeof event === 'boolean' ? event : event.checked;
        const currentDisplay = this.displayData();
        let currentSelected = [...this.selectedRows()];
        if (checked) {
            currentDisplay.forEach(row => {
                if (!this.isRowSelected(row, currentSelected)) {
                    currentSelected.push(row);
                }
            });
        }
        else {
            const displayIds = new Set(currentDisplay.map(r => this.getRowId(r)));
            currentSelected = currentSelected.filter(item => !displayIds.has(this.getRowId(item)));
        }
        this.selectedRows.set(currentSelected);
        this.selectionChange.emit(currentSelected);
    }
    handleSort(columnKey, isSortable) {
        if (!isSortable)
            return;
        let newDirection = 'asc';
        if (this.sortColumn() === columnKey) {
            const currentDir = this.sortDirection();
            if (currentDir === 'asc')
                newDirection = 'desc';
            else if (currentDir === 'desc')
                newDirection = 'none';
            else
                newDirection = 'asc';
        }
        this.sortColumn.set(newDirection === 'none' ? '' : columnKey);
        this.sortDirection.set(newDirection);
        this.sortChange.emit({ column: columnKey, direction: newDirection });
    }
    handleRowClick(row) {
        this.rowClick.emit(row);
    }
    getAriaSort(columnKey, isSortable) {
        if (!isSortable)
            return null;
        if (this.sortColumn() !== columnKey)
            return 'none';
        const dir = this.sortDirection();
        if (dir === 'asc')
            return 'ascending';
        if (dir === 'desc')
            return 'descending';
        return 'none';
    }
    getCellValue(row, key) {
        return row?.[key] ?? '';
    }
    getSkeletonArray() {
        return Array.from({ length: this.loadingRowsCount() }, (_, i) => i);
    }
    static ɵfac = function TableComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TableComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TableComponent, selectors: [["orc-table"]], contentQueries: function TableComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.declaredColumns, ColumnDirective, 4);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { data: [1, "data"], columnsConfig: [1, "columnsConfig"], rowKey: [1, "rowKey"], selectable: [1, "selectable"], selectedRows: [1, "selectedRows"], sortColumn: [1, "sortColumn"], sortDirection: [1, "sortDirection"], striped: [1, "striped"], bordered: [1, "bordered"], hoverable: [1, "hoverable"], loading: [1, "loading"], loadingRowsCount: [1, "loadingRowsCount"], emptyTitle: [1, "emptyTitle"], emptyMessage: [1, "emptyMessage"], paginated: [1, "paginated"], pageSize: [1, "pageSize"], currentPage: [1, "currentPage"], totalItems: [1, "totalItems"], pageSizeOptions: [1, "pageSizeOptions"] }, outputs: { selectedRows: "selectedRowsChange", selectionChange: "selectionChange", sortColumn: "sortColumnChange", sortDirection: "sortDirectionChange", sortChange: "sortChange", pageSize: "pageSizeChange", currentPage: "currentPageChange", rowClick: "rowClick" }, decls: 13, vars: 9, consts: [[1, "orc-table-container"], ["role", "region", "aria-label", "Tabela de dados", "tabindex", "0", 1, "orc-table-wrapper"], [1, "orc-table"], [1, "orc-table__head"], [1, "orc-table__head-row"], ["scope", "col", 1, "orc-table__th", "orc-table__th--checkbox"], ["scope", "col", 1, "orc-table__th", 3, "orc-table__th--sortable", "orc-table__th--sorted", "width", "text-align", "tabindex"], [1, "orc-table__body"], [1, "orc-table__empty-row"], [1, "orc-table__footer"], ["ariaLabel", "Selecionar todas as linhas", 3, "change", "checked", "indeterminate"], ["scope", "col", 1, "orc-table__th", 3, "click", "keydown.enter", "keydown.space", "tabindex"], [1, "orc-table__th-content", 3, "justify-content"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "orc-table__th-content"], [1, "orc-table__th-text"], ["aria-hidden", "true", 1, "orc-table__sort-icon"], ["viewBox", "0 0 16 16", "fill", "none", "stroke", "currentColor", "stroke-width", "1.75", "stroke-linecap", "round", "stroke-linejoin", "round"], ["viewBox", "0 0 16 16", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 12V4M4 8l4-4 4 4"], ["d", "M8 4v8M4 8l4 4 4-4"], ["d", "M5 6l3-3 3 3M5 10l3 3 3-3", "opacity", "0.4"], [1, "orc-table__row", "orc-table__row--loading"], [1, "orc-table__td", "orc-table__td--checkbox"], [1, "orc-table__td"], ["variant", "rectangular", "width", "18px", "height", "18px", "borderRadius", "4px"], ["variant", "text", "height", "16px", 3, "width"], [1, "orc-table__empty-cell"], [1, "orc-table__empty-content"], ["aria-hidden", "true", 1, "orc-table__empty-icon"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x", "3", "y", "3", "width", "18", "height", "18", "rx", "2", "ry", "2"], ["x1", "3", "y1", "9", "x2", "21", "y2", "9"], ["x1", "9", "y1", "21", "x2", "9", "y2", "9"], [1, "orc-table__empty-title"], [1, "orc-table__empty-desc"], [1, "orc-table__row", 3, "orc-table__row--selected"], [1, "orc-table__row", 3, "click"], [1, "orc-table__td", 3, "text-align"], [1, "orc-table__td", "orc-table__td--checkbox", 3, "click"], [3, "change", "checked", "ariaLabel"], [1, "orc-table__cell-value"], [3, "pageSizeChange", "currentPageChange", "totalItems", "pageSize", "currentPage", "pageSizeOptions", "showPageSizeSelector"]], template: function TableComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "table", 2)(3, "thead", 3)(4, "tr", 4);
            i0.ɵɵtemplate(5, TableComponent_Conditional_5_Template, 2, 2, "th", 5);
            i0.ɵɵrepeaterCreate(6, TableComponent_For_7_Template, 3, 11, "th", 6, _forTrack0);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(8, "tbody", 7);
            i0.ɵɵtemplate(9, TableComponent_Conditional_9_Template, 2, 0)(10, TableComponent_Conditional_10_Template, 12, 3, "tr", 8)(11, TableComponent_Conditional_11_Template, 2, 0);
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(12, TableComponent_Conditional_12_Template, 2, 5, "div", 9);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-table-container--bordered", ctx.bordered())("orc-table-container--striped", ctx.striped())("orc-table-container--hoverable", ctx.hoverable());
            i0.ɵɵadvance(5);
            i0.ɵɵconditional(ctx.selectable() ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.declaredColumns());
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.loading() ? 9 : ctx.displayData().length === 0 ? 10 : 11);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.paginated() && ctx.effectiveTotalItems() > 0 ? 12 : -1);
        } }, dependencies: [CommonModule, i1.NgTemplateOutlet, CheckboxComponent,
            PaginatorComponent,
            SkeletonComponent], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;background:var(--bg-app, #ffffff);border-radius:20px;overflow:hidden;box-sizing:border-box}.orc-table-container--bordered[_ngcontent-%COMP%]{border:1px solid var(--orc-border, #d9d9d9)}.orc-table-container--striped[_ngcontent-%COMP%]   .orc-table__body[_ngcontent-%COMP%]   .orc-table__row[_ngcontent-%COMP%]:nth-child(2n):not(.orc-table__row--selected){background-color:var(--orc-th, #f9f9f9)}.orc-table-container--hoverable[_ngcontent-%COMP%]   .orc-table__body[_ngcontent-%COMP%]   .orc-table__row[_ngcontent-%COMP%]:hover:not(.orc-table__row--loading){background-color:#1c6aed08}.orc-table-wrapper[_ngcontent-%COMP%]{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;outline:none}.orc-table-wrapper[_ngcontent-%COMP%]:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-table[_ngcontent-%COMP%]{width:100%;border-collapse:collapse;text-align:left;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px}.orc-table__head[_ngcontent-%COMP%]{background-color:var(--orc-th, #f9f9f9)}.orc-table__head-row[_ngcontent-%COMP%]{border-bottom:1px solid var(--orc-border, #d9d9d9)}.orc-table__th[_ngcontent-%COMP%]{height:48px;padding:12px 16px;font-size:15px;font-weight:500;color:var(--orc-font-main, #141414);border-bottom:1px solid var(--orc-border, #d9d9d9);box-sizing:border-box;white-space:nowrap;outline:none;transition:background-color var(--transition-fast, .2s ease)}.orc-table__th--checkbox[_ngcontent-%COMP%]{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__th--sortable[_ngcontent-%COMP%]{cursor:pointer;-webkit-user-select:none;user-select:none}.orc-table__th--sortable[_ngcontent-%COMP%]:hover{background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-table__th--sortable[_ngcontent-%COMP%]:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-table__th--sorted[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-table__th-content[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px}.orc-table__th-text[_ngcontent-%COMP%]{font-weight:500}.orc-table__sort-icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;color:currentColor}.orc-table__sort-icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:14px;height:14px}.orc-table__body[_ngcontent-%COMP%]{background-color:var(--bg-app, #ffffff)}.orc-table__row[_ngcontent-%COMP%]{border-bottom:1px solid var(--orc-border, #d9d9d9);transition:background-color var(--transition-fast, .2s ease)}.orc-table__row[_ngcontent-%COMP%]:last-child{border-bottom:none}.orc-table__row--selected[_ngcontent-%COMP%]{background-color:#1c6aed14!important}.orc-table__td[_ngcontent-%COMP%]{padding:16px;min-height:56px;vertical-align:middle;font-size:14px;line-height:20px;color:var(--orc-font-main, #141414);box-sizing:border-box}.orc-table__td--checkbox[_ngcontent-%COMP%]{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__cell-value[_ngcontent-%COMP%]{display:block}.orc-table__empty-row[_ngcontent-%COMP%]:hover{background-color:transparent!important}.orc-table__empty-cell[_ngcontent-%COMP%]{padding:48px 24px;text-align:center}.orc-table__empty-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;max-width:320px;margin:0 auto}.orc-table__empty-icon[_ngcontent-%COMP%]{width:44px;height:44px;color:#929292;margin-bottom:4px}.orc-table__empty-icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-table__empty-title[_ngcontent-%COMP%]{font-size:16px;font-weight:600;color:var(--orc-font-main, #141414);margin:0}.orc-table__empty-desc[_ngcontent-%COMP%]{font-size:13px;color:var(--orc-font-secondary, #58595b);margin:0}.orc-table__footer[_ngcontent-%COMP%]{padding:12px 16px;background-color:var(--bg-app, #ffffff);border-top:1px solid var(--orc-border, #d9d9d9);display:flex;align-items:center;justify-content:flex-end}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TableComponent, [{
        type: Component,
        args: [{ selector: 'orc-table', standalone: true, imports: [
                    CommonModule,
                    CheckboxComponent,
                    PaginatorComponent,
                    SkeletonComponent,
                ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-table-container\"\n  [class.orc-table-container--bordered]=\"bordered()\"\n  [class.orc-table-container--striped]=\"striped()\"\n  [class.orc-table-container--hoverable]=\"hoverable()\"\n>\n  <div class=\"orc-table-wrapper\" role=\"region\" aria-label=\"Tabela de dados\" tabindex=\"0\">\n    <table class=\"orc-table\">\n      <!-- \u2500\u2500 Cabe\u00E7alho da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <thead class=\"orc-table__head\">\n        <tr class=\"orc-table__head-row\">\n          <!-- Coluna de Sele\u00E7\u00E3o em Massa -->\n          @if (selectable()) {\n            <th scope=\"col\" class=\"orc-table__th orc-table__th--checkbox\">\n              <orc-checkbox\n                [checked]=\"isAllSelected()\"\n                [indeterminate]=\"isSomeSelected()\"\n                (change)=\"toggleSelectAll($event)\"\n                ariaLabel=\"Selecionar todas as linhas\"\n              />\n            </th>\n          }\n\n          <!-- Colunas Declaradas via <orc-column> -->\n          @for (col of declaredColumns(); track col.key()) {\n            <th\n              scope=\"col\"\n              class=\"orc-table__th\"\n              [class.orc-table__th--sortable]=\"col.sortable()\"\n              [class.orc-table__th--sorted]=\"sortColumn() === col.key()\"\n              [style.width]=\"col.width() || null\"\n              [style.text-align]=\"col.align()\"\n              [attr.aria-sort]=\"getAriaSort(col.key(), col.sortable())\"\n              (click)=\"handleSort(col.key(), col.sortable())\"\n              (keydown.enter)=\"handleSort(col.key(), col.sortable())\"\n              (keydown.space)=\"handleSort(col.key(), col.sortable()); $event.preventDefault()\"\n              [tabindex]=\"col.sortable() ? 0 : -1\"\n            >\n              @if (col.headerTemplate(); as headerTpl) {\n                <ng-container *ngTemplateOutlet=\"headerTpl.templateRef; context: { column: col }\"></ng-container>\n              } @else {\n                <div class=\"orc-table__th-content\" [style.justify-content]=\"col.align() === 'center' ? 'center' : (col.align() === 'right' ? 'flex-end' : 'flex-start')\">\n                  <span class=\"orc-table__th-text\">{{ col.header() }}</span>\n                  @if (col.sortable()) {\n                    <span class=\"orc-table__sort-icon\" aria-hidden=\"true\">\n                      @if (sortColumn() === col.key()) {\n                        @if (sortDirection() === 'asc') {\n                          <!-- Seta Ascendente (SVG Figma) -->\n                          <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                            <path d=\"M8 12V4M4 8l4-4 4 4\" />\n                          </svg>\n                        } @else if (sortDirection() === 'desc') {\n                          <!-- Seta Descendente (SVG Figma) -->\n                          <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                            <path d=\"M8 4v8M4 8l4 4 4-4\" />\n                          </svg>\n                        }\n                      } @else {\n                        <!-- \u00CDcone Neutro de Ordena\u00E7\u00E3o -->\n                        <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                          <path d=\"M5 6l3-3 3 3M5 10l3 3 3-3\" opacity=\"0.4\" />\n                        </svg>\n                      }\n                    </span>\n                  }\n                </div>\n              }\n            </th>\n          }\n        </tr>\n      </thead>\n\n      <!-- \u2500\u2500 Corpo da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <tbody class=\"orc-table__body\">\n        <!-- Estado de Carregamento (Loading com Skeletons) -->\n        @if (loading()) {\n          @for (placeholder of getSkeletonArray(); track placeholder) {\n            <tr class=\"orc-table__row orc-table__row--loading\">\n              @if (selectable()) {\n                <td class=\"orc-table__td orc-table__td--checkbox\">\n                  <orc-skeleton variant=\"rectangular\" width=\"18px\" height=\"18px\" borderRadius=\"4px\" />\n                </td>\n              }\n              @for (col of declaredColumns(); track col.key()) {\n                <td class=\"orc-table__td\">\n                  <orc-skeleton variant=\"text\" height=\"16px\" [width]=\"col.key() === 'id' ? '40px' : '75%'\" />\n                </td>\n              }\n            </tr>\n          }\n        }\n        <!-- Estado Vazio (Empty State) -->\n        @else if (displayData().length === 0) {\n          <tr class=\"orc-table__empty-row\">\n            <td\n              class=\"orc-table__empty-cell\"\n              [attr.colspan]=\"declaredColumns().length + (selectable() ? 1 : 0)\"\n            >\n              <div class=\"orc-table__empty-content\">\n                <div class=\"orc-table__empty-icon\" aria-hidden=\"true\">\n                  <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                    <rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"2\" ry=\"2\"></rect>\n                    <line x1=\"3\" y1=\"9\" x2=\"21\" y2=\"9\"></line>\n                    <line x1=\"9\" y1=\"21\" x2=\"9\" y2=\"9\"></line>\n                  </svg>\n                </div>\n                <h4 class=\"orc-table__empty-title\">{{ emptyTitle() }}</h4>\n                <p class=\"orc-table__empty-desc\">{{ emptyMessage() }}</p>\n              </div>\n            </td>\n          </tr>\n        }\n        <!-- Linhas de Dados -->\n        @else {\n          @for (row of displayData(); track getRowId(row); let rowIndex = $index) {\n            @let selected = isRowSelected(row);\n            <tr\n              class=\"orc-table__row\"\n              [class.orc-table__row--selected]=\"selected\"\n              (click)=\"handleRowClick(row)\"\n            >\n              <!-- Checkbox de Sele\u00E7\u00E3o por Linha -->\n              @if (selectable()) {\n                <td class=\"orc-table__td orc-table__td--checkbox\" (click)=\"$event.stopPropagation()\">\n                  <orc-checkbox\n                    [checked]=\"selected\"\n                    (change)=\"toggleRowSelect(row, $event)\"\n                    [ariaLabel]=\"'Selecionar linha ' + (rowIndex + 1)\"\n                  />\n                </td>\n              }\n\n              <!-- C\u00E9lulas de Dados -->\n              @for (col of declaredColumns(); track col.key()) {\n                <td class=\"orc-table__td\" [style.text-align]=\"col.align()\">\n                  @if (col.cellTemplate(); as cellTpl) {\n                    <ng-container\n                      *ngTemplateOutlet=\"cellTpl.templateRef; context: {\n                        $implicit: row,\n                        row: row,\n                        index: rowIndex,\n                        column: col,\n                        value: getCellValue(row, col.key())\n                      }\"\n                    ></ng-container>\n                  } @else {\n                    <span class=\"orc-table__cell-value\">{{ getCellValue(row, col.key()) }}</span>\n                  }\n                </td>\n              }\n            </tr>\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n\n  <!-- \u2500\u2500 Rodap\u00E9 com Pagina\u00E7\u00E3o Integrada \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (paginated() && effectiveTotalItems() > 0) {\n    <div class=\"orc-table__footer\">\n      <orc-paginator\n        [totalItems]=\"effectiveTotalItems()\"\n        [(pageSize)]=\"pageSize\"\n        [(currentPage)]=\"currentPage\"\n        [pageSizeOptions]=\"pageSizeOptions()\"\n        [showPageSizeSelector]=\"true\"\n      />\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-table-container{display:flex;flex-direction:column;width:100%;background:var(--bg-app, #ffffff);border-radius:20px;overflow:hidden;box-sizing:border-box}.orc-table-container--bordered{border:1px solid var(--orc-border, #d9d9d9)}.orc-table-container--striped .orc-table__body .orc-table__row:nth-child(2n):not(.orc-table__row--selected){background-color:var(--orc-th, #f9f9f9)}.orc-table-container--hoverable .orc-table__body .orc-table__row:hover:not(.orc-table__row--loading){background-color:#1c6aed08}.orc-table-wrapper{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;outline:none}.orc-table-wrapper:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-table{width:100%;border-collapse:collapse;text-align:left;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px}.orc-table__head{background-color:var(--orc-th, #f9f9f9)}.orc-table__head-row{border-bottom:1px solid var(--orc-border, #d9d9d9)}.orc-table__th{height:48px;padding:12px 16px;font-size:15px;font-weight:500;color:var(--orc-font-main, #141414);border-bottom:1px solid var(--orc-border, #d9d9d9);box-sizing:border-box;white-space:nowrap;outline:none;transition:background-color var(--transition-fast, .2s ease)}.orc-table__th--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__th--sortable{cursor:pointer;-webkit-user-select:none;user-select:none}.orc-table__th--sortable:hover{background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-table__th--sortable:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-table__th--sorted{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-table__th-content{display:flex;align-items:center;gap:8px}.orc-table__th-text{font-weight:500}.orc-table__sort-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;color:currentColor}.orc-table__sort-icon svg{width:14px;height:14px}.orc-table__body{background-color:var(--bg-app, #ffffff)}.orc-table__row{border-bottom:1px solid var(--orc-border, #d9d9d9);transition:background-color var(--transition-fast, .2s ease)}.orc-table__row:last-child{border-bottom:none}.orc-table__row--selected{background-color:#1c6aed14!important}.orc-table__td{padding:16px;min-height:56px;vertical-align:middle;font-size:14px;line-height:20px;color:var(--orc-font-main, #141414);box-sizing:border-box}.orc-table__td--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__cell-value{display:block}.orc-table__empty-row:hover{background-color:transparent!important}.orc-table__empty-cell{padding:48px 24px;text-align:center}.orc-table__empty-content{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;max-width:320px;margin:0 auto}.orc-table__empty-icon{width:44px;height:44px;color:#929292;margin-bottom:4px}.orc-table__empty-icon svg{width:100%;height:100%}.orc-table__empty-title{font-size:16px;font-weight:600;color:var(--orc-font-main, #141414);margin:0}.orc-table__empty-desc{font-size:13px;color:var(--orc-font-secondary, #58595b);margin:0}.orc-table__footer{padding:12px 16px;background-color:var(--bg-app, #ffffff);border-top:1px solid var(--orc-border, #d9d9d9);display:flex;align-items:center;justify-content:flex-end}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TableComponent, { className: "TableComponent", filePath: "table.component.ts", lineNumber: 35 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { CellDefDirective, ColumnDirective, HeaderCellDefDirective, TableComponent };
//# sourceMappingURL=ciag-orchestra-table.mjs.map
