import * as i0 from '@angular/core';
import { inject, ElementRef, input, numberAttribute, booleanAttribute, model, signal, output, computed, forwardRef, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const _forTrack0 = ($index, $item) => $item.value;
function AutocompleteComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function AutocompleteComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 1);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, AutocompleteComponent_Conditional_1_Conditional_2_Template, 2, 0, "span", 7);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r0.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", ctx_r0.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.required() ? 2 : -1);
} }
function AutocompleteComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 8);
    i0.ɵɵlistener("mousedown", function AutocompleteComponent_Conditional_4_Template_button_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r2); return i0.ɵɵresetView($event.preventDefault()); })("click", function AutocompleteComponent_Conditional_4_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.clear($event)); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} }
function AutocompleteComponent_Conditional_5_For_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(option_r4.description);
} }
function AutocompleteComponent_Conditional_5_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 10);
    i0.ɵɵlistener("mousedown", function AutocompleteComponent_Conditional_5_For_2_Template_li_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r3); return i0.ɵɵresetView($event.preventDefault()); })("click", function AutocompleteComponent_Conditional_5_For_2_Template_li_click_0_listener() { const option_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.select(option_r4)); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, AutocompleteComponent_Conditional_5_For_2_Conditional_3_Template, 2, 1, "small");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r4 = ctx.$implicit;
    const $index_r5 = ctx.$index;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("orc-autocomplete__option--active", ctx_r0.activeIndex() === $index_r5)("orc-autocomplete__option--disabled", option_r4.disabled);
    i0.ɵɵproperty("id", ctx_r0.optionId($index_r5));
    i0.ɵɵattribute("aria-selected", ctx_r0.value() === option_r4.value)("aria-disabled", option_r4.disabled ? "true" : null);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(option_r4.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(option_r4.description ? 3 : -1);
} }
function AutocompleteComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 5);
    i0.ɵɵrepeaterCreate(1, AutocompleteComponent_Conditional_5_For_2_Template, 4, 9, "li", 9, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.listId());
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.filteredOptions());
} }
function AutocompleteComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-autocomplete__message--error", !!ctx_r0.errorMessage());
    i0.ɵɵproperty("id", ctx_r0.describedBy());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.errorMessage() || ctx_r0.helperText());
} }
let nextAutocompleteId = 0;
class AutocompleteComponent {
    host = inject((ElementRef));
    uniqueId = `orc-autocomplete-${++nextAutocompleteId}`;
    id = input('');
    name = input('');
    label = input('');
    placeholder = input('Comece a digitar...');
    helperText = input('');
    errorMessage = input('');
    options = input([]);
    minChars = input(0, { transform: numberAttribute });
    clearable = input(true, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    ariaLabel = input('');
    value = model(null);
    query = signal('');
    isOpen = signal(false);
    activeIndex = signal(-1);
    optionSelected = output();
    cvaDisabled = signal(false);
    effectiveId = computed(() => this.id() || this.uniqueId);
    listId = computed(() => `${this.effectiveId()}-list`);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    selectedLabel = computed(() => this.options().find(option => option.value === this.value())?.label ?? '');
    displayText = computed(() => this.query() || this.selectedLabel());
    filteredOptions = computed(() => {
        const query = this.query().trim().toLocaleLowerCase();
        if (query.length < this.minChars())
            return [];
        return this.options().filter(option => option.label.toLocaleLowerCase().includes(query) || option.value.toLocaleLowerCase().includes(query));
    });
    describedBy = computed(() => this.errorMessage() ? `${this.effectiveId()}-error` : this.helperText() ? `${this.effectiveId()}-helper` : null);
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        this.value.set(value === null || value === undefined ? null : String(value));
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    onInput(event) {
        const text = event.target.value;
        this.query.set(text);
        this.isOpen.set(text.length >= this.minChars());
        this.activeIndex.set(this.firstEnabledIndex());
    }
    onFocus() {
        if (!this.effectiveDisabled() && this.query().length >= this.minChars())
            this.isOpen.set(true);
    }
    onBlur() {
        this.onTouched();
        setTimeout(() => this.isOpen.set(false), 120);
    }
    select(option) {
        if (option.disabled || this.effectiveDisabled())
            return;
        this.value.set(option.value);
        this.query.set(option.label);
        this.isOpen.set(false);
        this.activeIndex.set(-1);
        this.onChange(option.value);
        this.optionSelected.emit(option);
    }
    clear(event) {
        event?.preventDefault();
        this.value.set(null);
        this.query.set('');
        this.isOpen.set(false);
        this.onChange(null);
    }
    onDocumentClick(event) {
        if (!this.host.nativeElement.contains(event.target))
            this.isOpen.set(false);
    }
    onKeydown(event) {
        const options = this.filteredOptions();
        if (event.key === 'Escape') {
            this.isOpen.set(false);
            return;
        }
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.moveActive(1);
            return;
        }
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.moveActive(-1);
            return;
        }
        if (event.key === 'Enter' && this.isOpen() && this.activeIndex() >= 0) {
            event.preventDefault();
            const option = options[this.activeIndex()];
            if (option)
                this.select(option);
        }
    }
    optionId(index) { return `${this.effectiveId()}-option-${index}`; }
    moveActive(direction) {
        const options = this.filteredOptions();
        if (!options.length)
            return;
        let index = this.activeIndex();
        for (let i = 0; i < options.length; i += 1) {
            index = (index + direction + options.length) % options.length;
            if (!options[index]?.disabled) {
                this.activeIndex.set(index);
                this.isOpen.set(true);
                return;
            }
        }
    }
    firstEnabledIndex() {
        return this.filteredOptions().findIndex(option => !option.disabled);
    }
    static ɵfac = function AutocompleteComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AutocompleteComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AutocompleteComponent, selectors: [["orc-autocomplete"]], hostBindings: function AutocompleteComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("click", function AutocompleteComponent_click_HostBindingHandler($event) { return ctx.onDocumentClick($event); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { id: [1, "id"], name: [1, "name"], label: [1, "label"], placeholder: [1, "placeholder"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], options: [1, "options"], minChars: [1, "minChars"], clearable: [1, "clearable"], disabled: [1, "disabled"], required: [1, "required"], ariaLabel: [1, "ariaLabel"], value: [1, "value"] }, outputs: { value: "valueChange", optionSelected: "optionSelected" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => AutocompleteComponent), multi: true }])], decls: 7, vars: 18, consts: [[1, "orc-autocomplete"], [1, "orc-autocomplete__label", 3, "for"], [1, "orc-autocomplete__control"], ["type", "text", "role", "combobox", "autocomplete", "off", 1, "orc-autocomplete__input", 3, "input", "focus", "blur", "keydown", "id", "name", "value", "placeholder", "disabled", "required"], ["type", "button", "aria-label", "Limpar sele\u00E7\u00E3o", 1, "orc-autocomplete__clear"], ["role", "listbox", 1, "orc-autocomplete__list", 3, "id"], [1, "orc-autocomplete__message", 3, "orc-autocomplete__message--error", "id"], ["aria-hidden", "true"], ["type", "button", "aria-label", "Limpar sele\u00E7\u00E3o", 1, "orc-autocomplete__clear", 3, "mousedown", "click"], ["role", "option", 1, "orc-autocomplete__option", 3, "orc-autocomplete__option--active", "orc-autocomplete__option--disabled", "id"], ["role", "option", 1, "orc-autocomplete__option", 3, "mousedown", "click", "id"], [1, "orc-autocomplete__message", 3, "id"]], template: function AutocompleteComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, AutocompleteComponent_Conditional_1_Template, 3, 3, "label", 1);
            i0.ɵɵelementStart(2, "div", 2)(3, "input", 3);
            i0.ɵɵlistener("input", function AutocompleteComponent_Template_input_input_3_listener($event) { return ctx.onInput($event); })("focus", function AutocompleteComponent_Template_input_focus_3_listener() { return ctx.onFocus(); })("blur", function AutocompleteComponent_Template_input_blur_3_listener() { return ctx.onBlur(); })("keydown", function AutocompleteComponent_Template_input_keydown_3_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, AutocompleteComponent_Conditional_4_Template, 2, 0, "button", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, AutocompleteComponent_Conditional_5_Template, 3, 1, "ul", 5)(6, AutocompleteComponent_Conditional_6_Template, 2, 4, "p", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-autocomplete--disabled", ctx.effectiveDisabled());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.name())("value", ctx.displayText())("placeholder", ctx.placeholder())("disabled", ctx.effectiveDisabled())("required", ctx.required());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-expanded", ctx.isOpen())("aria-controls", ctx.listId())("aria-activedescendant", ctx.activeIndex() >= 0 ? ctx.optionId(ctx.activeIndex()) : null)("aria-invalid", ctx.errorMessage() ? "true" : null)("aria-describedby", ctx.describedBy());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.clearable() && (ctx.query() || ctx.value()) ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isOpen() && ctx.filteredOptions().length ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.errorMessage() || ctx.helperText() ? 6 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-autocomplete[_ngcontent-%COMP%]{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-autocomplete__label[_ngcontent-%COMP%]{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-autocomplete__label[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}.orc-autocomplete__control[_ngcontent-%COMP%]{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-autocomplete__control[_ngcontent-%COMP%]:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-autocomplete__input[_ngcontent-%COMP%]{flex:1;min-width:0;padding:10px 12px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit}.orc-autocomplete__clear[_ngcontent-%COMP%]{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-font-secondary, #666);font-size:20px;cursor:pointer}.orc-autocomplete__clear[_ngcontent-%COMP%]:hover{background:var(--orc-th, #f7f8fa)}.orc-autocomplete__list[_ngcontent-%COMP%]{position:absolute;z-index:var(--z-dropdown, 1000);inset:calc(100% - 1px) 0 auto;max-height:240px;overflow:auto;margin:0;padding:4px;border:1px solid var(--orc-border, #d9d9d9);border-radius:0 0 var(--radius-md, 10px) var(--radius-md, 10px);background:var(--fill-modal, #fff);box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12));list-style:none}.orc-autocomplete__option[_ngcontent-%COMP%]{display:grid;gap:2px;padding:9px 10px;border-radius:var(--radius-sm, 6px);color:var(--orc-font-main, #141414);cursor:pointer}.orc-autocomplete__option[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666)}.orc-autocomplete__option[_ngcontent-%COMP%]:hover, .orc-autocomplete__option--active[_ngcontent-%COMP%]{background:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 10%,transparent)}.orc-autocomplete__option--disabled[_ngcontent-%COMP%]{opacity:.45;cursor:not-allowed}.orc-autocomplete--disabled[_ngcontent-%COMP%]{opacity:.55}.orc-autocomplete__message[_ngcontent-%COMP%]{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-autocomplete__message--error[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AutocompleteComponent, [{
        type: Component,
        args: [{ selector: 'orc-autocomplete', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => AutocompleteComponent), multi: true }], template: "<div class=\"orc-autocomplete\" [class.orc-autocomplete--disabled]=\"effectiveDisabled()\">\n  @if (label()) { <label class=\"orc-autocomplete__label\" [for]=\"effectiveId()\">{{ label() }} @if (required()) { <span aria-hidden=\"true\">*</span> }</label> }\n  <div class=\"orc-autocomplete__control\">\n    <input\n      class=\"orc-autocomplete__input\"\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      type=\"text\"\n      role=\"combobox\"\n      [value]=\"displayText()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"effectiveDisabled()\"\n      [required]=\"required()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-expanded]=\"isOpen()\"\n      [attr.aria-controls]=\"listId()\"\n      [attr.aria-activedescendant]=\"activeIndex() >= 0 ? optionId(activeIndex()) : null\"\n      [attr.aria-invalid]=\"errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      autocomplete=\"off\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus()\"\n      (blur)=\"onBlur()\"\n      (keydown)=\"onKeydown($event)\"\n    />\n    @if (clearable() && (query() || value())) { <button type=\"button\" class=\"orc-autocomplete__clear\" (mousedown)=\"$event.preventDefault()\" (click)=\"clear($event)\" aria-label=\"Limpar sele\u00E7\u00E3o\">\u00D7</button> }\n  </div>\n  @if (isOpen() && filteredOptions().length) {\n    <ul class=\"orc-autocomplete__list\" [id]=\"listId()\" role=\"listbox\">\n      @for (option of filteredOptions(); track option.value) {\n        <li\n          class=\"orc-autocomplete__option\"\n          [class.orc-autocomplete__option--active]=\"activeIndex() === $index\"\n          [class.orc-autocomplete__option--disabled]=\"option.disabled\"\n          [id]=\"optionId($index)\"\n          role=\"option\"\n          [attr.aria-selected]=\"value() === option.value\"\n          [attr.aria-disabled]=\"option.disabled ? 'true' : null\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"select(option)\"\n        >\n          <span>{{ option.label }}</span>\n          @if (option.description) { <small>{{ option.description }}</small> }\n        </li>\n      }\n    </ul>\n  }\n  @if (errorMessage() || helperText()) { <p class=\"orc-autocomplete__message\" [class.orc-autocomplete__message--error]=\"!!errorMessage()\" [id]=\"describedBy()\">{{ errorMessage() || helperText() }}</p> }\n</div>\n", styles: [":host{display:block;width:100%}.orc-autocomplete{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-autocomplete__label{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-autocomplete__label span{color:var(--color-error, #fb2c36)}.orc-autocomplete__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-autocomplete__control:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-autocomplete__input{flex:1;min-width:0;padding:10px 12px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit}.orc-autocomplete__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-font-secondary, #666);font-size:20px;cursor:pointer}.orc-autocomplete__clear:hover{background:var(--orc-th, #f7f8fa)}.orc-autocomplete__list{position:absolute;z-index:var(--z-dropdown, 1000);inset:calc(100% - 1px) 0 auto;max-height:240px;overflow:auto;margin:0;padding:4px;border:1px solid var(--orc-border, #d9d9d9);border-radius:0 0 var(--radius-md, 10px) var(--radius-md, 10px);background:var(--fill-modal, #fff);box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12));list-style:none}.orc-autocomplete__option{display:grid;gap:2px;padding:9px 10px;border-radius:var(--radius-sm, 6px);color:var(--orc-font-main, #141414);cursor:pointer}.orc-autocomplete__option small{color:var(--orc-font-secondary, #666)}.orc-autocomplete__option:hover,.orc-autocomplete__option--active{background:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 10%,transparent)}.orc-autocomplete__option--disabled{opacity:.45;cursor:not-allowed}.orc-autocomplete--disabled{opacity:.55}.orc-autocomplete__message{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-autocomplete__message--error{color:var(--color-error, #fb2c36)}\n"] }]
    }], null, { onDocumentClick: [{
            type: HostListener,
            args: ['document:click', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AutocompleteComponent, { className: "AutocompleteComponent", filePath: "autocomplete.component.ts", lineNumber: 29 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { AutocompleteComponent };
//# sourceMappingURL=ciag-orchestra-autocomplete.mjs.map
