import * as i0 from '@angular/core';
import { input, output, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

const _c0$3 = ["*"];
class CardComponent {
    clickable = input(false);
    selected = input(false);
    variant = input('simple');
    cardClick = output();
    onClick() {
        if (this.clickable()) {
            this.cardClick.emit();
        }
    }
    static ɵfac = function CardComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CardComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CardComponent, selectors: [["orc-card"]], inputs: { clickable: [1, "clickable"], selected: [1, "selected"], variant: [1, "variant"] }, outputs: { cardClick: "cardClick" }, ngContentSelectors: _c0$3, decls: 2, vars: 9, consts: [[1, "card", 3, "click", "keydown.enter", "keydown.space"]], template: function CardComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("click", function CardComponent_Template_div_click_0_listener() { return ctx.onClick(); })("keydown.enter", function CardComponent_Template_div_keydown_enter_0_listener() { return ctx.onClick(); })("keydown.space", function CardComponent_Template_div_keydown_space_0_listener() { return ctx.onClick(); });
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("card--clickable", ctx.clickable())("card--selected", ctx.selected())("card--dashboard", ctx.variant() === "dashboard");
            i0.ɵɵattribute("role", ctx.clickable() ? "button" : null)("tabindex", ctx.clickable() ? 0 : null)("aria-selected", ctx.selected() ? true : null);
        } }, dependencies: [CommonModule], styles: [".card[_ngcontent-%COMP%]{background:var(--bg-app);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:0 4px 2px #00000014;padding:var(--space-5);display:flex;flex-direction:column;gap:var(--space-3);position:relative;transition:transform var(--transition-fast),box-shadow var(--transition-fast),border-color var(--transition-fast)}.card--clickable[_ngcontent-%COMP%]{cursor:pointer}.card--clickable[_ngcontent-%COMP%]:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);border-color:var(--border-strong)}.card--selected[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico);box-shadow:0 0 0 2px #1c6aed26}.card--dashboard[_ngcontent-%COMP%]{flex-direction:row;align-items:center;gap:var(--space-4)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CardComponent, [{
        type: Component,
        args: [{ selector: 'orc-card', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"card\"\n  [class.card--clickable]=\"clickable()\"\n  [class.card--selected]=\"selected()\"\n  [class.card--dashboard]=\"variant() === 'dashboard'\"\n  [attr.role]=\"clickable() ? 'button' : null\"\n  [attr.tabindex]=\"clickable() ? 0 : null\"\n  [attr.aria-selected]=\"selected() ? true : null\"\n  (click)=\"onClick()\"\n  (keydown.enter)=\"onClick()\"\n  (keydown.space)=\"onClick()\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [".card{background:var(--bg-app);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:0 4px 2px #00000014;padding:var(--space-5);display:flex;flex-direction:column;gap:var(--space-3);position:relative;transition:transform var(--transition-fast),box-shadow var(--transition-fast),border-color var(--transition-fast)}.card--clickable{cursor:pointer}.card--clickable:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);border-color:var(--border-strong)}.card--selected{border-color:var(--orc-color-azul-eletrico);box-shadow:0 0 0 2px #1c6aed26}.card--dashboard{flex-direction:row;align-items:center;gap:var(--space-4)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CardComponent, { className: "CardComponent", filePath: "card.component.ts", lineNumber: 12 }); })();

const _c0$2 = ["*"];
class CardHeaderComponent {
    static ɵfac = function CardHeaderComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CardHeaderComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CardHeaderComponent, selectors: [["orc-card-header"]], ngContentSelectors: _c0$2, decls: 2, vars: 0, consts: [[1, "card-header"]], template: function CardHeaderComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } }, styles: [".card-header[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);width:100%;font-family:var(--font-sans);font-size:1rem;font-weight:500;color:var(--text-primary);letter-spacing:-.01em}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CardHeaderComponent, [{
        type: Component,
        args: [{ selector: 'orc-card-header', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-header\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-header{display:flex;align-items:center;gap:var(--space-2);width:100%;font-family:var(--font-sans);font-size:1rem;font-weight:500;color:var(--text-primary);letter-spacing:-.01em}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CardHeaderComponent, { className: "CardHeaderComponent", filePath: "card-header.component.ts", lineNumber: 10 }); })();

const _c0$1 = ["*"];
class CardBodyComponent {
    static ɵfac = function CardBodyComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CardBodyComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CardBodyComponent, selectors: [["orc-card-body"]], ngContentSelectors: _c0$1, decls: 2, vars: 0, consts: [[1, "card-body"]], template: function CardBodyComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } }, styles: [".card-body[_ngcontent-%COMP%]{width:100%;font-family:var(--font-sans);font-size:.875rem;line-height:1.5;color:var(--text-secondary);display:flex;flex-direction:column;gap:var(--space-2)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CardBodyComponent, [{
        type: Component,
        args: [{ selector: 'orc-card-body', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-body\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-body{width:100%;font-family:var(--font-sans);font-size:.875rem;line-height:1.5;color:var(--text-secondary);display:flex;flex-direction:column;gap:var(--space-2)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CardBodyComponent, { className: "CardBodyComponent", filePath: "card-body.component.ts", lineNumber: 10 }); })();

const _c0 = ["*"];
class CardFooterComponent {
    static ɵfac = function CardFooterComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CardFooterComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CardFooterComponent, selectors: [["orc-card-footer"]], ngContentSelectors: _c0, decls: 2, vars: 0, consts: [[1, "card-footer"]], template: function CardFooterComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } }, styles: [".card-footer[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-3);width:100%;margin-top:auto;padding-top:var(--space-2);border-top:1px solid var(--border-default)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CardFooterComponent, [{
        type: Component,
        args: [{ selector: 'orc-card-footer', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-footer\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-footer{display:flex;align-items:center;gap:var(--space-3);width:100%;margin-top:auto;padding-top:var(--space-2);border-top:1px solid var(--border-default)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CardFooterComponent, { className: "CardFooterComponent", filePath: "card-footer.component.ts", lineNumber: 10 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { CardBodyComponent, CardComponent, CardFooterComponent, CardHeaderComponent };
//# sourceMappingURL=ciag-orchestra-card.mjs.map
