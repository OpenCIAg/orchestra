export { DropdownComponent as MenuComponent } from '@ciag/orchestra/dropdown';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-menu.mjs.map
