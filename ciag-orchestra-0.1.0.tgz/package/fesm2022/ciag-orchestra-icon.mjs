import * as i0 from '@angular/core';
import { InjectionToken, input, inject, computed, ChangeDetectionStrategy, Component } from '@angular/core';

const _forTrack0 = ($index, $item) => $item.d;
function IconComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "title");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.title());
} }
function IconComponent_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelement(0, "path");
} if (rf & 2) {
    const path_r2 = ctx.$implicit;
    i0.ɵɵattribute("d", path_r2.d)("fill-rule", path_r2.fillRule)("clip-rule", path_r2.clipRule);
} }
const ORC_ICON_FALLBACK = {
    name: 'circle',
    viewBox: '0 0 24 24',
    paths: [{ d: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z' }],
};
const ORC_ICON_REGISTRY = new InjectionToken('ORC_ICON_REGISTRY');
function provideOrcIcons(...icons) {
    return {
        provide: ORC_ICON_REGISTRY,
        useValue: { get: (name) => icons.find((icon) => icon.name === name) },
    };
}
class IconComponent {
    name = input('circle');
    icon = input(null);
    size = input('md');
    fill = input('outline');
    ariaLabel = input('');
    title = input('');
    registry = inject(ORC_ICON_REGISTRY, { optional: true });
    definition = computed(() => this.icon() ?? this.registry?.get(this.name()) ?? ORC_ICON_FALLBACK);
    paths = computed(() => this.fill() === 'filled' ? (this.definition().filledPaths ?? this.definition().paths) : this.definition().paths);
    sizeValue = computed(() => typeof this.size() === 'number' ? `${this.size()}px` : ({ xs: '12px', sm: '16px', md: '20px', lg: '24px', xl: '32px' }[this.size()] ?? '20px'));
    static ɵfac = function IconComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IconComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IconComponent, selectors: [["orc-icon"]], inputs: { name: [1, "name"], icon: [1, "icon"], size: [1, "size"], fill: [1, "fill"], ariaLabel: [1, "ariaLabel"], title: [1, "title"] }, decls: 4, vars: 9, consts: [["fill", "currentColor", 1, "orc-icon"]], template: function IconComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(0, "svg", 0);
            i0.ɵɵtemplate(1, IconComponent_Conditional_1_Template, 2, 1, ":svg:title");
            i0.ɵɵrepeaterCreate(2, IconComponent_For_3_Template, 1, 3, ":svg:path", null, _forTrack0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("width", ctx.sizeValue())("height", ctx.sizeValue());
            i0.ɵɵattribute("viewBox", ctx.definition().viewBox)("role", ctx.ariaLabel() ? "img" : null)("aria-label", ctx.ariaLabel() || null)("aria-hidden", ctx.ariaLabel() ? null : "true");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.title() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.paths());
        } }, styles: ["[_nghost-%COMP%]{display:inline-flex;vertical-align:middle}.orc-icon[_ngcontent-%COMP%]{display:block;flex:0 0 auto}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IconComponent, [{
        type: Component,
        args: [{ selector: 'orc-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<svg class=\"orc-icon\" [style.width]=\"sizeValue()\" [style.height]=\"sizeValue()\" [attr.viewBox]=\"definition().viewBox\" fill=\"currentColor\" [attr.role]=\"ariaLabel() ? 'img' : null\" [attr.aria-label]=\"ariaLabel() || null\" [attr.aria-hidden]=\"ariaLabel() ? null : 'true'\">\n  @if (title()) { <title>{{ title() }}</title> }\n  @for (path of paths(); track path.d) {\n    <path [attr.d]=\"path.d\" [attr.fill-rule]=\"path.fillRule\" [attr.clip-rule]=\"path.clipRule\" />\n  }\n</svg>\n", styles: [":host{display:inline-flex;vertical-align:middle}.orc-icon{display:block;flex:0 0 auto}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IconComponent, { className: "IconComponent", filePath: "icon.component.ts", lineNumber: 30 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { IconComponent, ORC_ICON_FALLBACK, ORC_ICON_REGISTRY, provideOrcIcons };
//# sourceMappingURL=ciag-orchestra-icon.mjs.map
