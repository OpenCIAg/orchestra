import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component, HostBinding } from '@angular/core';
import { CommonModule } from '@angular/common';

class SkeletonComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    variant = input('text');
    animation = input('shimmer');
    width = input('');
    height = input('');
    borderRadius = input('');
    ariaLabel = input('Carregando conteúdo...');
    // ── Host Bindings ─────────────────────────────────────────
    get hostDisplay() {
        return this.variant() === 'circular' ? 'inline-block' : 'block';
    }
    get hostWidth() {
        const w = this.computedWidth();
        return w || (this.variant() === 'circular' ? '40px' : '100%');
    }
    hostVerticalAlign = 'middle';
    // ── Computed Dimensions ───────────────────────────────────
    computedWidth = computed(() => {
        const w = this.width();
        if (w)
            return typeof w === 'number' ? `${w}px` : w;
        switch (this.variant()) {
            case 'circular':
                return '40px';
            case 'text':
            case 'rectangular':
            default:
                return '100%';
        }
    });
    computedHeight = computed(() => {
        const h = this.height();
        if (h)
            return typeof h === 'number' ? `${h}px` : h;
        switch (this.variant()) {
            case 'circular':
                return '40px';
            case 'rectangular':
                return '96px';
            case 'text':
            default:
                return '14px';
        }
    });
    computedBorderRadius = computed(() => {
        const r = this.borderRadius();
        if (r)
            return r;
        switch (this.variant()) {
            case 'circular':
                return '50%';
            case 'text':
            case 'rectangular':
            default:
                return '8px';
        }
    });
    static ɵfac = function SkeletonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SkeletonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SkeletonComponent, selectors: [["orc-skeleton"]], hostVars: 6, hostBindings: function SkeletonComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵstyleProp("display", ctx.hostDisplay)("width", ctx.hostWidth)("vertical-align", ctx.hostVerticalAlign);
        } }, inputs: { variant: [1, "variant"], animation: [1, "animation"], width: [1, "width"], height: [1, "height"], borderRadius: [1, "borderRadius"], ariaLabel: [1, "ariaLabel"] }, decls: 3, vars: 20, consts: [["role", "status", "aria-busy", "true", 1, "orc-skeleton"], [1, "sr-only"]], template: function SkeletonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵstyleProp("width", ctx.computedWidth())("height", ctx.computedHeight())("border-radius", ctx.computedBorderRadius());
            i0.ɵɵclassProp("orc-skeleton--text", ctx.variant() === "text")("orc-skeleton--circular", ctx.variant() === "circular")("orc-skeleton--rectangular", ctx.variant() === "rectangular")("orc-skeleton--shimmer", ctx.animation() === "shimmer")("orc-skeleton--pulse", ctx.animation() === "pulse")("orc-skeleton--none", ctx.animation() === "none");
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.ariaLabel());
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box}.orc-skeleton[_ngcontent-%COMP%]{display:block;box-sizing:border-box;width:100%;height:100%;background-color:var(--skeleton-base, #F1F5F9);position:relative;overflow:hidden}.orc-skeleton--text[_ngcontent-%COMP%]{border-radius:8px}.orc-skeleton--circular[_ngcontent-%COMP%]{border-radius:50%}.orc-skeleton--rectangular[_ngcontent-%COMP%]{border-radius:8px}.orc-skeleton--shimmer[_ngcontent-%COMP%]{background-color:var(--skeleton-base, #F1F5F9);background-image:linear-gradient(90deg,var(--skeleton-base, #F1F5F9) 0%,var(--skeleton-highlight, #E2E8F0) 50%,var(--skeleton-base, #F1F5F9) 100%);background-size:200% 100%;background-repeat:no-repeat;animation:_ngcontent-%COMP%_orcShimmer 1.5s cubic-bezier(.4,0,.2,1) infinite}.orc-skeleton--pulse[_ngcontent-%COMP%]{background-color:var(--skeleton-base, #F1F5F9);animation:_ngcontent-%COMP%_orcPulse 1.5s ease-in-out infinite}.orc-skeleton--none[_ngcontent-%COMP%]{animation:none;background-color:var(--skeleton-base, #F1F5F9)}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes _ngcontent-%COMP%_orcShimmer{0%{background-position:150% 0}to{background-position:-150% 0}}@keyframes _ngcontent-%COMP%_orcPulse{0%,to{opacity:1}50%{opacity:.4}}@media(prefers-reduced-motion:reduce){.orc-skeleton--shimmer[_ngcontent-%COMP%], .orc-skeleton--pulse[_ngcontent-%COMP%]{animation:none;background-color:var(--skeleton-base, #F1F5F9)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SkeletonComponent, [{
        type: Component,
        args: [{ selector: 'orc-skeleton', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-skeleton\"\n  [class.orc-skeleton--text]=\"variant() === 'text'\"\n  [class.orc-skeleton--circular]=\"variant() === 'circular'\"\n  [class.orc-skeleton--rectangular]=\"variant() === 'rectangular'\"\n  [class.orc-skeleton--shimmer]=\"animation() === 'shimmer'\"\n  [class.orc-skeleton--pulse]=\"animation() === 'pulse'\"\n  [class.orc-skeleton--none]=\"animation() === 'none'\"\n  [style.width]=\"computedWidth()\"\n  [style.height]=\"computedHeight()\"\n  [style.border-radius]=\"computedBorderRadius()\"\n  role=\"status\"\n  aria-busy=\"true\"\n  [attr.aria-label]=\"ariaLabel()\"\n>\n  <span class=\"sr-only\">{{ ariaLabel() }}</span>\n</div>\n", styles: [":host{display:block;box-sizing:border-box}.orc-skeleton{display:block;box-sizing:border-box;width:100%;height:100%;background-color:var(--skeleton-base, #F1F5F9);position:relative;overflow:hidden}.orc-skeleton--text{border-radius:8px}.orc-skeleton--circular{border-radius:50%}.orc-skeleton--rectangular{border-radius:8px}.orc-skeleton--shimmer{background-color:var(--skeleton-base, #F1F5F9);background-image:linear-gradient(90deg,var(--skeleton-base, #F1F5F9) 0%,var(--skeleton-highlight, #E2E8F0) 50%,var(--skeleton-base, #F1F5F9) 100%);background-size:200% 100%;background-repeat:no-repeat;animation:orcShimmer 1.5s cubic-bezier(.4,0,.2,1) infinite}.orc-skeleton--pulse{background-color:var(--skeleton-base, #F1F5F9);animation:orcPulse 1.5s ease-in-out infinite}.orc-skeleton--none{animation:none;background-color:var(--skeleton-base, #F1F5F9)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes orcShimmer{0%{background-position:150% 0}to{background-position:-150% 0}}@keyframes orcPulse{0%,to{opacity:1}50%{opacity:.4}}@media(prefers-reduced-motion:reduce){.orc-skeleton--shimmer,.orc-skeleton--pulse{animation:none;background-color:var(--skeleton-base, #F1F5F9)}}\n"] }]
    }], null, { hostDisplay: [{
            type: HostBinding,
            args: ['style.display']
        }], hostWidth: [{
            type: HostBinding,
            args: ['style.width']
        }], hostVerticalAlign: [{
            type: HostBinding,
            args: ['style.vertical-align']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SkeletonComponent, { className: "SkeletonComponent", filePath: "skeleton.component.ts", lineNumber: 19 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { SkeletonComponent };
//# sourceMappingURL=ciag-orchestra-skeleton.mjs.map
