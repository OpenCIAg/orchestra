import * as i0 from '@angular/core';
import { inject, ElementRef, signal, ChangeDetectionStrategy, Component, ViewContainerRef, Renderer2, input, computed, Directive, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

class TooltipComponent {
    elementRef = inject((ElementRef));
    text = signal('');
    theme = signal('dark');
    position = signal('top');
    actualPosition = signal('top');
    visible = signal(false);
    id = signal('');
    static ɵfac = function TooltipComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TooltipComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TooltipComponent, selectors: [["orc-tooltip-overlay"]], decls: 5, vars: 17, consts: [["role", "tooltip", 1, "orc-tooltip", 3, "id"], [1, "orc-tooltip__text"], ["viewBox", "0 0 14 7", "aria-hidden", "true", 1, "orc-tooltip__arrow"], ["d", "M0 0 L7 7 L14 0 Z"]], template: function TooltipComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(3, "svg", 2);
            i0.ɵɵelement(4, "path", 3);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-tooltip--visible", ctx.visible())("orc-tooltip--dark", ctx.theme() === "dark")("orc-tooltip--light", ctx.theme() === "light")("orc-tooltip--top", ctx.actualPosition() === "top")("orc-tooltip--bottom", ctx.actualPosition() === "bottom")("orc-tooltip--left", ctx.actualPosition() === "left")("orc-tooltip--right", ctx.actualPosition() === "right");
            i0.ɵɵproperty("id", ctx.id());
            i0.ɵɵattribute("aria-hidden", !ctx.visible());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.text());
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{position:fixed;z-index:9999;pointer-events:none;display:block}.orc-tooltip[_ngcontent-%COMP%]{position:relative;display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:10px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:400;line-height:20px;white-space:nowrap;box-shadow:0 4px 12px #00000026,0 2px 4px #0000001a;transition:opacity .15s cubic-bezier(.16,1,.3,1),transform .15s cubic-bezier(.16,1,.3,1);opacity:0}.orc-tooltip--visible[_ngcontent-%COMP%]{opacity:1}.orc-tooltip--dark[_ngcontent-%COMP%]{background-color:var(--orc-font-main, #141414);color:#fff}.orc-tooltip--dark[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414)}.orc-tooltip--light[_ngcontent-%COMP%]{background-color:var(--orc-secondary-bg, #D9D9D9);color:var(--orc-font-main, #141414)}.orc-tooltip--light[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{color:var(--orc-secondary-bg, #D9D9D9)}.orc-tooltip__arrow[_ngcontent-%COMP%]{position:absolute;width:14px;height:7px;fill:currentColor;display:block;pointer-events:none}.orc-tooltip--top[_ngcontent-%COMP%]{transform:translateY(4px)}.orc-tooltip--top.orc-tooltip--visible[_ngcontent-%COMP%]{transform:translateY(0)}.orc-tooltip--top[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{bottom:-6px;left:50%;transform:translate(-50%)}.orc-tooltip--bottom[_ngcontent-%COMP%]{transform:translateY(-4px)}.orc-tooltip--bottom.orc-tooltip--visible[_ngcontent-%COMP%]{transform:translateY(0)}.orc-tooltip--bottom[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{top:-6px;left:50%;transform:translate(-50%) rotate(180deg)}.orc-tooltip--left[_ngcontent-%COMP%]{transform:translate(4px)}.orc-tooltip--left.orc-tooltip--visible[_ngcontent-%COMP%]{transform:translate(0)}.orc-tooltip--left[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{right:-10px;top:50%;transform:translateY(-50%) rotate(-90deg);width:14px;height:7px}.orc-tooltip--right[_ngcontent-%COMP%]{transform:translate(-4px)}.orc-tooltip--right.orc-tooltip--visible[_ngcontent-%COMP%]{transform:translate(0)}.orc-tooltip--right[_ngcontent-%COMP%]   .orc-tooltip__arrow[_ngcontent-%COMP%]{left:-10px;top:50%;transform:translateY(-50%) rotate(90deg);width:14px;height:7px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TooltipComponent, [{
        type: Component,
        args: [{ selector: 'orc-tooltip-overlay', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-tooltip\"\n  [class.orc-tooltip--visible]=\"visible()\"\n  [class.orc-tooltip--dark]=\"theme() === 'dark'\"\n  [class.orc-tooltip--light]=\"theme() === 'light'\"\n  [class.orc-tooltip--top]=\"actualPosition() === 'top'\"\n  [class.orc-tooltip--bottom]=\"actualPosition() === 'bottom'\"\n  [class.orc-tooltip--left]=\"actualPosition() === 'left'\"\n  [class.orc-tooltip--right]=\"actualPosition() === 'right'\"\n  [id]=\"id()\"\n  role=\"tooltip\"\n  [attr.aria-hidden]=\"!visible()\"\n>\n  <span class=\"orc-tooltip__text\">{{ text() }}</span>\n\n  <!-- Arrow SVG Polygon -->\n  <svg class=\"orc-tooltip__arrow\" viewBox=\"0 0 14 7\" aria-hidden=\"true\">\n    <path d=\"M0 0 L7 7 L14 0 Z\" />\n  </svg>\n</div>\n", styles: [":host{position:fixed;z-index:9999;pointer-events:none;display:block}.orc-tooltip{position:relative;display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:10px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:400;line-height:20px;white-space:nowrap;box-shadow:0 4px 12px #00000026,0 2px 4px #0000001a;transition:opacity .15s cubic-bezier(.16,1,.3,1),transform .15s cubic-bezier(.16,1,.3,1);opacity:0}.orc-tooltip--visible{opacity:1}.orc-tooltip--dark{background-color:var(--orc-font-main, #141414);color:#fff}.orc-tooltip--dark .orc-tooltip__arrow{color:var(--orc-font-main, #141414)}.orc-tooltip--light{background-color:var(--orc-secondary-bg, #D9D9D9);color:var(--orc-font-main, #141414)}.orc-tooltip--light .orc-tooltip__arrow{color:var(--orc-secondary-bg, #D9D9D9)}.orc-tooltip__arrow{position:absolute;width:14px;height:7px;fill:currentColor;display:block;pointer-events:none}.orc-tooltip--top{transform:translateY(4px)}.orc-tooltip--top.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--top .orc-tooltip__arrow{bottom:-6px;left:50%;transform:translate(-50%)}.orc-tooltip--bottom{transform:translateY(-4px)}.orc-tooltip--bottom.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--bottom .orc-tooltip__arrow{top:-6px;left:50%;transform:translate(-50%) rotate(180deg)}.orc-tooltip--left{transform:translate(4px)}.orc-tooltip--left.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--left .orc-tooltip__arrow{right:-10px;top:50%;transform:translateY(-50%) rotate(-90deg);width:14px;height:7px}.orc-tooltip--right{transform:translate(-4px)}.orc-tooltip--right.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--right .orc-tooltip__arrow{left:-10px;top:50%;transform:translateY(-50%) rotate(90deg);width:14px;height:7px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TooltipComponent, { className: "TooltipComponent", filePath: "tooltip.component.ts", lineNumber: 19 }); })();

let nextUniqueId = 0;
class TooltipDirective {
    elementRef = inject((ElementRef));
    viewContainerRef = inject(ViewContainerRef);
    renderer = inject(Renderer2);
    // ── Inputs (Signals API) ──────────────────────────────────
    appTooltip = input('', { alias: 'appTooltip' });
    uiTooltip = input('', { alias: 'uiTooltip' });
    orcTooltip = input('', { alias: 'orcTooltip' });
    tooltipPosition = input('top');
    tooltipTheme = input('dark');
    tooltipShowDelay = input(150);
    tooltipHideDelay = input(100);
    tooltipDisabled = input(false);
    // Texto efetivo do tooltip
    tooltipText = computed(() => {
        return this.appTooltip() || this.uiTooltip() || this.orcTooltip() || '';
    });
    componentRef = null;
    showTimeoutId = null;
    hideTimeoutId = null;
    tooltipId = `orc-tooltip-${++nextUniqueId}`;
    onMouseEnter() {
        this.scheduleShow();
    }
    onMouseLeave() {
        this.scheduleHide();
    }
    onFocusIn() {
        this.scheduleShow();
    }
    onFocusOut() {
        this.scheduleHide();
    }
    onEscape() {
        this.hideImmediately();
    }
    scheduleShow() {
        if (this.tooltipDisabled() || !this.tooltipText())
            return;
        this.clearHideTimeout();
        if (this.componentRef)
            return;
        const delay = this.tooltipShowDelay();
        if (delay <= 0) {
            this.show();
        }
        else {
            this.showTimeoutId = setTimeout(() => this.show(), delay);
        }
    }
    scheduleHide() {
        this.clearShowTimeout();
        if (!this.componentRef)
            return;
        const delay = this.tooltipHideDelay();
        if (delay <= 0) {
            this.hide();
        }
        else {
            this.hideTimeoutId = setTimeout(() => this.hide(), delay);
        }
    }
    show() {
        if (this.componentRef || this.tooltipDisabled() || !this.tooltipText())
            return;
        // Instancia o componente do tooltip
        this.componentRef = this.viewContainerRef.createComponent(TooltipComponent);
        const instance = this.componentRef.instance;
        instance.text.set(this.tooltipText());
        instance.theme.set(this.tooltipTheme());
        instance.position.set(this.tooltipPosition());
        instance.id.set(this.tooltipId);
        const domElement = this.componentRef.location.nativeElement;
        this.renderer.appendChild(document.body, domElement);
        // The tooltip starts with empty signal values. Render the new inputs before
        // measuring it, otherwise positioning uses the empty shell's dimensions
        // and becomes offset when the text is rendered on the next change-detection
        // pass.
        this.componentRef.changeDetectorRef.detectChanges();
        // WCAG A11y
        this.renderer.setAttribute(this.elementRef.nativeElement, 'aria-describedby', this.tooltipId);
        // Posicionamento inteligente com verificação de colisão
        this.updatePosition();
        // Fade-in animado no próximo frame
        requestAnimationFrame(() => {
            if (this.componentRef) {
                this.componentRef.instance.visible.set(true);
            }
        });
    }
    hide() {
        if (!this.componentRef)
            return;
        this.componentRef.instance.visible.set(false);
        const ref = this.componentRef;
        this.componentRef = null;
        // Remove aria-describedby
        this.renderer.removeAttribute(this.elementRef.nativeElement, 'aria-describedby');
        // Remove do DOM após a transição de fade-out
        setTimeout(() => {
            ref.destroy();
        }, 150);
    }
    hideImmediately() {
        this.clearShowTimeout();
        this.clearHideTimeout();
        if (this.componentRef) {
            this.renderer.removeAttribute(this.elementRef.nativeElement, 'aria-describedby');
            this.componentRef.destroy();
            this.componentRef = null;
        }
    }
    updatePosition() {
        if (!this.componentRef)
            return;
        const triggerEl = this.elementRef.nativeElement;
        const tooltipHost = this.componentRef.location.nativeElement;
        const tooltipEl = tooltipHost.firstElementChild;
        if (!tooltipEl)
            return;
        const triggerRect = triggerEl.getBoundingClientRect();
        const tooltipRect = tooltipEl.getBoundingClientRect();
        const margin = 8;
        let pos = this.tooltipPosition();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        // Verificação de espaço e inversão automática (Auto-Flip)
        if (pos === 'top' && triggerRect.top - tooltipRect.height - margin < 0) {
            pos = 'bottom';
        }
        else if (pos === 'bottom' &&
            triggerRect.bottom + tooltipRect.height + margin > viewportHeight) {
            pos = 'top';
        }
        else if (pos === 'left' &&
            triggerRect.left - tooltipRect.width - margin < 0) {
            pos = 'right';
        }
        else if (pos === 'right' &&
            triggerRect.right + tooltipRect.width + margin > viewportWidth) {
            pos = 'left';
        }
        this.componentRef.instance.actualPosition.set(pos);
        let top = 0;
        let left = 0;
        switch (pos) {
            case 'top':
                top = triggerRect.top - tooltipRect.height - margin;
                left = triggerRect.left + (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'bottom':
                top = triggerRect.bottom + margin;
                left = triggerRect.left + (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'left':
                top = triggerRect.top + (triggerRect.height - tooltipRect.height) / 2;
                left = triggerRect.left - tooltipRect.width - margin;
                break;
            case 'right':
                top = triggerRect.top + (triggerRect.height - tooltipRect.height) / 2;
                left = triggerRect.right + margin;
                break;
        }
        // Garante que não ultrapassa as bordas laterais da viewport
        left = Math.max(8, Math.min(left, viewportWidth - tooltipRect.width - 8));
        top = Math.max(8, Math.min(top, viewportHeight - tooltipRect.height - 8));
        this.renderer.setStyle(tooltipHost, 'top', `${top}px`);
        this.renderer.setStyle(tooltipHost, 'left', `${left}px`);
    }
    clearShowTimeout() {
        if (this.showTimeoutId) {
            clearTimeout(this.showTimeoutId);
            this.showTimeoutId = null;
        }
    }
    clearHideTimeout() {
        if (this.hideTimeoutId) {
            clearTimeout(this.hideTimeoutId);
            this.hideTimeoutId = null;
        }
    }
    ngOnDestroy() {
        this.hideImmediately();
    }
    static ɵfac = function TooltipDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TooltipDirective)(); };
    static ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: TooltipDirective, selectors: [["", "orcTooltip", ""]], hostBindings: function TooltipDirective_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mouseenter", function TooltipDirective_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); })("mouseleave", function TooltipDirective_mouseleave_HostBindingHandler() { return ctx.onMouseLeave(); })("focusin", function TooltipDirective_focusin_HostBindingHandler() { return ctx.onFocusIn(); })("focusout", function TooltipDirective_focusout_HostBindingHandler() { return ctx.onFocusOut(); })("keydown.escape", function TooltipDirective_keydown_escape_HostBindingHandler() { return ctx.onEscape(); });
        } }, inputs: { appTooltip: [1, "appTooltip"], uiTooltip: [1, "uiTooltip"], orcTooltip: [1, "orcTooltip"], tooltipPosition: [1, "tooltipPosition"], tooltipTheme: [1, "tooltipTheme"], tooltipShowDelay: [1, "tooltipShowDelay"], tooltipHideDelay: [1, "tooltipHideDelay"], tooltipDisabled: [1, "tooltipDisabled"] } });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TooltipDirective, [{
        type: Directive,
        args: [{
                selector: '[orcTooltip]',
                standalone: true,
            }]
    }], null, { onMouseEnter: [{
            type: HostListener,
            args: ['mouseenter']
        }], onMouseLeave: [{
            type: HostListener,
            args: ['mouseleave']
        }], onFocusIn: [{
            type: HostListener,
            args: ['focusin']
        }], onFocusOut: [{
            type: HostListener,
            args: ['focusout']
        }], onEscape: [{
            type: HostListener,
            args: ['keydown.escape']
        }] }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { TooltipComponent, TooltipDirective };
//# sourceMappingURL=ciag-orchestra-tooltip.mjs.map
