import * as i0 from '@angular/core';
import { model, input, booleanAttribute, output, computed, ChangeDetectionStrategy, Component, signal, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const P2_SHARED_STYLES = `
:host { display: block; box-sizing: border-box; font-family: var(--font-sans, Inter, system-ui, sans-serif); }
*, *::before, *::after { box-sizing: border-box; }
button, input { font: inherit; }
button { cursor: pointer; }
button:disabled { cursor: not-allowed; opacity: .55; }
.orc-p2-muted { color: var(--orc-font-secondary, #64748b); }
.orc-p2-focus:focus-visible, button:focus-visible, input:focus-visible, [tabindex]:focus-visible { outline: 2px solid var(--orc-color-azul-eletrico, #2563eb); outline-offset: 2px; }
`;

const _forTrack0$3 = ($index, $item) => $item.iso;
function CalendarComponent_For_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const weekday_r1 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(weekday_r1);
} }
function CalendarComponent_For_13_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 7);
    i0.ɵɵlistener("click", function CalendarComponent_For_13_Template_button_click_0_listener() { const day_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.selectDay(day_r3)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const day_r3 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-p2-calendar__day--outside", !day_r3.inCurrentMonth)("orc-p2-calendar__day--today", day_r3.today)("orc-p2-calendar__day--selected", ctx_r3.value() === day_r3.iso);
    i0.ɵɵproperty("disabled", day_r3.disabled);
    i0.ɵɵattribute("aria-selected", ctx_r3.value() === day_r3.iso)("aria-label", day_r3.iso);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", day_r3.day, " ");
} }
const _forTrack1$3 = ($index, $item) => $item.value;
function ComboboxComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 1);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r0.inputId);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function ComboboxComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 7);
    i0.ɵɵlistener("click", function ComboboxComponent_Conditional_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.clear()); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.disabled());
} }
function ComboboxComponent_Conditional_5_For_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(option_r4.description);
} }
function ComboboxComponent_Conditional_5_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 10);
    i0.ɵɵlistener("mousedown", function ComboboxComponent_Conditional_5_For_2_Template_li_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r3); return i0.ɵɵresetView($event.preventDefault()); })("click", function ComboboxComponent_Conditional_5_For_2_Template_li_click_0_listener() { const option_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.select(option_r4)); });
    i0.ɵɵelementStart(1, "strong");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, ComboboxComponent_Conditional_5_For_2_Conditional_3_Template, 2, 1, "small");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r4 = ctx.$implicit;
    const $index_r5 = ctx.$index;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("is-active", $index_r5 === ctx_r0.activeIndex())("is-disabled", option_r4.disabled);
    i0.ɵɵproperty("id", ctx_r0.optionId($index_r5));
    i0.ɵɵattribute("aria-selected", ctx_r0.value() === option_r4.value);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(option_r4.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(option_r4.description ? 3 : -1);
} }
function ComboboxComponent_Conditional_5_ForEmpty_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.emptyText());
} }
function ComboboxComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 5);
    i0.ɵɵrepeaterCreate(1, ComboboxComponent_Conditional_5_For_2_Template, 4, 8, "li", 8, _forTrack1$3, false, ComboboxComponent_Conditional_5_ForEmpty_3_Template, 2, 1, "li", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.listId);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.filteredOptions());
} }
function ComboboxComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.helperText());
} }
function DateInputComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "sup");
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function DateInputComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, DateInputComponent_Conditional_1_Conditional_2_Template, 2, 0, "sup");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", ctx_r0.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.required() ? 2 : -1);
} }
function DateInputComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.error());
} }
function DateInputComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.helperText());
} }
const _c0$3 = ["*"];
function ListboxComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function ListboxComponent_For_4_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(option_r3.description);
} }
function ListboxComponent_For_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 4);
    i0.ɵɵlistener("click", function ListboxComponent_For_4_Template_li_click_0_listener() { const option_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.select(option_r3)); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, ListboxComponent_For_4_Conditional_3_Template, 2, 1, "small");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("is-selected", ctx_r0.isSelected(option_r3))("is-disabled", option_r3.disabled);
    i0.ɵɵattribute("aria-selected", ctx_r0.isSelected(option_r3));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(option_r3.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(option_r3.description ? 3 : -1);
} }
function ListboxComponent_ForEmpty_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 3);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.emptyText());
} }
function MultiSelectComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function MultiSelectComponent_Conditional_7_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 6);
    i0.ɵɵlistener("click", function MultiSelectComponent_Conditional_7_For_2_Template_li_click_0_listener() { const option_r3 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.select(option_r3)); });
    i0.ɵɵelementStart(1, "span", 7);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r3 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("aria-selected", ctx_r0.isSelected(option_r3));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.isSelected(option_r3) ? "\u2713" : "");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(option_r3.label);
} }
function MultiSelectComponent_Conditional_7_ForEmpty_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.emptyText());
} }
function MultiSelectComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 3);
    i0.ɵɵrepeaterCreate(1, MultiSelectComponent_Conditional_7_For_2_Template, 4, 3, "li", 4, _forTrack1$3, false, MultiSelectComponent_Conditional_7_ForEmpty_3_Template, 2, 1, "li", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.options());
} }
function TagsInputComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function TagsInputComponent_For_4_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementStart(2, "button", 5);
    i0.ɵɵlistener("click", function TagsInputComponent_For_4_Template_button_click_2_listener() { const $index_r3 = i0.ɵɵrestoreView(_r2).$index; const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.removeTag($index_r3)); });
    i0.ɵɵtext(3, "\u00D7");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const tag_r4 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", tag_r4, " ");
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.disabled());
    i0.ɵɵattribute("aria-label", "Remove " + tag_r4);
} }
function TagsInputComponent_Conditional_6_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 7);
    i0.ɵɵlistener("mousedown", function TagsInputComponent_Conditional_6_For_2_Template_li_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r5); return i0.ɵɵresetView($event.preventDefault()); })("click", function TagsInputComponent_Conditional_6_For_2_Template_li_click_0_listener() { const suggestion_r6 = i0.ɵɵrestoreView(_r5).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.addTag(suggestion_r6)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const suggestion_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(suggestion_r6);
} }
function TagsInputComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 4);
    i0.ɵɵrepeaterCreate(1, TagsInputComponent_Conditional_6_For_2_Template, 2, 1, "li", 6, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.filteredSuggestions());
} }
function TagsInputComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.helperText());
} }
const pad = (value) => String(value).padStart(2, '0');
const toIso = (date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
const toMonthKey = (date) => `${date.getFullYear()}-${pad(date.getMonth() + 1)}`;
const fromMonthKey = (value) => {
    const [year, month] = value.split('-').map(Number);
    const safeYear = Number.isFinite(year) ? year : new Date().getFullYear();
    const safeMonth = Number.isFinite(month) ? month - 1 : new Date().getMonth();
    return new Date(safeYear, safeMonth, 1);
};
class CalendarComponent {
    value = model('');
    currentMonth = model(toMonthKey(new Date()));
    min = input('');
    max = input('');
    disabled = input(false, { transform: booleanAttribute });
    ariaLabel = input('Calendar');
    dateSelected = output();
    weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
    monthLabel = computed(() => fromMonthKey(this.currentMonth()).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }));
    days = computed(() => {
        const month = fromMonthKey(this.currentMonth());
        const start = new Date(month.getFullYear(), month.getMonth(), 1 - month.getDay());
        const today = toIso(new Date());
        return Array.from({ length: 42 }, (_, index) => {
            const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + index);
            const iso = toIso(date);
            return {
                iso,
                day: date.getDate(),
                inCurrentMonth: date.getMonth() === month.getMonth(),
                today: iso === today,
                disabled: this.disabled() || (!!this.min() && iso < this.min()) || (!!this.max() && iso > this.max()),
            };
        });
    });
    previousMonth() { this.shiftMonth(-1); }
    nextMonth() { this.shiftMonth(1); }
    selectDay(day) {
        if (day.disabled)
            return;
        this.value.set(day.iso);
        this.dateSelected.emit(day.iso);
    }
    shiftMonth(delta) {
        const current = fromMonthKey(this.currentMonth());
        this.currentMonth.set(toMonthKey(new Date(current.getFullYear(), current.getMonth() + delta, 1)));
    }
    static ɵfac = function CalendarComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CalendarComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CalendarComponent, selectors: [["orc-calendar"]], inputs: { value: [1, "value"], currentMonth: [1, "currentMonth"], min: [1, "min"], max: [1, "max"], disabled: [1, "disabled"], ariaLabel: [1, "ariaLabel"] }, outputs: { value: "valueChange", currentMonth: "currentMonthChange", dateSelected: "dateSelected" }, decls: 14, vars: 3, consts: [[1, "orc-p2-calendar"], [1, "orc-p2-calendar__header"], ["type", "button", "aria-label", "M\u00EAs anterior", 3, "click"], ["type", "button", "aria-label", "Pr\u00F3ximo m\u00EAs", 3, "click"], ["aria-hidden", "true", 1, "orc-p2-calendar__weekdays"], ["role", "grid", 1, "orc-p2-calendar__grid"], ["type", "button", "role", "gridcell", 1, "orc-p2-calendar__day", 3, "orc-p2-calendar__day--outside", "orc-p2-calendar__day--today", "orc-p2-calendar__day--selected", "disabled"], ["type", "button", "role", "gridcell", 1, "orc-p2-calendar__day", 3, "click", "disabled"]], template: function CalendarComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "section", 0)(1, "header", 1)(2, "button", 2);
            i0.ɵɵlistener("click", function CalendarComponent_Template_button_click_2_listener() { return ctx.previousMonth(); });
            i0.ɵɵtext(3, "\u2039");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "strong");
            i0.ɵɵtext(5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "button", 3);
            i0.ɵɵlistener("click", function CalendarComponent_Template_button_click_6_listener() { return ctx.nextMonth(); });
            i0.ɵɵtext(7, "\u203A");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(8, "div", 4);
            i0.ɵɵrepeaterCreate(9, CalendarComponent_For_10_Template, 2, 1, "span", null, i0.ɵɵrepeaterTrackByIdentity);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "div", 5);
            i0.ɵɵrepeaterCreate(12, CalendarComponent_For_13_Template, 2, 10, "button", 6, _forTrack0$3);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate(ctx.monthLabel());
            i0.ɵɵadvance(4);
            i0.ɵɵrepeater(ctx.weekdays);
            i0.ɵɵadvance(2);
            i0.ɵɵattribute("aria-label", ctx.monthLabel());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.days());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-calendar[_ngcontent-%COMP%]{width:min(100%,320px);padding:1rem;border:1px solid #e2e8f0;border-radius:.875rem;background:#fff;color:#0f172a}.orc-p2-calendar__header[_ngcontent-%COMP%], .orc-p2-calendar__weekdays[_ngcontent-%COMP%], .orc-p2-calendar__grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(7,1fr);align-items:center;gap:.25rem}.orc-p2-calendar__header[_ngcontent-%COMP%]{grid-template-columns:2rem 1fr 2rem;margin-bottom:.75rem;text-align:center}.orc-p2-calendar__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:0;border-radius:.375rem;background:transparent;font-size:1.35rem;line-height:2rem}.orc-p2-calendar__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover{background:#f1f5f9}.orc-p2-calendar__weekdays[_ngcontent-%COMP%]{margin-bottom:.25rem;color:#64748b;font-size:.7rem;font-weight:700;text-align:center;text-transform:uppercase}.orc-p2-calendar__day[_ngcontent-%COMP%]{min-height:2.2rem;border:0;border-radius:.5rem;background:transparent;color:inherit}.orc-p2-calendar__day[_ngcontent-%COMP%]:hover:not(:disabled), .orc-p2-calendar__day--selected[_ngcontent-%COMP%]{background:#2563eb;color:#fff}.orc-p2-calendar__day--outside[_ngcontent-%COMP%]{color:#94a3b8}.orc-p2-calendar__day--today[_ngcontent-%COMP%]{box-shadow:inset 0 0 0 1px #2563eb}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CalendarComponent, [{
        type: Component,
        args: [{ selector: 'orc-calendar', standalone: true, template: `
    <section class="orc-p2-calendar" [attr.aria-label]="ariaLabel()">
      <header class="orc-p2-calendar__header">
        <button type="button" aria-label="Mês anterior" (click)="previousMonth()">‹</button>
        <strong>{{ monthLabel() }}</strong>
        <button type="button" aria-label="Próximo mês" (click)="nextMonth()">›</button>
      </header>
      <div class="orc-p2-calendar__weekdays" aria-hidden="true">
        @for (weekday of weekdays; track weekday) { <span>{{ weekday }}</span> }
      </div>
      <div class="orc-p2-calendar__grid" role="grid" [attr.aria-label]="monthLabel()">
        @for (day of days(); track day.iso) {
          <button
            type="button"
            role="gridcell"
            class="orc-p2-calendar__day"
            [class.orc-p2-calendar__day--outside]="!day.inCurrentMonth"
            [class.orc-p2-calendar__day--today]="day.today"
            [class.orc-p2-calendar__day--selected]="value() === day.iso"
            [disabled]="day.disabled"
            [attr.aria-selected]="value() === day.iso"
            [attr.aria-label]="day.iso"
            (click)="selectDay(day)">
            {{ day.day }}
          </button>
        }
      </div>
    </section>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-calendar{width:min(100%,320px);padding:1rem;border:1px solid #e2e8f0;border-radius:.875rem;background:#fff;color:#0f172a}.orc-p2-calendar__header,.orc-p2-calendar__weekdays,.orc-p2-calendar__grid{display:grid;grid-template-columns:repeat(7,1fr);align-items:center;gap:.25rem}.orc-p2-calendar__header{grid-template-columns:2rem 1fr 2rem;margin-bottom:.75rem;text-align:center}.orc-p2-calendar__header button{border:0;border-radius:.375rem;background:transparent;font-size:1.35rem;line-height:2rem}.orc-p2-calendar__header button:hover{background:#f1f5f9}.orc-p2-calendar__weekdays{margin-bottom:.25rem;color:#64748b;font-size:.7rem;font-weight:700;text-align:center;text-transform:uppercase}.orc-p2-calendar__day{min-height:2.2rem;border:0;border-radius:.5rem;background:transparent;color:inherit}.orc-p2-calendar__day:hover:not(:disabled),.orc-p2-calendar__day--selected{background:#2563eb;color:#fff}.orc-p2-calendar__day--outside{color:#94a3b8}.orc-p2-calendar__day--today{box-shadow:inset 0 0 0 1px #2563eb}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CalendarComponent, { className: "CalendarComponent", filePath: "p2-form-components.ts", lineNumber: 79 }); })();
class ComboboxComponent {
    static nextId = 0;
    inputId = `orc-combobox-${++ComboboxComponent.nextId}`;
    listId = `${this.inputId}-listbox`;
    options = input([]);
    value = model(null);
    query = model('');
    open = model(false);
    label = input('');
    placeholder = input('Search…');
    helperText = input('');
    emptyText = input('No results');
    disabled = input(false, { transform: booleanAttribute });
    optionSelected = output();
    activeIndex = signal(-1);
    filteredOptions = computed(() => {
        const term = this.query().trim().toLocaleLowerCase();
        return this.options().filter(option => !term || option.label.toLocaleLowerCase().includes(term));
    });
    optionId(index) { return `${this.listId}-option-${index}`; }
    onInput(event) {
        this.query.set(event.target.value);
        this.open.set(true);
        this.activeIndex.set(0);
    }
    select(option) {
        if (option.disabled || this.disabled())
            return;
        this.value.set(option.value);
        this.query.set(option.label);
        this.open.set(false);
        this.optionSelected.emit(option);
    }
    clear() { this.value.set(null); this.query.set(''); this.open.set(false); }
    onKeydown(event) {
        const options = this.filteredOptions();
        if (event.key === 'Escape') {
            this.open.set(false);
            return;
        }
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            const delta = event.key === 'ArrowDown' ? 1 : -1;
            this.activeIndex.update(index => options.length ? (index + delta + options.length) % options.length : -1);
        }
        else if (event.key === 'Enter' && this.open() && this.activeIndex() >= 0) {
            event.preventDefault();
            const option = options[this.activeIndex()];
            if (option)
                this.select(option);
        }
    }
    static ɵfac = function ComboboxComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ComboboxComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ComboboxComponent, selectors: [["orc-combobox"]], inputs: { options: [1, "options"], value: [1, "value"], query: [1, "query"], open: [1, "open"], label: [1, "label"], placeholder: [1, "placeholder"], helperText: [1, "helperText"], emptyText: [1, "emptyText"], disabled: [1, "disabled"] }, outputs: { value: "valueChange", query: "queryChange", open: "openChange", optionSelected: "optionSelected" }, decls: 7, vars: 11, consts: [[1, "orc-p2-field"], [3, "for"], [1, "orc-p2-combobox"], ["role", "combobox", 3, "input", "focus", "keydown", "id", "value", "placeholder", "disabled"], ["type", "button", "aria-label", "Limpar", 1, "orc-p2-clear", 3, "disabled"], ["role", "listbox", 1, "orc-p2-options", 3, "id"], [1, "orc-p2-muted"], ["type", "button", "aria-label", "Limpar", 1, "orc-p2-clear", 3, "click", "disabled"], ["role", "option", 3, "id", "is-active", "is-disabled"], [1, "orc-p2-empty"], ["role", "option", 3, "mousedown", "click", "id"]], template: function ComboboxComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ComboboxComponent_Conditional_1_Template, 2, 2, "label", 1);
            i0.ɵɵelementStart(2, "div", 2)(3, "input", 3);
            i0.ɵɵlistener("input", function ComboboxComponent_Template_input_input_3_listener($event) { return ctx.onInput($event); })("focus", function ComboboxComponent_Template_input_focus_3_listener() { return ctx.open.set(true); })("keydown", function ComboboxComponent_Template_input_keydown_3_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, ComboboxComponent_Conditional_4_Template, 2, 1, "button", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ComboboxComponent_Conditional_5_Template, 4, 2, "ul", 5)(6, ComboboxComponent_Conditional_6_Template, 2, 1, "small", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("id", ctx.inputId)("value", ctx.query())("placeholder", ctx.placeholder())("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-expanded", ctx.open())("aria-controls", ctx.listId)("aria-activedescendant", ctx.activeIndex() >= 0 ? ctx.optionId(ctx.activeIndex()) : null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.query() ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.open() ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.helperText() ? 6 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-field[_ngcontent-%COMP%]{position:relative;display:grid;gap:.35rem;width:100%;color:#0f172a}label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.orc-p2-combobox[_ngcontent-%COMP%]{position:relative;display:flex;align-items:center}input[_ngcontent-%COMP%]{width:100%;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .75rem}.orc-p2-clear[_ngcontent-%COMP%]{position:absolute;right:.25rem;border:0;background:transparent;font-size:1.2rem}.orc-p2-options[_ngcontent-%COMP%]{position:absolute;z-index:2;top:4.3rem;right:0;left:0;max-height:15rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}.orc-p2-options[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:grid;gap:.1rem;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}.orc-p2-options[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover, .orc-p2-options[_ngcontent-%COMP%]   .is-active[_ngcontent-%COMP%]{background:#eff6ff}.orc-p2-options[_ngcontent-%COMP%]   .is-disabled[_ngcontent-%COMP%]{color:#94a3b8;cursor:not-allowed}.orc-p2-options[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#64748b}.orc-p2-empty[_ngcontent-%COMP%]{color:#64748b;cursor:default!important}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComboboxComponent, [{
        type: Component,
        args: [{ selector: 'orc-combobox', standalone: true, template: `
    <div class="orc-p2-field">
      @if (label()) { <label [for]="inputId">{{ label() }}</label> }
      <div class="orc-p2-combobox">
        <input
          [id]="inputId"
          role="combobox"
          [value]="query()"
          [placeholder]="placeholder()"
          [disabled]="disabled()"
          [attr.aria-expanded]="open()"
          [attr.aria-controls]="listId"
          [attr.aria-activedescendant]="activeIndex() >= 0 ? optionId(activeIndex()) : null"
          (input)="onInput($event)"
          (focus)="open.set(true)"
          (keydown)="onKeydown($event)" />
        @if (query()) { <button type="button" class="orc-p2-clear" aria-label="Limpar" [disabled]="disabled()" (click)="clear()">×</button> }
      </div>
      @if (open()) {
        <ul class="orc-p2-options" [id]="listId" role="listbox">
          @for (option of filteredOptions(); track option.value) {
            <li [id]="optionId($index)" role="option" [attr.aria-selected]="value() === option.value" [class.is-active]="$index === activeIndex()" [class.is-disabled]="option.disabled" (mousedown)="$event.preventDefault()" (click)="select(option)">
              <strong>{{ option.label }}</strong>
              @if (option.description) { <small>{{ option.description }}</small> }
            </li>
          } @empty { <li class="orc-p2-empty">{{ emptyText() }}</li> }
        </ul>
      }
      @if (helperText()) { <small class="orc-p2-muted">{{ helperText() }}</small> }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-field{position:relative;display:grid;gap:.35rem;width:100%;color:#0f172a}label{font-size:.875rem;font-weight:600}.orc-p2-combobox{position:relative;display:flex;align-items:center}input{width:100%;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .75rem}.orc-p2-clear{position:absolute;right:.25rem;border:0;background:transparent;font-size:1.2rem}.orc-p2-options{position:absolute;z-index:2;top:4.3rem;right:0;left:0;max-height:15rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}.orc-p2-options li{display:grid;gap:.1rem;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}.orc-p2-options li:hover,.orc-p2-options .is-active{background:#eff6ff}.orc-p2-options .is-disabled{color:#94a3b8;cursor:not-allowed}.orc-p2-options small{color:#64748b}.orc-p2-empty{color:#64748b;cursor:default!important}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ComboboxComponent, { className: "ComboboxComponent", filePath: "p2-form-components.ts", lineNumber: 171 }); })();
class DateInputComponent {
    value = model('');
    label = input('');
    name = input('');
    min = input('');
    max = input('');
    helperText = input('');
    error = input('');
    required = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    cvaDisabled = signal(false);
    onChange = () => undefined;
    onTouchedCallback = () => undefined;
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    writeValue(value) { this.value.set(value ?? ''); }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouchedCallback = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    onInput(event) { const value = event.target.value; this.value.set(value); this.onChange(value); }
    onTouched() { this.onTouchedCallback(); }
    static ɵfac = function DateInputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DateInputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DateInputComponent, selectors: [["orc-date-input"]], inputs: { value: [1, "value"], label: [1, "label"], name: [1, "name"], min: [1, "min"], max: [1, "max"], helperText: [1, "helperText"], error: [1, "error"], required: [1, "required"], disabled: [1, "disabled"], readonly: [1, "readonly"] }, outputs: { value: "valueChange" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DateInputComponent), multi: true }])], decls: 5, vars: 9, consts: [[1, "orc-p2-date-input"], ["type", "date", 3, "input", "blur", "value", "min", "max", "disabled", "readonly"], ["role", "alert", 1, "error"]], template: function DateInputComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "label", 0);
            i0.ɵɵtemplate(1, DateInputComponent_Conditional_1_Template, 3, 2, "span");
            i0.ɵɵelementStart(2, "input", 1);
            i0.ɵɵlistener("input", function DateInputComponent_Template_input_input_2_listener($event) { return ctx.onInput($event); })("blur", function DateInputComponent_Template_input_blur_2_listener() { return ctx.onTouched(); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, DateInputComponent_Conditional_3_Template, 2, 1, "small", 2)(4, DateInputComponent_Conditional_4_Template, 2, 1, "small");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("value", ctx.value())("min", ctx.min() || null)("max", ctx.max() || null)("disabled", ctx.effectiveDisabled())("readonly", ctx.readonly());
            i0.ɵɵattribute("aria-invalid", !!ctx.error());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.error() ? 3 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(!ctx.error() && ctx.helperText() ? 4 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-date-input[_ngcontent-%COMP%]{display:grid;gap:.35rem;color:#0f172a;font-size:.875rem;font-weight:600}input[_ngcontent-%COMP%]{min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .65rem;font-weight:400}small[_ngcontent-%COMP%]{color:#64748b;font-weight:400}.error[_ngcontent-%COMP%]{color:#b91c1c}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DateInputComponent, [{
        type: Component,
        args: [{ selector: 'orc-date-input', standalone: true, template: `
    <label class="orc-p2-date-input">
      @if (label()) { <span>{{ label() }} @if (required()) { <sup>*</sup> }</span> }
      <input type="date" [value]="value()" [min]="min() || null" [max]="max() || null" [disabled]="effectiveDisabled()" [readonly]="readonly()" [attr.aria-invalid]="!!error()" (input)="onInput($event)" (blur)="onTouched()" />
      @if (error()) { <small class="error" role="alert">{{ error() }}</small> }
      @if (!error() && helperText()) { <small>{{ helperText() }}</small> }
    </label>
  `, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => DateInputComponent), multi: true }], styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-date-input{display:grid;gap:.35rem;color:#0f172a;font-size:.875rem;font-weight:600}input{min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .65rem;font-weight:400}small{color:#64748b;font-weight:400}.error{color:#b91c1c}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DateInputComponent, { className: "DateInputComponent", filePath: "p2-form-components.ts", lineNumber: 244 }); })();
class InputGroupComponent {
    label = input('');
    prefix = input('');
    suffix = input('');
    static ɵfac = function InputGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InputGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: InputGroupComponent, selectors: [["orc-input-group"]], inputs: { label: [1, "label"], prefix: [1, "prefix"], suffix: [1, "suffix"] }, ngContentSelectors: _c0$3, decls: 7, vars: 7, consts: [["role", "group", 1, "orc-p2-input-group"], [1, "prefix"], [1, "control"], [1, "suffix"]], template: function InputGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0)(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 2);
            i0.ɵɵprojection(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "span", 3);
            i0.ɵɵtext(6);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.label() || null);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("empty", !ctx.prefix());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.prefix());
            i0.ɵɵadvance(3);
            i0.ɵɵclassProp("empty", !ctx.suffix());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.suffix());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-input-group[_ngcontent-%COMP%]{display:flex;align-items:stretch;width:100%;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;overflow:hidden;background:#fff}.prefix[_ngcontent-%COMP%], .suffix[_ngcontent-%COMP%]{display:inline-flex;align-items:center;padding-inline:.7rem;background:#f8fafc;color:#475569;font-size:.875rem}.prefix.empty[_ngcontent-%COMP%], .suffix.empty[_ngcontent-%COMP%]{display:none}.control[_ngcontent-%COMP%]{display:flex;flex:1;align-items:center;min-width:0}.control[_ngcontent-%COMP%]     input, .control[_ngcontent-%COMP%]     textarea, .control[_ngcontent-%COMP%]     select{width:100%;border:0;outline:0;padding:.5rem .7rem;background:transparent}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InputGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-input-group', standalone: true, template: `<div class="orc-p2-input-group" role="group" [attr.aria-label]="label() || null"><span class="prefix" [class.empty]="!prefix()">{{ prefix() }}</span><div class="control"><ng-content /></div><span class="suffix" [class.empty]="!suffix()">{{ suffix() }}</span></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-input-group{display:flex;align-items:stretch;width:100%;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;overflow:hidden;background:#fff}.prefix,.suffix{display:inline-flex;align-items:center;padding-inline:.7rem;background:#f8fafc;color:#475569;font-size:.875rem}.prefix.empty,.suffix.empty{display:none}.control{display:flex;flex:1;align-items:center;min-width:0}.control ::ng-deep input,.control ::ng-deep textarea,.control ::ng-deep select{width:100%;border:0;outline:0;padding:.5rem .7rem;background:transparent}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(InputGroupComponent, { className: "InputGroupComponent", filePath: "p2-form-components.ts", lineNumber: 275 }); })();
class ListboxComponent {
    options = input([]);
    value = model(null);
    multiple = input(false, { transform: booleanAttribute });
    label = input('');
    ariaLabel = input('Listbox');
    emptyText = input('No options');
    optionSelected = output();
    activeIndex = signal(0);
    isSelected(option) {
        const current = this.value();
        return this.multiple() ? (Array.isArray(current) && current.includes(option.value)) : current === option.value;
    }
    select(option) {
        if (option.disabled)
            return;
        if (this.multiple()) {
            const value = this.value();
            const current = Array.isArray(value) ? [...value] : [];
            const index = current.indexOf(option.value);
            index >= 0 ? current.splice(index, 1) : current.push(option.value);
            this.value.set(current);
        }
        else {
            this.value.set(option.value);
        }
        this.optionSelected.emit(option);
    }
    onKeydown(event) {
        const options = this.options();
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            const delta = event.key === 'ArrowDown' ? 1 : -1;
            this.activeIndex.update(index => options.length ? (index + delta + options.length) % options.length : 0);
        }
        else if (event.key === 'Enter' && options[this.activeIndex()]) {
            this.select(options[this.activeIndex()]);
        }
    }
    static ɵfac = function ListboxComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListboxComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListboxComponent, selectors: [["orc-listbox"]], inputs: { options: [1, "options"], value: [1, "value"], multiple: [1, "multiple"], label: [1, "label"], ariaLabel: [1, "ariaLabel"], emptyText: [1, "emptyText"] }, outputs: { value: "valueChange", optionSelected: "optionSelected" }, decls: 6, vars: 4, consts: [[1, "orc-p2-listbox-wrap"], ["role", "listbox", "tabindex", "0", 1, "orc-p2-listbox", 3, "keydown"], ["role", "option", 3, "is-selected", "is-disabled"], [1, "empty"], ["role", "option", 3, "click"]], template: function ListboxComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ListboxComponent_Conditional_1_Template, 2, 1, "label");
            i0.ɵɵelementStart(2, "ul", 1);
            i0.ɵɵlistener("keydown", function ListboxComponent_Template_ul_keydown_2_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵrepeaterCreate(3, ListboxComponent_For_4_Template, 4, 7, "li", 2, _forTrack1$3, false, ListboxComponent_ForEmpty_5_Template, 2, 1, "li", 3);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵattribute("aria-label", ctx.ariaLabel())("aria-multiselectable", ctx.multiple());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.options());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-listbox-wrap[_ngcontent-%COMP%]{display:grid;gap:.35rem;color:#0f172a}label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.orc-p2-listbox[_ngcontent-%COMP%]{max-height:16rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;list-style:none;outline:none}li[_ngcontent-%COMP%]{display:grid;gap:.1rem;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}li[_ngcontent-%COMP%]:hover, li.is-selected[_ngcontent-%COMP%]{background:#eff6ff;color:#1d4ed8}li.is-disabled[_ngcontent-%COMP%]{color:#94a3b8;cursor:not-allowed}small[_ngcontent-%COMP%], .empty[_ngcontent-%COMP%]{color:#64748b}.empty[_ngcontent-%COMP%]{cursor:default}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListboxComponent, [{
        type: Component,
        args: [{ selector: 'orc-listbox', standalone: true, template: `
    <div class="orc-p2-listbox-wrap">
      @if (label()) { <label>{{ label() }}</label> }
      <ul class="orc-p2-listbox" role="listbox" [attr.aria-label]="ariaLabel()" [attr.aria-multiselectable]="multiple()" tabindex="0" (keydown)="onKeydown($event)">
        @for (option of options(); track option.value) {
          <li role="option" [attr.aria-selected]="isSelected(option)" [class.is-selected]="isSelected(option)" [class.is-disabled]="option.disabled" (click)="select(option)">
            <span>{{ option.label }}</span>@if (option.description) { <small>{{ option.description }}</small> }
          </li>
        } @empty { <li class="empty">{{ emptyText() }}</li> }
      </ul>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-listbox-wrap{display:grid;gap:.35rem;color:#0f172a}label{font-size:.875rem;font-weight:600}.orc-p2-listbox{max-height:16rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;list-style:none;outline:none}li{display:grid;gap:.1rem;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}li:hover,li.is-selected{background:#eff6ff;color:#1d4ed8}li.is-disabled{color:#94a3b8;cursor:not-allowed}small,.empty{color:#64748b}.empty{cursor:default}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ListboxComponent, { className: "ListboxComponent", filePath: "p2-form-components.ts", lineNumber: 303 }); })();
class MultiSelectComponent {
    options = input([]);
    value = model([]);
    label = input('');
    placeholder = input('Select options');
    emptyText = input('No options');
    disabled = input(false, { transform: booleanAttribute });
    open = model(false);
    optionSelected = output();
    isSelected(option) { return this.value().includes(option.value); }
    selectedLabels() { return this.options().filter(option => this.isSelected(option)).map(option => option.label).join(', '); }
    select(option) {
        if (option.disabled || this.disabled())
            return;
        const current = [...this.value()];
        const index = current.indexOf(option.value);
        index >= 0 ? current.splice(index, 1) : current.push(option.value);
        this.value.set(current);
        this.optionSelected.emit(option);
    }
    static ɵfac = function MultiSelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MultiSelectComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MultiSelectComponent, selectors: [["orc-multi-select"]], inputs: { options: [1, "options"], value: [1, "value"], label: [1, "label"], placeholder: [1, "placeholder"], emptyText: [1, "emptyText"], disabled: [1, "disabled"], open: [1, "open"] }, outputs: { value: "valueChange", open: "openChange", optionSelected: "optionSelected" }, decls: 8, vars: 5, consts: [[1, "orc-p2-multi-select"], ["type", "button", 1, "trigger", 3, "click", "disabled"], ["aria-hidden", "true"], ["role", "listbox", "aria-multiselectable", "true", 1, "options"], ["role", "option"], [1, "empty"], ["role", "option", 3, "click"], [1, "check"]], template: function MultiSelectComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MultiSelectComponent_Conditional_1_Template, 2, 1, "label");
            i0.ɵɵelementStart(2, "button", 1);
            i0.ɵɵlistener("click", function MultiSelectComponent_Template_button_click_2_listener() { return ctx.open.set(!ctx.open()); });
            i0.ɵɵelementStart(3, "span");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "span", 2);
            i0.ɵɵtext(6, "\u2304");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(7, MultiSelectComponent_Conditional_7_Template, 4, 1, "ul", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-expanded", ctx.open());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.selectedLabels() || ctx.placeholder());
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.open() ? 7 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-multi-select[_ngcontent-%COMP%]{position:relative;display:grid;gap:.35rem;color:#0f172a}label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.trigger[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .75rem;background:#fff;text-align:left}.options[_ngcontent-%COMP%]{position:absolute;z-index:2;top:4.2rem;right:0;left:0;max-height:15rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}li[_ngcontent-%COMP%]{display:flex;gap:.5rem;align-items:center;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}li[_ngcontent-%COMP%]:hover{background:#eff6ff}.check[_ngcontent-%COMP%]{width:1rem;color:#2563eb}.empty[_ngcontent-%COMP%]{color:#64748b;cursor:default}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MultiSelectComponent, [{
        type: Component,
        args: [{ selector: 'orc-multi-select', standalone: true, template: `
    <div class="orc-p2-multi-select">
      @if (label()) { <label>{{ label() }}</label> }
      <button type="button" class="trigger" [disabled]="disabled()" [attr.aria-expanded]="open()" (click)="open.set(!open())">
        <span>{{ selectedLabels() || placeholder() }}</span><span aria-hidden="true">⌄</span>
      </button>
      @if (open()) {
        <ul class="options" role="listbox" aria-multiselectable="true">
          @for (option of options(); track option.value) { <li role="option" [attr.aria-selected]="isSelected(option)" (click)="select(option)"><span class="check">{{ isSelected(option) ? '✓' : '' }}</span>{{ option.label }}</li> }
          @empty { <li class="empty">{{ emptyText() }}</li> }
        </ul>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-multi-select{position:relative;display:grid;gap:.35rem;color:#0f172a}label{font-size:.875rem;font-weight:600}.trigger{display:flex;justify-content:space-between;align-items:center;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;padding:.5rem .75rem;background:#fff;text-align:left}.options{position:absolute;z-index:2;top:4.2rem;right:0;left:0;max-height:15rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}li{display:flex;gap:.5rem;align-items:center;padding:.55rem .65rem;border-radius:.35rem;cursor:pointer}li:hover{background:#eff6ff}.check{width:1rem;color:#2563eb}.empty{color:#64748b;cursor:default}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MultiSelectComponent, { className: "MultiSelectComponent", filePath: "p2-form-components.ts", lineNumber: 369 }); })();
class TagsInputComponent {
    value = model([]);
    draft = signal('');
    label = input('');
    placeholder = input('Add a tag…');
    helperText = input('');
    suggestions = input([]);
    maxTags = input(undefined);
    disabled = input(false, { transform: booleanAttribute });
    tagAdded = output();
    tagRemoved = output();
    onChange = () => undefined;
    onTouchedCallback = () => undefined;
    filteredSuggestions = computed(() => this.suggestions().filter(item => item.toLocaleLowerCase().includes(this.draft().toLocaleLowerCase()) && !this.value().includes(item)).slice(0, 8));
    writeValue(value) { this.value.set(Array.isArray(value) ? [...value] : []); }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouchedCallback = fn; }
    setDisabledState(disabled) { /* input remains the source of truth for this lightweight control */ void disabled; }
    onKeydown(event) {
        if (event.key === 'Enter' || event.key === ',') {
            event.preventDefault();
            this.addTag(this.draft().trim());
        }
        if (event.key === 'Backspace' && !this.draft() && this.value().length)
            this.removeTag(this.value().length - 1);
    }
    addTag(tag) {
        const normalized = tag.trim();
        if (!normalized || this.disabled() || this.value().includes(normalized) || (this.maxTags() !== undefined && this.value().length >= this.maxTags()))
            return;
        const next = [...this.value(), normalized];
        this.value.set(next);
        this.draft.set('');
        this.onChange(next);
        this.tagAdded.emit(normalized);
    }
    removeTag(index) {
        if (this.disabled())
            return;
        const removed = this.value()[index];
        if (removed === undefined)
            return;
        const next = this.value().filter((_, current) => current !== index);
        this.value.set(next);
        this.onChange(next);
        this.tagRemoved.emit(removed);
    }
    onTouched() { this.onTouchedCallback(); }
    static ɵfac = function TagsInputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TagsInputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TagsInputComponent, selectors: [["orc-tags-input"]], inputs: { value: [1, "value"], label: [1, "label"], placeholder: [1, "placeholder"], helperText: [1, "helperText"], suggestions: [1, "suggestions"], maxTags: [1, "maxTags"], disabled: [1, "disabled"] }, outputs: { value: "valueChange", tagAdded: "tagAdded", tagRemoved: "tagRemoved" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => TagsInputComponent), multi: true }])], decls: 8, vars: 8, consts: [[1, "orc-p2-tags-input"], [1, "input-shell"], [1, "tag"], [3, "input", "keydown", "placeholder", "disabled", "value"], ["role", "listbox", 1, "suggestions"], ["type", "button", 3, "click", "disabled"], ["role", "option"], ["role", "option", 3, "mousedown", "click"]], template: function TagsInputComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, TagsInputComponent_Conditional_1_Template, 2, 1, "label");
            i0.ɵɵelementStart(2, "div", 1);
            i0.ɵɵrepeaterCreate(3, TagsInputComponent_For_4_Template, 4, 3, "span", 2, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵelementStart(5, "input", 3);
            i0.ɵɵlistener("input", function TagsInputComponent_Template_input_input_5_listener($event) { return ctx.draft.set($event.target.value); })("keydown", function TagsInputComponent_Template_input_keydown_5_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(6, TagsInputComponent_Conditional_6_Template, 3, 0, "ul", 4)(7, TagsInputComponent_Conditional_7_Template, 2, 1, "small");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("is-disabled", ctx.disabled());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.value());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("placeholder", ctx.value().length ? "" : ctx.placeholder())("disabled", ctx.disabled())("value", ctx.draft());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.suggestions().length && ctx.draft() ? 6 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.helperText() ? 7 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tags-input[_ngcontent-%COMP%]{position:relative;display:grid;gap:.35rem;color:#0f172a}label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.input-shell[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center;min-height:2.5rem;padding:.35rem .5rem;border:1px solid #cbd5e1;border-radius:.5rem}.input-shell.is-disabled[_ngcontent-%COMP%]{background:#f8fafc}input[_ngcontent-%COMP%]{min-width:6rem;flex:1;border:0;outline:0}.tag[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:.2rem;padding:.2rem .45rem;border-radius:999px;background:#dbeafe;color:#1d4ed8;font-size:.8rem}.tag[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:0;padding:0;background:transparent;color:inherit}small[_ngcontent-%COMP%]{color:#64748b;font-weight:400}.suggestions[_ngcontent-%COMP%]{position:absolute;z-index:2;top:4.2rem;right:0;left:0;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}.suggestions[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{padding:.5rem .65rem;cursor:pointer}.suggestions[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover{background:#eff6ff}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TagsInputComponent, [{
        type: Component,
        args: [{ selector: 'orc-tags-input', standalone: true, template: `
    <div class="orc-p2-tags-input">
      @if (label()) { <label>{{ label() }}</label> }
      <div class="input-shell" [class.is-disabled]="disabled()">
        @for (tag of value(); track $index) { <span class="tag">{{ tag }} <button type="button" [disabled]="disabled()" [attr.aria-label]="'Remove ' + tag" (click)="removeTag($index)">×</button></span> }
        <input [placeholder]="value().length ? '' : placeholder()" [disabled]="disabled()" [value]="draft()" (input)="draft.set(($any($event.target)).value)" (keydown)="onKeydown($event)" />
      </div>
      @if (suggestions().length && draft()) { <ul class="suggestions" role="listbox">@for (suggestion of filteredSuggestions(); track suggestion) { <li role="option" (mousedown)="$event.preventDefault()" (click)="addTag(suggestion)">{{ suggestion }}</li> }</ul> }
      @if (helperText()) { <small>{{ helperText() }}</small> }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => TagsInputComponent), multi: true }], styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tags-input{position:relative;display:grid;gap:.35rem;color:#0f172a}label{font-size:.875rem;font-weight:600}.input-shell{display:flex;flex-wrap:wrap;gap:.35rem;align-items:center;min-height:2.5rem;padding:.35rem .5rem;border:1px solid #cbd5e1;border-radius:.5rem}.input-shell.is-disabled{background:#f8fafc}input{min-width:6rem;flex:1;border:0;outline:0}.tag{display:inline-flex;align-items:center;gap:.2rem;padding:.2rem .45rem;border-radius:999px;background:#dbeafe;color:#1d4ed8;font-size:.8rem}.tag button{border:0;padding:0;background:transparent;color:inherit}small{color:#64748b;font-weight:400}.suggestions{position:absolute;z-index:2;top:4.2rem;right:0;left:0;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}.suggestions li{padding:.5rem .65rem;cursor:pointer}.suggestions li:hover{background:#eff6ff}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TagsInputComponent, { className: "TagsInputComponent", filePath: "p2-form-components.ts", lineNumber: 411 }); })();

const _c0$2 = ["*"];
function KbdComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const key_r1 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(key_r1);
} }
class ButtonGroupComponent {
    orientation = input('horizontal');
    attached = input(false, { transform: booleanAttribute });
    label = input('Button group');
    static ɵfac = function ButtonGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ButtonGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ButtonGroupComponent, selectors: [["orc-button-group"]], inputs: { orientation: [1, "orientation"], attached: [1, "attached"], label: [1, "label"] }, ngContentSelectors: _c0$2, decls: 2, vars: 5, consts: [["role", "group", 1, "orc-p2-button-group"]], template: function ButtonGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("vertical", ctx.orientation() === "vertical")("attached", ctx.attached());
            i0.ɵɵattribute("aria-label", ctx.label());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-button-group[_ngcontent-%COMP%]{display:inline-flex;gap:.5rem;align-items:center}.orc-p2-button-group.vertical[_ngcontent-%COMP%]{flex-direction:column;align-items:stretch}.orc-p2-button-group.attached[_ngcontent-%COMP%]{gap:0}.orc-p2-button-group.attached[_ngcontent-%COMP%]     button{border-radius:0}.orc-p2-button-group.attached[_ngcontent-%COMP%]     button:first-child{border-radius:.5rem 0 0 .5rem}.orc-p2-button-group.attached[_ngcontent-%COMP%]     button:last-child{border-radius:0 .5rem .5rem 0}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ButtonGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-button-group', standalone: true, template: `<div class="orc-p2-button-group" [class.vertical]="orientation() === 'vertical'" [class.attached]="attached()" role="group" [attr.aria-label]="label()"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-button-group{display:inline-flex;gap:.5rem;align-items:center}.orc-p2-button-group.vertical{flex-direction:column;align-items:stretch}.orc-p2-button-group.attached{gap:0}.orc-p2-button-group.attached ::ng-deep button{border-radius:0}.orc-p2-button-group.attached ::ng-deep button:first-child{border-radius:.5rem 0 0 .5rem}.orc-p2-button-group.attached ::ng-deep button:last-child{border-radius:0 .5rem .5rem 0}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ButtonGroupComponent, { className: "ButtonGroupComponent", filePath: "p2-layout-components.ts", lineNumber: 11 }); })();
class GridComponent {
    columns = input(0);
    minColumnWidth = input('12rem');
    gap = input('1rem');
    alignItems = input('stretch');
    label = input('');
    columnsStyle = computed(() => this.columns() > 0 ? `repeat(${this.columns()}, minmax(0, 1fr))` : `repeat(auto-fit, minmax(${this.minColumnWidth()}, 1fr))`);
    static ɵfac = function GridComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GridComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GridComponent, selectors: [["orc-grid"]], inputs: { columns: [1, "columns"], minColumnWidth: [1, "minColumnWidth"], gap: [1, "gap"], alignItems: [1, "alignItems"], label: [1, "label"] }, ngContentSelectors: _c0$2, decls: 2, vars: 7, consts: [[1, "orc-p2-grid"]], template: function GridComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("grid-template-columns", ctx.columnsStyle())("gap", ctx.gap())("align-items", ctx.alignItems());
            i0.ɵɵattribute("aria-label", ctx.label() || null);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-grid[_ngcontent-%COMP%]{display:grid;width:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GridComponent, [{
        type: Component,
        args: [{ selector: 'orc-grid', standalone: true, template: `<div class="orc-p2-grid" [style.grid-template-columns]="columnsStyle()" [style.gap]="gap()" [style.align-items]="alignItems()" [attr.aria-label]="label() || null"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-grid{display:grid;width:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GridComponent, { className: "GridComponent", filePath: "p2-layout-components.ts", lineNumber: 24 }); })();
class AspectRatioComponent {
    ratio = input('16 / 9');
    overflow = input('hidden');
    static ɵfac = function AspectRatioComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AspectRatioComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AspectRatioComponent, selectors: [["orc-aspect-ratio"]], inputs: { ratio: [1, "ratio"], overflow: [1, "overflow"] }, ngContentSelectors: _c0$2, decls: 2, vars: 4, consts: [[1, "orc-p2-aspect-ratio"]], template: function AspectRatioComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("aspect-ratio", ctx.ratio())("overflow", ctx.overflow());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-aspect-ratio[_ngcontent-%COMP%]{position:relative;width:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AspectRatioComponent, [{
        type: Component,
        args: [{ selector: 'orc-aspect-ratio', standalone: true, template: `<div class="orc-p2-aspect-ratio" [style.aspect-ratio]="ratio()" [style.overflow]="overflow()"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-aspect-ratio{position:relative;width:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AspectRatioComponent, { className: "AspectRatioComponent", filePath: "p2-layout-components.ts", lineNumber: 40 }); })();
class ContainerComponent {
    maxWidth = input('72rem');
    padding = input('1rem');
    fluid = input(false, { transform: booleanAttribute });
    static ɵfac = function ContainerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ContainerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ContainerComponent, selectors: [["orc-container"]], inputs: { maxWidth: [1, "maxWidth"], padding: [1, "padding"], fluid: [1, "fluid"] }, ngContentSelectors: _c0$2, decls: 2, vars: 6, consts: [[1, "orc-p2-container"]], template: function ContainerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("max-width", ctx.fluid() ? null : ctx.maxWidth())("padding-inline", ctx.padding());
            i0.ɵɵclassProp("fluid", ctx.fluid());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-container[_ngcontent-%COMP%]{width:100%;margin-inline:auto}.orc-p2-container[_ngcontent-%COMP%]:not(.fluid){box-sizing:border-box}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ContainerComponent, [{
        type: Component,
        args: [{ selector: 'orc-container', standalone: true, template: `<div class="orc-p2-container" [class.fluid]="fluid()" [style.max-width]="fluid() ? null : maxWidth()" [style.padding-inline]="padding()"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-container{width:100%;margin-inline:auto}.orc-p2-container:not(.fluid){box-sizing:border-box}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ContainerComponent, { className: "ContainerComponent", filePath: "p2-layout-components.ts", lineNumber: 52 }); })();
class FlexComponent {
    direction = input('row');
    gap = input('1rem');
    align = input('stretch');
    justify = input('start');
    wrap = input(false, { transform: booleanAttribute });
    static ɵfac = function FlexComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FlexComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FlexComponent, selectors: [["orc-flex"]], inputs: { direction: [1, "direction"], gap: [1, "gap"], align: [1, "align"], justify: [1, "justify"], wrap: [1, "wrap"] }, ngContentSelectors: _c0$2, decls: 2, vars: 10, consts: [[1, "orc-p2-flex"]], template: function FlexComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("flex-direction", ctx.direction())("gap", ctx.gap())("align-items", ctx.align())("justify-content", ctx.justify())("flex-wrap", ctx.wrap() ? "wrap" : "nowrap");
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-flex[_ngcontent-%COMP%]{display:flex;width:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FlexComponent, [{
        type: Component,
        args: [{ selector: 'orc-flex', standalone: true, template: `<div class="orc-p2-flex" [style.flex-direction]="direction()" [style.gap]="gap()" [style.align-items]="align()" [style.justify-content]="justify()" [style.flex-wrap]="wrap() ? 'wrap' : 'nowrap'"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-flex{display:flex;width:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FlexComponent, { className: "FlexComponent", filePath: "p2-layout-components.ts", lineNumber: 65 }); })();
class StackComponent {
    direction = input('column');
    gap = input('1rem');
    align = input('stretch');
    justify = input('start');
    static ɵfac = function StackComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StackComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StackComponent, selectors: [["orc-stack"]], inputs: { direction: [1, "direction"], gap: [1, "gap"], align: [1, "align"], justify: [1, "justify"] }, ngContentSelectors: _c0$2, decls: 2, vars: 8, consts: [[1, "orc-p2-stack"]], template: function StackComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("flex-direction", ctx.direction())("gap", ctx.gap())("align-items", ctx.align())("justify-content", ctx.justify());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-stack[_ngcontent-%COMP%]{display:flex;width:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StackComponent, [{
        type: Component,
        args: [{ selector: 'orc-stack', standalone: true, template: `<div class="orc-p2-stack" [style.flex-direction]="direction()" [style.gap]="gap()" [style.align-items]="align()" [style.justify-content]="justify()"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-stack{display:flex;width:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StackComponent, { className: "StackComponent", filePath: "p2-layout-components.ts", lineNumber: 80 }); })();
class SpaceComponent {
    size = input('1rem');
    direction = input('row');
    wrap = input(false, { transform: booleanAttribute });
    static ɵfac = function SpaceComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SpaceComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SpaceComponent, selectors: [["orc-space"]], inputs: { size: [1, "size"], direction: [1, "direction"], wrap: [1, "wrap"] }, ngContentSelectors: _c0$2, decls: 2, vars: 6, consts: [[1, "orc-p2-space"]], template: function SpaceComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("flex-direction", ctx.direction())("gap", ctx.size())("flex-wrap", ctx.wrap() ? "wrap" : "nowrap");
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-space[_ngcontent-%COMP%]{display:flex;align-items:center}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SpaceComponent, [{
        type: Component,
        args: [{ selector: 'orc-space', standalone: true, template: `<div class="orc-p2-space" [style.flex-direction]="direction()" [style.gap]="size()" [style.flex-wrap]="wrap() ? 'wrap' : 'nowrap'"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-space{display:flex;align-items:center}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SpaceComponent, { className: "SpaceComponent", filePath: "p2-layout-components.ts", lineNumber: 94 }); })();
class BoxComponent {
    padding = input('0');
    margin = input('0');
    background = input('');
    radius = input('.5rem');
    width = input('');
    static ɵfac = function BoxComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || BoxComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: BoxComponent, selectors: [["orc-box"]], inputs: { padding: [1, "padding"], margin: [1, "margin"], background: [1, "background"], radius: [1, "radius"], width: [1, "width"] }, ngContentSelectors: _c0$2, decls: 2, vars: 10, consts: [[1, "orc-p2-box"]], template: function BoxComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("padding", ctx.padding())("margin", ctx.margin())("background", ctx.background() || null)("border-radius", ctx.radius())("width", ctx.width() || null);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-box[_ngcontent-%COMP%]{width:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(BoxComponent, [{
        type: Component,
        args: [{ selector: 'orc-box', standalone: true, template: `<div class="orc-p2-box" [style.padding]="padding()" [style.margin]="margin()" [style.background]="background() || null" [style.border-radius]="radius()" [style.width]="width() || null"><ng-content /></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-box{width:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(BoxComponent, { className: "BoxComponent", filePath: "p2-layout-components.ts", lineNumber: 107 }); })();
class SeparatorComponent {
    orientation = input('horizontal');
    label = input('');
    static ɵfac = function SeparatorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SeparatorComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SeparatorComponent, selectors: [["orc-separator"]], inputs: { orientation: [1, "orientation"], label: [1, "label"] }, decls: 1, vars: 4, consts: [["role", "separator", 1, "orc-p2-separator"]], template: function SeparatorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelement(0, "div", 0);
        } if (rf & 2) {
            i0.ɵɵclassProp("vertical", ctx.orientation() === "vertical");
            i0.ɵɵattribute("aria-orientation", ctx.orientation())("aria-label", ctx.label() || null);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-separator[_ngcontent-%COMP%]{width:100%;height:1px;background:#cbd5e1}.orc-p2-separator.vertical[_ngcontent-%COMP%]{width:1px;height:100%;min-height:1rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SeparatorComponent, [{
        type: Component,
        args: [{ selector: 'orc-separator', standalone: true, template: `<div class="orc-p2-separator" [class.vertical]="orientation() === 'vertical'" role="separator" [attr.aria-orientation]="orientation()" [attr.aria-label]="label() || null"></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-separator{width:100%;height:1px;background:#cbd5e1}.orc-p2-separator.vertical{width:1px;height:100%;min-height:1rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SeparatorComponent, { className: "SeparatorComponent", filePath: "p2-layout-components.ts", lineNumber: 122 }); })();
class VisuallyHiddenComponent {
    static ɵfac = function VisuallyHiddenComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || VisuallyHiddenComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: VisuallyHiddenComponent, selectors: [["orc-visually-hidden"]], ngContentSelectors: _c0$2, decls: 2, vars: 0, consts: [[1, "orc-p2-visually-hidden"]], template: function VisuallyHiddenComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "span", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-visually-hidden[_ngcontent-%COMP%]{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(VisuallyHiddenComponent, [{
        type: Component,
        args: [{ selector: 'orc-visually-hidden', standalone: true, template: `<span class="orc-p2-visually-hidden"><ng-content /></span>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-visually-hidden{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(VisuallyHiddenComponent, { className: "VisuallyHiddenComponent", filePath: "p2-layout-components.ts", lineNumber: 134 }); })();
class TypographyComponent {
    as = input('span');
    size = input('md');
    weight = input(400);
    color = input('');
    truncate = input(false, { transform: booleanAttribute });
    static ɵfac = function TypographyComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TypographyComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TypographyComponent, selectors: [["orc-typography"]], inputs: { as: [1, "as"], size: [1, "size"], weight: [1, "weight"], color: [1, "color"], truncate: [1, "truncate"] }, ngContentSelectors: _c0$2, decls: 2, vars: 8, consts: [[1, "orc-p2-typography"]], template: function TypographyComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "span", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap("orc-p2-typography orc-p2-typography--" + ctx.size());
            i0.ɵɵstyleProp("font-weight", ctx.weight())("color", ctx.color() || null);
            i0.ɵɵclassProp("truncate", ctx.truncate());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-typography[_ngcontent-%COMP%]{display:inline;line-height:1.5}.orc-p2-typography--xs[_ngcontent-%COMP%]{font-size:.75rem}.orc-p2-typography--sm[_ngcontent-%COMP%]{font-size:.875rem}.orc-p2-typography--md[_ngcontent-%COMP%]{font-size:1rem}.orc-p2-typography--lg[_ngcontent-%COMP%]{font-size:1.25rem}.orc-p2-typography--xl[_ngcontent-%COMP%]{font-size:1.75rem}.truncate[_ngcontent-%COMP%]{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TypographyComponent, [{
        type: Component,
        args: [{ selector: 'orc-typography', standalone: true, template: `<span class="orc-p2-typography" [class]="'orc-p2-typography orc-p2-typography--' + size()" [style.font-weight]="weight()" [style.color]="color() || null" [class.truncate]="truncate()"><ng-content /></span>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-typography{display:inline;line-height:1.5}.orc-p2-typography--xs{font-size:.75rem}.orc-p2-typography--sm{font-size:.875rem}.orc-p2-typography--md{font-size:1rem}.orc-p2-typography--lg{font-size:1.25rem}.orc-p2-typography--xl{font-size:1.75rem}.truncate{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TypographyComponent, { className: "TypographyComponent", filePath: "p2-layout-components.ts", lineNumber: 143 }); })();
class TextComponent {
    size = input('md');
    muted = input(false, { transform: booleanAttribute });
    truncate = input(false, { transform: booleanAttribute });
    static ɵfac = function TextComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TextComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TextComponent, selectors: [["orc-text"]], inputs: { size: [1, "size"], muted: [1, "muted"], truncate: [1, "truncate"] }, ngContentSelectors: _c0$2, decls: 2, vars: 4, consts: [["[class", "'orc-p2-text orc-p2-text--' + size()", 1, "orc-p2-text"]], template: function TextComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "span", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("muted", ctx.muted())("truncate", ctx.truncate());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-text[_ngcontent-%COMP%]{color:#0f172a}.orc-p2-text--sm[_ngcontent-%COMP%]{font-size:.875rem}.orc-p2-text--md[_ngcontent-%COMP%]{font-size:1rem}.orc-p2-text--lg[_ngcontent-%COMP%]{font-size:1.25rem}.muted[_ngcontent-%COMP%]{color:#64748b}.truncate[_ngcontent-%COMP%]{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TextComponent, [{
        type: Component,
        args: [{ selector: 'orc-text', standalone: true, template: `<span class="orc-p2-text" [class.muted]="muted()" [class.truncate]="truncate()" [class="'orc-p2-text orc-p2-text--' + size()"><ng-content /></span>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-text{color:#0f172a}.orc-p2-text--sm{font-size:.875rem}.orc-p2-text--md{font-size:1rem}.orc-p2-text--lg{font-size:1.25rem}.muted{color:#64748b}.truncate{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TextComponent, { className: "TextComponent", filePath: "p2-layout-components.ts", lineNumber: 158 }); })();
class KbdComponent {
    keys = input('⌘ K');
    ariaLabel = input('');
    normalizedKeys = computed(() => {
        const keys = this.keys();
        return Array.isArray(keys) ? keys : keys.split(/\s*\+\s*/);
    });
    static ɵfac = function KbdComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || KbdComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: KbdComponent, selectors: [["orc-kbd"]], inputs: { keys: [1, "keys"], ariaLabel: [1, "ariaLabel"] }, decls: 3, vars: 1, consts: [[1, "orc-p2-kbd"]], template: function KbdComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "kbd", 0);
            i0.ɵɵrepeaterCreate(1, KbdComponent_For_2_Template, 2, 1, "span", null, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.normalizedKeys());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-kbd[_ngcontent-%COMP%]{display:inline-flex;gap:.2rem;align-items:center;padding:.15rem .35rem;border:1px solid #cbd5e1;border-bottom-width:2px;border-radius:.3rem;background:#f8fafc;color:#334155;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.75rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KbdComponent, [{
        type: Component,
        args: [{ selector: 'orc-kbd', standalone: true, template: `<kbd class="orc-p2-kbd" [attr.aria-label]="ariaLabel() || null">@for (key of normalizedKeys(); track $index) { <span>{{ key }}</span> }</kbd>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-kbd{display:inline-flex;gap:.2rem;align-items:center;padding:.15rem .35rem;border:1px solid #cbd5e1;border-bottom-width:2px;border-radius:.3rem;background:#f8fafc;color:#334155;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.75rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(KbdComponent, { className: "KbdComponent", filePath: "p2-layout-components.ts", lineNumber: 171 }); })();
class LinkComponent {
    href = input('#');
    target = input('');
    ariaLabel = input('');
    underline = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    activated = output();
    onClick(event) { if (this.disabled()) {
        event.preventDefault();
        return;
    } this.activated.emit(event); }
    static ɵfac = function LinkComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || LinkComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LinkComponent, selectors: [["orc-link"]], inputs: { href: [1, "href"], target: [1, "target"], ariaLabel: [1, "ariaLabel"], underline: [1, "underline"], disabled: [1, "disabled"] }, outputs: { activated: "activated" }, ngContentSelectors: _c0$2, decls: 2, vars: 9, consts: [[1, "orc-p2-link", 3, "click", "href", "target", "rel"]], template: function LinkComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "a", 0);
            i0.ɵɵlistener("click", function LinkComponent_Template_a_click_0_listener($event) { return ctx.onClick($event); });
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("disabled", ctx.disabled())("underline", ctx.underline());
            i0.ɵɵproperty("href", ctx.disabled() ? null : ctx.href(), i0.ɵɵsanitizeUrl)("target", ctx.target() || null)("rel", ctx.target() === "_blank" ? "noopener noreferrer" : null);
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-disabled", ctx.disabled());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-link[_ngcontent-%COMP%]{color:#2563eb;text-decoration:none}.orc-p2-link.underline[_ngcontent-%COMP%], .orc-p2-link[_ngcontent-%COMP%]:hover{text-decoration:underline}.orc-p2-link.disabled[_ngcontent-%COMP%]{pointer-events:none;color:#94a3b8}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LinkComponent, [{
        type: Component,
        args: [{ selector: 'orc-link', standalone: true, template: `<a class="orc-p2-link" [href]="disabled() ? null : href()" [target]="target() || null" [rel]="target() === '_blank' ? 'noopener noreferrer' : null" [class.disabled]="disabled()" [class.underline]="underline()" [attr.aria-label]="ariaLabel() || null" [attr.aria-disabled]="disabled()" (click)="onClick($event)"><ng-content /></a>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-link{color:#2563eb;text-decoration:none}.orc-p2-link.underline,.orc-p2-link:hover{text-decoration:underline}.orc-p2-link.disabled{pointer-events:none;color:#94a3b8}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(LinkComponent, { className: "LinkComponent", filePath: "p2-layout-components.ts", lineNumber: 187 }); })();

const _forTrack0$2 = ($index, $item) => $item.value;
function MenubarComponent_For_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.shortcut);
} }
function MenubarComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 2);
    i0.ɵɵlistener("click", function MenubarComponent_For_2_Template_button_click_0_listener() { const item_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.activate(item_r2)); });
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, MenubarComponent_For_2_Conditional_2_Template, 2, 1, "small");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const $index_r4 = ctx.$index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("is-active", $index_r4 === ctx_r2.activeIndex());
    i0.ɵɵproperty("disabled", item_r2.disabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2("", item_r2.icon, " ", item_r2.label, " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.shortcut ? 2 : -1);
} }
function TagComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 2);
    i0.ɵɵlistener("click", function TagComponent_Conditional_3_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.remove($event)); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.disabled());
    i0.ɵɵattribute("aria-label", "Remove " + ctx_r1.label());
} }
const _c0$1 = [[["", "hover-card-trigger", ""]], "*"];
const _c1 = ["[hover-card-trigger]", "*"];
function HoverCardComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-label", ctx_r0.label());
} }
const _forTrack1$2 = ($index, $item) => $item.key;
function _forTrack2($index, $item) { return this.getRowId($item); }
function DataTableComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "th", 2)(1, "input", 4);
    i0.ɵɵlistener("change", function DataTableComponent_Conditional_6_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggleAll($event.target.checked)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r1.allSelected())("indeterminate", ctx_r1.someSelected());
} }
function DataTableComponent_For_8_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "th", 5);
    i0.ɵɵlistener("click", function DataTableComponent_For_8_Template_th_click_0_listener() { const column_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.sortBy(column_r4)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const column_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("sortable", column_r4.sortable);
    i0.ɵɵattribute("aria-sort", ctx_r1.sortKey() === column_r4.key ? ctx_r1.sortDirection() : null);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(column_r4.header);
} }
function DataTableComponent_Conditional_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr")(1, "td", 6);
    i0.ɵɵtext(2, "Loading\u2026");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵattribute("colspan", ctx_r1.columns().length + (ctx_r1.selectable() ? 1 : 0));
} }
function DataTableComponent_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr")(1, "td", 6);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵattribute("colspan", ctx_r1.columns().length + (ctx_r1.selectable() ? 1 : 0));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.emptyText());
} }
function DataTableComponent_Conditional_12_For_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 8);
    i0.ɵɵlistener("click", function DataTableComponent_Conditional_12_For_1_Conditional_1_Template_td_click_0_listener($event) { i0.ɵɵrestoreView(_r7); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(1, "input", 9);
    i0.ɵɵlistener("change", function DataTableComponent_Conditional_12_For_1_Conditional_1_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r7); const row_r6 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.toggleRow(row_r6, $event.target.checked)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const row_r6 = i0.ɵɵnextContext().$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r1.isSelected(row_r6));
    i0.ɵɵattribute("aria-label", "Select row " + ctx_r1.getRowId(row_r6));
} }
function DataTableComponent_Conditional_12_For_1_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const column_r8 = ctx.$implicit;
    const row_r6 = i0.ɵɵnextContext().$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.getCell(row_r6, column_r8.key));
} }
function DataTableComponent_Conditional_12_For_1_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "tr", 8);
    i0.ɵɵlistener("click", function DataTableComponent_Conditional_12_For_1_Template_tr_click_0_listener() { const row_r6 = i0.ɵɵrestoreView(_r5).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.rowClick.emit(row_r6)); });
    i0.ɵɵtemplate(1, DataTableComponent_Conditional_12_For_1_Conditional_1_Template, 2, 2, "td");
    i0.ɵɵrepeaterCreate(2, DataTableComponent_Conditional_12_For_1_For_3_Template, 2, 1, "td", null, _forTrack1$2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r6 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("selected", ctx_r1.isSelected(row_r6));
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.selectable() ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.columns());
} }
function DataTableComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, DataTableComponent_Conditional_12_For_1_Template, 4, 3, "tr", 7, _forTrack2, true);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r1.rows());
} }
const _c2 = ["*"];
function EmptyStateComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description());
} }
function EmptyStateComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 3);
    i0.ɵɵlistener("click", function EmptyStateComponent_Conditional_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.action.emit()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.actionLabel());
} }
function VirtualScrollerComponent_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("height", ctx_r1.itemHeight(), "px");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.itemLabel(item_r1));
} }
class CodeComponent {
    code = input('');
    language = input('text');
    copyLabel = input('Copy');
    copiedLabel = input('Copied');
    copied = signal(false);
    copiedEvent = output();
    async copy() {
        if (typeof navigator !== 'undefined' && navigator.clipboard)
            await navigator.clipboard.writeText(this.code());
        this.copied.set(true);
        this.copiedEvent.emit(this.code());
        setTimeout(() => this.copied.set(false), 1200);
    }
    static ɵfac = function CodeComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CodeComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CodeComponent, selectors: [["orc-code"]], inputs: { code: [1, "code"], language: [1, "language"], copyLabel: [1, "copyLabel"], copiedLabel: [1, "copiedLabel"] }, outputs: { copiedEvent: "copiedEvent" }, decls: 9, vars: 3, consts: [[1, "orc-p2-code"], [1, "toolbar"], ["type", "button", 3, "click"]], template: function CodeComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "span");
            i0.ɵɵtext(3);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "button", 2);
            i0.ɵɵlistener("click", function CodeComponent_Template_button_click_4_listener() { return ctx.copy(); });
            i0.ɵɵtext(5);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "pre")(7, "code");
            i0.ɵɵtext(8);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(ctx.language());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.copied() ? ctx.copiedLabel() : ctx.copyLabel());
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(ctx.code());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-code[_ngcontent-%COMP%]{overflow:hidden;border:1px solid #1e293b;border-radius:.75rem;background:#0f172a;color:#e2e8f0}.toolbar[_ngcontent-%COMP%]{display:flex;justify-content:space-between;padding:.45rem .7rem;border-bottom:1px solid #334155;color:#94a3b8;font-size:.75rem}.toolbar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:0;border-radius:.35rem;background:#1e293b;color:#e2e8f0;padding:.25rem .5rem}pre[_ngcontent-%COMP%]{margin:0;overflow:auto;padding:1rem}code[_ngcontent-%COMP%]{font:.82rem/1.6 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CodeComponent, [{
        type: Component,
        args: [{ selector: 'orc-code', standalone: true, template: `<div class="orc-p2-code"><div class="toolbar"><span>{{ language() }}</span><button type="button" (click)="copy()">{{ copied() ? copiedLabel() : copyLabel() }}</button></div><pre><code>{{ code() }}</code></pre></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-code{overflow:hidden;border:1px solid #1e293b;border-radius:.75rem;background:#0f172a;color:#e2e8f0}.toolbar{display:flex;justify-content:space-between;padding:.45rem .7rem;border-bottom:1px solid #334155;color:#94a3b8;font-size:.75rem}.toolbar button{border:0;border-radius:.35rem;background:#1e293b;color:#e2e8f0;padding:.25rem .5rem}pre{margin:0;overflow:auto;padding:1rem}code{font:.82rem/1.6 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CodeComponent, { className: "CodeComponent", filePath: "p2-data-components.ts", lineNumber: 11 }); })();
class MenubarComponent {
    items = input([]);
    label = input('Main menu');
    loop = input(true, { transform: booleanAttribute });
    activeIndex = signal(0);
    itemSelect = output();
    activate(item) { if (!item.disabled)
        this.itemSelect.emit(item); }
    onKeydown(event) {
        const count = this.items().length;
        if (!count)
            return;
        if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
            event.preventDefault();
            const delta = event.key === 'ArrowRight' ? 1 : -1;
            this.activeIndex.update(index => this.loop() ? (index + delta + count) % count : Math.max(0, Math.min(count - 1, index + delta)));
        }
        else if (event.key === 'Home') {
            event.preventDefault();
            this.activeIndex.set(0);
        }
        else if (event.key === 'End') {
            event.preventDefault();
            this.activeIndex.set(count - 1);
        }
        else if (event.key === 'Enter' || event.key === ' ') {
            const item = this.items()[this.activeIndex()];
            if (item)
                this.activate(item);
        }
    }
    static ɵfac = function MenubarComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || MenubarComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MenubarComponent, selectors: [["orc-menubar"]], inputs: { items: [1, "items"], label: [1, "label"], loop: [1, "loop"] }, outputs: { itemSelect: "itemSelect" }, decls: 3, vars: 1, consts: [["role", "menubar", 1, "orc-p2-menubar", 3, "keydown"], ["type", "button", "role", "menuitem", 3, "disabled", "is-active"], ["type", "button", "role", "menuitem", 3, "click", "disabled"]], template: function MenubarComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "nav", 0);
            i0.ɵɵlistener("keydown", function MenubarComponent_Template_nav_keydown_0_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵrepeaterCreate(1, MenubarComponent_For_2_Template, 3, 6, "button", 1, _forTrack0$2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.items());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-menubar[_ngcontent-%COMP%]{display:flex;gap:.2rem;align-items:center;padding:.25rem;border:1px solid #e2e8f0;border-radius:.6rem;background:#fff}.orc-p2-menubar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;gap:.5rem;align-items:center;border:0;border-radius:.4rem;background:transparent;color:#0f172a;padding:.5rem .7rem}.orc-p2-menubar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover, .orc-p2-menubar[_ngcontent-%COMP%]   button.is-active[_ngcontent-%COMP%]{background:#eff6ff;color:#1d4ed8}.orc-p2-menubar[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{margin-left:.5rem;color:#64748b}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MenubarComponent, [{
        type: Component,
        args: [{ selector: 'orc-menubar', standalone: true, template: `<nav class="orc-p2-menubar" role="menubar" [attr.aria-label]="label()" (keydown)="onKeydown($event)">@for (item of items(); track item.value) { <button type="button" role="menuitem" [disabled]="item.disabled" [class.is-active]="$index === activeIndex()" (click)="activate(item)">{{ item.icon }} {{ item.label }} @if (item.shortcut) { <small>{{ item.shortcut }}</small> }</button> }</nav>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-menubar{display:flex;gap:.2rem;align-items:center;padding:.25rem;border:1px solid #e2e8f0;border-radius:.6rem;background:#fff}.orc-p2-menubar button{display:inline-flex;gap:.5rem;align-items:center;border:0;border-radius:.4rem;background:transparent;color:#0f172a;padding:.5rem .7rem}.orc-p2-menubar button:hover,.orc-p2-menubar button.is-active{background:#eff6ff;color:#1d4ed8}.orc-p2-menubar small{margin-left:.5rem;color:#64748b}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(MenubarComponent, { className: "MenubarComponent", filePath: "p2-data-components.ts", lineNumber: 38 }); })();
class TagComponent {
    label = input('Tag');
    variant = input('neutral');
    removable = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    removed = output();
    remove(event) { event.stopPropagation(); if (!this.disabled())
        this.removed.emit(this.label()); }
    static ɵfac = function TagComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TagComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TagComponent, selectors: [["orc-tag"]], inputs: { label: [1, "label"], variant: [1, "variant"], removable: [1, "removable"], disabled: [1, "disabled"] }, outputs: { removed: "removed" }, decls: 4, vars: 7, consts: [[1, "orc-p2-tag"], ["type", "button", 3, "disabled"], ["type", "button", 3, "click", "disabled"]], template: function TagComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "span", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, TagComponent_Conditional_3_Template, 2, 2, "button", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap("orc-p2-tag orc-p2-tag--" + ctx.variant());
            i0.ɵɵclassProp("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-disabled", ctx.disabled());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.removable() ? 3 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tag[_ngcontent-%COMP%]{display:inline-flex;gap:.3rem;align-items:center;min-height:1.6rem;padding:.2rem .55rem;border-radius:.35rem;font-size:.8rem;font-weight:600}.orc-p2-tag--neutral[_ngcontent-%COMP%]{background:#f1f5f9;color:#334155}.orc-p2-tag--primary[_ngcontent-%COMP%]{background:#dbeafe;color:#1d4ed8}.orc-p2-tag--success[_ngcontent-%COMP%]{background:#dcfce7;color:#166534}.orc-p2-tag--warning[_ngcontent-%COMP%]{background:#fef3c7;color:#92400e}.orc-p2-tag--danger[_ngcontent-%COMP%]{background:#fee2e2;color:#991b1b}.orc-p2-tag[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:0;padding:0;background:transparent;color:inherit;font-size:1rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TagComponent, [{
        type: Component,
        args: [{ selector: 'orc-tag', standalone: true, template: `<span class="orc-p2-tag" [class]="'orc-p2-tag orc-p2-tag--' + variant()" [class.disabled]="disabled()" [attr.aria-disabled]="disabled()"><span>{{ label() }}</span>@if (removable()) { <button type="button" [disabled]="disabled()" [attr.aria-label]="'Remove ' + label()" (click)="remove($event)">×</button> }</span>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tag{display:inline-flex;gap:.3rem;align-items:center;min-height:1.6rem;padding:.2rem .55rem;border-radius:.35rem;font-size:.8rem;font-weight:600}.orc-p2-tag--neutral{background:#f1f5f9;color:#334155}.orc-p2-tag--primary{background:#dbeafe;color:#1d4ed8}.orc-p2-tag--success{background:#dcfce7;color:#166534}.orc-p2-tag--warning{background:#fef3c7;color:#92400e}.orc-p2-tag--danger{background:#fee2e2;color:#991b1b}.orc-p2-tag button{border:0;padding:0;background:transparent;color:inherit;font-size:1rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TagComponent, { className: "TagComponent", filePath: "p2-data-components.ts", lineNumber: 67 }); })();
class HoverCardComponent {
    open = model(false);
    label = input('Details');
    openCard() { this.open.set(true); }
    closeCard() { this.open.set(false); }
    static ɵfac = function HoverCardComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || HoverCardComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: HoverCardComponent, selectors: [["orc-hover-card"]], inputs: { open: [1, "open"], label: [1, "label"] }, outputs: { open: "openChange" }, ngContentSelectors: _c1, decls: 4, vars: 1, consts: [[1, "orc-p2-hover-card", 3, "mouseenter", "mouseleave", "focusin", "focusout"], [1, "trigger"], ["role", "dialog", 1, "content"]], template: function HoverCardComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0$1);
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("mouseenter", function HoverCardComponent_Template_div_mouseenter_0_listener() { return ctx.openCard(); })("mouseleave", function HoverCardComponent_Template_div_mouseleave_0_listener() { return ctx.closeCard(); })("focusin", function HoverCardComponent_Template_div_focusin_0_listener() { return ctx.openCard(); })("focusout", function HoverCardComponent_Template_div_focusout_0_listener() { return ctx.closeCard(); });
            i0.ɵɵelementStart(1, "span", 1);
            i0.ɵɵprojection(2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, HoverCardComponent_Conditional_3_Template, 2, 1, "div", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.open() ? 3 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-hover-card[_ngcontent-%COMP%]{position:relative;display:inline-block}.trigger[_ngcontent-%COMP%]{display:inline-block}.content[_ngcontent-%COMP%]{position:absolute;z-index:3;top:calc(100% + .5rem);left:0;width:min(20rem,80vw);padding:.75rem;border:1px solid #cbd5e1;border-radius:.65rem;background:#fff;box-shadow:0 12px 28px #0f172a1f;color:#0f172a}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HoverCardComponent, [{
        type: Component,
        args: [{ selector: 'orc-hover-card', standalone: true, template: `<div class="orc-p2-hover-card" (mouseenter)="openCard()" (mouseleave)="closeCard()" (focusin)="openCard()" (focusout)="closeCard()"><span class="trigger"><ng-content select="[hover-card-trigger]" /></span>@if (open()) { <div class="content" role="dialog" [attr.aria-label]="label()"><ng-content /></div> }</div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-hover-card{position:relative;display:inline-block}.trigger{display:inline-block}.content{position:absolute;z-index:3;top:calc(100% + .5rem);left:0;width:min(20rem,80vw);padding:.75rem;border:1px solid #cbd5e1;border-radius:.65rem;background:#fff;box-shadow:0 12px 28px #0f172a1f;color:#0f172a}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(HoverCardComponent, { className: "HoverCardComponent", filePath: "p2-data-components.ts", lineNumber: 83 }); })();
class DataTableComponent {
    data = input([]);
    columns = input([]);
    rowKey = input('id');
    label = input('Data table');
    emptyText = input('No data');
    loading = input(false, { transform: booleanAttribute });
    selectable = input(false, { transform: booleanAttribute });
    selected = model([]);
    sortKey = signal('');
    sortDirection = signal('ascending');
    rowClick = output();
    selectionChange = output();
    sortChange = output();
    rows = computed(() => {
        const key = this.sortKey();
        const direction = this.sortDirection();
        const result = [...this.data()];
        if (!key)
            return result;
        return result.sort((a, b) => {
            const left = a[key];
            const right = b[key];
            const compare = String(left ?? '').localeCompare(String(right ?? ''), undefined, { numeric: true, sensitivity: 'base' });
            return direction === 'ascending' ? compare : -compare;
        });
    });
    allSelected = computed(() => !!this.rows().length && this.rows().every(row => this.isSelected(row)));
    someSelected = computed(() => this.rows().some(row => this.isSelected(row)) && !this.allSelected());
    getRowId(row) { return String(row[this.rowKey()] ?? JSON.stringify(row)); }
    getCell(row, key) { return row[key] ?? ''; }
    isSelected(row) { return this.selected().some(item => this.getRowId(item) === this.getRowId(row)); }
    toggleRow(row, checked) {
        const next = this.selected().filter(item => this.getRowId(item) !== this.getRowId(row));
        if (checked)
            next.push(row);
        this.selected.set(next);
        this.selectionChange.emit(next);
    }
    toggleAll(checked) { const next = checked ? [...this.rows()] : []; this.selected.set(next); this.selectionChange.emit(next); }
    sortBy(column) {
        if (!column.sortable)
            return;
        const direction = this.sortKey() === column.key && this.sortDirection() === 'ascending' ? 'descending' : 'ascending';
        this.sortKey.set(column.key);
        this.sortDirection.set(direction);
        this.sortChange.emit({ key: column.key, direction });
    }
    static ɵfac = function DataTableComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DataTableComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataTableComponent, selectors: [["orc-data-table"]], inputs: { data: [1, "data"], columns: [1, "columns"], rowKey: [1, "rowKey"], label: [1, "label"], emptyText: [1, "emptyText"], loading: [1, "loading"], selectable: [1, "selectable"], selected: [1, "selected"] }, outputs: { selected: "selectedChange", rowClick: "rowClick", selectionChange: "selectionChange", sortChange: "sortChange" }, decls: 13, vars: 4, consts: [[1, "orc-p2-data-table"], [1, "sr-only"], ["scope", "col"], ["scope", "col", 3, "sortable"], ["type", "checkbox", "aria-label", "Select all", 3, "change", "checked", "indeterminate"], ["scope", "col", 3, "click"], [1, "empty"], [3, "selected"], [3, "click"], ["type", "checkbox", 3, "change", "checked"]], template: function DataTableComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "table")(2, "caption", 1);
            i0.ɵɵtext(3);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "thead")(5, "tr");
            i0.ɵɵtemplate(6, DataTableComponent_Conditional_6_Template, 2, 2, "th", 2);
            i0.ɵɵrepeaterCreate(7, DataTableComponent_For_8_Template, 2, 4, "th", 3, _forTrack1$2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(9, "tbody");
            i0.ɵɵtemplate(10, DataTableComponent_Conditional_10_Template, 3, 1, "tr")(11, DataTableComponent_Conditional_11_Template, 3, 2, "tr")(12, DataTableComponent_Conditional_12_Template, 2, 0);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-busy", ctx.loading());
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(ctx.label());
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.selectable() ? 6 : -1);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.columns());
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.loading() ? 10 : !ctx.rows().length ? 11 : 12);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-data-table[_ngcontent-%COMP%]{width:100%;overflow:auto;border:1px solid #e2e8f0;border-radius:.75rem;background:#fff}table[_ngcontent-%COMP%]{width:100%;border-collapse:collapse;color:#0f172a}th[_ngcontent-%COMP%], td[_ngcontent-%COMP%]{padding:.7rem .8rem;border-bottom:1px solid #e2e8f0;text-align:left}th[_ngcontent-%COMP%]{background:#f8fafc;font-size:.8rem}th.sortable[_ngcontent-%COMP%]{cursor:pointer}tr.selected[_ngcontent-%COMP%]{background:#eff6ff}.empty[_ngcontent-%COMP%]{padding:2rem;text-align:center;color:#64748b}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataTableComponent, [{
        type: Component,
        args: [{ selector: 'orc-data-table', standalone: true, template: `
    <div class="orc-p2-data-table" [attr.aria-busy]="loading()">
      <table>
        <caption class="sr-only">{{ label() }}</caption>
        <thead><tr>@if (selectable()) { <th scope="col"><input type="checkbox" [checked]="allSelected()" [indeterminate]="someSelected()" aria-label="Select all" (change)="toggleAll(($any($event.target)).checked)" /></th> } @for (column of columns(); track column.key) { <th scope="col" [attr.aria-sort]="sortKey() === column.key ? sortDirection() : null" [class.sortable]="column.sortable" (click)="sortBy(column)">{{ column.header }}</th> }</tr></thead>
        <tbody>
          @if (loading()) { <tr><td class="empty" [attr.colspan]="columns().length + (selectable() ? 1 : 0)">Loading…</td></tr> }
          @else if (!rows().length) { <tr><td class="empty" [attr.colspan]="columns().length + (selectable() ? 1 : 0)">{{ emptyText() }}</td></tr> }
          @else { @for (row of rows(); track getRowId(row)) { <tr [class.selected]="isSelected(row)" (click)="rowClick.emit(row)">@if (selectable()) { <td (click)="$event.stopPropagation()"><input type="checkbox" [checked]="isSelected(row)" [attr.aria-label]="'Select row ' + getRowId(row)" (change)="toggleRow(row, ($any($event.target)).checked)" /></td> } @for (column of columns(); track column.key) { <td>{{ getCell(row, column.key) }}</td> }</tr> } }
        </tbody>
      </table>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-data-table{width:100%;overflow:auto;border:1px solid #e2e8f0;border-radius:.75rem;background:#fff}table{width:100%;border-collapse:collapse;color:#0f172a}th,td{padding:.7rem .8rem;border-bottom:1px solid #e2e8f0;text-align:left}th{background:#f8fafc;font-size:.8rem}th.sortable{cursor:pointer}tr.selected{background:#eff6ff}.empty{padding:2rem;text-align:center;color:#64748b}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DataTableComponent, { className: "DataTableComponent", filePath: "p2-data-components.ts", lineNumber: 115 }); })();
class EmptyStateComponent {
    title = input('Nothing here yet');
    description = input('There is no content to show.');
    icon = input('∅');
    actionLabel = input('');
    action = output();
    static ɵfac = function EmptyStateComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || EmptyStateComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EmptyStateComponent, selectors: [["orc-empty-state"]], inputs: { title: [1, "title"], description: [1, "description"], icon: [1, "icon"], actionLabel: [1, "actionLabel"] }, outputs: { action: "action" }, ngContentSelectors: _c2, decls: 8, vars: 5, consts: [[1, "orc-p2-empty-state"], ["aria-hidden", "true", 1, "icon"], ["type", "button"], ["type", "button", 3, "click"]], template: function EmptyStateComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "section", 0)(1, "div", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "h2");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, EmptyStateComponent_Conditional_5_Template, 2, 1, "p")(6, EmptyStateComponent_Conditional_6_Template, 2, 1, "button", 2);
            i0.ɵɵprojection(7);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.title());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.icon());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.title());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.description() ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.actionLabel() ? 6 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-empty-state[_ngcontent-%COMP%]{display:grid;justify-items:center;gap:.6rem;padding:3rem 1.5rem;border:1px dashed #cbd5e1;border-radius:.75rem;text-align:center;color:#0f172a}.icon[_ngcontent-%COMP%]{font-size:2rem}h2[_ngcontent-%COMP%], p[_ngcontent-%COMP%]{margin:0}p[_ngcontent-%COMP%]{max-width:36rem;color:#64748b}button[_ngcontent-%COMP%]{border:0;border-radius:.5rem;background:#2563eb;color:#fff;padding:.55rem .85rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EmptyStateComponent, [{
        type: Component,
        args: [{ selector: 'orc-empty-state', standalone: true, template: `<section class="orc-p2-empty-state" [attr.aria-label]="title()"><div class="icon" aria-hidden="true">{{ icon() }}</div><h2>{{ title() }}</h2>@if (description()) { <p>{{ description() }}</p> } @if (actionLabel()) { <button type="button" (click)="action.emit()">{{ actionLabel() }}</button> }<ng-content /></section>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-empty-state{display:grid;justify-items:center;gap:.6rem;padding:3rem 1.5rem;border:1px dashed #cbd5e1;border-radius:.75rem;text-align:center;color:#0f172a}.icon{font-size:2rem}h2,p{margin:0}p{max-width:36rem;color:#64748b}button{border:0;border-radius:.5rem;background:#2563eb;color:#fff;padding:.55rem .85rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(EmptyStateComponent, { className: "EmptyStateComponent", filePath: "p2-data-components.ts", lineNumber: 167 }); })();
class VirtualScrollerComponent {
    items = input([]);
    itemHeight = input(40);
    viewportHeight = input('240px');
    overscan = input(4);
    label = input('Scrollable list');
    itemLabelKey = input('label');
    scrollTop = signal(0);
    rangeChange = output();
    startIndex = computed(() => Math.max(0, Math.floor(this.scrollTop() / Math.max(1, this.itemHeight())) - this.overscan()));
    endIndex = computed(() => Math.min(this.items().length, Math.ceil((this.scrollTop() + this.viewportPixels()) / Math.max(1, this.itemHeight())) + this.overscan()));
    viewportPixels = computed(() => Number.parseInt(this.viewportHeight(), 10) || 240);
    visibleItems = computed(() => this.items().slice(this.startIndex(), this.endIndex()));
    topSpacer = computed(() => this.startIndex() * this.itemHeight());
    bottomSpacer = computed(() => Math.max(0, (this.items().length - this.endIndex()) * this.itemHeight()));
    onScroll(event) { const top = event.target.scrollTop; this.scrollTop.set(top); this.rangeChange.emit({ start: this.startIndex(), end: this.endIndex() }); }
    itemLabel(item) { if (item && typeof item === 'object')
        return String(item[this.itemLabelKey()] ?? ''); return String(item ?? ''); }
    static ɵfac = function VirtualScrollerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || VirtualScrollerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: VirtualScrollerComponent, selectors: [["orc-virtual-scroller"]], inputs: { items: [1, "items"], itemHeight: [1, "itemHeight"], viewportHeight: [1, "viewportHeight"], overscan: [1, "overscan"], label: [1, "label"], itemLabelKey: [1, "itemLabelKey"] }, outputs: { rangeChange: "rangeChange" }, decls: 5, vars: 7, consts: [["role", "list", 1, "orc-p2-virtual-scroller", 3, "scroll"], ["role", "listitem", 1, "item", 3, "height"], ["role", "listitem", 1, "item"]], template: function VirtualScrollerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("scroll", function VirtualScrollerComponent_Template_div_scroll_0_listener($event) { return ctx.onScroll($event); });
            i0.ɵɵelement(1, "div");
            i0.ɵɵrepeaterCreate(2, VirtualScrollerComponent_For_3_Template, 2, 3, "div", 1, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵelement(4, "div");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵstyleProp("height", ctx.viewportHeight());
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("height", ctx.topSpacer(), "px");
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.visibleItems());
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("height", ctx.bottomSpacer(), "px");
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-virtual-scroller[_ngcontent-%COMP%]{overflow:auto;border:1px solid #cbd5e1;border-radius:.6rem;background:#fff;color:#0f172a}.item[_ngcontent-%COMP%]{display:flex;align-items:center;padding:0 .75rem;border-bottom:1px solid #f1f5f9}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(VirtualScrollerComponent, [{
        type: Component,
        args: [{ selector: 'orc-virtual-scroller', standalone: true, template: `<div class="orc-p2-virtual-scroller" role="list" [attr.aria-label]="label()" [style.height]="viewportHeight()" (scroll)="onScroll($event)"><div [style.height.px]="topSpacer()"></div>@for (item of visibleItems(); track $index) { <div role="listitem" class="item" [style.height.px]="itemHeight()">{{ itemLabel(item) }}</div> }<div [style.height.px]="bottomSpacer()"></div></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-virtual-scroller{overflow:auto;border:1px solid #cbd5e1;border-radius:.6rem;background:#fff;color:#0f172a}.item{display:flex;align-items:center;padding:0 .75rem;border-bottom:1px solid #f1f5f9}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(VirtualScrollerComponent, { className: "VirtualScrollerComponent", filePath: "p2-data-components.ts", lineNumber: 182 }); })();

function FloatingActionButtonComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵtext(1, "\u2026");
    i0.ɵɵelementEnd();
} }
function FloatingActionButtonComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.icon());
} }
function FloatingActionButtonComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
const _c0 = ["*"];
const _forTrack0$1 = ($index, $item) => $item.value;
function ContextMenuComponent_Conditional_2_For_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r4.shortcut);
} }
function ContextMenuComponent_Conditional_2_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 4);
    i0.ɵɵlistener("click", function ContextMenuComponent_Conditional_2_For_2_Template_button_click_0_listener() { const item_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.activate(item_r4)); });
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, ContextMenuComponent_Conditional_2_For_2_Conditional_2_Template, 2, 1, "small");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    i0.ɵɵclassProp("danger", item_r4.danger);
    i0.ɵɵproperty("disabled", item_r4.disabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", item_r4.label, " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r4.shortcut ? 2 : -1);
} }
function ContextMenuComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵlistener("keydown", function ContextMenuComponent_Conditional_2_Template_div_keydown_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onKeydown($event)); });
    i0.ɵɵrepeaterCreate(1, ContextMenuComponent_Conditional_2_For_2_Template, 3, 5, "button", 3, _forTrack0$1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("left", ctx_r1.position().x, "px")("top", ctx_r1.position().y, "px");
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.items());
} }
function SpeedDialComponent_Conditional_2_For_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 4);
    i0.ɵɵlistener("click", function SpeedDialComponent_Conditional_2_For_1_Template_button_click_0_listener() { const action_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.activate(action_r2)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const action_r2 = ctx.$implicit;
    i0.ɵɵproperty("disabled", action_r2.disabled);
    i0.ɵɵattribute("aria-label", action_r2.label);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(action_r2.icon || "\u2022");
} }
function SpeedDialComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, SpeedDialComponent_Conditional_2_For_1_Template, 2, 3, "button", 3, _forTrack0$1);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r2.actions());
} }
const _forTrack1$1 = ($index, $item) => $item.id;
function SplitterComponent_Conditional_1_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "section", 2)(1, "header");
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(3, "div", 3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const panel_r1 = ctx.$implicit;
    const $index_r2 = ctx.$index;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("flex-basis", ctx_r2.panelSize($index_r2), "%");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(panel_r1.label || panel_r1.id);
} }
function SplitterComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, SplitterComponent_Conditional_1_For_1_Template, 4, 3, "section", 1, _forTrack1$1);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r2.panels());
} }
function SplitterComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
class FloatingActionButtonComponent {
    label = input('');
    icon = input('+');
    ariaLabel = input('Create');
    extended = input(false, { transform: booleanAttribute });
    loading = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    clicked = output();
    static ɵfac = function FloatingActionButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FloatingActionButtonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FloatingActionButtonComponent, selectors: [["orc-floating-action-button"]], inputs: { label: [1, "label"], icon: [1, "icon"], ariaLabel: [1, "ariaLabel"], extended: [1, "extended"], loading: [1, "loading"], disabled: [1, "disabled"] }, outputs: { clicked: "clicked" }, decls: 4, vars: 8, consts: [["type", "button", 1, "orc-p2-fab", 3, "click", "disabled"], ["aria-hidden", "true"]], template: function FloatingActionButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function FloatingActionButtonComponent_Template_button_click_0_listener($event) { return ctx.clicked.emit($event); });
            i0.ɵɵtemplate(1, FloatingActionButtonComponent_Conditional_1_Template, 2, 0, "span", 1)(2, FloatingActionButtonComponent_Conditional_2_Template, 2, 1, "span", 1)(3, FloatingActionButtonComponent_Conditional_3_Template, 2, 1, "span");
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("extended", ctx.extended())("loading", ctx.loading());
            i0.ɵɵproperty("disabled", ctx.disabled() || ctx.loading());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.loading() ? 1 : 2);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.extended() ? 3 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-fab[_ngcontent-%COMP%]{display:inline-flex;gap:.5rem;align-items:center;justify-content:center;min-width:3rem;min-height:3rem;border:0;border-radius:999px;background:#2563eb;color:#fff;box-shadow:0 8px 18px #2563eb40;font-weight:700}.orc-p2-fab.extended[_ngcontent-%COMP%]{padding-inline:1rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FloatingActionButtonComponent, [{
        type: Component,
        args: [{ selector: 'orc-floating-action-button', standalone: true, template: `<button type="button" class="orc-p2-fab" [class.extended]="extended()" [class.loading]="loading()" [disabled]="disabled() || loading()" [attr.aria-label]="ariaLabel()" (click)="clicked.emit($event)">@if (loading()) { <span aria-hidden="true">…</span> } @else { <span aria-hidden="true">{{ icon() }}</span> } @if (extended()) { <span>{{ label() }}</span> }</button>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-fab{display:inline-flex;gap:.5rem;align-items:center;justify-content:center;min-width:3rem;min-height:3rem;border:0;border-radius:999px;background:#2563eb;color:#fff;box-shadow:0 8px 18px #2563eb40;font-weight:700}.orc-p2-fab.extended{padding-inline:1rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FloatingActionButtonComponent, { className: "FloatingActionButtonComponent", filePath: "p2-overlay-components.ts", lineNumber: 11 }); })();
class CloseButtonComponent {
    ariaLabel = input('Close');
    icon = input('×');
    size = input('md');
    disabled = input(false, { transform: booleanAttribute });
    close = output();
    static ɵfac = function CloseButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CloseButtonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CloseButtonComponent, selectors: [["orc-close-button"]], inputs: { ariaLabel: [1, "ariaLabel"], icon: [1, "icon"], size: [1, "size"], disabled: [1, "disabled"] }, outputs: { close: "close" }, decls: 2, vars: 5, consts: [["type", "button", 1, "orc-p2-close-button", 3, "click", "disabled"]], template: function CloseButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function CloseButtonComponent_Template_button_click_0_listener() { return ctx.close.emit(); });
            i0.ɵɵtext(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap("orc-p2-close-button orc-p2-close-button--" + ctx.size());
            i0.ɵɵproperty("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.icon());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-close-button[_ngcontent-%COMP%]{display:inline-grid;place-items:center;border:0;border-radius:.4rem;background:transparent;color:#475569}.orc-p2-close-button[_ngcontent-%COMP%]:hover{background:#f1f5f9;color:#0f172a}.orc-p2-close-button--sm[_ngcontent-%COMP%]{width:1.5rem;height:1.5rem}.orc-p2-close-button--md[_ngcontent-%COMP%]{width:2rem;height:2rem}.orc-p2-close-button--lg[_ngcontent-%COMP%]{width:2.5rem;height:2.5rem;font-size:1.3rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CloseButtonComponent, [{
        type: Component,
        args: [{ selector: 'orc-close-button', standalone: true, template: `<button type="button" class="orc-p2-close-button" [class]="'orc-p2-close-button orc-p2-close-button--' + size()" [disabled]="disabled()" [attr.aria-label]="ariaLabel()" (click)="close.emit()">{{ icon() }}</button>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-close-button{display:inline-grid;place-items:center;border:0;border-radius:.4rem;background:transparent;color:#475569}.orc-p2-close-button:hover{background:#f1f5f9;color:#0f172a}.orc-p2-close-button--sm{width:1.5rem;height:1.5rem}.orc-p2-close-button--md{width:2rem;height:2rem}.orc-p2-close-button--lg{width:2.5rem;height:2.5rem;font-size:1.3rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CloseButtonComponent, { className: "CloseButtonComponent", filePath: "p2-overlay-components.ts", lineNumber: 28 }); })();
class ContextMenuComponent {
    items = input([]);
    open = model(false);
    position = signal({ x: 0, y: 0 });
    itemSelect = output();
    opened = output();
    openAt(event) { event.preventDefault(); this.position.set({ x: event.clientX, y: event.clientY }); this.open.set(true); this.opened.emit(this.position()); }
    activate(item) { if (item.disabled)
        return; this.itemSelect.emit(item); this.open.set(false); }
    onKeydown(event) { if (event.key === 'Escape') {
        event.preventDefault();
        this.open.set(false);
    } }
    static ɵfac = function ContextMenuComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ContextMenuComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ContextMenuComponent, selectors: [["orc-context-menu"]], inputs: { items: [1, "items"], open: [1, "open"] }, outputs: { open: "openChange", itemSelect: "itemSelect", opened: "opened" }, ngContentSelectors: _c0, decls: 3, vars: 1, consts: [[1, "orc-p2-context-menu-host", 3, "contextmenu"], ["role", "menu", 1, "orc-p2-context-menu", 3, "left", "top"], ["role", "menu", 1, "orc-p2-context-menu", 3, "keydown"], ["type", "button", "role", "menuitem", 3, "disabled", "danger"], ["type", "button", "role", "menuitem", 3, "click", "disabled"]], template: function ContextMenuComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("contextmenu", function ContextMenuComponent_Template_div_contextmenu_0_listener($event) { return ctx.openAt($event); });
            i0.ɵɵprojection(1);
            i0.ɵɵtemplate(2, ContextMenuComponent_Conditional_2_Template, 3, 4, "div", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.open() ? 2 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-context-menu-host[_ngcontent-%COMP%]{position:relative;min-height:2rem}.orc-p2-context-menu[_ngcontent-%COMP%]{position:fixed;z-index:10;display:grid;min-width:12rem;padding:.25rem;border:1px solid #cbd5e1;border-radius:.55rem;background:#fff;box-shadow:0 12px 28px #0f172a26}.orc-p2-context-menu[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:flex;justify-content:space-between;border:0;border-radius:.35rem;background:transparent;padding:.55rem .7rem;text-align:left}.orc-p2-context-menu[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover{background:#eff6ff}.orc-p2-context-menu[_ngcontent-%COMP%]   button.danger[_ngcontent-%COMP%]{color:#b91c1c}small[_ngcontent-%COMP%]{color:#64748b}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ContextMenuComponent, [{
        type: Component,
        args: [{ selector: 'orc-context-menu', standalone: true, template: `<div class="orc-p2-context-menu-host" (contextmenu)="openAt($event)"><ng-content />@if (open()) { <div class="orc-p2-context-menu" role="menu" [style.left.px]="position().x" [style.top.px]="position().y" (keydown)="onKeydown($event)">@for (item of items(); track item.value) { <button type="button" role="menuitem" [disabled]="item.disabled" [class.danger]="item.danger" (click)="activate(item)">{{ item.label }} @if (item.shortcut) { <small>{{ item.shortcut }}</small> }</button> }</div> }</div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-context-menu-host{position:relative;min-height:2rem}.orc-p2-context-menu{position:fixed;z-index:10;display:grid;min-width:12rem;padding:.25rem;border:1px solid #cbd5e1;border-radius:.55rem;background:#fff;box-shadow:0 12px 28px #0f172a26}.orc-p2-context-menu button{display:flex;justify-content:space-between;border:0;border-radius:.35rem;background:transparent;padding:.55rem .7rem;text-align:left}.orc-p2-context-menu button:hover{background:#eff6ff}.orc-p2-context-menu button.danger{color:#b91c1c}small{color:#64748b}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ContextMenuComponent, { className: "ContextMenuComponent", filePath: "p2-overlay-components.ts", lineNumber: 48 }); })();
class SpeedDialComponent {
    actions = input([]);
    open = model(false);
    icon = input('+');
    openLabel = input('Open actions');
    closeLabel = input('Close actions');
    actionSelect = output();
    activate(action) { if (!action.disabled) {
        this.actionSelect.emit(action);
        this.open.set(false);
    } }
    static ɵfac = function SpeedDialComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SpeedDialComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SpeedDialComponent, selectors: [["orc-speed-dial"]], inputs: { actions: [1, "actions"], open: [1, "open"], icon: [1, "icon"], openLabel: [1, "openLabel"], closeLabel: [1, "closeLabel"] }, outputs: { open: "openChange", actionSelect: "actionSelect" }, decls: 5, vars: 6, consts: [[1, "orc-p2-speed-dial"], [1, "actions"], ["type", "button", 1, "trigger", 3, "click"], ["type", "button", 3, "disabled"], ["type", "button", 3, "click", "disabled"]], template: function SpeedDialComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1);
            i0.ɵɵtemplate(2, SpeedDialComponent_Conditional_2_Template, 2, 0);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "button", 2);
            i0.ɵɵlistener("click", function SpeedDialComponent_Template_button_click_3_listener() { return ctx.open.set(!ctx.open()); });
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵclassProp("open", ctx.open());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.open() ? 2 : -1);
            i0.ɵɵadvance();
            i0.ɵɵattribute("aria-expanded", ctx.open())("aria-label", ctx.open() ? ctx.closeLabel() : ctx.openLabel());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.open() ? "\u00D7" : ctx.icon());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-speed-dial[_ngcontent-%COMP%]{display:inline-flex;flex-direction:column;align-items:center;gap:.5rem}.actions[_ngcontent-%COMP%]{display:flex;flex-direction:column-reverse;gap:.45rem}.actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%], .trigger[_ngcontent-%COMP%]{display:grid;place-items:center;width:2.6rem;height:2.6rem;border:0;border-radius:999px;background:#e2e8f0;color:#0f172a}.trigger[_ngcontent-%COMP%]{background:#2563eb;color:#fff;font-size:1.3rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SpeedDialComponent, [{
        type: Component,
        args: [{ selector: 'orc-speed-dial', standalone: true, template: `<div class="orc-p2-speed-dial"><div class="actions" [class.open]="open()">@if (open()) { @for (action of actions(); track action.value) { <button type="button" [disabled]="action.disabled" [attr.aria-label]="action.label" (click)="activate(action)">{{ action.icon || '•' }}</button> } }</div><button type="button" class="trigger" [attr.aria-expanded]="open()" [attr.aria-label]="open() ? closeLabel() : openLabel()" (click)="open.set(!open())">{{ open() ? '×' : icon() }}</button></div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-speed-dial{display:inline-flex;flex-direction:column;align-items:center;gap:.5rem}.actions{display:flex;flex-direction:column-reverse;gap:.45rem}.actions button,.trigger{display:grid;place-items:center;width:2.6rem;height:2.6rem;border:0;border-radius:999px;background:#e2e8f0;color:#0f172a}.trigger{background:#2563eb;color:#fff;font-size:1.3rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SpeedDialComponent, { className: "SpeedDialComponent", filePath: "p2-overlay-components.ts", lineNumber: 70 }); })();
class PortalComponent {
    target = input(null);
    static ɵfac = function PortalComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PortalComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PortalComponent, selectors: [["orc-portal"]], inputs: { target: [1, "target"] }, ngContentSelectors: _c0, decls: 1, vars: 0, template: function PortalComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵprojection(0);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PortalComponent, [{
        type: Component,
        args: [{ selector: 'orc-portal', standalone: true, template: `<ng-content />`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PortalComponent, { className: "PortalComponent", filePath: "p2-overlay-components.ts", lineNumber: 87 }); })();
class SplitterComponent {
    panels = input([]);
    orientation = input('horizontal');
    label = input('Resizable panels');
    sizes = model([]);
    sizesChange = output();
    normalizedSizes = computed(() => {
        const count = this.panels().length;
        if (!count)
            return [];
        const supplied = this.sizes();
        if (supplied.length === count && supplied.every(size => size > 0))
            return supplied;
        return Array.from({ length: count }, () => 100 / count);
    });
    panelSize(index) { return this.normalizedSizes()[index] ?? 0; }
    setSizes(sizes) { const next = this.normalize(sizes); this.sizes.set(next); this.sizesChange.emit(next); }
    resize(index, delta) {
        const next = [...this.normalizedSizes()];
        if (index < 0 || index >= next.length - 1)
            return;
        next[index] = Math.max(10, Math.min(90, next[index] + delta));
        next[index + 1] = Math.max(10, next[index + 1] - delta);
        this.setSizes(next);
    }
    normalize(sizes) { const total = sizes.reduce((sum, size) => sum + Math.max(0, size), 0) || 1; return sizes.map(size => Math.max(0, size) / total * 100); }
    static ɵfac = function SplitterComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SplitterComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SplitterComponent, selectors: [["orc-splitter"]], inputs: { panels: [1, "panels"], orientation: [1, "orientation"], label: [1, "label"], sizes: [1, "sizes"] }, outputs: { sizes: "sizesChange", sizesChange: "sizesChange" }, ngContentSelectors: _c0, decls: 3, vars: 4, consts: [["role", "group", 1, "orc-p2-splitter"], [1, "panel", 3, "flex-basis"], [1, "panel"], [1, "panel-body"]], template: function SplitterComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, SplitterComponent_Conditional_1_Template, 2, 0)(2, SplitterComponent_Conditional_2_Template, 1, 0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("vertical", ctx.orientation() === "vertical");
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.panels().length ? 1 : 2);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-splitter[_ngcontent-%COMP%]{display:flex;min-height:8rem;width:100%;gap:1px;background:#cbd5e1}.orc-p2-splitter.vertical[_ngcontent-%COMP%]{flex-direction:column}.panel[_ngcontent-%COMP%]{min-width:0;min-height:0;flex:1 1 0;background:#fff;color:#0f172a}.panel[_ngcontent-%COMP%]   header[_ngcontent-%COMP%]{padding:.45rem .65rem;border-bottom:1px solid #e2e8f0;font-size:.8rem;font-weight:700}.panel-body[_ngcontent-%COMP%]{min-height:4rem;padding:.5rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SplitterComponent, [{
        type: Component,
        args: [{ selector: 'orc-splitter', standalone: true, template: `<div class="orc-p2-splitter" [class.vertical]="orientation() === 'vertical'" role="group" [attr.aria-label]="label()">@if (panels().length) { @for (panel of panels(); track panel.id) { <section class="panel" [style.flex-basis.%]="panelSize($index)"><header>{{ panel.label || panel.id }}</header><div class="panel-body"></div></section> } } @else { <ng-content /> }</div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-splitter{display:flex;min-height:8rem;width:100%;gap:1px;background:#cbd5e1}.orc-p2-splitter.vertical{flex-direction:column}.panel{min-width:0;min-height:0;flex:1 1 0;background:#fff;color:#0f172a}.panel header{padding:.45rem .65rem;border-bottom:1px solid #e2e8f0;font-size:.8rem;font-weight:700}.panel-body{min-height:4rem;padding:.5rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SplitterComponent, { className: "SplitterComponent", filePath: "p2-overlay-components.ts", lineNumber: 105 }); })();

const _forTrack0 = ($index, $item) => $item.value;
function SegmentedControlComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 2);
    i0.ɵɵlistener("click", function SegmentedControlComponent_For_2_Template_button_click_0_listener() { const option_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.select(option_r2)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("selected", ctx_r2.isSelected(option_r2));
    i0.ɵɵproperty("disabled", option_r2.disabled || ctx_r2.disabled());
    i0.ɵɵattribute("aria-pressed", ctx_r2.isSelected(option_r2));
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2("", option_r2.icon, " ", option_r2.label, "");
} }
const _forTrack1 = ($index, $item) => $item.node.value;
function TreeSelectComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function TreeSelectComponent_Conditional_6_For_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 9);
    i0.ɵɵlistener("click", function TreeSelectComponent_Conditional_6_For_2_Conditional_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const item_r4 = i0.ɵɵnextContext().$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.toggle(item_r4.node)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r4 = i0.ɵɵnextContext().$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("aria-label", ctx_r0.expanded().has(item_r4.node.value) ? "Collapse" : "Expand");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.expanded().has(item_r4.node.value) ? "\u25BE" : "\u25B8");
} }
function TreeSelectComponent_Conditional_6_For_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 7);
} }
function TreeSelectComponent_Conditional_6_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 5);
    i0.ɵɵtemplate(1, TreeSelectComponent_Conditional_6_For_2_Conditional_1_Template, 2, 2, "button", 6)(2, TreeSelectComponent_Conditional_6_For_2_Conditional_2_Template, 1, 0, "span", 7);
    i0.ɵɵelementStart(3, "button", 8);
    i0.ɵɵlistener("click", function TreeSelectComponent_Conditional_6_For_2_Template_button_click_3_listener() { const item_r4 = i0.ɵɵrestoreView(_r2).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.select(item_r4.node)); });
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("padding-left", item_r4.level * 0.9, "rem");
    i0.ɵɵclassProp("selected", ctx_r0.value() === item_r4.node.value)("disabled", item_r4.node.disabled);
    i0.ɵɵattribute("aria-level", item_r4.level)("aria-selected", ctx_r0.value() === item_r4.node.value);
    i0.ɵɵadvance();
    i0.ɵɵconditional((item_r4.node.children == null ? null : item_r4.node.children.length) ? 1 : 2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", item_r4.node.disabled);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r4.node.label);
} }
function TreeSelectComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "ul", 3);
    i0.ɵɵrepeaterCreate(1, TreeSelectComponent_Conditional_6_For_2_Template, 5, 11, "li", 4, _forTrack1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.visibleNodes());
} }
class SegmentedControlComponent {
    options = input([]);
    value = model(null);
    label = input('Options');
    disabled = input(false, { transform: booleanAttribute });
    valueChangeEvent = output();
    activeIndex = signal(0);
    isSelected(option) { return this.value() === option.value; }
    select(option) { if (option.disabled || this.disabled())
        return; this.value.set(option.value); this.valueChangeEvent.emit(option.value); }
    onKeydown(event) {
        const options = this.options();
        if (!options.length)
            return;
        if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
            event.preventDefault();
            const delta = event.key === 'ArrowRight' ? 1 : -1;
            this.activeIndex.update(index => (index + delta + options.length) % options.length);
        }
        else if (event.key === 'Enter' || event.key === ' ') {
            const option = options[this.activeIndex()];
            if (option)
                this.select(option);
        }
    }
    static ɵfac = function SegmentedControlComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SegmentedControlComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SegmentedControlComponent, selectors: [["orc-segmented-control"]], inputs: { options: [1, "options"], value: [1, "value"], label: [1, "label"], disabled: [1, "disabled"] }, outputs: { value: "valueChange", valueChangeEvent: "valueChangeEvent" }, decls: 3, vars: 1, consts: [["role", "group", 1, "orc-p2-segmented", 3, "keydown"], ["type", "button", 3, "disabled", "selected"], ["type", "button", 3, "click", "disabled"]], template: function SegmentedControlComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("keydown", function SegmentedControlComponent_Template_div_keydown_0_listener($event) { return ctx.onKeydown($event); });
            i0.ɵɵrepeaterCreate(1, SegmentedControlComponent_For_2_Template, 2, 6, "button", 1, _forTrack0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.options());
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-segmented[_ngcontent-%COMP%]{display:inline-flex;gap:.2rem;padding:.2rem;border-radius:.6rem;background:#f1f5f9}.orc-p2-segmented[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:0;border-radius:.4rem;background:transparent;color:#475569;padding:.5rem .75rem}.orc-p2-segmented[_ngcontent-%COMP%]   button.selected[_ngcontent-%COMP%]{background:#fff;color:#1d4ed8;box-shadow:0 1px 3px #0f172a1a}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SegmentedControlComponent, [{
        type: Component,
        args: [{ selector: 'orc-segmented-control', standalone: true, template: `<div class="orc-p2-segmented" role="group" [attr.aria-label]="label()" (keydown)="onKeydown($event)">@for (option of options(); track option.value) { <button type="button" [disabled]="option.disabled || disabled()" [class.selected]="isSelected(option)" [attr.aria-pressed]="isSelected(option)" (click)="select(option)">{{ option.icon }} {{ option.label }}</button> }</div>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-segmented{display:inline-flex;gap:.2rem;padding:.2rem;border-radius:.6rem;background:#f1f5f9}.orc-p2-segmented button{border:0;border-radius:.4rem;background:transparent;color:#475569;padding:.5rem .75rem}.orc-p2-segmented button.selected{background:#fff;color:#1d4ed8;box-shadow:0 1px 3px #0f172a1a}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SegmentedControlComponent, { className: "SegmentedControlComponent", filePath: "p2-selection-components.ts", lineNumber: 11 }); })();
class TreeSelectComponent {
    nodes = input([]);
    value = model(null);
    label = input('');
    placeholder = input('Select an item');
    disabled = input(false, { transform: booleanAttribute });
    open = model(false);
    expanded = signal(new Set());
    nodeSelect = output();
    visibleNodes = computed(() => {
        const result = [];
        const visit = (nodes, level) => {
            for (const node of nodes) {
                result.push({ node, level });
                if (node.children?.length && this.expanded().has(node.value))
                    visit(node.children, level + 1);
            }
        };
        visit(this.nodes(), 1);
        return result;
    });
    selectedLabel() { return this.findNode(this.nodes(), this.value())?.label ?? ''; }
    toggle(node) { if (!node.children?.length)
        return; this.expanded.update(current => { const next = new Set(current); next.has(node.value) ? next.delete(node.value) : next.add(node.value); return next; }); }
    select(node) { if (node.disabled)
        return; this.value.set(node.value); this.nodeSelect.emit(node); this.open.set(false); }
    findNode(nodes, value) { for (const node of nodes) {
        if (node.value === value)
            return node;
        const nested = node.children ? this.findNode(node.children, value) : undefined;
        if (nested)
            return nested;
    } return undefined; }
    static ɵfac = function TreeSelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TreeSelectComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TreeSelectComponent, selectors: [["orc-tree-select"]], inputs: { nodes: [1, "nodes"], value: [1, "value"], label: [1, "label"], placeholder: [1, "placeholder"], disabled: [1, "disabled"], open: [1, "open"] }, outputs: { value: "valueChange", open: "openChange", nodeSelect: "nodeSelect" }, decls: 7, vars: 5, consts: [[1, "orc-p2-tree-select"], ["type", "button", 1, "trigger", 3, "click", "disabled"], ["aria-hidden", "true"], ["role", "tree", 1, "tree"], ["role", "treeitem", 3, "padding-left", "selected", "disabled"], ["role", "treeitem"], ["type", "button", 1, "expand"], [1, "expand-placeholder"], ["type", "button", 1, "item", 3, "click", "disabled"], ["type", "button", 1, "expand", 3, "click"]], template: function TreeSelectComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, TreeSelectComponent_Conditional_1_Template, 2, 1, "label");
            i0.ɵɵelementStart(2, "button", 1);
            i0.ɵɵlistener("click", function TreeSelectComponent_Template_button_click_2_listener() { return ctx.open.set(!ctx.open()); });
            i0.ɵɵtext(3);
            i0.ɵɵelementStart(4, "span", 2);
            i0.ɵɵtext(5, "\u2304");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(6, TreeSelectComponent_Conditional_6_Template, 3, 0, "ul", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-expanded", ctx.open());
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate1("", ctx.selectedLabel() || ctx.placeholder(), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.open() ? 6 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*[_ngcontent-%COMP%], *[_ngcontent-%COMP%]:before, *[_ngcontent-%COMP%]:after{box-sizing:border-box}button[_ngcontent-%COMP%], input[_ngcontent-%COMP%]{font:inherit}button[_ngcontent-%COMP%]{cursor:pointer}button[_ngcontent-%COMP%]:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus[_ngcontent-%COMP%]:focus-visible, button[_ngcontent-%COMP%]:focus-visible, input[_ngcontent-%COMP%]:focus-visible, [tabindex][_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tree-select[_ngcontent-%COMP%]{position:relative;display:grid;gap:.35rem;color:#0f172a}label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.trigger[_ngcontent-%COMP%]{display:flex;justify-content:space-between;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;padding:.5rem .7rem;text-align:left}.tree[_ngcontent-%COMP%]{position:absolute;z-index:3;top:4.2rem;right:0;left:0;max-height:16rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}li[_ngcontent-%COMP%]{display:flex;align-items:center;min-height:2rem}li.selected[_ngcontent-%COMP%]{background:#eff6ff}li.disabled[_ngcontent-%COMP%]{color:#94a3b8}.expand[_ngcontent-%COMP%], .expand-placeholder[_ngcontent-%COMP%]{flex:0 0 1.4rem;width:1.4rem;border:0;background:transparent;text-align:center}.item[_ngcontent-%COMP%]{flex:1;border:0;background:transparent;padding:.35rem;text-align:left}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TreeSelectComponent, [{
        type: Component,
        args: [{ selector: 'orc-tree-select', standalone: true, template: `
    <div class="orc-p2-tree-select">
      @if (label()) { <label>{{ label() }}</label> }
      <button type="button" class="trigger" [disabled]="disabled()" [attr.aria-expanded]="open()" (click)="open.set(!open())">{{ selectedLabel() || placeholder() }} <span aria-hidden="true">⌄</span></button>
      @if (open()) {
        <ul class="tree" role="tree">
          @for (item of visibleNodes(); track item.node.value) {
            <li role="treeitem" [attr.aria-level]="item.level" [style.padding-left.rem]="item.level * .9" [attr.aria-selected]="value() === item.node.value" [class.selected]="value() === item.node.value" [class.disabled]="item.node.disabled">
              @if (item.node.children?.length) { <button type="button" class="expand" [attr.aria-label]="expanded().has(item.node.value) ? 'Collapse' : 'Expand'" (click)="toggle(item.node)">{{ expanded().has(item.node.value) ? '▾' : '▸' }}</button> } @else { <span class="expand-placeholder"></span> }
              <button type="button" class="item" [disabled]="item.node.disabled" (click)="select(item.node)">{{ item.node.label }}</button>
            </li>
          }
        </ul>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;font-family:var(--font-sans, Inter, system-ui, sans-serif)}*,*:before,*:after{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}.orc-p2-muted{color:var(--orc-font-secondary, #64748b)}.orc-p2-focus:focus-visible,button:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #2563eb);outline-offset:2px}.orc-p2-tree-select{position:relative;display:grid;gap:.35rem;color:#0f172a}label{font-size:.875rem;font-weight:600}.trigger{display:flex;justify-content:space-between;min-height:2.5rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;padding:.5rem .7rem;text-align:left}.tree{position:absolute;z-index:3;top:4.2rem;right:0;left:0;max-height:16rem;overflow:auto;margin:0;padding:.25rem;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;box-shadow:0 10px 25px #0f172a1a;list-style:none}li{display:flex;align-items:center;min-height:2rem}li.selected{background:#eff6ff}li.disabled{color:#94a3b8}.expand,.expand-placeholder{flex:0 0 1.4rem;width:1.4rem;border:0;background:transparent;text-align:center}.item{flex:1;border:0;background:transparent;padding:.35rem;text-align:left}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TreeSelectComponent, { className: "TreeSelectComponent", filePath: "p2-selection-components.ts", lineNumber: 55 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { AspectRatioComponent, BoxComponent, ButtonGroupComponent, CalendarComponent, CloseButtonComponent, CodeComponent, ComboboxComponent, ContainerComponent, ContextMenuComponent, DataTableComponent, DateInputComponent, EmptyStateComponent, FlexComponent, FloatingActionButtonComponent, GridComponent, HoverCardComponent, InputGroupComponent, KbdComponent, LinkComponent, ListboxComponent, MenubarComponent, MultiSelectComponent, P2_SHARED_STYLES, PortalComponent, SegmentedControlComponent, SeparatorComponent, SpaceComponent, SpeedDialComponent, SplitterComponent, StackComponent, TagComponent, TagsInputComponent, TextComponent, TreeSelectComponent, TypographyComponent, VirtualScrollerComponent, VisuallyHiddenComponent };
//# sourceMappingURL=ciag-orchestra-p2.mjs.map
