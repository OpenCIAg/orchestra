import * as i0 from '@angular/core';
import { inject, ElementRef, input, model, booleanAttribute, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

function ColorPickerComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 1);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r0.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function ColorPickerComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.value() || "Sem cor");
} }
function ColorPickerComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 9);
    i0.ɵɵlistener("click", function ColorPickerComponent_Conditional_8_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.clear()); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r0.effectiveDisabled());
} }
function ColorPickerComponent_Conditional_9_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "input", 14);
    i0.ɵɵlistener("input", function ColorPickerComponent_Conditional_9_Conditional_2_Template_input_input_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.onTextInput($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("value", ctx_r0.value());
} }
function ColorPickerComponent_Conditional_9_For_5_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 15);
    i0.ɵɵlistener("click", function ColorPickerComponent_Conditional_9_For_5_Template_button_click_0_listener() { const color_r6 = i0.ɵɵrestoreView(_r5).$implicit; const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.selectColor(color_r6)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const color_r6 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("background-color", color_r6);
    i0.ɵɵclassProp("orc-color-picker__preset--active", ctx_r0.value().toUpperCase() === color_r6.toUpperCase());
    i0.ɵɵattribute("aria-label", color_r6);
} }
function ColorPickerComponent_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 8)(1, "input", 10);
    i0.ɵɵlistener("input", function ColorPickerComponent_Conditional_9_Template_input_input_1_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onNativeColor($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(2, ColorPickerComponent_Conditional_9_Conditional_2_Template, 1, 1, "input", 11);
    i0.ɵɵelementStart(3, "div", 12);
    i0.ɵɵrepeaterCreate(4, ColorPickerComponent_Conditional_9_For_5_Template, 1, 5, "button", 13, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", ctx_r0.nativeValue())("disabled", ctx_r0.effectiveDisabled());
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.showInput() ? 2 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(ctx_r0.presets());
} }
let nextColorPickerId = 0;
const DEFAULT_PRESETS = ['#1C6AED', '#0406AB', '#FF6A1C', '#1CEDB9', '#6A1CED', '#006F4A', '#FB2C36', '#FE9A00', '#141414', '#FFFFFF'];
class ColorPickerComponent {
    host = inject((ElementRef));
    uniqueId = `orc-color-picker-${++nextColorPickerId}`;
    id = input('');
    label = input('');
    value = model('#1C6AED');
    size = input('md');
    presets = input(DEFAULT_PRESETS);
    disabled = input(false, { transform: booleanAttribute });
    clearable = input(true, { transform: booleanAttribute });
    showInput = input(true, { transform: booleanAttribute });
    ariaLabel = input('Escolher cor');
    colorChange = output();
    isOpen = signal(false);
    cvaDisabled = signal(false);
    effectiveId = computed(() => this.id() || this.uniqueId);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    nativeValue = computed(() => this.toNativeHex(this.value()));
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) { if (typeof value === 'string' && this.isValidColor(value))
        this.value.set(value); }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    toggle() { if (!this.effectiveDisabled())
        this.isOpen.update(open => !open); }
    selectColor(color) { if (!this.effectiveDisabled() && this.isValidColor(color)) {
        this.update(color);
        this.isOpen.set(false);
    } }
    onNativeColor(event) { this.update(event.target.value.toUpperCase()); }
    onTextInput(event) { const color = event.target.value; if (this.isValidColor(color))
        this.update(color.toUpperCase()); }
    clear() { if (!this.effectiveDisabled()) {
        this.update('');
        this.isOpen.set(false);
    } }
    onDocumentClick(event) { if (!this.host.nativeElement.contains(event.target))
        this.isOpen.set(false); }
    update(color) { this.value.set(color); this.onChange(color); this.colorChange.emit(color); this.onTouched(); }
    isValidColor(color) { return /^#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?$/.test(color); }
    toNativeHex(color) { if (/^#[0-9A-Fa-f]{3}$/.test(color))
        return '#' + color.slice(1).split('').map(char => char + char).join(''); return this.isValidColor(color) ? color : '#000000'; }
    static ɵfac = function ColorPickerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ColorPickerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ColorPickerComponent, selectors: [["orc-color-picker"]], hostBindings: function ColorPickerComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("click", function ColorPickerComponent_click_HostBindingHandler($event) { return ctx.onDocumentClick($event); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { id: [1, "id"], label: [1, "label"], value: [1, "value"], size: [1, "size"], presets: [1, "presets"], disabled: [1, "disabled"], clearable: [1, "clearable"], showInput: [1, "showInput"], ariaLabel: [1, "ariaLabel"] }, outputs: { value: "valueChange", colorChange: "colorChange" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ColorPickerComponent), multi: true }])], decls: 10, vars: 12, consts: [[1, "orc-color-picker"], [1, "orc-color-picker__label", 3, "for"], [1, "orc-color-picker__control"], ["type", "button", 1, "orc-color-picker__trigger", 3, "click", "id", "disabled"], ["aria-hidden", "true", 1, "orc-color-picker__swatch"], [1, "orc-color-picker__value"], ["aria-hidden", "true", 1, "orc-color-picker__chevron"], ["type", "button", "aria-label", "Remover cor", 1, "orc-color-picker__clear", 3, "disabled"], ["role", "dialog", "aria-label", "Paleta de cores", 1, "orc-color-picker__panel"], ["type", "button", "aria-label", "Remover cor", 1, "orc-color-picker__clear", 3, "click", "disabled"], ["type", "color", "aria-label", "Seletor nativo de cor", 1, "orc-color-picker__native", 3, "input", "value", "disabled"], ["type", "text", "aria-label", "C\u00F3digo hexadecimal", "inputmode", "text", 1, "orc-color-picker__text", 3, "value"], ["aria-label", "Cores predefinidas", 1, "orc-color-picker__presets"], ["type", "button", 1, "orc-color-picker__preset", 3, "background-color", "orc-color-picker__preset--active"], ["type", "text", "aria-label", "C\u00F3digo hexadecimal", "inputmode", "text", 1, "orc-color-picker__text", 3, "input", "value"], ["type", "button", 1, "orc-color-picker__preset", 3, "click"]], template: function ColorPickerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ColorPickerComponent_Conditional_1_Template, 2, 2, "label", 1);
            i0.ɵɵelementStart(2, "div", 2)(3, "button", 3);
            i0.ɵɵlistener("click", function ColorPickerComponent_Template_button_click_3_listener() { return ctx.toggle(); });
            i0.ɵɵelement(4, "span", 4);
            i0.ɵɵtemplate(5, ColorPickerComponent_Conditional_5_Template, 2, 1, "span", 5);
            i0.ɵɵelementStart(6, "span", 6);
            i0.ɵɵtext(7, "\u2304");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(8, ColorPickerComponent_Conditional_8_Template, 2, 1, "button", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, ColorPickerComponent_Conditional_9_Template, 6, 3, "div", 8);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-color-picker--disabled", ctx.effectiveDisabled());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("id", ctx.effectiveId())("disabled", ctx.effectiveDisabled());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel())("aria-expanded", ctx.isOpen());
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("background-color", ctx.value() || "transparent");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showInput() ? 5 : -1);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.clearable() && ctx.value() ? 8 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isOpen() ? 9 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-color-picker[_ngcontent-%COMP%]{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-color-picker__label[_ngcontent-%COMP%]{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-color-picker__control[_ngcontent-%COMP%]{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-color-picker__trigger[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;flex:1;min-width:0;height:42px;padding:0 10px;border:0;border-radius:inherit;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:left;cursor:pointer}.orc-color-picker__trigger[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-color-picker__swatch[_ngcontent-%COMP%]{width:22px;height:22px;flex:0 0 auto;border:1px solid rgba(0,0,0,.16);border-radius:50%;background-image:linear-gradient(45deg,#ddd 25%,transparent 25%),linear-gradient(-45deg,#ddd 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#ddd 75%),linear-gradient(-45deg,transparent 75%,#ddd 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0}.orc-color-picker__value[_ngcontent-%COMP%]{min-width:0;overflow:hidden;color:var(--orc-font-secondary, #666);font-size:13px;text-overflow:ellipsis;white-space:nowrap}.orc-color-picker__chevron[_ngcontent-%COMP%]{margin-left:auto}.orc-color-picker__clear[_ngcontent-%COMP%]{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-font-secondary, #666);font-size:20px;cursor:pointer}.orc-color-picker__panel[_ngcontent-%COMP%]{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + 4px);left:0;display:grid;gap:12px;width:min(260px,100%);padding:12px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12))}.orc-color-picker__native[_ngcontent-%COMP%]{width:100%;height:42px;padding:0;border:0;background:transparent;cursor:pointer}.orc-color-picker__text[_ngcontent-%COMP%]{width:100%;min-height:36px;padding:0 8px;box-sizing:border-box;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-sm, 6px);background:var(--fill-modal, #fff);color:var(--orc-font-main, #141414)}.orc-color-picker__presets[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.orc-color-picker__preset[_ngcontent-%COMP%]{width:30px;height:30px;padding:0;border:1px solid rgba(0,0,0,.16);border-radius:50%;cursor:pointer}.orc-color-picker__preset[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-color-picker__preset--active[_ngcontent-%COMP%]{box-shadow:0 0 0 2px var(--fill-modal, #fff),0 0 0 4px var(--orc-color-azul-eletrico, #1c6aed)}.orc-color-picker--disabled[_ngcontent-%COMP%]{opacity:.55}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColorPickerComponent, [{
        type: Component,
        args: [{ selector: 'orc-color-picker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ColorPickerComponent), multi: true }], template: "<div class=\"orc-color-picker\" [class.orc-color-picker--disabled]=\"effectiveDisabled()\">\n  @if (label()) { <label class=\"orc-color-picker__label\" [for]=\"effectiveId()\">{{ label() }}</label> }\n  <div class=\"orc-color-picker__control\">\n    <button type=\"button\" class=\"orc-color-picker__trigger\" [id]=\"effectiveId()\" [disabled]=\"effectiveDisabled()\" [attr.aria-label]=\"ariaLabel()\" [attr.aria-expanded]=\"isOpen()\" (click)=\"toggle()\">\n      <span class=\"orc-color-picker__swatch\" [style.background-color]=\"value() || 'transparent'\" aria-hidden=\"true\"></span>\n      @if (showInput()) { <span class=\"orc-color-picker__value\">{{ value() || 'Sem cor' }}</span> }\n      <span class=\"orc-color-picker__chevron\" aria-hidden=\"true\">\u2304</span>\n    </button>\n    @if (clearable() && value()) { <button type=\"button\" class=\"orc-color-picker__clear\" (click)=\"clear()\" [disabled]=\"effectiveDisabled()\" aria-label=\"Remover cor\">\u00D7</button> }\n  </div>\n  @if (isOpen()) {\n    <div class=\"orc-color-picker__panel\" role=\"dialog\" aria-label=\"Paleta de cores\">\n      <input class=\"orc-color-picker__native\" type=\"color\" [value]=\"nativeValue()\" (input)=\"onNativeColor($event)\" [disabled]=\"effectiveDisabled()\" aria-label=\"Seletor nativo de cor\" />\n      @if (showInput()) { <input class=\"orc-color-picker__text\" type=\"text\" [value]=\"value()\" (input)=\"onTextInput($event)\" aria-label=\"C\u00F3digo hexadecimal\" inputmode=\"text\" /> }\n      <div class=\"orc-color-picker__presets\" aria-label=\"Cores predefinidas\">\n        @for (color of presets(); track color) { <button type=\"button\" class=\"orc-color-picker__preset\" [style.background-color]=\"color\" [class.orc-color-picker__preset--active]=\"value().toUpperCase() === color.toUpperCase()\" [attr.aria-label]=\"color\" (click)=\"selectColor(color)\"></button> }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-color-picker{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-color-picker__label{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-color-picker__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-color-picker__trigger{display:flex;align-items:center;gap:8px;flex:1;min-width:0;height:42px;padding:0 10px;border:0;border-radius:inherit;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:left;cursor:pointer}.orc-color-picker__trigger:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-color-picker__swatch{width:22px;height:22px;flex:0 0 auto;border:1px solid rgba(0,0,0,.16);border-radius:50%;background-image:linear-gradient(45deg,#ddd 25%,transparent 25%),linear-gradient(-45deg,#ddd 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#ddd 75%),linear-gradient(-45deg,transparent 75%,#ddd 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0}.orc-color-picker__value{min-width:0;overflow:hidden;color:var(--orc-font-secondary, #666);font-size:13px;text-overflow:ellipsis;white-space:nowrap}.orc-color-picker__chevron{margin-left:auto}.orc-color-picker__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-font-secondary, #666);font-size:20px;cursor:pointer}.orc-color-picker__panel{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + 4px);left:0;display:grid;gap:12px;width:min(260px,100%);padding:12px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12))}.orc-color-picker__native{width:100%;height:42px;padding:0;border:0;background:transparent;cursor:pointer}.orc-color-picker__text{width:100%;min-height:36px;padding:0 8px;box-sizing:border-box;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-sm, 6px);background:var(--fill-modal, #fff);color:var(--orc-font-main, #141414)}.orc-color-picker__presets{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.orc-color-picker__preset{width:30px;height:30px;padding:0;border:1px solid rgba(0,0,0,.16);border-radius:50%;cursor:pointer}.orc-color-picker__preset:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-color-picker__preset--active{box-shadow:0 0 0 2px var(--fill-modal, #fff),0 0 0 4px var(--orc-color-azul-eletrico, #1c6aed)}.orc-color-picker--disabled{opacity:.55}\n"] }]
    }], null, { onDocumentClick: [{
            type: HostListener,
            args: ['document:click', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ColorPickerComponent, { className: "ColorPickerComponent", filePath: "color-picker.component.ts", lineNumber: 18 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ColorPickerComponent };
//# sourceMappingURL=ciag-orchestra-color-picker.mjs.map
