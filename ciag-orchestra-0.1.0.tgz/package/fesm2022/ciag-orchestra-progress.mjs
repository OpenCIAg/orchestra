import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

function ProgressBarComponent_Conditional_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
function ProgressBarComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.formattedValue());
} }
function ProgressBarComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵtemplate(1, ProgressBarComponent_Conditional_1_Conditional_1_Template, 2, 1, "span", 4)(2, ProgressBarComponent_Conditional_1_Conditional_2_Template, 2, 1, "span", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.label() ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.showValue() && !ctx_r0.isIndeterminate() ? 2 : -1);
} }
function ProgressBarComponent_Conditional_2_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 7);
} if (rf & 2) {
    const seg_r2 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("background-color", seg_r2 <= ctx_r0.currentSegment() ? ctx_r0.customColor() || null : ctx_r0.customTrackColor() || null)("height", ctx_r0.customHeight() ? ctx_r0.customHeight() + (ctx_r0.customHeight().toString().endsWith("px") ? "" : "px") : null);
    i0.ɵɵclassProp("orc-progress-bar__segment-item--active", seg_r2 <= ctx_r0.currentSegment());
} }
function ProgressBarComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵrepeaterCreate(1, ProgressBarComponent_Conditional_2_For_2_Template, 1, 6, "div", 6, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-valuenow", ctx_r0.currentSegment())("aria-valuemin", 1)("aria-valuemax", ctx_r0.segmentArray().length)("aria-label", ctx_r0.ariaLabel() || ctx_r0.label() || "Etapas do progresso")("aria-valuetext", ctx_r0.ariaValueText() || "Etapa " + ctx_r0.currentSegment() + " de " + ctx_r0.segmentArray().length);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r0.segmentArray());
} }
function ProgressBarComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵelement(1, "div", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("background-color", ctx_r0.customTrackColor() || null)("height", ctx_r0.customHeight() ? ctx_r0.customHeight() + (ctx_r0.customHeight().toString().endsWith("px") ? "" : "px") : null);
    i0.ɵɵattribute("aria-valuenow", ctx_r0.isIndeterminate() ? null : ctx_r0.normalizedValue())("aria-valuemin", ctx_r0.isIndeterminate() ? null : 0)("aria-valuemax", ctx_r0.isIndeterminate() ? null : 100)("aria-label", ctx_r0.ariaLabel() || ctx_r0.label() || "Progresso")("aria-valuetext", ctx_r0.ariaValueText() || (ctx_r0.isIndeterminate() ? "Carregando..." : ctx_r0.formattedValue()));
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("width", ctx_r0.isIndeterminate() ? null : ctx_r0.normalizedValue() + "%")("background-color", ctx_r0.customColor() || null);
} }
class ProgressBarComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    /** Valor percentual atual do progresso (0 a 100) */
    value = input(0);
    /** Modo de operação: 'determinate' (valor numérico) ou 'indeterminate' (animação contínua) */
    mode = input('determinate');
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    variant = input('primary');
    /** Espessura / tamanho da barra: 'sm' (4px) | 'md' (8px - padrão Figma) | 'lg' (12px) */
    size = input('md');
    /** Rótulo textual opcional exibido no topo à esquerda (ex: 'Progresso', 'Upload') */
    label = input('');
    /** Exibe a porcentagem numérica no topo à direita */
    showValue = input(false);
    /** Prefixo opcional para exibição de valor (ex: '$') */
    valuePrefix = input('');
    /** Sufixo para exibição de valor (padrão: '%') */
    valueSuffix = input('%');
    /** Cantos arredondados tipo pílula (padrão Figma: true) */
    rounded = input(true);
    /** Suporte a etapas segmentadas (ex: 3 barras discretas) */
    segments = input(0);
    /** Etapa ativa atual no modo segmentado (1-indexed ou 0-indexed) */
    currentSegment = input(0);
    /** Altura customizada (ex: '6px' ou número 6) */
    customHeight = input('');
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    customColor = input('');
    /** Cor customizada da trilha / fundo da barra */
    customTrackColor = input('');
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    ariaLabel = input('');
    /** Sobrescreve a descrição audível aria-valuetext */
    ariaValueText = input('');
    // ── Computeds Reativos ────────────────────────────────────
    isIndeterminate = computed(() => this.mode() === 'indeterminate');
    normalizedValue = computed(() => {
        const val = Number(this.value());
        if (isNaN(val))
            return 0;
        return Math.min(100, Math.max(0, val));
    });
    formattedValue = computed(() => {
        return `${this.valuePrefix()}${Math.round(this.normalizedValue())}${this.valueSuffix()}`;
    });
    hasHeader = computed(() => {
        return Boolean(this.label() || this.showValue());
    });
    segmentArray = computed(() => {
        const total = this.segments();
        if (total <= 0)
            return [];
        return Array.from({ length: total }, (_, i) => i + 1);
    });
    static ɵfac = function ProgressBarComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ProgressBarComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ProgressBarComponent, selectors: [["orc-progress-bar"]], inputs: { value: [1, "value"], mode: [1, "mode"], variant: [1, "variant"], size: [1, "size"], label: [1, "label"], showValue: [1, "showValue"], valuePrefix: [1, "valuePrefix"], valueSuffix: [1, "valueSuffix"], rounded: [1, "rounded"], segments: [1, "segments"], currentSegment: [1, "currentSegment"], customHeight: [1, "customHeight"], customColor: [1, "customColor"], customTrackColor: [1, "customTrackColor"], ariaLabel: [1, "ariaLabel"], ariaValueText: [1, "ariaValueText"] }, decls: 4, vars: 22, consts: [[1, "orc-progress-bar-host"], [1, "orc-progress-bar__header"], ["role", "progressbar", 1, "orc-progress-bar__segments"], ["role", "progressbar", 1, "orc-progress-bar__track", 3, "background-color", "height"], [1, "orc-progress-bar__label"], [1, "orc-progress-bar__value"], [1, "orc-progress-bar__segment-item", 3, "orc-progress-bar__segment-item--active", "background-color", "height"], [1, "orc-progress-bar__segment-item"], ["role", "progressbar", 1, "orc-progress-bar__track"], [1, "orc-progress-bar__fill"]], template: function ProgressBarComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ProgressBarComponent_Conditional_1_Template, 3, 2, "div", 1)(2, ProgressBarComponent_Conditional_2_Template, 3, 5, "div", 2)(3, ProgressBarComponent_Conditional_3_Template, 2, 13, "div", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-progress-bar--rounded", ctx.rounded())("orc-progress-bar--sm", ctx.size() === "sm")("orc-progress-bar--md", ctx.size() === "md")("orc-progress-bar--lg", ctx.size() === "lg")("orc-progress-bar--primary", ctx.variant() === "primary")("orc-progress-bar--neutral", ctx.variant() === "neutral")("orc-progress-bar--success", ctx.variant() === "success")("orc-progress-bar--warning", ctx.variant() === "warning")("orc-progress-bar--error", ctx.variant() === "error" || ctx.variant() === "danger")("orc-progress-bar--indeterminate", ctx.isIndeterminate());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.hasHeader() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.segmentArray().length > 0 ? 2 : 3);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-progress-bar-host[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;width:100%;box-sizing:border-box}.orc-progress-bar-host.orc-progress-bar--primary[_ngcontent-%COMP%]{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-bar-host.orc-progress-bar--neutral[_ngcontent-%COMP%]{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-bar-host.orc-progress-bar--success[_ngcontent-%COMP%]{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-bar-host.orc-progress-bar--warning[_ngcontent-%COMP%]{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-bar-host.orc-progress-bar--error[_ngcontent-%COMP%]{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-bar-host.orc-progress-bar--sm[_ngcontent-%COMP%]{--progress-height: 4px}.orc-progress-bar-host.orc-progress-bar--md[_ngcontent-%COMP%]{--progress-height: 8px}.orc-progress-bar-host.orc-progress-bar--lg[_ngcontent-%COMP%]{--progress-height: 12px}.orc-progress-bar-host.orc-progress-bar--rounded[_ngcontent-%COMP%]   .orc-progress-bar__track[_ngcontent-%COMP%], .orc-progress-bar-host.orc-progress-bar--rounded[_ngcontent-%COMP%]   .orc-progress-bar__fill[_ngcontent-%COMP%], .orc-progress-bar-host.orc-progress-bar--rounded[_ngcontent-%COMP%]   .orc-progress-bar__segment-item[_ngcontent-%COMP%]{border-radius:9999px}.orc-progress-bar__header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;min-height:16px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:12px;line-height:16px;color:var(--orc-font-secondary, #58595b)}.orc-progress-bar__label[_ngcontent-%COMP%]{font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-progress-bar__value[_ngcontent-%COMP%]{font-weight:400;font-variant-numeric:tabular-nums;margin-left:auto;white-space:nowrap}.orc-progress-bar__track[_ngcontent-%COMP%]{position:relative;width:100%;height:var(--progress-height, 8px);background-color:var(--orc-border, #d9d9d9);overflow:hidden;box-sizing:border-box}.orc-progress-bar__fill[_ngcontent-%COMP%]{height:100%;background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));transition:width .35s cubic-bezier(.4,0,.2,1);box-sizing:border-box}.orc-progress-bar--indeterminate[_ngcontent-%COMP%]   .orc-progress-bar__fill[_ngcontent-%COMP%]{position:absolute;top:0;bottom:0;width:auto;will-change:left,right;animation:_ngcontent-%COMP%_orc-indeterminate-bar 1.8s cubic-bezier(.65,.815,.735,.395) infinite}@keyframes _ngcontent-%COMP%_orc-indeterminate-bar{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}.orc-progress-bar__segments[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;width:100%}.orc-progress-bar__segment-item[_ngcontent-%COMP%]{flex:1;height:var(--progress-height, 6px);background-color:var(--orc-border, #d9d9d9);transition:background-color .3s ease}.orc-progress-bar__segment-item--active[_ngcontent-%COMP%]{background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed))}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProgressBarComponent, [{
        type: Component,
        args: [{ selector: 'orc-progress-bar', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-progress-bar-host\"\n  [class.orc-progress-bar--rounded]=\"rounded()\"\n  [class.orc-progress-bar--sm]=\"size() === 'sm'\"\n  [class.orc-progress-bar--md]=\"size() === 'md'\"\n  [class.orc-progress-bar--lg]=\"size() === 'lg'\"\n  [class.orc-progress-bar--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-bar--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-bar--success]=\"variant() === 'success'\"\n  [class.orc-progress-bar--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-bar--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-bar--indeterminate]=\"isIndeterminate()\"\n>\n  <!-- Header (Label & Valor num\u00E9rico) -->\n  @if (hasHeader()) {\n    <div class=\"orc-progress-bar__header\">\n      @if (label()) {\n        <span class=\"orc-progress-bar__label\">{{ label() }}</span>\n      }\n      @if (showValue() && !isIndeterminate()) {\n        <span class=\"orc-progress-bar__value\">{{ formattedValue() }}</span>\n      }\n    </div>\n  }\n\n  <!-- Segmented Bars Mode -->\n  @if (segmentArray().length > 0) {\n    <div\n      class=\"orc-progress-bar__segments\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"currentSegment()\"\n      [attr.aria-valuemin]=\"1\"\n      [attr.aria-valuemax]=\"segmentArray().length\"\n      [attr.aria-label]=\"ariaLabel() || label() || 'Etapas do progresso'\"\n      [attr.aria-valuetext]=\"ariaValueText() || ('Etapa ' + currentSegment() + ' de ' + segmentArray().length)\"\n    >\n      @for (seg of segmentArray(); track seg) {\n        <div\n          class=\"orc-progress-bar__segment-item\"\n          [class.orc-progress-bar__segment-item--active]=\"seg <= currentSegment()\"\n          [style.background-color]=\"seg <= currentSegment() ? (customColor() || null) : (customTrackColor() || null)\"\n          [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n        ></div>\n      }\n    </div>\n  } @else {\n    <!-- Continuous Progress Bar Track -->\n    <div\n      class=\"orc-progress-bar__track\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n      [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n      [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n      [attr.aria-label]=\"ariaLabel() || label() || 'Progresso'\"\n      [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? 'Carregando...' : formattedValue())\"\n      [style.background-color]=\"customTrackColor() || null\"\n      [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n    >\n      <div\n        class=\"orc-progress-bar__fill\"\n        [style.width]=\"isIndeterminate() ? null : (normalizedValue() + '%')\"\n        [style.background-color]=\"customColor() || null\"\n      ></div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-progress-bar-host{display:flex;flex-direction:column;gap:4px;width:100%;box-sizing:border-box}.orc-progress-bar-host.orc-progress-bar--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-bar-host.orc-progress-bar--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-bar-host.orc-progress-bar--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-bar-host.orc-progress-bar--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-bar-host.orc-progress-bar--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-bar-host.orc-progress-bar--sm{--progress-height: 4px}.orc-progress-bar-host.orc-progress-bar--md{--progress-height: 8px}.orc-progress-bar-host.orc-progress-bar--lg{--progress-height: 12px}.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__track,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__fill,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__segment-item{border-radius:9999px}.orc-progress-bar__header{display:flex;align-items:center;justify-content:space-between;min-height:16px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:12px;line-height:16px;color:var(--orc-font-secondary, #58595b)}.orc-progress-bar__label{font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-progress-bar__value{font-weight:400;font-variant-numeric:tabular-nums;margin-left:auto;white-space:nowrap}.orc-progress-bar__track{position:relative;width:100%;height:var(--progress-height, 8px);background-color:var(--orc-border, #d9d9d9);overflow:hidden;box-sizing:border-box}.orc-progress-bar__fill{height:100%;background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));transition:width .35s cubic-bezier(.4,0,.2,1);box-sizing:border-box}.orc-progress-bar--indeterminate .orc-progress-bar__fill{position:absolute;top:0;bottom:0;width:auto;will-change:left,right;animation:orc-indeterminate-bar 1.8s cubic-bezier(.65,.815,.735,.395) infinite}@keyframes orc-indeterminate-bar{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}.orc-progress-bar__segments{display:flex;align-items:center;gap:6px;width:100%}.orc-progress-bar__segment-item{flex:1;height:var(--progress-height, 6px);background-color:var(--orc-border, #d9d9d9);transition:background-color .3s ease}.orc-progress-bar__segment-item--active{background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed))}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ProgressBarComponent, { className: "ProgressBarComponent", filePath: "progress-bar.component.ts", lineNumber: 18 }); })();

const _c0 = ["*"];
function ProgressCircleComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.formattedValue());
} }
function ProgressCircleComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
class ProgressCircleComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    /** Valor percentual atual do progresso circular (0 a 100) */
    value = input(0);
    /** Modo de operação: 'determinate' (valor exato) ou 'indeterminate' (spinner contínuo) */
    mode = input('determinate');
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    variant = input('primary');
    /** Dimensão do círculo: 'sm' (32px) | 'md' (48px) | 'lg' (64px) | 'xl' (96px) ou número em px */
    size = input('md');
    /** Espessura do traço (em px). Se omitido, é calculado proporcionalmente ao tamanho */
    strokeWidth = input(undefined);
    /** Exibe o valor numérico centralizado dentro do círculo */
    showValue = input(false);
    /** Cantos arredondados na ponta do arco (stroke-linecap: round) */
    rounded = input(true);
    /** Prefixo opcional para exibição de valor (ex: '$') */
    valuePrefix = input('');
    /** Sufixo para exibição de valor (padrão: '%') */
    valueSuffix = input('%');
    /** Rótulo textual opcional */
    label = input('');
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    customColor = input('');
    /** Cor customizada da trilha de fundo */
    customTrackColor = input('');
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    ariaLabel = input('');
    /** Sobrescreve a descrição audível aria-valuetext */
    ariaValueText = input('');
    // ── Computeds Reativos ────────────────────────────────────
    isIndeterminate = computed(() => this.mode() === 'indeterminate');
    normalizedValue = computed(() => {
        const val = Number(this.value());
        if (isNaN(val))
            return 0;
        return Math.min(100, Math.max(0, val));
    });
    pixelSize = computed(() => {
        const s = this.size();
        if (typeof s === 'number')
            return s > 0 ? s : 48;
        switch (s) {
            case 'sm': return 32;
            case 'md': return 48;
            case 'lg': return 64;
            case 'xl': return 96;
            default: return 48;
        }
    });
    computedStrokeWidth = computed(() => {
        const custom = this.strokeWidth();
        if (custom !== undefined && custom > 0)
            return custom;
        const s = this.pixelSize();
        if (s <= 32)
            return 3;
        if (s <= 48)
            return 4;
        if (s <= 64)
            return 5;
        return 6;
    });
    center = computed(() => this.pixelSize() / 2);
    radius = computed(() => {
        return Math.max(1, (this.pixelSize() - this.computedStrokeWidth()) / 2);
    });
    circumference = computed(() => {
        return 2 * Math.PI * this.radius();
    });
    strokeDashOffset = computed(() => {
        if (this.isIndeterminate())
            return 0;
        const progress = this.normalizedValue() / 100;
        return this.circumference() * (1 - progress);
    });
    formattedValue = computed(() => {
        return `${this.valuePrefix()}${Math.round(this.normalizedValue())}${this.valueSuffix()}`;
    });
    static ɵfac = function ProgressCircleComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ProgressCircleComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ProgressCircleComponent, selectors: [["orc-progress-circle"]], inputs: { value: [1, "value"], mode: [1, "mode"], variant: [1, "variant"], size: [1, "size"], strokeWidth: [1, "strokeWidth"], showValue: [1, "showValue"], rounded: [1, "rounded"], valuePrefix: [1, "valuePrefix"], valueSuffix: [1, "valueSuffix"], label: [1, "label"], customColor: [1, "customColor"], customTrackColor: [1, "customTrackColor"], ariaLabel: [1, "ariaLabel"], ariaValueText: [1, "ariaValueText"] }, ngContentSelectors: _c0, decls: 7, vars: 44, consts: [[1, "orc-progress-circle-host"], ["role", "progressbar", 1, "orc-progress-circle__svg"], [1, "orc-progress-circle__track"], [1, "orc-progress-circle__fill"], [1, "orc-progress-circle__content"], [1, "orc-progress-circle__value"]], template: function ProgressCircleComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(1, "svg", 1);
            i0.ɵɵelement(2, "circle", 2)(3, "circle", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵnamespaceHTML();
            i0.ɵɵelementStart(4, "div", 4);
            i0.ɵɵtemplate(5, ProgressCircleComponent_Conditional_5_Template, 2, 1, "span", 5)(6, ProgressCircleComponent_Conditional_6_Template, 1, 0);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵstyleProp("width", ctx.pixelSize(), "px")("height", ctx.pixelSize(), "px");
            i0.ɵɵclassProp("orc-progress-circle--primary", ctx.variant() === "primary")("orc-progress-circle--neutral", ctx.variant() === "neutral")("orc-progress-circle--success", ctx.variant() === "success")("orc-progress-circle--warning", ctx.variant() === "warning")("orc-progress-circle--error", ctx.variant() === "error" || ctx.variant() === "danger")("orc-progress-circle--indeterminate", ctx.isIndeterminate());
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("width", ctx.pixelSize(), "px")("height", ctx.pixelSize(), "px");
            i0.ɵɵattribute("viewBox", "0 0 " + ctx.pixelSize() + " " + ctx.pixelSize())("aria-valuenow", ctx.isIndeterminate() ? null : ctx.normalizedValue())("aria-valuemin", ctx.isIndeterminate() ? null : 0)("aria-valuemax", ctx.isIndeterminate() ? null : 100)("aria-label", ctx.ariaLabel() || ctx.label() || "Progresso circular")("aria-valuetext", ctx.ariaValueText() || (ctx.isIndeterminate() ? "Carregando..." : ctx.formattedValue()));
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("stroke", ctx.customTrackColor() || null);
            i0.ɵɵattribute("cx", ctx.center())("cy", ctx.center())("r", ctx.radius())("stroke-width", ctx.computedStrokeWidth());
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("stroke", ctx.customColor() || null);
            i0.ɵɵattribute("cx", ctx.center())("cy", ctx.center())("r", ctx.radius())("stroke-width", ctx.computedStrokeWidth())("stroke-dasharray", ctx.circumference())("stroke-dashoffset", ctx.strokeDashOffset())("stroke-linecap", ctx.rounded() ? "round" : "butt");
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("font-size", ctx.pixelSize() <= 32 ? 9 : ctx.pixelSize() <= 48 ? 11 : ctx.pixelSize() <= 64 ? 14 : 18, "px");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showValue() && !ctx.isIndeterminate() ? 5 : 6);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:inline-block;vertical-align:middle}.orc-progress-circle-host[_ngcontent-%COMP%]{position:relative;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box}.orc-progress-circle-host.orc-progress-circle--primary[_ngcontent-%COMP%]{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-circle-host.orc-progress-circle--neutral[_ngcontent-%COMP%]{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-circle-host.orc-progress-circle--success[_ngcontent-%COMP%]{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-circle-host.orc-progress-circle--warning[_ngcontent-%COMP%]{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-circle-host.orc-progress-circle--error[_ngcontent-%COMP%]{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-circle__svg[_ngcontent-%COMP%]{display:block;transform:rotate(-90deg);transform-origin:50% 50%}.orc-progress-circle__track[_ngcontent-%COMP%]{stroke:var(--orc-border, #d9d9d9);fill:none}.orc-progress-circle__fill[_ngcontent-%COMP%]{stroke:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));fill:none;transition:stroke-dashoffset .35s cubic-bezier(.4,0,.2,1)}.orc-progress-circle--indeterminate[_ngcontent-%COMP%]   .orc-progress-circle__svg[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_orc-circle-rotate 1.6s linear infinite}.orc-progress-circle--indeterminate[_ngcontent-%COMP%]   .orc-progress-circle__fill[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_orc-circle-dash 1.6s ease-in-out infinite;transition:none}@keyframes _ngcontent-%COMP%_orc-circle-rotate{to{transform:rotate(270deg)}}@keyframes _ngcontent-%COMP%_orc-circle-dash{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35px}to{stroke-dasharray:89,200;stroke-dashoffset:-124px}}.orc-progress-circle__content[_ngcontent-%COMP%]{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;font-variant-numeric:tabular-nums;color:var(--orc-font-main, #141414)}.orc-progress-circle__value[_ngcontent-%COMP%]{line-height:1}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProgressCircleComponent, [{
        type: Component,
        args: [{ selector: 'orc-progress-circle', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-progress-circle-host\"\n  [class.orc-progress-circle--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-circle--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-circle--success]=\"variant() === 'success'\"\n  [class.orc-progress-circle--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-circle--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-circle--indeterminate]=\"isIndeterminate()\"\n  [style.width.px]=\"pixelSize()\"\n  [style.height.px]=\"pixelSize()\"\n>\n  <svg\n    class=\"orc-progress-circle__svg\"\n    [attr.viewBox]=\"'0 0 ' + pixelSize() + ' ' + pixelSize()\"\n    [style.width.px]=\"pixelSize()\"\n    [style.height.px]=\"pixelSize()\"\n    role=\"progressbar\"\n    [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n    [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n    [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n    [attr.aria-label]=\"ariaLabel() || label() || 'Progresso circular'\"\n    [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? 'Carregando...' : formattedValue())\"\n  >\n    <!-- Trilha de fundo (Track) -->\n    <circle\n      class=\"orc-progress-circle__track\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [style.stroke]=\"customTrackColor() || null\"\n    />\n\n    <!-- Arco de preenchimento (Fill) -->\n    <circle\n      class=\"orc-progress-circle__fill\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [attr.stroke-dasharray]=\"circumference()\"\n      [attr.stroke-dashoffset]=\"strokeDashOffset()\"\n      [attr.stroke-linecap]=\"rounded() ? 'round' : 'butt'\"\n      [style.stroke]=\"customColor() || null\"\n    />\n  </svg>\n\n  <!-- Conte\u00FAdo centralizado (Porcentagem ou custom template) -->\n  <div class=\"orc-progress-circle__content\" [style.font-size.px]=\"pixelSize() <= 32 ? 9 : pixelSize() <= 48 ? 11 : pixelSize() <= 64 ? 14 : 18\">\n    @if (showValue() && !isIndeterminate()) {\n      <span class=\"orc-progress-circle__value\">{{ formattedValue() }}</span>\n    } @else {\n      <ng-content></ng-content>\n    }\n  </div>\n</div>\n", styles: [":host{display:inline-block;vertical-align:middle}.orc-progress-circle-host{position:relative;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box}.orc-progress-circle-host.orc-progress-circle--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-circle-host.orc-progress-circle--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-circle-host.orc-progress-circle--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-circle-host.orc-progress-circle--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-circle-host.orc-progress-circle--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-circle__svg{display:block;transform:rotate(-90deg);transform-origin:50% 50%}.orc-progress-circle__track{stroke:var(--orc-border, #d9d9d9);fill:none}.orc-progress-circle__fill{stroke:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));fill:none;transition:stroke-dashoffset .35s cubic-bezier(.4,0,.2,1)}.orc-progress-circle--indeterminate .orc-progress-circle__svg{animation:orc-circle-rotate 1.6s linear infinite}.orc-progress-circle--indeterminate .orc-progress-circle__fill{animation:orc-circle-dash 1.6s ease-in-out infinite;transition:none}@keyframes orc-circle-rotate{to{transform:rotate(270deg)}}@keyframes orc-circle-dash{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35px}to{stroke-dasharray:89,200;stroke-dashoffset:-124px}}.orc-progress-circle__content{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;font-variant-numeric:tabular-nums;color:var(--orc-font-main, #141414)}.orc-progress-circle__value{line-height:1}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ProgressCircleComponent, { className: "ProgressCircleComponent", filePath: "progress-circle.component.ts", lineNumber: 18 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ProgressBarComponent, ProgressCircleComponent };
//# sourceMappingURL=ciag-orchestra-progress.mjs.map
