import * as i0 from '@angular/core';
import { input, output, computed, ChangeDetectionStrategy, Component, signal, forwardRef, HostListener, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { ProgressBarComponent } from '@ciag/orchestra/progress';
import { ButtonComponent } from '@ciag/orchestra/button';

function FileItemComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 3);
    i0.ɵɵelement(1, "path", 14)(2, "polyline", 15)(3, "line", 16)(4, "line", 17)(5, "polyline", 18);
    i0.ɵɵelementEnd();
} }
function FileItemComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 3);
    i0.ɵɵelement(1, "rect", 19)(2, "circle", 20)(3, "polyline", 21);
    i0.ɵɵelementEnd();
} }
function FileItemComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 3);
    i0.ɵɵelement(1, "path", 14)(2, "polyline", 15);
    i0.ɵɵelementEnd();
} }
function FileItemComponent_Conditional_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12)(1, "div", 22)(2, "span", 13);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 13);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(6, "orc-progress-bar", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1("", ctx_r0.fileData().formattedSize, " | Calculando restante...");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("", ctx_r0.fileData().progress, "%");
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", ctx_r0.fileData().progress);
} }
function FileItemComponent_Conditional_16_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0, " Enviado com sucesso ");
} }
function FileItemComponent_Conditional_16_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 24);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.fileData().errorMessage || "Falha no envio");
} }
function FileItemComponent_Conditional_16_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0, " Pendente ");
} }
function FileItemComponent_Conditional_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, FileItemComponent_Conditional_16_Conditional_2_Template, 1, 0)(3, FileItemComponent_Conditional_16_Conditional_3_Template, 2, 1, "span", 24)(4, FileItemComponent_Conditional_16_Conditional_4_Template, 1, 0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.fileData().formattedSize, " | 100% | ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.fileData().status === "success" ? 2 : ctx_r0.fileData().status === "error" ? 3 : 4);
} }
class FileItemComponent {
    // ── Inputs ──────────────────────────────────────────────────
    fileData = input.required();
    disabled = input(false);
    // ── Outputs ─────────────────────────────────────────────────
    remove = output();
    // ── Computeds ───────────────────────────────────────────────
    isImage = computed(() => {
        return this.fileData().type.startsWith('image/');
    });
    badgeVariant = computed(() => {
        switch (this.fileData().status) {
            case 'success': return 'soft';
            case 'error': return 'soft';
            default: return 'outline';
        }
    });
    badgeStatus = computed(() => {
        switch (this.fileData().status) {
            case 'success': return 'success';
            case 'error': return 'danger';
            case 'uploading': return 'primary';
            default: return 'neutral';
        }
    });
    showProgress = computed(() => {
        return this.fileData().status === 'uploading' || this.fileData().progress > 0;
    });
    // ── Handlers ────────────────────────────────────────────────
    onRemove() {
        if (this.disabled())
            return;
        this.remove.emit(this.fileData().id);
    }
    static ɵfac = function FileItemComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FileItemComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FileItemComponent, selectors: [["orc-file-item"]], inputs: { fileData: [1, "fileData"], disabled: [1, "disabled"] }, outputs: { remove: "remove" }, decls: 17, vars: 6, consts: [[1, "orc-file-item"], [1, "orc-file-item__icon-wrapper"], [1, "orc-file-item__icon"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-file-item__content"], [1, "orc-file-item__header"], [1, "orc-file-item__name", 3, "title"], [1, "orc-file-item__remove"], ["variant", "ghost", "size", "sm", "ariaLabel", "Remover arquivo", 3, "click", "iconOnly", "disabled"], ["iconLeft", "", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x1", "18", "y1", "6", "x2", "6", "y2", "18"], ["x1", "6", "y1", "6", "x2", "18", "y2", "18"], [1, "orc-file-item__progress-container"], [1, "orc-file-item__meta"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["x1", "16", "y1", "13", "x2", "8", "y2", "13"], ["x1", "16", "y1", "17", "x2", "8", "y2", "17"], ["points", "10 9 9 9 8 9"], ["x", "3", "y", "3", "width", "18", "height", "18", "rx", "2", "ry", "2"], ["cx", "8.5", "cy", "8.5", "r", "1.5"], ["points", "21 15 16 10 5 21"], [1, "orc-file-item__progress-text-row"], ["variant", "neutral", "size", "md", 3, "value"], [2, "color", "var(--color-error)"]], template: function FileItemComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "div", 2);
            i0.ɵɵtemplate(3, FileItemComponent_Conditional_3_Template, 6, 0, ":svg:svg", 3)(4, FileItemComponent_Conditional_4_Template, 4, 0, ":svg:svg", 3)(5, FileItemComponent_Conditional_5_Template, 3, 0, ":svg:svg", 3);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 4)(7, "div", 5)(8, "span", 6);
            i0.ɵɵtext(9);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "div", 7)(11, "orc-button", 8);
            i0.ɵɵlistener("click", function FileItemComponent_Template_orc_button_click_11_listener() { return ctx.onRemove(); });
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(12, "svg", 9);
            i0.ɵɵelement(13, "line", 10)(14, "line", 11);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(15, FileItemComponent_Conditional_15_Template, 7, 3, "div", 12)(16, FileItemComponent_Conditional_16_Template, 5, 2, "div", 13);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.fileData().type.includes("pdf") ? 3 : ctx.fileData().type.includes("image") ? 4 : 5);
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("title", ctx.fileData().name);
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.fileData().name);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("iconOnly", true)("disabled", ctx.disabled());
            i0.ɵɵadvance(4);
            i0.ɵɵconditional(ctx.fileData().status === "uploading" || ctx.fileData().progress > 0 && ctx.fileData().status !== "success" && ctx.fileData().status !== "error" ? 15 : 16);
        } }, dependencies: [CommonModule, ProgressBarComponent, ButtonComponent], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-file-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:15px;padding:10px;background-color:var(--bg-app);border-radius:var(--radius-md)}.orc-file-item__icon-wrapper[_ngcontent-%COMP%]{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center}.orc-file-item__icon[_ngcontent-%COMP%]{width:100%;height:100%;color:var(--text-secondary)}.orc-file-item__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-file-item__content[_ngcontent-%COMP%]{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}.orc-file-item__header[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;height:24px}.orc-file-item__name[_ngcontent-%COMP%]{font-weight:500;font-size:.875rem;line-height:20px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-file-item__remove[_ngcontent-%COMP%]{flex-shrink:0;width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-file-item__remove[_ngcontent-%COMP%]     .orc-button{padding:0!important;min-height:24px!important;min-width:24px!important}.orc-file-item__remove[_ngcontent-%COMP%]     .orc-button svg{width:16px!important;height:16px!important}.orc-file-item__progress-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px}.orc-file-item__progress-text-row[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;height:16px}.orc-file-item__meta[_ngcontent-%COMP%]{font-size:.75rem;color:var(--text-secondary);line-height:16px;white-space:nowrap}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileItemComponent, [{
        type: Component,
        args: [{ selector: 'orc-file-item', standalone: true, imports: [CommonModule, ProgressBarComponent, ButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-file-item\">\n  <!-- \u00CDcone (20x20) -->\n  <div class=\"orc-file-item__icon-wrapper\">\n    <div class=\"orc-file-item__icon\">\n      @if (fileData().type.includes('pdf')) {\n        <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n          <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n          <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n          <polyline points=\"10 9 9 9 8 9\"></polyline>\n        </svg>\n      } @else if (fileData().type.includes('image')) {\n        <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"2\" ry=\"2\"></rect>\n          <circle cx=\"8.5\" cy=\"8.5\" r=\"1.5\"></circle>\n          <polyline points=\"21 15 16 10 5 21\"></polyline>\n        </svg>\n      } @else {\n        <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n        </svg>\n      }\n    </div>\n  </div>\n\n  <!-- Conte\u00FAdo -->\n  <div class=\"orc-file-item__content\">\n    \n    <!-- Linha 1: T\u00EDtulo e Bot\u00E3o de Remover -->\n    <div class=\"orc-file-item__header\">\n      <span class=\"orc-file-item__name\" [title]=\"fileData().name\">{{ fileData().name }}</span>\n      <div class=\"orc-file-item__remove\">\n        <orc-button \n          variant=\"ghost\" \n          size=\"sm\" \n          [iconOnly]=\"true\" \n          [disabled]=\"disabled()\"\n          (click)=\"onRemove()\"\n          ariaLabel=\"Remover arquivo\"\n        >\n          <svg iconLeft viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      </div>\n    </div>\n\n    <!-- Linha 2: Status / Progresso -->\n    @if (fileData().status === 'uploading' || fileData().progress > 0 && fileData().status !== 'success' && fileData().status !== 'error') {\n      <div class=\"orc-file-item__progress-container\">\n        <div class=\"orc-file-item__progress-text-row\">\n          <span class=\"orc-file-item__meta\">{{ fileData().formattedSize }} | Calculando restante...</span>\n          <span class=\"orc-file-item__meta\">{{ fileData().progress }}%</span>\n        </div>\n        \n        <!-- Figma uses black progress bar (accent) -->\n        <orc-progress-bar \n          [value]=\"fileData().progress\" \n          variant=\"neutral\"\n          size=\"md\">\n        </orc-progress-bar>\n      </div>\n    } @else {\n      <!-- Estado de Sucesso ou Erro -->\n      <div class=\"orc-file-item__meta\">\n        {{ fileData().formattedSize }} | 100% | \n        @if (fileData().status === 'success') {\n          Enviado com sucesso\n        } @else if (fileData().status === 'error') {\n          <span style=\"color: var(--color-error)\">{{ fileData().errorMessage || 'Falha no envio' }}</span>\n        } @else {\n          Pendente\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-item{display:flex;align-items:center;gap:15px;padding:10px;background-color:var(--bg-app);border-radius:var(--radius-md)}.orc-file-item__icon-wrapper{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center}.orc-file-item__icon{width:100%;height:100%;color:var(--text-secondary)}.orc-file-item__icon svg{width:100%;height:100%}.orc-file-item__content{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}.orc-file-item__header{display:flex;align-items:flex-start;justify-content:space-between;height:24px}.orc-file-item__name{font-weight:500;font-size:.875rem;line-height:20px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-file-item__remove{flex-shrink:0;width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-file-item__remove ::ng-deep .orc-button{padding:0!important;min-height:24px!important;min-width:24px!important}.orc-file-item__remove ::ng-deep .orc-button svg{width:16px!important;height:16px!important}.orc-file-item__progress-container{display:flex;flex-direction:column;gap:4px}.orc-file-item__progress-text-row{display:flex;justify-content:space-between;align-items:center;height:16px}.orc-file-item__meta{font-size:.75rem;color:var(--text-secondary);line-height:16px;white-space:nowrap}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FileItemComponent, { className: "FileItemComponent", filePath: "file-item/file-item.component.ts", lineNumber: 16 }); })();

const _c0 = ["fileInput"];
const _forTrack0 = ($index, $item) => $item.id;
function FileUploaderComponent_Conditional_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.subLabel());
} }
function FileUploaderComponent_Conditional_16_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "orc-file-item", 17);
    i0.ɵɵlistener("remove", function FileUploaderComponent_Conditional_16_For_2_Template_orc_file_item_remove_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onRemoveFile($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const file_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("fileData", file_r4)("disabled", ctx_r1.isDisabled());
} }
function FileUploaderComponent_Conditional_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 15);
    i0.ɵɵrepeaterCreate(1, FileUploaderComponent_Conditional_16_For_2_Template, 1, 2, "orc-file-item", 16, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.files());
} }
class FileUploaderComponent {
    fileInputRef;
    // ── Inputs ──────────────────────────────────────────────────
    accept = input(''); // e.g., 'image/*,.pdf'
    multiple = input(true);
    maxFiles = input(10);
    maxFileSize = input(5); // In MB
    disabled = input(false);
    label = input('Clique ou arraste seus arquivos aqui');
    subLabel = input('Suporta imagens e PDFs');
    forceDragover = input(false);
    // ── Internal State (Signals) ────────────────────────────────
    files = signal([]);
    isDragging = signal(false);
    // ── CVA callbacks ───────────────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    // ── Computeds ───────────────────────────────────────────────
    isDisabled = computed(() => this.disabled());
    hasReachedMaxFiles = computed(() => {
        return this.multiple() ? this.files().length >= this.maxFiles() : this.files().length >= 1;
    });
    // ── CVA Methods ─────────────────────────────────────────────
    writeValue(value) {
        this.files.set(value || []);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        // handled via input optionally, but mostly via form group
    }
    // ── Drag & Drop Handlers ────────────────────────────────────
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        this.isDragging.set(true);
    }
    onDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        const droppedFiles = event.dataTransfer?.files;
        if (droppedFiles && droppedFiles.length > 0) {
            this.handleFiles(Array.from(droppedFiles));
        }
    }
    // ── User Actions ────────────────────────────────────────────
    onAreaClick() {
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        this.fileInputRef.nativeElement.click();
        this.onTouched();
    }
    onAreaKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.onAreaClick();
        }
    }
    onFileSelected(event) {
        const input = event.target;
        if (input.files && input.files.length > 0) {
            this.handleFiles(Array.from(input.files));
            input.value = ''; // Reset input to allow re-selecting same file
        }
    }
    onRemoveFile(id) {
        if (this.isDisabled())
            return;
        this.files.update(list => list.filter(f => f.id !== id));
        this.onChange(this.files());
    }
    // ── Logic ───────────────────────────────────────────────────
    handleFiles(newFiles) {
        const currentFiles = this.files();
        let filesToAdd = newFiles;
        if (!this.multiple()) {
            filesToAdd = [newFiles[0]];
        }
        else {
            const remainingSlots = this.maxFiles() - currentFiles.length;
            if (remainingSlots <= 0)
                return;
            filesToAdd = newFiles.slice(0, remainingSlots);
        }
        const newItems = filesToAdd.map(file => this.createFileItem(file));
        if (!this.multiple()) {
            this.files.set(newItems);
        }
        else {
            this.files.update(list => [...list, ...newItems]);
        }
        this.onChange(this.files());
    }
    createFileItem(file) {
        const isOverSize = file.size > this.maxFileSize() * 1024 * 1024;
        // Simplistic accept validation (for demo purposes)
        let isInvalidType = false;
        if (this.accept()) {
            const allowedTypes = this.accept().split(',').map(t => t.trim().toLowerCase());
            if (allowedTypes.length > 0 && !allowedTypes.includes('*/*')) {
                const fileExt = '.' + file.name.split('.').pop()?.toLowerCase();
                const fileType = file.type.toLowerCase();
                isInvalidType = !allowedTypes.some(type => {
                    if (type.startsWith('.'))
                        return fileExt === type;
                    if (type.endsWith('/*'))
                        return fileType.startsWith(type.replace('/*', ''));
                    return fileType === type;
                });
            }
        }
        let status = 'pending';
        let errorMessage = '';
        if (isOverSize) {
            status = 'error';
            errorMessage = `O arquivo excede o limite de ${this.maxFileSize()}MB`;
        }
        else if (isInvalidType) {
            status = 'error';
            errorMessage = 'Formato de arquivo não suportado';
        }
        return {
            id: Math.random().toString(36).substring(2, 11),
            file,
            name: file.name,
            size: file.size,
            formattedSize: this.formatBytes(file.size),
            type: file.type,
            progress: 0,
            status,
            errorMessage,
            previewUrl: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined
        };
    }
    formatBytes(bytes, decimals = 2) {
        if (bytes === 0)
            return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
    static ɵfac = function FileUploaderComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FileUploaderComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FileUploaderComponent, selectors: [["orc-file-uploader"]], viewQuery: function FileUploaderComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.fileInputRef = _t.first);
        } }, hostBindings: function FileUploaderComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("dragover", function FileUploaderComponent_dragover_HostBindingHandler($event) { return ctx.onDragOver($event); })("dragleave", function FileUploaderComponent_dragleave_HostBindingHandler($event) { return ctx.onDragLeave($event); })("drop", function FileUploaderComponent_drop_HostBindingHandler($event) { return ctx.onDrop($event); });
        } }, inputs: { accept: [1, "accept"], multiple: [1, "multiple"], maxFiles: [1, "maxFiles"], maxFileSize: [1, "maxFileSize"], disabled: [1, "disabled"], label: [1, "label"], subLabel: [1, "subLabel"], forceDragover: [1, "forceDragover"] }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => FileUploaderComponent),
                    multi: true
                }
            ])], decls: 17, vars: 13, consts: [["fileInput", ""], [1, "orc-file-uploader"], ["type", "file", "hidden", "", "aria-hidden", "true", 1, "orc-file-uploader__input", 3, "change", "accept", "multiple", "disabled"], ["role", "button", "tabindex", "0", "aria-label", "\u00C1rea de upload de arquivos", 1, "orc-file-uploader__dropzone", 3, "click", "keydown"], [1, "orc-file-uploader__dropzone-content"], [1, "orc-file-uploader__icon"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["x1", "16", "y1", "13", "x2", "8", "y2", "13"], ["x1", "16", "y1", "17", "x2", "8", "y2", "17"], ["points", "10 9 9 9 8 9"], [1, "orc-file-uploader__text"], [1, "orc-file-uploader__label"], [1, "orc-file-uploader__sublabel"], ["aria-live", "polite", 1, "orc-file-uploader__list"], [3, "fileData", "disabled"], [3, "remove", "fileData", "disabled"]], template: function FileUploaderComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1)(1, "input", 2, 0);
            i0.ɵɵlistener("change", function FileUploaderComponent_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFileSelected($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 3);
            i0.ɵɵlistener("click", function FileUploaderComponent_Template_div_click_3_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onAreaClick()); })("keydown", function FileUploaderComponent_Template_div_keydown_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onAreaKeyDown($event)); });
            i0.ɵɵelementStart(4, "div", 4)(5, "div", 5);
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(6, "svg", 6);
            i0.ɵɵelement(7, "path", 7)(8, "polyline", 8)(9, "line", 9)(10, "line", 10)(11, "polyline", 11);
            i0.ɵɵelementEnd()();
            i0.ɵɵnamespaceHTML();
            i0.ɵɵelementStart(12, "div", 12)(13, "span", 13);
            i0.ɵɵtext(14);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(15, FileUploaderComponent_Conditional_15_Template, 2, 1, "span", 14);
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(16, FileUploaderComponent_Conditional_16_Template, 3, 0, "div", 15);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-file-uploader--disabled", ctx.isDisabled());
            i0.ɵɵadvance();
            i0.ɵɵproperty("accept", ctx.accept())("multiple", ctx.multiple())("disabled", ctx.isDisabled() || ctx.hasReachedMaxFiles());
            i0.ɵɵadvance(2);
            i0.ɵɵclassProp("orc-file-uploader__dropzone--dragover", ctx.isDragging() || ctx.forceDragover())("orc-file-uploader__dropzone--disabled", ctx.isDisabled());
            i0.ɵɵattribute("aria-disabled", ctx.isDisabled() || ctx.hasReachedMaxFiles());
            i0.ɵɵadvance(11);
            i0.ɵɵtextInterpolate(ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.subLabel() ? 15 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.files().length > 0 ? 16 : -1);
        } }, dependencies: [CommonModule, FileItemComponent], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-file-uploader[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--space-4)}.orc-file-uploader--disabled[_ngcontent-%COMP%]{opacity:.6;pointer-events:none}.orc-file-uploader__dropzone[_ngcontent-%COMP%]{border:3px dashed var(--border-default);border-radius:16px;background-color:var(--bg-app);padding:var(--space-8);cursor:pointer;transition:all var(--transition-fast);outline:none}.orc-file-uploader__dropzone[_ngcontent-%COMP%]:hover, .orc-file-uploader__dropzone[_ngcontent-%COMP%]:focus-visible{border-color:var(--color-accent);background-color:var(--bg-subtle)}.orc-file-uploader__dropzone--dragover[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico);background-color:#1c6aed0a}.orc-file-uploader__dropzone--disabled[_ngcontent-%COMP%]{cursor:not-allowed;border-color:var(--border-default)!important;background-color:var(--bg-subtle)!important}.orc-file-uploader__dropzone-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--space-6)}.orc-file-uploader__icon[_ngcontent-%COMP%]{width:70px;height:70px;color:var(--text-secondary);display:flex;align-items:center;justify-content:center}.orc-file-uploader__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-file-uploader__text[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--space-3)}.orc-file-uploader__label[_ngcontent-%COMP%]{font-size:1rem;font-weight:400;color:var(--text-primary)}.orc-file-uploader__sublabel[_ngcontent-%COMP%]{font-size:1rem;font-weight:400;color:var(--text-secondary)}.orc-file-uploader__list[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--space-3);max-height:260px;overflow-y:auto;padding-right:4px}.orc-file-uploader__list[_ngcontent-%COMP%]::-webkit-scrollbar{width:6px}.orc-file-uploader__list[_ngcontent-%COMP%]::-webkit-scrollbar-track{background:var(--bg-subtle);border-radius:4px}.orc-file-uploader__list[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:var(--border-default);border-radius:4px}.orc-file-uploader__list[_ngcontent-%COMP%]::-webkit-scrollbar-thumb:hover{background:var(--text-secondary)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FileUploaderComponent, [{
        type: Component,
        args: [{ selector: 'orc-file-uploader', standalone: true, imports: [CommonModule, FileItemComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => FileUploaderComponent),
                        multi: true
                    }
                ], template: "<div class=\"orc-file-uploader\" [class.orc-file-uploader--disabled]=\"isDisabled()\">\n  \n  <input \n    #fileInput\n    type=\"file\" \n    class=\"orc-file-uploader__input\" \n    [accept]=\"accept()\" \n    [multiple]=\"multiple()\"\n    [disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n    (change)=\"onFileSelected($event)\"\n    hidden\n    aria-hidden=\"true\"\n  />\n\n  <div \n    class=\"orc-file-uploader__dropzone\"\n    [class.orc-file-uploader__dropzone--dragover]=\"isDragging() || forceDragover()\"\n    [class.orc-file-uploader__dropzone--disabled]=\"isDisabled()\"\n    role=\"button\"\n    tabindex=\"0\"\n    (click)=\"onAreaClick()\"\n    (keydown)=\"onAreaKeyDown($event)\"\n    [attr.aria-disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n    aria-label=\"\u00C1rea de upload de arquivos\"\n  >\n    <div class=\"orc-file-uploader__dropzone-content\">\n      <div class=\"orc-file-uploader__icon\">\n        <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n          <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n          <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n          <polyline points=\"10 9 9 9 8 9\"></polyline>\n        </svg>\n      </div>\n      <div class=\"orc-file-uploader__text\">\n        <span class=\"orc-file-uploader__label\">{{ label() }}</span>\n        @if (subLabel()) {\n          <span class=\"orc-file-uploader__sublabel\">{{ subLabel() }}</span>\n        }\n      </div>\n    </div>\n  </div>\n\n  @if (files().length > 0) {\n    <div class=\"orc-file-uploader__list\" aria-live=\"polite\">\n      @for (file of files(); track file.id) {\n        <orc-file-item \n          [fileData]=\"file\" \n          [disabled]=\"isDisabled()\"\n          (remove)=\"onRemoveFile($event)\">\n        </orc-file-item>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-uploader{display:flex;flex-direction:column;gap:var(--space-4)}.orc-file-uploader--disabled{opacity:.6;pointer-events:none}.orc-file-uploader__dropzone{border:3px dashed var(--border-default);border-radius:16px;background-color:var(--bg-app);padding:var(--space-8);cursor:pointer;transition:all var(--transition-fast);outline:none}.orc-file-uploader__dropzone:hover,.orc-file-uploader__dropzone:focus-visible{border-color:var(--color-accent);background-color:var(--bg-subtle)}.orc-file-uploader__dropzone--dragover{border-color:var(--orc-color-azul-eletrico);background-color:#1c6aed0a}.orc-file-uploader__dropzone--disabled{cursor:not-allowed;border-color:var(--border-default)!important;background-color:var(--bg-subtle)!important}.orc-file-uploader__dropzone-content{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--space-6)}.orc-file-uploader__icon{width:70px;height:70px;color:var(--text-secondary);display:flex;align-items:center;justify-content:center}.orc-file-uploader__icon svg{width:100%;height:100%}.orc-file-uploader__text{display:flex;flex-direction:column;gap:var(--space-3)}.orc-file-uploader__label{font-size:1rem;font-weight:400;color:var(--text-primary)}.orc-file-uploader__sublabel{font-size:1rem;font-weight:400;color:var(--text-secondary)}.orc-file-uploader__list{display:flex;flex-direction:column;gap:var(--space-3);max-height:260px;overflow-y:auto;padding-right:4px}.orc-file-uploader__list::-webkit-scrollbar{width:6px}.orc-file-uploader__list::-webkit-scrollbar-track{background:var(--bg-subtle);border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb{background:var(--border-default);border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb:hover{background:var(--text-secondary)}\n"] }]
    }], null, { fileInputRef: [{
            type: ViewChild,
            args: ['fileInput']
        }], onDragOver: [{
            type: HostListener,
            args: ['dragover', ['$event']]
        }], onDragLeave: [{
            type: HostListener,
            args: ['dragleave', ['$event']]
        }], onDrop: [{
            type: HostListener,
            args: ['drop', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FileUploaderComponent, { className: "FileUploaderComponent", filePath: "file-uploader.component.ts", lineNumber: 34 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { FileItemComponent, FileUploaderComponent };
//# sourceMappingURL=ciag-orchestra-file-uploader.mjs.map
