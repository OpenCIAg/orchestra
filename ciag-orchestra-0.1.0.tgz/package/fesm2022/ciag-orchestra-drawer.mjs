import * as i0 from '@angular/core';
import { model, input, booleanAttribute, output, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';

const _c0 = [[["", "drawer-title", ""]], "*", [["", "drawer-actions", ""]]];
const _c1 = ["[drawer-title]", "*", "[drawer-actions]"];
function DrawerComponent_Conditional_0_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 6);
    i0.ɵɵlistener("click", function DrawerComponent_Conditional_0_Conditional_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.close()); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} }
function DrawerComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 0);
    i0.ɵɵlistener("click", function DrawerComponent_Conditional_0_Template_div_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onBackdrop()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(1, "aside", 1)(2, "div", 2);
    i0.ɵɵprojection(3);
    i0.ɵɵtemplate(4, DrawerComponent_Conditional_0_Conditional_4_Template, 2, 0, "button", 3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 4);
    i0.ɵɵprojection(6, 1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "div", 5);
    i0.ɵɵprojection(8, 2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵclassMap("orc-drawer orc-drawer--" + ctx_r1.placement());
    i0.ɵɵattribute("aria-label", ctx_r1.label());
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(ctx_r1.dismissible() ? 4 : -1);
} }
class DrawerComponent {
    open = model(false);
    placement = input('right');
    label = input('Painel lateral');
    closeOnBackdrop = input(true, { transform: booleanAttribute });
    dismissible = input(true, { transform: booleanAttribute });
    closed = output();
    close() {
        if (!this.dismissible())
            return;
        this.open.set(false);
        this.closed.emit();
    }
    onBackdrop() {
        if (this.closeOnBackdrop())
            this.close();
    }
    onEscape() {
        if (this.open())
            this.close();
    }
    static ɵfac = function DrawerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DrawerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DrawerComponent, selectors: [["orc-drawer"]], hostBindings: function DrawerComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown.escape", function DrawerComponent_keydown_escape_HostBindingHandler() { return ctx.onEscape(); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { open: [1, "open"], placement: [1, "placement"], label: [1, "label"], closeOnBackdrop: [1, "closeOnBackdrop"], dismissible: [1, "dismissible"] }, outputs: { open: "openChange", closed: "closed" }, ngContentSelectors: _c1, decls: 1, vars: 1, consts: [["aria-hidden", "true", 1, "orc-drawer__backdrop", 3, "click"], ["role", "dialog", "aria-modal", "true", 1, "orc-drawer"], [1, "orc-drawer__header"], ["type", "button", "aria-label", "Fechar painel", 1, "orc-drawer__close"], [1, "orc-drawer__body"], [1, "orc-drawer__footer"], ["type", "button", "aria-label", "Fechar painel", 1, "orc-drawer__close", 3, "click"]], template: function DrawerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0);
            i0.ɵɵtemplate(0, DrawerComponent_Conditional_0_Template, 9, 4);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.open() ? 0 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:contents}.orc-drawer__backdrop[_ngcontent-%COMP%]{position:fixed;inset:0;z-index:var(--z-modal-backdrop);background:#00000085}.orc-drawer[_ngcontent-%COMP%]{position:fixed;z-index:var(--z-modal);display:flex;flex-direction:column;max-width:100vw;max-height:100vh;background:var(--orc-fill-modal);color:var(--text-primary);border:1px solid var(--border-default);box-shadow:var(--shadow-lg)}.orc-drawer--left[_ngcontent-%COMP%], .orc-drawer--right[_ngcontent-%COMP%]{top:0;bottom:0;width:min(26rem,92vw)}.orc-drawer--left[_ngcontent-%COMP%]{left:0}.orc-drawer--right[_ngcontent-%COMP%]{right:0}.orc-drawer--top[_ngcontent-%COMP%], .orc-drawer--bottom[_ngcontent-%COMP%]{left:0;right:0;min-height:12rem;max-height:80vh}.orc-drawer--top[_ngcontent-%COMP%]{top:0}.orc-drawer--bottom[_ngcontent-%COMP%]{bottom:0}.orc-drawer__header[_ngcontent-%COMP%], .orc-drawer__footer[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-4) var(--space-5);border-color:var(--border-default)}.orc-drawer__header[_ngcontent-%COMP%]{justify-content:space-between;border-bottom:1px solid var(--border-default)}.orc-drawer__footer[_ngcontent-%COMP%]{justify-content:flex-end;border-top:1px solid var(--border-default)}.orc-drawer__body[_ngcontent-%COMP%]{flex:1;overflow:auto;padding:var(--space-5)}.orc-drawer__close[_ngcontent-%COMP%]{border:0;background:transparent;color:var(--text-secondary);font:inherit;font-size:1.5rem;cursor:pointer;border-radius:var(--radius-sm)}.orc-drawer__close[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:2px}@media(prefers-reduced-motion:no-preference){.orc-drawer[_ngcontent-%COMP%]{animation:orc-drawer-in var(--transition-base)}@keyframes orc-drawer-in{0%{opacity:0;transform:translate(1rem)}}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DrawerComponent, [{
        type: Component,
        args: [{ selector: 'orc-drawer', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (open()) {\n  <div class=\"orc-drawer__backdrop\" (click)=\"onBackdrop()\" aria-hidden=\"true\"></div>\n  <aside class=\"orc-drawer\" [class]=\"'orc-drawer orc-drawer--' + placement()\" role=\"dialog\" aria-modal=\"true\" [attr.aria-label]=\"label()\">\n    <div class=\"orc-drawer__header\">\n      <ng-content select=\"[drawer-title]\" />\n      @if (dismissible()) { <button type=\"button\" class=\"orc-drawer__close\" (click)=\"close()\" aria-label=\"Fechar painel\">\u00D7</button> }\n    </div>\n    <div class=\"orc-drawer__body\"><ng-content /></div>\n    <div class=\"orc-drawer__footer\"><ng-content select=\"[drawer-actions]\" /></div>\n  </aside>\n}\n", styles: [":host{display:contents}.orc-drawer__backdrop{position:fixed;inset:0;z-index:var(--z-modal-backdrop);background:#00000085}.orc-drawer{position:fixed;z-index:var(--z-modal);display:flex;flex-direction:column;max-width:100vw;max-height:100vh;background:var(--orc-fill-modal);color:var(--text-primary);border:1px solid var(--border-default);box-shadow:var(--shadow-lg)}.orc-drawer--left,.orc-drawer--right{top:0;bottom:0;width:min(26rem,92vw)}.orc-drawer--left{left:0}.orc-drawer--right{right:0}.orc-drawer--top,.orc-drawer--bottom{left:0;right:0;min-height:12rem;max-height:80vh}.orc-drawer--top{top:0}.orc-drawer--bottom{bottom:0}.orc-drawer__header,.orc-drawer__footer{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-4) var(--space-5);border-color:var(--border-default)}.orc-drawer__header{justify-content:space-between;border-bottom:1px solid var(--border-default)}.orc-drawer__footer{justify-content:flex-end;border-top:1px solid var(--border-default)}.orc-drawer__body{flex:1;overflow:auto;padding:var(--space-5)}.orc-drawer__close{border:0;background:transparent;color:var(--text-secondary);font:inherit;font-size:1.5rem;cursor:pointer;border-radius:var(--radius-sm)}.orc-drawer__close:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:2px}@media(prefers-reduced-motion:no-preference){.orc-drawer{animation:orc-drawer-in var(--transition-base)}@keyframes orc-drawer-in{0%{opacity:0;transform:translate(1rem)}}}\n"] }]
    }], null, { onEscape: [{
            type: HostListener,
            args: ['document:keydown.escape']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DrawerComponent, { className: "DrawerComponent", filePath: "drawer.component.ts", lineNumber: 12 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { DrawerComponent };
//# sourceMappingURL=ciag-orchestra-drawer.mjs.map
