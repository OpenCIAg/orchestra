import * as i0 from '@angular/core';
import { input, booleanAttribute, computed, ChangeDetectionStrategy, Component } from '@angular/core';

function DividerComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(2, "span", 0);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.label());
} }
class DividerComponent {
    orientation = input('horizontal');
    variant = input('solid');
    label = input('');
    inset = input(false, { transform: booleanAttribute });
    decorative = input(true, { transform: booleanAttribute });
    ariaLabel = input('');
    classes = computed(() => ({
        'orc-divider': true,
        'orc-divider--vertical': this.orientation() === 'vertical',
        'orc-divider--inset': this.inset(),
        [`orc-divider--${this.variant()}`]: true,
        'orc-divider--labeled': !!this.label(),
    }));
    static ɵfac = function DividerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DividerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DividerComponent, selectors: [["orc-divider"]], inputs: { orientation: [1, "orientation"], variant: [1, "variant"], label: [1, "label"], inset: [1, "inset"], decorative: [1, "decorative"], ariaLabel: [1, "ariaLabel"] }, decls: 3, vars: 7, consts: [[1, "orc-divider__line"], [1, "orc-divider__label"]], template: function DividerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div");
            i0.ɵɵelement(1, "span", 0);
            i0.ɵɵtemplate(2, DividerComponent_Conditional_2_Template, 3, 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap(ctx.classes());
            i0.ɵɵattribute("role", ctx.decorative() ? null : "separator")("aria-orientation", ctx.decorative() ? null : ctx.orientation())("aria-label", ctx.decorative() ? null : ctx.ariaLabel() || ctx.label() || null)("aria-hidden", ctx.decorative() ? "true" : null);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.label() ? 2 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-divider[_ngcontent-%COMP%]{display:flex;align-items:center;gap:12px;width:100%;color:var(--orc-font-secondary, #666)}.orc-divider--inset[_ngcontent-%COMP%]{padding-inline:16px;box-sizing:border-box}.orc-divider__line[_ngcontent-%COMP%]{flex:1;min-width:0;border-top:1px var(--orc-border, #d9d9d9)}.orc-divider--dashed[_ngcontent-%COMP%]   .orc-divider__line[_ngcontent-%COMP%]{border-top-style:dashed}.orc-divider--dotted[_ngcontent-%COMP%]   .orc-divider__line[_ngcontent-%COMP%]{border-top-style:dotted}.orc-divider__label[_ngcontent-%COMP%]{font-size:12px;white-space:nowrap}.orc-divider--vertical[_ngcontent-%COMP%]{width:auto;min-height:24px;height:100%;flex-direction:column}.orc-divider--vertical[_ngcontent-%COMP%]   .orc-divider__line[_ngcontent-%COMP%]{width:1px;height:auto;min-height:12px;border-top:0;border-left:1px var(--orc-border, #d9d9d9)}.orc-divider--vertical.orc-divider--dashed[_ngcontent-%COMP%]   .orc-divider__line[_ngcontent-%COMP%]{border-left-style:dashed}.orc-divider--vertical.orc-divider--dotted[_ngcontent-%COMP%]   .orc-divider__line[_ngcontent-%COMP%]{border-left-style:dotted}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DividerComponent, [{
        type: Component,
        args: [{ selector: 'orc-divider', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [class]=\"classes()\"\n  [attr.role]=\"decorative() ? null : 'separator'\"\n  [attr.aria-orientation]=\"decorative() ? null : orientation()\"\n  [attr.aria-label]=\"decorative() ? null : (ariaLabel() || label() || null)\"\n  [attr.aria-hidden]=\"decorative() ? 'true' : null\"\n>\n  <span class=\"orc-divider__line\"></span>\n  @if (label()) { <span class=\"orc-divider__label\">{{ label() }}</span><span class=\"orc-divider__line\"></span> }\n</div>\n", styles: [":host{display:block;width:100%}.orc-divider{display:flex;align-items:center;gap:12px;width:100%;color:var(--orc-font-secondary, #666)}.orc-divider--inset{padding-inline:16px;box-sizing:border-box}.orc-divider__line{flex:1;min-width:0;border-top:1px var(--orc-border, #d9d9d9)}.orc-divider--dashed .orc-divider__line{border-top-style:dashed}.orc-divider--dotted .orc-divider__line{border-top-style:dotted}.orc-divider__label{font-size:12px;white-space:nowrap}.orc-divider--vertical{width:auto;min-height:24px;height:100%;flex-direction:column}.orc-divider--vertical .orc-divider__line{width:1px;height:auto;min-height:12px;border-top:0;border-left:1px var(--orc-border, #d9d9d9)}.orc-divider--vertical.orc-divider--dashed .orc-divider__line{border-left-style:dashed}.orc-divider--vertical.orc-divider--dotted .orc-divider__line{border-left-style:dotted}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DividerComponent, { className: "DividerComponent", filePath: "divider.component.ts", lineNumber: 13 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { DividerComponent };
//# sourceMappingURL=ciag-orchestra-divider.mjs.map
