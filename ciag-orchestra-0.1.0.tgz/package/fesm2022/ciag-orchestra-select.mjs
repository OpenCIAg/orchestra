import * as i0 from '@angular/core';
import { inject, ElementRef, input, booleanAttribute, signal, computed, ChangeDetectionStrategy, Component, HostListener, ViewContainerRef, viewChild, contentChildren, model, output, effect, forwardRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';

// src/app/shared/select/option.component.ts
const _c0$1 = ["*"];
function OptionComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 1);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("src", ctx_r0.avatarUrl(), i0.ɵɵsanitizeUrl);
} }
function OptionComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 7);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassMap(ctx_r0.icon());
} }
function OptionComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.label(), " ");
} }
function OptionComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
function OptionComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.description());
} }
function OptionComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 6);
    i0.ɵɵelement(1, "path", 8);
    i0.ɵɵelementEnd();
} }
let nextOptionId = 0;
class OptionComponent {
    select = inject(SelectComponent, { optional: true });
    elementRef = inject(ElementRef);
    defaultId = `orc-option-${++nextOptionId}`;
    // ── Signal Inputs ──────────────────────────────────────────
    id = input('');
    value = input.required();
    label = input('');
    description = input(undefined);
    icon = input(undefined);
    avatarUrl = input(undefined);
    disabled = input(false, { transform: booleanAttribute });
    // ── Internal State Signals ─────────────────────────────────
    isSelected = signal(false);
    isActive = signal(false);
    isHidden = signal(false);
    // ── Computeds ──────────────────────────────────────────────
    displayText = computed(() => {
        if (this.label())
            return this.label();
        const nativeText = this.elementRef?.nativeElement?.textContent?.trim();
        return nativeText || String(this.value() ?? '');
    });
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.disabled())
            return;
        if (this.select) {
            this.select.onOptionSelected(this);
        }
    }
    onMouseEnter() {
        if (this.disabled() || !this.select)
            return;
        this.select.setActiveOption(this);
    }
    getOptionText() {
        return this.displayText();
    }
    static ɵfac = function OptionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OptionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OptionComponent, selectors: [["orc-option"]], hostAttrs: ["role", "option"], hostVars: 9, hostBindings: function OptionComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("click", function OptionComponent_click_HostBindingHandler($event) { return ctx.onClick($event); })("mouseenter", function OptionComponent_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); });
        } if (rf & 2) {
            i0.ɵɵhostProperty("id", ctx.id() || ctx.defaultId);
            i0.ɵɵattribute("aria-selected", ctx.isSelected())("aria-disabled", ctx.disabled());
            i0.ɵɵclassProp("is-selected", ctx.isSelected())("is-active", ctx.isActive())("is-disabled", ctx.disabled());
        } }, inputs: { id: [1, "id"], value: [1, "value"], label: [1, "label"], description: [1, "description"], icon: [1, "icon"], avatarUrl: [1, "avatarUrl"], disabled: [1, "disabled"] }, ngContentSelectors: _c0$1, decls: 9, vars: 4, consts: [[1, "orc-option-container"], ["alt", "", 1, "orc-option-avatar", 3, "src"], ["aria-hidden", "true", 1, "orc-option-icon", 3, "class"], [1, "orc-option-content"], [1, "orc-option-label"], [1, "orc-option-description"], ["viewBox", "0 0 20 20", "fill", "currentColor", "aria-hidden", "true", 1, "orc-option-checkmark"], ["aria-hidden", "true", 1, "orc-option-icon"], ["fill-rule", "evenodd", "d", "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z", "clip-rule", "evenodd"]], template: function OptionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, OptionComponent_Conditional_1_Template, 1, 1, "img", 1)(2, OptionComponent_Conditional_2_Template, 1, 2, "i", 2);
            i0.ɵɵelementStart(3, "div", 3)(4, "span", 4);
            i0.ɵɵtemplate(5, OptionComponent_Conditional_5_Template, 1, 1)(6, OptionComponent_Conditional_6_Template, 1, 0);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, OptionComponent_Conditional_7_Template, 2, 1, "span", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(8, OptionComponent_Conditional_8_Template, 2, 0, ":svg:svg", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.avatarUrl() ? 1 : ctx.icon() ? 2 : -1);
            i0.ɵɵadvance(4);
            i0.ɵɵconditional(ctx.label() ? 5 : 6);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.description() ? 7 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isSelected() ? 8 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%;box-sizing:border-box}.is-hidden[_nghost-%COMP%]{display:none!important}.orc-option-container[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-option-container[_ngcontent-%COMP%]:hover{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}.is-active[_nghost-%COMP%]   .orc-option-container[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}.is-selected[_nghost-%COMP%]   .orc-option-container[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #EDEDED);font-weight:500}.is-disabled[_nghost-%COMP%]   .orc-option-container[_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed;pointer-events:none}.is-disabled[_nghost-%COMP%]   .orc-option-container[_ngcontent-%COMP%]:hover{background-color:transparent}.orc-option-avatar[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon[_ngcontent-%COMP%]{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label[_ngcontent-%COMP%]{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description[_ngcontent-%COMP%]{font-size:.75rem;line-height:1rem;color:var(--orc-font-secondary, #666666);font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark[_ngcontent-%COMP%]{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-font-main, #141414)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OptionComponent, [{
        type: Component,
        args: [{ selector: 'orc-option', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    'role': 'option',
                    '[id]': 'id() || defaultId',
                    '[attr.aria-selected]': 'isSelected()',
                    '[attr.aria-disabled]': 'disabled()',
                    '[class.is-selected]': 'isSelected()',
                    '[class.is-active]': 'isActive()',
                    '[class.is-disabled]': 'disabled()',
                }, template: "<div class=\"orc-option-container\">\n  @if (avatarUrl()) {\n    <img [src]=\"avatarUrl()\" alt=\"\" class=\"orc-option-avatar\" />\n  } @else if (icon()) {\n    <i [class]=\"icon()\" class=\"orc-option-icon\" aria-hidden=\"true\"></i>\n  }\n\n  <div class=\"orc-option-content\">\n    <span class=\"orc-option-label\">\n      @if (label()) {\n        {{ label() }}\n      } @else {\n        <ng-content></ng-content>\n      }\n    </span>\n    @if (description()) {\n      <span class=\"orc-option-description\">{{ description() }}</span>\n    }\n  </div>\n\n  @if (isSelected()) {\n    <svg class=\"orc-option-checkmark\" viewBox=\"0 0 20 20\" fill=\"currentColor\" aria-hidden=\"true\">\n      <path fill-rule=\"evenodd\" d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\" clip-rule=\"evenodd\" />\n    </svg>\n  }\n</div>\n", styles: [":host{display:block;width:100%;box-sizing:border-box}:host.is-hidden{display:none!important}.orc-option-container{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-option-container:hover{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}:host(.is-active) .orc-option-container{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}:host(.is-selected) .orc-option-container{background-color:var(--orc-highlight-cinza-claro, #EDEDED);font-weight:500}:host(.is-disabled) .orc-option-container{opacity:.5;cursor:not-allowed;pointer-events:none}:host(.is-disabled) .orc-option-container:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;line-height:1rem;color:var(--orc-font-secondary, #666666);font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-font-main, #141414)}\n"] }]
    }], null, { onClick: [{
            type: HostListener,
            args: ['click', ['$event']]
        }], onMouseEnter: [{
            type: HostListener,
            args: ['mouseenter']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OptionComponent, { className: "OptionComponent", filePath: "option.component.ts", lineNumber: 36 }); })();

// src/app/shared/select/select.component.ts
const _c0 = ["triggerEl"];
const _c1 = ["searchInput"];
const _c2 = ["dropdownPanel"];
const _c3 = [[["", "orcSelectTrigger", ""], ["", "selectTrigger", ""]], [["", "orcSelectHeader", ""]], [["", "orcSelectFooter", ""]], "*"];
const _c4 = ["[orcSelectTrigger], [selectTrigger]", "[orcSelectHeader]", "[orcSelectFooter]", "*"];
const _c5 = () => [];
const _forTrack0 = ($index, $item) => $item.value;
function SelectComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 14);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function SelectComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 4);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, SelectComponent_Conditional_1_Conditional_2_Template, 2, 0, "span", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r1.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.required() ? 2 : -1);
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 18);
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("src", item_r3.avatarUrl, i0.ɵɵsanitizeUrl);
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 22);
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵclassMap(item_r3.icon);
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 23);
    i0.ɵɵlistener("click", function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_5_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r4); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r1.removeSelectedItem(item_r3.value, $event)); });
    i0.ɵɵtext(1, " \u00D7 ");
    i0.ɵɵelementEnd();
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 17);
    i0.ɵɵtemplate(1, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_1_Template, 1, 1, "img", 18)(2, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_2_Template, 1, 2, "i", 19);
    i0.ɵɵelementStart(3, "span", 20);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Conditional_5_Template, 2, 0, "button", 21);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r3.avatarUrl ? 1 : item_r3.icon ? 2 : -1);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r3.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(!ctx_r1.effectiveDisabled() && !ctx_r1.readonly() ? 5 : -1);
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 15);
    i0.ɵɵrepeaterCreate(1, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_For_2_Template, 6, 3, "span", 17, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.selectedItems());
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.placeholder());
} }
function SelectComponent_ProjectionFallback_5_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_0_Template, 3, 0, "div", 15)(1, SelectComponent_ProjectionFallback_5_Conditional_0_Conditional_1_Template, 2, 1, "span", 16);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵconditional(ctx_r1.selectedItems().length > 0 ? 0 : 1);
} }
function SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 25);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵproperty("src", ctx_r1.selectedItems()[0].avatarUrl, i0.ɵɵsanitizeUrl);
} }
function SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 28);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵclassMap(ctx_r1.selectedItems()[0].icon);
} }
function SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 24);
    i0.ɵɵtemplate(1, SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Conditional_1_Template, 1, 1, "img", 25)(2, SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Conditional_2_Template, 1, 2, "i", 26);
    i0.ɵɵelementStart(3, "span", 27);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.selectedItems()[0].avatarUrl ? 1 : ctx_r1.selectedItems()[0].icon ? 2 : -1);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r1.selectedItems()[0].label);
} }
function SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.placeholder());
} }
function SelectComponent_ProjectionFallback_5_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_0_Template, 5, 2, "div", 24)(1, SelectComponent_ProjectionFallback_5_Conditional_1_Conditional_1_Template, 2, 1, "span", 16);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵconditional(ctx_r1.hasValue() ? 0 : 1);
} }
function SelectComponent_ProjectionFallback_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, SelectComponent_ProjectionFallback_5_Conditional_0_Template, 2, 1)(1, SelectComponent_ProjectionFallback_5_Conditional_1_Template, 2, 1);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵconditional(ctx_r1.multiple() ? 0 : 1);
} }
function SelectComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 29);
    i0.ɵɵlistener("click", function SelectComponent_Conditional_8_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.clearValue($event)); });
    i0.ɵɵtext(1, " \u00D7 ");
    i0.ɵɵelementEnd();
} }
function SelectComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r1.errorId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.errorMessage(), " ");
} }
function SelectComponent_Conditional_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r1.helperId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.helperText(), " ");
} }
function SelectComponent_ng_template_14_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 31)(1, "input", 33, 2);
    i0.ɵɵlistener("input", function SelectComponent_ng_template_14_Conditional_2_Template_input_input_1_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onSearchInput($event)); })("keydown", function SelectComponent_ng_template_14_Conditional_2_Template_input_keydown_1_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onKeyDown($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("placeholder", ctx_r1.searchPlaceholder())("value", ctx_r1.searchTerm());
} }
function SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 37);
} if (rf & 2) {
    const opt_r8 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("src", opt_r8.avatarUrl, i0.ɵɵsanitizeUrl);
} }
function SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 43);
} if (rf & 2) {
    const opt_r8 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵclassMap(opt_r8.icon);
} }
function SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 41);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const opt_r8 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(opt_r8.description);
} }
function SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 42);
    i0.ɵɵelement(1, "path", 44);
    i0.ɵɵelementEnd();
} }
function SelectComponent_ng_template_14_Conditional_4_For_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 36);
    i0.ɵɵlistener("click", function SelectComponent_ng_template_14_Conditional_4_For_1_Template_div_click_0_listener() { const opt_r8 = i0.ɵɵrestoreView(_r7).$implicit; const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.onDataOptionClick(opt_r8)); });
    i0.ɵɵtemplate(1, SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_1_Template, 1, 1, "img", 37)(2, SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_2_Template, 1, 2, "i", 38);
    i0.ɵɵelementStart(3, "div", 39)(4, "span", 40);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_6_Template, 2, 1, "span", 41);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(7, SelectComponent_ng_template_14_Conditional_4_For_1_Conditional_7_Template, 2, 0, ":svg:svg", 42);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const opt_r8 = ctx.$implicit;
    const ɵ$index_91_r9 = ctx.$index;
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵclassProp("is-selected", ctx_r1.multiple() ? (ctx_r1.value() || i0.ɵɵpureFunction0(12, _c5)).includes(opt_r8.value) : ctx_r1.value() === opt_r8.value)("is-active", ctx_r1.activeOptionIndex() === ɵ$index_91_r9)("is-disabled", opt_r8.disabled);
    i0.ɵɵattribute("aria-selected", ctx_r1.multiple() ? (ctx_r1.value() || i0.ɵɵpureFunction0(13, _c5)).includes(opt_r8.value) : ctx_r1.value() === opt_r8.value)("aria-disabled", opt_r8.disabled);
    i0.ɵɵadvance();
    i0.ɵɵconditional(opt_r8.avatarUrl ? 1 : opt_r8.icon ? 2 : -1);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(opt_r8.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(opt_r8.description ? 6 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional((ctx_r1.multiple() ? (ctx_r1.value() || i0.ɵɵpureFunction0(14, _c5)).includes(opt_r8.value) : ctx_r1.value() === opt_r8.value) ? 7 : -1);
} }
function SelectComponent_ng_template_14_Conditional_4_ForEmpty_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 35);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.searchEmptyText(), " ");
} }
function SelectComponent_ng_template_14_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, SelectComponent_ng_template_14_Conditional_4_For_1_Template, 8, 15, "div", 34, _forTrack0, false, SelectComponent_ng_template_14_Conditional_4_ForEmpty_2_Template, 2, 1, "div", 35);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵrepeater(ctx_r1.filteredDataOptions());
} }
function SelectComponent_ng_template_14_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0, 3);
} }
function SelectComponent_ng_template_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 30);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵtemplate(2, SelectComponent_ng_template_14_Conditional_2_Template, 3, 2, "div", 31);
    i0.ɵɵelementStart(3, "div", 32);
    i0.ɵɵtemplate(4, SelectComponent_ng_template_14_Conditional_4_Template, 3, 1)(5, SelectComponent_ng_template_14_Conditional_5_Template, 1, 0);
    i0.ɵɵelementEnd();
    i0.ɵɵprojection(6, 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r1.listboxId());
    i0.ɵɵattribute("aria-multiselectable", ctx_r1.multiple());
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.searchable() ? 2 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.isDataMode() ? 4 : 5);
} }
let nextSelectUniqueId = 0;
class SelectComponent {
    uniqueId = `orc-select-${++nextSelectUniqueId}`;
    hostEl = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    overlay = inject(Overlay);
    // ── Overlay References ─────────────────────────────────────
    overlayRef = null;
    portal;
    // ── Element Signals ────────────────────────────────────────
    triggerEl = viewChild('triggerEl');
    searchInputRef = viewChild('searchInput');
    dropdownPanel = viewChild.required('dropdownPanel');
    // ── Content Children Options ───────────────────────────────
    projectedOptions = contentChildren(OptionComponent, { descendants: true });
    // ── Signal Inputs ──────────────────────────────────────────
    id = input('');
    name = input('');
    placeholder = input('Selecione uma opção');
    label = input('');
    helperText = input('');
    errorMessage = input('');
    status = input('default');
    multiple = input(false, { transform: booleanAttribute });
    searchable = input(false, { transform: booleanAttribute });
    searchPlaceholder = input('Buscar...');
    searchEmptyText = input('Nenhum resultado encontrado');
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    clearable = input(false, { transform: booleanAttribute });
    options = input(undefined);
    // Acessibilidade WCAG
    ariaLabel = input('');
    ariaDescribedby = input('');
    // ── Two-Way Model Signal ───────────────────────────────────
    value = model(undefined);
    // ── Signal Outputs ─────────────────────────────────────────
    selectionChange = output();
    searchChange = output();
    opened = output();
    closed = output();
    blur = output();
    focus = output();
    // ── Internal State Signals ─────────────────────────────────
    isOpen = signal(false);
    isFocused = signal(false);
    searchTerm = signal('');
    cvaDisabled = signal(false);
    activeOptionIndex = signal(-1);
    // ── Computeds ──────────────────────────────────────────────
    effectiveId = computed(() => this.id() || this.uniqueId);
    listboxId = computed(() => `${this.effectiveId()}-listbox`);
    helperId = computed(() => `${this.effectiveId()}-helper`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    isInvalid = computed(() => this.status() === 'error');
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby())
            ids.push(this.ariaDescribedby());
        if (this.isInvalid() && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    });
    // Effective list of options either from inputs or projected components
    dataOptions = computed(() => {
        if (this.options() !== undefined) {
            return this.options() || [];
        }
        return [];
    });
    isDataMode = computed(() => this.options() !== undefined);
    // Filtered data options when searching
    filteredDataOptions = computed(() => {
        const list = this.dataOptions();
        const term = this.searchTerm().trim().toLowerCase();
        if (!term)
            return list;
        return list.filter((opt) => opt.label.toLowerCase().includes(term) ||
            (opt.description && opt.description.toLowerCase().includes(term)));
    });
    // Selected Option Items for display
    selectedItems = computed(() => {
        const currentVal = this.value();
        if (currentVal === undefined || currentVal === null || currentVal === '') {
            return [];
        }
        const valArray = this.multiple() ? (Array.isArray(currentVal) ? currentVal : [currentVal]) : [currentVal];
        if (this.isDataMode()) {
            const allData = this.dataOptions();
            return valArray.map((v) => {
                const found = allData.find((opt) => opt.value === v);
                return {
                    label: found ? found.label : String(v),
                    value: v,
                    icon: found?.icon,
                    avatarUrl: found?.avatarUrl,
                };
            });
        }
        // Projected mode
        const proj = this.projectedOptions();
        return valArray.map((v) => {
            const found = proj.find((opt) => opt.value() === v);
            return {
                label: found ? found.getOptionText() : String(v),
                value: v,
                icon: found?.icon(),
                avatarUrl: found?.avatarUrl(),
            };
        });
    });
    hasValue = computed(() => this.selectedItems().length > 0);
    // ── ControlValueAccessor Implementation ───────────────────
    onChange = () => { };
    onTouched = () => { };
    constructor() {
        // Synchronize selection state to projected components whenever value or projected options change
        effect(() => {
            const val = this.value();
            const isMulti = this.multiple();
            const projOptions = this.projectedOptions();
            projOptions.forEach((opt) => {
                if (isMulti) {
                    const arr = Array.isArray(val) ? val : [];
                    opt.isSelected.set(arr.includes(opt.value()));
                }
                else {
                    opt.isSelected.set(val === opt.value());
                }
            });
        });
        // Update visibility of projected options when searching
        effect(() => {
            if (this.isDataMode())
                return;
            const term = this.searchTerm().trim().toLowerCase();
            const projOptions = this.projectedOptions();
            projOptions.forEach((opt) => {
                if (!term) {
                    opt.isHidden.set(false);
                }
                else {
                    const desc = opt.description();
                    const matches = opt.getOptionText().toLowerCase().includes(term) ||
                        (desc ? desc.toLowerCase().includes(term) : false);
                    opt.isHidden.set(!matches);
                }
            });
        });
    }
    ngAfterViewInit() {
        this.portal = new TemplatePortal(this.dropdownPanel(), this.viewContainerRef);
    }
    ngOnDestroy() {
        this.closePanel();
    }
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Overlay & Panel Methods ───────────────────────────────
    togglePanel() {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.isOpen() ? this.closePanel() : this.openPanel();
    }
    openPanel() {
        if (this.isOpen() || this.effectiveDisabled() || this.readonly())
            return;
        const triggerNative = this.triggerEl()?.nativeElement || this.hostEl.nativeElement;
        const triggerWidth = triggerNative.getBoundingClientRect().width;
        const positionStrategy = this.createPositionStrategy(triggerNative);
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
            minWidth: triggerWidth,
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        this.overlayRef.backdropClick().subscribe(() => this.closePanel());
        this.overlayRef.keydownEvents().subscribe((event) => {
            if (event.key === 'Escape') {
                this.closePanel();
                event.stopPropagation();
            }
        });
        this.overlayRef.attach(this.portal);
        this.isOpen.set(true);
        this.opened.emit();
        if (this.searchable()) {
            setTimeout(() => this.searchInputRef()?.nativeElement?.focus(), 50);
        }
    }
    closePanel() {
        if (!this.isOpen())
            return;
        this.overlayRef?.dispose();
        this.overlayRef = null;
        this.isOpen.set(false);
        this.searchTerm.set('');
        this.activeOptionIndex.set(-1);
        this.onTouched();
        this.closed.emit();
    }
    createPositionStrategy(origin) {
        const positions = [
            { originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top', offsetY: 4 },
            { originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom', offsetY: -4 },
        ];
        return this.overlay
            .position()
            .flexibleConnectedTo(origin)
            .withPositions(positions)
            .withPush(true);
    }
    // ── Selection Logic ───────────────────────────────────────
    onOptionSelected(optionComponent) {
        this.selectValue(optionComponent.value());
    }
    onDataOptionClick(option) {
        if (option.disabled)
            return;
        this.selectValue(option.value);
    }
    selectValue(val) {
        if (this.multiple()) {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            const index = current.indexOf(val);
            if (index > -1) {
                current.splice(index, 1);
            }
            else {
                current.push(val);
            }
            this.value.set(current);
            this.onChange(current);
            this.selectionChange.emit(current);
        }
        else {
            this.value.set(val);
            this.onChange(val);
            this.selectionChange.emit(val);
            this.closePanel();
        }
    }
    removeSelectedItem(itemValue, event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        if (this.multiple()) {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            const updated = current.filter((v) => v !== itemValue);
            this.value.set(updated);
            this.onChange(updated);
            this.selectionChange.emit(updated);
        }
        else {
            this.clearValue(event);
        }
    }
    clearValue(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        const clearedVal = this.multiple() ? [] : undefined;
        this.value.set(clearedVal);
        this.onChange(clearedVal);
        this.selectionChange.emit(clearedVal);
    }
    setActiveOption(optionComponent) {
        const list = this.getVisibleOptions();
        const idx = list.indexOf(optionComponent);
        if (idx !== -1) {
            this.activeOptionIndex.set(idx);
            this.updateActiveHighlight(list, idx);
        }
    }
    getVisibleOptions() {
        return this.projectedOptions().filter((opt) => !opt.isHidden() && !opt.disabled());
    }
    updateActiveHighlight(list, activeIdx) {
        list.forEach((opt, index) => {
            opt.isActive.set(index === activeIdx);
        });
    }
    // ── Search Event Handler ──────────────────────────────────
    onSearchInput(event) {
        const target = event.target;
        const val = target.value;
        this.searchTerm.set(val);
        this.searchChange.emit(val);
    }
    // ── Keyboard Navigation (WAI-ARIA Select) ────────────────
    onKeyDown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else {
                    this.navigateOption(1);
                }
                break;
            case 'ArrowUp':
                event.preventDefault();
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else {
                    this.navigateOption(-1);
                }
                break;
            case 'Enter':
            case ' ':
                if (!this.searchable() || !this.isOpen()) {
                    event.preventDefault();
                }
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else if (this.activeOptionIndex() >= 0) {
                    event.preventDefault();
                    this.confirmActiveOption();
                }
                break;
            case 'Tab':
                if (this.isOpen()) {
                    this.closePanel();
                }
                break;
            case 'Escape':
                if (this.isOpen()) {
                    event.stopPropagation();
                    this.closePanel();
                }
                break;
        }
    }
    navigateOption(direction) {
        if (this.isDataMode()) {
            const optionsList = this.filteredDataOptions().filter((o) => !o.disabled);
            if (optionsList.length === 0)
                return;
            let nextIndex = this.activeOptionIndex() + direction;
            if (nextIndex < 0)
                nextIndex = optionsList.length - 1;
            if (nextIndex >= optionsList.length)
                nextIndex = 0;
            this.activeOptionIndex.set(nextIndex);
        }
        else {
            const visibleOpts = this.getVisibleOptions();
            if (visibleOpts.length === 0)
                return;
            let nextIndex = this.activeOptionIndex() + direction;
            if (nextIndex < 0)
                nextIndex = visibleOpts.length - 1;
            if (nextIndex >= visibleOpts.length)
                nextIndex = 0;
            this.activeOptionIndex.set(nextIndex);
            this.updateActiveHighlight(visibleOpts, nextIndex);
        }
    }
    confirmActiveOption() {
        const idx = this.activeOptionIndex();
        if (idx < 0)
            return;
        if (this.isDataMode()) {
            const optionsList = this.filteredDataOptions().filter((o) => !o.disabled);
            if (optionsList[idx]) {
                this.selectValue(optionsList[idx].value);
            }
        }
        else {
            const visibleOpts = this.getVisibleOptions();
            if (visibleOpts[idx]) {
                this.selectValue(visibleOpts[idx].value());
            }
        }
    }
    onTriggerFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
    }
    onTriggerBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
    }
    onDocumentClick(target) {
        if (!this.isOpen())
            return;
        const insideHost = target instanceof Node && this.hostEl.nativeElement.contains(target);
        const insideOverlay = this.overlayRef?.overlayElement.contains(target);
        if (!insideHost && !insideOverlay) {
            this.closePanel();
        }
    }
    static ɵfac = function SelectComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SelectComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SelectComponent, selectors: [["orc-select"]], contentQueries: function SelectComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.projectedOptions, OptionComponent, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, viewQuery: function SelectComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.triggerEl, _c0, 5);
            i0.ɵɵviewQuerySignal(ctx.searchInputRef, _c1, 5);
            i0.ɵɵviewQuerySignal(ctx.dropdownPanel, _c2, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(3);
        } }, hostBindings: function SelectComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("click", function SelectComponent_click_HostBindingHandler($event) { return ctx.onDocumentClick($event.target); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { id: [1, "id"], name: [1, "name"], placeholder: [1, "placeholder"], label: [1, "label"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], status: [1, "status"], multiple: [1, "multiple"], searchable: [1, "searchable"], searchPlaceholder: [1, "searchPlaceholder"], searchEmptyText: [1, "searchEmptyText"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], clearable: [1, "clearable"], options: [1, "options"], ariaLabel: [1, "ariaLabel"], ariaDescribedby: [1, "ariaDescribedby"], value: [1, "value"] }, outputs: { value: "valueChange", selectionChange: "selectionChange", searchChange: "searchChange", opened: "opened", closed: "closed", blur: "blur", focus: "focus" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => SelectComponent),
                    multi: true,
                },
            ])], ngContentSelectors: _c4, decls: 16, vars: 27, consts: [["triggerEl", ""], ["dropdownPanel", ""], ["searchInput", ""], [1, "orc-select-wrapper"], [1, "orc-select-label", 3, "for"], ["role", "combobox", 1, "orc-select-trigger", 3, "click", "keydown", "focus", "blur", "id"], [1, "orc-select-trigger-content"], [1, "orc-select-actions"], ["type", "button", "aria-label", "Limpar sele\u00E7\u00E3o", 1, "orc-select-clear-btn"], [1, "orc-select-arrow"], ["width", "20", "height", "20", "viewBox", "0 0 20 20", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M5 7.5L10 12.5L15 7.5", "stroke", "currentColor", "stroke-width", "1.67", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-select-message", "is-error", 3, "id"], [1, "orc-select-message", "is-helper", 3, "id"], ["aria-hidden", "true", 1, "orc-select-required-asterisk"], [1, "orc-select-chips"], [1, "orc-select-placeholder"], [1, "orc-select-chip"], ["alt", "", 1, "orc-chip-avatar", 3, "src"], ["aria-hidden", "true", 1, "orc-chip-icon", 3, "class"], [1, "orc-chip-label"], ["type", "button", "aria-label", "Remover op\u00E7\u00E3o", 1, "orc-chip-remove"], ["aria-hidden", "true", 1, "orc-chip-icon"], ["type", "button", "aria-label", "Remover op\u00E7\u00E3o", 1, "orc-chip-remove", 3, "click"], [1, "orc-select-single-value"], ["alt", "", 1, "orc-value-avatar", 3, "src"], ["aria-hidden", "true", 1, "orc-value-icon", 3, "class"], [1, "orc-value-text"], ["aria-hidden", "true", 1, "orc-value-icon"], ["type", "button", "aria-label", "Limpar sele\u00E7\u00E3o", 1, "orc-select-clear-btn", 3, "click"], ["role", "listbox", 1, "orc-select-dropdown", 3, "id"], [1, "orc-select-search-container"], [1, "orc-select-options-list"], ["type", "text", 1, "orc-select-search-input", 3, "input", "keydown", "placeholder", "value"], ["role", "option", 1, "orc-data-option", 3, "is-selected", "is-active", "is-disabled"], [1, "orc-select-empty-state"], ["role", "option", 1, "orc-data-option", 3, "click"], ["alt", "", 1, "orc-option-avatar", 3, "src"], ["aria-hidden", "true", 1, "orc-option-icon", 3, "class"], [1, "orc-option-content"], [1, "orc-option-label"], [1, "orc-option-description"], ["viewBox", "0 0 20 20", "fill", "currentColor", 1, "orc-option-checkmark"], ["aria-hidden", "true", 1, "orc-option-icon"], ["fill-rule", "evenodd", "d", "M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z", "clip-rule", "evenodd"]], template: function SelectComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c3);
            i0.ɵɵelementStart(0, "div", 3);
            i0.ɵɵtemplate(1, SelectComponent_Conditional_1_Template, 3, 3, "label", 4);
            i0.ɵɵelementStart(2, "div", 5, 0);
            i0.ɵɵlistener("click", function SelectComponent_Template_div_click_2_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.togglePanel()); })("keydown", function SelectComponent_Template_div_keydown_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeyDown($event)); })("focus", function SelectComponent_Template_div_focus_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onTriggerFocus($event)); })("blur", function SelectComponent_Template_div_blur_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onTriggerBlur($event)); });
            i0.ɵɵelementStart(4, "div", 6);
            i0.ɵɵprojection(5, 0, null, SelectComponent_ProjectionFallback_5_Template, 2, 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 7);
            i0.ɵɵtemplate(8, SelectComponent_Conditional_8_Template, 2, 0, "button", 8);
            i0.ɵɵelementStart(9, "div", 9);
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(10, "svg", 10);
            i0.ɵɵelement(11, "path", 11);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(12, SelectComponent_Conditional_12_Template, 2, 2, "p", 12)(13, SelectComponent_Conditional_13_Template, 2, 2, "p", 13);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(14, SelectComponent_ng_template_14_Template, 7, 4, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵclassProp("is-disabled", ctx.effectiveDisabled())("is-invalid", ctx.isInvalid());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("is-open", ctx.isOpen())("is-focused", ctx.isFocused())("is-disabled", ctx.effectiveDisabled())("is-readonly", ctx.readonly())("is-invalid", ctx.isInvalid());
            i0.ɵɵproperty("id", ctx.effectiveId());
            i0.ɵɵattribute("aria-expanded", ctx.isOpen())("aria-controls", ctx.listboxId())("aria-haspopup", "listbox")("aria-disabled", ctx.effectiveDisabled())("aria-invalid", ctx.isInvalid())("aria-describedby", ctx.computedAriaDescribedBy())("tabindex", ctx.effectiveDisabled() ? -1 : 0);
            i0.ɵɵadvance(6);
            i0.ɵɵconditional(ctx.clearable() && ctx.hasValue() && !ctx.effectiveDisabled() && !ctx.readonly() ? 8 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("is-expanded", ctx.isOpen());
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.isInvalid() && ctx.errorMessage() ? 12 : ctx.helperText() ? 13 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-select-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box}.orc-select-wrapper.is-disabled[_ngcontent-%COMP%]{opacity:.6;pointer-events:none}.orc-select-label[_ngcontent-%COMP%]{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);display:inline-flex;align-items:center;gap:var(--space-1, .25rem)}.orc-select-required-asterisk[_ngcontent-%COMP%]{color:var(--color-error, #FB2C36)}.orc-select-trigger[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;min-height:41px;width:100%;padding:.625rem;background-color:var(--orc-fill-input, #FFFFFF);border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-md, .625rem);box-sizing:border-box;cursor:pointer;outline:none;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-select-trigger[_ngcontent-%COMP%]:hover:not(.is-disabled):not(.is-readonly){border-color:var(--border-strong, #D9D9D9)}.orc-select-trigger.is-focused[_ngcontent-%COMP%], .orc-select-trigger.is-open[_ngcontent-%COMP%]{border-color:var(--color-accent, #141414);box-shadow:0 0 0 1px var(--color-accent, #141414)}.orc-select-trigger.is-invalid[_ngcontent-%COMP%]{border-color:var(--color-error, #FB2C36)!important}.orc-select-trigger.is-invalid.is-focused[_ngcontent-%COMP%], .orc-select-trigger.is-invalid.is-open[_ngcontent-%COMP%]{box-shadow:0 0 0 1px var(--color-error, #FB2C36)!important}.orc-select-trigger.is-disabled[_ngcontent-%COMP%]{cursor:not-allowed;background-color:var(--bg-subtle, #F9F9F9)}.orc-select-trigger-content[_ngcontent-%COMP%]{display:flex;align-items:center;flex:1 1 auto;min-width:0;overflow:hidden}.orc-select-placeholder[_ngcontent-%COMP%]{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-font-secondary, #666666);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-single-value[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2, .5rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-value-avatar[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-value-icon[_ngcontent-%COMP%]{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-value-text[_ngcontent-%COMP%]{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-chips[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:.375rem;width:100%}.orc-select-chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem .5rem;background-color:var(--orc-highlight-cinza-claro, #EDEDED);border-radius:var(--radius-sm, .375rem);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.75rem;color:var(--orc-font-main, #141414)}.orc-chip-avatar[_ngcontent-%COMP%]{width:1rem;height:1rem;border-radius:var(--radius-full, 9999px)}.orc-chip-icon[_ngcontent-%COMP%]{font-size:.875rem}.orc-chip-label[_ngcontent-%COMP%]{white-space:nowrap}.orc-chip-remove[_ngcontent-%COMP%]{background:transparent;border:none;color:var(--orc-font-secondary, #666666);font-size:.875rem;line-height:1;cursor:pointer;padding:0 .125rem;display:inline-flex;align-items:center;justify-content:center;border-radius:50%}.orc-chip-remove[_ngcontent-%COMP%]:hover{color:var(--color-error, #FB2C36);background-color:#0000000d}.orc-select-actions[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.25rem;margin-left:.5rem;flex-shrink:0}.orc-select-clear-btn[_ngcontent-%COMP%]{background:transparent;border:none;color:var(--orc-font-secondary, #666666);font-size:1.125rem;cursor:pointer;padding:0 .25rem;line-height:1}.orc-select-clear-btn[_ngcontent-%COMP%]:hover{color:var(--orc-font-main, #141414)}.orc-select-arrow[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;color:var(--orc-font-main, #141414);transition:transform var(--transition-fast, .12s ease)}.orc-select-arrow.is-expanded[_ngcontent-%COMP%]{transform:rotate(180deg)}.orc-select-dropdown[_ngcontent-%COMP%]{background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-md, .625rem);box-shadow:var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, .08));padding:.625rem;display:flex;flex-direction:column;gap:.25rem;box-sizing:border-box;max-height:260px;overflow:hidden;z-index:1000}.orc-select-search-container[_ngcontent-%COMP%]{padding-bottom:.5rem;border-bottom:1px solid var(--orc-border, #D9D9D9);margin-bottom:.25rem}.orc-select-search-input[_ngcontent-%COMP%]{width:100%;padding:.5rem .625rem;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-sm, .375rem);outline:none;box-sizing:border-box}.orc-select-search-input[_ngcontent-%COMP%]:focus{border-color:var(--color-accent, #141414)}.orc-select-options-list[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.125rem;overflow-y:auto;max-height:200px}.orc-select-options-list[_ngcontent-%COMP%]::-webkit-scrollbar{width:6px}.orc-select-options-list[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{background:var(--border-strong, #D9D9D9);border-radius:var(--radius-full, 9999px)}.orc-data-option[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease)}.orc-data-option[_ngcontent-%COMP%]:hover, .orc-data-option.is-active[_ngcontent-%COMP%], .orc-data-option.is-selected[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-data-option.is-disabled[_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed}.orc-data-option.is-disabled[_ngcontent-%COMP%]:hover{background-color:transparent}.orc-option-avatar[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon[_ngcontent-%COMP%]{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label[_ngcontent-%COMP%]{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description[_ngcontent-%COMP%]{font-size:.75rem;color:var(--orc-font-secondary, #666666);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark[_ngcontent-%COMP%]{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-font-main, #141414)}.orc-select-empty-state[_ngcontent-%COMP%]{padding:.75rem;text-align:center;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-font-secondary, #666666)}.orc-select-message[_ngcontent-%COMP%]{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem}.orc-select-message.is-error[_ngcontent-%COMP%]{color:var(--color-error, #FB2C36)}.orc-select-message.is-helper[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SelectComponent, [{
        type: Component,
        args: [{ selector: 'orc-select', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => SelectComponent),
                        multi: true,
                    },
                ], template: "<div class=\"orc-select-wrapper\" [class.is-disabled]=\"effectiveDisabled()\" [class.is-invalid]=\"isInvalid()\">\n  <!-- Label -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-select-label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-select-required-asterisk\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- Main Combobox Trigger -->\n  <div\n    #triggerEl\n    [id]=\"effectiveId()\"\n    class=\"orc-select-trigger\"\n    [class.is-open]=\"isOpen()\"\n    [class.is-focused]=\"isFocused()\"\n    [class.is-disabled]=\"effectiveDisabled()\"\n    [class.is-readonly]=\"readonly()\"\n    [class.is-invalid]=\"isInvalid()\"\n    role=\"combobox\"\n    [attr.aria-expanded]=\"isOpen()\"\n    [attr.aria-controls]=\"listboxId()\"\n    [attr.aria-haspopup]=\"'listbox'\"\n    [attr.aria-disabled]=\"effectiveDisabled()\"\n    [attr.aria-invalid]=\"isInvalid()\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.tabindex]=\"effectiveDisabled() ? -1 : 0\"\n    (click)=\"togglePanel()\"\n    (keydown)=\"onKeyDown($event)\"\n    (focus)=\"onTriggerFocus($event)\"\n    (blur)=\"onTriggerBlur($event)\"\n  >\n    <div class=\"orc-select-trigger-content\">\n      <ng-content select=\"[orcSelectTrigger], [selectTrigger]\">\n        @if (multiple()) {\n          @if (selectedItems().length > 0) {\n            <div class=\"orc-select-chips\">\n              @for (item of selectedItems(); track item.value) {\n                <span class=\"orc-select-chip\">\n                  @if (item.avatarUrl) {\n                    <img [src]=\"item.avatarUrl\" alt=\"\" class=\"orc-chip-avatar\" />\n                  } @else if (item.icon) {\n                    <i [class]=\"item.icon\" class=\"orc-chip-icon\" aria-hidden=\"true\"></i>\n                  }\n                  <span class=\"orc-chip-label\">{{ item.label }}</span>\n                  @if (!effectiveDisabled() && !readonly()) {\n                    <button\n                      type=\"button\"\n                      class=\"orc-chip-remove\"\n                      aria-label=\"Remover op\u00E7\u00E3o\"\n                      (click)=\"removeSelectedItem(item.value, $event)\"\n                    >\n                      &times;\n                    </button>\n                  }\n                </span>\n              }\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        } @else {\n          @if (hasValue()) {\n            <div class=\"orc-select-single-value\">\n              @if (selectedItems()[0].avatarUrl) {\n                <img [src]=\"selectedItems()[0].avatarUrl\" alt=\"\" class=\"orc-value-avatar\" />\n              } @else if (selectedItems()[0].icon) {\n                <i [class]=\"selectedItems()[0].icon\" class=\"orc-value-icon\" aria-hidden=\"true\"></i>\n              }\n              <span class=\"orc-value-text\">{{ selectedItems()[0].label }}</span>\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        }\n      </ng-content>\n    </div>\n\n    <!-- Actions (Clear & Chevron Arrow) -->\n    <div class=\"orc-select-actions\">\n      @if (clearable() && hasValue() && !effectiveDisabled() && !readonly()) {\n        <button\n          type=\"button\"\n          class=\"orc-select-clear-btn\"\n          aria-label=\"Limpar sele\u00E7\u00E3o\"\n          (click)=\"clearValue($event)\"\n        >\n          &times;\n        </button>\n      }\n\n      <div class=\"orc-select-arrow\" [class.is-expanded]=\"isOpen()\">\n        <svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <path d=\"M5 7.5L10 12.5L15 7.5\" stroke=\"currentColor\" stroke-width=\"1.67\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n      </div>\n    </div>\n  </div>\n\n  <!-- Helper Text or Error Message -->\n  @if (isInvalid() && errorMessage()) {\n    <p [id]=\"errorId()\" class=\"orc-select-message is-error\">\n      {{ errorMessage() }}\n    </p>\n  } @else if (helperText()) {\n    <p [id]=\"helperId()\" class=\"orc-select-message is-helper\">\n      {{ helperText() }}\n    </p>\n  }\n</div>\n\n<!-- Floating Dropdown Panel Template -->\n<ng-template #dropdownPanel>\n  <div\n    [id]=\"listboxId()\"\n    class=\"orc-select-dropdown\"\n    role=\"listbox\"\n    [attr.aria-multiselectable]=\"multiple()\"\n  >\n    <!-- Header projection -->\n    <ng-content select=\"[orcSelectHeader]\"></ng-content>\n\n    <!-- Search Input -->\n    @if (searchable()) {\n      <div class=\"orc-select-search-container\">\n        <input\n          #searchInput\n          type=\"text\"\n          class=\"orc-select-search-input\"\n          [placeholder]=\"searchPlaceholder()\"\n          [value]=\"searchTerm()\"\n          (input)=\"onSearchInput($event)\"\n          (keydown)=\"onKeyDown($event)\"\n        />\n      </div>\n    }\n\n    <!-- Options Container -->\n    <div class=\"orc-select-options-list\">\n      @if (isDataMode()) {\n        @for (opt of filteredDataOptions(); track opt.value; let idx = $index) {\n          <div\n            class=\"orc-data-option\"\n            [class.is-selected]=\"multiple() ? (value() || []).includes(opt.value) : value() === opt.value\"\n            [class.is-active]=\"activeOptionIndex() === idx\"\n            [class.is-disabled]=\"opt.disabled\"\n            role=\"option\"\n            [attr.aria-selected]=\"multiple() ? (value() || []).includes(opt.value) : value() === opt.value\"\n            [attr.aria-disabled]=\"opt.disabled\"\n            (click)=\"onDataOptionClick(opt)\"\n          >\n            @if (opt.avatarUrl) {\n              <img [src]=\"opt.avatarUrl\" alt=\"\" class=\"orc-option-avatar\" />\n            } @else if (opt.icon) {\n              <i [class]=\"opt.icon\" class=\"orc-option-icon\" aria-hidden=\"true\"></i>\n            }\n            <div class=\"orc-option-content\">\n              <span class=\"orc-option-label\">{{ opt.label }}</span>\n              @if (opt.description) {\n                <span class=\"orc-option-description\">{{ opt.description }}</span>\n              }\n            </div>\n            @if (multiple() ? (value() || []).includes(opt.value) : value() === opt.value) {\n              <svg class=\"orc-option-checkmark\" viewBox=\"0 0 20 20\" fill=\"currentColor\">\n                <path fill-rule=\"evenodd\" d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\" clip-rule=\"evenodd\" />\n              </svg>\n            }\n          </div>\n        } @empty {\n          <div class=\"orc-select-empty-state\">\n            {{ searchEmptyText() }}\n          </div>\n        }\n      } @else {\n        <!-- Projected <orc-option> elements -->\n        <ng-content></ng-content>\n      }\n    </div>\n\n    <!-- Footer projection -->\n    <ng-content select=\"[orcSelectFooter]\"></ng-content>\n  </div>\n</ng-template>\n", styles: [":host{display:block;width:100%}.orc-select-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box}.orc-select-wrapper.is-disabled{opacity:.6;pointer-events:none}.orc-select-label{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);display:inline-flex;align-items:center;gap:var(--space-1, .25rem)}.orc-select-required-asterisk{color:var(--color-error, #FB2C36)}.orc-select-trigger{display:flex;align-items:center;justify-content:space-between;min-height:41px;width:100%;padding:.625rem;background-color:var(--orc-fill-input, #FFFFFF);border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-md, .625rem);box-sizing:border-box;cursor:pointer;outline:none;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-select-trigger:hover:not(.is-disabled):not(.is-readonly){border-color:var(--border-strong, #D9D9D9)}.orc-select-trigger.is-focused,.orc-select-trigger.is-open{border-color:var(--color-accent, #141414);box-shadow:0 0 0 1px var(--color-accent, #141414)}.orc-select-trigger.is-invalid{border-color:var(--color-error, #FB2C36)!important}.orc-select-trigger.is-invalid.is-focused,.orc-select-trigger.is-invalid.is-open{box-shadow:0 0 0 1px var(--color-error, #FB2C36)!important}.orc-select-trigger.is-disabled{cursor:not-allowed;background-color:var(--bg-subtle, #F9F9F9)}.orc-select-trigger-content{display:flex;align-items:center;flex:1 1 auto;min-width:0;overflow:hidden}.orc-select-placeholder{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-font-secondary, #666666);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-single-value{display:flex;align-items:center;gap:var(--space-2, .5rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-value-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-value-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-value-text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-chips{display:flex;flex-wrap:wrap;gap:.375rem;width:100%}.orc-select-chip{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem .5rem;background-color:var(--orc-highlight-cinza-claro, #EDEDED);border-radius:var(--radius-sm, .375rem);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.75rem;color:var(--orc-font-main, #141414)}.orc-chip-avatar{width:1rem;height:1rem;border-radius:var(--radius-full, 9999px)}.orc-chip-icon{font-size:.875rem}.orc-chip-label{white-space:nowrap}.orc-chip-remove{background:transparent;border:none;color:var(--orc-font-secondary, #666666);font-size:.875rem;line-height:1;cursor:pointer;padding:0 .125rem;display:inline-flex;align-items:center;justify-content:center;border-radius:50%}.orc-chip-remove:hover{color:var(--color-error, #FB2C36);background-color:#0000000d}.orc-select-actions{display:flex;align-items:center;gap:.25rem;margin-left:.5rem;flex-shrink:0}.orc-select-clear-btn{background:transparent;border:none;color:var(--orc-font-secondary, #666666);font-size:1.125rem;cursor:pointer;padding:0 .25rem;line-height:1}.orc-select-clear-btn:hover{color:var(--orc-font-main, #141414)}.orc-select-arrow{display:flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;color:var(--orc-font-main, #141414);transition:transform var(--transition-fast, .12s ease)}.orc-select-arrow.is-expanded{transform:rotate(180deg)}.orc-select-dropdown{background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-md, .625rem);box-shadow:var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, .08));padding:.625rem;display:flex;flex-direction:column;gap:.25rem;box-sizing:border-box;max-height:260px;overflow:hidden;z-index:1000}.orc-select-search-container{padding-bottom:.5rem;border-bottom:1px solid var(--orc-border, #D9D9D9);margin-bottom:.25rem}.orc-select-search-input{width:100%;padding:.5rem .625rem;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;border:1px solid var(--orc-border, #D9D9D9);border-radius:var(--radius-sm, .375rem);outline:none;box-sizing:border-box}.orc-select-search-input:focus{border-color:var(--color-accent, #141414)}.orc-select-options-list{display:flex;flex-direction:column;gap:.125rem;overflow-y:auto;max-height:200px}.orc-select-options-list::-webkit-scrollbar{width:6px}.orc-select-options-list::-webkit-scrollbar-thumb{background:var(--border-strong, #D9D9D9);border-radius:var(--radius-full, 9999px)}.orc-data-option{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease)}.orc-data-option:hover,.orc-data-option.is-active,.orc-data-option.is-selected{background-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-data-option.is-disabled{opacity:.5;cursor:not-allowed}.orc-data-option.is-disabled:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;color:var(--orc-font-secondary, #666666);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-font-main, #141414)}.orc-select-empty-state{padding:.75rem;text-align:center;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-font-secondary, #666666)}.orc-select-message{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem}.orc-select-message.is-error{color:var(--color-error, #FB2C36)}.orc-select-message.is-helper{color:var(--orc-font-secondary, #666666)}\n"] }]
    }], () => [], { onDocumentClick: [{
            type: HostListener,
            args: ['document:click', ['$event.target']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SelectComponent, { className: "SelectComponent", filePath: "select.component.ts", lineNumber: 49 }); })();

// src/app/shared/select/select.types.ts

/**
 * Generated bundle index. Do not edit.
 */

export { OptionComponent, SelectComponent };
//# sourceMappingURL=ciag-orchestra-select.mjs.map
