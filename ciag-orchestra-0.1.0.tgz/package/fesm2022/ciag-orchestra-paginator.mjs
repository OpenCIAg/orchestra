import * as i0 from '@angular/core';
import { input, model, output, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

function PaginatorComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtext(1, " Exibindo ");
    i0.ɵɵelementStart(2, "strong");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtext(4, " de ");
    i0.ɵɵelementStart(5, "strong");
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd();
    i0.ɵɵtext(7, " itens ");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate2("", ctx_r0.startIndex(), "\u2013", ctx_r0.endIndex(), "");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r0.totalItems());
} }
function PaginatorComponent_li_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "button", 7);
    i0.ɵɵlistener("click", function PaginatorComponent_li_3_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.firstPage()); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(2, "svg", 8);
    i0.ɵɵelement(3, "path", 9);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.isFirstPage() || ctx_r0.disabled())("title", ctx_r0.firstLabel());
    i0.ɵɵattribute("aria-disabled", ctx_r0.isFirstPage() || ctx_r0.disabled())("aria-label", ctx_r0.firstLabel());
} }
function PaginatorComponent_li_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "button", 10);
    i0.ɵɵlistener("click", function PaginatorComponent_li_4_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r3); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.prevPage()); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(2, "svg", 8);
    i0.ɵɵelement(3, "path", 11);
    i0.ɵɵelementEnd();
    i0.ɵɵnamespaceHTML();
    i0.ɵɵelementStart(4, "span", 12);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.isFirstPage() || ctx_r0.disabled());
    i0.ɵɵattribute("aria-disabled", ctx_r0.isFirstPage() || ctx_r0.disabled())("aria-label", ctx_r0.previousLabel());
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r0.previousLabel());
} }
function PaginatorComponent_ng_container_5_li_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "button", 14);
    i0.ɵɵlistener("click", function PaginatorComponent_ng_container_5_li_1_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r4); const p_r5 = i0.ɵɵnextContext().$implicit; const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.goToPage(+p_r5)); });
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const p_r5 = i0.ɵɵnextContext().$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵclassProp("orc-paginator__btn--active", p_r5 === ctx_r0.currentPage());
    i0.ɵɵproperty("disabled", ctx_r0.disabled());
    i0.ɵɵattribute("aria-current", p_r5 === ctx_r0.currentPage() ? "page" : null)("aria-label", "Ir para a p\u00E1gina " + p_r5);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", p_r5, " ");
} }
function PaginatorComponent_ng_container_5_li_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 15);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 16);
    i0.ɵɵelement(2, "circle", 17)(3, "circle", 18)(4, "circle", 19);
    i0.ɵɵelementEnd()();
} }
function PaginatorComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, PaginatorComponent_ng_container_5_li_1_Template, 3, 6, "li", 3)(2, PaginatorComponent_ng_container_5_li_2_Template, 5, 0, "li", 13);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const p_r5 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", p_r5 !== "ellipsis");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", p_r5 === "ellipsis");
} }
function PaginatorComponent_li_6_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "button", 20);
    i0.ɵɵlistener("click", function PaginatorComponent_li_6_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r6); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.nextPage()); });
    i0.ɵɵelementStart(2, "span", 12);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(4, "svg", 8);
    i0.ɵɵelement(5, "path", 21);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.isLastPage() || ctx_r0.disabled());
    i0.ɵɵattribute("aria-disabled", ctx_r0.isLastPage() || ctx_r0.disabled())("aria-label", ctx_r0.nextLabel());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.nextLabel());
} }
function PaginatorComponent_li_7_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "button", 22);
    i0.ɵɵlistener("click", function PaginatorComponent_li_7_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r7); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.lastPage()); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(2, "svg", 8);
    i0.ɵɵelement(3, "path", 23);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.isLastPage() || ctx_r0.disabled())("title", ctx_r0.lastLabel());
    i0.ɵɵattribute("aria-disabled", ctx_r0.isLastPage() || ctx_r0.disabled())("aria-label", ctx_r0.lastLabel());
} }
function PaginatorComponent_div_8_option_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 30);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const opt_r9 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("value", opt_r9);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2(" ", opt_r9, " / ", ctx_r0.itemsPerPageLabel(), " ");
} }
function PaginatorComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 24)(1, "select", 25);
    i0.ɵɵlistener("change", function PaginatorComponent_div_8_Template_select_change_1_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onPageSizeChange($event)); });
    i0.ɵɵtemplate(2, PaginatorComponent_div_8_option_2_Template, 2, 3, "option", 26);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "div", 27);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(4, "svg", 28);
    i0.ɵɵelement(5, "path", 29);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", ctx_r0.disabled())("value", ctx_r0.pageSize());
    i0.ɵɵattribute("aria-label", "Quantidade de itens por p\u00E1gina");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r0.pageSizeOptions());
} }
class PaginatorComponent {
    // ── Inputs & Models (Signals API) ─────────────────────────
    /** Total de itens na coleção de dados */
    totalItems = input(0);
    /** Quantidade de itens por página (Two-Way Data Binding) */
    pageSize = model(10);
    /** Página atual selecionada (1-indexed, Two-Way Data Binding) */
    currentPage = model(1);
    /** Opções de quantidade de itens por página */
    pageSizeOptions = input([10, 20, 50]);
    /** Se deve exibir o seletor de quantidade de itens por página */
    showPageSizeSelector = input(true);
    /** Se deve exibir os botões de Primeira e Última página */
    showFirstLastButtons = input(false);
    /** Se deve exibir os botões Anterior e Próximo */
    showPrevNextButtons = input(true);
    /** Se deve exibir o texto informativo de total (ex: 1-20 de 100 itens) */
    showTotalInfo = input(false);
    /** Se o componente está desabilitado */
    disabled = input(false);
    /** Tamanho visual do componente ('sm' | 'md' | 'lg') */
    size = input('md');
    /** Quantidade máxima de botões numéricos visíveis antes de colapsar */
    maxVisiblePages = input(7);
    /** Rótulo do botão Anterior */
    previousLabel = input('Anterior');
    /** Rótulo do botão Próximo */
    nextLabel = input('Próximo');
    /** Rótulo do botão Primeira Página */
    firstLabel = input('Primeira');
    /** Rótulo do botão Última Página */
    lastLabel = input('Última');
    /** Sufixo exibido no seletor de itens (ex: "20 / Página") */
    itemsPerPageLabel = input('Página');
    /** Atributo de acessibilidade aria-label da tag nav */
    ariaLabel = input('Paginação');
    // ── Outputs (Event Emitting) ──────────────────────────────
    /** Disparado sempre que a página ou o pageSize é alterado */
    pageChange = output();
    /** Disparado exclusivamente quando o pageSize é alterado */
    pageSizeChange = output();
    // ── Computeds (Reatividade Inteligente) ────────────────────
    /** Total de páginas calculado dinamicamente */
    totalPages = computed(() => {
        const total = this.totalItems();
        const size = Math.max(1, this.pageSize() || 1);
        return Math.max(1, Math.ceil(total / size));
    });
    /** Índice inicial do intervalo visível (1-indexed) */
    startIndex = computed(() => {
        if (this.totalItems() === 0)
            return 0;
        return (this.currentPage() - 1) * this.pageSize() + 1;
    });
    /** Índice final do intervalo visível (1-indexed) */
    endIndex = computed(() => {
        return Math.min(this.currentPage() * this.pageSize(), this.totalItems());
    });
    /** Se está na primeira página */
    isFirstPage = computed(() => this.currentPage() <= 1);
    /** Se está na última página */
    isLastPage = computed(() => this.currentPage() >= this.totalPages());
    /** Lista inteligente de páginas e reticências a serem renderizadas */
    visiblePages = computed(() => {
        const total = this.totalPages();
        const current = this.currentPage();
        const max = Math.max(5, this.maxVisiblePages());
        if (total <= max) {
            return Array.from({ length: total }, (_, i) => i + 1);
        }
        const pages = [];
        const leftSibling = Math.max(current - 1, 1);
        const rightSibling = Math.min(current + 1, total);
        const showLeftEllipsis = leftSibling > 2;
        const showRightEllipsis = rightSibling < total - 2;
        if (!showLeftEllipsis && showRightEllipsis) {
            // Perto do início: 1, 2, 3, ..., total
            const count = 3;
            for (let i = 1; i <= count; i++) {
                pages.push(i);
            }
            pages.push('ellipsis');
            pages.push(total);
        }
        else if (showLeftEllipsis && !showRightEllipsis) {
            // Perto do fim: 1, ..., total-2, total-1, total
            pages.push(1);
            pages.push('ellipsis');
            const count = 3;
            for (let i = total - count + 1; i <= total; i++) {
                pages.push(i);
            }
        }
        else {
            // No meio: 1, ..., current-1, current, current+1, ..., total
            pages.push(1);
            pages.push('ellipsis');
            for (let i = leftSibling; i <= rightSibling; i++) {
                pages.push(i);
            }
            pages.push('ellipsis');
            pages.push(total);
        }
        return pages;
    });
    // ── Ações de Navegação ────────────────────────────────────
    /** Navega para uma página específica */
    goToPage(page) {
        if (this.disabled())
            return;
        const target = Math.max(1, Math.min(page, this.totalPages()));
        if (target !== this.currentPage()) {
            this.currentPage.set(target);
            this.emitPageChangeEvent();
        }
    }
    /** Navega para a página anterior */
    prevPage() {
        if (!this.isFirstPage() && !this.disabled()) {
            this.goToPage(this.currentPage() - 1);
        }
    }
    /** Navega para a próxima página */
    nextPage() {
        if (!this.isLastPage() && !this.disabled()) {
            this.goToPage(this.currentPage() + 1);
        }
    }
    /** Navega para a primeira página */
    firstPage() {
        if (!this.isFirstPage() && !this.disabled()) {
            this.goToPage(1);
        }
    }
    /** Navega para a última página */
    lastPage() {
        if (!this.isLastPage() && !this.disabled()) {
            this.goToPage(this.totalPages());
        }
    }
    /** Manipula a mudança de itens por página via select */
    onPageSizeChange(event) {
        if (this.disabled())
            return;
        const select = event.target;
        const newSize = Number(select.value);
        if (newSize && newSize !== this.pageSize()) {
            this.pageSize.set(newSize);
            this.pageSizeChange.emit(newSize);
            // Ajusta a página atual caso exceda o novo total de páginas
            const newTotalPages = Math.max(1, Math.ceil(this.totalItems() / newSize));
            if (this.currentPage() > newTotalPages) {
                this.currentPage.set(newTotalPages);
            }
            this.emitPageChangeEvent();
        }
    }
    /** Emite o evento unificado de alteração */
    emitPageChangeEvent() {
        this.pageChange.emit({
            page: this.currentPage(),
            pageSize: this.pageSize(),
            totalPages: this.totalPages(),
            startIndex: this.startIndex(),
            endIndex: this.endIndex(),
            totalItems: this.totalItems(),
        });
    }
    static ɵfac = function PaginatorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PaginatorComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PaginatorComponent, selectors: [["orc-paginator"]], inputs: { totalItems: [1, "totalItems"], pageSize: [1, "pageSize"], currentPage: [1, "currentPage"], pageSizeOptions: [1, "pageSizeOptions"], showPageSizeSelector: [1, "showPageSizeSelector"], showFirstLastButtons: [1, "showFirstLastButtons"], showPrevNextButtons: [1, "showPrevNextButtons"], showTotalInfo: [1, "showTotalInfo"], disabled: [1, "disabled"], size: [1, "size"], maxVisiblePages: [1, "maxVisiblePages"], previousLabel: [1, "previousLabel"], nextLabel: [1, "nextLabel"], firstLabel: [1, "firstLabel"], lastLabel: [1, "lastLabel"], itemsPerPageLabel: [1, "itemsPerPageLabel"], ariaLabel: [1, "ariaLabel"] }, outputs: { pageSize: "pageSizeChange", currentPage: "currentPageChange", pageChange: "pageChange", pageSizeChange: "pageSizeChange" }, decls: 9, vars: 14, consts: [[1, "orc-paginator"], ["class", "orc-paginator__info", 4, "ngIf"], ["role", "list", 1, "orc-paginator__list"], [4, "ngIf"], [4, "ngFor", "ngForOf"], ["class", "orc-paginator__page-size", 4, "ngIf"], [1, "orc-paginator__info"], ["type", "button", 1, "orc-paginator__btn", "orc-paginator__btn--nav", "orc-paginator__btn--first", 3, "click", "disabled", "title"], ["viewBox", "0 0 16 16", "fill", "none", "aria-hidden", "true", 1, "orc-paginator__icon"], ["d", "M11 12L7 8L11 4M7 12L3 8L7 4", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["type", "button", 1, "orc-paginator__btn", "orc-paginator__btn--nav", "orc-paginator__btn--prev", 3, "click", "disabled"], ["d", "M10 12L6 8L10 4", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-paginator__btn-text"], ["class", "orc-paginator__ellipsis", "aria-hidden", "true", 4, "ngIf"], ["type", "button", 1, "orc-paginator__btn", "orc-paginator__btn--page", 3, "click", "disabled"], ["aria-hidden", "true", 1, "orc-paginator__ellipsis"], ["viewBox", "0 0 16 16", "fill", "none", 1, "orc-paginator__icon-dots"], ["cx", "4", "cy", "8", "r", "1.25", "fill", "currentColor"], ["cx", "8", "cy", "8", "r", "1.25", "fill", "currentColor"], ["cx", "12", "cy", "8", "r", "1.25", "fill", "currentColor"], ["type", "button", 1, "orc-paginator__btn", "orc-paginator__btn--nav", "orc-paginator__btn--next", 3, "click", "disabled"], ["d", "M6 4L10 8L6 12", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["type", "button", 1, "orc-paginator__btn", "orc-paginator__btn--nav", "orc-paginator__btn--last", 3, "click", "disabled", "title"], ["d", "M5 4L9 8L5 12M9 4L13 8L9 12", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-paginator__page-size"], [1, "orc-paginator__select", 3, "change", "disabled", "value"], [3, "value", 4, "ngFor", "ngForOf"], ["aria-hidden", "true", 1, "orc-paginator__select-icon"], ["viewBox", "0 0 16 16", "fill", "none"], ["d", "M4 6L8 10L12 6", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], [3, "value"]], template: function PaginatorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "nav", 0);
            i0.ɵɵtemplate(1, PaginatorComponent_div_1_Template, 8, 3, "div", 1);
            i0.ɵɵelementStart(2, "ul", 2);
            i0.ɵɵtemplate(3, PaginatorComponent_li_3_Template, 4, 4, "li", 3)(4, PaginatorComponent_li_4_Template, 6, 4, "li", 3)(5, PaginatorComponent_ng_container_5_Template, 3, 2, "ng-container", 4)(6, PaginatorComponent_li_6_Template, 6, 4, "li", 3)(7, PaginatorComponent_li_7_Template, 4, 4, "li", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(8, PaginatorComponent_div_8_Template, 6, 4, "div", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-paginator--disabled", ctx.disabled())("orc-paginator--sm", ctx.size() === "sm")("orc-paginator--lg", ctx.size() === "lg");
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showTotalInfo());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.showFirstLastButtons());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showPrevNextButtons());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.visiblePages());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showPrevNextButtons());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showFirstLastButtons());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showPageSizeSelector() && ctx.pageSizeOptions().length > 0);
        } }, dependencies: [CommonModule, i1.NgForOf, i1.NgIf, FormsModule, i2.NgSelectOption, i2.ɵNgSelectMultipleOption], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-paginator[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4, 16px);width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif);-webkit-user-select:none;user-select:none}.orc-paginator__info[_ngcontent-%COMP%]{font-size:.875rem;color:var(--orc-font-secondary, #666666);white-space:nowrap}.orc-paginator__info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414);font-weight:600}.orc-paginator__list[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:4px;list-style:none;margin:0;padding:0;height:36px}.orc-paginator__btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;height:36px;background:transparent;border:none;border-radius:8px;color:var(--orc-font-main, #141414);font-family:inherit;font-size:.875rem;font-weight:400;line-height:20px;cursor:pointer;transition:all var(--transition-fast, .12s ease);outline:none;text-decoration:none}.orc-paginator__btn[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--bg-subtle, #f9f9f9);color:var(--orc-color-azul-royal, #0406ab)}.orc-paginator__btn[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-paginator__btn[_ngcontent-%COMP%]:disabled, .orc-paginator__btn[aria-disabled=true][_ngcontent-%COMP%]{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-paginator__btn--page[_ngcontent-%COMP%]{min-width:36px;width:36px;padding:0}.orc-paginator__btn--active[_ngcontent-%COMP%]{background:var(--orc-th, #f9f9f9);font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-paginator__btn--active[_ngcontent-%COMP%]:hover{background:var(--orc-th, #f9f9f9);color:var(--orc-font-main, #141414)}.orc-paginator__btn--nav[_ngcontent-%COMP%]{padding:8px 12px;gap:4px;min-width:36px}.orc-paginator__btn--first[_ngcontent-%COMP%], .orc-paginator__btn--last[_ngcontent-%COMP%]{padding:0;width:36px}.orc-paginator__btn-text[_ngcontent-%COMP%]{font-size:.875rem;line-height:20px;color:inherit}.orc-paginator__icon[_ngcontent-%COMP%]{width:16px;height:16px;display:block;flex-shrink:0}.orc-paginator__ellipsis[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;color:var(--orc-font-secondary, #666666)}.orc-paginator__icon-dots[_ngcontent-%COMP%]{width:16px;height:16px}.orc-paginator__page-size[_ngcontent-%COMP%]{position:relative;display:inline-flex;align-items:center;height:36px}.orc-paginator__select[_ngcontent-%COMP%]{appearance:none;-webkit-appearance:none;-moz-appearance:none;height:36px;background:var(--orc-fill-input, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;padding:3px 36px 3px 12px;font-family:inherit;font-size:.875rem;line-height:22px;color:var(--orc-font-secondary, #666666);cursor:pointer;outline:none;transition:all var(--transition-fast, .12s ease)}.orc-paginator__select[_ngcontent-%COMP%]:hover:not(:disabled){border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-font-main, #141414)}.orc-paginator__select[_ngcontent-%COMP%]:focus-visible{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed26}.orc-paginator__select[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:not-allowed;background:var(--bg-muted, #ededed)}.orc-paginator__select-icon[_ngcontent-%COMP%]{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:16px;height:16px;color:var(--orc-font-secondary, #666666);pointer-events:none;display:flex;align-items:center;justify-content:center}.orc-paginator__select-icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__list[_ngcontent-%COMP%], .orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__page-size[_ngcontent-%COMP%]{height:30px}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__btn[_ngcontent-%COMP%]{height:30px;font-size:.75rem}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__btn--page[_ngcontent-%COMP%]{width:30px;min-width:30px}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__btn--nav[_ngcontent-%COMP%]{padding:4px 8px}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__ellipsis[_ngcontent-%COMP%]{width:30px;height:30px}.orc-paginator--sm[_ngcontent-%COMP%]   .orc-paginator__select[_ngcontent-%COMP%]{height:30px;font-size:.75rem;padding:2px 30px 2px 10px;border-radius:8px}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__list[_ngcontent-%COMP%], .orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__page-size[_ngcontent-%COMP%]{height:42px}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__btn[_ngcontent-%COMP%]{height:42px;font-size:1rem}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__btn--page[_ngcontent-%COMP%]{width:42px;min-width:42px}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__btn--nav[_ngcontent-%COMP%]{padding:10px 16px}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__ellipsis[_ngcontent-%COMP%]{width:42px;height:42px}.orc-paginator--lg[_ngcontent-%COMP%]   .orc-paginator__select[_ngcontent-%COMP%]{height:42px;font-size:1rem;padding:4px 40px 4px 14px;border-radius:12px}.orc-paginator--disabled[_ngcontent-%COMP%]{opacity:.5;pointer-events:none}@media(max-width:768px){.orc-paginator[_ngcontent-%COMP%]{flex-direction:column;align-items:center;gap:var(--space-3, 12px)}.orc-paginator__list[_ngcontent-%COMP%]{flex-wrap:wrap;justify-content:center;height:auto}.orc-paginator__page-size[_ngcontent-%COMP%]{width:100%;justify-content:center}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PaginatorComponent, [{
        type: Component,
        args: [{ selector: 'orc-paginator', standalone: true, imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav\n  class=\"orc-paginator\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [class.orc-paginator--disabled]=\"disabled()\"\n  [class.orc-paginator--sm]=\"size() === 'sm'\"\n  [class.orc-paginator--lg]=\"size() === 'lg'\"\n>\n  <!-- Texto Informativo de Itens (Opcional) -->\n  <div *ngIf=\"showTotalInfo()\" class=\"orc-paginator__info\">\n    Exibindo <strong>{{ startIndex() }}\u2013{{ endIndex() }}</strong> de <strong>{{ totalItems() }}</strong> itens\n  </div>\n\n  <!-- Lista de Navega\u00E7\u00E3o e P\u00E1ginas -->\n  <ul class=\"orc-paginator__list\" role=\"list\">\n    <!-- Bot\u00E3o: Primeira P\u00E1gina (Opcional) -->\n    <li *ngIf=\"showFirstLastButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--first\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"firstPage()\"\n        [attr.aria-label]=\"firstLabel()\"\n        [title]=\"firstLabel()\"\n      >\n        <svg class=\"orc-paginator__icon\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n          <path d=\"M11 12L7 8L11 4M7 12L3 8L7 4\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: Anterior (Figma Node 18:1752) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--prev\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"prevPage()\"\n        [attr.aria-label]=\"previousLabel()\"\n      >\n        <svg class=\"orc-paginator__icon\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n          <path d=\"M10 12L6 8L10 4\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n        <span class=\"orc-paginator__btn-text\">{{ previousLabel() }}</span>\n      </button>\n    </li>\n\n    <!-- Bot\u00F5es Num\u00E9ricos e Retic\u00EAncias (Figma Nodes 18:1758 - 18:1773) -->\n    <ng-container *ngFor=\"let p of visiblePages()\">\n      <!-- N\u00FAmero da P\u00E1gina -->\n      <li *ngIf=\"p !== 'ellipsis'\">\n        <button\n          type=\"button\"\n          class=\"orc-paginator__btn orc-paginator__btn--page\"\n          [class.orc-paginator__btn--active]=\"p === currentPage()\"\n          [attr.aria-current]=\"p === currentPage() ? 'page' : null\"\n          [disabled]=\"disabled()\"\n          (click)=\"goToPage(+p)\"\n          [attr.aria-label]=\"'Ir para a p\u00E1gina ' + p\"\n        >\n          {{ p }}\n        </button>\n      </li>\n\n      <!-- Retic\u00EAncias (...) -->\n      <li *ngIf=\"p === 'ellipsis'\" class=\"orc-paginator__ellipsis\" aria-hidden=\"true\">\n        <svg class=\"orc-paginator__icon-dots\" viewBox=\"0 0 16 16\" fill=\"none\">\n          <circle cx=\"4\" cy=\"8\" r=\"1.25\" fill=\"currentColor\"/>\n          <circle cx=\"8\" cy=\"8\" r=\"1.25\" fill=\"currentColor\"/>\n          <circle cx=\"12\" cy=\"8\" r=\"1.25\" fill=\"currentColor\"/>\n        </svg>\n      </li>\n    </ng-container>\n\n    <!-- Bot\u00E3o: Pr\u00F3ximo (Figma Node 32:18542) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--next\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"nextPage()\"\n        [attr.aria-label]=\"nextLabel()\"\n      >\n        <span class=\"orc-paginator__btn-text\">{{ nextLabel() }}</span>\n        <svg class=\"orc-paginator__icon\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n          <path d=\"M6 4L10 8L6 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: \u00DAltima P\u00E1gina (Opcional) -->\n    <li *ngIf=\"showFirstLastButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--last\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"lastPage()\"\n        [attr.aria-label]=\"lastLabel()\"\n        [title]=\"lastLabel()\"\n      >\n        <svg class=\"orc-paginator__icon\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n          <path d=\"M5 4L9 8L5 12M9 4L13 8L9 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n      </button>\n    </li>\n  </ul>\n\n  <!-- Seletor de Itens por P\u00E1gina (Figma Node 32:18566: \"20 / P\u00E1gina\") -->\n  <div\n    *ngIf=\"showPageSizeSelector() && pageSizeOptions().length > 0\"\n    class=\"orc-paginator__page-size\"\n  >\n    <select\n      class=\"orc-paginator__select\"\n      [disabled]=\"disabled()\"\n      [value]=\"pageSize()\"\n      (change)=\"onPageSizeChange($event)\"\n      [attr.aria-label]=\"'Quantidade de itens por p\u00E1gina'\"\n    >\n      <option *ngFor=\"let opt of pageSizeOptions()\" [value]=\"opt\">\n        {{ opt }} / {{ itemsPerPageLabel() }}\n      </option>\n    </select>\n    <div class=\"orc-paginator__select-icon\" aria-hidden=\"true\">\n      <svg viewBox=\"0 0 16 16\" fill=\"none\">\n        <path d=\"M4 6L8 10L12 6\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n      </svg>\n    </div>\n  </div>\n</nav>\n", styles: [":host{display:block;width:100%}.orc-paginator{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4, 16px);width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif);-webkit-user-select:none;user-select:none}.orc-paginator__info{font-size:.875rem;color:var(--orc-font-secondary, #666666);white-space:nowrap}.orc-paginator__info strong{color:var(--orc-font-main, #141414);font-weight:600}.orc-paginator__list{display:inline-flex;align-items:center;gap:4px;list-style:none;margin:0;padding:0;height:36px}.orc-paginator__btn{display:inline-flex;align-items:center;justify-content:center;height:36px;background:transparent;border:none;border-radius:8px;color:var(--orc-font-main, #141414);font-family:inherit;font-size:.875rem;font-weight:400;line-height:20px;cursor:pointer;transition:all var(--transition-fast, .12s ease);outline:none;text-decoration:none}.orc-paginator__btn:hover:not(:disabled){background:var(--bg-subtle, #f9f9f9);color:var(--orc-color-azul-royal, #0406ab)}.orc-paginator__btn:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-paginator__btn:disabled,.orc-paginator__btn[aria-disabled=true]{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-paginator__btn--page{min-width:36px;width:36px;padding:0}.orc-paginator__btn--active{background:var(--orc-th, #f9f9f9);font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-paginator__btn--active:hover{background:var(--orc-th, #f9f9f9);color:var(--orc-font-main, #141414)}.orc-paginator__btn--nav{padding:8px 12px;gap:4px;min-width:36px}.orc-paginator__btn--first,.orc-paginator__btn--last{padding:0;width:36px}.orc-paginator__btn-text{font-size:.875rem;line-height:20px;color:inherit}.orc-paginator__icon{width:16px;height:16px;display:block;flex-shrink:0}.orc-paginator__ellipsis{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;color:var(--orc-font-secondary, #666666)}.orc-paginator__icon-dots{width:16px;height:16px}.orc-paginator__page-size{position:relative;display:inline-flex;align-items:center;height:36px}.orc-paginator__select{appearance:none;-webkit-appearance:none;-moz-appearance:none;height:36px;background:var(--orc-fill-input, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;padding:3px 36px 3px 12px;font-family:inherit;font-size:.875rem;line-height:22px;color:var(--orc-font-secondary, #666666);cursor:pointer;outline:none;transition:all var(--transition-fast, .12s ease)}.orc-paginator__select:hover:not(:disabled){border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-font-main, #141414)}.orc-paginator__select:focus-visible{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed26}.orc-paginator__select:disabled{opacity:.4;cursor:not-allowed;background:var(--bg-muted, #ededed)}.orc-paginator__select-icon{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:16px;height:16px;color:var(--orc-font-secondary, #666666);pointer-events:none;display:flex;align-items:center;justify-content:center}.orc-paginator__select-icon svg{width:100%;height:100%}.orc-paginator--sm .orc-paginator__list,.orc-paginator--sm .orc-paginator__page-size{height:30px}.orc-paginator--sm .orc-paginator__btn{height:30px;font-size:.75rem}.orc-paginator--sm .orc-paginator__btn--page{width:30px;min-width:30px}.orc-paginator--sm .orc-paginator__btn--nav{padding:4px 8px}.orc-paginator--sm .orc-paginator__ellipsis{width:30px;height:30px}.orc-paginator--sm .orc-paginator__select{height:30px;font-size:.75rem;padding:2px 30px 2px 10px;border-radius:8px}.orc-paginator--lg .orc-paginator__list,.orc-paginator--lg .orc-paginator__page-size{height:42px}.orc-paginator--lg .orc-paginator__btn{height:42px;font-size:1rem}.orc-paginator--lg .orc-paginator__btn--page{width:42px;min-width:42px}.orc-paginator--lg .orc-paginator__btn--nav{padding:10px 16px}.orc-paginator--lg .orc-paginator__ellipsis{width:42px;height:42px}.orc-paginator--lg .orc-paginator__select{height:42px;font-size:1rem;padding:4px 40px 4px 14px;border-radius:12px}.orc-paginator--disabled{opacity:.5;pointer-events:none}@media(max-width:768px){.orc-paginator{flex-direction:column;align-items:center;gap:var(--space-3, 12px)}.orc-paginator__list{flex-wrap:wrap;justify-content:center;height:auto}.orc-paginator__page-size{width:100%;justify-content:center}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PaginatorComponent, { className: "PaginatorComponent", filePath: "paginator.component.ts", lineNumber: 26 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { PaginatorComponent };
//# sourceMappingURL=ciag-orchestra-paginator.mjs.map
