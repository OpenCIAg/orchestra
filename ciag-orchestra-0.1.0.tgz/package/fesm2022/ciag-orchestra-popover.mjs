import * as i0 from '@angular/core';
import { model, input, inject, ElementRef, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';

const _c0 = [[["", "popover-trigger", ""]], "*"];
const _c1 = ["[popover-trigger]", "*"];
function PopoverComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "section", 2);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassMap("orc-popover orc-popover--" + ctx_r0.placement());
    i0.ɵɵattribute("aria-label", ctx_r0.label());
} }
class PopoverComponent {
    open = model(false);
    placement = input('bottom');
    label = input('Conteúdo adicional');
    host = inject((ElementRef));
    toggle() { this.open.update(v => !v); }
    close() { this.open.set(false); }
    onEscape() { this.close(); }
    onOutside(event) { if (this.open() && !this.host.nativeElement.contains(event.target))
        this.close(); }
    static ɵfac = function PopoverComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PopoverComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PopoverComponent, selectors: [["orc-popover"]], hostBindings: function PopoverComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown.escape", function PopoverComponent_keydown_escape_HostBindingHandler() { return ctx.onEscape(); }, false, i0.ɵɵresolveDocument)("click", function PopoverComponent_click_HostBindingHandler($event) { return ctx.onOutside($event); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { open: [1, "open"], placement: [1, "placement"], label: [1, "label"] }, outputs: { open: "openChange" }, ngContentSelectors: _c1, decls: 3, vars: 2, consts: [[1, "orc-popover__trigger", 3, "click", "keydown.enter", "keydown.space"], ["role", "dialog", 1, "orc-popover", 3, "class"], ["role", "dialog", 1, "orc-popover"]], template: function PopoverComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0);
            i0.ɵɵelementStart(0, "span", 0);
            i0.ɵɵlistener("click", function PopoverComponent_Template_span_click_0_listener() { return ctx.toggle(); })("keydown.enter", function PopoverComponent_Template_span_keydown_enter_0_listener() { return ctx.toggle(); })("keydown.space", function PopoverComponent_Template_span_keydown_space_0_listener($event) { ctx.toggle(); return $event.preventDefault(); });
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(2, PopoverComponent_Conditional_2_Template, 2, 3, "section", 1);
        } if (rf & 2) {
            i0.ɵɵattribute("aria-expanded", ctx.open());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.open() ? 2 : -1);
        } }, styles: ["[_nghost-%COMP%]{position:relative;display:inline-block}.orc-popover__trigger[_ngcontent-%COMP%]{display:inline-flex;cursor:pointer}.orc-popover[_ngcontent-%COMP%]{position:absolute;z-index:var(--z-popover);width:max-content;max-width:min(22rem,90vw);padding:var(--space-4);background:var(--orc-fill-modal);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-lg)}.orc-popover--bottom[_ngcontent-%COMP%]{top:calc(100% + var(--space-2));left:0}.orc-popover--top[_ngcontent-%COMP%]{bottom:calc(100% + var(--space-2));left:0}.orc-popover--left[_ngcontent-%COMP%]{right:calc(100% + var(--space-2));top:0}.orc-popover--right[_ngcontent-%COMP%]{left:calc(100% + var(--space-2));top:0}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PopoverComponent, [{
        type: Component,
        args: [{ selector: 'orc-popover', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"orc-popover__trigger\" (click)=\"toggle()\" (keydown.enter)=\"toggle()\" (keydown.space)=\"toggle(); $event.preventDefault()\" [attr.aria-expanded]=\"open()\"><ng-content select=\"[popover-trigger]\" /></span>\n@if (open()) { <section class=\"orc-popover\" [class]=\"'orc-popover orc-popover--'+placement()\" role=\"dialog\" [attr.aria-label]=\"label()\"><ng-content /></section> }\n", styles: [":host{position:relative;display:inline-block}.orc-popover__trigger{display:inline-flex;cursor:pointer}.orc-popover{position:absolute;z-index:var(--z-popover);width:max-content;max-width:min(22rem,90vw);padding:var(--space-4);background:var(--orc-fill-modal);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-lg)}.orc-popover--bottom{top:calc(100% + var(--space-2));left:0}.orc-popover--top{bottom:calc(100% + var(--space-2));left:0}.orc-popover--left{right:calc(100% + var(--space-2));top:0}.orc-popover--right{left:calc(100% + var(--space-2));top:0}\n"] }]
    }], null, { onEscape: [{
            type: HostListener,
            args: ['document:keydown.escape']
        }], onOutside: [{
            type: HostListener,
            args: ['document:click', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(PopoverComponent, { className: "PopoverComponent", filePath: "popover.component.ts", lineNumber: 4 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { PopoverComponent };
//# sourceMappingURL=ciag-orchestra-popover.mjs.map
