import * as i0 from '@angular/core';
import { input, output, computed, ChangeDetectionStrategy, Component, contentChildren, signal } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';

const _c0$1 = ["*", "*", "*", "*"];
function BreadcrumbItemComponent_a_0_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "path", 10)(2, "polyline", 11);
    i0.ɵɵelementEnd();
} }
function BreadcrumbItemComponent_a_0_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_a_0_span_1__svg_svg_1_Template, 3, 0, "svg", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon() === "home");
} }
function BreadcrumbItemComponent_a_0_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function BreadcrumbItemComponent_a_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 4);
    i0.ɵɵlistener("click", function BreadcrumbItemComponent_a_0_Template_a_click_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleClick($event)); });
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_a_0_span_1_Template, 2, 1, "span", 5)(2, BreadcrumbItemComponent_a_0_span_2_Template, 2, 1, "span", 6);
    i0.ɵɵprojection(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("routerLink", ctx_r1.routerLink());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
} }
function BreadcrumbItemComponent_a_1_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "path", 10)(2, "polyline", 11);
    i0.ɵɵelementEnd();
} }
function BreadcrumbItemComponent_a_1_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_a_1_span_1__svg_svg_1_Template, 3, 0, "svg", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon() === "home");
} }
function BreadcrumbItemComponent_a_1_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function BreadcrumbItemComponent_a_1_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 13);
    i0.ɵɵlistener("click", function BreadcrumbItemComponent_a_1_Template_a_click_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleClick($event)); });
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_a_1_span_1_Template, 2, 1, "span", 5)(2, BreadcrumbItemComponent_a_1_span_2_Template, 2, 1, "span", 6);
    i0.ɵɵprojection(3, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("href", ctx_r1.href(), i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
} }
function BreadcrumbItemComponent_span_2_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "path", 10)(2, "polyline", 11);
    i0.ɵɵelementEnd();
} }
function BreadcrumbItemComponent_span_2_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_span_2_span_1__svg_svg_1_Template, 3, 0, "svg", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon() === "home");
} }
function BreadcrumbItemComponent_span_2_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function BreadcrumbItemComponent_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 14);
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_span_2_span_1_Template, 2, 1, "span", 5)(2, BreadcrumbItemComponent_span_2_span_2_Template, 2, 1, "span", 6);
    i0.ɵɵprojection(3, 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
} }
function BreadcrumbItemComponent_span_3_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "path", 10)(2, "polyline", 11);
    i0.ɵɵelementEnd();
} }
function BreadcrumbItemComponent_span_3_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_span_3_span_1__svg_svg_1_Template, 3, 0, "svg", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon() === "home");
} }
function BreadcrumbItemComponent_span_3_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function BreadcrumbItemComponent_span_3_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵlistener("click", function BreadcrumbItemComponent_span_3_Template_span_click_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleClick($event)); })("keydown.enter", function BreadcrumbItemComponent_span_3_Template_span_keydown_enter_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleClick($event)); })("keydown.space", function BreadcrumbItemComponent_span_3_Template_span_keydown_space_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.handleClick($event)); });
    i0.ɵɵtemplate(1, BreadcrumbItemComponent_span_3_span_1_Template, 2, 1, "span", 5)(2, BreadcrumbItemComponent_span_3_span_2_Template, 2, 1, "span", 6);
    i0.ɵɵprojection(3, 3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-breadcrumb-item__link", !ctx_r1.disabled())("orc-breadcrumb-item__text", ctx_r1.disabled())("orc-breadcrumb-item__text--disabled", ctx_r1.disabled());
    i0.ɵɵattribute("role", !ctx_r1.disabled() ? "button" : null)("tabindex", !ctx_r1.disabled() ? 0 : null);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.icon());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
} }
class BreadcrumbItemComponent {
    // Inputs (Signals API)
    label = input('');
    routerLink = input(undefined);
    href = input(undefined);
    active = input(false);
    disabled = input(false);
    icon = input(undefined);
    // Outputs (Signals API)
    itemClick = output();
    // Determine if item has an active link
    hasLink = computed(() => {
        return !this.active() && !this.disabled() && (!!this.routerLink() || !!this.href());
    });
    handleClick(event) {
        if (this.disabled() || this.active()) {
            event.preventDefault();
            return;
        }
        this.itemClick.emit(event);
    }
    static ɵfac = function BreadcrumbItemComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || BreadcrumbItemComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: BreadcrumbItemComponent, selectors: [["orc-breadcrumb-item"]], hostAttrs: [1, "orc-breadcrumb-item-host"], hostVars: 4, hostBindings: function BreadcrumbItemComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵclassProp("orc-breadcrumb-item--active", ctx.active())("orc-breadcrumb-item--disabled", ctx.disabled());
        } }, inputs: { label: [1, "label"], routerLink: [1, "routerLink"], href: [1, "href"], active: [1, "active"], disabled: [1, "disabled"], icon: [1, "icon"] }, outputs: { itemClick: "itemClick" }, ngContentSelectors: _c0$1, decls: 4, vars: 4, consts: [["class", "orc-breadcrumb-item__link", 3, "routerLink", "click", 4, "ngIf"], ["class", "orc-breadcrumb-item__link", 3, "href", "click", 4, "ngIf"], ["class", "orc-breadcrumb-item__current", "aria-current", "page", 4, "ngIf"], [3, "orc-breadcrumb-item__link", "orc-breadcrumb-item__text", "orc-breadcrumb-item__text--disabled", "click", "keydown.enter", "keydown.space", 4, "ngIf"], [1, "orc-breadcrumb-item__link", 3, "click", "routerLink"], ["class", "orc-breadcrumb-item__icon", "aria-hidden", "true", 4, "ngIf"], ["class", "orc-breadcrumb-item__label", 4, "ngIf"], ["aria-hidden", "true", 1, "orc-breadcrumb-item__icon"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", 4, "ngIf"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"], ["points", "9 22 9 12 15 12 15 22"], [1, "orc-breadcrumb-item__label"], [1, "orc-breadcrumb-item__link", 3, "click", "href"], ["aria-current", "page", 1, "orc-breadcrumb-item__current"], [3, "click", "keydown.enter", "keydown.space"]], template: function BreadcrumbItemComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0$1);
            i0.ɵɵtemplate(0, BreadcrumbItemComponent_a_0_Template, 4, 3, "a", 0)(1, BreadcrumbItemComponent_a_1_Template, 4, 3, "a", 1)(2, BreadcrumbItemComponent_span_2_Template, 4, 2, "span", 2)(3, BreadcrumbItemComponent_span_3_Template, 4, 10, "span", 3);
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.routerLink() && !ctx.active() && !ctx.disabled());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.href() && !ctx.routerLink() && !ctx.active() && !ctx.disabled());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.active());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.active() && !ctx.routerLink() && !ctx.href());
        } }, dependencies: [CommonModule, i1.NgIf, RouterModule, i2.RouterLink], styles: ["[_nghost-%COMP%]{display:inline-flex;align-items:center}.orc-breadcrumb-item__link[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:400;line-height:20px;color:var(--orc-font-secondary, #666666);text-decoration:none;cursor:pointer;transition:color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 4px)}.orc-breadcrumb-item__link[_ngcontent-%COMP%]:hover{color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb-item__link[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-breadcrumb-item__current[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:20px;font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-breadcrumb-item__text[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666)}.orc-breadcrumb-item__text--disabled[_ngcontent-%COMP%]{opacity:.35;cursor:not-allowed}.orc-breadcrumb-item__icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px}.orc-breadcrumb-item__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(BreadcrumbItemComponent, [{
        type: Component,
        args: [{ selector: 'orc-breadcrumb-item', standalone: true, imports: [CommonModule, RouterModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    'class': 'orc-breadcrumb-item-host',
                    '[class.orc-breadcrumb-item--active]': 'active()',
                    '[class.orc-breadcrumb-item--disabled]': 'disabled()',
                }, template: "<!-- Item com RouterLink do Angular -->\n<a\n  *ngIf=\"routerLink() && !active() && !disabled()\"\n  [routerLink]=\"routerLink()\"\n  class=\"orc-breadcrumb-item__link\"\n  (click)=\"handleClick($event)\"\n>\n  <span *ngIf=\"icon()\" class=\"orc-breadcrumb-item__icon\" aria-hidden=\"true\">\n    <svg *ngIf=\"icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n      <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n    </svg>\n  </span>\n  <span class=\"orc-breadcrumb-item__label\" *ngIf=\"label()\">{{ label() }}</span>\n  <ng-content></ng-content>\n</a>\n\n<!-- Item com link HTML nativo (href) -->\n<a\n  *ngIf=\"href() && !routerLink() && !active() && !disabled()\"\n  [href]=\"href()\"\n  class=\"orc-breadcrumb-item__link\"\n  (click)=\"handleClick($event)\"\n>\n  <span *ngIf=\"icon()\" class=\"orc-breadcrumb-item__icon\" aria-hidden=\"true\">\n    <svg *ngIf=\"icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n      <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n    </svg>\n  </span>\n  <span class=\"orc-breadcrumb-item__label\" *ngIf=\"label()\">{{ label() }}</span>\n  <ng-content></ng-content>\n</a>\n\n<!-- Item ativo / p\u00E1gina atual (WAI-ARIA aria-current=\"page\") -->\n<span\n  *ngIf=\"active()\"\n  class=\"orc-breadcrumb-item__current\"\n  aria-current=\"page\"\n>\n  <span *ngIf=\"icon()\" class=\"orc-breadcrumb-item__icon\" aria-hidden=\"true\">\n    <svg *ngIf=\"icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n      <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n    </svg>\n  </span>\n  <span class=\"orc-breadcrumb-item__label\" *ngIf=\"label()\">{{ label() }}</span>\n  <ng-content></ng-content>\n</span>\n\n<!-- Item naveg\u00E1vel gen\u00E9rico (sem routerLink ou href) ou desabilitado -->\n<span\n  *ngIf=\"!active() && !routerLink() && !href()\"\n  [class.orc-breadcrumb-item__link]=\"!disabled()\"\n  [class.orc-breadcrumb-item__text]=\"disabled()\"\n  [class.orc-breadcrumb-item__text--disabled]=\"disabled()\"\n  [attr.role]=\"!disabled() ? 'button' : null\"\n  [attr.tabindex]=\"!disabled() ? 0 : null\"\n  (click)=\"handleClick($event)\"\n  (keydown.enter)=\"handleClick($any($event))\"\n  (keydown.space)=\"handleClick($any($event))\"\n>\n  <span *ngIf=\"icon()\" class=\"orc-breadcrumb-item__icon\" aria-hidden=\"true\">\n    <svg *ngIf=\"icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n      <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n    </svg>\n  </span>\n  <span class=\"orc-breadcrumb-item__label\" *ngIf=\"label()\">{{ label() }}</span>\n  <ng-content></ng-content>\n</span>\n", styles: [":host{display:inline-flex;align-items:center}.orc-breadcrumb-item__link{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:400;line-height:20px;color:var(--orc-font-secondary, #666666);text-decoration:none;cursor:pointer;transition:color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 4px)}.orc-breadcrumb-item__link:hover{color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb-item__link:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-breadcrumb-item__current{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:20px;font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-breadcrumb-item__text{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666)}.orc-breadcrumb-item__text--disabled{opacity:.35;cursor:not-allowed}.orc-breadcrumb-item__icon{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px}.orc-breadcrumb-item__icon svg{width:100%;height:100%}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(BreadcrumbItemComponent, { className: "BreadcrumbItemComponent", filePath: "breadcrumb-item.component.ts", lineNumber: 24 }); })();

const _c0 = ["*"];
function BreadcrumbComponent_ng_container_2_ng_container_1_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵlistener("click", function BreadcrumbComponent_ng_container_2_ng_container_1_button_2_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.expand()); });
    i0.ɵɵtext(1, " ... ");
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_3_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 18)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_3_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_span_3_span_1__svg_svg_1_Template, 3, 0, "svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon === "home");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_span_3_span_1_Template, 2, 1, "span", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r3.label, " ");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_4_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 18)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_4_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_a_4_span_1__svg_svg_1_Template, 3, 0, "svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon === "home");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_4_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 20);
    i0.ɵɵlistener("click", function BreadcrumbComponent_ng_container_2_ng_container_1_a_4_Template_a_click_0_listener($event) { i0.ɵɵrestoreView(_r4); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onItemClicked(item_r3, item_r3.originalIndex, $event)); });
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_a_4_span_1_Template, 2, 1, "span", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("routerLink", item_r3.routerLink);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r3.label, " ");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_5_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 18)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_5_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_a_5_span_1__svg_svg_1_Template, 3, 0, "svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon === "home");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_a_5_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "a", 21);
    i0.ɵɵlistener("click", function BreadcrumbComponent_ng_container_2_ng_container_1_a_5_Template_a_click_0_listener($event) { i0.ɵɵrestoreView(_r5); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onItemClicked(item_r3, item_r3.originalIndex, $event)); });
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_a_5_span_1_Template, 2, 1, "span", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("href", item_r3.url, i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r3.label, " ");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_span_1__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 18)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_span_6_span_1__svg_svg_1_Template, 3, 0, "svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon === "home");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 22);
    i0.ɵɵlistener("click", function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_Template_span_click_0_listener($event) { i0.ɵɵrestoreView(_r6); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onItemClicked(item_r3, item_r3.originalIndex, $event)); })("keydown.enter", function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_Template_span_keydown_enter_0_listener($event) { i0.ɵɵrestoreView(_r6); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onItemClicked(item_r3, item_r3.originalIndex, $event)); })("keydown.space", function BreadcrumbComponent_ng_container_2_ng_container_1_span_6_Template_span_keydown_space_0_listener($event) { i0.ɵɵrestoreView(_r6); const item_r3 = i0.ɵɵnextContext().$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onItemClicked(item_r3, item_r3.originalIndex, $event)); });
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_span_6_span_1_Template, 2, 1, "span", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", item_r3.icon);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", item_r3.label, " ");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_li_7__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 26);
    i0.ɵɵelement(1, "path", 27);
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1, "/");
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1, ">");
    i0.ɵɵelementEnd();
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.separator(), " ");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_li_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 23);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_li_7__svg_svg_1_Template, 2, 0, "svg", 24)(2, BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_2_Template, 2, 0, "span", 25)(3, BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_3_Template, 2, 0, "span", 25)(4, BreadcrumbComponent_ng_container_2_ng_container_1_li_7_span_4_Template, 2, 1, "span", 25);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.separator() === "chevron");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.separator() === "slash");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.separator() === "arrow");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.separator() !== "chevron" && ctx_r1.separator() !== "slash" && ctx_r1.separator() !== "arrow");
} }
function BreadcrumbComponent_ng_container_2_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "li", 5);
    i0.ɵɵtemplate(2, BreadcrumbComponent_ng_container_2_ng_container_1_button_2_Template, 2, 0, "button", 6)(3, BreadcrumbComponent_ng_container_2_ng_container_1_span_3_Template, 3, 2, "span", 7)(4, BreadcrumbComponent_ng_container_2_ng_container_1_a_4_Template, 3, 3, "a", 8)(5, BreadcrumbComponent_ng_container_2_ng_container_1_a_5_Template, 3, 3, "a", 9)(6, BreadcrumbComponent_ng_container_2_ng_container_1_span_6_Template, 3, 2, "span", 10);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(7, BreadcrumbComponent_ng_container_2_ng_container_1_li_7_Template, 5, 4, "li", 11);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const last_r7 = ctx.last;
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", item_r3.isEllipsis);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !item_r3.isEllipsis && item_r3.isLast);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !item_r3.isEllipsis && !item_r3.isLast && item_r3.routerLink);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !item_r3.isEllipsis && !item_r3.isLast && !item_r3.routerLink && item_r3.url);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !item_r3.isEllipsis && !item_r3.isLast && !item_r3.routerLink && !item_r3.url);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", !last_r7);
} }
function BreadcrumbComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, BreadcrumbComponent_ng_container_2_ng_container_1_Template, 8, 6, "ng-container", 4);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.processedItems());
} }
function BreadcrumbComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
class BreadcrumbComponent {
    // Inputs (Signals API)
    items = input(undefined);
    separator = input('chevron');
    variant = input('default');
    maxItems = input(undefined);
    itemsBeforeCollapse = input(1);
    itemsAfterCollapse = input(1);
    ariaLabel = input('Breadcrumb');
    // Outputs (Signals API)
    itemClick = output();
    // Itens filhos registrados via projeção de conteúdo
    breadcrumbItems = contentChildren(BreadcrumbItemComponent);
    // Estado de expansão do colapso (...)
    isExpanded = signal(false);
    // Cálculo de itens visíveis quando usamos o modo data-driven com colapso
    processedItems = computed(() => {
        const rawItems = this.items();
        if (!rawItems)
            return [];
        const max = this.maxItems();
        if (!max || rawItems.length <= max || this.isExpanded()) {
            return rawItems.map((item, index) => ({
                ...item,
                isEllipsis: false,
                isLast: index === rawItems.length - 1,
                originalIndex: index,
            }));
        }
        const beforeCount = Math.max(1, this.itemsBeforeCollapse());
        const afterCount = Math.max(1, this.itemsAfterCollapse());
        const beforeItems = rawItems
            .slice(0, beforeCount)
            .map((item, idx) => ({
            ...item,
            isEllipsis: false,
            isLast: false,
            originalIndex: idx,
        }));
        const ellipsisItem = {
            label: '...',
            isEllipsis: true,
            isLast: false,
            originalIndex: -1,
        };
        const afterItems = rawItems
            .slice(rawItems.length - afterCount)
            .map((item, idx) => ({
            ...item,
            isEllipsis: false,
            isLast: idx === afterCount - 1,
            originalIndex: rawItems.length - afterCount + idx,
        }));
        return [...beforeItems, ellipsisItem, ...afterItems];
    });
    expand() {
        this.isExpanded.set(true);
    }
    onItemClicked(item, index, event) {
        this.itemClick.emit({ item: item, index });
    }
    static ɵfac = function BreadcrumbComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || BreadcrumbComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: BreadcrumbComponent, selectors: [["orc-breadcrumb"]], contentQueries: function BreadcrumbComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.breadcrumbItems, BreadcrumbItemComponent, 4);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { items: [1, "items"], separator: [1, "separator"], variant: [1, "variant"], maxItems: [1, "maxItems"], itemsBeforeCollapse: [1, "itemsBeforeCollapse"], itemsAfterCollapse: [1, "itemsAfterCollapse"], ariaLabel: [1, "ariaLabel"] }, outputs: { itemClick: "itemClick" }, ngContentSelectors: _c0, decls: 5, vars: 7, consts: [["projectionMode", ""], [1, "orc-breadcrumb"], [1, "orc-breadcrumb__list"], [4, "ngIf", "ngIfElse"], [4, "ngFor", "ngForOf"], [1, "orc-breadcrumb__item"], ["type", "button", "class", "orc-breadcrumb__ellipsis-btn", "aria-label", "Expandir itens ocultos do breadcrumb", "title", "Expandir itens ocultos", 3, "click", 4, "ngIf"], ["class", "orc-breadcrumb__current", "aria-current", "page", 4, "ngIf"], ["class", "orc-breadcrumb__link", 3, "routerLink", "click", 4, "ngIf"], ["class", "orc-breadcrumb__link", 3, "href", "click", 4, "ngIf"], ["class", "orc-breadcrumb__link", "role", "button", "tabindex", "0", 3, "click", "keydown.enter", "keydown.space", 4, "ngIf"], ["class", "orc-breadcrumb__separator", "aria-hidden", "true", 4, "ngIf"], ["type", "button", "aria-label", "Expandir itens ocultos do breadcrumb", "title", "Expandir itens ocultos", 1, "orc-breadcrumb__ellipsis-btn", 3, "click"], ["aria-current", "page", 1, "orc-breadcrumb__current"], ["class", "orc-breadcrumb__icon", "aria-hidden", "true", 4, "ngIf"], ["aria-hidden", "true", 1, "orc-breadcrumb__icon"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", 4, "ngIf"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2"], ["d", "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"], ["points", "9 22 9 12 15 12 15 22"], [1, "orc-breadcrumb__link", 3, "click", "routerLink"], [1, "orc-breadcrumb__link", 3, "click", "href"], ["role", "button", "tabindex", "0", 1, "orc-breadcrumb__link", 3, "click", "keydown.enter", "keydown.space"], ["aria-hidden", "true", 1, "orc-breadcrumb__separator"], ["viewBox", "0 0 14 14", "fill", "none", "class", "orc-breadcrumb__separator-icon", 4, "ngIf"], ["class", "orc-breadcrumb__separator-text", 4, "ngIf"], ["viewBox", "0 0 14 14", "fill", "none", 1, "orc-breadcrumb__separator-icon"], ["d", "M5.25 2.625L9.625 7L5.25 11.375", "stroke", "currentColor", "stroke-width", "1.25", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-breadcrumb__separator-text"]], template: function BreadcrumbComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "nav", 1)(1, "ol", 2);
            i0.ɵɵtemplate(2, BreadcrumbComponent_ng_container_2_Template, 2, 1, "ng-container", 3)(3, BreadcrumbComponent_ng_template_3_Template, 1, 0, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            const projectionMode_r8 = i0.ɵɵreference(4);
            i0.ɵɵclassProp("orc-breadcrumb--variant-default", ctx.variant() === "default")("orc-breadcrumb--variant-underlined", ctx.variant() === "underlined");
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.items())("ngIfElse", projectionMode_r8);
        } }, dependencies: [CommonModule, i1.NgForOf, i1.NgIf, RouterModule, i2.RouterLink], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-breadcrumb[_ngcontent-%COMP%]{display:inline-flex;align-items:center;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-breadcrumb__list[_ngcontent-%COMP%]{display:inline-flex;flex-wrap:wrap;align-items:center;list-style:none;margin:0;padding:0;gap:8px}.orc-breadcrumb__item[_ngcontent-%COMP%]{display:inline-flex;align-items:center}.orc-breadcrumb__link[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666);text-decoration:none;cursor:pointer;transition:color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 4px)}.orc-breadcrumb__link[_ngcontent-%COMP%]:hover{color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb__link[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-breadcrumb__text[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666)}.orc-breadcrumb__current[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-breadcrumb__ellipsis-btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;padding:0 6px;height:20px;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-font-secondary, #666666);font-family:inherit;font-size:.875rem;font-weight:600;cursor:pointer;transition:all var(--transition-fast, .12s ease)}.orc-breadcrumb__ellipsis-btn[_ngcontent-%COMP%]:hover{background:var(--bg-muted, #ededed);color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb__ellipsis-btn[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed)}.orc-breadcrumb__separator[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-font-secondary, #666666);-webkit-user-select:none;user-select:none}.orc-breadcrumb__separator-icon[_ngcontent-%COMP%]{width:14px;height:14px;display:block}.orc-breadcrumb__separator-text[_ngcontent-%COMP%]{font-size:.875rem;line-height:1}.orc-breadcrumb__icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px}.orc-breadcrumb__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-breadcrumb--variant-underlined[_ngcontent-%COMP%]   .orc-breadcrumb__current[_ngcontent-%COMP%]{font-weight:400;color:var(--orc-color-azul-eletrico, #1c6aed);text-decoration:underline}.orc-breadcrumb--variant-underlined[_ngcontent-%COMP%]     .orc-breadcrumb-item--active .orc-breadcrumb-item__current{font-weight:400;color:var(--orc-color-azul-eletrico, #1c6aed);text-decoration:underline}.orc-breadcrumb[_ngcontent-%COMP%]     app-breadcrumb-item+app-breadcrumb-item:before{content:\"\";display:inline-block;width:14px;height:14px;margin:0 8px;background-repeat:no-repeat;background-position:center;background-size:contain;background-image:url(\"data:image/svg+xml,%3Csvg viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5.25 2.625L9.625 7L5.25 11.375' stroke='%23666666' stroke-width='1.25' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\")}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(BreadcrumbComponent, [{
        type: Component,
        args: [{ selector: 'orc-breadcrumb', standalone: true, imports: [CommonModule, RouterModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav\n  [attr.aria-label]=\"ariaLabel()\"\n  class=\"orc-breadcrumb\"\n  [class.orc-breadcrumb--variant-default]=\"variant() === 'default'\"\n  [class.orc-breadcrumb--variant-underlined]=\"variant() === 'underlined'\"\n>\n  <ol class=\"orc-breadcrumb__list\">\n    <!-- Modo 1: Data-Driven via array [items] -->\n    <ng-container *ngIf=\"items(); else projectionMode\">\n      <ng-container *ngFor=\"let item of processedItems(); let i = index; let last = last\">\n        <!-- Item Regular ou Ellipsis -->\n        <li class=\"orc-breadcrumb__item\">\n          <!-- Bot\u00E3o de expans\u00E3o (...) quando colapsado -->\n          <button\n            *ngIf=\"item.isEllipsis\"\n            type=\"button\"\n            class=\"orc-breadcrumb__ellipsis-btn\"\n            (click)=\"expand()\"\n            aria-label=\"Expandir itens ocultos do breadcrumb\"\n            title=\"Expandir itens ocultos\"\n          >\n            ...\n          </button>\n\n          <!-- Item Ativo / \u00DAltimo elemento da hierarquia -->\n          <span\n            *ngIf=\"!item.isEllipsis && item.isLast\"\n            class=\"orc-breadcrumb__current\"\n            aria-current=\"page\"\n          >\n            <span *ngIf=\"item.icon\" class=\"orc-breadcrumb__icon\" aria-hidden=\"true\">\n              <svg *ngIf=\"item.icon === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n            </span>\n            {{ item.label }}\n          </span>\n\n          <!-- Item com RouterLink do Angular -->\n          <a\n            *ngIf=\"!item.isEllipsis && !item.isLast && item.routerLink\"\n            [routerLink]=\"item.routerLink\"\n            class=\"orc-breadcrumb__link\"\n            (click)=\"onItemClicked(item, item.originalIndex, $event)\"\n          >\n            <span *ngIf=\"item.icon\" class=\"orc-breadcrumb__icon\" aria-hidden=\"true\">\n              <svg *ngIf=\"item.icon === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n            </span>\n            {{ item.label }}\n          </a>\n\n          <!-- Item com link HTML externo (url) -->\n          <a\n            *ngIf=\"!item.isEllipsis && !item.isLast && !item.routerLink && item.url\"\n            [href]=\"item.url\"\n            class=\"orc-breadcrumb__link\"\n            (click)=\"onItemClicked(item, item.originalIndex, $event)\"\n          >\n            <span *ngIf=\"item.icon\" class=\"orc-breadcrumb__icon\" aria-hidden=\"true\">\n              <svg *ngIf=\"item.icon === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n            </span>\n            {{ item.label }}\n          </a>\n\n          <!-- Item sem routerLink ou url (clic\u00E1vel com evento sem sair da p\u00E1gina) -->\n          <span\n            *ngIf=\"!item.isEllipsis && !item.isLast && !item.routerLink && !item.url\"\n            class=\"orc-breadcrumb__link\"\n            role=\"button\"\n            tabindex=\"0\"\n            (click)=\"onItemClicked(item, item.originalIndex, $event)\"\n            (keydown.enter)=\"onItemClicked(item, item.originalIndex, $any($event))\"\n            (keydown.space)=\"onItemClicked(item, item.originalIndex, $any($event))\"\n          >\n            <span *ngIf=\"item.icon\" class=\"orc-breadcrumb__icon\" aria-hidden=\"true\">\n              <svg *ngIf=\"item.icon === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n            </span>\n            {{ item.label }}\n          </span>\n        </li>\n\n        <!-- Separador entre os itens -->\n        <li *ngIf=\"!last\" class=\"orc-breadcrumb__separator\" aria-hidden=\"true\">\n          <!-- Chevron (Figma Padr\u00E3o - Node 18:1714) -->\n          <svg *ngIf=\"separator() === 'chevron'\" viewBox=\"0 0 14 14\" fill=\"none\" class=\"orc-breadcrumb__separator-icon\">\n            <path d=\"M5.25 2.625L9.625 7L5.25 11.375\" stroke=\"currentColor\" stroke-width=\"1.25\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n          </svg>\n          <!-- Slash / -->\n          <span *ngIf=\"separator() === 'slash'\" class=\"orc-breadcrumb__separator-text\">/</span>\n          <!-- Arrow > -->\n          <span *ngIf=\"separator() === 'arrow'\" class=\"orc-breadcrumb__separator-text\">&gt;</span>\n          <!-- Custom String -->\n          <span *ngIf=\"separator() !== 'chevron' && separator() !== 'slash' && separator() !== 'arrow'\" class=\"orc-breadcrumb__separator-text\">\n            {{ separator() }}\n          </span>\n        </li>\n      </ng-container>\n    </ng-container>\n\n    <!-- Modo 2: Proje\u00E7\u00E3o Declarativa (<orc-breadcrumb-item>) -->\n    <ng-template #projectionMode>\n      <ng-content></ng-content>\n    </ng-template>\n  </ol>\n</nav>\n", styles: [":host{display:inline-flex}.orc-breadcrumb{display:inline-flex;align-items:center;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-breadcrumb__list{display:inline-flex;flex-wrap:wrap;align-items:center;list-style:none;margin:0;padding:0;gap:8px}.orc-breadcrumb__item{display:inline-flex;align-items:center}.orc-breadcrumb__link{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666);text-decoration:none;cursor:pointer;transition:color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 4px)}.orc-breadcrumb__link:hover{color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb__link:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-breadcrumb__text{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:400;color:var(--orc-font-secondary, #666666)}.orc-breadcrumb__current{display:inline-flex;align-items:center;gap:6px;font-size:.875rem;line-height:20px;font-weight:600;color:var(--orc-font-main, #141414);cursor:default}.orc-breadcrumb__ellipsis-btn{display:inline-flex;align-items:center;justify-content:center;padding:0 6px;height:20px;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-font-secondary, #666666);font-family:inherit;font-size:.875rem;font-weight:600;cursor:pointer;transition:all var(--transition-fast, .12s ease)}.orc-breadcrumb__ellipsis-btn:hover{background:var(--bg-muted, #ededed);color:var(--orc-color-azul-royal, #0406ab)}.orc-breadcrumb__ellipsis-btn:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed)}.orc-breadcrumb__separator{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-font-secondary, #666666);-webkit-user-select:none;user-select:none}.orc-breadcrumb__separator-icon{width:14px;height:14px;display:block}.orc-breadcrumb__separator-text{font-size:.875rem;line-height:1}.orc-breadcrumb__icon{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px}.orc-breadcrumb__icon svg{width:100%;height:100%}.orc-breadcrumb--variant-underlined .orc-breadcrumb__current{font-weight:400;color:var(--orc-color-azul-eletrico, #1c6aed);text-decoration:underline}.orc-breadcrumb--variant-underlined ::ng-deep .orc-breadcrumb-item--active .orc-breadcrumb-item__current{font-weight:400;color:var(--orc-color-azul-eletrico, #1c6aed);text-decoration:underline}.orc-breadcrumb ::ng-deep app-breadcrumb-item+app-breadcrumb-item:before{content:\"\";display:inline-block;width:14px;height:14px;margin:0 8px;background-repeat:no-repeat;background-position:center;background-size:contain;background-image:url(\"data:image/svg+xml,%3Csvg viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5.25 2.625L9.625 7L5.25 11.375' stroke='%23666666' stroke-width='1.25' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\")}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(BreadcrumbComponent, { className: "BreadcrumbComponent", filePath: "breadcrumb.component.ts", lineNumber: 34 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { BreadcrumbComponent, BreadcrumbItemComponent };
//# sourceMappingURL=ciag-orchestra-breadcrumb.mjs.map
