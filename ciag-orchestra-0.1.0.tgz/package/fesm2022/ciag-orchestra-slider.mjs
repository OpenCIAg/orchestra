import * as i0 from '@angular/core';
import { viewChild, input, booleanAttribute, numberAttribute, model, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const _c0 = ["trackElement"];
const _c1 = ["startThumb"];
const _c2 = ["endThumb"];
const _forTrack0 = ($index, $item) => $item.value;
function SliderComponent_Conditional_1_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵtextInterpolate2(" ", ctx_r1.formattedStartValue(), " \u2013 ", ctx_r1.formattedEndValue(), " ");
} }
function SliderComponent_Conditional_1_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r1.formattedEndValue(), " ");
} }
function SliderComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4)(1, "label", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "span", 15);
    i0.ɵɵtemplate(4, SliderComponent_Conditional_1_Conditional_4_Template, 1, 2)(5, SliderComponent_Conditional_1_Conditional_5_Template, 1, 1);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵattribute("for", ctx_r1.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.range() ? 4 : 5);
} }
function SliderComponent_Conditional_6_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 17);
} if (rf & 2) {
    const tickPercent_r3 = ctx.$implicit;
    i0.ɵɵstyleProp("left", tickPercent_r3, "%");
} }
function SliderComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵrepeaterCreate(1, SliderComponent_Conditional_6_For_2_Template, 1, 2, "span", 16, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.ticks());
} }
function SliderComponent_Conditional_7_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.formattedStartValue(), " ");
} }
function SliderComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 18, 2);
    i0.ɵɵlistener("keydown", function SliderComponent_Conditional_7_Template_div_keydown_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onKeyDown($event, "start")); })("focus", function SliderComponent_Conditional_7_Template_div_focus_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onThumbFocus("start")); })("blur", function SliderComponent_Conditional_7_Template_div_blur_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onThumbBlur()); })("mouseenter", function SliderComponent_Conditional_7_Template_div_mouseenter_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onThumbMouseEnter("start")); })("mouseleave", function SliderComponent_Conditional_7_Template_div_mouseleave_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onThumbMouseLeave()); });
    i0.ɵɵtemplate(2, SliderComponent_Conditional_7_Conditional_2_Template, 2, 1, "div", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("left", ctx_r1.startPercent(), "%");
    i0.ɵɵclassProp("orc-slider-thumb--active", ctx_r1.activeThumb() === "start" && ctx_r1.isDragging())("orc-slider-thumb--focused", ctx_r1.focusedThumb() === "start");
    i0.ɵɵattribute("aria-valuenow", ctx_r1.currentStartValue())("aria-valuemin", ctx_r1.minVal())("aria-valuemax", ctx_r1.currentEndValue())("aria-label", ctx_r1.ariaLabelMin())("aria-orientation", "horizontal")("aria-disabled", ctx_r1.effectiveDisabled() ? "true" : null);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.shouldShowTooltip("start") ? 2 : -1);
} }
function SliderComponent_Conditional_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.formattedEndValue(), " ");
} }
function SliderComponent_Conditional_11_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const mark_r5 = ctx.$implicit;
    i0.ɵɵstyleProp("left", mark_r5.percent, "%");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", mark_r5.label, " ");
} }
function SliderComponent_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 12);
    i0.ɵɵrepeaterCreate(1, SliderComponent_Conditional_11_For_2_Template, 2, 3, "span", 19, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.parsedMarks());
} }
function SliderComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r1.helperId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.helperText(), " ");
} }
let nextSliderUniqueId = 0;
class SliderComponent {
    uniqueId = `orc-slider-${++nextSliderUniqueId}`;
    // ── Element References ────────────────────────────────────
    trackRef = viewChild('trackElement');
    startThumbRef = viewChild('startThumb');
    endThumbRef = viewChild('endThumb');
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('');
    name = input('');
    range = input(false, { transform: booleanAttribute });
    min = input(0, {
        transform: (v) => numberAttribute(v, 0),
    });
    max = input(100, {
        transform: (v) => numberAttribute(v, 100),
    });
    step = input(1, {
        transform: (v) => numberAttribute(v, 1),
    });
    size = input('md');
    disabled = input(false, { transform: booleanAttribute });
    showTicks = input(false, { transform: booleanAttribute });
    showLabels = input(false, { transform: booleanAttribute });
    marks = input(undefined);
    showTooltip = input('auto');
    valueFormatter = input(undefined);
    label = input('');
    helperText = input('');
    ariaLabel = input('');
    ariaLabelMin = input('Valor mínimo');
    ariaLabelMax = input('Valor máximo');
    // ── Two-Way Model ─────────────────────────────────────────
    value = model(0);
    // ── Outputs (Signals API) ─────────────────────────────────
    sliderChange = output();
    sliderInput = output();
    // ── Estado Interno ────────────────────────────────────────
    activeThumb = signal(null);
    isDragging = signal(false);
    hoveredThumb = signal(null);
    focusedThumb = signal(null);
    cvaDisabled = signal(false);
    activePointerId = null;
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.id() || this.uniqueId);
    helperId = computed(() => `${this.effectiveId()}-helper`);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    minVal = computed(() => this.min());
    maxVal = computed(() => {
        const min = this.minVal();
        const max = this.max();
        return max > min ? max : min + 1;
    });
    stepVal = computed(() => {
        const s = this.step();
        return s > 0 ? s : 1;
    });
    normalizedValues = computed(() => {
        const raw = this.value();
        const min = this.minVal();
        const max = this.maxVal();
        const isRange = this.range();
        if (isRange) {
            let start;
            let end;
            if (Array.isArray(raw)) {
                start = Number(raw[0]) || min;
                end = Number(raw[1]) || max;
            }
            else {
                start = min;
                end = Number(raw) || max;
            }
            start = this.clamp(start, min, max);
            end = this.clamp(end, min, max);
            if (start > end) {
                start = end;
            }
            return [start, end];
        }
        else {
            let val = typeof raw === 'number' ? raw : Array.isArray(raw) ? raw[0] : min;
            val = this.clamp(Number(val) || min, min, max);
            return [min, val];
        }
    });
    currentStartValue = computed(() => this.normalizedValues()[0]);
    currentEndValue = computed(() => this.normalizedValues()[1]);
    startPercent = computed(() => {
        const min = this.minVal();
        const max = this.maxVal();
        const val = this.currentStartValue();
        return this.calculatePercent(val, min, max);
    });
    endPercent = computed(() => {
        const min = this.minVal();
        const max = this.maxVal();
        const val = this.currentEndValue();
        return this.calculatePercent(val, min, max);
    });
    fillLeftPercent = computed(() => {
        return this.range() ? this.startPercent() : 0;
    });
    fillWidthPercent = computed(() => {
        if (this.range()) {
            return Math.max(0, this.endPercent() - this.startPercent());
        }
        return this.endPercent();
    });
    formattedStartValue = computed(() => {
        const val = this.currentStartValue();
        const fmt = this.valueFormatter();
        return fmt ? fmt(val) : String(val);
    });
    formattedEndValue = computed(() => {
        const val = this.currentEndValue();
        const fmt = this.valueFormatter();
        return fmt ? fmt(val) : String(val);
    });
    parsedMarks = computed(() => {
        const marksData = this.marks();
        const min = this.minVal();
        const max = this.maxVal();
        if (!marksData) {
            if (this.showLabels()) {
                return [
                    { value: min, percent: 0, label: String(min) },
                    { value: max, percent: 100, label: String(max) },
                ];
            }
            return [];
        }
        if (Array.isArray(marksData)) {
            return marksData.map((item) => {
                const val = typeof item === 'number' ? item : item.value;
                const lbl = typeof item === 'number' ? String(item) : item.label ?? String(val);
                return {
                    value: val,
                    percent: this.calculatePercent(val, min, max),
                    label: lbl,
                };
            });
        }
        if (typeof marksData === 'object') {
            return Object.entries(marksData).map(([valStr, label]) => {
                const val = Number(valStr);
                return {
                    value: val,
                    percent: this.calculatePercent(val, min, max),
                    label: String(label),
                };
            });
        }
        return [];
    });
    ticks = computed(() => {
        if (!this.showTicks())
            return [];
        const min = this.minVal();
        const max = this.maxVal();
        const step = this.stepVal();
        const count = Math.floor((max - min) / step);
        if (count > 100)
            return []; // Evita renderizar milhares de ticks se step for muito pequeno
        const items = [];
        for (let i = 0; i <= count; i++) {
            const val = min + i * step;
            items.push(this.calculatePercent(val, min, max));
        }
        return items;
    });
    // ── ControlValueAccessor ──────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        if (value === null || value === undefined) {
            this.value.set(this.range() ? [this.minVal(), this.maxVal()] : this.minVal());
        }
        else {
            this.value.set(value);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers de Ponteiro / Arraste ────────────────────────
    onTrackPointerDown(event) {
        if (this.effectiveDisabled())
            return;
        const track = this.trackRef()?.nativeElement;
        if (!track)
            return;
        const rect = track.getBoundingClientRect();
        const clickPercent = this.clamp((event.clientX - rect.left) / rect.width, 0, 1);
        const clickedVal = this.percentToValue(clickPercent);
        let targetThumb = 'end';
        if (this.range()) {
            const startDist = Math.abs(clickedVal - this.currentStartValue());
            const endDist = Math.abs(clickedVal - this.currentEndValue());
            if (startDist < endDist) {
                targetThumb = 'start';
            }
            else if (startDist === endDist) {
                targetThumb = clickedVal < this.currentStartValue() ? 'start' : 'end';
            }
            else {
                targetThumb = 'end';
            }
        }
        this.activeThumb.set(targetThumb);
        this.isDragging.set(true);
        this.activePointerId = event.pointerId;
        this.updateValueByTarget(targetThumb, clickedVal);
        // Adiciona ouvintes globais para continuidade fluida do arraste
        window.addEventListener('pointermove', this.onGlobalPointerMove);
        window.addEventListener('pointerup', this.onGlobalPointerUp);
        window.addEventListener('pointercancel', this.onGlobalPointerUp);
        // Foca o thumb correspondente para acessibilidade
        if (targetThumb === 'start') {
            this.startThumbRef()?.nativeElement.focus();
        }
        else {
            this.endThumbRef()?.nativeElement.focus();
        }
        event.preventDefault();
    }
    onGlobalPointerMove = (event) => {
        if (!this.isDragging() || this.effectiveDisabled())
            return;
        const track = this.trackRef()?.nativeElement;
        if (!track)
            return;
        const rect = track.getBoundingClientRect();
        const percent = this.clamp((event.clientX - rect.left) / rect.width, 0, 1);
        const currentVal = this.percentToValue(percent);
        const thumb = this.activeThumb();
        if (thumb) {
            this.updateValueByTarget(thumb, currentVal);
        }
    };
    onGlobalPointerUp = (event) => {
        if (!this.isDragging())
            return;
        this.isDragging.set(false);
        this.activeThumb.set(null);
        this.activePointerId = null;
        window.removeEventListener('pointermove', this.onGlobalPointerMove);
        window.removeEventListener('pointerup', this.onGlobalPointerUp);
        window.removeEventListener('pointercancel', this.onGlobalPointerUp);
        this.onTouched();
        this.sliderChange.emit(this.value());
    };
    // ── Navegação por Teclado WCAG ────────────────────────────
    onKeyDown(event, thumb) {
        if (this.effectiveDisabled())
            return;
        const step = this.stepVal();
        const pageJump = Math.max(step * 10, (this.maxVal() - this.minVal()) / 10);
        const currentVal = thumb === 'start' ? this.currentStartValue() : this.currentEndValue();
        let nextVal = currentVal;
        let handled = false;
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowUp':
                nextVal = currentVal + step;
                handled = true;
                break;
            case 'ArrowLeft':
            case 'ArrowDown':
                nextVal = currentVal - step;
                handled = true;
                break;
            case 'PageUp':
                nextVal = currentVal + pageJump;
                handled = true;
                break;
            case 'PageDown':
                nextVal = currentVal - pageJump;
                handled = true;
                break;
            case 'Home':
                nextVal = this.minVal();
                handled = true;
                break;
            case 'End':
                nextVal = this.maxVal();
                handled = true;
                break;
        }
        if (handled) {
            event.preventDefault();
            this.updateValueByTarget(thumb, nextVal);
            this.sliderChange.emit(this.value());
        }
    }
    onThumbFocus(thumb) {
        this.focusedThumb.set(thumb);
    }
    onThumbBlur() {
        this.focusedThumb.set(null);
        this.onTouched();
    }
    onThumbMouseEnter(thumb) {
        this.hoveredThumb.set(thumb);
    }
    onThumbMouseLeave() {
        this.hoveredThumb.set(null);
    }
    // ── Utilitários de Cálculo e Atualização ───────────────────
    updateValueByTarget(thumb, rawVal) {
        const min = this.minVal();
        const max = this.maxVal();
        const steppedVal = this.snapToStep(this.clamp(rawVal, min, max));
        if (this.range()) {
            let [start, end] = this.normalizedValues();
            if (thumb === 'start') {
                start = Math.min(steppedVal, end);
            }
            else {
                end = Math.max(steppedVal, start);
            }
            const nextRange = [start, end];
            this.value.set(nextRange);
            this.onChange(nextRange);
            this.sliderInput.emit(nextRange);
        }
        else {
            this.value.set(steppedVal);
            this.onChange(steppedVal);
            this.sliderInput.emit(steppedVal);
        }
    }
    snapToStep(val) {
        const min = this.minVal();
        const step = this.stepVal();
        const count = Math.round((val - min) / step);
        const result = min + count * step;
        // Arredonda para evitar problemas de ponto flutuante (ex: 0.1 + 0.2 = 0.30000000000000004)
        const stepDecimals = (step.toString().split('.')[1] || '').length;
        return Number(result.toFixed(stepDecimals));
    }
    calculatePercent(val, min, max) {
        if (max <= min)
            return 0;
        return this.clamp(((val - min) / (max - min)) * 100, 0, 100);
    }
    percentToValue(percent) {
        const min = this.minVal();
        const max = this.maxVal();
        return min + percent * (max - min);
    }
    clamp(val, min, max) {
        return Math.max(min, Math.min(max, val));
    }
    shouldShowTooltip(thumb) {
        const mode = this.showTooltip();
        if (mode === 'never')
            return false;
        if (mode === 'always')
            return true;
        // auto: exibe durante arraste, hover ou foco
        const isThisThumbActive = this.activeThumb() === thumb && this.isDragging();
        const isThisThumbHovered = this.hoveredThumb() === thumb;
        const isThisThumbFocused = this.focusedThumb() === thumb;
        return isThisThumbActive || isThisThumbHovered || isThisThumbFocused;
    }
    ngOnDestroy() {
        window.removeEventListener('pointermove', this.onGlobalPointerMove);
        window.removeEventListener('pointerup', this.onGlobalPointerUp);
        window.removeEventListener('pointercancel', this.onGlobalPointerUp);
    }
    static ɵfac = function SliderComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SliderComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SliderComponent, selectors: [["orc-slider"]], viewQuery: function SliderComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.trackRef, _c0, 5);
            i0.ɵɵviewQuerySignal(ctx.startThumbRef, _c1, 5);
            i0.ɵɵviewQuerySignal(ctx.endThumbRef, _c2, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(3);
        } }, inputs: { id: [1, "id"], name: [1, "name"], range: [1, "range"], min: [1, "min"], max: [1, "max"], step: [1, "step"], size: [1, "size"], disabled: [1, "disabled"], showTicks: [1, "showTicks"], showLabels: [1, "showLabels"], marks: [1, "marks"], showTooltip: [1, "showTooltip"], valueFormatter: [1, "valueFormatter"], label: [1, "label"], helperText: [1, "helperText"], ariaLabel: [1, "ariaLabel"], ariaLabelMin: [1, "ariaLabelMin"], ariaLabelMax: [1, "ariaLabelMax"], value: [1, "value"] }, outputs: { value: "valueChange", sliderChange: "sliderChange", sliderInput: "sliderInput" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => SliderComponent),
                    multi: true,
                },
            ])], decls: 13, vars: 32, consts: [["trackElement", ""], ["endThumb", ""], ["startThumb", ""], [1, "orc-slider-wrapper"], [1, "orc-slider-header"], [1, "orc-slider-track-container", 3, "pointerdown"], [1, "orc-slider-track"], [1, "orc-slider-fill"], [1, "orc-slider-ticks-container"], ["role", "slider", "tabindex", "0", 1, "orc-slider-thumb", "orc-slider-thumb--start", 3, "orc-slider-thumb--active", "orc-slider-thumb--focused", "left"], ["role", "slider", "tabindex", "0", 1, "orc-slider-thumb", "orc-slider-thumb--end", 3, "keydown", "focus", "blur", "mouseenter", "mouseleave", "id"], ["role", "tooltip", 1, "orc-slider-tooltip"], [1, "orc-slider-marks"], [1, "orc-slider-helper", 3, "id"], [1, "orc-slider-label"], [1, "orc-slider-value-display"], [1, "orc-slider-tick", 3, "left"], [1, "orc-slider-tick"], ["role", "slider", "tabindex", "0", 1, "orc-slider-thumb", "orc-slider-thumb--start", 3, "keydown", "focus", "blur", "mouseenter", "mouseleave"], [1, "orc-slider-mark-label", 3, "left"], [1, "orc-slider-mark-label"]], template: function SliderComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 3);
            i0.ɵɵtemplate(1, SliderComponent_Conditional_1_Template, 6, 3, "div", 4);
            i0.ɵɵelementStart(2, "div", 5, 0);
            i0.ɵɵlistener("pointerdown", function SliderComponent_Template_div_pointerdown_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onTrackPointerDown($event)); });
            i0.ɵɵelementStart(4, "div", 6);
            i0.ɵɵelement(5, "div", 7);
            i0.ɵɵtemplate(6, SliderComponent_Conditional_6_Template, 3, 0, "div", 8);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, SliderComponent_Conditional_7_Template, 3, 13, "div", 9);
            i0.ɵɵelementStart(8, "div", 10, 1);
            i0.ɵɵlistener("keydown", function SliderComponent_Template_div_keydown_8_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeyDown($event, "end")); })("focus", function SliderComponent_Template_div_focus_8_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onThumbFocus("end")); })("blur", function SliderComponent_Template_div_blur_8_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onThumbBlur()); })("mouseenter", function SliderComponent_Template_div_mouseenter_8_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onThumbMouseEnter("end")); })("mouseleave", function SliderComponent_Template_div_mouseleave_8_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onThumbMouseLeave()); });
            i0.ɵɵtemplate(10, SliderComponent_Conditional_10_Template, 2, 1, "div", 11);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(11, SliderComponent_Conditional_11_Template, 3, 0, "div", 12)(12, SliderComponent_Conditional_12_Template, 2, 2, "div", 13);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-slider-wrapper--disabled", ctx.effectiveDisabled())("orc-slider-wrapper--sm", ctx.size() === "sm")("orc-slider-wrapper--md", ctx.size() === "md")("orc-slider-wrapper--lg", ctx.size() === "lg");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance(4);
            i0.ɵɵstyleProp("left", ctx.fillLeftPercent(), "%")("width", ctx.fillWidthPercent(), "%");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showTicks() ? 6 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.range() ? 7 : -1);
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("left", ctx.endPercent(), "%");
            i0.ɵɵclassProp("orc-slider-thumb--active", ctx.activeThumb() === "end" && ctx.isDragging())("orc-slider-thumb--focused", ctx.focusedThumb() === "end");
            i0.ɵɵproperty("id", ctx.effectiveId());
            i0.ɵɵattribute("aria-valuenow", ctx.currentEndValue())("aria-valuemin", ctx.range() ? ctx.currentStartValue() : ctx.minVal())("aria-valuemax", ctx.maxVal())("aria-label", ctx.range() ? ctx.ariaLabelMax() : ctx.ariaLabel() || ctx.label() || "Slider")("aria-orientation", "horizontal")("aria-disabled", ctx.effectiveDisabled() ? "true" : null)("aria-describedby", ctx.helperText() ? ctx.helperId() : null);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.shouldShowTooltip("end") ? 10 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.parsedMarks().length > 0 ? 11 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.helperText() ? 12 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-slider-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-slider-wrapper--sm[_ngcontent-%COMP%]{--slider-track-height: 10px;--slider-thumb-size: 14px;--slider-tick-size: 3px}.orc-slider-wrapper--md[_ngcontent-%COMP%]{--slider-track-height: 16px;--slider-thumb-size: 16px;--slider-tick-size: 4px}.orc-slider-wrapper--lg[_ngcontent-%COMP%]{--slider-track-height: 20px;--slider-thumb-size: 20px;--slider-tick-size: 5px}.orc-slider-wrapper--disabled[_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed}.orc-slider-wrapper--disabled[_ngcontent-%COMP%]   .orc-slider-track-container[_ngcontent-%COMP%]{pointer-events:none;cursor:not-allowed}.orc-slider-wrapper--disabled[_ngcontent-%COMP%]   .orc-slider-thumb[_ngcontent-%COMP%]{cursor:not-allowed;border-color:var(--orc-border, #d9d9d9);box-shadow:none}.orc-slider-wrapper--disabled[_ngcontent-%COMP%]   .orc-slider-fill[_ngcontent-%COMP%]{background:var(--text-tertiary, #999999)}.orc-slider-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem)}.orc-slider-label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);cursor:pointer}.orc-slider-value-display[_ngcontent-%COMP%]{font-size:.8125rem;font-weight:600;color:var(--orc-color-azul-eletrico, #1c6aed);font-variant-numeric:tabular-nums}.orc-slider-track-container[_ngcontent-%COMP%]{position:relative;width:100%;height:var(--slider-track-height);display:flex;align-items:center;cursor:pointer;touch-action:none;-webkit-user-select:none;user-select:none;padding:8px 0;box-sizing:content-box}.orc-slider-track[_ngcontent-%COMP%]{position:relative;width:100%;height:var(--slider-track-height);background:var(--orc-border, #d9d9d9);border-radius:var(--radius-full, 200px);overflow:visible;transition:background .15s ease}.orc-slider-fill[_ngcontent-%COMP%]{position:absolute;top:0;height:100%;background:var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-full, 200px);transition:background .15s ease}.orc-slider-ticks-container[_ngcontent-%COMP%]{position:absolute;inset:0;pointer-events:none}.orc-slider-tick[_ngcontent-%COMP%]{position:absolute;top:50%;width:var(--slider-tick-size);height:var(--slider-tick-size);background:#ffffffb3;border-radius:50%;transform:translate(-50%,-50%)}.orc-slider-thumb[_ngcontent-%COMP%]{position:absolute;top:50%;width:var(--slider-thumb-size);height:var(--slider-thumb-size);background:var(--fill-modal, #ffffff);border:1px solid var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-full, 200px);box-shadow:0 1px 3px #00000026,0 1px 2px #0000001a;transform:translate(-50%,-50%);cursor:grab;outline:none;box-sizing:border-box;z-index:2;transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease}.orc-slider-thumb[_ngcontent-%COMP%]:hover{box-shadow:0 0 0 4px #1c6aed26,0 2px 4px #0003;transform:translate(-50%,-50%) scale(1.1)}.orc-slider-thumb--focused[_ngcontent-%COMP%], .orc-slider-thumb[_ngcontent-%COMP%]:focus-visible{box-shadow:0 0 0 4px #1c6aed40,0 2px 4px #0003;border-color:var(--orc-color-azul-eletrico, #1c6aed);transform:translate(-50%,-50%) scale(1.15);z-index:4}.orc-slider-thumb--active[_ngcontent-%COMP%]{cursor:grabbing;box-shadow:0 0 0 6px #1c6aed4d,0 2px 6px #00000040;transform:translate(-50%,-50%) scale(1.2);z-index:5}.orc-slider-tooltip[_ngcontent-%COMP%]{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--orc-font-main, #141414);color:#fff;font-size:.6875rem;font-weight:600;line-height:1;padding:4px 7px;border-radius:var(--radius-sm, 4px);white-space:nowrap;pointer-events:none;box-shadow:0 2px 8px #0003;animation:_ngcontent-%COMP%_orc-tooltip-fade .15s cubic-bezier(.16,1,.3,1);font-variant-numeric:tabular-nums}.orc-slider-tooltip[_ngcontent-%COMP%]:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border-width:4px 4px 0 4px;border-style:solid;border-color:var(--orc-font-main, #141414) transparent transparent transparent}@keyframes _ngcontent-%COMP%_orc-tooltip-fade{0%{opacity:0;transform:translate(-50%) translateY(4px)}to{opacity:1;transform:translate(-50%) translateY(0)}}.orc-slider-marks[_ngcontent-%COMP%]{position:relative;width:100%;height:16px;margin-top:2px}.orc-slider-mark-label[_ngcontent-%COMP%]{position:absolute;transform:translate(-50%);font-size:.75rem;color:var(--text-secondary, #666666);white-space:nowrap;pointer-events:none;font-variant-numeric:tabular-nums}.orc-slider-helper[_ngcontent-%COMP%]{font-size:.75rem;color:var(--text-secondary, #666666);margin-top:2px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SliderComponent, [{
        type: Component,
        args: [{ selector: 'orc-slider', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => SliderComponent),
                        multi: true,
                    },
                ], template: "<div\n  class=\"orc-slider-wrapper\"\n  [class.orc-slider-wrapper--disabled]=\"effectiveDisabled()\"\n  [class.orc-slider-wrapper--sm]=\"size() === 'sm'\"\n  [class.orc-slider-wrapper--md]=\"size() === 'md'\"\n  [class.orc-slider-wrapper--lg]=\"size() === 'lg'\"\n>\n  <!-- R\u00F3tulo Superior (Label) -->\n  @if (label()) {\n    <div class=\"orc-slider-header\">\n      <label [attr.for]=\"effectiveId()\" class=\"orc-slider-label\">\n        {{ label() }}\n      </label>\n      <span class=\"orc-slider-value-display\">\n        @if (range()) {\n          {{ formattedStartValue() }} \u2013 {{ formattedEndValue() }}\n        } @else {\n          {{ formattedEndValue() }}\n        }\n      </span>\n    </div>\n  }\n\n  <!-- \u00C1rea Interativa do Slider (Track + Thumbs) -->\n  <div\n    #trackElement\n    class=\"orc-slider-track-container\"\n    (pointerdown)=\"onTrackPointerDown($event)\"\n  >\n    <!-- Barra de Fundo (Track Inativo) -->\n    <div class=\"orc-slider-track\">\n      <!-- Barra Preenchida Ativa (Progress Fill) -->\n      <div\n        class=\"orc-slider-fill\"\n        [style.left.%]=\"fillLeftPercent()\"\n        [style.width.%]=\"fillWidthPercent()\"\n      ></div>\n\n      <!-- Marca\u00E7\u00F5es de Escala (Ticks) -->\n      @if (showTicks()) {\n        <div class=\"orc-slider-ticks-container\">\n          @for (tickPercent of ticks(); track $index) {\n            <span\n              class=\"orc-slider-tick\"\n              [style.left.%]=\"tickPercent\"\n            ></span>\n          }\n        </div>\n      }\n    </div>\n\n    <!-- Thumb Inicial (Apenas no Modo Range) -->\n    @if (range()) {\n      <div\n        #startThumb\n        class=\"orc-slider-thumb orc-slider-thumb--start\"\n        [class.orc-slider-thumb--active]=\"activeThumb() === 'start' && isDragging()\"\n        [class.orc-slider-thumb--focused]=\"focusedThumb() === 'start'\"\n        [style.left.%]=\"startPercent()\"\n        role=\"slider\"\n        tabindex=\"0\"\n        [attr.aria-valuenow]=\"currentStartValue()\"\n        [attr.aria-valuemin]=\"minVal()\"\n        [attr.aria-valuemax]=\"currentEndValue()\"\n        [attr.aria-label]=\"ariaLabelMin()\"\n        [attr.aria-orientation]=\"'horizontal'\"\n        [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n        (keydown)=\"onKeyDown($event, 'start')\"\n        (focus)=\"onThumbFocus('start')\"\n        (blur)=\"onThumbBlur()\"\n        (mouseenter)=\"onThumbMouseEnter('start')\"\n        (mouseleave)=\"onThumbMouseLeave()\"\n      >\n        <!-- Tooltip Flutuante -->\n        @if (shouldShowTooltip('start')) {\n          <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n            {{ formattedStartValue() }}\n          </div>\n        }\n      </div>\n    }\n\n    <!-- Thumb Principal / Final -->\n    <div\n      #endThumb\n      [id]=\"effectiveId()\"\n      class=\"orc-slider-thumb orc-slider-thumb--end\"\n      [class.orc-slider-thumb--active]=\"activeThumb() === 'end' && isDragging()\"\n      [class.orc-slider-thumb--focused]=\"focusedThumb() === 'end'\"\n      [style.left.%]=\"endPercent()\"\n      role=\"slider\"\n      tabindex=\"0\"\n      [attr.aria-valuenow]=\"currentEndValue()\"\n      [attr.aria-valuemin]=\"range() ? currentStartValue() : minVal()\"\n      [attr.aria-valuemax]=\"maxVal()\"\n      [attr.aria-label]=\"range() ? ariaLabelMax() : (ariaLabel() || label() || 'Slider')\"\n      [attr.aria-orientation]=\"'horizontal'\"\n      [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n      [attr.aria-describedby]=\"helperText() ? helperId() : null\"\n      (keydown)=\"onKeyDown($event, 'end')\"\n      (focus)=\"onThumbFocus('end')\"\n      (blur)=\"onThumbBlur()\"\n      (mouseenter)=\"onThumbMouseEnter('end')\"\n      (mouseleave)=\"onThumbMouseLeave()\"\n    >\n      <!-- Tooltip Flutuante -->\n      @if (shouldShowTooltip('end')) {\n        <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n          {{ formattedEndValue() }}\n        </div>\n      }\n    </div>\n  </div>\n\n  <!-- R\u00F3tulos e Marca\u00E7\u00F5es Inferiores (Marks & Labels) -->\n  @if (parsedMarks().length > 0) {\n    <div class=\"orc-slider-marks\">\n      @for (mark of parsedMarks(); track mark.value) {\n        <span\n          class=\"orc-slider-mark-label\"\n          [style.left.%]=\"mark.percent\"\n        >\n          {{ mark.label }}\n        </span>\n      }\n    </div>\n  }\n\n  <!-- Texto de Ajuda (Helper Text) -->\n  @if (helperText()) {\n    <div [id]=\"helperId()\" class=\"orc-slider-helper\">\n      {{ helperText() }}\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-slider-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-slider-wrapper--sm{--slider-track-height: 10px;--slider-thumb-size: 14px;--slider-tick-size: 3px}.orc-slider-wrapper--md{--slider-track-height: 16px;--slider-thumb-size: 16px;--slider-tick-size: 4px}.orc-slider-wrapper--lg{--slider-track-height: 20px;--slider-thumb-size: 20px;--slider-tick-size: 5px}.orc-slider-wrapper--disabled{opacity:.5;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-track-container{pointer-events:none;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-thumb{cursor:not-allowed;border-color:var(--orc-border, #d9d9d9);box-shadow:none}.orc-slider-wrapper--disabled .orc-slider-fill{background:var(--text-tertiary, #999999)}.orc-slider-header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem)}.orc-slider-label{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);cursor:pointer}.orc-slider-value-display{font-size:.8125rem;font-weight:600;color:var(--orc-color-azul-eletrico, #1c6aed);font-variant-numeric:tabular-nums}.orc-slider-track-container{position:relative;width:100%;height:var(--slider-track-height);display:flex;align-items:center;cursor:pointer;touch-action:none;-webkit-user-select:none;user-select:none;padding:8px 0;box-sizing:content-box}.orc-slider-track{position:relative;width:100%;height:var(--slider-track-height);background:var(--orc-border, #d9d9d9);border-radius:var(--radius-full, 200px);overflow:visible;transition:background .15s ease}.orc-slider-fill{position:absolute;top:0;height:100%;background:var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-full, 200px);transition:background .15s ease}.orc-slider-ticks-container{position:absolute;inset:0;pointer-events:none}.orc-slider-tick{position:absolute;top:50%;width:var(--slider-tick-size);height:var(--slider-tick-size);background:#ffffffb3;border-radius:50%;transform:translate(-50%,-50%)}.orc-slider-thumb{position:absolute;top:50%;width:var(--slider-thumb-size);height:var(--slider-thumb-size);background:var(--fill-modal, #ffffff);border:1px solid var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-full, 200px);box-shadow:0 1px 3px #00000026,0 1px 2px #0000001a;transform:translate(-50%,-50%);cursor:grab;outline:none;box-sizing:border-box;z-index:2;transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease}.orc-slider-thumb:hover{box-shadow:0 0 0 4px #1c6aed26,0 2px 4px #0003;transform:translate(-50%,-50%) scale(1.1)}.orc-slider-thumb--focused,.orc-slider-thumb:focus-visible{box-shadow:0 0 0 4px #1c6aed40,0 2px 4px #0003;border-color:var(--orc-color-azul-eletrico, #1c6aed);transform:translate(-50%,-50%) scale(1.15);z-index:4}.orc-slider-thumb--active{cursor:grabbing;box-shadow:0 0 0 6px #1c6aed4d,0 2px 6px #00000040;transform:translate(-50%,-50%) scale(1.2);z-index:5}.orc-slider-tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--orc-font-main, #141414);color:#fff;font-size:.6875rem;font-weight:600;line-height:1;padding:4px 7px;border-radius:var(--radius-sm, 4px);white-space:nowrap;pointer-events:none;box-shadow:0 2px 8px #0003;animation:orc-tooltip-fade .15s cubic-bezier(.16,1,.3,1);font-variant-numeric:tabular-nums}.orc-slider-tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border-width:4px 4px 0 4px;border-style:solid;border-color:var(--orc-font-main, #141414) transparent transparent transparent}@keyframes orc-tooltip-fade{0%{opacity:0;transform:translate(-50%) translateY(4px)}to{opacity:1;transform:translate(-50%) translateY(0)}}.orc-slider-marks{position:relative;width:100%;height:16px;margin-top:2px}.orc-slider-mark-label{position:absolute;transform:translate(-50%);font-size:.75rem;color:var(--text-secondary, #666666);white-space:nowrap;pointer-events:none;font-variant-numeric:tabular-nums}.orc-slider-helper{font-size:.75rem;color:var(--text-secondary, #666666);margin-top:2px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SliderComponent, { className: "SliderComponent", filePath: "slider.component.ts", lineNumber: 43 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { SliderComponent };
//# sourceMappingURL=ciag-orchestra-slider.mjs.map
