import * as i0 from '@angular/core';
import { inject, ElementRef, input, booleanAttribute, output, signal, computed, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';

const _c0 = ["*"];
class ScrollAreaComponent {
    host = inject((ElementRef));
    orientation = input('vertical');
    maxHeight = input('240px');
    maxWidth = input('');
    alwaysShowScrollbar = input(false, { transform: booleanAttribute });
    label = input('Scrollable content');
    scrolled = output();
    canScrollBack = signal(false);
    canScrollForward = signal(false);
    viewportStyle = computed(() => ({ 'max-height': this.maxHeight() || null, 'max-width': this.maxWidth() || null }));
    onScroll(event) {
        const target = event.target;
        const vertical = target.scrollTop > 0;
        const horizontal = target.scrollLeft > 0;
        const verticalForward = target.scrollTop + target.clientHeight < target.scrollHeight - 1;
        const horizontalForward = target.scrollLeft + target.clientWidth < target.scrollWidth - 1;
        this.canScrollBack.set(this.orientation() === 'horizontal' ? horizontal : vertical);
        this.canScrollForward.set(this.orientation() === 'horizontal' ? horizontalForward : verticalForward);
        this.scrolled.emit({ top: target.scrollTop, left: target.scrollLeft });
    }
    onKeydown(event) {
        const viewport = this.host.nativeElement.querySelector('.orc-scroll-area__viewport');
        if (!viewport)
            return;
        if (event.key === 'PageDown') {
            event.preventDefault();
            viewport.scrollBy({ top: viewport.clientHeight, behavior: 'smooth' });
        }
        if (event.key === 'PageUp') {
            event.preventDefault();
            viewport.scrollBy({ top: -viewport.clientHeight, behavior: 'smooth' });
        }
    }
    static ɵfac = function ScrollAreaComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ScrollAreaComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ScrollAreaComponent, selectors: [["orc-scroll-area"]], hostBindings: function ScrollAreaComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown", function ScrollAreaComponent_keydown_HostBindingHandler($event) { return ctx.onKeydown($event); });
        } }, inputs: { orientation: [1, "orientation"], maxHeight: [1, "maxHeight"], maxWidth: [1, "maxWidth"], alwaysShowScrollbar: [1, "alwaysShowScrollbar"], label: [1, "label"] }, outputs: { scrolled: "scrolled" }, ngContentSelectors: _c0, decls: 5, vars: 13, consts: [[1, "orc-scroll-area"], ["aria-hidden", "true", 1, "orc-scroll-area__shadow", "orc-scroll-area__shadow--top"], ["tabindex", "0", 1, "orc-scroll-area__viewport", 3, "scroll"], ["aria-hidden", "true", 1, "orc-scroll-area__shadow", "orc-scroll-area__shadow--bottom"]], template: function ScrollAreaComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "div", 1);
            i0.ɵɵelementStart(2, "div", 2);
            i0.ɵɵlistener("scroll", function ScrollAreaComponent_Template_div_scroll_2_listener($event) { return ctx.onScroll($event); });
            i0.ɵɵprojection(3);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "div", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-scroll-area--horizontal", ctx.orientation() === "horizontal")("orc-scroll-area--both", ctx.orientation() === "both")("orc-scroll-area--always", ctx.alwaysShowScrollbar());
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵclassProp("orc-scroll-area__shadow--visible", ctx.canScrollBack());
            i0.ɵɵadvance();
            i0.ɵɵstyleMap(ctx.viewportStyle());
            i0.ɵɵadvance(2);
            i0.ɵɵclassProp("orc-scroll-area__shadow--visible", ctx.canScrollForward());
        } }, styles: ["[_nghost-%COMP%]{display:block;min-width:0}.orc-scroll-area[_ngcontent-%COMP%]{position:relative;min-width:0}.orc-scroll-area__viewport[_ngcontent-%COMP%]{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:var(--orc-border, #d9d9d9) transparent;outline:none}.orc-scroll-area__viewport[_ngcontent-%COMP%]:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-scroll-area__viewport[_ngcontent-%COMP%]::-webkit-scrollbar{width:8px;height:8px}.orc-scroll-area__viewport[_ngcontent-%COMP%]::-webkit-scrollbar-thumb{border-radius:999px;background:var(--orc-border, #d9d9d9)}.orc-scroll-area--horizontal[_ngcontent-%COMP%]   .orc-scroll-area__viewport[_ngcontent-%COMP%]{overflow-x:auto;overflow-y:hidden;white-space:nowrap}.orc-scroll-area--both[_ngcontent-%COMP%]   .orc-scroll-area__viewport[_ngcontent-%COMP%]{overflow:auto}.orc-scroll-area--always[_ngcontent-%COMP%]   .orc-scroll-area__viewport[_ngcontent-%COMP%]{scrollbar-gutter:stable}.orc-scroll-area__shadow[_ngcontent-%COMP%]{position:absolute;z-index:1;right:8px;left:0;height:18px;pointer-events:none;opacity:0;transition:opacity .2s}.orc-scroll-area__shadow--top[_ngcontent-%COMP%]{top:0;background:linear-gradient(var(--fill-modal, #fff),transparent)}.orc-scroll-area__shadow--bottom[_ngcontent-%COMP%]{bottom:0;background:linear-gradient(transparent,var(--fill-modal, #fff))}.orc-scroll-area__shadow--visible[_ngcontent-%COMP%]{opacity:1}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ScrollAreaComponent, [{
        type: Component,
        args: [{ selector: 'orc-scroll-area', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-scroll-area\" [class.orc-scroll-area--horizontal]=\"orientation() === 'horizontal'\" [class.orc-scroll-area--both]=\"orientation() === 'both'\" [class.orc-scroll-area--always]=\"alwaysShowScrollbar()\" [attr.aria-label]=\"label()\">\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--top\" [class.orc-scroll-area__shadow--visible]=\"canScrollBack()\" aria-hidden=\"true\"></div>\n  <div class=\"orc-scroll-area__viewport\" [style]=\"viewportStyle()\" tabindex=\"0\" (scroll)=\"onScroll($event)\"><ng-content /></div>\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--bottom\" [class.orc-scroll-area__shadow--visible]=\"canScrollForward()\" aria-hidden=\"true\"></div>\n</div>\n", styles: [":host{display:block;min-width:0}.orc-scroll-area{position:relative;min-width:0}.orc-scroll-area__viewport{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:var(--orc-border, #d9d9d9) transparent;outline:none}.orc-scroll-area__viewport:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-scroll-area__viewport::-webkit-scrollbar{width:8px;height:8px}.orc-scroll-area__viewport::-webkit-scrollbar-thumb{border-radius:999px;background:var(--orc-border, #d9d9d9)}.orc-scroll-area--horizontal .orc-scroll-area__viewport{overflow-x:auto;overflow-y:hidden;white-space:nowrap}.orc-scroll-area--both .orc-scroll-area__viewport{overflow:auto}.orc-scroll-area--always .orc-scroll-area__viewport{scrollbar-gutter:stable}.orc-scroll-area__shadow{position:absolute;z-index:1;right:8px;left:0;height:18px;pointer-events:none;opacity:0;transition:opacity .2s}.orc-scroll-area__shadow--top{top:0;background:linear-gradient(var(--fill-modal, #fff),transparent)}.orc-scroll-area__shadow--bottom{bottom:0;background:linear-gradient(transparent,var(--fill-modal, #fff))}.orc-scroll-area__shadow--visible{opacity:1}\n"] }]
    }], null, { onKeydown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ScrollAreaComponent, { className: "ScrollAreaComponent", filePath: "scroll-area.component.ts", lineNumber: 12 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ScrollAreaComponent };
//# sourceMappingURL=ciag-orchestra-scroll-area.mjs.map
