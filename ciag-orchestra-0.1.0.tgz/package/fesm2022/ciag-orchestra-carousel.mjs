import * as i0 from '@angular/core';
import { input, model, booleanAttribute, numberAttribute, output, computed, effect, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

function CarouselComponent_Conditional_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 6);
} if (rf & 2) {
    const item_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("src", item_r1.image, i0.ɵɵsanitizeUrl)("alt", item_r1.alt || item_r1.label);
} }
function CarouselComponent_Conditional_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.safeIndex() + 1);
} }
function CarouselComponent_Conditional_2_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r1.description);
} }
function CarouselComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "article", 2);
    i0.ɵɵtemplate(1, CarouselComponent_Conditional_2_Conditional_1_Template, 1, 2, "img", 6)(2, CarouselComponent_Conditional_2_Conditional_2_Template, 2, 1, "div", 7);
    i0.ɵɵelementStart(3, "div", 8)(4, "h3");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, CarouselComponent_Conditional_2_Conditional_6_Template, 2, 1, "p");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r1 = ctx;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r1.itemId(ctx_r1.safeIndex()));
    i0.ɵɵattribute("aria-label", ctx_r1.safeIndex() + 1 + " of " + ctx_r1.items().length);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r1.image ? 1 : 2);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(item_r1.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r1.description ? 6 : -1);
} }
function CarouselComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 3);
    i0.ɵɵtext(1, "Nenhum item dispon\u00EDvel.");
    i0.ɵɵelementEnd();
} }
function CarouselComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 4)(1, "button", 9);
    i0.ɵɵlistener("click", function CarouselComponent_Conditional_4_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.previous()); });
    i0.ɵɵtext(2, "\u2039");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "button", 10);
    i0.ɵɵlistener("click", function CarouselComponent_Conditional_4_Template_button_click_3_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.next()); });
    i0.ɵɵtext(4, "\u203A");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", !ctx_r1.canGoPrevious());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r1.canGoNext());
} }
function CarouselComponent_Conditional_5_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵlistener("click", function CarouselComponent_Conditional_5_For_2_Template_button_click_0_listener() { const $index_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.goTo($index_r5)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const $index_r5 = ctx.$index;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("orc-carousel__indicator--active", ctx_r1.safeIndex() === $index_r5);
    i0.ɵɵproperty("disabled", item_r6.disabled);
    i0.ɵɵattribute("aria-selected", ctx_r1.safeIndex() === $index_r5)("aria-label", "Exibir " + item_r6.label);
} }
function CarouselComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵrepeaterCreate(1, CarouselComponent_Conditional_5_For_2_Template, 1, 5, "button", 11, i0.ɵɵcomponentInstance().trackItem, true);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.items());
} }
let nextCarouselId = 0;
class CarouselComponent {
    carouselId = `orc-carousel-${++nextCarouselId}`;
    autoplayTimer = null;
    items = input([]);
    activeIndex = model(0);
    orientation = input('horizontal');
    loop = input(true, { transform: booleanAttribute });
    autoplay = input(false, { transform: booleanAttribute });
    interval = input(5000, { transform: numberAttribute });
    showArrows = input(true, { transform: booleanAttribute });
    showIndicators = input(true, { transform: booleanAttribute });
    ariaLabel = input('Carousel');
    slideChange = output();
    activeItem = computed(() => this.items()[this.safeIndex()] ?? null);
    safeIndex = computed(() => {
        const count = this.items().length;
        if (!count)
            return 0;
        return Math.min(Math.max(this.activeIndex(), 0), count - 1);
    });
    canGoPrevious = computed(() => this.loop() || this.findIndex(-1) !== null);
    canGoNext = computed(() => this.loop() || this.findIndex(1) !== null);
    itemId = (index) => `${this.carouselId}-item-${index}`;
    constructor() {
        effect(() => {
            this.items();
            this.autoplay();
            this.interval();
            this.stopAutoplay();
            if (this.autoplay() && this.items().length > 1) {
                this.autoplayTimer = setInterval(() => this.next(), Math.max(1000, this.interval()));
            }
        });
    }
    ngOnDestroy() {
        this.stopAutoplay();
    }
    previous() {
        const index = this.findIndex(-1);
        if (index !== null)
            this.goTo(index);
    }
    next() {
        const index = this.findIndex(1);
        if (index !== null)
            this.goTo(index);
    }
    goTo(index) {
        const item = this.items()[index];
        if (!item || item.disabled)
            return;
        this.activeIndex.set(index);
        this.slideChange.emit({ index, item });
    }
    trackItem(index, item) {
        return item.id ?? index;
    }
    onKeydown(event) {
        if (this.orientation() === 'vertical') {
            if (event.key === 'ArrowUp') {
                event.preventDefault();
                this.previous();
            }
            else if (event.key === 'ArrowDown') {
                event.preventDefault();
                this.next();
            }
            return;
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            this.previous();
        }
        else if (event.key === 'ArrowRight') {
            event.preventDefault();
            this.next();
        }
    }
    findIndex(direction) {
        const items = this.items();
        if (!items.length)
            return null;
        const start = this.safeIndex();
        for (let offset = 1; offset <= items.length; offset += 1) {
            let candidate = start + direction * offset;
            if (this.loop()) {
                candidate = (candidate + items.length) % items.length;
            }
            else if (candidate < 0 || candidate >= items.length) {
                continue;
            }
            if (!items[candidate]?.disabled)
                return candidate;
        }
        return null;
    }
    stopAutoplay() {
        if (this.autoplayTimer !== null) {
            clearInterval(this.autoplayTimer);
            this.autoplayTimer = null;
        }
    }
    static ɵfac = function CarouselComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CarouselComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CarouselComponent, selectors: [["orc-carousel"]], hostBindings: function CarouselComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown", function CarouselComponent_keydown_HostBindingHandler($event) { return ctx.onKeydown($event); });
        } }, inputs: { items: [1, "items"], activeIndex: [1, "activeIndex"], orientation: [1, "orientation"], loop: [1, "loop"], autoplay: [1, "autoplay"], interval: [1, "interval"], showArrows: [1, "showArrows"], showIndicators: [1, "showIndicators"], ariaLabel: [1, "ariaLabel"] }, outputs: { activeIndex: "activeIndexChange", slideChange: "slideChange" }, decls: 6, vars: 6, consts: [["aria-roledescription", "carousel", "tabindex", "0", 1, "orc-carousel"], ["aria-live", "polite", 1, "orc-carousel__viewport"], ["role", "group", "aria-roledescription", "slide", 1, "orc-carousel__slide", 3, "id"], [1, "orc-carousel__empty"], [1, "orc-carousel__arrows"], ["role", "tablist", "aria-label", "Slides", 1, "orc-carousel__indicators"], [1, "orc-carousel__image", 3, "src", "alt"], ["aria-hidden", "true", 1, "orc-carousel__placeholder"], [1, "orc-carousel__content"], ["type", "button", "aria-label", "Anterior", 1, "orc-carousel__arrow", 3, "click", "disabled"], ["type", "button", "aria-label", "Pr\u00F3ximo", 1, "orc-carousel__arrow", 3, "click", "disabled"], ["type", "button", "role", "tab", 1, "orc-carousel__indicator", 3, "orc-carousel__indicator--active", "disabled"], ["type", "button", "role", "tab", 1, "orc-carousel__indicator", 3, "click", "disabled"]], template: function CarouselComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "section", 0)(1, "div", 1);
            i0.ɵɵtemplate(2, CarouselComponent_Conditional_2_Template, 7, 5, "article", 2)(3, CarouselComponent_Conditional_3_Template, 2, 0, "div", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, CarouselComponent_Conditional_4_Template, 5, 2, "div", 4)(5, CarouselComponent_Conditional_5_Template, 3, 0, "div", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_2_0;
            i0.ɵɵclassProp("orc-carousel--vertical", ctx.orientation() === "vertical");
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional((tmp_2_0 = ctx.activeItem()) ? 2 : 3, tmp_2_0);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.showArrows() && ctx.items().length > 1 ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showIndicators() && ctx.items().length > 1 ? 5 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-carousel[_ngcontent-%COMP%]{position:relative;display:grid;gap:12px;width:100%;padding:12px;box-sizing:border-box;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-lg, 14px);background:var(--fill-modal, #fff);outline:none}.orc-carousel[_ngcontent-%COMP%]:focus-visible{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 22%,transparent)}.orc-carousel--vertical[_ngcontent-%COMP%]   .orc-carousel__slide[_ngcontent-%COMP%]{min-height:220px}.orc-carousel__viewport[_ngcontent-%COMP%]{min-width:0;overflow:hidden}.orc-carousel__slide[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px;min-height:180px;padding:12px;border-radius:var(--radius-md, 10px);background:var(--orc-th, #f7f8fa)}.orc-carousel__image[_ngcontent-%COMP%], .orc-carousel__placeholder[_ngcontent-%COMP%]{width:42%;max-height:220px;aspect-ratio:16/10;object-fit:cover;border-radius:var(--radius-md, 10px)}.orc-carousel__placeholder[_ngcontent-%COMP%]{display:grid;place-items:center;background:var(--orc-color-azul-eletrico, #1c6aed);color:#fff;font-size:2rem;font-weight:700}.orc-carousel__content[_ngcontent-%COMP%]{min-width:0}.orc-carousel__content[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0 0 6px;color:var(--orc-font-main, #141414);font-size:1rem}.orc-carousel__content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;color:var(--orc-font-secondary, #666);line-height:1.5}.orc-carousel__arrows[_ngcontent-%COMP%]{display:flex;justify-content:space-between;position:absolute;inset:50% 16px auto;transform:translateY(-50%);pointer-events:none}.orc-carousel__arrow[_ngcontent-%COMP%]{pointer-events:auto;display:grid;place-items:center;width:34px;height:34px;border:1px solid var(--orc-border, #d9d9d9);border-radius:50%;background:var(--fill-modal, #fff);color:var(--orc-font-main, #141414);font-size:1.5rem;line-height:1;cursor:pointer}.orc-carousel__arrow[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:not-allowed}.orc-carousel__arrow[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-carousel__indicators[_ngcontent-%COMP%]{display:flex;justify-content:center;gap:6px}.orc-carousel__indicator[_ngcontent-%COMP%]{width:8px;height:8px;padding:0;border:0;border-radius:50%;background:var(--orc-border, #d9d9d9);cursor:pointer}.orc-carousel__indicator--active[_ngcontent-%COMP%]{width:22px;border-radius:999px;background:var(--orc-color-azul-eletrico, #1c6aed)}.orc-carousel__indicator[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-carousel__empty[_ngcontent-%COMP%]{padding:32px;text-align:center;color:var(--orc-font-secondary, #666)}@media(max-width:560px){.orc-carousel__slide[_ngcontent-%COMP%]{align-items:stretch;flex-direction:column}.orc-carousel__image[_ngcontent-%COMP%], .orc-carousel__placeholder[_ngcontent-%COMP%]{width:100%}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CarouselComponent, [{
        type: Component,
        args: [{ selector: 'orc-carousel', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<section\n  class=\"orc-carousel\"\n  [class.orc-carousel--vertical]=\"orientation() === 'vertical'\"\n  [attr.aria-label]=\"ariaLabel()\"\n  aria-roledescription=\"carousel\"\n  tabindex=\"0\"\n>\n  <div class=\"orc-carousel__viewport\" aria-live=\"polite\">\n    @if (activeItem(); as item) {\n      <article\n        class=\"orc-carousel__slide\"\n        [id]=\"itemId(safeIndex())\"\n        role=\"group\"\n        aria-roledescription=\"slide\"\n        [attr.aria-label]=\"(safeIndex() + 1) + ' of ' + items().length\"\n      >\n        @if (item.image) {\n          <img class=\"orc-carousel__image\" [src]=\"item.image\" [alt]=\"item.alt || item.label\" />\n        } @else {\n          <div class=\"orc-carousel__placeholder\" aria-hidden=\"true\">{{ safeIndex() + 1 }}</div>\n        }\n        <div class=\"orc-carousel__content\">\n          <h3>{{ item.label }}</h3>\n          @if (item.description) { <p>{{ item.description }}</p> }\n        </div>\n      </article>\n    } @else {\n      <div class=\"orc-carousel__empty\">Nenhum item dispon\u00EDvel.</div>\n    }\n  </div>\n\n  @if (showArrows() && items().length > 1) {\n    <div class=\"orc-carousel__arrows\">\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"previous()\" [disabled]=\"!canGoPrevious()\" aria-label=\"Anterior\">\u2039</button>\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"next()\" [disabled]=\"!canGoNext()\" aria-label=\"Pr\u00F3ximo\">\u203A</button>\n    </div>\n  }\n\n  @if (showIndicators() && items().length > 1) {\n    <div class=\"orc-carousel__indicators\" role=\"tablist\" aria-label=\"Slides\">\n      @for (item of items(); track trackItem($index, item)) {\n        <button\n          type=\"button\"\n          class=\"orc-carousel__indicator\"\n          [class.orc-carousel__indicator--active]=\"safeIndex() === $index\"\n          [disabled]=\"item.disabled\"\n          role=\"tab\"\n          [attr.aria-selected]=\"safeIndex() === $index\"\n          [attr.aria-label]=\"'Exibir ' + item.label\"\n          (click)=\"goTo($index)\"\n        ></button>\n      }\n    </div>\n  }\n</section>\n", styles: [":host{display:block;width:100%}.orc-carousel{position:relative;display:grid;gap:12px;width:100%;padding:12px;box-sizing:border-box;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-lg, 14px);background:var(--fill-modal, #fff);outline:none}.orc-carousel:focus-visible{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 22%,transparent)}.orc-carousel--vertical .orc-carousel__slide{min-height:220px}.orc-carousel__viewport{min-width:0;overflow:hidden}.orc-carousel__slide{display:flex;align-items:center;gap:16px;min-height:180px;padding:12px;border-radius:var(--radius-md, 10px);background:var(--orc-th, #f7f8fa)}.orc-carousel__image,.orc-carousel__placeholder{width:42%;max-height:220px;aspect-ratio:16/10;object-fit:cover;border-radius:var(--radius-md, 10px)}.orc-carousel__placeholder{display:grid;place-items:center;background:var(--orc-color-azul-eletrico, #1c6aed);color:#fff;font-size:2rem;font-weight:700}.orc-carousel__content{min-width:0}.orc-carousel__content h3{margin:0 0 6px;color:var(--orc-font-main, #141414);font-size:1rem}.orc-carousel__content p{margin:0;color:var(--orc-font-secondary, #666);line-height:1.5}.orc-carousel__arrows{display:flex;justify-content:space-between;position:absolute;inset:50% 16px auto;transform:translateY(-50%);pointer-events:none}.orc-carousel__arrow{pointer-events:auto;display:grid;place-items:center;width:34px;height:34px;border:1px solid var(--orc-border, #d9d9d9);border-radius:50%;background:var(--fill-modal, #fff);color:var(--orc-font-main, #141414);font-size:1.5rem;line-height:1;cursor:pointer}.orc-carousel__arrow:disabled{opacity:.4;cursor:not-allowed}.orc-carousel__arrow:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-carousel__indicators{display:flex;justify-content:center;gap:6px}.orc-carousel__indicator{width:8px;height:8px;padding:0;border:0;border-radius:50%;background:var(--orc-border, #d9d9d9);cursor:pointer}.orc-carousel__indicator--active{width:22px;border-radius:999px;background:var(--orc-color-azul-eletrico, #1c6aed)}.orc-carousel__indicator:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-carousel__empty{padding:32px;text-align:center;color:var(--orc-font-secondary, #666)}@media(max-width:560px){.orc-carousel__slide{align-items:stretch;flex-direction:column}.orc-carousel__image,.orc-carousel__placeholder{width:100%}}\n"] }]
    }], () => [], { onKeydown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CarouselComponent, { className: "CarouselComponent", filePath: "carousel.component.ts", lineNumber: 28 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { CarouselComponent };
//# sourceMappingURL=ciag-orchestra-carousel.mjs.map
