import * as i0 from '@angular/core';
import { input, output, ChangeDetectionStrategy, Component } from '@angular/core';

function TimelineComponent_For_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 5);
} }
function TimelineComponent_For_2_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "time", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r3.date);
} }
function TimelineComponent_For_2_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r3.description);
} }
function TimelineComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li", 3);
    i0.ɵɵlistener("click", function TimelineComponent_For_2_Template_li_click_0_listener() { const ctx_r1 = i0.ɵɵrestoreView(_r1); const item_r3 = ctx_r1.$implicit; const $index_r4 = ctx_r1.$index; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.selectItem(item_r3, $index_r4)); })("keydown", function TimelineComponent_For_2_Template_li_keydown_0_listener($event) { const ctx_r5 = i0.ɵɵrestoreView(_r1); const item_r3 = ctx_r5.$implicit; const $index_r4 = ctx_r5.$index; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onItemKeydown($event, item_r3, $index_r4)); });
    i0.ɵɵelementStart(1, "div", 4);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, TimelineComponent_For_2_Conditional_3_Template, 1, 0, "div", 5);
    i0.ɵɵelementStart(4, "div", 6);
    i0.ɵɵtemplate(5, TimelineComponent_For_2_Conditional_5_Template, 2, 1, "time", 7);
    i0.ɵɵelementStart(6, "h3");
    i0.ɵɵtext(7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(8, TimelineComponent_For_2_Conditional_8_Template, 2, 1, "p");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    const $index_r4 = ctx.$index;
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵclassMap("orc-timeline__item orc-timeline__item--" + (item_r3.status || "pending"));
    i0.ɵɵattribute("aria-label", item_r3.title);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r3.icon || $index_r4 + 1);
    i0.ɵɵadvance();
    i0.ɵɵconditional($index_r4 < ctx_r4.items().length - 1 ? 3 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(item_r3.date ? 5 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r3.title);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r3.description ? 8 : -1);
} }
function TimelineComponent_ForEmpty_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 2);
    i0.ɵɵtext(1, "Nenhum evento registrado.");
    i0.ɵɵelementEnd();
} }
class TimelineComponent {
    items = input([]);
    orientation = input('vertical');
    ariaLabel = input('Timeline');
    itemSelect = output();
    trackItem(index, item) { return item.id ?? index; }
    selectItem(item, index) { this.itemSelect.emit({ item, index }); }
    onItemKeydown(event, item, index) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.selectItem(item, index);
        }
    }
    static ɵfac = function TimelineComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TimelineComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TimelineComponent, selectors: [["orc-timeline"]], inputs: { items: [1, "items"], orientation: [1, "orientation"], ariaLabel: [1, "ariaLabel"] }, outputs: { itemSelect: "itemSelect" }, decls: 4, vars: 4, consts: [[1, "orc-timeline"], ["tabindex", "0", 1, "orc-timeline__item", 3, "class"], [1, "orc-timeline__empty"], ["tabindex", "0", 1, "orc-timeline__item", 3, "click", "keydown"], ["aria-hidden", "true", 1, "orc-timeline__marker"], ["aria-hidden", "true", 1, "orc-timeline__connector"], [1, "orc-timeline__content"], [1, "orc-timeline__date"]], template: function TimelineComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "ol", 0);
            i0.ɵɵrepeaterCreate(1, TimelineComponent_For_2_Template, 9, 8, "li", 1, ctx.trackItem, true, TimelineComponent_ForEmpty_3_Template, 2, 0, "li", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-timeline--horizontal", ctx.orientation() === "horizontal");
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.items());
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-timeline[_ngcontent-%COMP%]{display:grid;gap:0;margin:0;padding:4px 0;list-style:none}.orc-timeline__item[_ngcontent-%COMP%]{position:relative;display:grid;grid-template-columns:28px minmax(0,1fr);column-gap:12px;min-height:76px;cursor:pointer}.orc-timeline__item[_ngcontent-%COMP%]:last-child{min-height:0}.orc-timeline__item[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:3px}.orc-timeline__marker[_ngcontent-%COMP%]{z-index:1;display:grid;place-items:center;width:28px;height:28px;border:2px solid var(--orc-border, #d9d9d9);border-radius:50%;background:var(--fill-modal, #fff);color:var(--orc-font-secondary, #666);font-size:11px;font-weight:700;box-sizing:border-box}.orc-timeline__connector[_ngcontent-%COMP%]{position:absolute;top:28px;bottom:0;left:13px;border-left:2px solid var(--orc-border, #d9d9d9)}.orc-timeline__content[_ngcontent-%COMP%]{padding-bottom:20px}.orc-timeline__date[_ngcontent-%COMP%]{display:block;margin-bottom:3px;color:var(--orc-font-secondary, #666);font-size:11px}.orc-timeline__content[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0 0 4px;color:var(--orc-font-main, #141414);font-size:14px}.orc-timeline__content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;color:var(--orc-font-secondary, #666);font-size:13px;line-height:1.45}.orc-timeline__item--completed[_ngcontent-%COMP%]   .orc-timeline__marker[_ngcontent-%COMP%]{border-color:var(--color-success, #006f4a);background:var(--color-success, #006f4a);color:#fff}.orc-timeline__item--current[_ngcontent-%COMP%]   .orc-timeline__marker[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 4px #1c6aed21}.orc-timeline__item--error[_ngcontent-%COMP%]   .orc-timeline__marker[_ngcontent-%COMP%]{border-color:var(--color-error, #fb2c36);color:var(--color-error, #fb2c36)}.orc-timeline--horizontal[_ngcontent-%COMP%]{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}.orc-timeline--horizontal[_ngcontent-%COMP%]   .orc-timeline__item[_ngcontent-%COMP%]{display:block;min-height:120px;padding-inline:6px}.orc-timeline--horizontal[_ngcontent-%COMP%]   .orc-timeline__connector[_ngcontent-%COMP%]{top:13px;bottom:auto;left:34px;width:calc(100% - 40px);border-top:2px solid var(--orc-border, #d9d9d9);border-left:0}.orc-timeline--horizontal[_ngcontent-%COMP%]   .orc-timeline__content[_ngcontent-%COMP%]{padding-top:10px;padding-bottom:0}.orc-timeline__empty[_ngcontent-%COMP%]{padding:24px;color:var(--orc-font-secondary, #666);text-align:center}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TimelineComponent, [{
        type: Component,
        args: [{ selector: 'orc-timeline', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ol class=\"orc-timeline\" [class.orc-timeline--horizontal]=\"orientation() === 'horizontal'\" [attr.aria-label]=\"ariaLabel()\">\n  @for (item of items(); track trackItem($index, item)) {\n    <li class=\"orc-timeline__item\" [class]=\"'orc-timeline__item orc-timeline__item--' + (item.status || 'pending')\" tabindex=\"0\" [attr.aria-label]=\"item.title\" (click)=\"selectItem(item, $index)\" (keydown)=\"onItemKeydown($event, item, $index)\">\n      <div class=\"orc-timeline__marker\" aria-hidden=\"true\">{{ item.icon || ($index + 1) }}</div>\n      @if ($index < items().length - 1) { <div class=\"orc-timeline__connector\" aria-hidden=\"true\"></div> }\n      <div class=\"orc-timeline__content\">\n        @if (item.date) { <time class=\"orc-timeline__date\">{{ item.date }}</time> }\n        <h3>{{ item.title }}</h3>\n        @if (item.description) { <p>{{ item.description }}</p> }\n      </div>\n    </li>\n  } @empty {\n    <li class=\"orc-timeline__empty\">Nenhum evento registrado.</li>\n  }\n</ol>\n", styles: [":host{display:block;width:100%}.orc-timeline{display:grid;gap:0;margin:0;padding:4px 0;list-style:none}.orc-timeline__item{position:relative;display:grid;grid-template-columns:28px minmax(0,1fr);column-gap:12px;min-height:76px;cursor:pointer}.orc-timeline__item:last-child{min-height:0}.orc-timeline__item:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:3px}.orc-timeline__marker{z-index:1;display:grid;place-items:center;width:28px;height:28px;border:2px solid var(--orc-border, #d9d9d9);border-radius:50%;background:var(--fill-modal, #fff);color:var(--orc-font-secondary, #666);font-size:11px;font-weight:700;box-sizing:border-box}.orc-timeline__connector{position:absolute;top:28px;bottom:0;left:13px;border-left:2px solid var(--orc-border, #d9d9d9)}.orc-timeline__content{padding-bottom:20px}.orc-timeline__date{display:block;margin-bottom:3px;color:var(--orc-font-secondary, #666);font-size:11px}.orc-timeline__content h3{margin:0 0 4px;color:var(--orc-font-main, #141414);font-size:14px}.orc-timeline__content p{margin:0;color:var(--orc-font-secondary, #666);font-size:13px;line-height:1.45}.orc-timeline__item--completed .orc-timeline__marker{border-color:var(--color-success, #006f4a);background:var(--color-success, #006f4a);color:#fff}.orc-timeline__item--current .orc-timeline__marker{border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 4px #1c6aed21}.orc-timeline__item--error .orc-timeline__marker{border-color:var(--color-error, #fb2c36);color:var(--color-error, #fb2c36)}.orc-timeline--horizontal{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}.orc-timeline--horizontal .orc-timeline__item{display:block;min-height:120px;padding-inline:6px}.orc-timeline--horizontal .orc-timeline__connector{top:13px;bottom:auto;left:34px;width:calc(100% - 40px);border-top:2px solid var(--orc-border, #d9d9d9);border-left:0}.orc-timeline--horizontal .orc-timeline__content{padding-top:10px;padding-bottom:0}.orc-timeline__empty{padding:24px;color:var(--orc-font-secondary, #666);text-align:center}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TimelineComponent, { className: "TimelineComponent", filePath: "timeline.component.ts", lineNumber: 11 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { TimelineComponent };
//# sourceMappingURL=ciag-orchestra-timeline.mjs.map
