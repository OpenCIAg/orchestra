import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, ChangeDetectionStrategy, Component } from '@angular/core';

function ChipComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 4);
    i0.ɵɵlistener("click", function ChipComponent_Conditional_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.toggle()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.disabled());
    i0.ɵɵattribute("aria-pressed", ctx_r1.selected());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function ChipComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function ChipComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 5);
    i0.ɵɵlistener("click", function ChipComponent_Conditional_3_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.remove($event)); });
    i0.ɵɵtext(1, "\u00D7");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.disabled());
} }
class ChipComponent {
    label = input('');
    value = input('');
    variant = input('neutral');
    size = input('md');
    selectable = input(false, { transform: booleanAttribute });
    removable = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    selected = model(false);
    removed = output();
    toggle() {
        if (!this.disabled() && this.selectable())
            this.selected.update(value => !value);
    }
    remove(event) {
        event.stopPropagation();
        if (!this.disabled())
            this.removed.emit(this.value() || this.label());
    }
    static ɵfac = function ChipComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ChipComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChipComponent, selectors: [["orc-chip"]], inputs: { label: [1, "label"], value: [1, "value"], variant: [1, "variant"], size: [1, "size"], selectable: [1, "selectable"], removable: [1, "removable"], disabled: [1, "disabled"], selected: [1, "selected"] }, outputs: { selected: "selectedChange", removed: "removed" }, decls: 4, vars: 10, consts: [["role", "option", 1, "orc-chip"], ["type", "button", 1, "orc-chip__main", 3, "disabled"], [1, "orc-chip__main"], ["type", "button", "aria-label", "Remover", 1, "orc-chip__remove", 3, "disabled"], ["type", "button", 1, "orc-chip__main", 3, "click", "disabled"], ["type", "button", "aria-label", "Remover", 1, "orc-chip__remove", 3, "click", "disabled"]], template: function ChipComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ChipComponent_Conditional_1_Template, 2, 3, "button", 1)(2, ChipComponent_Conditional_2_Template, 2, 1, "span", 2)(3, ChipComponent_Conditional_3_Template, 2, 1, "button", 3);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap("orc-chip orc-chip--" + ctx.variant() + " orc-chip--" + ctx.size());
            i0.ɵɵclassProp("orc-chip--selected", ctx.selected())("orc-chip--disabled", ctx.disabled());
            i0.ɵɵattribute("aria-selected", ctx.selectable() ? ctx.selected() : null)("aria-disabled", ctx.disabled() ? "true" : null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.selectable() ? 1 : 2);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.removable() ? 3 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:inline-block}.orc-chip[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:4px;max-width:100%;min-height:30px;padding:0 6px 0 10px;border:1px solid var(--orc-border, #d9d9d9);border-radius:999px;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);box-sizing:border-box;font-family:var(--font-sans, system-ui, sans-serif)}.orc-chip--sm[_ngcontent-%COMP%]{min-height:24px;padding-left:8px;font-size:11px}.orc-chip--md[_ngcontent-%COMP%]{font-size:12px}.orc-chip--lg[_ngcontent-%COMP%]{min-height:36px;padding-left:12px;font-size:14px}.orc-chip--primary[_ngcontent-%COMP%]{border-color:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 30%,var(--orc-border, #d9d9d9));background:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 10%,transparent);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-chip--success[_ngcontent-%COMP%]{background:color-mix(in srgb,var(--color-success, #006f4a) 10%,transparent);color:var(--color-success, #006f4a)}.orc-chip--warning[_ngcontent-%COMP%]{background:color-mix(in srgb,var(--color-warning, #fe9a00) 12%,transparent);color:#8b4c00}.orc-chip--danger[_ngcontent-%COMP%]{background:color-mix(in srgb,var(--color-error, #fb2c36) 10%,transparent);color:var(--color-error, #fb2c36)}.orc-chip--selected[_ngcontent-%COMP%]{box-shadow:0 0 0 2px color-mix(in srgb,currentColor 24%,transparent)}.orc-chip--disabled[_ngcontent-%COMP%]{opacity:.5}.orc-chip__main[_ngcontent-%COMP%]{min-width:0;padding:0;border:0;background:transparent;color:inherit;font:inherit;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}button.orc-chip__main[_ngcontent-%COMP%]{cursor:pointer}button.orc-chip__main[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:2px}button.orc-chip__main[_ngcontent-%COMP%]:disabled{cursor:not-allowed}.orc-chip__remove[_ngcontent-%COMP%]{display:grid;place-items:center;width:22px;height:22px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;font-size:16px;line-height:1;cursor:pointer}.orc-chip__remove[_ngcontent-%COMP%]:hover:not(:disabled){background:color-mix(in srgb,currentColor 12%,transparent)}.orc-chip__remove[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:1px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChipComponent, [{
        type: Component,
        args: [{ selector: 'orc-chip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-chip\" [class]=\"'orc-chip orc-chip--' + variant() + ' orc-chip--' + size()\" [class.orc-chip--selected]=\"selected()\" [class.orc-chip--disabled]=\"disabled()\" role=\"option\" [attr.aria-selected]=\"selectable() ? selected() : null\" [attr.aria-disabled]=\"disabled() ? 'true' : null\">\n  @if (selectable()) {\n    <button type=\"button\" class=\"orc-chip__main\" [disabled]=\"disabled()\" [attr.aria-pressed]=\"selected()\" (click)=\"toggle()\">{{ label() }}</button>\n  } @else {\n    <span class=\"orc-chip__main\">{{ label() }}</span>\n  }\n  @if (removable()) { <button type=\"button\" class=\"orc-chip__remove\" [disabled]=\"disabled()\" (click)=\"remove($event)\" aria-label=\"Remover\">\u00D7</button> }\n</div>\n", styles: [":host{display:inline-block}.orc-chip{display:inline-flex;align-items:center;gap:4px;max-width:100%;min-height:30px;padding:0 6px 0 10px;border:1px solid var(--orc-border, #d9d9d9);border-radius:999px;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);box-sizing:border-box;font-family:var(--font-sans, system-ui, sans-serif)}.orc-chip--sm{min-height:24px;padding-left:8px;font-size:11px}.orc-chip--md{font-size:12px}.orc-chip--lg{min-height:36px;padding-left:12px;font-size:14px}.orc-chip--primary{border-color:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 30%,var(--orc-border, #d9d9d9));background:color-mix(in srgb,var(--orc-color-azul-eletrico, #1c6aed) 10%,transparent);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-chip--success{background:color-mix(in srgb,var(--color-success, #006f4a) 10%,transparent);color:var(--color-success, #006f4a)}.orc-chip--warning{background:color-mix(in srgb,var(--color-warning, #fe9a00) 12%,transparent);color:#8b4c00}.orc-chip--danger{background:color-mix(in srgb,var(--color-error, #fb2c36) 10%,transparent);color:var(--color-error, #fb2c36)}.orc-chip--selected{box-shadow:0 0 0 2px color-mix(in srgb,currentColor 24%,transparent)}.orc-chip--disabled{opacity:.5}.orc-chip__main{min-width:0;padding:0;border:0;background:transparent;color:inherit;font:inherit;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}button.orc-chip__main{cursor:pointer}button.orc-chip__main:focus-visible{outline:2px solid currentColor;outline-offset:2px}button.orc-chip__main:disabled{cursor:not-allowed}.orc-chip__remove{display:grid;place-items:center;width:22px;height:22px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;font-size:16px;line-height:1;cursor:pointer}.orc-chip__remove:hover:not(:disabled){background:color-mix(in srgb,currentColor 12%,transparent)}.orc-chip__remove:focus-visible{outline:2px solid currentColor;outline-offset:1px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ChipComponent, { className: "ChipComponent", filePath: "chip.component.ts", lineNumber: 11 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ChipComponent };
//# sourceMappingURL=ciag-orchestra-chip.mjs.map
