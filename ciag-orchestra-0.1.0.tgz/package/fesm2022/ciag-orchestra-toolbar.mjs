import * as i0 from '@angular/core';
import { input, booleanAttribute, Directive, ChangeDetectionStrategy, Component, HostListener, ContentChildren } from '@angular/core';

const _c0 = ["*"];
class ToolbarItemDirective {
    elementRef;
    disabled = input(false, { transform: booleanAttribute });
    constructor(elementRef) {
        this.elementRef = elementRef;
    }
    static ɵfac = function ToolbarItemDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ToolbarItemDirective)(i0.ɵɵdirectiveInject(i0.ElementRef)); };
    static ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: ToolbarItemDirective, selectors: [["", "orcToolbarItem", ""]], hostVars: 2, hostBindings: function ToolbarItemDirective_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵattribute("tabindex", ctx.disabled() ? -1 : 0)("aria-disabled", ctx.disabled() ? "true" : null);
        } }, inputs: { disabled: [1, "disabled"] } });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ToolbarItemDirective, [{
        type: Directive,
        args: [{
                selector: '[orcToolbarItem]',
                standalone: true,
                host: {
                    '[attr.tabindex]': 'disabled() ? -1 : 0',
                    '[attr.aria-disabled]': 'disabled() ? "true" : null',
                },
            }]
    }], () => [{ type: i0.ElementRef }], null); })();
class ToolbarComponent {
    items;
    orientation = input('horizontal');
    label = input('Toolbar');
    loop = input(true, { transform: booleanAttribute });
    onKeydown(event) {
        const forward = this.orientation() === 'horizontal' ? event.key === 'ArrowRight' : event.key === 'ArrowDown';
        const backward = this.orientation() === 'horizontal' ? event.key === 'ArrowLeft' : event.key === 'ArrowUp';
        if (!forward && !backward && event.key !== 'Home' && event.key !== 'End')
            return;
        const items = this.items?.toArray().filter(item => !item.disabled()) ?? [];
        if (!items.length)
            return;
        const active = document.activeElement;
        let index = items.findIndex(item => item.elementRef.nativeElement === active);
        if (event.key === 'Home')
            index = 0;
        else if (event.key === 'End')
            index = items.length - 1;
        else {
            if (index < 0)
                index = forward ? -1 : items.length;
            const next = index + (forward ? 1 : -1);
            if (next >= 0 && next < items.length)
                index = next;
            else if (this.loop())
                index = (next + items.length) % items.length;
            else
                return;
        }
        event.preventDefault();
        items[index].elementRef.nativeElement.focus();
    }
    handleKeydown(event) { this.onKeydown(event); }
    static ɵfac = function ToolbarComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ToolbarComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ToolbarComponent, selectors: [["orc-toolbar"]], contentQueries: function ToolbarComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuery(dirIndex, ToolbarItemDirective, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.items = _t);
        } }, hostBindings: function ToolbarComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown", function ToolbarComponent_keydown_HostBindingHandler($event) { return ctx.handleKeydown($event); });
        } }, inputs: { orientation: [1, "orientation"], label: [1, "label"], loop: [1, "loop"] }, ngContentSelectors: _c0, decls: 2, vars: 4, consts: [["role", "toolbar", 1, "orc-toolbar"]], template: function ToolbarComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-toolbar--vertical", ctx.orientation() === "vertical");
            i0.ɵɵattribute("aria-label", ctx.label())("aria-orientation", ctx.orientation());
        } }, styles: ["[_nghost-%COMP%]{display:block}.orc-toolbar[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;width:fit-content;max-width:100%;padding:4px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--orc-th, #f7f8fa)}.orc-toolbar--vertical[_ngcontent-%COMP%]{flex-direction:column;align-items:stretch}.orc-toolbar[_ngcontent-%COMP%]     [orcToolbarItem]{min-height:34px;padding:6px 10px;border:0;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-font-main, #141414);font:inherit;cursor:pointer}.orc-toolbar[_ngcontent-%COMP%]     [orcToolbarItem]:hover{background:var(--fill-modal, #fff)}.orc-toolbar[_ngcontent-%COMP%]     [orcToolbarItem]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:1px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ToolbarComponent, [{
        type: Component,
        args: [{ selector: 'orc-toolbar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-toolbar\" [class.orc-toolbar--vertical]=\"orientation() === 'vertical'\" role=\"toolbar\" [attr.aria-label]=\"label()\" [attr.aria-orientation]=\"orientation()\"><ng-content /></div>\n", styles: [":host{display:block}.orc-toolbar{display:flex;align-items:center;gap:6px;width:fit-content;max-width:100%;padding:4px;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--orc-th, #f7f8fa)}.orc-toolbar--vertical{flex-direction:column;align-items:stretch}.orc-toolbar ::ng-deep [orcToolbarItem]{min-height:34px;padding:6px 10px;border:0;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-font-main, #141414);font:inherit;cursor:pointer}.orc-toolbar ::ng-deep [orcToolbarItem]:hover{background:var(--fill-modal, #fff)}.orc-toolbar ::ng-deep [orcToolbarItem]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:1px}\n"] }]
    }], null, { items: [{
            type: ContentChildren,
            args: [ToolbarItemDirective, { descendants: true }]
        }], handleKeydown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ToolbarComponent, { className: "ToolbarComponent", filePath: "toolbar.component.ts", lineNumber: 25 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ToolbarComponent, ToolbarItemDirective };
//# sourceMappingURL=ciag-orchestra-toolbar.mjs.map
