import * as i0 from '@angular/core';
import { input, output, signal, ChangeDetectionStrategy, Component, inject, model, viewChild, computed } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

const _c0$1 = ["*"];
class AccordionComponent {
    // Inputs (Signals API)
    multiple = input(false);
    variant = input('default');
    // Outputs (Signals API)
    expandedChange = output();
    // Lista de itens registrados no accordion
    items = signal([]);
    // ── Registro e Gerenciamento de Itens ──────────────────────
    registerItem(item) {
        this.items.update(list => [...list, item]);
    }
    unregisterItem(item) {
        this.items.update(list => list.filter(i => i !== item));
    }
    onItemToggle(targetItem, isExpanded) {
        if (!this.multiple() && isExpanded) {
            // Fecha todos os outros itens quando multiple for false
            for (const item of this.items()) {
                if (item !== targetItem && item.expanded()) {
                    item.expanded.set(false);
                    item.closed.emit();
                    item.toggle.emit(false);
                }
            }
        }
        this.expandedChange.emit({
            id: targetItem.itemId(),
            expanded: isExpanded,
        });
    }
    // ── Navegação por Teclado (WAI-ARIA Accordion Pattern) ─────
    handleKeyNavigation(event, currentItem) {
        const enabledItems = this.items().filter(item => !item.disabled());
        const currentIndex = enabledItems.indexOf(currentItem);
        if (currentIndex === -1)
            return;
        let targetItem;
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                targetItem = enabledItems[(currentIndex + 1) % enabledItems.length];
                break;
            case 'ArrowUp':
                event.preventDefault();
                targetItem =
                    enabledItems[(currentIndex - 1 + enabledItems.length) % enabledItems.length];
                break;
            case 'Home':
                event.preventDefault();
                targetItem = enabledItems[0];
                break;
            case 'End':
                event.preventDefault();
                targetItem = enabledItems[enabledItems.length - 1];
                break;
        }
        if (targetItem) {
            targetItem.focusHeader();
        }
    }
    static ɵfac = function AccordionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccordionComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccordionComponent, selectors: [["orc-accordion"]], inputs: { multiple: [1, "multiple"], variant: [1, "variant"] }, outputs: { expandedChange: "expandedChange" }, ngContentSelectors: _c0$1, decls: 2, vars: 4, consts: [["role", "presentation", 1, "orc-accordion"]], template: function AccordionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-accordion--separated", ctx.variant() === "separated")("orc-accordion--bordered", ctx.variant() === "bordered");
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-accordion[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;box-sizing:border-box}.orc-accordion--separated[_ngcontent-%COMP%]{gap:var(--space-3, .75rem)}.orc-accordion--bordered[_ngcontent-%COMP%]{border:1px solid var(--border-default, #e5e5e5);border-radius:var(--radius-lg, 12px);overflow:hidden}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccordionComponent, [{
        type: Component,
        args: [{ selector: 'orc-accordion', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-accordion\"\n  [class.orc-accordion--separated]=\"variant() === 'separated'\"\n  [class.orc-accordion--bordered]=\"variant() === 'bordered'\"\n  role=\"presentation\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion{display:flex;flex-direction:column;width:100%;box-sizing:border-box}.orc-accordion--separated{gap:var(--space-3, .75rem)}.orc-accordion--bordered{border:1px solid var(--border-default, #e5e5e5);border-radius:var(--radius-lg, 12px);overflow:hidden}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AccordionComponent, { className: "AccordionComponent", filePath: "accordion.component.ts", lineNumber: 20 }); })();

const _c0 = ["headerBtn"];
const _c1 = [[["", "accordion-header", ""], ["", "accordionHeader", ""]], "*"];
const _c2 = ["[accordion-header], [accordionHeader]", "*"];
function AccordionItemComponent_div_5_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.subtitle());
} }
function AccordionItemComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9)(1, "span", 10);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, AccordionItemComponent_div_5_span_3_Template, 2, 1, "span", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.title());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.subtitle());
} }
function AccordionItemComponent_span_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 14);
    i0.ɵɵelement(2, "polyline", 15);
    i0.ɵɵelementEnd()();
} }
let uniqueIdCounter = 0;
class AccordionItemComponent {
    accordion = inject(AccordionComponent, { optional: true });
    // Inputs (Signals API)
    id = input('');
    title = input('');
    subtitle = input('');
    icon = input('');
    disabled = input(false);
    hideToggle = input(false);
    // Model (Two-way binding Signals API)
    expanded = model(false);
    // Outputs (Signals API)
    opened = output();
    closed = output();
    toggle = output();
    // Referência do botão de cabeçalho para foco programático
    headerButton = viewChild('headerBtn');
    // ID interno garantido
    fallbackId = `orc-accordion-item-${++uniqueIdCounter}`;
    itemId = computed(() => this.id() || this.fallbackId);
    headerId = computed(() => `orc-accordion-header-${this.itemId()}`);
    panelId = computed(() => `orc-accordion-panel-${this.itemId()}`);
    ngOnInit() {
        if (this.accordion) {
            this.accordion.registerItem(this);
        }
    }
    ngOnDestroy() {
        if (this.accordion) {
            this.accordion.unregisterItem(this);
        }
    }
    // ── Métodos de Controle ───────────────────────────────────
    toggleExpanded() {
        if (this.disabled())
            return;
        const nextState = !this.expanded();
        this.expanded.set(nextState);
        if (nextState) {
            this.opened.emit();
        }
        else {
            this.closed.emit();
        }
        this.toggle.emit(nextState);
        if (this.accordion) {
            this.accordion.onItemToggle(this, nextState);
        }
    }
    focusHeader() {
        this.headerButton()?.nativeElement.focus();
    }
    onKeyDown(event) {
        if (this.accordion) {
            this.accordion.handleKeyNavigation(event, this);
        }
    }
    static ɵfac = function AccordionItemComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AccordionItemComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccordionItemComponent, selectors: [["orc-accordion-item"]], viewQuery: function AccordionItemComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.headerButton, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], title: [1, "title"], subtitle: [1, "subtitle"], icon: [1, "icon"], disabled: [1, "disabled"], hideToggle: [1, "hideToggle"], expanded: [1, "expanded"] }, outputs: { expanded: "expandedChange", opened: "opened", closed: "closed", toggle: "toggle" }, ngContentSelectors: _c2, decls: 11, vars: 14, consts: [["headerBtn", ""], [1, "orc-accordion-item"], ["type", "button", 1, "orc-accordion-item__header", 3, "click", "keydown", "disabled"], [1, "orc-accordion-item__header-content"], ["class", "orc-accordion-item__title-group", 4, "ngIf"], ["class", "orc-accordion-item__chevron", "aria-hidden", "true", 4, "ngIf"], ["role", "region", 1, "orc-accordion-item__collapse"], [1, "orc-accordion-item__content"], [1, "orc-accordion-item__body"], [1, "orc-accordion-item__title-group"], [1, "orc-accordion-item__title"], ["class", "orc-accordion-item__subtitle", 4, "ngIf"], [1, "orc-accordion-item__subtitle"], ["aria-hidden", "true", 1, "orc-accordion-item__chevron"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"]], template: function AccordionItemComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "div", 1)(1, "button", 2, 0);
            i0.ɵɵlistener("click", function AccordionItemComponent_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.toggleExpanded()); })("keydown", function AccordionItemComponent_Template_button_keydown_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeyDown($event)); });
            i0.ɵɵelementStart(3, "div", 3);
            i0.ɵɵprojection(4);
            i0.ɵɵtemplate(5, AccordionItemComponent_div_5_Template, 4, 2, "div", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, AccordionItemComponent_span_6_Template, 3, 0, "span", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 6)(8, "div", 7)(9, "div", 8);
            i0.ɵɵprojection(10, 1);
            i0.ɵɵelementEnd()()()();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-accordion-item--expanded", ctx.expanded())("orc-accordion-item--disabled", ctx.disabled());
            i0.ɵɵadvance();
            i0.ɵɵproperty("disabled", ctx.disabled());
            i0.ɵɵattribute("id", ctx.headerId())("aria-expanded", ctx.expanded())("aria-controls", ctx.panelId());
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.title());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.hideToggle());
            i0.ɵɵadvance();
            i0.ɵɵclassProp("orc-accordion-item__collapse--expanded", ctx.expanded());
            i0.ɵɵattribute("id", ctx.panelId())("aria-labelledby", ctx.headerId());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-accordion-item[_ngcontent-%COMP%]{width:100%;border-bottom:1px solid var(--border-default, #e5e5e5);font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease)}.orc-accordion-item[_ngcontent-%COMP%]:last-child{border-bottom:none}.orc-accordion-item__header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;width:100%;padding:15px 10px;background:transparent;border:none;cursor:pointer;text-align:left;gap:var(--space-4, 1rem);-webkit-user-select:none;user-select:none;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 6px)}.orc-accordion-item__header[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-subtle, rgba(0, 0, 0, .02))}.orc-accordion-item__header[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-accordion-item__header-content[_ngcontent-%COMP%]{flex:1;min-width:0}.orc-accordion-item__title-group[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2px}.orc-accordion-item__title[_ngcontent-%COMP%]{font-size:.875rem;font-weight:500;line-height:1.428;color:var(--orc-font-main, var(--text-primary, #141414))}.orc-accordion-item__subtitle[_ngcontent-%COMP%]{font-size:.75rem;font-weight:400;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item__chevron[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;flex-shrink:0;color:var(--orc-font-main, var(--text-primary, #141414));transition:transform var(--transition-normal, .2s cubic-bezier(.4, 0, .2, 1))}.orc-accordion-item__chevron[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:16px;height:16px;stroke-width:2.2}.orc-accordion-item--expanded[_ngcontent-%COMP%]   .orc-accordion-item__chevron[_ngcontent-%COMP%]{transform:rotate(180deg)}.orc-accordion-item__collapse[_ngcontent-%COMP%]{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.orc-accordion-item__collapse--expanded[_ngcontent-%COMP%]{grid-template-rows:1fr}.orc-accordion-item__content[_ngcontent-%COMP%]{overflow:hidden}.orc-accordion-item__body[_ngcontent-%COMP%]{padding:0 10px 15px;font-size:.875rem;font-weight:400;line-height:1.5;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item--disabled[_ngcontent-%COMP%]{opacity:.45;pointer-events:none}.orc-accordion-item--disabled[_ngcontent-%COMP%]   .orc-accordion-item__header[_ngcontent-%COMP%]{cursor:not-allowed}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccordionItemComponent, [{
        type: Component,
        args: [{ selector: 'orc-accordion-item', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-accordion-item\"\n  [class.orc-accordion-item--expanded]=\"expanded()\"\n  [class.orc-accordion-item--disabled]=\"disabled()\"\n>\n  <!-- Cabe\u00E7alho (WAI-ARIA Button) -->\n  <button\n    #headerBtn\n    type=\"button\"\n    class=\"orc-accordion-item__header\"\n    [attr.id]=\"headerId()\"\n    [attr.aria-expanded]=\"expanded()\"\n    [attr.aria-controls]=\"panelId()\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleExpanded()\"\n    (keydown)=\"onKeyDown($event)\"\n  >\n    <!-- Custom Header Projection or Default Title -->\n    <div class=\"orc-accordion-item__header-content\">\n      <ng-content select=\"[accordion-header], [accordionHeader]\"></ng-content>\n\n      <div class=\"orc-accordion-item__title-group\" *ngIf=\"title()\">\n        <span class=\"orc-accordion-item__title\">{{ title() }}</span>\n        <span *ngIf=\"subtitle()\" class=\"orc-accordion-item__subtitle\">{{ subtitle() }}</span>\n      </div>\n    </div>\n\n    <!-- Chevron Indicator (Figma Node 26:16952 & 26:17019) -->\n    <span *ngIf=\"!hideToggle()\" class=\"orc-accordion-item__chevron\" aria-hidden=\"true\">\n      <svg\n        viewBox=\"0 0 24 24\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      >\n        <polyline points=\"6 9 12 15 18 9\"></polyline>\n      </svg>\n    </span>\n  </button>\n\n  <!-- Painel de Conte\u00FAdo com Anima\u00E7\u00E3o Fluida (WAI-ARIA Region) -->\n  <div\n    class=\"orc-accordion-item__collapse\"\n    [class.orc-accordion-item__collapse--expanded]=\"expanded()\"\n    [attr.id]=\"panelId()\"\n    role=\"region\"\n    [attr.aria-labelledby]=\"headerId()\"\n  >\n    <div class=\"orc-accordion-item__content\">\n      <div class=\"orc-accordion-item__body\">\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion-item{width:100%;border-bottom:1px solid var(--border-default, #e5e5e5);font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease)}.orc-accordion-item:last-child{border-bottom:none}.orc-accordion-item__header{display:flex;align-items:center;justify-content:space-between;width:100%;padding:15px 10px;background:transparent;border:none;cursor:pointer;text-align:left;gap:var(--space-4, 1rem);-webkit-user-select:none;user-select:none;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 6px)}.orc-accordion-item__header:hover:not(:disabled){background-color:var(--bg-subtle, rgba(0, 0, 0, .02))}.orc-accordion-item__header:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-accordion-item__header-content{flex:1;min-width:0}.orc-accordion-item__title-group{display:flex;flex-direction:column;gap:2px}.orc-accordion-item__title{font-size:.875rem;font-weight:500;line-height:1.428;color:var(--orc-font-main, var(--text-primary, #141414))}.orc-accordion-item__subtitle{font-size:.75rem;font-weight:400;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item__chevron{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;flex-shrink:0;color:var(--orc-font-main, var(--text-primary, #141414));transition:transform var(--transition-normal, .2s cubic-bezier(.4, 0, .2, 1))}.orc-accordion-item__chevron svg{width:16px;height:16px;stroke-width:2.2}.orc-accordion-item--expanded .orc-accordion-item__chevron{transform:rotate(180deg)}.orc-accordion-item__collapse{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.orc-accordion-item__collapse--expanded{grid-template-rows:1fr}.orc-accordion-item__content{overflow:hidden}.orc-accordion-item__body{padding:0 10px 15px;font-size:.875rem;font-weight:400;line-height:1.5;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item--disabled{opacity:.45;pointer-events:none}.orc-accordion-item--disabled .orc-accordion-item__header{cursor:not-allowed}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AccordionItemComponent, { className: "AccordionItemComponent", filePath: "accordion-item.component.ts", lineNumber: 27 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionComponent, AccordionItemComponent };
//# sourceMappingURL=ciag-orchestra-accordion.mjs.map
