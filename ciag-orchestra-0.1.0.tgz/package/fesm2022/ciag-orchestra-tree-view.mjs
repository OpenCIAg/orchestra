import * as i0 from '@angular/core';
import { input, output, signal, computed, ChangeDetectionStrategy, Component } from '@angular/core';

const _forTrack0 = ($index, $item) => $item.node.id;
function TreeViewComponent_For_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 5);
    i0.ɵɵlistener("click", function TreeViewComponent_For_2_Conditional_1_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r4); const item_r2 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); ctx_r2.toggle(item_r2.node); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-label", ctx_r2.expanded().has(item_r2.node.id) ? "Recolher" : "Expandir");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.expanded().has(item_r2.node.id) ? "\u2212" : "+");
} }
function TreeViewComponent_For_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 4);
} }
function TreeViewComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵlistener("keydown", function TreeViewComponent_For_2_Template_div_keydown_0_listener($event) { const item_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.keydown($event, item_r2)); })("click", function TreeViewComponent_For_2_Template_div_click_0_listener() { const item_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.activate(item_r2.node)); });
    i0.ɵɵtemplate(1, TreeViewComponent_For_2_Conditional_1_Template, 2, 2, "button", 3)(2, TreeViewComponent_For_2_Conditional_2_Template, 1, 0, "span", 4);
    i0.ɵɵelementStart(3, "span");
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("--orc-tree-level", item_r2.level);
    i0.ɵɵattribute("aria-level", item_r2.level)("aria-expanded", item_r2.expandable ? ctx_r2.expanded().has(item_r2.node.id) : null)("aria-disabled", item_r2.node.disabled || null);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.expandable ? 1 : 2);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(item_r2.node.label);
} }
class TreeViewComponent {
    nodes = input([]);
    label = input('Árvore');
    nodeSelect = output();
    expanded = signal(new Set());
    visibleNodes = computed(() => { const result = []; const visit = (nodes, level) => nodes.forEach(node => { const expandable = !!node.children?.length; result.push({ node, level, expandable }); if (expandable && this.expanded().has(node.id))
        visit(node.children, level + 1); }); visit(this.nodes(), 1); return result; });
    toggle(node) { if (!node.children?.length)
        return; this.expanded.update(current => { const next = new Set(current); next.has(node.id) ? next.delete(node.id) : next.add(node.id); return next; }); }
    activate(node) { if (!node.disabled)
        this.nodeSelect.emit(node); }
    keydown(event, item) { if (event.key === 'ArrowRight' && item.expandable && !this.expanded().has(item.node.id)) {
        this.toggle(item.node);
        event.preventDefault();
    }
    else if (event.key === 'ArrowLeft' && this.expanded().has(item.node.id)) {
        this.toggle(item.node);
        event.preventDefault();
    }
    else if (event.key === 'Enter' || event.key === ' ') {
        this.activate(item.node);
        event.preventDefault();
    } }
    static ɵfac = function TreeViewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TreeViewComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TreeViewComponent, selectors: [["orc-tree-view"]], inputs: { nodes: [1, "nodes"], label: [1, "label"] }, outputs: { nodeSelect: "nodeSelect" }, decls: 3, vars: 1, consts: [["role", "tree", 1, "orc-tree"], ["role", "treeitem", "tabindex", "0", 1, "orc-tree__item", 3, "--orc-tree-level"], ["role", "treeitem", "tabindex", "0", 1, "orc-tree__item", 3, "keydown", "click"], ["type", "button", 1, "orc-tree__toggle"], [1, "orc-tree__spacer"], ["type", "button", 1, "orc-tree__toggle", 3, "click"]], template: function TreeViewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵrepeaterCreate(1, TreeViewComponent_For_2_Template, 5, 7, "div", 1, _forTrack0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.label());
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.visibleNodes());
        } }, styles: [".orc-tree[_ngcontent-%COMP%]{display:grid;padding:var(--space-2);background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-tree__item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);min-height:2.25rem;padding-inline-start:calc((var(--orc-tree-level) - 1) * var(--space-5));padding-inline-end:var(--space-2);border-radius:var(--radius-sm);cursor:pointer}.orc-tree__item[_ngcontent-%COMP%]:hover{background:var(--bg-muted)}.orc-tree__item[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-tree__item[aria-disabled=true][_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed}.orc-tree__toggle[_ngcontent-%COMP%]{width:1.5rem;height:1.5rem;border:0;border-radius:var(--radius-sm);background:var(--bg-muted);color:var(--text-primary);cursor:pointer}.orc-tree__spacer[_ngcontent-%COMP%]{width:1.5rem}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TreeViewComponent, [{
        type: Component,
        args: [{ selector: 'orc-tree-view', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-tree\" role=\"tree\" [attr.aria-label]=\"label()\">@for(item of visibleNodes();track item.node.id){<div class=\"orc-tree__item\" role=\"treeitem\" tabindex=\"0\" [style.--orc-tree-level]=\"item.level\" [attr.aria-level]=\"item.level\" [attr.aria-expanded]=\"item.expandable ? expanded().has(item.node.id) : null\" [attr.aria-disabled]=\"item.node.disabled || null\" (keydown)=\"keydown($event,item)\" (click)=\"activate(item.node)\">@if(item.expandable){<button type=\"button\" class=\"orc-tree__toggle\" (click)=\"toggle(item.node);$event.stopPropagation()\" [attr.aria-label]=\"expanded().has(item.node.id) ? 'Recolher' : 'Expandir'\">{{expanded().has(item.node.id)?'\u2212':'+'}}</button>}@else{<span class=\"orc-tree__spacer\"></span>}<span>{{item.node.label}}</span></div>}</div>\n", styles: [".orc-tree{display:grid;padding:var(--space-2);background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-tree__item{display:flex;align-items:center;gap:var(--space-2);min-height:2.25rem;padding-inline-start:calc((var(--orc-tree-level) - 1) * var(--space-5));padding-inline-end:var(--space-2);border-radius:var(--radius-sm);cursor:pointer}.orc-tree__item:hover{background:var(--bg-muted)}.orc-tree__item:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-tree__item[aria-disabled=true]{opacity:.5;cursor:not-allowed}.orc-tree__toggle{width:1.5rem;height:1.5rem;border:0;border-radius:var(--radius-sm);background:var(--bg-muted);color:var(--text-primary);cursor:pointer}.orc-tree__spacer{width:1.5rem}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TreeViewComponent, { className: "TreeViewComponent", filePath: "tree-view.component.ts", lineNumber: 5 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { TreeViewComponent };
//# sourceMappingURL=ciag-orchestra-tree-view.mjs.map
