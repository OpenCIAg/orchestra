import * as i0 from '@angular/core';
import { input, output, signal, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

const _c0 = [[["", "alert-title", ""], ["", "alertTitle", ""]], "*", [["", "alert-actions", ""], ["", "alertActions", ""]], [["", "alert-icon", ""], ["", "alertIcon", ""]]];
const _c1 = ["[alert-title], [alertTitle]", "*", "[alert-actions], [alertActions]", "[alert-icon], [alertIcon]"];
function AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "path", 9)(2, "path", 10)(3, "path", 11);
    i0.ɵɵelementEnd();
} }
function AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "path", 9)(2, "path", 12);
    i0.ɵɵelementEnd();
} }
function AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "path", 13)(2, "path", 14)(3, "path", 15);
    i0.ɵɵelementEnd();
} }
function AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "path", 9)(2, "path", 16);
    i0.ɵɵelementEnd();
} }
function AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_0_Template, 4, 0, ":svg:svg", 8)(1, AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_1_Template, 3, 0, ":svg:svg", 8)(2, AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_2_Template, 4, 0, ":svg:svg", 8)(3, AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Case_3_Template, 3, 0, ":svg:svg", 8);
} if (rf & 2) {
    let tmp_3_0;
    const ctx_r0 = i0.ɵɵnextContext(3);
    i0.ɵɵconditional((tmp_3_0 = ctx_r0.activeSeverity()) === "info" ? 0 : tmp_3_0 === "success" ? 1 : tmp_3_0 === "warning" ? 2 : tmp_3_0 === "error" ? 3 : -1);
} }
function AlertComponent_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵprojection(1, 3, null, AlertComponent_Conditional_0_Conditional_1_ProjectionFallback_1_Template, 4, 1);
    i0.ɵɵelementEnd();
} }
function AlertComponent_Conditional_0_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.title());
} }
function AlertComponent_Conditional_0_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.message());
} }
function AlertComponent_Conditional_0_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 17);
    i0.ɵɵlistener("click", function AlertComponent_Conditional_0_Conditional_9_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r0.handleDismiss($event)); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 18);
    i0.ɵɵelement(2, "path", 19);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext(2);
    i0.ɵɵattribute("aria-label", ctx_r0.closeAriaLabel());
} }
function AlertComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵtemplate(1, AlertComponent_Conditional_0_Conditional_1_Template, 3, 0, "div", 2);
    i0.ɵɵelementStart(2, "div", 3);
    i0.ɵɵtemplate(3, AlertComponent_Conditional_0_Conditional_3_Template, 2, 1, "p", 4);
    i0.ɵɵprojection(4);
    i0.ɵɵtemplate(5, AlertComponent_Conditional_0_Conditional_5_Template, 2, 1, "p", 5);
    i0.ɵɵprojection(6, 1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "div", 6);
    i0.ɵɵprojection(8, 2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, AlertComponent_Conditional_0_Conditional_9_Template, 3, 1, "button", 7);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-alert--severity-info", ctx_r0.activeSeverity() === "info")("orc-alert--severity-success", ctx_r0.activeSeverity() === "success")("orc-alert--severity-warning", ctx_r0.activeSeverity() === "warning")("orc-alert--severity-error", ctx_r0.activeSeverity() === "error")("orc-alert--variant-subtle", ctx_r0.activeVariant() === "subtle")("orc-alert--variant-filled", ctx_r0.activeVariant() === "filled")("orc-alert--variant-outline", ctx_r0.activeVariant() === "outline");
    i0.ɵɵattribute("role", ctx_r0.computedRole())("aria-live", ctx_r0.computedAriaLive())("aria-label", ctx_r0.ariaLabel() || undefined);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r0.showIcon() ? 1 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.title() ? 3 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r0.message() ? 5 : -1);
    i0.ɵɵadvance(4);
    i0.ɵɵconditional(ctx_r0.dismissible() ? 9 : -1);
} }
class AlertComponent {
    // ── Inputs (Signals API) ──────────────────────────────────────────
    /** Status / Severidade do alerta */
    severity = input('info');
    /** Alias para severity */
    status = input(undefined);
    /** Variante visual: soft/subtle (fundo claro), filled (sólido) ou outline (apenas borda) */
    variant = input('subtle');
    /** Título principal do alerta (opcional) */
    title = input('');
    /** Texto descritivo (opcional se fornecido via ng-content) */
    message = input('');
    /** Controla se o ícone do alerta deve ser exibido */
    showIcon = input(true);
    /** Define se o alerta pode ser dispensado pelo usuário exibindo o botão 'X' */
    dismissible = input(false);
    /** Sobrescreve o atributo role WCAG (padrão: 'alert' para error/warning e 'status' para info/success) */
    role = input(undefined);
    /** Rótulo acessível opcional para leitores de tela */
    ariaLabel = input('');
    /** Rótulo acessível do botão de fechar */
    closeAriaLabel = input('Fechar alerta');
    // ── Outputs (Signals API) ─────────────────────────────────────────
    /** Emitido quando o usuário clica no botão de fechar */
    onClose = output();
    /** Alias do evento de fechamento */
    closed = output();
    // ── Estado Interno Reativo ────────────────────────────────────────
    isVisible = signal(true);
    // ── Sinais Computados ─────────────────────────────────────────────
    /** Normaliza o tipo de severidade ativo */
    activeSeverity = computed(() => {
        return this.status() || this.severity();
    });
    /** Normaliza a variante */
    activeVariant = computed(() => {
        const v = this.variant();
        if (v === 'soft')
            return 'subtle';
        if (v === 'solid')
            return 'filled';
        return v;
    });
    /** Computa o atributo role WCAG ideal conforme o tipo de severidade */
    computedRole = computed(() => {
        if (this.role())
            return this.role();
        return this.activeSeverity() === 'error' || this.activeSeverity() === 'warning'
            ? 'alert'
            : 'status';
    });
    /** Computa aria-live: 'assertive' para erros críticos e 'polite' para informativos */
    computedAriaLive = computed(() => {
        return this.activeSeverity() === 'error' ? 'assertive' : 'polite';
    });
    // ── Handlers de Interação ────────────────────────────────────────
    handleDismiss(event) {
        event.stopPropagation();
        this.isVisible.set(false);
        this.onClose.emit(event);
        this.closed.emit();
    }
    static ɵfac = function AlertComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AlertComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AlertComponent, selectors: [["orc-alert"]], hostAttrs: [1, "orc-alert-host"], hostVars: 2, hostBindings: function AlertComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵclassProp("orc-alert-host--hidden", !ctx.isVisible());
        } }, inputs: { severity: [1, "severity"], status: [1, "status"], variant: [1, "variant"], title: [1, "title"], message: [1, "message"], showIcon: [1, "showIcon"], dismissible: [1, "dismissible"], role: [1, "role"], ariaLabel: [1, "ariaLabel"], closeAriaLabel: [1, "closeAriaLabel"] }, outputs: { onClose: "onClose", closed: "closed" }, ngContentSelectors: _c1, decls: 1, vars: 1, consts: [[1, "orc-alert", 3, "orc-alert--severity-info", "orc-alert--severity-success", "orc-alert--severity-warning", "orc-alert--severity-error", "orc-alert--variant-subtle", "orc-alert--variant-filled", "orc-alert--variant-outline"], [1, "orc-alert"], ["aria-hidden", "true", 1, "orc-alert__icon-container"], [1, "orc-alert__content"], [1, "orc-alert__title"], [1, "orc-alert__description"], [1, "orc-alert__actions"], ["type", "button", 1, "orc-alert__close"], ["viewBox", "0 0 16 16", "fill", "none", 1, "orc-alert__icon"], ["d", "M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334Z", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 10.667V8", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 5.333h.007", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "m5.333 8 2 2 3.334-3.333", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 1.333 1.333 13.333h13.334L8 1.333Z", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 6v3.333", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8 11.333h.007", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "m10 6-4 4M6 6l4 4", "stroke", "currentColor", "stroke-width", "1.333", "stroke-linecap", "round", "stroke-linejoin", "round"], ["type", "button", 1, "orc-alert__close", 3, "click"], ["viewBox", "0 0 16 16", "fill", "none", "aria-hidden", "true", 1, "orc-alert__close-icon"], ["d", "M12 4L4 12M4 4l8 8", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"]], template: function AlertComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0);
            i0.ɵɵtemplate(0, AlertComponent_Conditional_0_Template, 10, 21, "div", 0);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.isVisible() ? 0 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%;transition:opacity var(--transition-base, .2s ease),max-height var(--transition-base, .2s ease),transform var(--transition-base, .2s ease)}.orc-alert-host--hidden[_nghost-%COMP%]{opacity:0;pointer-events:none;max-height:0;overflow:hidden;margin:0;padding:0}.orc-alert[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:flex-start;position:relative;width:100%;min-height:68px;padding:13px 17px;border-radius:var(--radius-md, 10px);font-family:var(--font-sans, \"Poppins\", sans-serif);gap:12px;box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-alert__icon-container[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:16px;height:16px;margin-top:0}.orc-alert__icon[_ngcontent-%COMP%]{width:16px;height:16px;display:block}.orc-alert__content[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;gap:2px;font-size:14px;line-height:20px;word-break:break-word}.orc-alert__title[_ngcontent-%COMP%]{font-weight:500;letter-spacing:-.35px;margin:0;padding:0}.orc-alert__description[_ngcontent-%COMP%]{font-weight:400;margin:0;padding:0;opacity:.95}.orc-alert__actions[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:8px;flex-shrink:0;margin-left:auto}.orc-alert__close[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:currentColor;opacity:.7;cursor:pointer;transition:opacity var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease)}.orc-alert__close[_ngcontent-%COMP%]:hover{opacity:1;background-color:#00000014}.orc-alert__close[_ngcontent-%COMP%]:focus-visible{outline:2px solid currentColor;outline-offset:2px;opacity:1}.orc-alert__close-icon[_ngcontent-%COMP%]{width:14px;height:14px}.orc-alert--variant-subtle[_ngcontent-%COMP%]{border:1px solid transparent}.orc-alert--variant-subtle.orc-alert--severity-info[_ngcontent-%COMP%]{background-color:var(--status-info-soft-bg, #E1EAF6);color:var(--status-info-soft-fg, #2B7FFF)}.orc-alert--variant-subtle.orc-alert--severity-success[_ngcontent-%COMP%]{background-color:var(--status-success-soft-bg, #B8E7D7);color:var(--status-success-soft-fg, #006F4A)}.orc-alert--variant-subtle.orc-alert--severity-warning[_ngcontent-%COMP%]{background-color:var(--status-warning-soft-bg, #F6ECDD);color:var(--status-warning-soft-fg, #FE9A00)}.orc-alert--variant-subtle.orc-alert--severity-error[_ngcontent-%COMP%]{background-color:var(--status-danger-soft-bg, #F6D7D8);color:var(--status-danger-soft-fg, #FB2C36)}.orc-alert--variant-outline[_ngcontent-%COMP%]{background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--border-default, #D9D9D9)}.orc-alert--variant-outline.orc-alert--severity-info[_ngcontent-%COMP%]{color:var(--color-info, #2B7FFF)}.orc-alert--variant-outline.orc-alert--severity-success[_ngcontent-%COMP%]{color:var(--color-success, #006F4A)}.orc-alert--variant-outline.orc-alert--severity-warning[_ngcontent-%COMP%]{color:var(--color-warning, #FE9A00)}.orc-alert--variant-outline.orc-alert--severity-error[_ngcontent-%COMP%]{color:var(--color-error, #FB2C36)}.orc-alert--variant-filled[_ngcontent-%COMP%]{border:1px solid transparent;color:#fff}.orc-alert--variant-filled.orc-alert--severity-info[_ngcontent-%COMP%]{background-color:var(--color-info, #2B7FFF)}.orc-alert--variant-filled.orc-alert--severity-success[_ngcontent-%COMP%]{background-color:var(--color-success, #006F4A)}.orc-alert--variant-filled.orc-alert--severity-warning[_ngcontent-%COMP%]{background-color:var(--color-warning, #FE9A00);color:#fff}.orc-alert--variant-filled.orc-alert--severity-error[_ngcontent-%COMP%]{background-color:var(--color-error, #FB2C36)}.orc-alert--variant-filled[_ngcontent-%COMP%]   .orc-alert__close[_ngcontent-%COMP%]:hover{background-color:#fff3}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AlertComponent, [{
        type: Component,
        args: [{ selector: 'orc-alert', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    'class': 'orc-alert-host',
                    '[class.orc-alert-host--hidden]': '!isVisible()',
                }, template: "@if (isVisible()) {\n  <div\n    class=\"orc-alert\"\n    [class.orc-alert--severity-info]=\"activeSeverity() === 'info'\"\n    [class.orc-alert--severity-success]=\"activeSeverity() === 'success'\"\n    [class.orc-alert--severity-warning]=\"activeSeverity() === 'warning'\"\n    [class.orc-alert--severity-error]=\"activeSeverity() === 'error'\"\n    [class.orc-alert--variant-subtle]=\"activeVariant() === 'subtle'\"\n    [class.orc-alert--variant-filled]=\"activeVariant() === 'filled'\"\n    [class.orc-alert--variant-outline]=\"activeVariant() === 'outline'\"\n    [attr.role]=\"computedRole()\"\n    [attr.aria-live]=\"computedAriaLive()\"\n    [attr.aria-label]=\"ariaLabel() || undefined\"\n  >\n    <!-- \u00CDcone \u00E0 Esquerda (Customizado ou Padr\u00E3o do Figma) -->\n    @if (showIcon()) {\n      <div class=\"orc-alert__icon-container\" aria-hidden=\"true\">\n        <ng-content select=\"[alert-icon], [alertIcon]\">\n          <!-- \u00CDcones SVG fi\u00E9is ao Figma com currentColor -->\n          @switch (activeSeverity()) {\n            @case ('info') {\n              <svg class=\"orc-alert__icon\" viewBox=\"0 0 16 16\" fill=\"none\">\n                <path d=\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334Z\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"M8 10.667V8\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"M8 5.333h.007\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n              </svg>\n            }\n            @case ('success') {\n              <svg class=\"orc-alert__icon\" viewBox=\"0 0 16 16\" fill=\"none\">\n                <path d=\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334Z\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"m5.333 8 2 2 3.334-3.333\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n              </svg>\n            }\n            @case ('warning') {\n              <svg class=\"orc-alert__icon\" viewBox=\"0 0 16 16\" fill=\"none\">\n                <path d=\"M8 1.333 1.333 13.333h13.334L8 1.333Z\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"M8 6v3.333\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"M8 11.333h.007\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n              </svg>\n            }\n            @case ('error') {\n              <svg class=\"orc-alert__icon\" viewBox=\"0 0 16 16\" fill=\"none\">\n                <path d=\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334Z\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n                <path d=\"m10 6-4 4M6 6l4 4\" stroke=\"currentColor\" stroke-width=\"1.333\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n              </svg>\n            }\n          }\n        </ng-content>\n      </div>\n    }\n\n    <!-- Corpo do Conte\u00FAdo -->\n    <div class=\"orc-alert__content\">\n      @if (title()) {\n        <p class=\"orc-alert__title\">{{ title() }}</p>\n      }\n      <ng-content select=\"[alert-title], [alertTitle]\"></ng-content>\n\n      @if (message()) {\n        <p class=\"orc-alert__description\">{{ message() }}</p>\n      }\n      <ng-content></ng-content>\n    </div>\n\n    <!-- A\u00E7\u00F5es e Bot\u00F5es Integrados -->\n    <div class=\"orc-alert__actions\">\n      <ng-content select=\"[alert-actions], [alertActions]\"></ng-content>\n    </div>\n\n    <!-- Bot\u00E3o de Fechar -->\n    @if (dismissible()) {\n      <button\n        type=\"button\"\n        class=\"orc-alert__close\"\n        [attr.aria-label]=\"closeAriaLabel()\"\n        (click)=\"handleDismiss($event)\"\n      >\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" class=\"orc-alert__close-icon\" aria-hidden=\"true\">\n          <path d=\"M12 4L4 12M4 4l8 8\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n        </svg>\n      </button>\n    }\n  </div>\n}\n", styles: [":host{display:block;width:100%;transition:opacity var(--transition-base, .2s ease),max-height var(--transition-base, .2s ease),transform var(--transition-base, .2s ease)}:host.orc-alert-host--hidden{opacity:0;pointer-events:none;max-height:0;overflow:hidden;margin:0;padding:0}.orc-alert{display:flex;align-items:center;justify-content:flex-start;position:relative;width:100%;min-height:68px;padding:13px 17px;border-radius:var(--radius-md, 10px);font-family:var(--font-sans, \"Poppins\", sans-serif);gap:12px;box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-alert__icon-container{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:16px;height:16px;margin-top:0}.orc-alert__icon{width:16px;height:16px;display:block}.orc-alert__content{flex:1 1 auto;display:flex;flex-direction:column;gap:2px;font-size:14px;line-height:20px;word-break:break-word}.orc-alert__title{font-weight:500;letter-spacing:-.35px;margin:0;padding:0}.orc-alert__description{font-weight:400;margin:0;padding:0;opacity:.95}.orc-alert__actions{display:inline-flex;align-items:center;gap:8px;flex-shrink:0;margin-left:auto}.orc-alert__close{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:currentColor;opacity:.7;cursor:pointer;transition:opacity var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease)}.orc-alert__close:hover{opacity:1;background-color:#00000014}.orc-alert__close:focus-visible{outline:2px solid currentColor;outline-offset:2px;opacity:1}.orc-alert__close-icon{width:14px;height:14px}.orc-alert--variant-subtle{border:1px solid transparent}.orc-alert--variant-subtle.orc-alert--severity-info{background-color:var(--status-info-soft-bg, #E1EAF6);color:var(--status-info-soft-fg, #2B7FFF)}.orc-alert--variant-subtle.orc-alert--severity-success{background-color:var(--status-success-soft-bg, #B8E7D7);color:var(--status-success-soft-fg, #006F4A)}.orc-alert--variant-subtle.orc-alert--severity-warning{background-color:var(--status-warning-soft-bg, #F6ECDD);color:var(--status-warning-soft-fg, #FE9A00)}.orc-alert--variant-subtle.orc-alert--severity-error{background-color:var(--status-danger-soft-bg, #F6D7D8);color:var(--status-danger-soft-fg, #FB2C36)}.orc-alert--variant-outline{background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--border-default, #D9D9D9)}.orc-alert--variant-outline.orc-alert--severity-info{color:var(--color-info, #2B7FFF)}.orc-alert--variant-outline.orc-alert--severity-success{color:var(--color-success, #006F4A)}.orc-alert--variant-outline.orc-alert--severity-warning{color:var(--color-warning, #FE9A00)}.orc-alert--variant-outline.orc-alert--severity-error{color:var(--color-error, #FB2C36)}.orc-alert--variant-filled{border:1px solid transparent;color:#fff}.orc-alert--variant-filled.orc-alert--severity-info{background-color:var(--color-info, #2B7FFF)}.orc-alert--variant-filled.orc-alert--severity-success{background-color:var(--color-success, #006F4A)}.orc-alert--variant-filled.orc-alert--severity-warning{background-color:var(--color-warning, #FE9A00);color:#fff}.orc-alert--variant-filled.orc-alert--severity-error{background-color:var(--color-error, #FB2C36)}.orc-alert--variant-filled .orc-alert__close:hover{background-color:#fff3}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AlertComponent, { className: "AlertComponent", filePath: "alert.component.ts", lineNumber: 24 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { AlertComponent };
//# sourceMappingURL=ciag-orchestra-alert.mjs.map
