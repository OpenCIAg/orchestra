import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, viewChild, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const _c0 = ["nativeInput"];
const _c1 = ["*", "*"];
function CheckboxComponent__svg_svg_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 7);
    i0.ɵɵelement(1, "path", 8);
    i0.ɵɵelementEnd();
} }
function CheckboxComponent__svg_svg_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "path", 10);
    i0.ɵɵelementEnd();
} }
function CheckboxComponent_span_6_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.labelId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.label());
} }
function CheckboxComponent_span_6_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.descriptionId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.description(), " ");
} }
function CheckboxComponent_span_6_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 17);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.errorId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.errorMessage(), " ");
} }
function CheckboxComponent_span_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵtemplate(1, CheckboxComponent_span_6_span_1_Template, 2, 2, "span", 12);
    i0.ɵɵprojection(2);
    i0.ɵɵtemplate(3, CheckboxComponent_span_6_span_3_Template, 2, 2, "span", 13)(4, CheckboxComponent_span_6_span_4_Template, 2, 2, "span", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.label());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.description() && !ctx_r1.errorMessage());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.errorMessage());
} }
function CheckboxComponent_span_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
} }
let nextCheckboxUniqueId = 0;
class CheckboxComponent {
    // Inputs (Signals API)
    id = input('');
    name = input('');
    value = input(undefined);
    label = input('');
    description = input('');
    disabled = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    errorMessage = input('');
    ariaLabel = input('');
    ariaLabelledby = input('');
    ariaDescribedby = input('');
    // Two-way Models (Signals API)
    checked = model(false);
    indeterminate = model(false);
    // Outputs (Signals API)
    change = output();
    // Element reference ao input nativo para controle de foco
    inputElement = viewChild('nativeInput');
    // ID interno único
    uniqueId = `orc-checkbox-${++nextCheckboxUniqueId}`;
    // Estado interno para ControlValueAccessor
    cvaDisabled = signal(false);
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.id() || this.uniqueId);
    labelId = computed(() => `${this.effectiveId()}-label`);
    descriptionId = computed(() => `${this.effectiveId()}-desc`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    isDisabled = computed(() => this.disabled() || this.cvaDisabled());
    isError = computed(() => this.error() || !!this.errorMessage());
    // Acessibilidade WCAG: aria-checked com suporte a "mixed" para indeterminate
    ariaChecked = computed(() => {
        if (this.indeterminate()) {
            return 'mixed';
        }
        return this.checked() ? 'true' : 'false';
    });
    computedAriaDescribedBy = computed(() => {
        if (this.ariaDescribedby())
            return this.ariaDescribedby();
        if (this.errorMessage())
            return this.errorId();
        if (this.description())
            return this.descriptionId();
        return null;
    });
    hasContent = computed(() => {
        return !!this.label() || !!this.description() || !!this.errorMessage();
    });
    // Callbacks do ControlValueAccessor
    onChange = () => { };
    onTouched = () => { };
    // ── ControlValueAccessor Implementation ───────────────────
    writeValue(val) {
        this.checked.set(Boolean(val));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Event Handlers ────────────────────────────────────────
    onNativeChange(event) {
        if (this.isDisabled()) {
            event.preventDefault();
            return;
        }
        const input = event.target;
        // Se estava em estado indeterminado, alternar limpa o indeterminado e marca como checado
        if (this.indeterminate()) {
            this.indeterminate.set(false);
            this.checked.set(true);
        }
        else {
            this.checked.set(input.checked);
        }
        const newChecked = this.checked();
        this.onChange(newChecked);
        this.onTouched();
        this.change.emit({
            checked: newChecked,
            indeterminate: this.indeterminate(),
            value: this.value(),
        });
    }
    onBlur() {
        this.onTouched();
    }
    // ── Public API Methods ────────────────────────────────────
    toggle() {
        if (this.isDisabled())
            return;
        if (this.indeterminate()) {
            this.indeterminate.set(false);
            this.checked.set(true);
        }
        else {
            this.checked.update((c) => !c);
        }
        const newChecked = this.checked();
        this.onChange(newChecked);
        this.onTouched();
        this.change.emit({
            checked: newChecked,
            indeterminate: this.indeterminate(),
            value: this.value(),
        });
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = function CheckboxComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CheckboxComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CheckboxComponent, selectors: [["orc-checkbox"]], viewQuery: function CheckboxComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.inputElement, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], name: [1, "name"], value: [1, "value"], label: [1, "label"], description: [1, "description"], disabled: [1, "disabled"], required: [1, "required"], error: [1, "error"], errorMessage: [1, "errorMessage"], ariaLabel: [1, "ariaLabel"], ariaLabelledby: [1, "ariaLabelledby"], ariaDescribedby: [1, "ariaDescribedby"], checked: [1, "checked"], indeterminate: [1, "indeterminate"] }, outputs: { checked: "checkedChange", indeterminate: "indeterminateChange", change: "change" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => CheckboxComponent),
                    multi: true,
                },
            ])], ngContentSelectors: _c1, decls: 8, vars: 23, consts: [["nativeInput", ""], [1, "orc-checkbox"], ["type", "checkbox", 1, "orc-checkbox__native-input", 3, "change", "blur", "id", "name", "checked", "disabled", "required"], ["aria-hidden", "true", 1, "orc-checkbox__box"], ["class", "orc-checkbox__icon orc-checkbox__icon--check", "viewBox", "0 0 16 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 4, "ngIf"], ["class", "orc-checkbox__icon orc-checkbox__icon--dash", "viewBox", "0 0 16 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 4, "ngIf"], ["class", "orc-checkbox__content", 4, "ngIf"], ["viewBox", "0 0 16 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "orc-checkbox__icon", "orc-checkbox__icon--check"], ["d", "M3.5 8.2L6.5 11.2L12.5 4.8", "stroke", "currentColor", "stroke-width", "1.8", "stroke-linecap", "round", "stroke-linejoin", "round"], ["viewBox", "0 0 16 16", "fill", "none", "xmlns", "http://www.w3.org/2000/svg", 1, "orc-checkbox__icon", "orc-checkbox__icon--dash"], ["d", "M3.5 8H12.5", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round"], [1, "orc-checkbox__content"], ["class", "orc-checkbox__label", 3, "id", 4, "ngIf"], ["class", "orc-checkbox__description", 3, "id", 4, "ngIf"], ["class", "orc-checkbox__error", 3, "id", 4, "ngIf"], [1, "orc-checkbox__label", 3, "id"], [1, "orc-checkbox__description", 3, "id"], [1, "orc-checkbox__error", 3, "id"]], template: function CheckboxComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "label", 1)(1, "input", 2, 0);
            i0.ɵɵlistener("change", function CheckboxComponent_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onNativeChange($event)); })("blur", function CheckboxComponent_Template_input_blur_1_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur()); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "span", 3);
            i0.ɵɵtemplate(4, CheckboxComponent__svg_svg_4_Template, 2, 0, "svg", 4)(5, CheckboxComponent__svg_svg_5_Template, 2, 0, "svg", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, CheckboxComponent_span_6_Template, 5, 3, "span", 6)(7, CheckboxComponent_span_7_Template, 2, 0, "span", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-checkbox--checked", ctx.checked() && !ctx.indeterminate())("orc-checkbox--indeterminate", ctx.indeterminate())("orc-checkbox--disabled", ctx.isDisabled())("orc-checkbox--error", ctx.isError());
            i0.ɵɵattribute("for", ctx.effectiveId());
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.name() || null)("checked", ctx.checked())("disabled", ctx.isDisabled())("required", ctx.required());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-labelledby", ctx.ariaLabelledby() || null)("aria-describedby", ctx.computedAriaDescribedBy())("aria-checked", ctx.ariaChecked())("aria-invalid", ctx.isError());
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.checked() && !ctx.indeterminate());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.indeterminate());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.hasContent());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.hasContent());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-checkbox[_ngcontent-%COMP%]{display:inline-flex;align-items:flex-start;gap:11px;position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428}.orc-checkbox__native-input[_ngcontent-%COMP%]{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-checkbox__box[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-top:2px;flex-shrink:0;position:relative;border-radius:4px;border:1px solid var(--orc-border, #d9d9d9);background-color:var(--orc-fill-input, #ffffff);color:var(--orc-opposite-bw, #ffffff);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-checkbox__icon[_ngcontent-%COMP%]{width:12px;height:12px;display:block;animation:_ngcontent-%COMP%_orc-checkbox-appear var(--transition-fast, .12s ease)}.orc-checkbox__icon--check[_ngcontent-%COMP%], .orc-checkbox__icon--dash[_ngcontent-%COMP%]{stroke:currentColor}.orc-checkbox__content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.orc-checkbox__label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:400;color:var(--orc-font-main, #141414);line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-checkbox__description[_ngcontent-%COMP%]{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-checkbox__error[_ngcontent-%COMP%]{font-size:.75rem;color:var(--color-error, #fb2c36);line-height:1.4;margin-top:2px;font-weight:500}.orc-checkbox[_ngcontent-%COMP%]:hover:not(.orc-checkbox--disabled)   .orc-checkbox__box[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox[_ngcontent-%COMP%]   .orc-checkbox__native-input[_ngcontent-%COMP%]:focus-visible + .orc-checkbox__box[_ngcontent-%COMP%]{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-checkbox--checked[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox--checked[_ngcontent-%COMP%]   .orc-checkbox__label[_ngcontent-%COMP%]{font-weight:500;color:var(--orc-font-main, #141414)}.orc-checkbox--indeterminate[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox--indeterminate[_ngcontent-%COMP%]   .orc-checkbox__label[_ngcontent-%COMP%]{font-weight:500;color:var(--orc-font-main, #141414)}.orc-checkbox--error[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{border-color:var(--color-error, #fb2c36)!important}.orc-checkbox--error.orc-checkbox--checked[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%], .orc-checkbox--error.orc-checkbox--indeterminate[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{background-color:var(--color-error, #fb2c36)!important;border-color:var(--color-error, #fb2c36)!important}.orc-checkbox--error[_ngcontent-%COMP%]   .orc-checkbox__label[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}.orc-checkbox--error[_ngcontent-%COMP%]   .orc-checkbox__native-input[_ngcontent-%COMP%]:focus-visible + .orc-checkbox__box[_ngcontent-%COMP%]{outline-color:var(--color-error, #fb2c36)}.orc-checkbox--disabled[_ngcontent-%COMP%]{cursor:not-allowed;opacity:.5}.orc-checkbox--disabled[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9)}.orc-checkbox--disabled.orc-checkbox--checked[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%], .orc-checkbox--disabled.orc-checkbox--indeterminate[_ngcontent-%COMP%]   .orc-checkbox__box[_ngcontent-%COMP%]{background-color:var(--orc-font-secondary, #666666);border-color:var(--orc-font-secondary, #666666)}.orc-checkbox--disabled[_ngcontent-%COMP%]   .orc-checkbox__label[_ngcontent-%COMP%], .orc-checkbox--disabled[_ngcontent-%COMP%]   .orc-checkbox__description[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}@keyframes _ngcontent-%COMP%_orc-checkbox-appear{0%{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CheckboxComponent, [{
        type: Component,
        args: [{ selector: 'orc-checkbox', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => CheckboxComponent),
                        multi: true,
                    },
                ], template: "<label\n  class=\"orc-checkbox\"\n  [class.orc-checkbox--checked]=\"checked() && !indeterminate()\"\n  [class.orc-checkbox--indeterminate]=\"indeterminate()\"\n  [class.orc-checkbox--disabled]=\"isDisabled()\"\n  [class.orc-checkbox--error]=\"isError()\"\n  [attr.for]=\"effectiveId()\"\n>\n  <!-- Visually hidden native checkbox input for complete a11y, keyboard navigation (Space key) and Form bindings -->\n  <input\n    #nativeInput\n    type=\"checkbox\"\n    class=\"orc-checkbox__native-input\"\n    [id]=\"effectiveId()\"\n    [name]=\"name() || null\"\n    [checked]=\"checked()\"\n    [disabled]=\"isDisabled()\"\n    [required]=\"required()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"ariaLabelledby() || null\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-checked]=\"ariaChecked()\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onNativeChange($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n  <!-- Visual Custom Checkbox matching Figma 382:5024 (16x16px, 4px border radius) -->\n  <span class=\"orc-checkbox__box\" aria-hidden=\"true\">\n    <!-- Checked Checkmark Icon -->\n    <svg\n      *ngIf=\"checked() && !indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--check\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8.2L6.5 11.2L12.5 4.8\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.8\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n\n    <!-- Indeterminate Dash Icon -->\n    <svg\n      *ngIf=\"indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--dash\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8H12.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n      />\n    </svg>\n  </span>\n\n  <!-- Label, Description / Error & Content Projection -->\n  <span class=\"orc-checkbox__content\" *ngIf=\"hasContent()\">\n    <span class=\"orc-checkbox__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-checkbox__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-checkbox__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </span>\n\n  <span class=\"orc-checkbox__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-checkbox{display:inline-flex;align-items:flex-start;gap:11px;position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428}.orc-checkbox__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-checkbox__box{display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-top:2px;flex-shrink:0;position:relative;border-radius:4px;border:1px solid var(--orc-border, #d9d9d9);background-color:var(--orc-fill-input, #ffffff);color:var(--orc-opposite-bw, #ffffff);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-checkbox__icon{width:12px;height:12px;display:block;animation:orc-checkbox-appear var(--transition-fast, .12s ease)}.orc-checkbox__icon--check,.orc-checkbox__icon--dash{stroke:currentColor}.orc-checkbox__content{display:flex;flex-direction:column}.orc-checkbox__label{font-size:.875rem;font-weight:400;color:var(--orc-font-main, #141414);line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-checkbox__description{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-checkbox__error{font-size:.75rem;color:var(--color-error, #fb2c36);line-height:1.4;margin-top:2px;font-weight:500}.orc-checkbox:hover:not(.orc-checkbox--disabled) .orc-checkbox__box{border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-checkbox--checked .orc-checkbox__box{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox--checked .orc-checkbox__label{font-weight:500;color:var(--orc-font-main, #141414)}.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-checkbox--indeterminate .orc-checkbox__label{font-weight:500;color:var(--orc-font-main, #141414)}.orc-checkbox--error .orc-checkbox__box{border-color:var(--color-error, #fb2c36)!important}.orc-checkbox--error.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--error.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--color-error, #fb2c36)!important;border-color:var(--color-error, #fb2c36)!important}.orc-checkbox--error .orc-checkbox__label{color:var(--color-error, #fb2c36)}.orc-checkbox--error .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline-color:var(--color-error, #fb2c36)}.orc-checkbox--disabled{cursor:not-allowed;opacity:.5}.orc-checkbox--disabled .orc-checkbox__box{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9)}.orc-checkbox--disabled.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--disabled.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-font-secondary, #666666);border-color:var(--orc-font-secondary, #666666)}.orc-checkbox--disabled .orc-checkbox__label,.orc-checkbox--disabled .orc-checkbox__description{color:var(--orc-font-secondary, #666666)}@keyframes orc-checkbox-appear{0%{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CheckboxComponent, { className: "CheckboxComponent", filePath: "checkbox.component.ts", lineNumber: 35 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { CheckboxComponent };
//# sourceMappingURL=ciag-orchestra-checkbox.mjs.map
