import * as i0 from '@angular/core';
import { input, viewChild, computed, ChangeDetectionStrategy, Component, model, output, contentChildren, viewChildren } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

const _c0$1 = ["contentTemplate"];
const _c1$1 = ["customLabelTemplate"];
const _c2 = ["*", [["", "tab-label", ""], ["", "tabLabel", ""]]];
const _c3 = ["*", "[tab-label], [tabLabel]"];
function TabComponent_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
function TabComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0, 1);
} }
let uniqueTabIdCounter = 0;
class TabComponent {
    // Inputs (Signals API)
    label = input('');
    icon = input('');
    iconPosition = input('start');
    disabled = input(false);
    badge = input(undefined);
    id = input('');
    // Templates internos para projeção sob demanda
    contentTemplate = viewChild('contentTemplate');
    customLabelTemplate = viewChild('customLabelTemplate');
    // Identificador único garantido
    fallbackId = `orc-tab-${++uniqueTabIdCounter}`;
    tabId = computed(() => this.id() || this.fallbackId);
    panelId = computed(() => `${this.tabId()}-panel`);
    static ɵfac = function TabComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TabComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TabComponent, selectors: [["orc-tab"]], viewQuery: function TabComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.contentTemplate, _c0$1, 5);
            i0.ɵɵviewQuerySignal(ctx.customLabelTemplate, _c1$1, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(2);
        } }, inputs: { label: [1, "label"], icon: [1, "icon"], iconPosition: [1, "iconPosition"], disabled: [1, "disabled"], badge: [1, "badge"], id: [1, "id"] }, ngContentSelectors: _c3, decls: 4, vars: 0, consts: [["contentTemplate", ""], ["customLabelTemplate", ""]], template: function TabComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c2);
            i0.ɵɵtemplate(0, TabComponent_ng_template_0_Template, 1, 0, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor)(2, TabComponent_ng_template_2_Template, 1, 0, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:none}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TabComponent, [{
        type: Component,
        args: [{ selector: 'orc-tab', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #contentTemplate>\n  <ng-content></ng-content>\n</ng-template>\n\n<ng-template #customLabelTemplate>\n  <ng-content select=\"[tab-label], [tabLabel]\"></ng-content>\n</ng-template>\n", styles: [":host{display:none}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TabComponent, { className: "TabComponent", filePath: "tab.component.ts", lineNumber: 22 }); })();

const _c0 = ["tabBtn"];
const _c1 = ["*"];
function TabGroupComponent_ng_container_4_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 14);
} }
function TabGroupComponent_ng_container_4_span_4__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 18)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function TabGroupComponent_ng_container_4_span_4__svg_svg_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "circle", 20)(2, "path", 21);
    i0.ɵɵelementEnd();
} }
function TabGroupComponent_ng_container_4_span_4__svg_svg_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 17);
    i0.ɵɵelement(1, "path", 22)(2, "line", 23)(3, "line", 24);
    i0.ɵɵelementEnd();
} }
function TabGroupComponent_ng_container_4_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 15);
    i0.ɵɵtemplate(1, TabGroupComponent_ng_container_4_span_4__svg_svg_1_Template, 3, 0, "svg", 16)(2, TabGroupComponent_ng_container_4_span_4__svg_svg_2_Template, 3, 0, "svg", 16)(3, TabGroupComponent_ng_container_4_span_4__svg_svg_3_Template, 4, 0, "svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.icon() === "home");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.icon() === "settings");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.icon() === "warning");
} }
function TabGroupComponent_ng_container_4_span_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 25);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", tab_r4.label(), " ");
} }
function TabGroupComponent_ng_container_4_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function TabGroupComponent_ng_container_4_span_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", tab_r4.badge(), " ");
} }
function TabGroupComponent_ng_container_4_span_8__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 29);
    i0.ɵɵelement(1, "path", 18);
    i0.ɵɵelementEnd();
} }
function TabGroupComponent_ng_container_4_span_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 27);
    i0.ɵɵtemplate(1, TabGroupComponent_ng_container_4_span_8__svg_svg_1_Template, 2, 0, "svg", 28);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r4 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.icon() === "home");
} }
function TabGroupComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, TabGroupComponent_ng_container_4_span_1_Template, 1, 0, "span", 7);
    i0.ɵɵelementStart(2, "button", 8, 0);
    i0.ɵɵlistener("click", function TabGroupComponent_ng_container_4_Template_button_click_2_listener() { const i_r2 = i0.ɵɵrestoreView(_r1).index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.selectTab(i_r2)); })("keydown", function TabGroupComponent_ng_container_4_Template_button_keydown_2_listener($event) { const i_r2 = i0.ɵɵrestoreView(_r1).index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onKeydown($event, i_r2)); });
    i0.ɵɵtemplate(4, TabGroupComponent_ng_container_4_span_4_Template, 4, 3, "span", 9)(5, TabGroupComponent_ng_container_4_span_5_Template, 2, 1, "span", 10)(6, TabGroupComponent_ng_container_4_ng_container_6_Template, 1, 0, "ng-container", 11)(7, TabGroupComponent_ng_container_4_span_7_Template, 2, 1, "span", 12)(8, TabGroupComponent_ng_container_4_span_8_Template, 2, 1, "span", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const tab_r4 = ctx.$implicit;
    const i_r2 = ctx.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.variant() === "filled" && i_r2 > 0 && ctx_r2.selectedIndex() !== i_r2 && ctx_r2.selectedIndex() !== i_r2 - 1);
    i0.ɵɵadvance();
    i0.ɵɵclassProp("orc-tab-group__tab--active", ctx_r2.selectedIndex() === i_r2)("orc-tab-group__tab--disabled", tab_r4.disabled());
    i0.ɵɵproperty("id", tab_r4.tabId())("tabindex", ctx_r2.selectedIndex() === i_r2 ? 0 : -1)("disabled", tab_r4.disabled());
    i0.ɵɵattribute("aria-selected", ctx_r2.selectedIndex() === i_r2)("aria-controls", tab_r4.panelId());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", tab_r4.icon() && tab_r4.iconPosition() === "start");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.label());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", tab_r4.customLabelTemplate() || null);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.badge() !== undefined);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", tab_r4.icon() && tab_r4.iconPosition() === "end");
} }
function TabGroupComponent_div_6_ng_container_1_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function TabGroupComponent_div_6_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, TabGroupComponent_div_6_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 11);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const tab_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", tab_r5.contentTemplate() || null);
} }
function TabGroupComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 30);
    i0.ɵɵtemplate(1, TabGroupComponent_div_6_ng_container_1_Template, 2, 1, "ng-container", 31);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const tab_r5 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-tab-group__panel--active", ctx_r2.selectedIndex() === i_r6);
    i0.ɵɵproperty("id", tab_r5.panelId())("hidden", ctx_r2.selectedIndex() !== i_r6);
    i0.ɵɵattribute("aria-labelledby", tab_r5.tabId());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.selectedIndex() === i_r6);
} }
class TabGroupComponent {
    // Inputs & Model (Signals API)
    selectedIndex = model(0);
    variant = input('line');
    size = input('md');
    fullWidth = input(false);
    ariaLabel = input('Abas de navegação');
    // Outputs (Signals API)
    tabChange = output();
    // Abas filhas registradas via contentChildren
    tabs = contentChildren(TabComponent);
    // Referências dos botões de abas para navegação por teclado e foco programático
    tabButtons = viewChildren('tabBtn');
    // ── Seleção de Aba ────────────────────────────────────────
    selectTab(index) {
        const tabList = this.tabs();
        if (index < 0 || index >= tabList.length)
            return;
        const targetTab = tabList[index];
        if (targetTab.disabled())
            return;
        this.selectedIndex.set(index);
        this.tabChange.emit({ index, tab: targetTab });
    }
    // ── Navegação Acessível por Teclado (WAI-ARIA Tabs) ───────
    onKeydown(event, currentIndex) {
        const tabList = this.tabs();
        if (!tabList || tabList.length === 0)
            return;
        const enabledIndices = tabList
            .map((tab, idx) => (!tab.disabled() ? idx : -1))
            .filter(idx => idx !== -1);
        if (enabledIndices.length === 0)
            return;
        const currentPos = enabledIndices.indexOf(currentIndex);
        let targetIndex = -1;
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowDown':
                event.preventDefault();
                targetIndex =
                    enabledIndices[(currentPos + 1) % enabledIndices.length];
                break;
            case 'ArrowLeft':
            case 'ArrowUp':
                event.preventDefault();
                targetIndex =
                    enabledIndices[(currentPos - 1 + enabledIndices.length) % enabledIndices.length];
                break;
            case 'Home':
                event.preventDefault();
                targetIndex = enabledIndices[0];
                break;
            case 'End':
                event.preventDefault();
                targetIndex = enabledIndices[enabledIndices.length - 1];
                break;
            case ' ':
            case 'Enter':
                event.preventDefault();
                this.selectTab(currentIndex);
                return;
        }
        if (targetIndex !== -1) {
            this.selectTab(targetIndex);
            this.focusTab(targetIndex);
        }
    }
    focusTab(index) {
        const buttons = this.tabButtons();
        if (buttons && buttons[index]) {
            buttons[index].nativeElement.focus();
        }
    }
    static ɵfac = function TabGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TabGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TabGroupComponent, selectors: [["orc-tab-group"]], contentQueries: function TabGroupComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuerySignal(dirIndex, ctx.tabs, TabComponent, 4);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, viewQuery: function TabGroupComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.tabButtons, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { selectedIndex: [1, "selectedIndex"], variant: [1, "variant"], size: [1, "size"], fullWidth: [1, "fullWidth"], ariaLabel: [1, "ariaLabel"] }, outputs: { selectedIndex: "selectedIndexChange", tabChange: "tabChange" }, ngContentSelectors: _c1, decls: 7, vars: 15, consts: [["tabBtn", ""], ["aria-hidden", "true", 1, "orc-tab-group__slot"], [1, "orc-tab-group"], ["role", "tablist", 1, "orc-tab-group__header"], [4, "ngFor", "ngForOf"], [1, "orc-tab-group__panels"], ["role", "tabpanel", "class", "orc-tab-group__panel", "tabindex", "0", 3, "orc-tab-group__panel--active", "id", "hidden", 4, "ngFor", "ngForOf"], ["class", "orc-tab-group__divider", "aria-hidden", "true", 4, "ngIf"], ["type", "button", "role", "tab", 1, "orc-tab-group__tab", 3, "click", "keydown", "id", "tabindex", "disabled"], ["class", "orc-tab-group__icon orc-tab-group__icon--start", "aria-hidden", "true", 4, "ngIf"], ["class", "orc-tab-group__label", 4, "ngIf"], [4, "ngTemplateOutlet"], ["class", "orc-tab-group__badge", 4, "ngIf"], ["class", "orc-tab-group__icon orc-tab-group__icon--end", "aria-hidden", "true", 4, "ngIf"], ["aria-hidden", "true", 1, "orc-tab-group__divider"], ["aria-hidden", "true", 1, "orc-tab-group__icon", "orc-tab-group__icon--start"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", 4, "ngIf"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"], ["points", "9 22 9 12 15 12 15 22"], ["cx", "12", "cy", "12", "r", "3"], ["d", "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"], ["d", "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"], ["x1", "12", "y1", "9", "x2", "12", "y2", "13"], ["x1", "12", "y1", "17", "x2", "12.01", "y2", "17"], [1, "orc-tab-group__label"], [1, "orc-tab-group__badge"], ["aria-hidden", "true", 1, "orc-tab-group__icon", "orc-tab-group__icon--end"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", 4, "ngIf"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2"], ["role", "tabpanel", "tabindex", "0", 1, "orc-tab-group__panel", 3, "id", "hidden"], [4, "ngIf"]], template: function TabGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(2, "div", 2)(3, "div", 3);
            i0.ɵɵtemplate(4, TabGroupComponent_ng_container_4_Template, 9, 15, "ng-container", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 5);
            i0.ɵɵtemplate(6, TabGroupComponent_div_6_Template, 2, 6, "div", 6);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵclassProp("orc-tab-group--variant-line", ctx.variant() === "line")("orc-tab-group--variant-filled", ctx.variant() === "filled")("orc-tab-group--size-sm", ctx.size() === "sm")("orc-tab-group--size-md", ctx.size() === "md")("orc-tab-group--size-lg", ctx.size() === "lg")("orc-tab-group--full-width", ctx.fullWidth());
            i0.ɵɵadvance();
            i0.ɵɵattribute("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.tabs());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.tabs());
        } }, dependencies: [CommonModule, i1.NgForOf, i1.NgIf, i1.NgTemplateOutlet], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-tab-group[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-tab-group__slot[_ngcontent-%COMP%]{display:none}.orc-tab-group__header[_ngcontent-%COMP%]{display:flex;align-items:center;position:relative;-webkit-user-select:none;user-select:none;box-sizing:border-box;overflow-x:auto;scrollbar-width:none}.orc-tab-group__header[_ngcontent-%COMP%]::-webkit-scrollbar{display:none}.orc-tab-group__tab[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;cursor:pointer;font-family:inherit;white-space:nowrap;text-decoration:none;flex-shrink:0;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease);outline:none;box-sizing:border-box}.orc-tab-group__tab[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-tab-group__icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-tab-group__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%}.orc-tab-group__icon--start[_ngcontent-%COMP%]{margin-right:8px}.orc-tab-group__icon--end[_ngcontent-%COMP%]{margin-left:8px}.orc-tab-group__badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;font-size:.6875rem;font-weight:600;padding:1px 6px;border-radius:9999px;background:#1c6aed1f;color:var(--orc-color-azul-eletrico, #1c6aed);margin-left:8px}.orc-tab-group--full-width[_ngcontent-%COMP%]   .orc-tab-group__header[_ngcontent-%COMP%]{width:100%}.orc-tab-group--full-width[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{flex:1 0 auto}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__header[_ngcontent-%COMP%]{box-shadow:inset 0 -2px 0 var(--highlight-cinzaclaro, #ededed);gap:0}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:44px;padding:0 20px;font-size:1rem;font-weight:400;color:#929292;box-shadow:inset 0 -2px 0 transparent}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]   .orc-tab-group__icon[_ngcontent-%COMP%]{width:20px;height:20px;color:#929292}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]:hover:not(:disabled){color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]:hover:not(:disabled)   .orc-tab-group__icon[_ngcontent-%COMP%]{color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab--active[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600;box-shadow:inset 0 -2px 0 var(--orc-color-azul-eletrico, #1c6aed)}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab--active[_ngcontent-%COMP%]   .orc-tab-group__icon[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab--disabled[_ngcontent-%COMP%]{opacity:.25;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__header[_ngcontent-%COMP%]{background:var(--highlight-cinzaclaro, #ededed);padding:5px;border-radius:10px;display:inline-flex;align-items:center;gap:2px;width:fit-content}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:34px;padding:0 16px;font-size:.9375rem;font-weight:400;color:var(--orc-font-main, #141414);border-radius:10px;transition:all var(--transition-fast, .12s ease)}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]   .orc-tab-group__icon[_ngcontent-%COMP%]{width:18px;height:18px}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]:hover:not(:disabled):not(.orc-tab-group__tab--active){color:var(--orc-color-azul-royal, #0406ab);background-color:#fff9}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]:hover:not(:disabled):not(.orc-tab-group__tab--active)   .orc-tab-group__icon[_ngcontent-%COMP%]{color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab--active[_ngcontent-%COMP%]{background-color:var(--bg, #ffffff);color:var(--orc-font-main, #141414);font-weight:500;box-shadow:0 1px 3px #00000014}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab--disabled[_ngcontent-%COMP%]{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__divider[_ngcontent-%COMP%]{display:inline-block;width:1px;height:16px;background-color:#d4d4d8;margin:0 2px}.orc-tab-group--size-sm.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:36px;padding:0 14px;font-size:.875rem}.orc-tab-group--size-sm.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]   .orc-tab-group__icon[_ngcontent-%COMP%]{width:16px;height:16px}.orc-tab-group--size-sm.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:28px;padding:0 12px;font-size:.8125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:52px;padding:0 26px;font-size:1.125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]   .orc-tab-group__icon[_ngcontent-%COMP%]{width:24px;height:24px}.orc-tab-group--size-lg.orc-tab-group--variant-filled[_ngcontent-%COMP%]   .orc-tab-group__tab[_ngcontent-%COMP%]{height:42px;padding:0 22px;font-size:1.0625rem}.orc-tab-group__panels[_ngcontent-%COMP%]{width:100%;margin-top:var(--space-4, 1rem)}.orc-tab-group__panel[_ngcontent-%COMP%]{outline:none}.orc-tab-group__panel[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-sm, 6px)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TabGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-tab-group', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<!-- Coletor de abas filhas para ContentChildren -->\n<div class=\"orc-tab-group__slot\" aria-hidden=\"true\">\n  <ng-content></ng-content>\n</div>\n\n<div\n  class=\"orc-tab-group\"\n  [class.orc-tab-group--variant-line]=\"variant() === 'line'\"\n  [class.orc-tab-group--variant-filled]=\"variant() === 'filled'\"\n  [class.orc-tab-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-tab-group--size-md]=\"size() === 'md'\"\n  [class.orc-tab-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-tab-group--full-width]=\"fullWidth()\"\n>\n  <!-- Barra de Abas (WAI-ARIA Tablist) -->\n  <div\n    class=\"orc-tab-group__header\"\n    role=\"tablist\"\n    [attr.aria-label]=\"ariaLabel()\"\n  >\n    <ng-container *ngFor=\"let tab of tabs(); let i = index\">\n      <!-- Divisor sutil entre abas inativas na variante Filled (Figma Node 69:2171) -->\n      <span\n        *ngIf=\"variant() === 'filled' && i > 0 && selectedIndex() !== i && selectedIndex() !== i - 1\"\n        class=\"orc-tab-group__divider\"\n        aria-hidden=\"true\"\n      ></span>\n\n      <!-- Bot\u00E3o da Aba Individual (WAI-ARIA Tab) -->\n      <button\n        #tabBtn\n        type=\"button\"\n        role=\"tab\"\n        class=\"orc-tab-group__tab\"\n        [class.orc-tab-group__tab--active]=\"selectedIndex() === i\"\n        [class.orc-tab-group__tab--disabled]=\"tab.disabled()\"\n        [id]=\"tab.tabId()\"\n        [attr.aria-selected]=\"selectedIndex() === i\"\n        [attr.aria-controls]=\"tab.panelId()\"\n        [tabindex]=\"selectedIndex() === i ? 0 : -1\"\n        [disabled]=\"tab.disabled()\"\n        (click)=\"selectTab(i)\"\n        (keydown)=\"onKeydown($event, i)\"\n      >\n        <!-- \u00CDcone \u00E0 Esquerda (start) -->\n        <span\n          *ngIf=\"tab.icon() && tab.iconPosition() === 'start'\"\n          class=\"orc-tab-group__icon orc-tab-group__icon--start\"\n          aria-hidden=\"true\"\n        >\n          <!-- Home Icon padr\u00E3o se icon='home' -->\n          <svg *ngIf=\"tab.icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n            <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n          </svg>\n          <!-- Settings Icon padr\u00E3o se icon='settings' -->\n          <svg *ngIf=\"tab.icon() === 'settings'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>\n            <path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"></path>\n          </svg>\n          <!-- Warning Icon padr\u00E3o se icon='warning' -->\n          <svg *ngIf=\"tab.icon() === 'warning'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z\"></path>\n            <line x1=\"12\" y1=\"9\" x2=\"12\" y2=\"13\"></line>\n            <line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\"></line>\n          </svg>\n        </span>\n\n        <!-- Label / R\u00F3tulo da Aba -->\n        <span class=\"orc-tab-group__label\" *ngIf=\"tab.label()\">\n          {{ tab.label() }}\n        </span>\n\n        <!-- Proje\u00E7\u00E3o Customizada de Label (se houver) -->\n        <ng-container *ngTemplateOutlet=\"tab.customLabelTemplate() || null\"></ng-container>\n\n        <!-- Badge Opcional -->\n        <span *ngIf=\"tab.badge() !== undefined\" class=\"orc-tab-group__badge\">\n          {{ tab.badge() }}\n        </span>\n\n        <!-- \u00CDcone \u00E0 Direita (end) -->\n        <span\n          *ngIf=\"tab.icon() && tab.iconPosition() === 'end'\"\n          class=\"orc-tab-group__icon orc-tab-group__icon--end\"\n          aria-hidden=\"true\"\n        >\n          <svg *ngIf=\"tab.icon() === 'home'\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n            <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n          </svg>\n        </span>\n      </button>\n    </ng-container>\n  </div>\n\n  <!-- Pain\u00E9is de Conte\u00FAdo das Abas (WAI-ARIA Tabpanels) -->\n  <div class=\"orc-tab-group__panels\">\n    <div\n      *ngFor=\"let tab of tabs(); let i = index\"\n      role=\"tabpanel\"\n      class=\"orc-tab-group__panel\"\n      [class.orc-tab-group__panel--active]=\"selectedIndex() === i\"\n      [id]=\"tab.panelId()\"\n      [attr.aria-labelledby]=\"tab.tabId()\"\n      [hidden]=\"selectedIndex() !== i\"\n      tabindex=\"0\"\n    >\n      <ng-container *ngIf=\"selectedIndex() === i\">\n        <ng-container *ngTemplateOutlet=\"tab.contentTemplate() || null\"></ng-container>\n      </ng-container>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-tab-group{display:flex;flex-direction:column;width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-tab-group__slot{display:none}.orc-tab-group__header{display:flex;align-items:center;position:relative;-webkit-user-select:none;user-select:none;box-sizing:border-box;overflow-x:auto;scrollbar-width:none}.orc-tab-group__header::-webkit-scrollbar{display:none}.orc-tab-group__tab{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;cursor:pointer;font-family:inherit;white-space:nowrap;text-decoration:none;flex-shrink:0;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease);outline:none;box-sizing:border-box}.orc-tab-group__tab:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-tab-group__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-tab-group__icon svg{width:100%;height:100%}.orc-tab-group__icon--start{margin-right:8px}.orc-tab-group__icon--end{margin-left:8px}.orc-tab-group__badge{display:inline-flex;align-items:center;justify-content:center;font-size:.6875rem;font-weight:600;padding:1px 6px;border-radius:9999px;background:#1c6aed1f;color:var(--orc-color-azul-eletrico, #1c6aed);margin-left:8px}.orc-tab-group--full-width .orc-tab-group__header{width:100%}.orc-tab-group--full-width .orc-tab-group__tab{flex:1 0 auto}.orc-tab-group--variant-line .orc-tab-group__header{box-shadow:inset 0 -2px 0 var(--highlight-cinzaclaro, #ededed);gap:0}.orc-tab-group--variant-line .orc-tab-group__tab{height:44px;padding:0 20px;font-size:1rem;font-weight:400;color:#929292;box-shadow:inset 0 -2px 0 transparent}.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:20px;height:20px;color:#929292}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled){color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled) .orc-tab-group__icon{color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-line .orc-tab-group__tab--active{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600;box-shadow:inset 0 -2px 0 var(--orc-color-azul-eletrico, #1c6aed)}.orc-tab-group--variant-line .orc-tab-group__tab--active .orc-tab-group__icon{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-tab-group--variant-line .orc-tab-group__tab--disabled{opacity:.25;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__header{background:var(--highlight-cinzaclaro, #ededed);padding:5px;border-radius:10px;display:inline-flex;align-items:center;gap:2px;width:fit-content}.orc-tab-group--variant-filled .orc-tab-group__tab{height:34px;padding:0 16px;font-size:.9375rem;font-weight:400;color:var(--orc-font-main, #141414);border-radius:10px;transition:all var(--transition-fast, .12s ease)}.orc-tab-group--variant-filled .orc-tab-group__tab .orc-tab-group__icon{width:18px;height:18px}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active){color:var(--orc-color-azul-royal, #0406ab);background-color:#fff9}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active) .orc-tab-group__icon{color:var(--orc-color-azul-royal, #0406ab)}.orc-tab-group--variant-filled .orc-tab-group__tab--active{background-color:var(--bg, #ffffff);color:var(--orc-font-main, #141414);font-weight:500;box-shadow:0 1px 3px #00000014}.orc-tab-group--variant-filled .orc-tab-group__tab--disabled{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__divider{display:inline-block;width:1px;height:16px;background-color:#d4d4d8;margin:0 2px}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab{height:36px;padding:0 14px;font-size:.875rem}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:16px;height:16px}.orc-tab-group--size-sm.orc-tab-group--variant-filled .orc-tab-group__tab{height:28px;padding:0 12px;font-size:.8125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab{height:52px;padding:0 26px;font-size:1.125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:24px;height:24px}.orc-tab-group--size-lg.orc-tab-group--variant-filled .orc-tab-group__tab{height:42px;padding:0 22px;font-size:1.0625rem}.orc-tab-group__panels{width:100%;margin-top:var(--space-4, 1rem)}.orc-tab-group__panel{outline:none}.orc-tab-group__panel:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);border-radius:var(--radius-sm, 6px)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TabGroupComponent, { className: "TabGroupComponent", filePath: "tab-group.component.ts", lineNumber: 23 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { TabComponent, TabGroupComponent };
//# sourceMappingURL=ciag-orchestra-tabs.mjs.map
