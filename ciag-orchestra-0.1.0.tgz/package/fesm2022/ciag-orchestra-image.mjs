import * as i0 from '@angular/core';
import { input, signal, computed, output, ChangeDetectionStrategy, Component } from '@angular/core';

function ImageComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "img", 2);
    i0.ɵɵlistener("load", function ImageComponent_Conditional_1_Template_img_load_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onLoad()); })("error", function ImageComponent_Conditional_1_Template_img_error_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onError($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("object-fit", ctx_r1.fit());
    i0.ɵɵproperty("src", ctx_r1.renderedSrc(), i0.ɵɵsanitizeUrl)("alt", ctx_r1.alt())("loading", ctx_r1.loading());
    i0.ɵɵattribute("aria-label", ctx_r1.ariaLabel() || null);
} }
function ImageComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-label", ctx_r1.ariaLabel() || ctx_r1.alt() || ctx_r1.placeholder());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.placeholder());
} }
class ImageComponent {
    src = input('');
    alt = input('');
    fallbackSrc = input('');
    fit = input('cover');
    width = input('');
    height = input('');
    loading = input('lazy');
    radius = input('md');
    placeholder = input('Imagem indisponível');
    ariaLabel = input('');
    usingFallback = signal(false);
    failed = signal(false);
    renderedSrc = computed(() => this.failed() ? '' : (this.usingFallback() ? this.fallbackSrc() : this.src()));
    loaded = output();
    error = output();
    onLoad() { this.loaded.emit(); }
    onError(event) {
        if (this.fallbackSrc() && !this.usingFallback()) {
            this.usingFallback.set(true);
            return;
        }
        this.failed.set(true);
        this.error.emit(event);
    }
    static ɵfac = function ImageComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ImageComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ImageComponent, selectors: [["orc-image"]], inputs: { src: [1, "src"], alt: [1, "alt"], fallbackSrc: [1, "fallbackSrc"], fit: [1, "fit"], width: [1, "width"], height: [1, "height"], loading: [1, "loading"], radius: [1, "radius"], placeholder: [1, "placeholder"], ariaLabel: [1, "ariaLabel"] }, outputs: { loaded: "loaded", error: "error" }, decls: 3, vars: 7, consts: [["decoding", "async", 3, "src", "alt", "loading", "object-fit"], ["role", "img", 1, "orc-image__placeholder"], ["decoding", "async", 3, "load", "error", "src", "alt", "loading"]], template: function ImageComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "figure");
            i0.ɵɵtemplate(1, ImageComponent_Conditional_1_Template, 1, 6, "img", 0)(2, ImageComponent_Conditional_2_Template, 2, 2, "div", 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMap("orc-image orc-image--" + ctx.radius());
            i0.ɵɵstyleProp("width", ctx.width() || null)("height", ctx.height() || null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.renderedSrc() ? 1 : 2);
        } }, styles: ["[_nghost-%COMP%]{display:block}.orc-image[_ngcontent-%COMP%]{display:block;width:100%;height:auto;margin:0;overflow:hidden;background:var(--orc-th, #f7f8fa)}.orc-image--none[_ngcontent-%COMP%]{border-radius:0}.orc-image--sm[_ngcontent-%COMP%]{border-radius:var(--radius-sm, 6px)}.orc-image--md[_ngcontent-%COMP%]{border-radius:var(--radius-md, 10px)}.orc-image--lg[_ngcontent-%COMP%]{border-radius:var(--radius-lg, 14px)}.orc-image--full[_ngcontent-%COMP%]{border-radius:999px}.orc-image[_ngcontent-%COMP%]   img[_ngcontent-%COMP%], .orc-image__placeholder[_ngcontent-%COMP%]{display:block;width:100%;height:100%;min-height:64px}.orc-image[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{object-position:center}.orc-image__placeholder[_ngcontent-%COMP%]{display:grid;place-items:center;padding:16px;box-sizing:border-box;color:var(--orc-font-secondary, #666);font-size:12px;text-align:center}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ImageComponent, [{
        type: Component,
        args: [{ selector: 'orc-image', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<figure\n  [class]=\"'orc-image orc-image--' + radius()\"\n  [style.width]=\"width() || null\"\n  [style.height]=\"height() || null\"\n>\n  @if (renderedSrc()) {\n    <img\n      [src]=\"renderedSrc()\"\n      [alt]=\"alt()\"\n      [loading]=\"loading()\"\n      decoding=\"async\"\n      [style.object-fit]=\"fit()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      (load)=\"onLoad()\"\n      (error)=\"onError($event)\"\n    />\n  } @else {\n    <div class=\"orc-image__placeholder\" role=\"img\" [attr.aria-label]=\"ariaLabel() || alt() || placeholder()\">{{ placeholder() }}</div>\n  }\n</figure>\n", styles: [":host{display:block}.orc-image{display:block;width:100%;height:auto;margin:0;overflow:hidden;background:var(--orc-th, #f7f8fa)}.orc-image--none{border-radius:0}.orc-image--sm{border-radius:var(--radius-sm, 6px)}.orc-image--md{border-radius:var(--radius-md, 10px)}.orc-image--lg{border-radius:var(--radius-lg, 14px)}.orc-image--full{border-radius:999px}.orc-image img,.orc-image__placeholder{display:block;width:100%;height:100%;min-height:64px}.orc-image img{object-position:center}.orc-image__placeholder{display:grid;place-items:center;padding:16px;box-sizing:border-box;color:var(--orc-font-secondary, #666);font-size:12px;text-align:center}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ImageComponent, { className: "ImageComponent", filePath: "image.component.ts", lineNumber: 19 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ImageComponent };
//# sourceMappingURL=ciag-orchestra-image.mjs.map
