import * as i0 from '@angular/core';
import { model, input, output, inject, PLATFORM_ID, effect, computed, ChangeDetectionStrategy, Component, ViewChild, createComponent, Injectable } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { ButtonComponent } from '@ciag/orchestra/button';

const _c0 = ["dialogRef"];
const _c1 = [[["", "modal-header", ""]], [["", "modal-body", ""]], [["", "modal-footer", ""]]];
const _c2 = ["[modal-header]", "[modal-body]", "[modal-footer]"];
function ModalComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "orc-button", 8);
    i0.ɵɵlistener("click", function ModalComponent_Conditional_6_Template_orc_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onClose()); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 9);
    i0.ɵɵelement(2, "line", 10)(3, "line", 11);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("iconOnly", true);
} }
class ModalComponent {
    // ── Referência ao elemento nativo <dialog> ─────────────────
    dialogRef;
    // ── Inputs e Models ─────────────────────────────────────────
    isOpen = model(false);
    size = input('md');
    status = input('neutral');
    inline = input(false);
    closeOnBackdropClick = input(true);
    showCloseButton = input(true);
    ariaLabelledBy = input('');
    ariaDescribedBy = input('');
    zIndex = input(1000);
    // ── Outputs ─────────────────────────────────────────────────
    closed = output();
    platformId = inject(PLATFORM_ID);
    isBrowser = isPlatformBrowser(this.platformId);
    previousActiveElement = null;
    constructor() {
        effect(() => {
            if (!this.isBrowser)
                return;
            if (this.inline())
                return; // Inline mode doesn't use showModal()
            const open = this.isOpen();
            const dialog = this.dialogRef?.nativeElement;
            if (!dialog)
                return;
            if (open && !dialog.open) {
                this.previousActiveElement = document.activeElement;
                dialog.showModal();
                document.body.style.overflow = 'hidden'; // Scroll lock
            }
            else if (!open && dialog.open) {
                dialog.close();
                document.body.style.removeProperty('overflow');
                if (this.previousActiveElement) {
                    this.previousActiveElement.focus();
                }
            }
        });
    }
    // ── Computed Classes ────────────────────────────────────────
    modalClasses = computed(() => {
        return {
            'orc-modal': true,
            'orc-modal--inline': this.inline(),
            [`orc-modal--size-${this.size()}`]: true,
            'orc-modal--status-danger': this.status() === 'danger',
            'orc-modal--fullscreen': this.size() === 'fullScreen'
        };
    });
    // ── Handlers ────────────────────────────────────────────────
    onClose() {
        if (this.isOpen()) {
            this.isOpen.set(false);
            this.closed.emit();
        }
    }
    onCancel(event) {
        // Disparado nativamente ao apertar 'Escape'
        event.preventDefault(); // Previne o fechamento nativo para centralizar o estado no isOpen
        this.onClose();
    }
    onBackdropClick(event) {
        if (!this.closeOnBackdropClick())
            return;
        const dialog = this.dialogRef.nativeElement;
        // O <dialog> cobre a tela inteira com seu backdrop.
        // O click nele tem rect bounds específicos. Se clicar fora do conteúdo interno, é o backdrop.
        const rect = dialog.getBoundingClientRect();
        const isInDialog = (rect.top <= event.clientY &&
            event.clientY <= rect.top + rect.height &&
            rect.left <= event.clientX &&
            event.clientX <= rect.left + rect.width);
        // Como o conteúdo real está no <div class="orc-modal__container">, 
        // clicar no dialog propriamente (se o padding não cobrir a tela) é backdrop.
        // Mas a forma mais segura é checar o target.
        if (event.target === dialog) {
            this.onClose();
        }
    }
    ngOnDestroy() {
        if (this.isBrowser) {
            document.body.style.removeProperty('overflow');
        }
    }
    static ɵfac = function ModalComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ModalComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ModalComponent, selectors: [["orc-modal"]], viewQuery: function ModalComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dialogRef = _t.first);
        } }, inputs: { isOpen: [1, "isOpen"], size: [1, "size"], status: [1, "status"], inline: [1, "inline"], closeOnBackdropClick: [1, "closeOnBackdropClick"], showCloseButton: [1, "showCloseButton"], ariaLabelledBy: [1, "ariaLabelledBy"], ariaDescribedBy: [1, "ariaDescribedBy"], zIndex: [1, "zIndex"] }, outputs: { isOpen: "isOpenChange", closed: "closed" }, ngContentSelectors: _c2, decls: 11, vars: 8, consts: [["dialogRef", ""], ["role", "dialog", "aria-modal", "true", 3, "cancel", "click"], [1, "orc-modal__container", 3, "click"], [1, "orc-modal__header"], [1, "orc-modal__header-content"], ["variant", "ghost", "size", "sm", "ariaLabel", "Fechar modal", 1, "orc-modal__close-btn", 3, "iconOnly"], [1, "orc-modal__body"], [1, "orc-modal__footer"], ["variant", "ghost", "size", "sm", "ariaLabel", "Fechar modal", 1, "orc-modal__close-btn", 3, "click", "iconOnly"], ["iconLeft", "", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x1", "18", "y1", "6", "x2", "6", "y2", "18"], ["x1", "6", "y1", "6", "x2", "18", "y2", "18"]], template: function ModalComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "dialog", 1, 0);
            i0.ɵɵlistener("cancel", function ModalComponent_Template_dialog_cancel_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onCancel($event)); })("click", function ModalComponent_Template_dialog_click_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBackdropClick($event)); });
            i0.ɵɵelementStart(2, "div", 2);
            i0.ɵɵlistener("click", function ModalComponent_Template_div_click_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
            i0.ɵɵelementStart(3, "header", 3)(4, "div", 4);
            i0.ɵɵprojection(5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, ModalComponent_Conditional_6_Template, 4, 1, "orc-button", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "main", 6);
            i0.ɵɵprojection(8, 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "footer", 7);
            i0.ɵɵprojection(10, 2);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵclassMap(ctx.modalClasses());
            i0.ɵɵstyleProp("z-index", ctx.inline() ? "auto" : ctx.zIndex());
            i0.ɵɵattribute("aria-labelledby", ctx.ariaLabelledBy() || null)("aria-describedby", ctx.ariaDescribedBy() || null)("open", ctx.inline() ? "" : null);
            i0.ɵɵadvance(6);
            i0.ɵɵconditional(ctx.showCloseButton() ? 6 : -1);
        } }, dependencies: [CommonModule, ButtonComponent], styles: [".orc-modal[_ngcontent-%COMP%]{padding:0;border:none;background:transparent;color:var(--text-primary);margin:auto;overflow:visible}.orc-modal[_ngcontent-%COMP%]::backdrop{background-color:#00000080;backdrop-filter:blur(4px);animation:_ngcontent-%COMP%_fadeIn .2s ease}.orc-modal[open][_ngcontent-%COMP%]:not(.orc-modal--inline){animation:_ngcontent-%COMP%_scaleUp .25s cubic-bezier(.16,1,.3,1)}.orc-modal--inline[_ngcontent-%COMP%]{position:relative;width:auto;height:auto;margin:0;display:flex}.orc-modal--inline[_ngcontent-%COMP%]::backdrop{display:none}.orc-modal--inline[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{margin:0;box-shadow:none}.orc-modal--status-danger[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{border-color:var(--color-error, #fb2c36)}.orc-modal--size-sm[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{max-width:400px;width:100%}.orc-modal--size-custom[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{width:100%}.orc-modal--size-md[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{max-width:560px;width:100%}.orc-modal--size-lg[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{max-width:800px;width:100%}.orc-modal--size-xl[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{max-width:1140px;width:100%}.orc-modal--fullscreen[_ngcontent-%COMP%]   .orc-modal__container[_ngcontent-%COMP%]{max-width:100vw;width:100vw;height:100vh;border-radius:0;max-height:100vh}.orc-modal__container[_ngcontent-%COMP%]{display:flex;flex-direction:column;background-color:var(--orc-fill-modal);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);max-height:calc(100vh - var(--space-16));width:calc(100vw - var(--space-6));margin:0 auto;padding:var(--space-5);gap:15px}.orc-modal__header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;flex-shrink:0}.orc-modal__header-content[_ngcontent-%COMP%]{flex:1;font-size:1.125rem;font-weight:600;color:var(--text-primary);margin-right:var(--space-4)}.orc-modal__header-content[_ngcontent-%COMP%]     h1, .orc-modal__header-content[_ngcontent-%COMP%]     h2, .orc-modal__header-content[_ngcontent-%COMP%]     h3, .orc-modal__header-content[_ngcontent-%COMP%]     h4, .orc-modal__header-content[_ngcontent-%COMP%]     h5, .orc-modal__header-content[_ngcontent-%COMP%]     h6{margin:0;font-size:inherit;font-weight:inherit;line-height:inherit}.orc-modal__close-btn[_ngcontent-%COMP%]{margin:-.25rem -.25rem -.25rem 0}.orc-modal__close-btn[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:18px;height:18px}.orc-modal__body[_ngcontent-%COMP%]{overflow-y:auto;flex:1 1 auto}.orc-modal__footer[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:flex-end;gap:16px;flex-shrink:0}.orc-modal__footer[_ngcontent-%COMP%]     [modal-footer]{display:flex;align-items:center;justify-content:flex-end;gap:16px;width:100%}@keyframes _ngcontent-%COMP%_fadeIn{0%{opacity:0}to{opacity:1}}@keyframes _ngcontent-%COMP%_scaleUp{0%{opacity:0;transform:scale(.96) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ModalComponent, [{
        type: Component,
        args: [{ selector: 'orc-modal', standalone: true, imports: [CommonModule, ButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<dialog\n  #dialogRef\n  [class]=\"modalClasses()\"\n  [style.z-index]=\"inline() ? 'auto' : zIndex()\"\n  (cancel)=\"onCancel($event)\"\n  (click)=\"onBackdropClick($event)\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n  [attr.aria-describedby]=\"ariaDescribedBy() || null\"\n  [attr.open]=\"inline() ? '' : null\"\n>\n  <div class=\"orc-modal__container\" (click)=\"$event.stopPropagation()\">\n    <!-- HEADER -->\n    <header class=\"orc-modal__header\">\n      <div class=\"orc-modal__header-content\">\n        <ng-content select=\"[modal-header]\"></ng-content>\n      </div>\n      \n      @if (showCloseButton()) {\n        <orc-button\n          variant=\"ghost\"\n          size=\"sm\"\n          [iconOnly]=\"true\"\n          (click)=\"onClose()\"\n          ariaLabel=\"Fechar modal\"\n          class=\"orc-modal__close-btn\"\n        >\n          <svg iconLeft viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      }\n    </header>\n\n    <!-- BODY -->\n    <main class=\"orc-modal__body\">\n      <ng-content select=\"[modal-body]\"></ng-content>\n    </main>\n\n    <!-- FOOTER -->\n    <footer class=\"orc-modal__footer\">\n      <ng-content select=\"[modal-footer]\"></ng-content>\n    </footer>\n  </div>\n</dialog>\n", styles: [".orc-modal{padding:0;border:none;background:transparent;color:var(--text-primary);margin:auto;overflow:visible}.orc-modal::backdrop{background-color:#00000080;backdrop-filter:blur(4px);animation:fadeIn .2s ease}.orc-modal[open]:not(.orc-modal--inline){animation:scaleUp .25s cubic-bezier(.16,1,.3,1)}.orc-modal--inline{position:relative;width:auto;height:auto;margin:0;display:flex}.orc-modal--inline::backdrop{display:none}.orc-modal--inline .orc-modal__container{margin:0;box-shadow:none}.orc-modal--status-danger .orc-modal__container{border-color:var(--color-error, #fb2c36)}.orc-modal--size-sm .orc-modal__container{max-width:400px;width:100%}.orc-modal--size-custom .orc-modal__container{width:100%}.orc-modal--size-md .orc-modal__container{max-width:560px;width:100%}.orc-modal--size-lg .orc-modal__container{max-width:800px;width:100%}.orc-modal--size-xl .orc-modal__container{max-width:1140px;width:100%}.orc-modal--fullscreen .orc-modal__container{max-width:100vw;width:100vw;height:100vh;border-radius:0;max-height:100vh}.orc-modal__container{display:flex;flex-direction:column;background-color:var(--orc-fill-modal);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);max-height:calc(100vh - var(--space-16));width:calc(100vw - var(--space-6));margin:0 auto;padding:var(--space-5);gap:15px}.orc-modal__header{display:flex;align-items:center;justify-content:space-between;flex-shrink:0}.orc-modal__header-content{flex:1;font-size:1.125rem;font-weight:600;color:var(--text-primary);margin-right:var(--space-4)}.orc-modal__header-content ::ng-deep h1,.orc-modal__header-content ::ng-deep h2,.orc-modal__header-content ::ng-deep h3,.orc-modal__header-content ::ng-deep h4,.orc-modal__header-content ::ng-deep h5,.orc-modal__header-content ::ng-deep h6{margin:0;font-size:inherit;font-weight:inherit;line-height:inherit}.orc-modal__close-btn{margin:-.25rem -.25rem -.25rem 0}.orc-modal__close-btn svg{width:18px;height:18px}.orc-modal__body{overflow-y:auto;flex:1 1 auto}.orc-modal__footer{display:flex;align-items:center;justify-content:flex-end;gap:16px;flex-shrink:0}.orc-modal__footer ::ng-deep [modal-footer]{display:flex;align-items:center;justify-content:flex-end;gap:16px;width:100%}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes scaleUp{0%{opacity:0;transform:scale(.96) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}\n"] }]
    }], () => [], { dialogRef: [{
            type: ViewChild,
            args: ['dialogRef']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ModalComponent, { className: "ModalComponent", filePath: "modal.component.ts", lineNumber: 29 }); })();

class ModalRef {
    componentRef;
    destroyCallback;
    constructor(componentRef, destroyCallback) {
        this.componentRef = componentRef;
        this.destroyCallback = destroyCallback;
    }
    get instance() {
        return this.componentRef.instance;
    }
    close() {
        this.destroyCallback();
    }
}

class ModalService {
    appRef;
    injector;
    constructor(appRef, injector) {
        this.appRef = appRef;
        this.injector = injector;
    }
    /**
     * Abre um componente dinamicamente.
     * O componente injetado DEVE conter a tag <orc-modal> com [isOpen]="true" internamente,
     * para que o modal nativo assuma a camada de visualização (Top Layer do HTML5).
     */
    open(component, inputs) {
        // 1. Instanciar o componente dinamicamente
        const componentRef = createComponent(component, {
            environmentInjector: this.injector,
        });
        // 2. Setar inputs se fornecidos
        if (inputs) {
            Object.entries(inputs).forEach(([key, value]) => {
                componentRef.setInput(key, value);
            });
        }
        // 3. Atachar à árvore de views do Angular para detecção de mudanças
        this.appRef.attachView(componentRef.hostView);
        // 4. Inserir no DOM
        const domElem = componentRef.hostView.rootNodes[0];
        document.body.appendChild(domElem);
        // 5. Configurar lógica de destruição
        const destroyFn = () => {
            this.appRef.detachView(componentRef.hostView);
            componentRef.destroy();
        };
        return new ModalRef(componentRef, destroyFn);
    }
    static ɵfac = function ModalService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ModalService)(i0.ɵɵinject(i0.ApplicationRef), i0.ɵɵinject(i0.EnvironmentInjector)); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ModalService, factory: ModalService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ModalService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], () => [{ type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }], null); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ModalComponent, ModalRef, ModalService };
//# sourceMappingURL=ciag-orchestra-modal.mjs.map
