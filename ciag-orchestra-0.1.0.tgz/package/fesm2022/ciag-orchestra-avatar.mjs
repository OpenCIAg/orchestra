import * as i0 from '@angular/core';
import { input, output, signal, effect, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

function AvatarComponent_img_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "img", 5);
    i0.ɵɵlistener("error", function AvatarComponent_img_1_Template_img_error_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onImageError($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("src", ctx_r1.src(), i0.ɵɵsanitizeUrl)("alt", ctx_r1.alt() || ctx_r1.accessibleLabel());
} }
function AvatarComponent_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 6);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.computedInitials(), " ");
} }
function AvatarComponent__svg_svg_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 7);
    i0.ɵɵelement(1, "path", 8)(2, "circle", 9);
    i0.ɵɵelementEnd();
} }
function AvatarComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 10);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-avatar__status--online", ctx_r1.status() === "online")("orc-avatar__status--offline", ctx_r1.status() === "offline")("orc-avatar__status--busy", ctx_r1.status() === "busy")("orc-avatar__status--away", ctx_r1.status() === "away")("orc-avatar__status--top-right", ctx_r1.statusPosition() === "top-right")("orc-avatar__status--bottom-right", ctx_r1.statusPosition() === "bottom-right")("orc-avatar__status--top-left", ctx_r1.statusPosition() === "top-left")("orc-avatar__status--bottom-left", ctx_r1.statusPosition() === "bottom-left");
    i0.ɵɵproperty("title", ctx_r1.statusText());
    i0.ɵɵattribute("aria-label", ctx_r1.statusText());
} }
class AvatarComponent {
    // Inputs (Signals API)
    src = input('');
    name = input('');
    initials = input('');
    alt = input('');
    size = input('md');
    shape = input('circular');
    status = input(undefined);
    statusPosition = input('bottom-right');
    colorVariant = input('default');
    bordered = input(false);
    clickable = input(false);
    // Outputs (Signals API)
    imageError = output();
    avatarClick = output();
    // Estado interno para controle de erro no carregamento da imagem
    imageFailed = signal(false);
    constructor() {
        // Reseta estado de erro caso a URL da imagem mude
        effect(() => {
            this.src();
            this.imageFailed.set(false);
        }, { allowSignalWrites: true });
    }
    // ── Sinais Computados ──────────────────────────────────────
    showImage = computed(() => {
        return Boolean(this.src() && !this.imageFailed());
    });
    computedInitials = computed(() => {
        if (this.initials()) {
            return this.initials().trim().toUpperCase().slice(0, 3);
        }
        const fullName = this.name()?.trim();
        if (!fullName)
            return '';
        const parts = fullName.split(/\s+/).filter(Boolean);
        if (parts.length === 1) {
            return parts[0].slice(0, 2).toUpperCase();
        }
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    });
    hasInitials = computed(() => {
        return !this.showImage() && Boolean(this.computedInitials());
    });
    showIcon = computed(() => {
        return !this.showImage() && !this.hasInitials();
    });
    effectiveColorVariant = computed(() => {
        const variant = this.colorVariant();
        if (variant !== 'auto') {
            return variant;
        }
        const key = this.name() || this.initials() || '';
        if (!key)
            return 'default';
        const variants = ['primary', 'royal', 'orange', 'purple'];
        let hash = 0;
        for (let i = 0; i < key.length; i++) {
            hash = key.charCodeAt(i) + ((hash << 5) - hash);
        }
        const index = Math.abs(hash) % variants.length;
        return variants[index];
    });
    accessibleLabel = computed(() => {
        if (this.alt())
            return this.alt();
        if (this.name())
            return `Avatar de ${this.name()}`;
        if (this.computedInitials())
            return `Avatar ${this.computedInitials()}`;
        return 'Avatar do usuário';
    });
    statusText = computed(() => {
        switch (this.status()) {
            case 'online':
                return 'Online';
            case 'offline':
                return 'Offline';
            case 'busy':
                return 'Ocupado';
            case 'away':
                return 'Ausente';
            default:
                return '';
        }
    });
    // ── Event Handlers ────────────────────────────────────────
    onImageError(event) {
        this.imageFailed.set(true);
        this.imageError.emit(event);
    }
    onClick(event) {
        if (this.clickable()) {
            this.avatarClick.emit(event);
        }
    }
    static ɵfac = function AvatarComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AvatarComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AvatarComponent, selectors: [["orc-avatar"]], inputs: { src: [1, "src"], name: [1, "name"], initials: [1, "initials"], alt: [1, "alt"], size: [1, "size"], shape: [1, "shape"], status: [1, "status"], statusPosition: [1, "statusPosition"], colorVariant: [1, "colorVariant"], bordered: [1, "bordered"], clickable: [1, "clickable"] }, outputs: { imageError: "imageError", avatarClick: "avatarClick" }, decls: 5, vars: 38, consts: [["role", "img", 1, "orc-avatar", 3, "click", "keydown.enter", "keydown.space"], ["class", "orc-avatar__img", "loading", "lazy", 3, "src", "alt", "error", 4, "ngIf"], ["class", "orc-avatar__initials", "aria-hidden", "true", 4, "ngIf"], ["class", "orc-avatar__icon", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 4, "ngIf"], ["class", "orc-avatar__status", 3, "orc-avatar__status--online", "orc-avatar__status--offline", "orc-avatar__status--busy", "orc-avatar__status--away", "orc-avatar__status--top-right", "orc-avatar__status--bottom-right", "orc-avatar__status--top-left", "orc-avatar__status--bottom-left", "title", 4, "ngIf"], ["loading", "lazy", 1, "orc-avatar__img", 3, "error", "src", "alt"], ["aria-hidden", "true", 1, "orc-avatar__initials"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 1, "orc-avatar__icon"], ["d", "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"], ["cx", "12", "cy", "7", "r", "4"], [1, "orc-avatar__status", 3, "title"]], template: function AvatarComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("click", function AvatarComponent_Template_div_click_0_listener($event) { return ctx.onClick($event); })("keydown.enter", function AvatarComponent_Template_div_keydown_enter_0_listener($event) { return ctx.onClick($event); })("keydown.space", function AvatarComponent_Template_div_keydown_space_0_listener($event) { return ctx.onClick($event); });
            i0.ɵɵtemplate(1, AvatarComponent_img_1_Template, 1, 2, "img", 1)(2, AvatarComponent_span_2_Template, 2, 1, "span", 2)(3, AvatarComponent__svg_svg_3_Template, 3, 0, "svg", 3)(4, AvatarComponent_span_4_Template, 1, 18, "span", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-avatar--size-xs", ctx.size() === "xs")("orc-avatar--size-sm", ctx.size() === "sm")("orc-avatar--size-md", ctx.size() === "md")("orc-avatar--size-lg", ctx.size() === "lg")("orc-avatar--size-xl", ctx.size() === "xl")("orc-avatar--shape-circular", ctx.shape() === "circular")("orc-avatar--shape-rounded", ctx.shape() === "rounded")("orc-avatar--shape-square", ctx.shape() === "square")("orc-avatar--bordered", ctx.bordered())("orc-avatar--clickable", ctx.clickable())("orc-avatar--variant-default", ctx.effectiveColorVariant() === "default")("orc-avatar--variant-primary", ctx.effectiveColorVariant() === "primary")("orc-avatar--variant-royal", ctx.effectiveColorVariant() === "royal")("orc-avatar--variant-orange", ctx.effectiveColorVariant() === "orange")("orc-avatar--variant-purple", ctx.effectiveColorVariant() === "purple")("orc-avatar--variant-cyan", ctx.effectiveColorVariant() === "cyan");
            i0.ɵɵattribute("aria-label", ctx.accessibleLabel())("tabindex", ctx.clickable() ? 0 : null);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showImage());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.hasInitials());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showIcon());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.status());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-avatar[_ngcontent-%COMP%]{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;box-sizing:border-box;overflow:visible;transition:transform var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-avatar--size-xs[_ngcontent-%COMP%]{width:24px;height:24px;font-size:.6875rem;--status-size: 6px;--status-offset: -1px;--icon-size: 14px;--border-radius-rounded: 6px}.orc-avatar--size-sm[_ngcontent-%COMP%]{width:32px;height:32px;font-size:.75rem;--status-size: 8px;--status-offset: -1px;--icon-size: 16px;--border-radius-rounded: 8px}.orc-avatar--size-md[_ngcontent-%COMP%]{width:40px;height:40px;font-size:.9375rem;--status-size: 10px;--status-offset: 0px;--icon-size: 20px;--border-radius-rounded: 10px}.orc-avatar--size-lg[_ngcontent-%COMP%]{width:48px;height:48px;font-size:1.0625rem;--status-size: 12px;--status-offset: 1px;--icon-size: 24px;--border-radius-rounded: 12px}.orc-avatar--size-xl[_ngcontent-%COMP%]{width:64px;height:64px;font-size:1.375rem;--status-size: 14px;--status-offset: 2px;--icon-size: 32px;--border-radius-rounded: 16px}.orc-avatar--shape-circular[_ngcontent-%COMP%], .orc-avatar--shape-circular[_ngcontent-%COMP%]   .orc-avatar__img[_ngcontent-%COMP%]{border-radius:9999px}.orc-avatar--shape-rounded[_ngcontent-%COMP%], .orc-avatar--shape-rounded[_ngcontent-%COMP%]   .orc-avatar__img[_ngcontent-%COMP%]{border-radius:var(--border-radius-rounded, 10px)}.orc-avatar--shape-square[_ngcontent-%COMP%], .orc-avatar--shape-square[_ngcontent-%COMP%]   .orc-avatar__img[_ngcontent-%COMP%]{border-radius:0}.orc-avatar--bordered[_ngcontent-%COMP%]{box-shadow:0 0 0 2px var(--orc-bg, #ffffff)}.orc-avatar--variant-default[_ngcontent-%COMP%]{background-color:#ececf0;color:#0a0a0a}.orc-avatar--variant-primary[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-avatar--variant-royal[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-royal, #0406ab);color:#fff}.orc-avatar--variant-orange[_ngcontent-%COMP%]{background-color:var(--orc-color-laranja, #ff6a1c);color:#fff}.orc-avatar--variant-purple[_ngcontent-%COMP%]{background-color:var(--orc-color-roxo-lavender, #6a1ced);color:#fff}.orc-avatar--variant-cyan[_ngcontent-%COMP%]{background-color:var(--orc-color-ciano, #1cedb9);color:#141414}.orc-avatar__img[_ngcontent-%COMP%]{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}.orc-avatar__initials[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;line-height:1;letter-spacing:.02em;font-weight:500}.orc-avatar__icon[_ngcontent-%COMP%]{width:var(--icon-size, 20px);height:var(--icon-size, 20px);opacity:.75}.orc-avatar__status[_ngcontent-%COMP%]{position:absolute;width:var(--status-size, 10px);height:var(--status-size, 10px);border-radius:9999px;border:2px solid var(--orc-bg, #ffffff);box-sizing:content-box;z-index:2}.orc-avatar__status--bottom-right[_ngcontent-%COMP%]{bottom:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--top-right[_ngcontent-%COMP%]{top:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--bottom-left[_ngcontent-%COMP%]{bottom:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--top-left[_ngcontent-%COMP%]{top:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--online[_ngcontent-%COMP%]{background-color:#22c55e}.orc-avatar__status--busy[_ngcontent-%COMP%]{background-color:var(--color-error, #fb2c36)}.orc-avatar__status--away[_ngcontent-%COMP%]{background-color:var(--color-warning, #fe9a00)}.orc-avatar__status--offline[_ngcontent-%COMP%]{background-color:#999}.orc-avatar--clickable[_ngcontent-%COMP%]{cursor:pointer}.orc-avatar--clickable[_ngcontent-%COMP%]:hover{opacity:.9;transform:translateY(-1px)}.orc-avatar--clickable[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AvatarComponent, [{
        type: Component,
        args: [{ selector: 'orc-avatar', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-avatar\"\n  [class.orc-avatar--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar--size-md]=\"size() === 'md'\"\n  [class.orc-avatar--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar--size-xl]=\"size() === 'xl'\"\n  [class.orc-avatar--shape-circular]=\"shape() === 'circular'\"\n  [class.orc-avatar--shape-rounded]=\"shape() === 'rounded'\"\n  [class.orc-avatar--shape-square]=\"shape() === 'square'\"\n  [class.orc-avatar--bordered]=\"bordered()\"\n  [class.orc-avatar--clickable]=\"clickable()\"\n  [class.orc-avatar--variant-default]=\"effectiveColorVariant() === 'default'\"\n  [class.orc-avatar--variant-primary]=\"effectiveColorVariant() === 'primary'\"\n  [class.orc-avatar--variant-royal]=\"effectiveColorVariant() === 'royal'\"\n  [class.orc-avatar--variant-orange]=\"effectiveColorVariant() === 'orange'\"\n  [class.orc-avatar--variant-purple]=\"effectiveColorVariant() === 'purple'\"\n  [class.orc-avatar--variant-cyan]=\"effectiveColorVariant() === 'cyan'\"\n  role=\"img\"\n  [attr.aria-label]=\"accessibleLabel()\"\n  [attr.tabindex]=\"clickable() ? 0 : null\"\n  (click)=\"onClick($event)\"\n  (keydown.enter)=\"onClick($any($event))\"\n  (keydown.space)=\"onClick($any($event))\"\n>\n  <!-- Imagem do Avatar -->\n  <img\n    *ngIf=\"showImage()\"\n    [src]=\"src()\"\n    [alt]=\"alt() || accessibleLabel()\"\n    (error)=\"onImageError($event)\"\n    class=\"orc-avatar__img\"\n    loading=\"lazy\"\n  />\n\n  <!-- Iniciais do Usu\u00E1rio -->\n  <span *ngIf=\"hasInitials()\" class=\"orc-avatar__initials\" aria-hidden=\"true\">\n    {{ computedInitials() }}\n  </span>\n\n  <!-- \u00CDcone Fallback Padr\u00E3o -->\n  <svg\n    *ngIf=\"showIcon()\"\n    class=\"orc-avatar__icon\"\n    viewBox=\"0 0 24 24\"\n    fill=\"none\"\n    stroke=\"currentColor\"\n    stroke-width=\"2\"\n    stroke-linecap=\"round\"\n    stroke-linejoin=\"round\"\n    aria-hidden=\"true\"\n  >\n    <path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\" />\n    <circle cx=\"12\" cy=\"7\" r=\"4\" />\n  </svg>\n\n  <!-- Indicador de Status (Online/Offline/Busy/Away) -->\n  <span\n    *ngIf=\"status()\"\n    class=\"orc-avatar__status\"\n    [class.orc-avatar__status--online]=\"status() === 'online'\"\n    [class.orc-avatar__status--offline]=\"status() === 'offline'\"\n    [class.orc-avatar__status--busy]=\"status() === 'busy'\"\n    [class.orc-avatar__status--away]=\"status() === 'away'\"\n    [class.orc-avatar__status--top-right]=\"statusPosition() === 'top-right'\"\n    [class.orc-avatar__status--bottom-right]=\"statusPosition() === 'bottom-right'\"\n    [class.orc-avatar__status--top-left]=\"statusPosition() === 'top-left'\"\n    [class.orc-avatar__status--bottom-left]=\"statusPosition() === 'bottom-left'\"\n    [attr.aria-label]=\"statusText()\"\n    [title]=\"statusText()\"\n  ></span>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;box-sizing:border-box;overflow:visible;transition:transform var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-avatar--size-xs{width:24px;height:24px;font-size:.6875rem;--status-size: 6px;--status-offset: -1px;--icon-size: 14px;--border-radius-rounded: 6px}.orc-avatar--size-sm{width:32px;height:32px;font-size:.75rem;--status-size: 8px;--status-offset: -1px;--icon-size: 16px;--border-radius-rounded: 8px}.orc-avatar--size-md{width:40px;height:40px;font-size:.9375rem;--status-size: 10px;--status-offset: 0px;--icon-size: 20px;--border-radius-rounded: 10px}.orc-avatar--size-lg{width:48px;height:48px;font-size:1.0625rem;--status-size: 12px;--status-offset: 1px;--icon-size: 24px;--border-radius-rounded: 12px}.orc-avatar--size-xl{width:64px;height:64px;font-size:1.375rem;--status-size: 14px;--status-offset: 2px;--icon-size: 32px;--border-radius-rounded: 16px}.orc-avatar--shape-circular,.orc-avatar--shape-circular .orc-avatar__img{border-radius:9999px}.orc-avatar--shape-rounded,.orc-avatar--shape-rounded .orc-avatar__img{border-radius:var(--border-radius-rounded, 10px)}.orc-avatar--shape-square,.orc-avatar--shape-square .orc-avatar__img{border-radius:0}.orc-avatar--bordered{box-shadow:0 0 0 2px var(--orc-bg, #ffffff)}.orc-avatar--variant-default{background-color:#ececf0;color:#0a0a0a}.orc-avatar--variant-primary{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-avatar--variant-royal{background-color:var(--orc-color-azul-royal, #0406ab);color:#fff}.orc-avatar--variant-orange{background-color:var(--orc-color-laranja, #ff6a1c);color:#fff}.orc-avatar--variant-purple{background-color:var(--orc-color-roxo-lavender, #6a1ced);color:#fff}.orc-avatar--variant-cyan{background-color:var(--orc-color-ciano, #1cedb9);color:#141414}.orc-avatar__img{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}.orc-avatar__initials{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;line-height:1;letter-spacing:.02em;font-weight:500}.orc-avatar__icon{width:var(--icon-size, 20px);height:var(--icon-size, 20px);opacity:.75}.orc-avatar__status{position:absolute;width:var(--status-size, 10px);height:var(--status-size, 10px);border-radius:9999px;border:2px solid var(--orc-bg, #ffffff);box-sizing:content-box;z-index:2}.orc-avatar__status--bottom-right{bottom:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--top-right{top:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--bottom-left{bottom:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--top-left{top:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--online{background-color:#22c55e}.orc-avatar__status--busy{background-color:var(--color-error, #fb2c36)}.orc-avatar__status--away{background-color:var(--color-warning, #fe9a00)}.orc-avatar__status--offline{background-color:#999}.orc-avatar--clickable{cursor:pointer}.orc-avatar--clickable:hover{opacity:.9;transform:translateY(-1px)}.orc-avatar--clickable:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}\n"] }]
    }], () => [], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AvatarComponent, { className: "AvatarComponent", filePath: "avatar.component.ts", lineNumber: 27 }); })();

const _c0 = ["*"];
function AvatarGroupComponent_ng_container_1_orc_avatar_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "orc-avatar", 4);
} if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", item_r1.src || "")("name", item_r1.name || "")("initials", item_r1.initials || "")("alt", item_r1.alt || "")("size", ctx_r1.size())("shape", ctx_r1.shape())("status", item_r1.status)("colorVariant", item_r1.colorVariant || "default")("bordered", ctx_r1.bordered());
} }
function AvatarGroupComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, AvatarGroupComponent_ng_container_1_orc_avatar_1_Template, 1, 9, "orc-avatar", 3);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.visibleItems());
} }
function AvatarGroupComponent_orc_avatar_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "orc-avatar", 5);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("initials", ctx_r1.excessText())("size", ctx_r1.size())("shape", ctx_r1.shape())("colorVariant", ctx_r1.excessColorVariant())("bordered", ctx_r1.bordered())("alt", "Mais " + ctx_r1.calculatedExcess() + " membros");
} }
class AvatarGroupComponent {
    // Inputs (Signals API)
    items = input([]);
    max = input(0);
    size = input('md');
    shape = input('circular');
    excessCount = input(0);
    excessColorVariant = input('default');
    bordered = input(true);
    // Sinais computados
    visibleItems = computed(() => {
        const list = this.items();
        const limit = this.max();
        if (limit > 0 && list.length > limit) {
            return list.slice(0, limit);
        }
        return list;
    });
    calculatedExcess = computed(() => {
        if (this.excessCount() > 0) {
            return this.excessCount();
        }
        const limit = this.max();
        const total = this.items().length;
        if (limit > 0 && total > limit) {
            return total - limit;
        }
        return 0;
    });
    excessText = computed(() => {
        const excess = this.calculatedExcess();
        return excess > 0 ? `+${excess}` : '';
    });
    static ɵfac = function AvatarGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || AvatarGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AvatarGroupComponent, selectors: [["orc-avatar-group"]], inputs: { items: [1, "items"], max: [1, "max"], size: [1, "size"], shape: [1, "shape"], excessCount: [1, "excessCount"], excessColorVariant: [1, "excessColorVariant"], bordered: [1, "bordered"] }, ngContentSelectors: _c0, decls: 4, vars: 12, consts: [["role", "group", "aria-label", "Grupo de avatares", 1, "orc-avatar-group"], [4, "ngIf"], ["class", "orc-avatar-group__item orc-avatar-group__excess", 3, "initials", "size", "shape", "colorVariant", "bordered", "alt", 4, "ngIf"], ["class", "orc-avatar-group__item", 3, "src", "name", "initials", "alt", "size", "shape", "status", "colorVariant", "bordered", 4, "ngFor", "ngForOf"], [1, "orc-avatar-group__item", 3, "src", "name", "initials", "alt", "size", "shape", "status", "colorVariant", "bordered"], [1, "orc-avatar-group__item", "orc-avatar-group__excess", 3, "initials", "size", "shape", "colorVariant", "bordered", "alt"]], template: function AvatarGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, AvatarGroupComponent_ng_container_1_Template, 2, 1, "ng-container", 1);
            i0.ɵɵprojection(2);
            i0.ɵɵtemplate(3, AvatarGroupComponent_orc_avatar_3_Template, 1, 6, "orc-avatar", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-avatar-group--size-xs", ctx.size() === "xs")("orc-avatar-group--size-sm", ctx.size() === "sm")("orc-avatar-group--size-md", ctx.size() === "md")("orc-avatar-group--size-lg", ctx.size() === "lg")("orc-avatar-group--size-xl", ctx.size() === "xl");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.items().length > 0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.calculatedExcess() > 0);
        } }, dependencies: [CommonModule, i1.NgForOf, i1.NgIf, AvatarComponent], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-avatar-group[_ngcontent-%COMP%]{display:inline-flex;align-items:center;flex-direction:row;--group-overlap: -12px}.orc-avatar-group--size-xs[_ngcontent-%COMP%]{--group-overlap: -8px}.orc-avatar-group--size-sm[_ngcontent-%COMP%]{--group-overlap: -10px}.orc-avatar-group--size-md[_ngcontent-%COMP%]{--group-overlap: -12px}.orc-avatar-group--size-lg[_ngcontent-%COMP%]{--group-overlap: -14px}.orc-avatar-group--size-xl[_ngcontent-%COMP%]{--group-overlap: -18px}.orc-avatar-group[_ngcontent-%COMP%]    >app-avatar, .orc-avatar-group[_ngcontent-%COMP%]   .orc-avatar-group__item[_ngcontent-%COMP%]{position:relative;transition:transform var(--transition-fast, .12s ease),z-index var(--transition-fast, .12s ease)}.orc-avatar-group[_ngcontent-%COMP%]    >app-avatar .orc-avatar, .orc-avatar-group[_ngcontent-%COMP%]   .orc-avatar-group__item[_ngcontent-%COMP%]   .orc-avatar[_ngcontent-%COMP%]{box-shadow:0 0 0 2px var(--orc-bg, #ffffff)}.orc-avatar-group[_ngcontent-%COMP%]    >app-avatar:not(:first-child), .orc-avatar-group[_ngcontent-%COMP%]   .orc-avatar-group__item[_ngcontent-%COMP%]:not(:first-child){margin-left:var(--group-overlap)}.orc-avatar-group[_ngcontent-%COMP%]    >app-avatar:hover, .orc-avatar-group[_ngcontent-%COMP%]   .orc-avatar-group__item[_ngcontent-%COMP%]:hover{z-index:10!important;transform:translateY(-2px) scale(1.08)}.orc-avatar-group__excess[_ngcontent-%COMP%]   .orc-avatar[_ngcontent-%COMP%]{background-color:#ececf0;color:#0a0a0a;font-weight:500}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AvatarGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-avatar-group', standalone: true, imports: [CommonModule, AvatarComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-avatar-group\"\n  [class.orc-avatar-group--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar-group--size-md]=\"size() === 'md'\"\n  [class.orc-avatar-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar-group--size-xl]=\"size() === 'xl'\"\n  role=\"group\"\n  aria-label=\"Grupo de avatares\"\n>\n  <!-- Modo com lista de items informada via input -->\n  <ng-container *ngIf=\"items().length > 0\">\n    <orc-avatar\n      *ngFor=\"let item of visibleItems()\"\n      [src]=\"item.src || ''\"\n      [name]=\"item.name || ''\"\n      [initials]=\"item.initials || ''\"\n      [alt]=\"item.alt || ''\"\n      [size]=\"size()\"\n      [shape]=\"shape()\"\n      [status]=\"item.status\"\n      [colorVariant]=\"item.colorVariant || 'default'\"\n      [bordered]=\"bordered()\"\n      class=\"orc-avatar-group__item\"\n    ></orc-avatar>\n  </ng-container>\n\n  <!-- Proje\u00E7\u00E3o de conte\u00FAdo quando items n\u00E3o for informado -->\n  <ng-content></ng-content>\n\n  <!-- Contador Excedente (+N) -->\n  <orc-avatar\n    *ngIf=\"calculatedExcess() > 0\"\n    [initials]=\"excessText()\"\n    [size]=\"size()\"\n    [shape]=\"shape()\"\n    [colorVariant]=\"excessColorVariant()\"\n    [bordered]=\"bordered()\"\n    [alt]=\"'Mais ' + calculatedExcess() + ' membros'\"\n    class=\"orc-avatar-group__item orc-avatar-group__excess\"\n  ></orc-avatar>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar-group{display:inline-flex;align-items:center;flex-direction:row;--group-overlap: -12px}.orc-avatar-group--size-xs{--group-overlap: -8px}.orc-avatar-group--size-sm{--group-overlap: -10px}.orc-avatar-group--size-md{--group-overlap: -12px}.orc-avatar-group--size-lg{--group-overlap: -14px}.orc-avatar-group--size-xl{--group-overlap: -18px}.orc-avatar-group ::ng-deep>app-avatar,.orc-avatar-group .orc-avatar-group__item{position:relative;transition:transform var(--transition-fast, .12s ease),z-index var(--transition-fast, .12s ease)}.orc-avatar-group ::ng-deep>app-avatar .orc-avatar,.orc-avatar-group .orc-avatar-group__item .orc-avatar{box-shadow:0 0 0 2px var(--orc-bg, #ffffff)}.orc-avatar-group ::ng-deep>app-avatar:not(:first-child),.orc-avatar-group .orc-avatar-group__item:not(:first-child){margin-left:var(--group-overlap)}.orc-avatar-group ::ng-deep>app-avatar:hover,.orc-avatar-group .orc-avatar-group__item:hover{z-index:10!important;transform:translateY(-2px) scale(1.08)}.orc-avatar-group__excess .orc-avatar{background-color:#ececf0;color:#0a0a0a;font-weight:500}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(AvatarGroupComponent, { className: "AvatarGroupComponent", filePath: "avatar-group.component.ts", lineNumber: 24 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { AvatarComponent, AvatarGroupComponent };
//# sourceMappingURL=ciag-orchestra-avatar.mjs.map
