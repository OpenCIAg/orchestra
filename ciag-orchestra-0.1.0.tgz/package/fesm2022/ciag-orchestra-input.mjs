import * as i0 from '@angular/core';
import { viewChild, input, booleanAttribute, numberAttribute, model, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

/**
 * Utilitário de máscara leve e sem dependências externas.
 * Suporta tokens padrão:
 * - `0` ou `9`: Apenas dígitos numéricos (0-9)
 * - `A` ou `a`: Apenas letras (a-z, A-Z)
 * - `*`: Alfanumérico (letras e números)
 */
function applyMask(rawVal, maskPattern) {
    if (!rawVal || !maskPattern)
        return rawVal;
    const rawChars = String(rawVal).split('');
    let formatted = '';
    let rawIdx = 0;
    for (let mIdx = 0; mIdx < maskPattern.length && rawIdx < rawChars.length; mIdx++) {
        const maskChar = maskPattern[mIdx];
        const rawChar = rawChars[rawIdx];
        if (maskChar === '0' || maskChar === '9') {
            if (/\d/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                // Ignora caractere não numérico da entrada bruta e tenta o próximo
                rawIdx++;
                mIdx--; // repete a posição da máscara
            }
        }
        else if (maskChar === 'A' || maskChar === 'a') {
            if (/[a-zA-Z]/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                rawIdx++;
                mIdx--;
            }
        }
        else if (maskChar === '*') {
            if (/[a-zA-Z0-9]/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                rawIdx++;
                mIdx--;
            }
        }
        else {
            // Caractere literal da máscara (ex: '.', '-', '(', ')', '/', ' ')
            formatted += maskChar;
            if (rawChar === maskChar) {
                rawIdx++;
            }
        }
    }
    return formatted;
}
function cleanMask(formattedVal, maskPattern) {
    if (!formattedVal || !maskPattern)
        return formattedVal;
    // Extrai apenas os caracteres que correspondem aos tokens dinâmicos da máscara
    let clean = '';
    const specialChars = new Set(maskPattern.replace(/[09Aa*]/g, '').split(''));
    for (const ch of String(formattedVal)) {
        if (!specialChars.has(ch)) {
            clean += ch;
        }
    }
    return clean;
}

const _c0$1 = ["nativeInput"];
const _c1 = [[["", "prefix", ""], ["", "orcPrefix", ""]], [["", "suffix", ""], ["", "orcSuffix", ""]]];
const _c2 = ["[prefix], [orcPrefix]", "[suffix], [orcSuffix]"];
function InputComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function InputComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, InputComponent_Conditional_1_Conditional_2_Template, 2, 0, "span", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r1.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.required() ? 2 : -1);
} }
function InputComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.prefixText());
} }
function InputComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 12);
    i0.ɵɵlistener("click", function InputComponent_Conditional_8_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onClear($event)); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 13);
    i0.ɵɵelement(2, "path", 14);
    i0.ɵɵelementEnd()();
} }
function InputComponent_Conditional_9_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 16);
    i0.ɵɵelement(1, "path", 17)(2, "line", 18);
    i0.ɵɵelementEnd();
} }
function InputComponent_Conditional_9_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 16);
    i0.ɵɵelement(1, "path", 19)(2, "circle", 20);
    i0.ɵɵelementEnd();
} }
function InputComponent_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 15);
    i0.ɵɵlistener("click", function InputComponent_Conditional_9_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.togglePasswordVisibility($event)); });
    i0.ɵɵtemplate(1, InputComponent_Conditional_9_Conditional_1_Template, 3, 0, ":svg:svg", 16)(2, InputComponent_Conditional_9_Conditional_2_Template, 3, 0, ":svg:svg", 16);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵattribute("aria-label", ctx_r1.isPasswordVisible() ? "Ocultar senha" : "Exibir senha");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.isPasswordVisible() ? 1 : 2);
} }
function InputComponent_Conditional_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.suffixText());
} }
function InputComponent_Conditional_13_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 22);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 25);
    i0.ɵɵelement(2, "path", 26);
    i0.ɵɵelementEnd();
    i0.ɵɵnamespaceHTML();
    i0.ɵɵelementStart(3, "span");
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.errorId());
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r1.errorMessage());
} }
function InputComponent_Conditional_13_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.helperId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.helperText(), " ");
} }
function InputComponent_Conditional_13_Conditional_4_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵtextInterpolate1(" / ", ctx_r1.maxLength(), " ");
} }
function InputComponent_Conditional_13_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 27);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, InputComponent_Conditional_13_Conditional_4_Conditional_2_Template, 1, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("orc-input__char-count--limit", ctx_r1.maxLength() && ctx_r1.charCount() >= ctx_r1.maxLength());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.charCount(), "");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.maxLength() ? 2 : -1);
} }
function InputComponent_Conditional_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 10)(1, "div", 21);
    i0.ɵɵtemplate(2, InputComponent_Conditional_13_Conditional_2_Template, 5, 2, "p", 22)(3, InputComponent_Conditional_13_Conditional_3_Template, 2, 2, "p", 23);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, InputComponent_Conditional_13_Conditional_4_Template, 3, 4, "span", 24);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.status() === "error" && ctx_r1.errorMessage() ? 2 : ctx_r1.helperText() ? 3 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.showCharCount() ? 4 : -1);
} }
let nextInputUniqueId = 0;
class InputComponent {
    uniqueId = `orc-input-${++nextInputUniqueId}`;
    // ── Native Input Element Reference ────────────────────────
    nativeInputRef = viewChild('nativeInput');
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('');
    name = input('');
    type = input('text');
    size = input('md');
    status = input('default');
    placeholder = input('Digite algo...');
    label = input('');
    helperText = input('');
    errorMessage = input('');
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    clearable = input(false, { transform: booleanAttribute });
    mask = input('');
    unmaskValue = input(false, { transform: booleanAttribute });
    maxLength = input(undefined, {
        transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined),
    });
    minLength = input(undefined, {
        transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined),
    });
    min = input(undefined);
    max = input(undefined);
    step = input(undefined);
    showCharCount = input(false, { transform: booleanAttribute });
    prefixText = input('');
    suffixText = input('');
    autocomplete = input('off');
    autofocus = input(false, { transform: booleanAttribute });
    // Acessibilidade WCAG
    ariaLabel = input('');
    ariaDescribedby = input('');
    // ── Two-Way Model ─────────────────────────────────────────
    value = model('');
    // ── Outputs (Signals API) ─────────────────────────────────
    inputChange = output();
    blur = output();
    focus = output();
    clear = output();
    // ── Estado Interno ────────────────────────────────────────
    isFocused = signal(false);
    isPasswordVisible = signal(false);
    cvaDisabled = signal(false);
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.id() || this.uniqueId);
    helperId = computed(() => `${this.effectiveId()}-helper`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    currentType = computed(() => {
        if (this.type() === 'password') {
            return this.isPasswordVisible() ? 'text' : 'password';
        }
        return this.type();
    });
    stringValue = computed(() => {
        const v = this.value();
        const str = v !== null && v !== undefined ? String(v) : '';
        if (this.mask()) {
            return applyMask(str, this.mask());
        }
        return str;
    });
    charCount = computed(() => this.stringValue().length);
    effectiveMaxLength = computed(() => {
        if (this.mask()) {
            return this.mask().length;
        }
        return this.maxLength();
    });
    isClearVisible = computed(() => {
        const hasVal = this.stringValue().length > 0;
        const canClear = this.clearable() || this.type() === 'search';
        return hasVal && canClear && !this.effectiveDisabled() && !this.readonly();
    });
    isPasswordToggleVisible = computed(() => {
        return this.type() === 'password' && !this.effectiveDisabled();
    });
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby()) {
            ids.push(this.ariaDescribedby());
        }
        if (this.status() === 'error' && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    });
    // ── ControlValueAccessor ──────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        const val = value ?? '';
        if (this.mask() && val) {
            const masked = applyMask(String(val), this.mask());
            this.value.set(this.unmaskValue() ? cleanMask(masked, this.mask()) : masked);
        }
        else {
            this.value.set(val);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers de Eventos ───────────────────────────────────
    onInput(event) {
        const target = event.target;
        let rawVal = target.value;
        if (this.mask()) {
            const maskedVal = applyMask(rawVal, this.mask());
            target.value = maskedVal;
            const emittedVal = this.unmaskValue() ? cleanMask(maskedVal, this.mask()) : maskedVal;
            this.value.set(emittedVal);
            this.onChange(emittedVal);
            this.inputChange.emit(emittedVal);
            return;
        }
        const val = this.type() === 'number' && rawVal !== ''
            ? (target.valueAsNumber || rawVal)
            : rawVal;
        this.value.set(val);
        this.onChange(val);
        this.inputChange.emit(val);
    }
    onFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
    }
    onBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
    }
    onClear(event) {
        event.preventDefault();
        event.stopPropagation();
        this.value.set('');
        this.onChange('');
        this.inputChange.emit('');
        this.clear.emit();
        this.focusNative();
    }
    togglePasswordVisibility(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isPasswordVisible.update(visible => !visible);
    }
    focusNative() {
        this.nativeInputRef()?.nativeElement.focus();
    }
    select() {
        this.nativeInputRef()?.nativeElement.select();
    }
    static ɵfac = function InputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || InputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: InputComponent, selectors: [["orc-input"]], viewQuery: function InputComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.nativeInputRef, _c0$1, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], name: [1, "name"], type: [1, "type"], size: [1, "size"], status: [1, "status"], placeholder: [1, "placeholder"], label: [1, "label"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], clearable: [1, "clearable"], mask: [1, "mask"], unmaskValue: [1, "unmaskValue"], maxLength: [1, "maxLength"], minLength: [1, "minLength"], min: [1, "min"], max: [1, "max"], step: [1, "step"], showCharCount: [1, "showCharCount"], prefixText: [1, "prefixText"], suffixText: [1, "suffixText"], autocomplete: [1, "autocomplete"], autofocus: [1, "autofocus"], ariaLabel: [1, "ariaLabel"], ariaDescribedby: [1, "ariaDescribedby"], value: [1, "value"] }, outputs: { value: "valueChange", inputChange: "inputChange", blur: "blur", focus: "focus", clear: "clear" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => InputComponent),
                    multi: true,
                },
            ])], ngContentSelectors: _c2, decls: 14, vars: 44, consts: [["nativeInput", ""], [1, "orc-input-container"], [1, "orc-input__label", 3, "for"], [1, "orc-input-box", 3, "click"], [1, "orc-input__slot", "orc-input__slot--prefix", 3, "click"], [1, "orc-input__affix-text"], [1, "orc-input__native", 3, "input", "focus", "blur", "id", "name", "type", "value", "placeholder", "disabled", "readOnly", "required", "maxLength", "minLength", "min", "max", "step", "autocomplete", "autofocus"], ["type", "button", "aria-label", "Limpar campo", "tabindex", "-1", 1, "orc-input__action-btn", "orc-input__clear-btn"], ["type", "button", "tabindex", "-1", 1, "orc-input__action-btn", "orc-input__password-btn"], [1, "orc-input__slot", "orc-input__slot--suffix", 3, "click"], [1, "orc-input__footer"], ["aria-hidden", "true", 1, "orc-input__required-marker"], ["type", "button", "aria-label", "Limpar campo", "tabindex", "-1", 1, "orc-input__action-btn", "orc-input__clear-btn", 3, "click"], ["viewBox", "0 0 16 16", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round"], ["d", "M4 4l8 8M12 4l-8 8"], ["type", "button", "tabindex", "-1", 1, "orc-input__action-btn", "orc-input__password-btn", 3, "click"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"], ["x1", "1", "y1", "1", "x2", "23", "y2", "23"], ["d", "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"], ["cx", "12", "cy", "12", "r", "3"], [1, "orc-input__message-area"], ["role", "alert", 1, "orc-input__message", "orc-input__message--error", 3, "id"], [1, "orc-input__message", "orc-input__message--helper", 3, "id"], [1, "orc-input__char-count", 3, "orc-input__char-count--limit"], ["viewBox", "0 0 16 16", "fill", "currentColor", 1, "orc-input__message-icon"], ["d", "M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z"], [1, "orc-input__char-count"]], template: function InputComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, InputComponent_Conditional_1_Template, 3, 3, "label", 2);
            i0.ɵɵelementStart(2, "div", 3);
            i0.ɵɵlistener("click", function InputComponent_Template_div_click_2_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.focusNative()); });
            i0.ɵɵelementStart(3, "div", 4);
            i0.ɵɵlistener("click", function InputComponent_Template_div_click_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
            i0.ɵɵprojection(4);
            i0.ɵɵtemplate(5, InputComponent_Conditional_5_Template, 2, 1, "span", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "input", 6, 0);
            i0.ɵɵlistener("input", function InputComponent_Template_input_input_6_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onInput($event)); })("focus", function InputComponent_Template_input_focus_6_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFocus($event)); })("blur", function InputComponent_Template_input_blur_6_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(8, InputComponent_Conditional_8_Template, 3, 0, "button", 7)(9, InputComponent_Conditional_9_Template, 3, 2, "button", 8);
            i0.ɵɵelementStart(10, "div", 9);
            i0.ɵɵlistener("click", function InputComponent_Template_div_click_10_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
            i0.ɵɵprojection(11, 1);
            i0.ɵɵtemplate(12, InputComponent_Conditional_12_Template, 2, 1, "span", 5);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(13, InputComponent_Conditional_13_Template, 5, 2, "div", 10);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_21_0;
            let tmp_22_0;
            let tmp_23_0;
            let tmp_24_0;
            let tmp_25_0;
            i0.ɵɵclassProp("orc-input-container--disabled", ctx.effectiveDisabled())("orc-input-container--readonly", ctx.readonly());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("orc-input-box--sm", ctx.size() === "sm")("orc-input-box--md", ctx.size() === "md")("orc-input-box--lg", ctx.size() === "lg")("orc-input-box--focused", ctx.isFocused())("orc-input-box--disabled", ctx.effectiveDisabled())("orc-input-box--readonly", ctx.readonly())("orc-input-box--error", ctx.status() === "error")("orc-input-box--success", ctx.status() === "success");
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.prefixText() ? 5 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.name())("type", ctx.currentType())("value", ctx.stringValue())("placeholder", ctx.placeholder())("disabled", ctx.effectiveDisabled())("readOnly", ctx.readonly())("required", ctx.required())("maxLength", (tmp_21_0 = ctx.effectiveMaxLength()) !== null && tmp_21_0 !== undefined ? tmp_21_0 : null)("minLength", (tmp_22_0 = ctx.minLength()) !== null && tmp_22_0 !== undefined ? tmp_22_0 : null)("min", (tmp_23_0 = ctx.min()) !== null && tmp_23_0 !== undefined ? tmp_23_0 : null)("max", (tmp_24_0 = ctx.max()) !== null && tmp_24_0 !== undefined ? tmp_24_0 : null)("step", (tmp_25_0 = ctx.step()) !== null && tmp_25_0 !== undefined ? tmp_25_0 : null)("autocomplete", ctx.autocomplete())("autofocus", ctx.autofocus());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-invalid", ctx.status() === "error" ? "true" : null)("aria-describedby", ctx.computedAriaDescribedBy());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.isClearVisible() ? 8 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isPasswordToggleVisible() ? 9 : -1);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.suffixText() ? 12 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.status() === "error" && ctx.errorMessage() || ctx.helperText() || ctx.showCharCount() ? 13 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-input-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-input-container--disabled[_ngcontent-%COMP%]{cursor:not-allowed}.orc-input__label[_ngcontent-%COMP%]{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-input__required-marker[_ngcontent-%COMP%]{color:#fb2c36;margin-left:3px;font-weight:700}.orc-input-box[_ngcontent-%COMP%]{display:flex;align-items:center;width:100%;background-color:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;box-sizing:border-box;gap:8px;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-input-box[_ngcontent-%COMP%]:hover:not(.orc-input-box--focused):not(.orc-input-box--disabled):not(.orc-input-box--error):not(.orc-input-box--success){background-color:var(--orc-th, #f9f9f9);border-color:var(--orc-border, #d9d9d9)}.orc-input-box--focused[_ngcontent-%COMP%]{background-color:var(--fill-modal, #ffffff);border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 4px 4px 8px #2b7fff0a,0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-input-box--disabled[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9);opacity:.5;cursor:not-allowed}.orc-input-box--disabled[_ngcontent-%COMP%]   .orc-input__native[_ngcontent-%COMP%]{cursor:not-allowed}.orc-input-box--readonly[_ngcontent-%COMP%]{background-color:var(--orc-th, #f9f9f9);cursor:default}.orc-input-box--readonly[_ngcontent-%COMP%]   .orc-input__native[_ngcontent-%COMP%]{cursor:default}.orc-input-box--error[_ngcontent-%COMP%]{border-color:#fb2c36!important}.orc-input-box--error.orc-input-box--focused[_ngcontent-%COMP%]{box-shadow:0 0 0 3px #fb2c3626!important}.orc-input-box--success[_ngcontent-%COMP%]{border-color:#00c950!important}.orc-input-box--success.orc-input-box--focused[_ngcontent-%COMP%]{box-shadow:0 0 0 3px #00c95026!important}.orc-input-box--sm[_ngcontent-%COMP%]{min-height:36px;padding:0 10px;font-size:13px}.orc-input-box--sm[_ngcontent-%COMP%]   .orc-input__native[_ngcontent-%COMP%]{font-size:13px}.orc-input-box--md[_ngcontent-%COMP%]{min-height:44px;padding:0 12px;font-size:14px}.orc-input-box--md[_ngcontent-%COMP%]   .orc-input__native[_ngcontent-%COMP%]{font-size:14px}.orc-input-box--lg[_ngcontent-%COMP%]{min-height:52px;padding:0 16px;font-size:15px}.orc-input-box--lg[_ngcontent-%COMP%]   .orc-input__native[_ngcontent-%COMP%]{font-size:15px}.orc-input__native[_ngcontent-%COMP%]{flex:1;min-width:0;width:100%;height:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-font-main, #141414);line-height:normal;padding:0;margin:0}.orc-input__native[_ngcontent-%COMP%]::placeholder{color:var(--orc-font-secondary, #666666);font-weight:400;opacity:1}.orc-input__native[type=number][_ngcontent-%COMP%]::-webkit-inner-spin-button, .orc-input__native[type=number][_ngcontent-%COMP%]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.orc-input__native[type=number][_ngcontent-%COMP%]{-moz-appearance:textfield}.orc-input__native[type=search][_ngcontent-%COMP%]::-webkit-search-cancel-button, .orc-input__native[type=search][_ngcontent-%COMP%]::-webkit-search-decoration{-webkit-appearance:none}.orc-input__slot[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-font-secondary, #666666);flex-shrink:0;-webkit-user-select:none;user-select:none}.orc-input__slot[_ngcontent-%COMP%]:empty{display:none}.orc-input__slot[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:16px;height:16px}.orc-input__affix-text[_ngcontent-%COMP%]{font-size:13px;font-weight:500;color:var(--orc-font-secondary, #666666)}.orc-input__action-btn[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-font-secondary, #666666);cursor:pointer;outline:none;flex-shrink:0;transition:color var(--transition-fast, .15s ease),background-color var(--transition-fast, .15s ease)}.orc-input__action-btn[_ngcontent-%COMP%]:hover{color:var(--orc-font-main, #141414);background-color:#0000000d}.orc-input__action-btn[_ngcontent-%COMP%]:focus-visible{box-shadow:0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-input__action-btn[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:16px;height:16px}.orc-input__clear-btn[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:14px;height:14px}.orc-input__footer[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-input__message-area[_ngcontent-%COMP%]{flex:1;min-width:0}.orc-input__message[_ngcontent-%COMP%]{margin:0;line-height:1.4}.orc-input__message--helper[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}.orc-input__message--error[_ngcontent-%COMP%]{color:#fb2c36;display:flex;align-items:center;gap:4px;font-weight:500}.orc-input__message-icon[_ngcontent-%COMP%]{width:14px;height:14px;flex-shrink:0}.orc-input__char-count[_ngcontent-%COMP%]{font-size:11px;color:var(--orc-font-secondary, #666666);white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-input__char-count--limit[_ngcontent-%COMP%]{color:#fb2c36;font-weight:600}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InputComponent, [{
        type: Component,
        args: [{ selector: 'orc-input', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => InputComponent),
                        multi: true,
                    },
                ], template: "<div\n  class=\"orc-input-container\"\n  [class.orc-input-container--disabled]=\"effectiveDisabled()\"\n  [class.orc-input-container--readonly]=\"readonly()\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-input__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-input__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Input com Prefixos, Sufixos e A\u00E7\u00F5es \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-input-box\"\n    [class.orc-input-box--sm]=\"size() === 'sm'\"\n    [class.orc-input-box--md]=\"size() === 'md'\"\n    [class.orc-input-box--lg]=\"size() === 'lg'\"\n    [class.orc-input-box--focused]=\"isFocused()\"\n    [class.orc-input-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-input-box--readonly]=\"readonly()\"\n    [class.orc-input-box--error]=\"status() === 'error'\"\n    [class.orc-input-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <!-- Prefixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--prefix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[prefix], [orcPrefix]\" />\n      @if (prefixText()) {\n        <span class=\"orc-input__affix-text\">{{ prefixText() }}</span>\n      }\n    </div>\n\n    <!-- Input Nativo -->\n    <input\n      #nativeInput\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [type]=\"currentType()\"\n      [value]=\"stringValue()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [maxLength]=\"effectiveMaxLength() ?? null\"\n      [minLength]=\"minLength() ?? null\"\n      [min]=\"min() ?? null\"\n      [max]=\"max() ?? null\"\n      [step]=\"step() ?? null\"\n      [autocomplete]=\"autocomplete()\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-invalid]=\"status() === 'error' ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"orc-input__native\"\n    />\n\n    <!-- Bot\u00E3o de Limpar (Search / Clearable) -->\n    @if (isClearVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__clear-btn\"\n        (click)=\"onClear($event)\"\n        aria-label=\"Limpar campo\"\n        tabindex=\"-1\"\n      >\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\">\n          <path d=\"M4 4l8 8M12 4l-8 8\" />\n        </svg>\n      </button>\n    }\n\n    <!-- Bot\u00E3o de Alternar Senha (Password Toggle) -->\n    @if (isPasswordToggleVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__password-btn\"\n        (click)=\"togglePasswordVisibility($event)\"\n        [attr.aria-label]=\"isPasswordVisible() ? 'Ocultar senha' : 'Exibir senha'\"\n        tabindex=\"-1\"\n      >\n        @if (isPasswordVisible()) {\n          <!-- \u00CDcone Olho Fechado / Eye Off -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24\" />\n            <line x1=\"1\" y1=\"1\" x2=\"23\" y2=\"23\" />\n          </svg>\n        } @else {\n          <!-- \u00CDcone Olho Aberto / Eye -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z\" />\n            <circle cx=\"12\" cy=\"12\" r=\"3\" />\n          </svg>\n        }\n      </button>\n    }\n\n    <!-- Sufixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--suffix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[suffix], [orcSuffix]\" />\n      @if (suffixText()) {\n        <span class=\"orc-input__affix-text\">{{ suffixText() }}</span>\n      }\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if ((status() === 'error' && errorMessage()) || helperText() || showCharCount()) {\n    <div class=\"orc-input__footer\">\n      <div class=\"orc-input__message-area\">\n        @if (status() === 'error' && errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-input__message orc-input__message--error\" role=\"alert\">\n            <svg class=\"orc-input__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-input__message orc-input__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-input__char-count\" [class.orc-input__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-input-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-input-container--disabled{cursor:not-allowed}.orc-input__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-input__required-marker{color:#fb2c36;margin-left:3px;font-weight:700}.orc-input-box{display:flex;align-items:center;width:100%;background-color:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;box-sizing:border-box;gap:8px;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-input-box:hover:not(.orc-input-box--focused):not(.orc-input-box--disabled):not(.orc-input-box--error):not(.orc-input-box--success){background-color:var(--orc-th, #f9f9f9);border-color:var(--orc-border, #d9d9d9)}.orc-input-box--focused{background-color:var(--fill-modal, #ffffff);border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 4px 4px 8px #2b7fff0a,0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-input-box--disabled{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9);opacity:.5;cursor:not-allowed}.orc-input-box--disabled .orc-input__native{cursor:not-allowed}.orc-input-box--readonly{background-color:var(--orc-th, #f9f9f9);cursor:default}.orc-input-box--readonly .orc-input__native{cursor:default}.orc-input-box--error{border-color:#fb2c36!important}.orc-input-box--error.orc-input-box--focused{box-shadow:0 0 0 3px #fb2c3626!important}.orc-input-box--success{border-color:#00c950!important}.orc-input-box--success.orc-input-box--focused{box-shadow:0 0 0 3px #00c95026!important}.orc-input-box--sm{min-height:36px;padding:0 10px;font-size:13px}.orc-input-box--sm .orc-input__native{font-size:13px}.orc-input-box--md{min-height:44px;padding:0 12px;font-size:14px}.orc-input-box--md .orc-input__native{font-size:14px}.orc-input-box--lg{min-height:52px;padding:0 16px;font-size:15px}.orc-input-box--lg .orc-input__native{font-size:15px}.orc-input__native{flex:1;min-width:0;width:100%;height:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-font-main, #141414);line-height:normal;padding:0;margin:0}.orc-input__native::placeholder{color:var(--orc-font-secondary, #666666);font-weight:400;opacity:1}.orc-input__native[type=number]::-webkit-inner-spin-button,.orc-input__native[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.orc-input__native[type=number]{-moz-appearance:textfield}.orc-input__native[type=search]::-webkit-search-cancel-button,.orc-input__native[type=search]::-webkit-search-decoration{-webkit-appearance:none}.orc-input__slot{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-font-secondary, #666666);flex-shrink:0;-webkit-user-select:none;user-select:none}.orc-input__slot:empty{display:none}.orc-input__slot svg{width:16px;height:16px}.orc-input__affix-text{font-size:13px;font-weight:500;color:var(--orc-font-secondary, #666666)}.orc-input__action-btn{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-font-secondary, #666666);cursor:pointer;outline:none;flex-shrink:0;transition:color var(--transition-fast, .15s ease),background-color var(--transition-fast, .15s ease)}.orc-input__action-btn:hover{color:var(--orc-font-main, #141414);background-color:#0000000d}.orc-input__action-btn:focus-visible{box-shadow:0 0 0 2px var(--orc-color-azul-eletrico, #1c6aed)}.orc-input__action-btn svg{width:16px;height:16px}.orc-input__clear-btn svg{width:14px;height:14px}.orc-input__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-input__message-area{flex:1;min-width:0}.orc-input__message{margin:0;line-height:1.4}.orc-input__message--helper{color:var(--orc-font-secondary, #666666)}.orc-input__message--error{color:#fb2c36;display:flex;align-items:center;gap:4px;font-weight:500}.orc-input__message-icon{width:14px;height:14px;flex-shrink:0}.orc-input__char-count{font-size:11px;color:var(--orc-font-secondary, #666666);white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-input__char-count--limit{color:#fb2c36;font-weight:600}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(InputComponent, { className: "InputComponent", filePath: "input.component.ts", lineNumber: 37 }); })();

const _c0 = ["nativeTextarea"];
function TextareaComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 6);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function TextareaComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, TextareaComponent_Conditional_1_Conditional_2_Template, 2, 0, "span", 6);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r1.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.required() ? 2 : -1);
} }
function TextareaComponent_Conditional_5_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 8);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 11);
    i0.ɵɵelement(2, "path", 12);
    i0.ɵɵelementEnd();
    i0.ɵɵnamespaceHTML();
    i0.ɵɵelementStart(3, "span");
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.errorId());
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r1.errorMessage());
} }
function TextareaComponent_Conditional_5_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r1.helperId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.helperText(), " ");
} }
function TextareaComponent_Conditional_5_Conditional_4_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵtextInterpolate1(" / ", ctx_r1.maxLength(), " ");
} }
function TextareaComponent_Conditional_5_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, TextareaComponent_Conditional_5_Conditional_4_Conditional_2_Template, 1, 1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassProp("orc-textarea__char-count--limit", ctx_r1.maxLength() && ctx_r1.charCount() >= ctx_r1.maxLength());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r1.charCount(), "");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.maxLength() ? 2 : -1);
} }
function TextareaComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 5)(1, "div", 7);
    i0.ɵɵtemplate(2, TextareaComponent_Conditional_5_Conditional_2_Template, 5, 2, "p", 8)(3, TextareaComponent_Conditional_5_Conditional_3_Template, 2, 2, "p", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, TextareaComponent_Conditional_5_Conditional_4_Template, 3, 4, "span", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.status() === "error" && ctx_r1.errorMessage() ? 2 : ctx_r1.helperText() ? 3 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.showCharCount() ? 4 : -1);
} }
let nextTextareaUniqueId = 0;
class TextareaComponent {
    uniqueId = `orc-textarea-${++nextTextareaUniqueId}`;
    // ── Native Textarea Element Reference ─────────────────────
    nativeTextareaRef = viewChild('nativeTextarea');
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('');
    name = input('');
    size = input('md');
    status = input('default');
    placeholder = input('Digite algo...');
    label = input('');
    helperText = input('');
    errorMessage = input('');
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    rows = input(4, {
        transform: (val) => numberAttribute(val, 4),
    });
    resize = input('vertical');
    autoResize = input(false, { transform: booleanAttribute });
    maxLength = input(undefined, {
        transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined),
    });
    minLength = input(undefined, {
        transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined),
    });
    showCharCount = input(false, { transform: booleanAttribute });
    autofocus = input(false, { transform: booleanAttribute });
    // Acessibilidade WCAG
    ariaLabel = input('');
    ariaDescribedby = input('');
    // ── Two-Way Model ─────────────────────────────────────────
    value = model('');
    // ── Outputs (Signals API) ─────────────────────────────────
    inputChange = output();
    blur = output();
    focus = output();
    // ── Estado Interno ────────────────────────────────────────
    isFocused = signal(false);
    cvaDisabled = signal(false);
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.id() || this.uniqueId);
    helperId = computed(() => `${this.effectiveId()}-helper`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    stringValue = computed(() => {
        const v = this.value();
        return v !== null && v !== undefined ? String(v) : '';
    });
    charCount = computed(() => this.stringValue().length);
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby()) {
            ids.push(this.ariaDescribedby());
        }
        if (this.status() === 'error' && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    });
    // ── ControlValueAccessor ──────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        this.value.set(value ?? '');
        this.adjustHeight();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers de Eventos ───────────────────────────────────
    onInput(event) {
        const target = event.target;
        const val = target.value;
        this.value.set(val);
        this.onChange(val);
        this.inputChange.emit(val);
        this.adjustHeight();
    }
    onFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
    }
    onBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
    }
    adjustHeight() {
        if (!this.autoResize())
            return;
        const textarea = this.nativeTextareaRef()?.nativeElement;
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = `${textarea.scrollHeight}px`;
        }
    }
    focusNative() {
        this.nativeTextareaRef()?.nativeElement.focus();
    }
    select() {
        this.nativeTextareaRef()?.nativeElement.select();
    }
    static ɵfac = function TextareaComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TextareaComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TextareaComponent, selectors: [["orc-textarea"]], viewQuery: function TextareaComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.nativeTextareaRef, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], name: [1, "name"], size: [1, "size"], status: [1, "status"], placeholder: [1, "placeholder"], label: [1, "label"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], rows: [1, "rows"], resize: [1, "resize"], autoResize: [1, "autoResize"], maxLength: [1, "maxLength"], minLength: [1, "minLength"], showCharCount: [1, "showCharCount"], autofocus: [1, "autofocus"], ariaLabel: [1, "ariaLabel"], ariaDescribedby: [1, "ariaDescribedby"], value: [1, "value"] }, outputs: { value: "valueChange", inputChange: "inputChange", blur: "blur", focus: "focus" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => TextareaComponent),
                    multi: true,
                },
            ])], decls: 6, vars: 38, consts: [["nativeTextarea", ""], [1, "orc-textarea-container"], [1, "orc-textarea__label", 3, "for"], [1, "orc-textarea-box", 3, "click"], [1, "orc-textarea__native", 3, "input", "focus", "blur", "id", "name", "value", "placeholder", "disabled", "readOnly", "required", "rows", "maxLength", "minLength", "autofocus"], [1, "orc-textarea__footer"], ["aria-hidden", "true", 1, "orc-textarea__required-marker"], [1, "orc-textarea__message-area"], ["role", "alert", 1, "orc-textarea__message", "orc-textarea__message--error", 3, "id"], [1, "orc-textarea__message", "orc-textarea__message--helper", 3, "id"], [1, "orc-textarea__char-count", 3, "orc-textarea__char-count--limit"], ["viewBox", "0 0 16 16", "fill", "currentColor", 1, "orc-textarea__message-icon"], ["d", "M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z"], [1, "orc-textarea__char-count"]], template: function TextareaComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, TextareaComponent_Conditional_1_Template, 3, 3, "label", 2);
            i0.ɵɵelementStart(2, "div", 3);
            i0.ɵɵlistener("click", function TextareaComponent_Template_div_click_2_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.focusNative()); });
            i0.ɵɵelementStart(3, "textarea", 4, 0);
            i0.ɵɵlistener("input", function TextareaComponent_Template_textarea_input_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onInput($event)); })("focus", function TextareaComponent_Template_textarea_focus_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFocus($event)); })("blur", function TextareaComponent_Template_textarea_blur_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur($event)); });
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(5, TextareaComponent_Conditional_5_Template, 5, 2, "div", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_21_0;
            let tmp_22_0;
            i0.ɵɵclassProp("orc-textarea-container--disabled", ctx.effectiveDisabled())("orc-textarea-container--readonly", ctx.readonly());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("orc-textarea-box--sm", ctx.size() === "sm")("orc-textarea-box--md", ctx.size() === "md")("orc-textarea-box--lg", ctx.size() === "lg")("orc-textarea-box--focused", ctx.isFocused())("orc-textarea-box--disabled", ctx.effectiveDisabled())("orc-textarea-box--readonly", ctx.readonly())("orc-textarea-box--error", ctx.status() === "error")("orc-textarea-box--success", ctx.status() === "success");
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("resize", ctx.autoResize() ? "none" : ctx.resize());
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.name())("value", ctx.stringValue())("placeholder", ctx.placeholder())("disabled", ctx.effectiveDisabled())("readOnly", ctx.readonly())("required", ctx.required())("rows", ctx.rows())("maxLength", (tmp_21_0 = ctx.maxLength()) !== null && tmp_21_0 !== undefined ? tmp_21_0 : null)("minLength", (tmp_22_0 = ctx.minLength()) !== null && tmp_22_0 !== undefined ? tmp_22_0 : null)("autofocus", ctx.autofocus());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-invalid", ctx.status() === "error" ? "true" : null)("aria-describedby", ctx.computedAriaDescribedBy());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.status() === "error" && ctx.errorMessage() || ctx.helperText() || ctx.showCharCount() ? 5 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-textarea-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-textarea-container--disabled[_ngcontent-%COMP%]{cursor:not-allowed}.orc-textarea__label[_ngcontent-%COMP%]{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-textarea__required-marker[_ngcontent-%COMP%]{color:#fb2c36;margin-left:3px;font-weight:700}.orc-textarea-box[_ngcontent-%COMP%]{display:flex;width:100%;background-color:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;box-sizing:border-box;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-textarea-box[_ngcontent-%COMP%]:hover:not(.orc-textarea-box--focused):not(.orc-textarea-box--disabled):not(.orc-textarea-box--error):not(.orc-textarea-box--success){background-color:var(--orc-th, #f9f9f9);border-color:var(--orc-border, #d9d9d9)}.orc-textarea-box--focused[_ngcontent-%COMP%]{background-color:var(--fill-modal, #ffffff);border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 4px 4px 8px #2b7fff0a,0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-textarea-box--disabled[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9);opacity:.5;cursor:not-allowed}.orc-textarea-box--disabled[_ngcontent-%COMP%]   .orc-textarea__native[_ngcontent-%COMP%]{cursor:not-allowed}.orc-textarea-box--readonly[_ngcontent-%COMP%]{background-color:var(--orc-th, #f9f9f9);cursor:default}.orc-textarea-box--readonly[_ngcontent-%COMP%]   .orc-textarea__native[_ngcontent-%COMP%]{cursor:default}.orc-textarea-box--error[_ngcontent-%COMP%]{border-color:#fb2c36!important}.orc-textarea-box--error.orc-textarea-box--focused[_ngcontent-%COMP%]{box-shadow:0 0 0 3px #fb2c3626!important}.orc-textarea-box--success[_ngcontent-%COMP%]{border-color:#00c950!important}.orc-textarea-box--success.orc-textarea-box--focused[_ngcontent-%COMP%]{box-shadow:0 0 0 3px #00c95026!important}.orc-textarea-box--sm[_ngcontent-%COMP%]{padding:8px 10px;font-size:13px}.orc-textarea-box--sm[_ngcontent-%COMP%]   .orc-textarea__native[_ngcontent-%COMP%]{font-size:13px;min-height:80px}.orc-textarea-box--md[_ngcontent-%COMP%]{padding:10px 12px;font-size:14px}.orc-textarea-box--md[_ngcontent-%COMP%]   .orc-textarea__native[_ngcontent-%COMP%]{font-size:14px;min-height:120px}.orc-textarea-box--lg[_ngcontent-%COMP%]{padding:12px 16px;font-size:15px}.orc-textarea-box--lg[_ngcontent-%COMP%]   .orc-textarea__native[_ngcontent-%COMP%]{font-size:15px;min-height:160px}.orc-textarea__native[_ngcontent-%COMP%]{width:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-font-main, #141414);line-height:1.5;padding:0;margin:0}.orc-textarea__native[_ngcontent-%COMP%]::placeholder{color:var(--orc-font-secondary, #666666);font-weight:400;opacity:1}.orc-textarea__footer[_ngcontent-%COMP%]{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-textarea__message-area[_ngcontent-%COMP%]{flex:1;min-width:0}.orc-textarea__message[_ngcontent-%COMP%]{margin:0;line-height:1.4}.orc-textarea__message--helper[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}.orc-textarea__message--error[_ngcontent-%COMP%]{color:#fb2c36;display:flex;align-items:center;gap:4px;font-weight:500}.orc-textarea__message-icon[_ngcontent-%COMP%]{width:14px;height:14px;flex-shrink:0}.orc-textarea__char-count[_ngcontent-%COMP%]{font-size:11px;color:var(--orc-font-secondary, #666666);white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-textarea__char-count--limit[_ngcontent-%COMP%]{color:#fb2c36;font-weight:600}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TextareaComponent, [{
        type: Component,
        args: [{ selector: 'orc-textarea', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => TextareaComponent),
                        multi: true,
                    },
                ], template: "<div\n  class=\"orc-textarea-container\"\n  [class.orc-textarea-container--disabled]=\"effectiveDisabled()\"\n  [class.orc-textarea-container--readonly]=\"readonly()\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-textarea__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-textarea__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Textarea \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-textarea-box\"\n    [class.orc-textarea-box--sm]=\"size() === 'sm'\"\n    [class.orc-textarea-box--md]=\"size() === 'md'\"\n    [class.orc-textarea-box--lg]=\"size() === 'lg'\"\n    [class.orc-textarea-box--focused]=\"isFocused()\"\n    [class.orc-textarea-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-textarea-box--readonly]=\"readonly()\"\n    [class.orc-textarea-box--error]=\"status() === 'error'\"\n    [class.orc-textarea-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <textarea\n      #nativeTextarea\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [value]=\"stringValue()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [rows]=\"rows()\"\n      [maxLength]=\"maxLength() ?? null\"\n      [minLength]=\"minLength() ?? null\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-invalid]=\"status() === 'error' ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      [style.resize]=\"autoResize() ? 'none' : resize()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"orc-textarea__native\"\n    ></textarea>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if ((status() === 'error' && errorMessage()) || helperText() || showCharCount()) {\n    <div class=\"orc-textarea__footer\">\n      <div class=\"orc-textarea__message-area\">\n        @if (status() === 'error' && errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-textarea__message orc-textarea__message--error\" role=\"alert\">\n            <svg class=\"orc-textarea__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-textarea__message orc-textarea__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-textarea__char-count\" [class.orc-textarea__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-textarea-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-textarea-container--disabled{cursor:not-allowed}.orc-textarea__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-textarea__required-marker{color:#fb2c36;margin-left:3px;font-weight:700}.orc-textarea-box{display:flex;width:100%;background-color:var(--fill-modal, #ffffff);border:1px solid var(--orc-border, #d9d9d9);border-radius:10px;box-sizing:border-box;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-textarea-box:hover:not(.orc-textarea-box--focused):not(.orc-textarea-box--disabled):not(.orc-textarea-box--error):not(.orc-textarea-box--success){background-color:var(--orc-th, #f9f9f9);border-color:var(--orc-border, #d9d9d9)}.orc-textarea-box--focused{background-color:var(--fill-modal, #ffffff);border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 4px 4px 8px #2b7fff0a,0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-textarea-box--disabled{background-color:var(--orc-highlight-cinza-claro, #ededed);border-color:var(--orc-border, #d9d9d9);opacity:.5;cursor:not-allowed}.orc-textarea-box--disabled .orc-textarea__native{cursor:not-allowed}.orc-textarea-box--readonly{background-color:var(--orc-th, #f9f9f9);cursor:default}.orc-textarea-box--readonly .orc-textarea__native{cursor:default}.orc-textarea-box--error{border-color:#fb2c36!important}.orc-textarea-box--error.orc-textarea-box--focused{box-shadow:0 0 0 3px #fb2c3626!important}.orc-textarea-box--success{border-color:#00c950!important}.orc-textarea-box--success.orc-textarea-box--focused{box-shadow:0 0 0 3px #00c95026!important}.orc-textarea-box--sm{padding:8px 10px;font-size:13px}.orc-textarea-box--sm .orc-textarea__native{font-size:13px;min-height:80px}.orc-textarea-box--md{padding:10px 12px;font-size:14px}.orc-textarea-box--md .orc-textarea__native{font-size:14px;min-height:120px}.orc-textarea-box--lg{padding:12px 16px;font-size:15px}.orc-textarea-box--lg .orc-textarea__native{font-size:15px;min-height:160px}.orc-textarea__native{width:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-font-main, #141414);line-height:1.5;padding:0;margin:0}.orc-textarea__native::placeholder{color:var(--orc-font-secondary, #666666);font-weight:400;opacity:1}.orc-textarea__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-textarea__message-area{flex:1;min-width:0}.orc-textarea__message{margin:0;line-height:1.4}.orc-textarea__message--helper{color:var(--orc-font-secondary, #666666)}.orc-textarea__message--error{color:#fb2c36;display:flex;align-items:center;gap:4px;font-weight:500}.orc-textarea__message-icon{width:14px;height:14px;flex-shrink:0}.orc-textarea__char-count{font-size:11px;color:var(--orc-font-secondary, #666666);white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-textarea__char-count--limit{color:#fb2c36;font-weight:600}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TextareaComponent, { className: "TextareaComponent", filePath: "textarea.component.ts", lineNumber: 36 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { InputComponent, TextareaComponent, applyMask, cleanMask };
//# sourceMappingURL=ciag-orchestra-input.mjs.map
