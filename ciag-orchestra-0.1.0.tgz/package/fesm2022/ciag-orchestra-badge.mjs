import * as i0 from '@angular/core';
import { input, output, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

const _c0 = [[["", "badge-icon-left", ""], ["", "badgeIconLeft", ""]], "*", [["", "badge-icon-right", ""], ["", "badgeIconRight", ""]]];
const _c1 = ["[badge-icon-left], [badgeIconLeft]", "*", "[badge-icon-right], [badgeIconRight]"];
function BadgeComponent_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 5);
} }
function BadgeComponent_ng_container_3__svg_svg_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "polyline", 9);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3__svg_svg_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "circle", 11)(2, "line", 12)(3, "line", 13);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3__svg_svg_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "path", 14)(2, "line", 15)(3, "line", 16);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3__svg_svg_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "circle", 11)(2, "line", 17)(3, "line", 18);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3__svg_svg_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "circle", 11)(2, "polyline", 19);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3__svg_svg_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "line", 20)(2, "polyline", 21);
    i0.ɵɵelementEnd();
} }
function BadgeComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, BadgeComponent_ng_container_3__svg_svg_1_Template, 2, 0, "svg", 6)(2, BadgeComponent_ng_container_3__svg_svg_2_Template, 4, 0, "svg", 7)(3, BadgeComponent_ng_container_3__svg_svg_3_Template, 4, 0, "svg", 7)(4, BadgeComponent_ng_container_3__svg_svg_4_Template, 4, 0, "svg", 7)(5, BadgeComponent_ng_container_3__svg_svg_5_Template, 3, 0, "svg", 7)(6, BadgeComponent_ng_container_3__svg_svg_6_Template, 3, 0, "svg", 7);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "success" || ctx_r0.status() === "completed");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "info");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "warning");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "danger");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "pending");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r0.status() === "new");
} }
function BadgeComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r0.displayValue(), " ");
} }
function BadgeComponent_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 23);
    i0.ɵɵlistener("click", function BadgeComponent_button_7_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.onDismissClick($event)); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 24);
    i0.ɵɵelement(2, "line", 25)(3, "line", 26);
    i0.ɵɵelementEnd()();
} }
class BadgeComponent {
    // Inputs (Signals API)
    variant = input('soft');
    status = input('primary');
    size = input('md');
    text = input('');
    count = input(undefined);
    maxCount = input(99);
    dot = input(false);
    showDefaultIcon = input(false);
    dismissible = input(false);
    pill = input(false);
    ariaLabel = input('');
    // Outputs (Signals API)
    dismiss = output();
    // ── Sinais Computados ──────────────────────────────────────
    displayValue = computed(() => {
        const val = this.count();
        if (val !== undefined && val !== null) {
            const max = this.maxCount();
            return val > max ? `+${max}` : val.toString();
        }
        return this.text();
    });
    normalizedStatus = computed(() => {
        const s = this.status();
        switch (s) {
            case 'danger':
                return 'error';
            case 'completed':
                return 'success';
            case 'new':
                return 'info';
            default:
                return s;
        }
    });
    isDotOnly = computed(() => {
        return this.variant() === 'dot' && !this.displayValue();
    });
    accessibleLabel = computed(() => {
        if (this.ariaLabel())
            return this.ariaLabel();
        if (this.displayValue())
            return this.displayValue();
        return `Badge de status ${this.status()}`;
    });
    // ── Handlers ──────────────────────────────────────────────
    onDismissClick(event) {
        event.stopPropagation();
        this.dismiss.emit(event);
    }
    static ɵfac = function BadgeComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || BadgeComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: BadgeComponent, selectors: [["orc-badge"]], inputs: { variant: [1, "variant"], status: [1, "status"], size: [1, "size"], text: [1, "text"], count: [1, "count"], maxCount: [1, "maxCount"], dot: [1, "dot"], showDefaultIcon: [1, "showDefaultIcon"], dismissible: [1, "dismissible"], pill: [1, "pill"], ariaLabel: [1, "ariaLabel"] }, outputs: { dismiss: "dismiss" }, ngContentSelectors: _c1, decls: 8, vars: 45, consts: [["role", "status", 1, "orc-badge"], ["class", "orc-badge__dot", "aria-hidden", "true", 4, "ngIf"], [4, "ngIf"], ["class", "orc-badge__label", 4, "ngIf"], ["type", "button", "class", "orc-badge__dismiss", "aria-label", "Remover badge", 3, "click", 4, "ngIf"], ["aria-hidden", "true", 1, "orc-badge__dot"], ["class", "orc-badge__icon", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 4, "ngIf"], ["class", "orc-badge__icon", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 4, "ngIf"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 1, "orc-badge__icon"], ["points", "20 6 9 17 4 12"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 1, "orc-badge__icon"], ["cx", "12", "cy", "12", "r", "10"], ["x1", "12", "y1", "16", "x2", "12", "y2", "12"], ["x1", "12", "y1", "8", "x2", "12.01", "y2", "8"], ["d", "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"], ["x1", "12", "y1", "9", "x2", "12", "y2", "13"], ["x1", "12", "y1", "17", "x2", "12.01", "y2", "17"], ["x1", "15", "y1", "9", "x2", "9", "y2", "15"], ["x1", "9", "y1", "9", "x2", "15", "y2", "15"], ["points", "12 6 12 12 16 14"], ["x1", "7", "y1", "17", "x2", "17", "y2", "7"], ["points", "7 7 17 7 17 17"], [1, "orc-badge__label"], ["type", "button", "aria-label", "Remover badge", 1, "orc-badge__dismiss", 3, "click"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x1", "18", "y1", "6", "x2", "6", "y2", "18"], ["x1", "6", "y1", "6", "x2", "18", "y2", "18"]], template: function BadgeComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0);
            i0.ɵɵelementStart(0, "span", 0);
            i0.ɵɵtemplate(1, BadgeComponent_span_1_Template, 1, 0, "span", 1);
            i0.ɵɵprojection(2);
            i0.ɵɵtemplate(3, BadgeComponent_ng_container_3_Template, 7, 6, "ng-container", 2)(4, BadgeComponent_span_4_Template, 2, 1, "span", 3);
            i0.ɵɵprojection(5, 1);
            i0.ɵɵprojection(6, 2);
            i0.ɵɵtemplate(7, BadgeComponent_button_7_Template, 4, 0, "button", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-badge--variant-soft", ctx.variant() === "soft")("orc-badge--variant-solid", ctx.variant() === "solid")("orc-badge--variant-outline", ctx.variant() === "outline")("orc-badge--variant-dot", ctx.variant() === "dot")("orc-badge--variant-ghost", ctx.variant() === "ghost")("orc-badge--status-primary", ctx.status() === "primary")("orc-badge--status-secondary", ctx.status() === "secondary")("orc-badge--status-success", ctx.status() === "success" || ctx.status() === "completed")("orc-badge--status-warning", ctx.status() === "warning")("orc-badge--status-danger", ctx.status() === "danger")("orc-badge--status-info", ctx.status() === "info" || ctx.status() === "new")("orc-badge--status-neutral", ctx.status() === "neutral")("orc-badge--status-pending", ctx.status() === "pending")("orc-badge--status-active", ctx.status() === "active")("orc-badge--status-inactive", ctx.status() === "inactive")("orc-badge--size-sm", ctx.size() === "sm")("orc-badge--size-md", ctx.size() === "md")("orc-badge--size-lg", ctx.size() === "lg")("orc-badge--pill", ctx.pill())("orc-badge--dot-only", ctx.isDotOnly());
            i0.ɵɵattribute("aria-label", ctx.accessibleLabel());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.dot() || ctx.variant() === "dot");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.showDefaultIcon());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.displayValue());
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.dismissible());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-badge[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:4px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:400;line-height:1.333;-webkit-user-select:none;user-select:none;white-space:nowrap;box-sizing:border-box;overflow:hidden;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-badge--size-sm[_ngcontent-%COMP%]{height:18px;padding:1px 6px;font-size:.6875rem;border-radius:6px;gap:3px}.orc-badge--size-sm[_ngcontent-%COMP%]   .orc-badge__icon[_ngcontent-%COMP%]{width:9px;height:9px}.orc-badge--size-sm[_ngcontent-%COMP%]   .orc-badge__dot[_ngcontent-%COMP%]{width:5px;height:5px}.orc-badge--size-md[_ngcontent-%COMP%]{height:22px;padding:2px 8px;font-size:.75rem;border-radius:8px;gap:4px}.orc-badge--size-md[_ngcontent-%COMP%]   .orc-badge__icon[_ngcontent-%COMP%]{width:10px;height:10px}.orc-badge--size-md[_ngcontent-%COMP%]   .orc-badge__dot[_ngcontent-%COMP%]{width:6px;height:6px}.orc-badge--size-lg[_ngcontent-%COMP%]{height:28px;padding:4px 12px;font-size:.8125rem;border-radius:8px;gap:6px}.orc-badge--size-lg[_ngcontent-%COMP%]   .orc-badge__icon[_ngcontent-%COMP%]{width:13px;height:13px}.orc-badge--size-lg[_ngcontent-%COMP%]   .orc-badge__dot[_ngcontent-%COMP%]{width:8px;height:8px}.orc-badge--pill[_ngcontent-%COMP%]{border-radius:9999px!important}.orc-badge--dot-only[_ngcontent-%COMP%]{padding:0;width:auto;height:auto;background:transparent!important;border:none!important}.orc-badge__icon[_ngcontent-%COMP%]{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center}.orc-badge__dot[_ngcontent-%COMP%]{flex-shrink:0;border-radius:9999px;background-color:currentColor}.orc-badge__label[_ngcontent-%COMP%]{display:inline-flex;align-items:center}.orc-badge__dismiss[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;padding:0;margin-left:2px;cursor:pointer;color:inherit;opacity:.7;border-radius:50%;transition:opacity var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease)}.orc-badge__dismiss[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:10px;height:10px}.orc-badge__dismiss[_ngcontent-%COMP%]:hover{opacity:1;background-color:#00000014}.orc-badge--variant-soft.orc-badge--status-primary[_ngcontent-%COMP%]{background-color:#1c6aed1f;color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-soft.orc-badge--status-secondary[_ngcontent-%COMP%], .orc-badge--variant-soft.orc-badge--status-neutral[_ngcontent-%COMP%]{background-color:var(--status-neutral-soft-bg, #eceef2);color:var(--status-neutral-soft-fg, #141414)}.orc-badge--variant-soft.orc-badge--status-success[_ngcontent-%COMP%]{background-color:var(--status-success-soft-bg, #b8e7d7);color:var(--status-success-soft-fg, #006f4a)}.orc-badge--variant-soft.orc-badge--status-info[_ngcontent-%COMP%]{background-color:var(--status-info-soft-bg, #e1eaf6);color:var(--status-info-soft-fg, #2b7fff)}.orc-badge--variant-soft.orc-badge--status-warning[_ngcontent-%COMP%]{background-color:var(--status-warning-soft-bg, #f6ecdd);color:var(--status-warning-soft-fg, #fe9a00)}.orc-badge--variant-soft.orc-badge--status-danger[_ngcontent-%COMP%]{background-color:var(--status-danger-soft-bg, #f6d7d8);color:var(--status-danger-soft-fg, #fb2c36)}.orc-badge--variant-soft.orc-badge--status-pending[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #ededed);color:var(--text-primary, #141414)}.orc-badge--variant-soft.orc-badge--status-active[_ngcontent-%COMP%]{background-color:var(--orc-bg, #ffffff);border:1px solid var(--border-default, #d9d9d9);color:var(--text-primary, #141414)}.orc-badge--variant-soft.orc-badge--status-inactive[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-secondary, #666666)}.orc-badge--variant-solid.orc-badge--status-primary[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-badge--variant-solid.orc-badge--status-secondary[_ngcontent-%COMP%]{background-color:var(--status-neutral-soft-bg, #eceef2);color:var(--status-neutral-soft-fg, #141414)}.orc-badge--variant-solid.orc-badge--status-neutral[_ngcontent-%COMP%]{background-color:var(--bg-inverse, #141414);color:var(--text-inverse, #ffffff)}.orc-badge--variant-solid.orc-badge--status-success[_ngcontent-%COMP%]{background-color:#006f4a;color:#fff}.orc-badge--variant-solid.orc-badge--status-info[_ngcontent-%COMP%]{background-color:#2b7fff;color:#fff}.orc-badge--variant-solid.orc-badge--status-warning[_ngcontent-%COMP%]{background-color:#fe9a00;color:#141414}.orc-badge--variant-solid.orc-badge--status-danger[_ngcontent-%COMP%]{background-color:#d4183d;color:#fff}.orc-badge--variant-solid.orc-badge--status-pending[_ngcontent-%COMP%]{background-color:#71717a;color:#fff}.orc-badge--variant-solid.orc-badge--status-active[_ngcontent-%COMP%]{background-color:#006f4a;color:#fff}.orc-badge--variant-solid.orc-badge--status-inactive[_ngcontent-%COMP%]{background-color:#a1a1aa;color:#fff}.orc-badge--variant-outline[_ngcontent-%COMP%]{background-color:transparent;border:1px solid var(--border-default, #d9d9d9);color:var(--text-primary, #141414)}.orc-badge--variant-outline.orc-badge--status-primary[_ngcontent-%COMP%]{border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-outline.orc-badge--status-success[_ngcontent-%COMP%]{border-color:#006f4a;color:#006f4a}.orc-badge--variant-outline.orc-badge--status-info[_ngcontent-%COMP%]{border-color:#2b7fff;color:#2b7fff}.orc-badge--variant-outline.orc-badge--status-warning[_ngcontent-%COMP%]{border-color:#fe9a00;color:#fe9a00}.orc-badge--variant-outline.orc-badge--status-danger[_ngcontent-%COMP%]{border-color:#fb2c36;color:#fb2c36}.orc-badge--variant-dot[_ngcontent-%COMP%]{background-color:transparent;padding:0 4px}.orc-badge--variant-dot.orc-badge--status-primary[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-dot.orc-badge--status-secondary[_ngcontent-%COMP%], .orc-badge--variant-dot.orc-badge--status-neutral[_ngcontent-%COMP%]{color:var(--text-secondary, #71717a)}.orc-badge--variant-dot.orc-badge--status-success[_ngcontent-%COMP%]{color:#006f4a}.orc-badge--variant-dot.orc-badge--status-info[_ngcontent-%COMP%]{color:#2b7fff}.orc-badge--variant-dot.orc-badge--status-warning[_ngcontent-%COMP%]{color:#fe9a00}.orc-badge--variant-dot.orc-badge--status-danger[_ngcontent-%COMP%]{color:#fb2c36}.orc-badge--variant-dot.orc-badge--status-pending[_ngcontent-%COMP%]{color:#fe9a00}.orc-badge--variant-dot.orc-badge--status-active[_ngcontent-%COMP%]{color:#006f4a}.orc-badge--variant-dot.orc-badge--status-inactive[_ngcontent-%COMP%]{color:#999}.orc-badge--variant-ghost[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-primary, #141414);padding:0 4px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(BadgeComponent, [{
        type: Component,
        args: [{ selector: 'orc-badge', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n  class=\"orc-badge\"\n  [class.orc-badge--variant-soft]=\"variant() === 'soft'\"\n  [class.orc-badge--variant-solid]=\"variant() === 'solid'\"\n  [class.orc-badge--variant-outline]=\"variant() === 'outline'\"\n  [class.orc-badge--variant-dot]=\"variant() === 'dot'\"\n  [class.orc-badge--variant-ghost]=\"variant() === 'ghost'\"\n  [class.orc-badge--status-primary]=\"status() === 'primary'\"\n  [class.orc-badge--status-secondary]=\"status() === 'secondary'\"\n  [class.orc-badge--status-success]=\"status() === 'success' || status() === 'completed'\"\n  [class.orc-badge--status-warning]=\"status() === 'warning'\"\n  [class.orc-badge--status-danger]=\"status() === 'danger'\"\n  [class.orc-badge--status-info]=\"status() === 'info' || status() === 'new'\"\n  [class.orc-badge--status-neutral]=\"status() === 'neutral'\"\n  [class.orc-badge--status-pending]=\"status() === 'pending'\"\n  [class.orc-badge--status-active]=\"status() === 'active'\"\n  [class.orc-badge--status-inactive]=\"status() === 'inactive'\"\n  [class.orc-badge--size-sm]=\"size() === 'sm'\"\n  [class.orc-badge--size-md]=\"size() === 'md'\"\n  [class.orc-badge--size-lg]=\"size() === 'lg'\"\n  [class.orc-badge--pill]=\"pill()\"\n  [class.orc-badge--dot-only]=\"isDotOnly()\"\n  role=\"status\"\n  [attr.aria-label]=\"accessibleLabel()\"\n>\n  <!-- Dot Indicator (quando variant=\"dot\" ou dot=\"true\") -->\n  <span *ngIf=\"dot() || variant() === 'dot'\" class=\"orc-badge__dot\" aria-hidden=\"true\"></span>\n\n  <!-- \u00CDcone \u00E0 Esquerda (Projetado via ng-content) -->\n  <ng-content select=\"[badge-icon-left], [badgeIconLeft]\"></ng-content>\n\n  <!-- \u00CDcones Padr\u00E3o do Figma (quando showDefaultIcon=\"true\") -->\n  <ng-container *ngIf=\"showDefaultIcon()\">\n    <!-- Sucesso / Conclu\u00EDdo -->\n    <svg\n      *ngIf=\"status() === 'success' || status() === 'completed'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.5\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <polyline points=\"20 6 9 17 4 12\"></polyline>\n    </svg>\n\n    <!-- Informa\u00E7\u00E3o -->\n    <svg\n      *ngIf=\"status() === 'info'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <circle cx=\"12\" cy=\"12\" r=\"10\"></circle>\n      <line x1=\"12\" y1=\"16\" x2=\"12\" y2=\"12\"></line>\n      <line x1=\"12\" y1=\"8\" x2=\"12.01\" y2=\"8\"></line>\n    </svg>\n\n    <!-- Aviso -->\n    <svg\n      *ngIf=\"status() === 'warning'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <path d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z\"></path>\n      <line x1=\"12\" y1=\"9\" x2=\"12\" y2=\"13\"></line>\n      <line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\"></line>\n    </svg>\n\n    <!-- Erro / Danger -->\n    <svg\n      *ngIf=\"status() === 'danger'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <circle cx=\"12\" cy=\"12\" r=\"10\"></circle>\n      <line x1=\"15\" y1=\"9\" x2=\"9\" y2=\"15\"></line>\n      <line x1=\"9\" y1=\"9\" x2=\"15\" y2=\"15\"></line>\n    </svg>\n\n    <!-- Pendente (Rel\u00F3gio) -->\n    <svg\n      *ngIf=\"status() === 'pending'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <circle cx=\"12\" cy=\"12\" r=\"10\"></circle>\n      <polyline points=\"12 6 12 12 16 14\"></polyline>\n    </svg>\n\n    <!-- Novo (Sparkle / Arrow) -->\n    <svg\n      *ngIf=\"status() === 'new'\"\n      class=\"orc-badge__icon\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2.2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      aria-hidden=\"true\"\n    >\n      <line x1=\"7\" y1=\"17\" x2=\"17\" y2=\"7\"></line>\n      <polyline points=\"7 7 17 7 17 17\"></polyline>\n    </svg>\n  </ng-container>\n\n  <!-- Conte\u00FAdo de Texto ou N\u00FAmero -->\n  <span class=\"orc-badge__label\" *ngIf=\"displayValue()\">\n    {{ displayValue() }}\n  </span>\n  <ng-content></ng-content>\n\n  <!-- \u00CDcone \u00E0 Direita (Projetado via ng-content) -->\n  <ng-content select=\"[badge-icon-right], [badgeIconRight]\"></ng-content>\n\n  <!-- Bot\u00E3o de Fechar / Remover (Dismissible) -->\n  <button\n    *ngIf=\"dismissible()\"\n    type=\"button\"\n    class=\"orc-badge__dismiss\"\n    aria-label=\"Remover badge\"\n    (click)=\"onDismissClick($event)\"\n  >\n    <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n      <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n    </svg>\n  </button>\n</span>\n", styles: [":host{display:inline-flex}.orc-badge{display:inline-flex;align-items:center;justify-content:center;gap:4px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:400;line-height:1.333;-webkit-user-select:none;user-select:none;white-space:nowrap;box-sizing:border-box;overflow:hidden;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-badge--size-sm{height:18px;padding:1px 6px;font-size:.6875rem;border-radius:6px;gap:3px}.orc-badge--size-sm .orc-badge__icon{width:9px;height:9px}.orc-badge--size-sm .orc-badge__dot{width:5px;height:5px}.orc-badge--size-md{height:22px;padding:2px 8px;font-size:.75rem;border-radius:8px;gap:4px}.orc-badge--size-md .orc-badge__icon{width:10px;height:10px}.orc-badge--size-md .orc-badge__dot{width:6px;height:6px}.orc-badge--size-lg{height:28px;padding:4px 12px;font-size:.8125rem;border-radius:8px;gap:6px}.orc-badge--size-lg .orc-badge__icon{width:13px;height:13px}.orc-badge--size-lg .orc-badge__dot{width:8px;height:8px}.orc-badge--pill{border-radius:9999px!important}.orc-badge--dot-only{padding:0;width:auto;height:auto;background:transparent!important;border:none!important}.orc-badge__icon{flex-shrink:0;display:inline-flex;align-items:center;justify-content:center}.orc-badge__dot{flex-shrink:0;border-radius:9999px;background-color:currentColor}.orc-badge__label{display:inline-flex;align-items:center}.orc-badge__dismiss{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;padding:0;margin-left:2px;cursor:pointer;color:inherit;opacity:.7;border-radius:50%;transition:opacity var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease)}.orc-badge__dismiss svg{width:10px;height:10px}.orc-badge__dismiss:hover{opacity:1;background-color:#00000014}.orc-badge--variant-soft.orc-badge--status-primary{background-color:#1c6aed1f;color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-soft.orc-badge--status-secondary,.orc-badge--variant-soft.orc-badge--status-neutral{background-color:var(--status-neutral-soft-bg, #eceef2);color:var(--status-neutral-soft-fg, #141414)}.orc-badge--variant-soft.orc-badge--status-success{background-color:var(--status-success-soft-bg, #b8e7d7);color:var(--status-success-soft-fg, #006f4a)}.orc-badge--variant-soft.orc-badge--status-info{background-color:var(--status-info-soft-bg, #e1eaf6);color:var(--status-info-soft-fg, #2b7fff)}.orc-badge--variant-soft.orc-badge--status-warning{background-color:var(--status-warning-soft-bg, #f6ecdd);color:var(--status-warning-soft-fg, #fe9a00)}.orc-badge--variant-soft.orc-badge--status-danger{background-color:var(--status-danger-soft-bg, #f6d7d8);color:var(--status-danger-soft-fg, #fb2c36)}.orc-badge--variant-soft.orc-badge--status-pending{background-color:var(--orc-highlight-cinza-claro, #ededed);color:var(--text-primary, #141414)}.orc-badge--variant-soft.orc-badge--status-active{background-color:var(--orc-bg, #ffffff);border:1px solid var(--border-default, #d9d9d9);color:var(--text-primary, #141414)}.orc-badge--variant-soft.orc-badge--status-inactive{background-color:transparent;color:var(--text-secondary, #666666)}.orc-badge--variant-solid.orc-badge--status-primary{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-badge--variant-solid.orc-badge--status-secondary{background-color:var(--status-neutral-soft-bg, #eceef2);color:var(--status-neutral-soft-fg, #141414)}.orc-badge--variant-solid.orc-badge--status-neutral{background-color:var(--bg-inverse, #141414);color:var(--text-inverse, #ffffff)}.orc-badge--variant-solid.orc-badge--status-success{background-color:#006f4a;color:#fff}.orc-badge--variant-solid.orc-badge--status-info{background-color:#2b7fff;color:#fff}.orc-badge--variant-solid.orc-badge--status-warning{background-color:#fe9a00;color:#141414}.orc-badge--variant-solid.orc-badge--status-danger{background-color:#d4183d;color:#fff}.orc-badge--variant-solid.orc-badge--status-pending{background-color:#71717a;color:#fff}.orc-badge--variant-solid.orc-badge--status-active{background-color:#006f4a;color:#fff}.orc-badge--variant-solid.orc-badge--status-inactive{background-color:#a1a1aa;color:#fff}.orc-badge--variant-outline{background-color:transparent;border:1px solid var(--border-default, #d9d9d9);color:var(--text-primary, #141414)}.orc-badge--variant-outline.orc-badge--status-primary{border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-outline.orc-badge--status-success{border-color:#006f4a;color:#006f4a}.orc-badge--variant-outline.orc-badge--status-info{border-color:#2b7fff;color:#2b7fff}.orc-badge--variant-outline.orc-badge--status-warning{border-color:#fe9a00;color:#fe9a00}.orc-badge--variant-outline.orc-badge--status-danger{border-color:#fb2c36;color:#fb2c36}.orc-badge--variant-dot{background-color:transparent;padding:0 4px}.orc-badge--variant-dot.orc-badge--status-primary{color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-badge--variant-dot.orc-badge--status-secondary,.orc-badge--variant-dot.orc-badge--status-neutral{color:var(--text-secondary, #71717a)}.orc-badge--variant-dot.orc-badge--status-success{color:#006f4a}.orc-badge--variant-dot.orc-badge--status-info{color:#2b7fff}.orc-badge--variant-dot.orc-badge--status-warning{color:#fe9a00}.orc-badge--variant-dot.orc-badge--status-danger{color:#fb2c36}.orc-badge--variant-dot.orc-badge--status-pending{color:#fe9a00}.orc-badge--variant-dot.orc-badge--status-active{color:#006f4a}.orc-badge--variant-dot.orc-badge--status-inactive{color:#999}.orc-badge--variant-ghost{background-color:transparent;color:var(--text-primary, #141414);padding:0 4px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(BadgeComponent, { className: "BadgeComponent", filePath: "badge.component.ts", lineNumber: 19 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { BadgeComponent };
//# sourceMappingURL=ciag-orchestra-badge.mjs.map
