import * as i0 from '@angular/core';
import { input, inject, output, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';

const _c0$1 = [[["", "iconLeft", ""]], "*", [["", "iconRight", ""]]];
const _c1 = ["[iconLeft]", "*", "[iconRight]"];
function ButtonComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 5);
    i0.ɵɵelement(2, "circle", 6)(3, "circle", 7);
    i0.ɵɵelementEnd()();
} }
function ButtonComponent_Conditional_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 8);
} if (rf & 2) {
    const icon_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", icon_r1.content, i0.ɵɵsanitizeHtml);
} }
function ButtonComponent_Conditional_2_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i");
} if (rf & 2) {
    const icon_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassMap(icon_r1.content);
} }
function ButtonComponent_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtemplate(1, ButtonComponent_Conditional_2_Conditional_1_Template, 1, 1, "span", 8)(2, ButtonComponent_Conditional_2_Conditional_2_Template, 1, 2, "i", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx.isSvg ? 1 : 2);
} }
function ButtonComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
function ButtonComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 3);
    i0.ɵɵprojection(1, 1);
    i0.ɵɵelementEnd();
} }
function ButtonComponent_Conditional_5_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 8);
} if (rf & 2) {
    const icon_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", icon_r2.content, i0.ɵɵsanitizeHtml);
} }
function ButtonComponent_Conditional_5_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i");
} if (rf & 2) {
    const icon_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassMap(icon_r2.content);
} }
function ButtonComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtemplate(1, ButtonComponent_Conditional_5_Conditional_1_Template, 1, 1, "span", 8)(2, ButtonComponent_Conditional_5_Conditional_2_Template, 1, 2, "i", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx.isSvg ? 1 : 2);
} }
function ButtonComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0, 2);
} }
class ButtonComponent {
    // ── Inputs (Signals API) ──────────────────────────────────────────
    variant = input('primary');
    size = input('md');
    disabled = input(false);
    loading = input(false);
    fullWidth = input(false);
    iconLeft = input(undefined);
    iconRight = input(undefined);
    iconOnly = input(false);
    type = input('button');
    ariaLabel = input('');
    sanitizer = inject(DomSanitizer);
    // ── Outputs (Signals API) ─────────────────────────────────────────
    click = output();
    // ── Computed Signals ──────────────────────────────────────────────
    isDisabled = computed(() => this.disabled() || this.loading());
    safeIconLeft = computed(() => {
        const icon = this.iconLeft();
        if (!icon)
            return null;
        if (icon.trim().startsWith('<svg')) {
            return { isSvg: true, content: this.sanitizer.bypassSecurityTrustHtml(icon) };
        }
        return { isSvg: false, content: icon };
    });
    safeIconRight = computed(() => {
        const icon = this.iconRight();
        if (!icon)
            return null;
        if (icon.trim().startsWith('<svg')) {
            return { isSvg: true, content: this.sanitizer.bypassSecurityTrustHtml(icon) };
        }
        return { isSvg: false, content: icon };
    });
    buttonClasses = computed(() => {
        return {
            'orc-button': true,
            [`orc-button--variant-${this.variant()}`]: true,
            [`orc-button--size-${this.size()}`]: true,
            'orc-button--disabled': this.isDisabled(),
            'orc-button--loading': this.loading(),
            'orc-button--full-width': this.fullWidth(),
            'orc-button--icon-only': this.iconOnly(),
        };
    });
    // ── Event Handlers ────────────────────────────────────────────────
    handleClick(event) {
        if (this.isDisabled()) {
            event.preventDefault();
            event.stopPropagation();
            return;
        }
        this.click.emit(event);
    }
    static ɵfac = function ButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ButtonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ButtonComponent, selectors: [["orc-button"]], inputs: { variant: [1, "variant"], size: [1, "size"], disabled: [1, "disabled"], loading: [1, "loading"], fullWidth: [1, "fullWidth"], iconLeft: [1, "iconLeft"], iconRight: [1, "iconRight"], iconOnly: [1, "iconOnly"], type: [1, "type"], ariaLabel: [1, "ariaLabel"] }, outputs: { click: "click" }, ngContentSelectors: _c1, decls: 7, vars: 11, consts: [[3, "click", "type", "disabled"], ["aria-hidden", "true", 1, "orc-button__spinner"], ["aria-hidden", "true", 1, "orc-button__icon", "orc-button__icon--left"], [1, "orc-button__text"], ["aria-hidden", "true", 1, "orc-button__icon", "orc-button__icon--right"], ["viewBox", "0 0 24 24", "fill", "none", 1, "orc-button__spinner-svg"], ["cx", "12", "cy", "12", "r", "10", "stroke", "currentColor", "stroke-width", "3", 1, "orc-button__spinner-track"], ["cx", "12", "cy", "12", "r", "10", "stroke", "currentColor", "stroke-width", "3", "stroke-dasharray", "80", "stroke-dashoffset", "60", 1, "orc-button__spinner-head"], [1, "orc-button__icon-svg-wrapper", 3, "innerHTML"], [3, "class"]], template: function ButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef(_c0$1);
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function ButtonComponent_Template_button_click_0_listener($event) { return ctx.handleClick($event); });
            i0.ɵɵtemplate(1, ButtonComponent_Conditional_1_Template, 4, 0, "span", 1)(2, ButtonComponent_Conditional_2_Template, 3, 1, "span", 2)(3, ButtonComponent_Conditional_3_Template, 1, 0)(4, ButtonComponent_Conditional_4_Template, 2, 0, "span", 3)(5, ButtonComponent_Conditional_5_Template, 3, 1, "span", 4)(6, ButtonComponent_Conditional_6_Template, 1, 0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_7_0;
            let tmp_9_0;
            i0.ɵɵclassMap(ctx.buttonClasses());
            i0.ɵɵproperty("type", ctx.type())("disabled", ctx.isDisabled());
            i0.ɵɵattribute("aria-disabled", ctx.isDisabled() ? "true" : null)("aria-busy", ctx.loading() ? "true" : null)("aria-label", ctx.ariaLabel() || null);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.loading() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional((tmp_7_0 = ctx.safeIconLeft()) ? 2 : 3, tmp_7_0);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(!ctx.iconOnly() ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional((tmp_9_0 = ctx.safeIconRight()) ? 5 : 6, tmp_9_0);
        } }, dependencies: [CommonModule], styles: [".orc-button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-sans);font-weight:500;border-radius:var(--radius-md);border:1px solid transparent;cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap;position:relative;transition:background-color var(--transition-base),border-color var(--transition-base),color var(--transition-base),opacity var(--transition-base),box-shadow var(--transition-base)}.orc-button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--color-accent);outline-offset:2px}.orc-button[_ngcontent-%COMP%]:disabled, .orc-button--disabled[_ngcontent-%COMP%]{cursor:not-allowed;opacity:.6;pointer-events:none}.orc-button--loading[_ngcontent-%COMP%]{cursor:default;pointer-events:none}.orc-button--loading[_ngcontent-%COMP%]   .orc-button__text[_ngcontent-%COMP%], .orc-button--loading[_ngcontent-%COMP%]   .orc-button__icon[_ngcontent-%COMP%]{opacity:0}.orc-button--full-width[_ngcontent-%COMP%]{display:flex;width:100%}.orc-button__spinner[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center}.orc-button__spinner-svg[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem;animation:_ngcontent-%COMP%_orc-button-spin .8s linear infinite}.orc-button__spinner-track[_ngcontent-%COMP%]{opacity:.25}.orc-button__spinner-head[_ngcontent-%COMP%]{transform-origin:center}.orc-button__icon[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;font-size:1.15em;line-height:1}.orc-button__icon--left[_ngcontent-%COMP%]{margin-right:var(--space-2)}.orc-button__icon--right[_ngcontent-%COMP%]{margin-left:var(--space-2)}.orc-button__text[_ngcontent-%COMP%]{display:inline-flex;align-items:center;line-height:1}.orc-button--size-sm[_ngcontent-%COMP%]{height:2rem;padding:0 var(--space-3);font-size:.875rem;border-radius:var(--radius-sm)}.orc-button--size-sm[_ngcontent-%COMP%]   .orc-button__spinner-svg[_ngcontent-%COMP%]{width:1rem;height:1rem}.orc-button--size-md[_ngcontent-%COMP%]{height:2.5rem;padding:0 var(--space-4);font-size:.875rem}.orc-button--size-md[_ngcontent-%COMP%]   .orc-button__spinner-svg[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem}.orc-button--size-lg[_ngcontent-%COMP%]{height:3rem;padding:0 var(--space-5);font-size:1rem}.orc-button--size-lg[_ngcontent-%COMP%]   .orc-button__spinner-svg[_ngcontent-%COMP%]{width:1.5rem;height:1.5rem}.orc-button--variant-primary[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1C6AED);color:#fff;border-color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-primary[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--orc-color-azul-royal, #0406AB);border-color:var(--orc-color-azul-royal, #0406AB)}.orc-button--variant-primary[_ngcontent-%COMP%]:active:not(:disabled){opacity:.9}.orc-button--variant-secondary[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #EDEDED);color:var(--text-primary, #141414);border-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-button--variant-secondary[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--orc-secondary-bg, #D9D9D9);border-color:var(--orc-secondary-bg, #D9D9D9)}.orc-button--variant-secondary[_ngcontent-%COMP%]:active:not(:disabled){opacity:.9}.orc-button--variant-outline[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-primary, #141414);border-color:var(--border-default, #D9D9D9)}.orc-button--variant-outline[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);border-color:var(--border-strong, #D9D9D9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-outline[_ngcontent-%COMP%]:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-button--variant-ghost[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-primary, #141414);border-color:transparent}.orc-button--variant-ghost[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-ghost[_ngcontent-%COMP%]:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-button--variant-link[_ngcontent-%COMP%]{background-color:transparent;color:var(--orc-color-azul-eletrico, #1C6AED);border-color:transparent;padding-left:0;padding-right:0;height:auto;min-height:unset;border-radius:0}.orc-button--variant-link[_ngcontent-%COMP%]:hover:not(:disabled){text-decoration:underline;color:var(--orc-color-azul-royal, #0406AB)}.orc-button--variant-link[_ngcontent-%COMP%]:active:not(:disabled){opacity:.8}.orc-button--variant-danger[_ngcontent-%COMP%]{background-color:var(--color-error, #FB2C36);color:#fff;border-color:var(--color-error, #FB2C36)}.orc-button--variant-danger[_ngcontent-%COMP%]:hover:not(:disabled){background-color:#d4183d;border-color:#d4183d}.orc-button--variant-danger[_ngcontent-%COMP%]:active:not(:disabled){filter:brightness(.9)}@keyframes _ngcontent-%COMP%_orc-button-spin{to{transform:rotate(360deg)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ButtonComponent, [{
        type: Component,
        args: [{ selector: 'orc-button', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  [type]=\"type()\"\n  [disabled]=\"isDisabled()\"\n  [attr.aria-disabled]=\"isDisabled() ? 'true' : null\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n  [class]=\"buttonClasses()\"\n  (click)=\"handleClick($event)\"\n>\n  @if (loading()) {\n    <span class=\"orc-button__spinner\" aria-hidden=\"true\">\n      <svg class=\"orc-button__spinner-svg\" viewBox=\"0 0 24 24\" fill=\"none\">\n        <circle class=\"orc-button__spinner-track\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"3\"></circle>\n        <circle class=\"orc-button__spinner-head\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"3\" stroke-dasharray=\"80\" stroke-dashoffset=\"60\"></circle>\n      </svg>\n    </span>\n  }\n\n  <!-- Left Icon -->\n  @if (safeIconLeft(); as icon) {\n    <span class=\"orc-button__icon orc-button__icon--left\" aria-hidden=\"true\">\n      @if (icon.isSvg) {\n        <span class=\"orc-button__icon-svg-wrapper\" [innerHTML]=\"icon.content\"></span>\n      } @else {\n        <i [class]=\"icon.content\"></i>\n      }\n    </span>\n  } @else {\n    <ng-content select=\"[iconLeft]\"></ng-content>\n  }\n\n  <!-- Content -->\n  @if (!iconOnly()) {\n    <span class=\"orc-button__text\">\n      <ng-content></ng-content>\n    </span>\n  }\n\n  <!-- Right Icon -->\n  @if (safeIconRight(); as icon) {\n    <span class=\"orc-button__icon orc-button__icon--right\" aria-hidden=\"true\">\n      @if (icon.isSvg) {\n        <span class=\"orc-button__icon-svg-wrapper\" [innerHTML]=\"icon.content\"></span>\n      } @else {\n        <i [class]=\"icon.content\"></i>\n      }\n    </span>\n  } @else {\n    <ng-content select=\"[iconRight]\"></ng-content>\n  }\n</button>\n", styles: [".orc-button{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-sans);font-weight:500;border-radius:var(--radius-md);border:1px solid transparent;cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap;position:relative;transition:background-color var(--transition-base),border-color var(--transition-base),color var(--transition-base),opacity var(--transition-base),box-shadow var(--transition-base)}.orc-button:focus-visible{outline:2px solid var(--color-accent);outline-offset:2px}.orc-button:disabled,.orc-button--disabled{cursor:not-allowed;opacity:.6;pointer-events:none}.orc-button--loading{cursor:default;pointer-events:none}.orc-button--loading .orc-button__text,.orc-button--loading .orc-button__icon{opacity:0}.orc-button--full-width{display:flex;width:100%}.orc-button__spinner{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center}.orc-button__spinner-svg{width:1.25rem;height:1.25rem;animation:orc-button-spin .8s linear infinite}.orc-button__spinner-track{opacity:.25}.orc-button__spinner-head{transform-origin:center}.orc-button__icon{display:inline-flex;align-items:center;justify-content:center;font-size:1.15em;line-height:1}.orc-button__icon--left{margin-right:var(--space-2)}.orc-button__icon--right{margin-left:var(--space-2)}.orc-button__text{display:inline-flex;align-items:center;line-height:1}.orc-button--size-sm{height:2rem;padding:0 var(--space-3);font-size:.875rem;border-radius:var(--radius-sm)}.orc-button--size-sm .orc-button__spinner-svg{width:1rem;height:1rem}.orc-button--size-md{height:2.5rem;padding:0 var(--space-4);font-size:.875rem}.orc-button--size-md .orc-button__spinner-svg{width:1.25rem;height:1.25rem}.orc-button--size-lg{height:3rem;padding:0 var(--space-5);font-size:1rem}.orc-button--size-lg .orc-button__spinner-svg{width:1.5rem;height:1.5rem}.orc-button--variant-primary{background-color:var(--orc-color-azul-eletrico, #1C6AED);color:#fff;border-color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-primary:hover:not(:disabled){background-color:var(--orc-color-azul-royal, #0406AB);border-color:var(--orc-color-azul-royal, #0406AB)}.orc-button--variant-primary:active:not(:disabled){opacity:.9}.orc-button--variant-secondary{background-color:var(--orc-highlight-cinza-claro, #EDEDED);color:var(--text-primary, #141414);border-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-button--variant-secondary:hover:not(:disabled){background-color:var(--orc-secondary-bg, #D9D9D9);border-color:var(--orc-secondary-bg, #D9D9D9)}.orc-button--variant-secondary:active:not(:disabled){opacity:.9}.orc-button--variant-outline{background-color:transparent;color:var(--text-primary, #141414);border-color:var(--border-default, #D9D9D9)}.orc-button--variant-outline:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);border-color:var(--border-strong, #D9D9D9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-outline:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-button--variant-ghost{background-color:transparent;color:var(--text-primary, #141414);border-color:transparent}.orc-button--variant-ghost:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-button--variant-ghost:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-button--variant-link{background-color:transparent;color:var(--orc-color-azul-eletrico, #1C6AED);border-color:transparent;padding-left:0;padding-right:0;height:auto;min-height:unset;border-radius:0}.orc-button--variant-link:hover:not(:disabled){text-decoration:underline;color:var(--orc-color-azul-royal, #0406AB)}.orc-button--variant-link:active:not(:disabled){opacity:.8}.orc-button--variant-danger{background-color:var(--color-error, #FB2C36);color:#fff;border-color:var(--color-error, #FB2C36)}.orc-button--variant-danger:hover:not(:disabled){background-color:#d4183d;border-color:#d4183d}.orc-button--variant-danger:active:not(:disabled){filter:brightness(.9)}@keyframes orc-button-spin{to{transform:rotate(360deg)}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ButtonComponent, { className: "ButtonComponent", filePath: "button.component.ts", lineNumber: 21 }); })();

const _c0 = ["*"];
function IconButtonComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 1);
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 3);
    i0.ɵɵelement(2, "circle", 4)(3, "circle", 5);
    i0.ɵɵelementEnd()();
} }
function IconButtonComponent_Conditional_3_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 6);
} if (rf & 2) {
    const iconData_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", iconData_r1.content, i0.ɵɵsanitizeHtml);
} }
function IconButtonComponent_Conditional_3_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i");
} if (rf & 2) {
    const iconData_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassMap(iconData_r1.content);
} }
function IconButtonComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, IconButtonComponent_Conditional_3_Conditional_0_Template, 1, 1, "span", 6)(1, IconButtonComponent_Conditional_3_Conditional_1_Template, 1, 2, "i", 7);
} if (rf & 2) {
    i0.ɵɵconditional(ctx.isSvg ? 0 : 1);
} }
function IconButtonComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵprojection(0);
} }
class IconButtonComponent {
    // ── Inputs (Signals API) ──────────────────────────────────────────
    variant = input('primary');
    size = input('md');
    disabled = input(false);
    loading = input(false);
    icon = input(undefined);
    ariaLabel = input.required(); // Require ariaLabel for accessibility
    sanitizer = inject(DomSanitizer);
    // ── Outputs (Signals API) ─────────────────────────────────────────
    click = output();
    // ── Computed Signals ──────────────────────────────────────────────
    isDisabled = computed(() => this.disabled() || this.loading());
    safeIcon = computed(() => {
        const icon = this.icon();
        if (!icon)
            return null;
        if (icon.trim().startsWith('<svg')) {
            return { isSvg: true, content: this.sanitizer.bypassSecurityTrustHtml(icon) };
        }
        return { isSvg: false, content: icon };
    });
    buttonClasses = computed(() => {
        return {
            'orc-icon-button': true,
            [`orc-icon-button--variant-${this.variant()}`]: true,
            [`orc-icon-button--size-${this.size()}`]: true,
            'orc-icon-button--disabled': this.isDisabled(),
            'orc-icon-button--loading': this.loading(),
        };
    });
    // ── Event Handlers ────────────────────────────────────────────────
    handleClick(event) {
        if (this.isDisabled()) {
            event.preventDefault();
            event.stopPropagation();
            return;
        }
        this.click.emit(event);
    }
    static ɵfac = function IconButtonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || IconButtonComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IconButtonComponent, selectors: [["orc-icon-button"]], inputs: { variant: [1, "variant"], size: [1, "size"], disabled: [1, "disabled"], loading: [1, "loading"], icon: [1, "icon"], ariaLabel: [1, "ariaLabel"] }, outputs: { click: "click" }, ngContentSelectors: _c0, decls: 5, vars: 8, consts: [["type", "button", 3, "click", "disabled"], ["aria-hidden", "true", 1, "orc-icon-button__spinner"], [1, "orc-icon-button__icon-container"], ["viewBox", "0 0 24 24", "fill", "none", 1, "orc-icon-button__spinner-svg"], ["cx", "12", "cy", "12", "r", "10", "stroke", "currentColor", "stroke-width", "3", 1, "orc-icon-button__spinner-track"], ["cx", "12", "cy", "12", "r", "10", "stroke", "currentColor", "stroke-width", "3", "stroke-dasharray", "80", "stroke-dashoffset", "60", 1, "orc-icon-button__spinner-head"], [1, "orc-icon-button__icon-svg-wrapper", 3, "innerHTML"], [3, "class"]], template: function IconButtonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function IconButtonComponent_Template_button_click_0_listener($event) { return ctx.handleClick($event); });
            i0.ɵɵtemplate(1, IconButtonComponent_Conditional_1_Template, 4, 0, "span", 1);
            i0.ɵɵelementStart(2, "span", 2);
            i0.ɵɵtemplate(3, IconButtonComponent_Conditional_3_Template, 2, 1)(4, IconButtonComponent_Conditional_4_Template, 1, 0);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            let tmp_6_0;
            i0.ɵɵclassMap(ctx.buttonClasses());
            i0.ɵɵproperty("disabled", ctx.isDisabled());
            i0.ɵɵattribute("aria-disabled", ctx.isDisabled() ? "true" : null)("aria-busy", ctx.loading() ? "true" : null)("aria-label", ctx.ariaLabel());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.loading() ? 1 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional((tmp_6_0 = ctx.safeIcon()) ? 3 : 4, tmp_6_0);
        } }, dependencies: [CommonModule], styles: [".orc-icon-button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-sans);border-radius:var(--radius-md);border:1px solid transparent;cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap;position:relative;transition:background-color var(--transition-base),border-color var(--transition-base),color var(--transition-base),opacity var(--transition-base),box-shadow var(--transition-base)}.orc-icon-button[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--color-accent);outline-offset:2px}.orc-icon-button[_ngcontent-%COMP%]:disabled, .orc-icon-button--disabled[_ngcontent-%COMP%]{cursor:not-allowed;opacity:.6;pointer-events:none}.orc-icon-button--loading[_ngcontent-%COMP%]{cursor:default;pointer-events:none}.orc-icon-button--loading[_ngcontent-%COMP%]   .orc-icon-button__icon-container[_ngcontent-%COMP%]{opacity:0}.orc-icon-button__spinner[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center}.orc-icon-button__spinner-svg[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem;animation:_ngcontent-%COMP%_orc-icon-button-spin .8s linear infinite}.orc-icon-button__spinner-track[_ngcontent-%COMP%]{opacity:.25}.orc-icon-button__spinner-head[_ngcontent-%COMP%]{transform-origin:center}.orc-icon-button__icon-container[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;font-size:1.25rem;line-height:1}.orc-icon-button__icon-container[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{display:inline-flex;font-style:normal}.orc-icon-button--size-sm[_ngcontent-%COMP%]{width:2rem;height:2rem;font-size:.875rem;border-radius:var(--radius-sm)}.orc-icon-button--size-sm[_ngcontent-%COMP%]   .orc-icon-button__icon-container[_ngcontent-%COMP%]{font-size:1rem}.orc-icon-button--size-sm[_ngcontent-%COMP%]   .orc-icon-button__spinner-svg[_ngcontent-%COMP%]{width:1rem;height:1rem}.orc-icon-button--size-md[_ngcontent-%COMP%]{width:2.5rem;height:2.5rem;font-size:1rem}.orc-icon-button--size-md[_ngcontent-%COMP%]   .orc-icon-button__icon-container[_ngcontent-%COMP%]{font-size:1.25rem}.orc-icon-button--size-md[_ngcontent-%COMP%]   .orc-icon-button__spinner-svg[_ngcontent-%COMP%]{width:1.25rem;height:1.25rem}.orc-icon-button--size-lg[_ngcontent-%COMP%]{width:3rem;height:3rem;font-size:1.125rem}.orc-icon-button--size-lg[_ngcontent-%COMP%]   .orc-icon-button__icon-container[_ngcontent-%COMP%]{font-size:1.5rem}.orc-icon-button--size-lg[_ngcontent-%COMP%]   .orc-icon-button__spinner-svg[_ngcontent-%COMP%]{width:1.5rem;height:1.5rem}.orc-icon-button--variant-primary[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1C6AED);color:#fff;border-color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-primary[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--orc-color-azul-royal, #0406AB);border-color:var(--orc-color-azul-royal, #0406AB)}.orc-icon-button--variant-primary[_ngcontent-%COMP%]:active:not(:disabled){opacity:.9}.orc-icon-button--variant-secondary[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #EDEDED);color:var(--text-primary, #141414);border-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-icon-button--variant-secondary[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--orc-secondary-bg, #D9D9D9);border-color:var(--orc-secondary-bg, #D9D9D9)}.orc-icon-button--variant-secondary[_ngcontent-%COMP%]:active:not(:disabled){opacity:.9}.orc-icon-button--variant-outline[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-primary, #141414);border-color:var(--border-default, #D9D9D9)}.orc-icon-button--variant-outline[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);border-color:var(--border-strong, #D9D9D9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-outline[_ngcontent-%COMP%]:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-icon-button--variant-ghost[_ngcontent-%COMP%]{background-color:transparent;color:var(--text-primary, #141414);border-color:transparent}.orc-icon-button--variant-ghost[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-ghost[_ngcontent-%COMP%]:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-icon-button--variant-link[_ngcontent-%COMP%]{background-color:transparent;color:var(--orc-color-azul-eletrico, #1C6AED);border-color:transparent;width:auto;height:auto;min-height:unset;border-radius:0;padding:var(--space-1)}.orc-icon-button--variant-link[_ngcontent-%COMP%]:hover:not(:disabled){text-decoration:underline;color:var(--orc-color-azul-royal, #0406AB)}.orc-icon-button--variant-link[_ngcontent-%COMP%]:active:not(:disabled){opacity:.8}.orc-icon-button--variant-danger[_ngcontent-%COMP%]{background-color:var(--color-error, #FB2C36);color:#fff;border-color:var(--color-error, #FB2C36)}.orc-icon-button--variant-danger[_ngcontent-%COMP%]:hover:not(:disabled){background-color:#d4183d;border-color:#d4183d}.orc-icon-button--variant-danger[_ngcontent-%COMP%]:active:not(:disabled){filter:brightness(.9)}@keyframes _ngcontent-%COMP%_orc-icon-button-spin{to{transform:rotate(360deg)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IconButtonComponent, [{
        type: Component,
        args: [{ selector: 'orc-icon-button', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  type=\"button\"\n  [disabled]=\"isDisabled()\"\n  [attr.aria-disabled]=\"isDisabled() ? 'true' : null\"\n  [attr.aria-busy]=\"loading() ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [class]=\"buttonClasses()\"\n  (click)=\"handleClick($event)\"\n>\n  @if (loading()) {\n    <span class=\"orc-icon-button__spinner\" aria-hidden=\"true\">\n      <svg class=\"orc-icon-button__spinner-svg\" viewBox=\"0 0 24 24\" fill=\"none\">\n        <circle class=\"orc-icon-button__spinner-track\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"3\"></circle>\n        <circle class=\"orc-icon-button__spinner-head\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"3\" stroke-dasharray=\"80\" stroke-dashoffset=\"60\"></circle>\n      </svg>\n    </span>\n  }\n\n  <span class=\"orc-icon-button__icon-container\">\n    @if (safeIcon(); as iconData) {\n      @if (iconData.isSvg) {\n        <span class=\"orc-icon-button__icon-svg-wrapper\" [innerHTML]=\"iconData.content\"></span>\n      } @else {\n        <i [class]=\"iconData.content\"></i>\n      }\n    } @else {\n      <ng-content></ng-content>\n    }\n  </span>\n</button>\n", styles: [".orc-icon-button{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-sans);border-radius:var(--radius-md);border:1px solid transparent;cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap;position:relative;transition:background-color var(--transition-base),border-color var(--transition-base),color var(--transition-base),opacity var(--transition-base),box-shadow var(--transition-base)}.orc-icon-button:focus-visible{outline:2px solid var(--color-accent);outline-offset:2px}.orc-icon-button:disabled,.orc-icon-button--disabled{cursor:not-allowed;opacity:.6;pointer-events:none}.orc-icon-button--loading{cursor:default;pointer-events:none}.orc-icon-button--loading .orc-icon-button__icon-container{opacity:0}.orc-icon-button__spinner{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center}.orc-icon-button__spinner-svg{width:1.25rem;height:1.25rem;animation:orc-icon-button-spin .8s linear infinite}.orc-icon-button__spinner-track{opacity:.25}.orc-icon-button__spinner-head{transform-origin:center}.orc-icon-button__icon-container{display:inline-flex;align-items:center;justify-content:center;font-size:1.25rem;line-height:1}.orc-icon-button__icon-container i{display:inline-flex;font-style:normal}.orc-icon-button--size-sm{width:2rem;height:2rem;font-size:.875rem;border-radius:var(--radius-sm)}.orc-icon-button--size-sm .orc-icon-button__icon-container{font-size:1rem}.orc-icon-button--size-sm .orc-icon-button__spinner-svg{width:1rem;height:1rem}.orc-icon-button--size-md{width:2.5rem;height:2.5rem;font-size:1rem}.orc-icon-button--size-md .orc-icon-button__icon-container{font-size:1.25rem}.orc-icon-button--size-md .orc-icon-button__spinner-svg{width:1.25rem;height:1.25rem}.orc-icon-button--size-lg{width:3rem;height:3rem;font-size:1.125rem}.orc-icon-button--size-lg .orc-icon-button__icon-container{font-size:1.5rem}.orc-icon-button--size-lg .orc-icon-button__spinner-svg{width:1.5rem;height:1.5rem}.orc-icon-button--variant-primary{background-color:var(--orc-color-azul-eletrico, #1C6AED);color:#fff;border-color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-primary:hover:not(:disabled){background-color:var(--orc-color-azul-royal, #0406AB);border-color:var(--orc-color-azul-royal, #0406AB)}.orc-icon-button--variant-primary:active:not(:disabled){opacity:.9}.orc-icon-button--variant-secondary{background-color:var(--orc-highlight-cinza-claro, #EDEDED);color:var(--text-primary, #141414);border-color:var(--orc-highlight-cinza-claro, #EDEDED)}.orc-icon-button--variant-secondary:hover:not(:disabled){background-color:var(--orc-secondary-bg, #D9D9D9);border-color:var(--orc-secondary-bg, #D9D9D9)}.orc-icon-button--variant-secondary:active:not(:disabled){opacity:.9}.orc-icon-button--variant-outline{background-color:transparent;color:var(--text-primary, #141414);border-color:var(--border-default, #D9D9D9)}.orc-icon-button--variant-outline:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);border-color:var(--border-strong, #D9D9D9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-outline:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-icon-button--variant-ghost{background-color:transparent;color:var(--text-primary, #141414);border-color:transparent}.orc-icon-button--variant-ghost:hover:not(:disabled){background-color:var(--bg-subtle, #F9F9F9);color:var(--orc-color-azul-eletrico, #1C6AED)}.orc-icon-button--variant-ghost:active:not(:disabled){background-color:var(--bg-muted, #EDEDED)}.orc-icon-button--variant-link{background-color:transparent;color:var(--orc-color-azul-eletrico, #1C6AED);border-color:transparent;width:auto;height:auto;min-height:unset;border-radius:0;padding:var(--space-1)}.orc-icon-button--variant-link:hover:not(:disabled){text-decoration:underline;color:var(--orc-color-azul-royal, #0406AB)}.orc-icon-button--variant-link:active:not(:disabled){opacity:.8}.orc-icon-button--variant-danger{background-color:var(--color-error, #FB2C36);color:#fff;border-color:var(--color-error, #FB2C36)}.orc-icon-button--variant-danger:hover:not(:disabled){background-color:#d4183d;border-color:#d4183d}.orc-icon-button--variant-danger:active:not(:disabled){filter:brightness(.9)}@keyframes orc-icon-button-spin{to{transform:rotate(360deg)}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(IconButtonComponent, { className: "IconButtonComponent", filePath: "icon-button.component.ts", lineNumber: 21 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ButtonComponent, IconButtonComponent };
//# sourceMappingURL=ciag-orchestra-button.mjs.map
