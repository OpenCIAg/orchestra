import * as i0 from '@angular/core';
import { input, ChangeDetectionStrategy, Component } from '@angular/core';

const _c0 = ["*"];
function FormFieldComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 2);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function FormFieldComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.error());
} }
function FormFieldComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.helperText());
} }
class FormFieldComponent {
    label = input('');
    helperText = input('');
    error = input('');
    required = input(false);
    static ɵfac = function FormFieldComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FormFieldComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormFieldComponent, selectors: [["orc-form-field"]], inputs: { label: [1, "label"], helperText: [1, "helperText"], error: [1, "error"], required: [1, "required"] }, ngContentSelectors: _c0, decls: 8, vars: 5, consts: [[1, "orc-form-field"], [1, "orc-form-field__label"], ["aria-hidden", "true"], [1, "orc-form-field__control"], ["role", "alert", 1, "orc-form-field__error"], [1, "orc-form-field__help"]], template: function FormFieldComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "label", 0)(1, "span", 1);
            i0.ɵɵtext(2);
            i0.ɵɵtemplate(3, FormFieldComponent_Conditional_3_Template, 2, 0, "span", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "span", 3);
            i0.ɵɵprojection(5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, FormFieldComponent_Conditional_6_Template, 2, 1, "span", 4)(7, FormFieldComponent_Conditional_7_Template, 2, 1, "span", 5);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-form-field--invalid", ctx.error());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1("", ctx.label(), " ");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.required() ? 3 : -1);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.error() ? 6 : ctx.helperText() ? 7 : -1);
        } }, styles: [".orc-form-field[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-form-field__label[_ngcontent-%COMP%]{font-size:.875rem;font-weight:600}.orc-form-field__help[_ngcontent-%COMP%], .orc-form-field__error[_ngcontent-%COMP%]{font-size:.75rem;color:var(--text-secondary)}.orc-form-field__error[_ngcontent-%COMP%]{color:var(--color-error)}.orc-form-field--invalid[_ngcontent-%COMP%]   .orc-form-field__control[_ngcontent-%COMP%]{--border-default:var(--color-error)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormFieldComponent, [{
        type: Component,
        args: [{ selector: 'orc-form-field', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<label class=\"orc-form-field\" [class.orc-form-field--invalid]=\"error()\"><span class=\"orc-form-field__label\">{{label()}} @if(required()){<span aria-hidden=\"true\">*</span>}</span><span class=\"orc-form-field__control\"><ng-content /></span>@if(error()){<span class=\"orc-form-field__error\" role=\"alert\">{{error()}}</span>}@else if(helperText()){<span class=\"orc-form-field__help\">{{helperText()}}</span>}</label>\n", styles: [".orc-form-field{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-form-field__label{font-size:.875rem;font-weight:600}.orc-form-field__help,.orc-form-field__error{font-size:.75rem;color:var(--text-secondary)}.orc-form-field__error{color:var(--color-error)}.orc-form-field--invalid .orc-form-field__control{--border-default:var(--color-error)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FormFieldComponent, { className: "FormFieldComponent", filePath: "form-field.component.ts", lineNumber: 3 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { FormFieldComponent };
//# sourceMappingURL=ciag-orchestra-form-field.mjs.map
