import * as i0 from '@angular/core';
import { input, model, output, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgressBarComponent } from '@ciag/orchestra/progress';

const _forTrack0 = ($index, $item) => $item.id || $index;
function StepperComponent_For_3_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 16);
} if (rf & 2) {
    const ɵ$index_5_r2 = i0.ɵɵnextContext().$index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-stepper__connector-line--completed", ctx_r2.isConnectorCompleted(ɵ$index_5_r2));
} }
function StepperComponent_For_3_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 7);
    i0.ɵɵelement(1, "polyline", 17);
    i0.ɵɵelementEnd();
} }
function StepperComponent_For_3_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "path", 18);
    i0.ɵɵelementEnd();
} }
function StepperComponent_For_3_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ɵ$index_5_r2 = i0.ɵɵnextContext().$index;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ɵ$index_5_r2 + 1);
} }
function StepperComponent_For_3_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 10);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const step_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(step_r5.icon);
} }
function StepperComponent_For_3_Conditional_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ɵ$index_5_r2 = i0.ɵɵnextContext().$index;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ɵ$index_5_r2 + 1);
} }
function StepperComponent_For_3_Conditional_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const step_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(step_r5.subtitle || step_r5.description);
} }
function StepperComponent_For_3_Conditional_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14);
    i0.ɵɵelement(1, "orc-progress-bar", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const step_r5 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", step_r5.progress)("showValue", true);
} }
function StepperComponent_For_3_Conditional_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 20);
} if (rf & 2) {
    const ɵ$index_5_r2 = i0.ɵɵnextContext().$index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-stepper__connector-line--completed", ctx_r2.isConnectorCompleted(ɵ$index_5_r2 + 1));
} }
function StepperComponent_For_3_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵdeclareLet(0)(1);
    i0.ɵɵelementStart(2, "li", 3);
    i0.ɵɵtemplate(3, StepperComponent_For_3_Conditional_3_Template, 1, 2, "div", 4);
    i0.ɵɵelementStart(4, "button", 5);
    i0.ɵɵlistener("click", function StepperComponent_For_3_Template_button_click_4_listener() { const ctx_r3 = i0.ɵɵrestoreView(_r1); const step_r5 = ctx_r3.$implicit; const ɵ$index_5_r2 = ctx_r3.$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.selectStep(ɵ$index_5_r2, step_r5)); });
    i0.ɵɵelementStart(5, "div", 6);
    i0.ɵɵtemplate(6, StepperComponent_For_3_Conditional_6_Template, 2, 0, ":svg:svg", 7)(7, StepperComponent_For_3_Conditional_7_Template, 2, 0, ":svg:svg", 8)(8, StepperComponent_For_3_Conditional_8_Template, 2, 1, "span", 9)(9, StepperComponent_For_3_Conditional_9_Template, 2, 1, "span", 10)(10, StepperComponent_For_3_Conditional_10_Template, 2, 1, "span", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "div", 11)(12, "span", 12);
    i0.ɵɵtext(13);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(14, StepperComponent_For_3_Conditional_14_Template, 2, 1, "span", 13)(15, StepperComponent_For_3_Conditional_15_Template, 2, 2, "div", 14);
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(16, StepperComponent_For_3_Conditional_16_Template, 1, 2, "div", 15);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const step_r5 = ctx.$implicit;
    const ɵ$index_5_r2 = ctx.$index;
    const ɵ$count_5_r6 = ctx.$count;
    const ctx_r2 = i0.ɵɵnextContext();
    const status_r7 = ctx_r2.getStepStatus(ɵ$index_5_r2, step_r5);
    const clickableState_r8 = ctx_r2.isStepClickable(ɵ$index_5_r2, step_r5);
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("orc-stepper__item--completed", status_r7 === "completed")("orc-stepper__item--active", status_r7 === "active")("orc-stepper__item--loading", status_r7 === "loading")("orc-stepper__item--pending", status_r7 === "pending")("orc-stepper__item--error", status_r7 === "error")("orc-stepper__item--disabled", step_r5.disabled)("orc-stepper__item--clickable", clickableState_r8);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.orientation() === "horizontal" && ɵ$index_5_r2 > 0 ? 3 : -1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("disabled", !clickableState_r8);
    i0.ɵɵattribute("aria-current", status_r7 === "active" ? "step" : null);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(status_r7 === "completed" ? 6 : status_r7 === "loading" || status_r7 === "active" && ctx_r2.orientation() === "vertical" ? 7 : ctx_r2.type() === "numeric" ? 8 : step_r5.icon ? 9 : 10);
    i0.ɵɵadvance(7);
    i0.ɵɵtextInterpolate(step_r5.title);
    i0.ɵɵadvance();
    i0.ɵɵconditional(step_r5.subtitle || step_r5.description ? 14 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(step_r5.progress !== undefined && (status_r7 === "active" || ctx_r2.orientation() === "vertical") ? 15 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.orientation() === "vertical" && !(ɵ$index_5_r2 === ɵ$count_5_r6 - 1) ? 16 : -1);
} }
class StepperComponent {
    // ── Inputs & Models ───────────────────────────────────────
    /** Lista de etapas a serem exibidas */
    steps = input([]);
    /** Índice da etapa ativa atual (0-indexed) */
    currentStep = model(0);
    /** Orientação do layout: 'horizontal' ou 'vertical' */
    orientation = input('horizontal');
    /** Estilo dos marcadores de etapa: 'numeric' (1, 2, 3...) ou 'icon' */
    type = input('numeric');
    /** Permite que o usuário clique nos passos para navegar */
    clickable = input(true);
    /** Modo linear: impede pular etapas à frente */
    linear = input(false);
    /** Evento emitido quando o usuário clica em uma etapa */
    stepChange = output();
    // ── Helpers & Métodos ─────────────────────────────────────
    getStepStatus(index, step) {
        if (step.status)
            return step.status;
        const current = this.currentStep();
        if (index < current)
            return 'completed';
        if (index === current)
            return 'active';
        return 'pending';
    }
    isStepClickable(index, step) {
        if (step.disabled || !this.clickable())
            return false;
        if (this.linear() && index > this.currentStep() + 1)
            return false;
        return true;
    }
    selectStep(index, step) {
        if (!this.isStepClickable(index, step))
            return;
        this.currentStep.set(index);
        this.stepChange.emit({ step, index });
    }
    isConnectorCompleted(index) {
        return index < this.currentStep();
    }
    static ɵfac = function StepperComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || StepperComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StepperComponent, selectors: [["orc-stepper"]], inputs: { steps: [1, "steps"], currentStep: [1, "currentStep"], orientation: [1, "orientation"], type: [1, "type"], clickable: [1, "clickable"], linear: [1, "linear"] }, outputs: { currentStep: "currentStepChange", stepChange: "stepChange" }, decls: 4, vars: 8, consts: [["aria-label", "Etapas do processo", 1, "orc-stepper"], [1, "orc-stepper__list"], [1, "orc-stepper__item", 3, "orc-stepper__item--completed", "orc-stepper__item--active", "orc-stepper__item--loading", "orc-stepper__item--pending", "orc-stepper__item--error", "orc-stepper__item--disabled", "orc-stepper__item--clickable"], [1, "orc-stepper__item"], [1, "orc-stepper__connector-line", "orc-stepper__connector-line--horizontal", 3, "orc-stepper__connector-line--completed"], ["type", "button", 1, "orc-stepper__step-btn", 3, "click", "disabled"], [1, "orc-stepper__marker"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "orc-stepper__icon", "orc-stepper__icon--check"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "orc-stepper__icon", "orc-stepper__icon--spin"], [1, "orc-stepper__number"], [1, "orc-stepper__custom-icon"], [1, "orc-stepper__content"], [1, "orc-stepper__title"], [1, "orc-stepper__subtitle"], [1, "orc-stepper__step-progress"], [1, "orc-stepper__connector-line", "orc-stepper__connector-line--vertical", 3, "orc-stepper__connector-line--completed"], [1, "orc-stepper__connector-line", "orc-stepper__connector-line--horizontal"], ["points", "20 6 9 17 4 12"], ["d", "M21 12a9 9 0 1 1-6.219-8.56"], ["variant", "primary", "label", "Progresso", 3, "value", "showValue"], [1, "orc-stepper__connector-line", "orc-stepper__connector-line--vertical"]], template: function StepperComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "nav", 0)(1, "ol", 1);
            i0.ɵɵrepeaterCreate(2, StepperComponent_For_3_Template, 17, 22, "li", 2, _forTrack0);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-stepper--horizontal", ctx.orientation() === "horizontal")("orc-stepper--vertical", ctx.orientation() === "vertical")("orc-stepper--numeric", ctx.type() === "numeric")("orc-stepper--icon", ctx.type() === "icon");
            i0.ɵɵadvance(2);
            i0.ɵɵrepeater(ctx.steps());
        } }, dependencies: [CommonModule, ProgressBarComponent], styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-stepper[_ngcontent-%COMP%]{width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-stepper__list[_ngcontent-%COMP%]{display:flex;margin:0;padding:0;list-style:none}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__list[_ngcontent-%COMP%]{flex-direction:row;align-items:flex-start;justify-content:space-between;width:100%}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item[_ngcontent-%COMP%]{display:flex;flex:1;align-items:flex-start;position:relative}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item[_ngcontent-%COMP%]:last-child{flex:0 0 auto}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__step-btn[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;text-align:center;background:none;border:none;padding:0;margin:0;cursor:default;min-width:100px;outline:none;transition:transform var(--transition-fast)}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--clickable[_ngcontent-%COMP%]   .orc-stepper__step-btn[_ngcontent-%COMP%]{cursor:pointer}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--clickable[_ngcontent-%COMP%]   .orc-stepper__step-btn[_ngcontent-%COMP%]:hover   .orc-stepper__marker[_ngcontent-%COMP%]{transform:scale(1.05)}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__connector-line--horizontal[_ngcontent-%COMP%]{flex:1;height:3px;background-color:var(--orc-border, #d9d9d9);margin:19px 8px 0;align-self:flex-start;transition:background-color .3s ease}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__connector-line--horizontal.orc-stepper__connector-line--completed[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:20px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;font-size:16px;font-weight:500;transition:all .3s ease;box-sizing:border-box}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--completed[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--completed[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414);font-weight:500}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--active[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff;border:2px solid #ffffff;box-shadow:0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--active[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--pending[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:var(--orc-border, #d9d9d9);color:#fff}.orc-stepper--horizontal[_ngcontent-%COMP%]   .orc-stepper__item--pending[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:#929292;font-weight:400}.orc-stepper--horizontal.orc-stepper--icon[_ngcontent-%COMP%]   .orc-stepper__item--active[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:#1c6aed33;color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal.orc-stepper--icon[_ngcontent-%COMP%]   .orc-stepper__item--pending[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:var(--orc-th, #f9f9f9);color:#929292;border:1px solid var(--orc-border, #d9d9d9)}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__list[_ngcontent-%COMP%]{flex-direction:column;width:100%}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item[_ngcontent-%COMP%]{position:relative;display:flex;flex-direction:column;width:100%}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__step-btn[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:16px;width:100%;text-align:left;background:none;border:none;padding:0;margin:0;cursor:default;outline:none}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--clickable[_ngcontent-%COMP%]   .orc-stepper__step-btn[_ngcontent-%COMP%]{cursor:pointer}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{width:32px;height:32px;border-radius:200px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box;transition:all .3s ease}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__connector-line--vertical[_ngcontent-%COMP%]{width:2px;min-height:36px;background-color:var(--orc-border, #d9d9d9);margin-left:15px;margin-top:4px;margin-bottom:4px;transition:background-color .3s ease}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__connector-line--vertical.orc-stepper__connector-line--completed[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__content[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;flex:1;padding-top:2px;padding-bottom:16px}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--completed[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);border:2px solid var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--completed[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:500}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--active[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:#fff;border:2px solid var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--active[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--pending[_ngcontent-%COMP%]   .orc-stepper__marker[_ngcontent-%COMP%]{background-color:#fff;border:2px solid var(--orc-border, #d9d9d9);color:var(--orc-font-secondary, #58595b)}.orc-stepper--vertical[_ngcontent-%COMP%]   .orc-stepper__item--pending[_ngcontent-%COMP%]   .orc-stepper__title[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #58595b);font-weight:500}.orc-stepper__content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:inherit}.orc-stepper__title[_ngcontent-%COMP%]{font-size:14px;line-height:20px;font-weight:500;transition:color var(--transition-fast)}.orc-stepper__subtitle[_ngcontent-%COMP%]{font-size:12px;line-height:16px;color:#929292;margin-top:2px}.orc-stepper__step-progress[_ngcontent-%COMP%]{margin-top:8px;width:100%}.orc-stepper__icon[_ngcontent-%COMP%]{width:18px;height:18px}.orc-stepper__icon--spin[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_orc-step-spin 1.5s linear infinite}.orc-stepper__custom-icon[_ngcontent-%COMP%]{font-size:18px;line-height:1}@keyframes _ngcontent-%COMP%_orc-step-spin{to{transform:rotate(360deg)}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StepperComponent, [{
        type: Component,
        args: [{ selector: 'orc-stepper', standalone: true, imports: [CommonModule, ProgressBarComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav class=\"orc-stepper\" [class.orc-stepper--horizontal]=\"orientation() === 'horizontal'\"\n  [class.orc-stepper--vertical]=\"orientation() === 'vertical'\" [class.orc-stepper--numeric]=\"type() === 'numeric'\"\n  [class.orc-stepper--icon]=\"type() === 'icon'\" aria-label=\"Etapas do processo\">\n  <ol class=\"orc-stepper__list\">\n    @for (step of steps(); track step.id || $index; let idx = $index; let isLast = $last) {\n    @let status = getStepStatus(idx, step);\n    @let clickableState = isStepClickable(idx, step);\n\n    <li class=\"orc-stepper__item\" [class.orc-stepper__item--completed]=\"status === 'completed'\"\n      [class.orc-stepper__item--active]=\"status === 'active'\" [class.orc-stepper__item--loading]=\"status === 'loading'\"\n      [class.orc-stepper__item--pending]=\"status === 'pending'\" [class.orc-stepper__item--error]=\"status === 'error'\"\n      [class.orc-stepper__item--disabled]=\"step.disabled\" [class.orc-stepper__item--clickable]=\"clickableState\">\n      <!-- Horizontal Connector Line (Before Step, if not first) -->\n      @if (orientation() === 'horizontal' && idx > 0) {\n      <div class=\"orc-stepper__connector-line orc-stepper__connector-line--horizontal\"\n        [class.orc-stepper__connector-line--completed]=\"isConnectorCompleted(idx)\"></div>\n      }\n\n      <!-- Step Trigger Button / Container -->\n      <button type=\"button\" class=\"orc-stepper__step-btn\" [disabled]=\"!clickableState\" (click)=\"selectStep(idx, step)\"\n        [attr.aria-current]=\"status === 'active' ? 'step' : null\">\n        <!-- Marker Circle (Number or Icon) -->\n        <div class=\"orc-stepper__marker\">\n          @if (status === 'completed') {\n          <!-- Checkmark SVG -->\n          <svg class=\"orc-stepper__icon orc-stepper__icon--check\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\"\n            stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <polyline points=\"20 6 9 17 4 12\"></polyline>\n          </svg>\n          } @else if (status === 'loading' || (status === 'active' && orientation() === 'vertical')) {\n          <!-- Spinner / Loader SVG -->\n          <svg class=\"orc-stepper__icon orc-stepper__icon--spin\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\"\n            stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M21 12a9 9 0 1 1-6.219-8.56\"></path>\n          </svg>\n          } @else if (type() === 'numeric') {\n          <!-- Step Number -->\n          <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n          } @else if (step.icon) {\n          <!-- Custom Icon or Text -->\n          <span class=\"orc-stepper__custom-icon\">{{ step.icon }}</span>\n          } @else {\n          <!-- Fallback to Number -->\n          <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n          }\n        </div>\n\n        <!-- Step Label & Description -->\n        <div class=\"orc-stepper__content\">\n          <span class=\"orc-stepper__title\">{{ step.title }}</span>\n          @if (step.subtitle || step.description) {\n          <span class=\"orc-stepper__subtitle\">{{ step.subtitle || step.description }}</span>\n          }\n\n          <!-- Embedded Progress Bar in Step (Figma Vertical Stepper Spec) -->\n          @if (step.progress !== undefined && (status === 'active' || orientation() === 'vertical')) {\n          <div class=\"orc-stepper__step-progress\">\n            <orc-progress-bar [value]=\"step.progress\" variant=\"primary\" label=\"Progresso\" [showValue]=\"true\" />\n          </div>\n          }\n        </div>\n      </button>\n\n      <!-- Vertical Connector Line (Below step, if not last) -->\n      @if (orientation() === 'vertical' && !isLast) {\n      <div class=\"orc-stepper__connector-line orc-stepper__connector-line--vertical\"\n        [class.orc-stepper__connector-line--completed]=\"isConnectorCompleted(idx + 1)\"></div>\n      }\n    </li>\n    }\n  </ol>\n</nav>", styles: [":host{display:block;width:100%}.orc-stepper{width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-stepper__list{display:flex;margin:0;padding:0;list-style:none}.orc-stepper--horizontal .orc-stepper__list{flex-direction:row;align-items:flex-start;justify-content:space-between;width:100%}.orc-stepper--horizontal .orc-stepper__item{display:flex;flex:1;align-items:flex-start;position:relative}.orc-stepper--horizontal .orc-stepper__item:last-child{flex:0 0 auto}.orc-stepper--horizontal .orc-stepper__step-btn{display:flex;flex-direction:column;align-items:center;text-align:center;background:none;border:none;padding:0;margin:0;cursor:default;min-width:100px;outline:none;transition:transform var(--transition-fast)}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn:hover .orc-stepper__marker{transform:scale(1.05)}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal{flex:1;height:3px;background-color:var(--orc-border, #d9d9d9);margin:19px 8px 0;align-self:flex-start;transition:background-color .3s ease}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal.orc-stepper__connector-line--completed{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal .orc-stepper__marker{width:40px;height:40px;border-radius:20px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;font-size:16px;font-weight:500;transition:all .3s ease;box-sizing:border-box}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-font-main, #141414);font-weight:500}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:#fff;border:2px solid #ffffff;box-shadow:0 0 0 1px var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__title{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-border, #d9d9d9);color:#fff}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__title{color:#929292;font-weight:400}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--active .orc-stepper__marker{background-color:#1c6aed33;color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-th, #f9f9f9);color:#929292;border:1px solid var(--orc-border, #d9d9d9)}.orc-stepper--vertical .orc-stepper__list{flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__item{position:relative;display:flex;flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__step-btn{display:flex;align-items:flex-start;gap:16px;width:100%;text-align:left;background:none;border:none;padding:0;margin:0;cursor:default;outline:none}.orc-stepper--vertical .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--vertical .orc-stepper__marker{width:32px;height:32px;border-radius:200px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box;transition:all .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical{width:2px;min-height:36px;background-color:var(--orc-border, #d9d9d9);margin-left:15px;margin-top:4px;margin-bottom:4px;transition:background-color .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical.orc-stepper__connector-line--completed{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--vertical .orc-stepper__content{display:flex;flex-direction:column;gap:4px;flex:1;padding-top:2px;padding-bottom:16px}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-color-azul-eletrico, #1c6aed);border:2px solid var(--orc-color-azul-eletrico, #1c6aed);color:#fff}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:500}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__marker{background-color:#fff;border:2px solid var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__title{color:var(--orc-color-azul-eletrico, #1c6aed);font-weight:600}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__marker{background-color:#fff;border:2px solid var(--orc-border, #d9d9d9);color:var(--orc-font-secondary, #58595b)}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__title{color:var(--orc-font-secondary, #58595b);font-weight:500}.orc-stepper__content{display:flex;flex-direction:column;align-items:inherit}.orc-stepper__title{font-size:14px;line-height:20px;font-weight:500;transition:color var(--transition-fast)}.orc-stepper__subtitle{font-size:12px;line-height:16px;color:#929292;margin-top:2px}.orc-stepper__step-progress{margin-top:8px;width:100%}.orc-stepper__icon{width:18px;height:18px}.orc-stepper__icon--spin{animation:orc-step-spin 1.5s linear infinite}.orc-stepper__custom-icon{font-size:18px;line-height:1}@keyframes orc-step-spin{to{transform:rotate(360deg)}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(StepperComponent, { className: "StepperComponent", filePath: "stepper.component.ts", lineNumber: 26 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { StepperComponent };
//# sourceMappingURL=ciag-orchestra-stepper.mjs.map
