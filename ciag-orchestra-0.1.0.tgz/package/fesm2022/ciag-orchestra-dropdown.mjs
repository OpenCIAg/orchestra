import * as i0 from '@angular/core';
import { input, output, inject, ElementRef, ViewContainerRef, viewChild, signal, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';

const _c0 = ["dropdownPanel"];
const _c1 = ["*"];
const _forTrack0 = ($index, $item) => $item.id || $item.label;
function DropdownComponent_ng_template_1_For_2_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 2);
} }
function DropdownComponent_ng_template_1_For_2_Conditional_1_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 5);
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵproperty("innerHTML", item_r2.icon, i0.ɵɵsanitizeHtml);
} }
function DropdownComponent_ng_template_1_For_2_Conditional_1_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 7);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.shortcut);
} }
function DropdownComponent_ng_template_1_For_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 4);
    i0.ɵɵlistener("click", function DropdownComponent_ng_template_1_For_2_Conditional_1_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r1); const item_r2 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onItemClick(item_r2, $event)); })("keydown", function DropdownComponent_ng_template_1_For_2_Conditional_1_Template_button_keydown_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.onItemKeydown($event)); });
    i0.ɵɵtemplate(1, DropdownComponent_ng_template_1_For_2_Conditional_1_Conditional_1_Template, 1, 1, "span", 5);
    i0.ɵɵelementStart(2, "span", 6);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, DropdownComponent_ng_template_1_For_2_Conditional_1_Conditional_4_Template, 2, 1, "span", 7);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵclassProp("orc-dropdown-item--danger", item_r2.danger)("orc-dropdown-item--disabled", item_r2.disabled);
    i0.ɵɵproperty("disabled", item_r2.disabled);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.icon ? 1 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.shortcut ? 4 : -1);
} }
function DropdownComponent_ng_template_1_For_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, DropdownComponent_ng_template_1_For_2_Conditional_0_Template, 1, 0, "div", 2)(1, DropdownComponent_ng_template_1_For_2_Conditional_1_Template, 5, 8, "button", 3);
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵconditional(item_r2.divider ? 0 : 1);
} }
function DropdownComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵrepeaterCreate(1, DropdownComponent_ng_template_1_For_2_Template, 2, 1, null, null, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r2.items());
} }
class DropdownComponent {
    items = input([]);
    placement = input('bottom-start');
    itemSelect = output();
    overlayRef = null;
    portal;
    hostEl = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    overlay = inject(Overlay);
    dropdownPanel = viewChild.required('dropdownPanel');
    isOpen = signal(false);
    ngAfterViewInit() {
        this.portal = new TemplatePortal(this.dropdownPanel(), this.viewContainerRef);
    }
    open() {
        if (this.isOpen())
            return;
        const positionStrategy = this.createPositionStrategy();
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        this.overlayRef.backdropClick().subscribe(() => this.close());
        this.overlayRef.keydownEvents().subscribe((event) => {
            if (event.key === 'Escape') {
                this.close();
                event.stopPropagation();
            }
        });
        this.overlayRef.attach(this.portal);
        this.isOpen.set(true);
        setTimeout(() => this.overlayRef?.overlayElement.querySelector('[role="menuitem"]:not([disabled])')?.focus());
    }
    close() {
        if (!this.isOpen())
            return;
        this.overlayRef?.dispose();
        this.overlayRef = null;
        this.isOpen.set(false);
    }
    toggle() {
        this.isOpen() ? this.close() : this.open();
    }
    onItemClick(item, $event) {
        if (item.disabled) {
            $event.stopPropagation();
            return;
        }
        if (item.children?.length) {
            return;
        }
        this.itemSelect.emit(item);
        item.action?.();
        this.close();
    }
    onItemKeydown(event) {
        const current = event.currentTarget;
        const menu = current.closest('[role="menu"]');
        const buttons = Array.from(menu?.querySelectorAll('[role="menuitem"]:not([disabled])') ?? []);
        const index = buttons.indexOf(current);
        if (!buttons.length || index < 0)
            return;
        const target = event.key === 'ArrowDown' ? buttons[(index + 1) % buttons.length]
            : event.key === 'ArrowUp' ? buttons[(index - 1 + buttons.length) % buttons.length]
                : event.key === 'Home' ? buttons[0]
                    : event.key === 'End' ? buttons[buttons.length - 1]
                        : undefined;
        if (target) {
            event.preventDefault();
            target.focus();
        }
    }
    createPositionStrategy() {
        const positions = this.getConnectedPositions();
        return this.overlay
            .position()
            .flexibleConnectedTo(this.hostEl)
            .withPositions(positions)
            .withFlexibleDimensions(false)
            .withPush(true);
    }
    getConnectedPositions() {
        switch (this.placement()) {
            case 'bottom-end':
                return [{ originX: 'end', originY: 'bottom', overlayX: 'end', overlayY: 'top' }];
            case 'top-start':
                return [{ originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'bottom' }];
            case 'top-end':
                return [{ originX: 'end', originY: 'top', overlayX: 'end', overlayY: 'bottom' }];
            default:
                return [{ originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top' }];
        }
    }
    onDocumentClick(target) {
        if (!this.isOpen())
            return;
        const inside = target instanceof Node && this.hostEl.nativeElement.contains(target);
        if (!inside)
            this.close();
    }
    static ɵfac = function DropdownComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DropdownComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DropdownComponent, selectors: [["orc-dropdown"]], viewQuery: function DropdownComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.dropdownPanel, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, hostBindings: function DropdownComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("click", function DropdownComponent_click_HostBindingHandler($event) { return ctx.onDocumentClick($event.target); }, false, i0.ɵɵresolveDocument);
        } }, inputs: { items: [1, "items"], placement: [1, "placement"] }, outputs: { itemSelect: "itemSelect" }, ngContentSelectors: _c1, decls: 3, vars: 0, consts: [["dropdownPanel", ""], ["role", "menu", 1, "orc-dropdown-menu"], ["role", "separator", 1, "orc-dropdown-divider"], ["type", "button", "role", "menuitem", 1, "orc-dropdown-item", 3, "orc-dropdown-item--danger", "orc-dropdown-item--disabled", "disabled"], ["type", "button", "role", "menuitem", 1, "orc-dropdown-item", 3, "click", "keydown", "disabled"], [1, "orc-dropdown-item__icon", 3, "innerHTML"], [1, "orc-dropdown-item__label"], [1, "orc-dropdown-item__shortcut"]], template: function DropdownComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵprojection(0);
            i0.ɵɵtemplate(1, DropdownComponent_ng_template_1_Template, 3, 0, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } }, styles: ["[_nghost-%COMP%]{display:inline-block}.orc-dropdown-menu[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:180px;background-color:var(--orc-bg);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-1);z-index:var(--z-dropdown);overflow:hidden}.orc-dropdown-item[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);width:100%;padding:var(--space-2) var(--space-3);font-family:var(--font-sans);font-size:.875rem;color:var(--text-primary);background:transparent;border:none;border-radius:var(--radius-sm);cursor:pointer;text-align:left;transition:background-color var(--transition-fast),color var(--transition-fast)}.orc-dropdown-item[_ngcontent-%COMP%]:hover:not(:disabled){background-color:var(--bg-muted)}.orc-dropdown-item--danger[_ngcontent-%COMP%]{color:var(--color-error)}.orc-dropdown-item--danger[_ngcontent-%COMP%]:hover:not(:disabled){background-color:#fb2c361a}.orc-dropdown-item--disabled[_ngcontent-%COMP%], .orc-dropdown-item[_ngcontent-%COMP%]:disabled{opacity:.5;cursor:not-allowed}.orc-dropdown-item__icon[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:16px;height:16px}.orc-dropdown-item__label[_ngcontent-%COMP%]{flex:1}.orc-dropdown-item__shortcut[_ngcontent-%COMP%]{font-size:.75rem;color:var(--text-muted);font-family:var(--font-mono)}.orc-dropdown-divider[_ngcontent-%COMP%]{height:1px;margin:var(--space-1) 0;background-color:var(--border-default)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DropdownComponent, [{
        type: Component,
        args: [{ selector: 'orc-dropdown', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content></ng-content>\n\n<ng-template #dropdownPanel>\n  <div class=\"orc-dropdown-menu\" role=\"menu\">\n    @for (item of items(); track item.id || item.label) {\n      @if (item.divider) {\n        <div class=\"orc-dropdown-divider\" role=\"separator\"></div>\n      } @else {\n        <button\n          type=\"button\"\n          class=\"orc-dropdown-item\"\n          [class.orc-dropdown-item--danger]=\"item.danger\"\n          [class.orc-dropdown-item--disabled]=\"item.disabled\"\n          [disabled]=\"item.disabled\"\n          role=\"menuitem\"\n          (click)=\"onItemClick(item, $event)\"\n          (keydown)=\"onItemKeydown($event)\"\n        >\n          @if (item.icon) {\n            <span class=\"orc-dropdown-item__icon\" [innerHTML]=\"item.icon\"></span>\n          }\n          <span class=\"orc-dropdown-item__label\">{{ item.label }}</span>\n          @if (item.shortcut) {\n            <span class=\"orc-dropdown-item__shortcut\">{{ item.shortcut }}</span>\n          }\n        </button>\n      }\n    }\n  </div>\n</ng-template>\n", styles: [":host{display:inline-block}.orc-dropdown-menu{display:flex;flex-direction:column;min-width:180px;background-color:var(--orc-bg);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-1);z-index:var(--z-dropdown);overflow:hidden}.orc-dropdown-item{display:flex;align-items:center;gap:var(--space-2);width:100%;padding:var(--space-2) var(--space-3);font-family:var(--font-sans);font-size:.875rem;color:var(--text-primary);background:transparent;border:none;border-radius:var(--radius-sm);cursor:pointer;text-align:left;transition:background-color var(--transition-fast),color var(--transition-fast)}.orc-dropdown-item:hover:not(:disabled){background-color:var(--bg-muted)}.orc-dropdown-item--danger{color:var(--color-error)}.orc-dropdown-item--danger:hover:not(:disabled){background-color:#fb2c361a}.orc-dropdown-item--disabled,.orc-dropdown-item:disabled{opacity:.5;cursor:not-allowed}.orc-dropdown-item__icon{display:flex;align-items:center;justify-content:center;width:16px;height:16px}.orc-dropdown-item__label{flex:1}.orc-dropdown-item__shortcut{font-size:.75rem;color:var(--text-muted);font-family:var(--font-mono)}.orc-dropdown-divider{height:1px;margin:var(--space-1) 0;background-color:var(--border-default)}\n"] }]
    }], null, { onDocumentClick: [{
            type: HostListener,
            args: ['document:click', ['$event.target']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DropdownComponent, { className: "DropdownComponent", filePath: "dropdown.component.ts", lineNumber: 27 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { DropdownComponent };
//# sourceMappingURL=ciag-orchestra-dropdown.mjs.map
