import * as i0 from '@angular/core';
import { inject, ElementRef, input, numberAttribute, booleanAttribute, model, signal, computed, forwardRef, ChangeDetectionStrategy, Component, HostListener, ContentChild } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { TooltipDirective } from '@ciag/orchestra/tooltip';

const _c0 = ["customIcon"];
function RatingComponent_For_3_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "span", 6);
    i0.ɵɵlistener("click", function RatingComponent_For_3_Conditional_1_Template_span_click_0_listener($event) { i0.ɵɵrestoreView(_r2); const i_r3 = i0.ɵɵnextContext().$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemClick($event, i_r3)); })("mouseenter", function RatingComponent_For_3_Conditional_1_Template_span_mouseenter_0_listener() { i0.ɵɵrestoreView(_r2); const i_r3 = i0.ɵɵnextContext().$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemHover(i_r3)); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const i_r3 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i_r3, " ");
} }
function RatingComponent_For_3_Conditional_2_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 12);
    i0.ɵɵlistener("click", function RatingComponent_For_3_Conditional_2_Conditional_0_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r5); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemClick($event, i_r3, true)); })("mouseenter", function RatingComponent_For_3_Conditional_2_Conditional_0_Template_div_mouseenter_0_listener() { i0.ɵɵrestoreView(_r5); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemHover(i_r3, true)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(1, "div", 13);
    i0.ɵɵlistener("click", function RatingComponent_For_3_Conditional_2_Conditional_0_Template_div_click_1_listener($event) { i0.ɵɵrestoreView(_r5); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemClick($event, i_r3, false)); })("mouseenter", function RatingComponent_For_3_Conditional_2_Conditional_0_Template_div_mouseenter_1_listener() { i0.ɵɵrestoreView(_r5); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemHover(i_r3, false)); });
    i0.ɵɵelementEnd();
} }
function RatingComponent_For_3_Conditional_2_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 14);
    i0.ɵɵlistener("click", function RatingComponent_For_3_Conditional_2_Conditional_1_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r6); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemClick($event, i_r3)); })("mouseenter", function RatingComponent_For_3_Conditional_2_Conditional_1_Template_div_mouseenter_0_listener() { i0.ɵɵrestoreView(_r6); const i_r3 = i0.ɵɵnextContext(2).$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onItemHover(i_r3)); });
    i0.ɵɵelementEnd();
} }
function RatingComponent_For_3_Conditional_2_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function RatingComponent_For_3_Conditional_2_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function RatingComponent_For_3_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, RatingComponent_For_3_Conditional_2_Conditional_0_Template, 2, 0)(1, RatingComponent_For_3_Conditional_2_Conditional_1_Template, 1, 0, "div", 7);
    i0.ɵɵelementStart(2, "div", 8);
    i0.ɵɵtemplate(3, RatingComponent_For_3_Conditional_2_ng_container_3_Template, 1, 0, "ng-container", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 10)(5, "div", 11);
    i0.ɵɵtemplate(6, RatingComponent_For_3_Conditional_2_ng_container_6_Template, 1, 0, "ng-container", 9);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const i_r3 = i0.ɵɵnextContext().$implicit;
    const ctx_r3 = i0.ɵɵnextContext();
    const defaultStar_r7 = i0.ɵɵreference(5);
    i0.ɵɵconditional(ctx_r3.allowHalf() ? 0 : 1);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r3.customIconTemplate || defaultStar_r7);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("width", ctx_r3.displayValue() >= i_r3 ? 100 : ctx_r3.displayValue() > i_r3 - 1 ? (ctx_r3.displayValue() - (i_r3 - 1)) * 100 : 0, "%");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r3.customIconTemplate || defaultStar_r7);
} }
function RatingComponent_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵtemplate(1, RatingComponent_For_3_Conditional_1_Template, 2, 1, "span", 5)(2, RatingComponent_For_3_Conditional_2_Template, 7, 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const i_r3 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-rating__item--disabled", ctx_r3.effectiveDisabled())("orc-rating__item--readonly", ctx_r3.readonly())("orc-rating__item--numeric", ctx_r3.numeric())("is-filled", ctx_r3.numeric() && ctx_r3.displayValue() >= i_r3);
    i0.ɵɵproperty("orcTooltip", ctx_r3.getTooltip(i_r3));
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r3.numeric() ? 1 : 2);
} }
function RatingComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 15);
    i0.ɵɵelement(1, "path", 16);
    i0.ɵɵelementEnd();
} }
let nextUniqueId = 0;
class RatingComponent {
    elementRef = inject((ElementRef));
    uniqueId = `orc-rating-${++nextUniqueId}`;
    // -- Inputs ---------------------------------------------------------
    id = input(this.uniqueId);
    max = input(5, { transform: numberAttribute });
    allowHalf = input(false, { transform: booleanAttribute });
    numeric = input(false, { transform: booleanAttribute });
    clearable = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    disabled = input(false, { transform: booleanAttribute });
    // Array de rótulos ex: ['Péssimo', 'Ruim', 'Regular', 'Bom', 'Excelente']
    tooltips = input([]);
    // Custom SVG via TemplateRef
    customIconTemplate;
    // -- Value (Model / CVA) ------------------------------------------
    value = model(0);
    // -- Internal State -----------------------------------------------
    hoverValue = signal(null);
    cvaDisabled = signal(false);
    isFocused = signal(false);
    // -- Computeds ----------------------------------------------------
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    starsArray = computed(() => Array.from({ length: this.max() }, (_, i) => i + 1));
    displayValue = computed(() => {
        const hover = this.hoverValue();
        return hover !== null ? hover : this.value();
    });
    // -- ControlValueAccessor -----------------------------------------
    onChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        const num = typeof val === 'number' ? val : parseFloat(val);
        this.value.set(!isNaN(num) ? num : 0);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // -- Interactions -------------------------------------------------
    onItemClick(event, index, isHalf = false) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        // In numeric mode, we ignore half clicks.
        let selectedValue = this.numeric() ? index : (isHalf && this.allowHalf() ? index - 0.5 : index);
        if (this.clearable() && this.value() === selectedValue) {
            selectedValue = 0;
        }
        this.updateValue(selectedValue);
        this.onTouched();
    }
    onItemHover(index, isHalf = false) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const hValue = this.numeric() ? index : (isHalf && this.allowHalf() ? index - 0.5 : index);
        this.hoverValue.set(hValue);
    }
    onMouseLeave() {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.hoverValue.set(null);
    }
    onFocus() {
        if (this.effectiveDisabled())
            return;
        this.isFocused.set(true);
    }
    onBlur() {
        if (this.effectiveDisabled())
            return;
        this.isFocused.set(false);
        this.onTouched();
    }
    updateValue(val) {
        const safeVal = Math.max(0, Math.min(val, this.max()));
        this.value.set(safeVal);
        this.onChange(safeVal);
    }
    // -- Keyboard Navigation (WCAG) -----------------------------------
    onKeydown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const step = this.allowHalf() && !this.numeric() ? 0.5 : 1;
        let current = this.value();
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowUp':
                event.preventDefault();
                this.updateValue(current + step);
                break;
            case 'ArrowLeft':
            case 'ArrowDown':
                event.preventDefault();
                this.updateValue(current - step);
                break;
            case 'Home':
                event.preventDefault();
                this.updateValue(this.allowHalf() ? 0.5 : 1);
                break;
            case 'End':
                event.preventDefault();
                this.updateValue(this.max());
                break;
            case 'Escape':
            case '0':
                if (this.clearable()) {
                    event.preventDefault();
                    this.updateValue(0);
                }
                break;
        }
    }
    // -- Accessibility Helpers ----------------------------------------
    getTooltip(index) {
        // index is 1-based
        const tt = this.tooltips();
        if (!tt || tt.length === 0)
            return undefined;
        return tt[index - 1] || undefined;
    }
    static ɵfac = function RatingComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || RatingComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RatingComponent, selectors: [["orc-rating"]], contentQueries: function RatingComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuery(dirIndex, _c0, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.customIconTemplate = _t.first);
        } }, hostBindings: function RatingComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown", function RatingComponent_keydown_HostBindingHandler($event) { return ctx.onKeydown($event); });
        } }, inputs: { id: [1, "id"], max: [1, "max"], allowHalf: [1, "allowHalf"], numeric: [1, "numeric"], clearable: [1, "clearable"], readonly: [1, "readonly"], disabled: [1, "disabled"], tooltips: [1, "tooltips"], value: [1, "value"] }, outputs: { value: "valueChange" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => RatingComponent),
                    multi: true,
                },
            ])], decls: 6, vars: 10, consts: [["defaultStar", ""], ["role", "slider", 1, "orc-rating", 3, "focus", "blur", "mouseleave", "id"], [1, "orc-rating__items"], [1, "orc-rating__item", 3, "orc-rating__item--disabled", "orc-rating__item--readonly", "orc-rating__item--numeric", "is-filled", "orcTooltip"], [1, "orc-rating__item", 3, "orcTooltip"], [1, "orc-rating__text"], [1, "orc-rating__text", 3, "click", "mouseenter"], [1, "orc-rating__half", "orc-rating__half--left", 2, "width", "100%"], [1, "orc-rating__icon"], [4, "ngTemplateOutlet"], [1, "orc-rating__icon", "orc-rating__icon--filled"], [1, "orc-rating__icon-content"], [1, "orc-rating__half", "orc-rating__half--left", 3, "click", "mouseenter"], [1, "orc-rating__half", "orc-rating__half--right", 3, "click", "mouseenter"], [1, "orc-rating__half", "orc-rating__half--left", 2, "width", "100%", 3, "click", "mouseenter"], ["viewBox", "0 0 24 24", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"]], template: function RatingComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵlistener("focus", function RatingComponent_Template_div_focus_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFocus()); })("blur", function RatingComponent_Template_div_blur_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur()); })("mouseleave", function RatingComponent_Template_div_mouseleave_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onMouseLeave()); });
            i0.ɵɵelementStart(1, "div", 2);
            i0.ɵɵrepeaterCreate(2, RatingComponent_For_3_Template, 3, 10, "div", 3, i0.ɵɵrepeaterTrackByIdentity);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(4, RatingComponent_ng_template_4_Template, 2, 0, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-rating--disabled", ctx.effectiveDisabled())("orc-rating--readonly", ctx.readonly());
            i0.ɵɵproperty("id", ctx.id());
            i0.ɵɵattribute("aria-valuenow", ctx.value())("aria-valuemin", 0)("aria-valuemax", ctx.max())("aria-valuetext", ctx.value() + " de " + ctx.max())("tabindex", ctx.effectiveDisabled() ? -1 : 0);
            i0.ɵɵadvance(2);
            i0.ɵɵrepeater(ctx.starsArray());
        } }, dependencies: [CommonModule, i1.NgTemplateOutlet, TooltipDirective], styles: [".orc-rating[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:var(--space-2);outline:none}.orc-rating[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:4px;border-radius:var(--radius-sm)}.orc-rating--disabled[_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed}.orc-rating--readonly[_ngcontent-%COMP%]{cursor:default}.orc-rating__items[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-1)}.orc-rating__item[_ngcontent-%COMP%]{position:relative;display:inline-flex;align-items:center;justify-content:center;color:var(--border-default);transition:transform var(--transition-fast);cursor:pointer}.orc-rating__item[_ngcontent-%COMP%]:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:scale(1.15)}.orc-rating__item--disabled[_ngcontent-%COMP%]{cursor:not-allowed}.orc-rating__item--readonly[_ngcontent-%COMP%]{cursor:default}.orc-rating__item[_ngcontent-%COMP%]   .orc-rating__half[_ngcontent-%COMP%]{position:absolute;top:0;bottom:0;width:50%;z-index:2}.orc-rating__item[_ngcontent-%COMP%]   .orc-rating__half--left[_ngcontent-%COMP%]{left:0}.orc-rating__item[_ngcontent-%COMP%]   .orc-rating__half--right[_ngcontent-%COMP%]{right:0}.orc-rating__item--numeric[_ngcontent-%COMP%]{width:40px;height:40px;border-radius:var(--radius-md);background-color:var(--orc-bg);border:1px solid var(--border-default);color:var(--text-secondary);font-size:1rem;font-weight:500;transition:all var(--transition-fast)}.orc-rating__item--numeric[_ngcontent-%COMP%]:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:none;border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-rating__item--numeric.is-filled[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-opposite-bw, #ffffff)}.orc-rating__icon[_ngcontent-%COMP%]{width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-rating__icon[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%]{width:100%;height:100%;fill:currentColor;transition:fill var(--transition-fast),color var(--transition-fast)}.orc-rating__icon--filled[_ngcontent-%COMP%]{position:absolute;top:0;left:0;color:var(--orc-color-laranja, #ff6a1c);overflow:hidden;width:0%;justify-content:flex-start;pointer-events:none}.orc-rating__icon-content[_ngcontent-%COMP%]{width:24px;height:24px;flex:0 0 24px;display:flex;align-items:center;justify-content:center}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RatingComponent, [{
        type: Component,
        args: [{ selector: 'orc-rating', standalone: true, imports: [CommonModule, TooltipDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => RatingComponent),
                        multi: true,
                    },
                ], template: "\n<div\n  class=\"orc-rating\"\n  [class.orc-rating--disabled]=\"effectiveDisabled()\"\n  [class.orc-rating--readonly]=\"readonly()\"\n  [id]=\"id()\"\n  role=\"slider\"\n  [attr.aria-valuenow]=\"value()\"\n  [attr.aria-valuemin]=\"0\"\n  [attr.aria-valuemax]=\"max()\"\n  [attr.aria-valuetext]=\"value() + ' de ' + max()\"\n  [attr.tabindex]=\"effectiveDisabled() ? -1 : 0\"\n  (focus)=\"onFocus()\"\n  (blur)=\"onBlur()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <div class=\"orc-rating__items\">\n    @for (i of starsArray(); track i) {\n      <!-- \n        i \u00E9 1-based (1, 2, 3...)\n        Para calcular o preenchimento, comparamos i com displayValue()\n      -->\n      <div\n        class=\"orc-rating__item\"\n        [class.orc-rating__item--disabled]=\"effectiveDisabled()\"\n        [class.orc-rating__item--readonly]=\"readonly()\"\n        [class.orc-rating__item--numeric]=\"numeric()\"\n        [class.is-filled]=\"numeric() && displayValue() >= i\"\n        [orcTooltip]=\"getTooltip(i)\"\n      >\n        @if (numeric()) {\n          <span class=\"orc-rating__text\" (click)=\"onItemClick($event, i)\" (mouseenter)=\"onItemHover(i)\">\n            {{ i }}\n          </span>\n        } @else {\n          <!-- \u00C1reas clic\u00E1veis invis\u00EDveis para capturar meia estrela ou estrela inteira -->\n          @if (allowHalf()) {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              (click)=\"onItemClick($event, i, true)\"\n              (mouseenter)=\"onItemHover(i, true)\"\n            ></div>\n            <div \n              class=\"orc-rating__half orc-rating__half--right\" \n              (click)=\"onItemClick($event, i, false)\"\n              (mouseenter)=\"onItemHover(i, false)\"\n            ></div>\n          } @else {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              style=\"width: 100%;\"\n              (click)=\"onItemClick($event, i)\"\n              (mouseenter)=\"onItemHover(i)\"\n            ></div>\n          }\n\n          <!-- \u00CDcone Base (Vazio) -->\n          <div class=\"orc-rating__icon\">\n            <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n          </div>\n\n          <!-- \u00CDcone Preenchido (Mascarado por largura) -->\n          <div class=\"orc-rating__icon orc-rating__icon--filled\"\n               [style.width.%]=\"displayValue() >= i ? 100 : (displayValue() > i - 1 ? (displayValue() - (i - 1)) * 100 : 0)\">\n            <div class=\"orc-rating__icon-content\">\n              <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n            </div>\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n\n<!-- Estrela SVG Padr\u00E3o -->\n<ng-template #defaultStar>\n  <svg viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n    <path d=\"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z\"/>\n  </svg>\n</ng-template>\n", styles: [".orc-rating{display:inline-flex;align-items:center;gap:var(--space-2);outline:none}.orc-rating:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:4px;border-radius:var(--radius-sm)}.orc-rating--disabled{opacity:.5;cursor:not-allowed}.orc-rating--readonly{cursor:default}.orc-rating__items{display:flex;align-items:center;gap:var(--space-1)}.orc-rating__item{position:relative;display:inline-flex;align-items:center;justify-content:center;color:var(--border-default);transition:transform var(--transition-fast);cursor:pointer}.orc-rating__item:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:scale(1.15)}.orc-rating__item--disabled{cursor:not-allowed}.orc-rating__item--readonly{cursor:default}.orc-rating__item .orc-rating__half{position:absolute;top:0;bottom:0;width:50%;z-index:2}.orc-rating__item .orc-rating__half--left{left:0}.orc-rating__item .orc-rating__half--right{right:0}.orc-rating__item--numeric{width:40px;height:40px;border-radius:var(--radius-md);background-color:var(--orc-bg);border:1px solid var(--border-default);color:var(--text-secondary);font-size:1rem;font-weight:500;transition:all var(--transition-fast)}.orc-rating__item--numeric:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:none;border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-rating__item--numeric.is-filled{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-opposite-bw, #ffffff)}.orc-rating__icon{width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-rating__icon svg{width:100%;height:100%;fill:currentColor;transition:fill var(--transition-fast),color var(--transition-fast)}.orc-rating__icon--filled{position:absolute;top:0;left:0;color:var(--orc-color-laranja, #ff6a1c);overflow:hidden;width:0%;justify-content:flex-start;pointer-events:none}.orc-rating__icon-content{width:24px;height:24px;flex:0 0 24px;display:flex;align-items:center;justify-content:center}\n"] }]
    }], null, { customIconTemplate: [{
            type: ContentChild,
            args: ['customIcon']
        }], onKeydown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(RatingComponent, { className: "RatingComponent", filePath: "rating.component.ts", lineNumber: 39 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { RatingComponent };
//# sourceMappingURL=ciag-orchestra-rating.mjs.map
