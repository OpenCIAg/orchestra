import * as i0 from '@angular/core';
import { InjectionToken, input, booleanAttribute, viewChild, inject, computed, ChangeDetectionStrategy, Component, model, output, signal, viewChildren, effect, forwardRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const ORC_OTP_INPUT = new InjectionToken('ORC_OTP_INPUT');

const _c0$1 = ["slotInput"];
class OtpSlotComponent {
    index = input(0);
    placeholder = input('');
    disabled = input(false, { transform: booleanAttribute });
    isFirst = input(false, { transform: booleanAttribute });
    isLast = input(false, { transform: booleanAttribute });
    inputElement = viewChild('slotInput');
    parentContext = inject(ORC_OTP_INPUT, { optional: true });
    value = computed(() => {
        if (!this.parentContext)
            return '';
        const values = this.parentContext.inputValues();
        return values[this.index()] || '';
    });
    inputMode = computed(() => {
        return this.parentContext ? this.parentContext.inputMode() : 'numeric';
    });
    effectivePlaceholder = computed(() => {
        return this.placeholder() || (this.parentContext ? this.parentContext.placeholder() : '');
    });
    isDisabled = computed(() => {
        return this.disabled() || (this.parentContext ? this.parentContext.isDisabled() : false);
    });
    ariaLabel = computed(() => {
        if (!this.parentContext)
            return `Dígito ${this.index() + 1}`;
        return `${this.parentContext.ariaLabel()} - dígito ${this.index() + 1} de ${this.parentContext.length()}`;
    });
    onInput(event) {
        this.parentContext?.onSlotInput(event, this.index());
    }
    onKeyDown(event) {
        this.parentContext?.onSlotKeyDown(event, this.index());
    }
    onPaste(event) {
        this.parentContext?.onSlotPaste(event, this.index());
    }
    onFocus() {
        this.parentContext?.onSlotFocus(this.index());
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = function OtpSlotComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OtpSlotComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OtpSlotComponent, selectors: [["orc-otp-slot"]], viewQuery: function OtpSlotComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.inputElement, _c0$1, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { index: [1, "index"], placeholder: [1, "placeholder"], disabled: [1, "disabled"], isFirst: [1, "isFirst"], isLast: [1, "isLast"] }, decls: 2, vars: 11, consts: [["slotInput", ""], ["type", "text", "maxlength", "1", 1, "otp-input", 3, "input", "keydown", "paste", "focus", "pattern", "placeholder", "value", "disabled"]], template: function OtpSlotComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "input", 1, 0);
            i0.ɵɵlistener("input", function OtpSlotComponent_Template_input_input_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onInput($event)); })("keydown", function OtpSlotComponent_Template_input_keydown_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeyDown($event)); })("paste", function OtpSlotComponent_Template_input_paste_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onPaste($event)); })("focus", function OtpSlotComponent_Template_input_focus_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFocus()); });
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("otp-input--first", ctx.isFirst())("otp-input--last", ctx.isLast());
            i0.ɵɵproperty("pattern", ctx.inputMode() === "numeric" ? "[0-9]*" : ".*")("placeholder", ctx.effectivePlaceholder())("value", ctx.value())("disabled", ctx.isDisabled());
            i0.ɵɵattribute("inputmode", ctx.inputMode())("aria-label", ctx.ariaLabel())("autocomplete", ctx.index() === 0 ? "one-time-code" : "off");
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:inline-flex}.otp-input[_ngcontent-%COMP%]{width:36px;height:36px;text-align:center;font-family:var(--font-sans);font-size:.9375rem;font-weight:600;color:var(--text-primary);background-color:var(--orc-secondary-bg);border:1px solid transparent;border-radius:0;outline:none;transition:background-color var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast)}.otp-input--first[_ngcontent-%COMP%]{border-top-left-radius:8px;border-bottom-left-radius:8px}.otp-input--last[_ngcontent-%COMP%]{border-top-right-radius:8px;border-bottom-right-radius:8px}.otp-input[_ngcontent-%COMP%]:focus{border-color:var(--orc-color-azul-eletrico);background-color:var(--orc-fill-input);box-shadow:0 0 0 2px #1c6aed33;z-index:2}.otp-input[_ngcontent-%COMP%]::placeholder{color:var(--text-muted);opacity:.5}.otp-input[disabled][_ngcontent-%COMP%]{opacity:.5;cursor:not-allowed}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OtpSlotComponent, [{
        type: Component,
        args: [{ selector: 'orc-otp-slot', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input\n  #slotInput\n  type=\"text\"\n  [attr.inputmode]=\"inputMode()\"\n  [pattern]=\"inputMode() === 'numeric' ? '[0-9]*' : '.*'\"\n  [placeholder]=\"effectivePlaceholder()\"\n  [value]=\"value()\"\n  [disabled]=\"isDisabled()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [attr.autocomplete]=\"index() === 0 ? 'one-time-code' : 'off'\"\n  maxlength=\"1\"\n  class=\"otp-input\"\n  [class.otp-input--first]=\"isFirst()\"\n  [class.otp-input--last]=\"isLast()\"\n  (input)=\"onInput($event)\"\n  (keydown)=\"onKeyDown($event)\"\n  (paste)=\"onPaste($event)\"\n  (focus)=\"onFocus()\"\n/>\n", styles: [":host{display:inline-flex}.otp-input{width:36px;height:36px;text-align:center;font-family:var(--font-sans);font-size:.9375rem;font-weight:600;color:var(--text-primary);background-color:var(--orc-secondary-bg);border:1px solid transparent;border-radius:0;outline:none;transition:background-color var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast)}.otp-input--first{border-top-left-radius:8px;border-bottom-left-radius:8px}.otp-input--last{border-top-right-radius:8px;border-bottom-right-radius:8px}.otp-input:focus{border-color:var(--orc-color-azul-eletrico);background-color:var(--orc-fill-input);box-shadow:0 0 0 2px #1c6aed33;z-index:2}.otp-input::placeholder{color:var(--text-muted);opacity:.5}.otp-input[disabled]{opacity:.5;cursor:not-allowed}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OtpSlotComponent, { className: "OtpSlotComponent", filePath: "otp-slot.component.ts", lineNumber: 22 }); })();

class OtpSeparatorComponent {
    static ɵfac = function OtpSeparatorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OtpSeparatorComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OtpSeparatorComponent, selectors: [["orc-otp-separator"]], decls: 3, vars: 0, consts: [["aria-hidden", "true", 1, "otp-separator"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round"], ["x1", "6", "y1", "12", "x2", "18", "y2", "12"]], template: function OtpSeparatorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵnamespaceSVG();
            i0.ɵɵelementStart(1, "svg", 1);
            i0.ɵɵelement(2, "line", 2);
            i0.ɵɵelementEnd()();
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:inline-flex;align-items:center;justify-content:center}.otp-separator[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:24px;height:36px;color:var(--text-secondary);svg{width:14px;height:14px;opacity:.8}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OtpSeparatorComponent, [{
        type: Component,
        args: [{ selector: 'orc-otp-separator', standalone: true, imports: [CommonModule], template: `
    <div class="otp-separator" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round">
        <line x1="6" y1="12" x2="18" y2="12" />
      </svg>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex;align-items:center;justify-content:center}.otp-separator{display:flex;align-items:center;justify-content:center;width:24px;height:36px;color:var(--text-secondary);svg{width:14px;height:14px;opacity:.8}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OtpSeparatorComponent, { className: "OtpSeparatorComponent", filePath: "otp-separator.component.ts", lineNumber: 38 }); })();

const _c0 = ["*"];
class OtpGroupComponent {
    static ɵfac = function OtpGroupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OtpGroupComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OtpGroupComponent, selectors: [["orc-otp-group"]], ngContentSelectors: _c0, decls: 2, vars: 0, consts: [[1, "otp-group"]], template: function OtpGroupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵprojection(1);
            i0.ɵɵelementEnd();
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:inline-flex}.otp-group[_ngcontent-%COMP%]{display:flex;gap:4px}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OtpGroupComponent, [{
        type: Component,
        args: [{ selector: 'orc-otp-group', standalone: true, imports: [CommonModule], template: `
    <div class="otp-group">
      <ng-content></ng-content>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex}.otp-group{display:flex;gap:4px}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OtpGroupComponent, { className: "OtpGroupComponent", filePath: "otp-group.component.ts", lineNumber: 24 }); })();

function OtpInputComponent_For_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "orc-otp-slot", 1);
} if (rf & 2) {
    const idx_r1 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("index", idx_r1)("isFirst", idx_r1 === 0)("isLast", idx_r1 === ctx_r1.firstHalfIndices().length - 1);
} }
function OtpInputComponent_For_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "orc-otp-slot", 1);
} if (rf & 2) {
    const idx_r3 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("index", idx_r3)("isFirst", idx_r3 === ctx_r1.secondHalfIndices()[0])("isLast", idx_r3 === ctx_r1.length() - 1);
} }
class OtpInputComponent {
    // Inputs
    length = input(6);
    placeholder = input('');
    disabled = input(false, { transform: booleanAttribute });
    inputMode = input('numeric');
    ariaLabel = input('Código de verificação');
    // Computed halves for grouped design
    firstHalfIndices = computed(() => {
        const half = Math.ceil(this.length() / 2);
        return Array.from({ length: half }, (_, i) => i);
    });
    secondHalfIndices = computed(() => {
        const half = Math.ceil(this.length() / 2);
        const len = this.length();
        return Array.from({ length: len - half }, (_, i) => half + i);
    });
    // Model & Outputs
    value = model('');
    completed = output();
    // Internal state
    inputValues = signal([]);
    cvaDisabled = signal(false);
    isDisabled = computed(() => this.disabled() || this.cvaDisabled());
    // View children slots to manage focus
    slots = viewChildren(OtpSlotComponent);
    // Callbacks for ControlValueAccessor
    onChange = () => { };
    onTouched = () => { };
    constructor() {
        // Sync external length change to inputValues array size
        effect(() => {
            const len = this.length();
            const currentVal = this.value() || '';
            const newValues = Array.from({ length: len }, (_, i) => currentVal[i] || '');
            this.inputValues.set(newValues);
        });
        // Sync model value changes to inputValues array
        effect(() => {
            const val = this.value() || '';
            const len = this.length();
            const newValues = Array.from({ length: len }, (_, i) => val[i] || '');
            const currentValuesStr = this.inputValues().join('');
            const newValStr = newValues.join('');
            if (currentValuesStr !== newValStr) {
                this.inputValues.set(newValues);
            }
        });
    }
    // ControlValueAccessor implementation
    writeValue(value) {
        const val = value || '';
        this.value.set(val);
        const len = this.length();
        const newValues = Array.from({ length: len }, (_, i) => val[i] || '');
        this.inputValues.set(newValues);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // Handle Input Changes from Slots
    onSlotInput(event, index) {
        const target = event.target;
        let val = target.value;
        if (this.inputMode() === 'numeric') {
            val = val.replace(/\D/g, '');
        }
        const currentValues = [...this.inputValues()];
        if (val.length > 1) {
            this.pasteCode(val, index);
            return;
        }
        currentValues[index] = val;
        this.updateValues(currentValues);
        if (val && index < this.length() - 1) {
            this.focusInput(index + 1);
        }
    }
    // Handle key events from Slots
    onSlotKeyDown(event, index) {
        const target = event.target;
        switch (event.key) {
            case 'Backspace':
                if (!target.value && index > 0) {
                    const currentValues = [...this.inputValues()];
                    currentValues[index - 1] = '';
                    this.updateValues(currentValues);
                    this.focusInput(index - 1);
                    event.preventDefault();
                }
                else if (target.value) {
                    const currentValues = [...this.inputValues()];
                    currentValues[index] = '';
                    this.updateValues(currentValues);
                }
                break;
            case 'ArrowLeft':
                if (index > 0) {
                    this.focusInput(index - 1);
                    event.preventDefault();
                }
                break;
            case 'ArrowRight':
                if (index < this.length() - 1) {
                    this.focusInput(index + 1);
                    event.preventDefault();
                }
                break;
        }
    }
    onSlotFocus(index) {
        this.onTouched();
    }
    onSlotPaste(event, index) {
        event.preventDefault();
        const clipboardData = event.clipboardData;
        if (!clipboardData)
            return;
        let pastedText = clipboardData.getData('text') || '';
        if (this.inputMode() === 'numeric') {
            pastedText = pastedText.replace(/\D/g, '');
        }
        this.pasteCode(pastedText, index);
    }
    pasteCode(code, startIndex) {
        if (!code)
            return;
        const currentValues = [...this.inputValues()];
        const len = this.length();
        let pasteIndex = startIndex;
        for (let i = 0; i < code.length && pasteIndex < len; i++) {
            currentValues[pasteIndex] = code[i];
            pasteIndex++;
        }
        this.updateValues(currentValues);
        const nextFocusIndex = Math.min(pasteIndex, len - 1);
        this.focusInput(nextFocusIndex);
    }
    updateValues(newValues) {
        this.inputValues.set(newValues);
        const combinedValue = newValues.join('');
        this.value.set(combinedValue);
        this.onChange(combinedValue);
        if (combinedValue.length === this.length()) {
            this.completed.emit(combinedValue);
        }
    }
    focusInput(index) {
        const slotRefs = this.slots();
        const slot = slotRefs[index];
        if (slot) {
            slot.focus();
        }
    }
    static ɵfac = function OtpInputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OtpInputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OtpInputComponent, selectors: [["orc-otp-input"]], viewQuery: function OtpInputComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.slots, OtpSlotComponent, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { length: [1, "length"], placeholder: [1, "placeholder"], disabled: [1, "disabled"], inputMode: [1, "inputMode"], ariaLabel: [1, "ariaLabel"], value: [1, "value"] }, outputs: { value: "valueChange", completed: "completed" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => OtpInputComponent),
                    multi: true,
                },
                {
                    provide: ORC_OTP_INPUT,
                    useExisting: forwardRef(() => OtpInputComponent),
                },
            ])], decls: 8, vars: 2, consts: [[1, "otp-container"], [3, "index", "isFirst", "isLast"]], template: function OtpInputComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "orc-otp-group");
            i0.ɵɵrepeaterCreate(2, OtpInputComponent_For_3_Template, 1, 3, "orc-otp-slot", 1, i0.ɵɵrepeaterTrackByIdentity);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "orc-otp-separator");
            i0.ɵɵelementStart(5, "orc-otp-group");
            i0.ɵɵrepeaterCreate(6, OtpInputComponent_For_7_Template, 1, 3, "orc-otp-slot", 1, i0.ɵɵrepeaterTrackByIdentity);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("otp-container--disabled", ctx.isDisabled());
            i0.ɵɵadvance(2);
            i0.ɵɵrepeater(ctx.firstHalfIndices());
            i0.ɵɵadvance(4);
            i0.ɵɵrepeater(ctx.secondHalfIndices());
        } }, dependencies: [CommonModule,
            OtpSlotComponent,
            OtpSeparatorComponent,
            OtpGroupComponent], styles: ["[_nghost-%COMP%]{display:inline-flex}.otp-container[_ngcontent-%COMP%]{display:flex;gap:var(--space-2);align-items:center;width:fit-content}.otp-container--disabled[_ngcontent-%COMP%]{opacity:.6;pointer-events:none}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OtpInputComponent, [{
        type: Component,
        args: [{ selector: 'orc-otp-input', standalone: true, imports: [
                    CommonModule,
                    OtpSlotComponent,
                    OtpSeparatorComponent,
                    OtpGroupComponent,
                ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => OtpInputComponent),
                        multi: true,
                    },
                    {
                        provide: ORC_OTP_INPUT,
                        useExisting: forwardRef(() => OtpInputComponent),
                    },
                ], template: "<div class=\"otp-container\" [class.otp-container--disabled]=\"isDisabled()\">\n  <!-- Grupo 1 -->\n  <orc-otp-group>\n    @for (idx of firstHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === 0\"\n        [isLast]=\"idx === firstHalfIndices().length - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n\n  <!-- Separador -->\n  <orc-otp-separator></orc-otp-separator>\n\n  <!-- Grupo 2 -->\n  <orc-otp-group>\n    @for (idx of secondHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === secondHalfIndices()[0]\"\n        [isLast]=\"idx === length() - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n</div>\n", styles: [":host{display:inline-flex}.otp-container{display:flex;gap:var(--space-2);align-items:center;width:fit-content}.otp-container--disabled{opacity:.6;pointer-events:none}\n"] }]
    }], () => [], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OtpInputComponent, { className: "OtpInputComponent", filePath: "otp-input.component.ts", lineNumber: 45 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ORC_OTP_INPUT, OtpGroupComponent, OtpInputComponent, OtpSeparatorComponent, OtpSlotComponent };
//# sourceMappingURL=ciag-orchestra-otp-input.mjs.map
