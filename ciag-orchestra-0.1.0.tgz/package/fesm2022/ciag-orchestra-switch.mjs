import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, viewChild, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const _c0 = ["switchButton"];
const _c1 = ["*", "*", "*"];
function SwitchComponent_div_1_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.labelId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.label());
} }
function SwitchComponent_div_1_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.descriptionId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r2.description(), " ");
} }
function SwitchComponent_div_1_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.errorId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r2.errorMessage(), " ");
} }
function SwitchComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 7);
    i0.ɵɵlistener("click", function SwitchComponent_div_1_Template_div_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.toggle()); });
    i0.ɵɵtemplate(1, SwitchComponent_div_1_span_1_Template, 2, 2, "span", 8);
    i0.ɵɵprojection(2);
    i0.ɵɵtemplate(3, SwitchComponent_div_1_span_3_Template, 2, 2, "span", 9)(4, SwitchComponent_div_1_span_4_Template, 2, 2, "span", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.label());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.description() && !ctx_r2.errorMessage());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.errorMessage());
} }
function SwitchComponent_div_6_span_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.labelId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.label());
} }
function SwitchComponent_div_6_span_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.descriptionId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r2.description(), " ");
} }
function SwitchComponent_div_6_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 13);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("id", ctx_r2.errorId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ctx_r2.errorMessage(), " ");
} }
function SwitchComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 7);
    i0.ɵɵlistener("click", function SwitchComponent_div_6_Template_div_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.toggle()); });
    i0.ɵɵtemplate(1, SwitchComponent_div_6_span_1_Template, 2, 2, "span", 8);
    i0.ɵɵprojection(2, 1);
    i0.ɵɵtemplate(3, SwitchComponent_div_6_span_3_Template, 2, 2, "span", 9)(4, SwitchComponent_div_6_span_4_Template, 2, 2, "span", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.label());
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r2.description() && !ctx_r2.errorMessage());
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.errorMessage());
} }
function SwitchComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14);
    i0.ɵɵprojection(1, 2);
    i0.ɵɵelementEnd();
} }
let nextSwitchUniqueId = 0;
class SwitchComponent {
    // Inputs (Signals API)
    id = input('');
    name = input('');
    value = input(undefined);
    label = input('');
    description = input('');
    size = input('md');
    labelPosition = input('end');
    disabled = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    error = input(false, { transform: booleanAttribute });
    errorMessage = input('');
    ariaLabel = input('');
    ariaLabelledby = input('');
    ariaDescribedby = input('');
    // Two-way Model (Signals API)
    checked = model(false);
    // Output (Signals API)
    change = output();
    // Element reference do botão interativo
    buttonElement = viewChild('switchButton');
    // Identificador único interno
    uniqueId = `orc-switch-${++nextSwitchUniqueId}`;
    // Estado interno para ControlValueAccessor
    cvaDisabled = signal(false);
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.id() || this.uniqueId);
    labelId = computed(() => `${this.effectiveId()}-label`);
    descriptionId = computed(() => `${this.effectiveId()}-desc`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    isDisabled = computed(() => this.disabled() || this.cvaDisabled());
    isError = computed(() => this.error() || !!this.errorMessage());
    computedAriaLabelledBy = computed(() => {
        if (this.ariaLabelledby())
            return this.ariaLabelledby();
        if (this.label())
            return this.labelId();
        return null;
    });
    computedAriaDescribedBy = computed(() => {
        if (this.ariaDescribedby())
            return this.ariaDescribedby();
        if (this.errorMessage())
            return this.errorId();
        if (this.description())
            return this.descriptionId();
        return null;
    });
    hasContent = computed(() => {
        return !!this.label() || !!this.description() || !!this.errorMessage();
    });
    // Callbacks do ControlValueAccessor
    onChange = () => { };
    onTouched = () => { };
    // ── ControlValueAccessor Implementation ───────────────────
    writeValue(val) {
        this.checked.set(Boolean(val));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Event Handlers ────────────────────────────────────────
    onToggle(event) {
        event.preventDefault();
        if (this.isDisabled()) {
            return;
        }
        const newChecked = !this.checked();
        this.checked.set(newChecked);
        this.onChange(newChecked);
        this.onTouched();
        this.change.emit({
            checked: newChecked,
            value: this.value(),
        });
    }
    onBlur() {
        this.onTouched();
    }
    // ── Public API Methods ────────────────────────────────────
    toggle() {
        if (this.isDisabled())
            return;
        const newChecked = !this.checked();
        this.checked.set(newChecked);
        this.onChange(newChecked);
        this.onTouched();
        this.change.emit({
            checked: newChecked,
            value: this.value(),
        });
    }
    focus() {
        this.buttonElement()?.nativeElement.focus();
    }
    static ɵfac = function SwitchComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SwitchComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SwitchComponent, selectors: [["orc-switch"]], viewQuery: function SwitchComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.buttonElement, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], name: [1, "name"], value: [1, "value"], label: [1, "label"], description: [1, "description"], size: [1, "size"], labelPosition: [1, "labelPosition"], disabled: [1, "disabled"], required: [1, "required"], error: [1, "error"], errorMessage: [1, "errorMessage"], ariaLabel: [1, "ariaLabel"], ariaLabelledby: [1, "ariaLabelledby"], ariaDescribedby: [1, "ariaDescribedby"], checked: [1, "checked"] }, outputs: { checked: "checkedChange", change: "change" }, features: [i0.ɵɵProvidersFeature([
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: forwardRef(() => SwitchComponent),
                    multi: true,
                },
            ])], ngContentSelectors: _c1, decls: 8, vars: 26, consts: [["switchButton", ""], [1, "orc-switch"], ["class", "orc-switch__content", 3, "click", 4, "ngIf"], ["type", "button", "role", "switch", 1, "orc-switch__control", 3, "click", "blur", "id", "disabled"], ["aria-hidden", "true", 1, "orc-switch__track"], [1, "orc-switch__thumb"], ["class", "orc-switch__content", 4, "ngIf"], [1, "orc-switch__content", 3, "click"], ["class", "orc-switch__label", 3, "id", 4, "ngIf"], ["class", "orc-switch__description", 3, "id", 4, "ngIf"], ["class", "orc-switch__error", 3, "id", 4, "ngIf"], [1, "orc-switch__label", 3, "id"], [1, "orc-switch__description", 3, "id"], [1, "orc-switch__error", 3, "id"], [1, "orc-switch__content"]], template: function SwitchComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef(_c1);
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, SwitchComponent_div_1_Template, 5, 3, "div", 2);
            i0.ɵɵelementStart(2, "button", 3, 0);
            i0.ɵɵlistener("click", function SwitchComponent_Template_button_click_2_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onToggle($event)); })("blur", function SwitchComponent_Template_button_blur_2_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur()); });
            i0.ɵɵelementStart(4, "span", 4);
            i0.ɵɵelement(5, "span", 5);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(6, SwitchComponent_div_6_Template, 5, 3, "div", 2)(7, SwitchComponent_div_7_Template, 2, 0, "div", 6);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-switch--checked", ctx.checked())("orc-switch--disabled", ctx.isDisabled())("orc-switch--error", ctx.isError())("orc-switch--size-sm", ctx.size() === "sm")("orc-switch--size-md", ctx.size() === "md")("orc-switch--size-lg", ctx.size() === "lg")("orc-switch--label-start", ctx.labelPosition() === "start")("orc-switch--label-end", ctx.labelPosition() === "end");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.labelPosition() === "start" && ctx.hasContent());
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.effectiveId())("disabled", ctx.isDisabled());
            i0.ɵɵattribute("aria-checked", ctx.checked())("aria-label", ctx.ariaLabel() || null)("aria-labelledby", ctx.computedAriaLabelledBy())("aria-describedby", ctx.computedAriaDescribedBy())("aria-invalid", ctx.isError());
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.labelPosition() === "end" && ctx.hasContent());
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.hasContent());
        } }, dependencies: [CommonModule, i1.NgIf], styles: ["[_nghost-%COMP%]{display:inline-flex}.orc-switch[_ngcontent-%COMP%]{display:inline-flex;align-items:flex-start;gap:var(--space-3, .75rem);-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428;--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-sm[_ngcontent-%COMP%]{--switch-track-w: 26px;--switch-track-h: 15px;--switch-thumb-size: 11px;--switch-thumb-offset: 2px;--switch-thumb-travel: 11px;--switch-font-size: .8125rem}.orc-switch--size-md[_ngcontent-%COMP%]{--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-lg[_ngcontent-%COMP%]{--switch-track-w: 42px;--switch-track-h: 24px;--switch-thumb-size: 18px;--switch-thumb-offset: 3px;--switch-thumb-travel: 18px;--switch-font-size: 1rem}.orc-switch--label-start[_ngcontent-%COMP%], .orc-switch--label-end[_ngcontent-%COMP%]{flex-direction:row}.orc-switch__control[_ngcontent-%COMP%]{background:transparent;border:none;padding:0;margin:2px 0 0;cursor:pointer;display:inline-flex;outline:none;border-radius:200px;flex-shrink:0}.orc-switch__control[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-switch__track[_ngcontent-%COMP%]{width:var(--switch-track-w);height:var(--switch-track-h);background-color:var(--orc-border, #d9d9d9);border-radius:200px;position:relative;display:flex;align-items:center;box-sizing:border-box;transition:background-color var(--transition-base, .2s ease),border-color var(--transition-base, .2s ease),box-shadow var(--transition-base, .2s ease)}.orc-switch__thumb[_ngcontent-%COMP%]{width:var(--switch-thumb-size);height:var(--switch-thumb-size);background-color:var(--orc-bg, #ffffff);border-radius:200px;position:absolute;left:var(--switch-thumb-offset);box-shadow:0 1px 3px #0003;transform:translate(0);transition:transform var(--transition-base, .2s ease),background-color var(--transition-base, .2s ease)}.orc-switch__content[_ngcontent-%COMP%]{display:flex;flex-direction:column;cursor:pointer}.orc-switch__label[_ngcontent-%COMP%]{font-size:var(--switch-font-size);font-weight:400;color:var(--orc-font-main, #141414);line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-switch__description[_ngcontent-%COMP%]{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-switch__error[_ngcontent-%COMP%]{font-size:.75rem;color:var(--color-error, #fb2c36);line-height:1.4;margin-top:2px;font-weight:500}.orc-switch[_ngcontent-%COMP%]:hover:not(.orc-switch--disabled)   .orc-switch__track[_ngcontent-%COMP%]{background-color:var(--orc-secondary-bg, #bfbfbf)}.orc-switch--checked[_ngcontent-%COMP%]   .orc-switch__track[_ngcontent-%COMP%]{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-switch--checked[_ngcontent-%COMP%]   .orc-switch__thumb[_ngcontent-%COMP%]{transform:translate(var(--switch-thumb-travel))}.orc-switch--checked[_ngcontent-%COMP%]   .orc-switch__label[_ngcontent-%COMP%]{font-weight:500;color:var(--orc-font-main, #141414)}.orc-switch--checked[_ngcontent-%COMP%]:hover:not(.orc-switch--disabled)   .orc-switch__track[_ngcontent-%COMP%]{background-color:#175cd3}.orc-switch--error[_ngcontent-%COMP%]   .orc-switch__track[_ngcontent-%COMP%]{background-color:var(--color-error, #fb2c36)}.orc-switch--error[_ngcontent-%COMP%]   .orc-switch__label[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}.orc-switch--error[_ngcontent-%COMP%]   .orc-switch__control[_ngcontent-%COMP%]:focus-visible{outline-color:var(--color-error, #fb2c36)}.orc-switch--disabled[_ngcontent-%COMP%]{cursor:not-allowed;opacity:.5}.orc-switch--disabled[_ngcontent-%COMP%]   .orc-switch__control[_ngcontent-%COMP%], .orc-switch--disabled[_ngcontent-%COMP%]   .orc-switch__content[_ngcontent-%COMP%]{cursor:not-allowed;pointer-events:none}.orc-switch--disabled[_ngcontent-%COMP%]   .orc-switch__track[_ngcontent-%COMP%]{background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-switch--disabled.orc-switch--checked[_ngcontent-%COMP%]   .orc-switch__track[_ngcontent-%COMP%]{background-color:var(--orc-font-secondary, #666666)}.orc-switch--disabled[_ngcontent-%COMP%]   .orc-switch__label[_ngcontent-%COMP%], .orc-switch--disabled[_ngcontent-%COMP%]   .orc-switch__description[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666666)}@media(prefers-reduced-motion:reduce){.orc-switch__track[_ngcontent-%COMP%], .orc-switch__thumb[_ngcontent-%COMP%]{transition:none!important}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SwitchComponent, [{
        type: Component,
        args: [{ selector: 'orc-switch', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => SwitchComponent),
                        multi: true,
                    },
                ], template: "<div\n  class=\"orc-switch\"\n  [class.orc-switch--checked]=\"checked()\"\n  [class.orc-switch--disabled]=\"isDisabled()\"\n  [class.orc-switch--error]=\"isError()\"\n  [class.orc-switch--size-sm]=\"size() === 'sm'\"\n  [class.orc-switch--size-md]=\"size() === 'md'\"\n  [class.orc-switch--size-lg]=\"size() === 'lg'\"\n  [class.orc-switch--label-start]=\"labelPosition() === 'start'\"\n  [class.orc-switch--label-end]=\"labelPosition() === 'end'\"\n>\n  <!-- Content before switch (when labelPosition === 'start') -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'start' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <!-- Interactive Switch Control (W3C WAI-ARIA Switch Pattern) -->\n  <button\n    #switchButton\n    type=\"button\"\n    role=\"switch\"\n    class=\"orc-switch__control\"\n    [id]=\"effectiveId()\"\n    [attr.aria-checked]=\"checked()\"\n    [disabled]=\"isDisabled()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"computedAriaLabelledBy()\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-invalid]=\"isError()\"\n    (click)=\"onToggle($event)\"\n    (blur)=\"onBlur()\"\n  >\n    <span class=\"orc-switch__track\" aria-hidden=\"true\">\n      <span class=\"orc-switch__thumb\"></span>\n    </span>\n  </button>\n\n  <!-- Content after switch (when labelPosition === 'end', default) -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'end' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <div class=\"orc-switch__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{display:inline-flex}.orc-switch{display:inline-flex;align-items:flex-start;gap:var(--space-3, .75rem);-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428;--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-sm{--switch-track-w: 26px;--switch-track-h: 15px;--switch-thumb-size: 11px;--switch-thumb-offset: 2px;--switch-thumb-travel: 11px;--switch-font-size: .8125rem}.orc-switch--size-md{--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-lg{--switch-track-w: 42px;--switch-track-h: 24px;--switch-thumb-size: 18px;--switch-thumb-offset: 3px;--switch-thumb-travel: 18px;--switch-font-size: 1rem}.orc-switch--label-start,.orc-switch--label-end{flex-direction:row}.orc-switch__control{background:transparent;border:none;padding:0;margin:2px 0 0;cursor:pointer;display:inline-flex;outline:none;border-radius:200px;flex-shrink:0}.orc-switch__control:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:2px}.orc-switch__track{width:var(--switch-track-w);height:var(--switch-track-h);background-color:var(--orc-border, #d9d9d9);border-radius:200px;position:relative;display:flex;align-items:center;box-sizing:border-box;transition:background-color var(--transition-base, .2s ease),border-color var(--transition-base, .2s ease),box-shadow var(--transition-base, .2s ease)}.orc-switch__thumb{width:var(--switch-thumb-size);height:var(--switch-thumb-size);background-color:var(--orc-bg, #ffffff);border-radius:200px;position:absolute;left:var(--switch-thumb-offset);box-shadow:0 1px 3px #0003;transform:translate(0);transition:transform var(--transition-base, .2s ease),background-color var(--transition-base, .2s ease)}.orc-switch__content{display:flex;flex-direction:column;cursor:pointer}.orc-switch__label{font-size:var(--switch-font-size);font-weight:400;color:var(--orc-font-main, #141414);line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-switch__description{font-size:.75rem;color:var(--orc-font-secondary, #666666);line-height:1.4;margin-top:2px}.orc-switch__error{font-size:.75rem;color:var(--color-error, #fb2c36);line-height:1.4;margin-top:2px;font-weight:500}.orc-switch:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:var(--orc-secondary-bg, #bfbfbf)}.orc-switch--checked .orc-switch__track{background-color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-switch--checked .orc-switch__thumb{transform:translate(var(--switch-thumb-travel))}.orc-switch--checked .orc-switch__label{font-weight:500;color:var(--orc-font-main, #141414)}.orc-switch--checked:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:#175cd3}.orc-switch--error .orc-switch__track{background-color:var(--color-error, #fb2c36)}.orc-switch--error .orc-switch__label{color:var(--color-error, #fb2c36)}.orc-switch--error .orc-switch__control:focus-visible{outline-color:var(--color-error, #fb2c36)}.orc-switch--disabled{cursor:not-allowed;opacity:.5}.orc-switch--disabled .orc-switch__control,.orc-switch--disabled .orc-switch__content{cursor:not-allowed;pointer-events:none}.orc-switch--disabled .orc-switch__track{background-color:var(--orc-highlight-cinza-claro, #ededed)}.orc-switch--disabled.orc-switch--checked .orc-switch__track{background-color:var(--orc-font-secondary, #666666)}.orc-switch--disabled .orc-switch__label,.orc-switch--disabled .orc-switch__description{color:var(--orc-font-secondary, #666666)}@media(prefers-reduced-motion:reduce){.orc-switch__track,.orc-switch__thumb{transition:none!important}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SwitchComponent, { className: "SwitchComponent", filePath: "switch.component.ts", lineNumber: 39 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { SwitchComponent };
//# sourceMappingURL=ciag-orchestra-switch.mjs.map
