import * as i0 from '@angular/core';
import { viewChild, input, numberAttribute, booleanAttribute, model, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const _c0 = ["nativeInput"];
function NumberInputComponent_Conditional_1_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 9);
    i0.ɵɵtext(1, "*");
    i0.ɵɵelementEnd();
} }
function NumberInputComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "label", 2);
    i0.ɵɵtext(1);
    i0.ɵɵtemplate(2, NumberInputComponent_Conditional_1_Conditional_2_Template, 2, 0, "span", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("for", ctx_r1.effectiveId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1("", ctx_r1.label(), " ");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r1.required() ? 2 : -1);
} }
function NumberInputComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.prefix());
} }
function NumberInputComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 10);
    i0.ɵɵlistener("click", function NumberInputComponent_Conditional_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.decrement()); });
    i0.ɵɵtext(1, "\u2212");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.effectiveDisabled() || ctx_r1.readonly());
} }
function NumberInputComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.suffix());
} }
function NumberInputComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 11);
    i0.ɵɵlistener("click", function NumberInputComponent_Conditional_8_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.increment()); });
    i0.ɵɵtext(1, "+");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r1.effectiveDisabled() || ctx_r1.readonly());
} }
function NumberInputComponent_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 12);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("orc-number-input__message--error", !!ctx_r1.errorMessage());
    i0.ɵɵproperty("id", ctx_r1.errorMessage() ? ctx_r1.errorId() : ctx_r1.helperId());
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r1.errorMessage() || ctx_r1.helperText());
} }
let nextNumberInputId = 0;
class NumberInputComponent {
    uniqueId = `orc-number-input-${++nextNumberInputId}`;
    nativeInput = viewChild('nativeInput');
    id = input('');
    name = input('');
    label = input('');
    placeholder = input('');
    helperText = input('');
    errorMessage = input('');
    status = input('default');
    size = input('md');
    min = input(undefined, { transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    max = input(undefined, { transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    step = input(1, { transform: numberAttribute });
    precision = input(undefined, { transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    prefix = input('');
    suffix = input('');
    disabled = input(false, { transform: booleanAttribute });
    readonly = input(false, { transform: booleanAttribute });
    required = input(false, { transform: booleanAttribute });
    showControls = input(true, { transform: booleanAttribute });
    ariaLabel = input('');
    value = model(null);
    valueChange = output();
    blur = output();
    cvaDisabled = signal(false);
    effectiveId = computed(() => this.id() || this.uniqueId);
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled());
    displayValue = computed(() => {
        const value = this.value();
        if (value === null || value === undefined)
            return '';
        return this.precision() === undefined ? String(value) : value.toFixed(this.precision());
    });
    helperId = computed(() => `${this.effectiveId()}-helper`);
    errorId = computed(() => `${this.effectiveId()}-error`);
    describedBy = computed(() => this.errorMessage() ? this.errorId() : this.helperText() ? this.helperId() : null);
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        const parsed = value === null || value === undefined || value === '' ? null : Number(value);
        this.value.set(parsed !== null && Number.isFinite(parsed) ? this.clamp(parsed) : null);
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    onInput(event) {
        const raw = event.target.value;
        if (raw.trim() === '') {
            this.update(null);
            return;
        }
        const parsed = Number(raw);
        if (Number.isFinite(parsed))
            this.update(this.clamp(parsed));
    }
    onBlur(event) {
        const input = event.target;
        if (this.value() !== null)
            input.value = this.displayValue();
        this.onTouched();
        this.blur.emit(event);
    }
    onKeydown(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.increment();
        }
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.decrement();
        }
    }
    increment() { this.update(this.clamp((this.value() ?? this.min() ?? 0) + this.step())); }
    decrement() { this.update(this.clamp((this.value() ?? this.min() ?? 0) - this.step())); }
    focus() { this.nativeInput()?.nativeElement.focus(); }
    update(value) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.value.set(value);
        this.onChange(value);
        this.valueChange.emit(value);
    }
    clamp(value) {
        const min = this.min();
        const max = this.max();
        let next = min === undefined ? value : Math.max(min, value);
        if (max !== undefined)
            next = Math.min(max, next);
        const precision = this.precision();
        return precision === undefined ? next : Number(next.toFixed(precision));
    }
    static ɵfac = function NumberInputComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || NumberInputComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: NumberInputComponent, selectors: [["orc-number-input"]], viewQuery: function NumberInputComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.nativeInput, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, inputs: { id: [1, "id"], name: [1, "name"], label: [1, "label"], placeholder: [1, "placeholder"], helperText: [1, "helperText"], errorMessage: [1, "errorMessage"], status: [1, "status"], size: [1, "size"], min: [1, "min"], max: [1, "max"], step: [1, "step"], precision: [1, "precision"], prefix: [1, "prefix"], suffix: [1, "suffix"], disabled: [1, "disabled"], readonly: [1, "readonly"], required: [1, "required"], showControls: [1, "showControls"], ariaLabel: [1, "ariaLabel"], value: [1, "value"] }, outputs: { value: "valueChange", valueChange: "valueChange", blur: "blur" }, features: [i0.ɵɵProvidersFeature([{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => NumberInputComponent), multi: true }])], decls: 10, vars: 27, consts: [["nativeInput", ""], [1, "orc-number-input"], [1, "orc-number-input__label", 3, "for"], [1, "orc-number-input__box"], [1, "orc-number-input__affix"], ["type", "button", "aria-label", "Diminuir", 1, "orc-number-input__control", 3, "disabled"], ["type", "number", "inputmode", "decimal", 1, "orc-number-input__native", 3, "input", "blur", "keydown", "id", "name", "value", "placeholder", "min", "max", "step", "disabled", "readOnly", "required"], ["type", "button", "aria-label", "Aumentar", 1, "orc-number-input__control", 3, "disabled"], [1, "orc-number-input__message", 3, "orc-number-input__message--error", "id"], ["aria-hidden", "true"], ["type", "button", "aria-label", "Diminuir", 1, "orc-number-input__control", 3, "click", "disabled"], ["type", "button", "aria-label", "Aumentar", 1, "orc-number-input__control", 3, "click", "disabled"], [1, "orc-number-input__message", 3, "id"]], template: function NumberInputComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 1);
            i0.ɵɵtemplate(1, NumberInputComponent_Conditional_1_Template, 3, 3, "label", 2);
            i0.ɵɵelementStart(2, "div", 3);
            i0.ɵɵtemplate(3, NumberInputComponent_Conditional_3_Template, 2, 1, "span", 4)(4, NumberInputComponent_Conditional_4_Template, 2, 1, "button", 5);
            i0.ɵɵelementStart(5, "input", 6, 0);
            i0.ɵɵlistener("input", function NumberInputComponent_Template_input_input_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onInput($event)); })("blur", function NumberInputComponent_Template_input_blur_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onBlur($event)); })("keydown", function NumberInputComponent_Template_input_keydown_5_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onKeydown($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, NumberInputComponent_Conditional_7_Template, 2, 1, "span", 4)(8, NumberInputComponent_Conditional_8_Template, 2, 1, "button", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, NumberInputComponent_Conditional_9_Template, 2, 4, "p", 8);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_12_0;
            let tmp_13_0;
            i0.ɵɵclassProp("orc-number-input--disabled", ctx.effectiveDisabled())("orc-number-input--readonly", ctx.readonly());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.label() ? 1 : -1);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("orc-number-input__box--error", ctx.status() === "error" || !!ctx.errorMessage())("orc-number-input__box--success", ctx.status() === "success");
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.prefix() ? 3 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showControls() ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.effectiveId())("name", ctx.name())("value", ctx.displayValue())("placeholder", ctx.placeholder())("min", (tmp_12_0 = ctx.min()) !== null && tmp_12_0 !== undefined ? tmp_12_0 : null)("max", (tmp_13_0 = ctx.max()) !== null && tmp_13_0 !== undefined ? tmp_13_0 : null)("step", ctx.step())("disabled", ctx.effectiveDisabled())("readOnly", ctx.readonly())("required", ctx.required());
            i0.ɵɵattribute("aria-label", ctx.ariaLabel() || null)("aria-invalid", ctx.status() === "error" || ctx.errorMessage() ? "true" : null)("aria-describedby", ctx.describedBy());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.suffix() ? 7 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.showControls() ? 8 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.errorMessage() || ctx.helperText() ? 9 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-number-input[_ngcontent-%COMP%]{display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-number-input__label[_ngcontent-%COMP%]{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-number-input__label[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}.orc-number-input__box[_ngcontent-%COMP%]{display:flex;align-items:center;min-height:44px;overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);transition:border-color .2s,box-shadow .2s}.orc-number-input__box[_ngcontent-%COMP%]:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-number-input__box--error[_ngcontent-%COMP%]{border-color:var(--color-error, #fb2c36)}.orc-number-input__box--success[_ngcontent-%COMP%]{border-color:var(--color-success, #006f4a)}.orc-number-input__native[_ngcontent-%COMP%]{flex:1;min-width:0;height:100%;padding:0 8px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:center}.orc-number-input__native[_ngcontent-%COMP%]::-webkit-inner-spin-button, .orc-number-input__native[_ngcontent-%COMP%]::-webkit-outer-spin-button{margin:0;-webkit-appearance:none}.orc-number-input__native[type=number][_ngcontent-%COMP%]{-moz-appearance:textfield}.orc-number-input__control[_ngcontent-%COMP%]{align-self:stretch;min-width:38px;padding:0 10px;border:0;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);font-size:20px;cursor:pointer}.orc-number-input__control[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--orc-border, #d9d9d9)}.orc-number-input__control[_ngcontent-%COMP%]:disabled{opacity:.4;cursor:not-allowed}.orc-number-input__control[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-number-input__affix[_ngcontent-%COMP%]{padding:0 10px;color:var(--orc-font-secondary, #666);font-size:13px}.orc-number-input--disabled[_ngcontent-%COMP%]{opacity:.55}.orc-number-input__message[_ngcontent-%COMP%]{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-number-input__message--error[_ngcontent-%COMP%]{color:var(--color-error, #fb2c36)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(NumberInputComponent, [{
        type: Component,
        args: [{ selector: 'orc-number-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => NumberInputComponent), multi: true }], template: "<div class=\"orc-number-input\" [class.orc-number-input--disabled]=\"effectiveDisabled()\" [class.orc-number-input--readonly]=\"readonly()\">\n  @if (label()) { <label class=\"orc-number-input__label\" [for]=\"effectiveId()\">{{ label() }} @if (required()) { <span aria-hidden=\"true\">*</span> }</label> }\n  <div class=\"orc-number-input__box\" [class.orc-number-input__box--error]=\"status() === 'error' || !!errorMessage()\" [class.orc-number-input__box--success]=\"status() === 'success'\">\n    @if (prefix()) { <span class=\"orc-number-input__affix\">{{ prefix() }}</span> }\n    @if (showControls()) { <button type=\"button\" class=\"orc-number-input__control\" (click)=\"decrement()\" [disabled]=\"effectiveDisabled() || readonly()\" aria-label=\"Diminuir\">\u2212</button> }\n    <input #nativeInput class=\"orc-number-input__native\" [id]=\"effectiveId()\" [name]=\"name()\" type=\"number\" inputmode=\"decimal\" [value]=\"displayValue()\" [placeholder]=\"placeholder()\" [min]=\"min() ?? null\" [max]=\"max() ?? null\" [step]=\"step()\" [disabled]=\"effectiveDisabled()\" [readOnly]=\"readonly()\" [required]=\"required()\" [attr.aria-label]=\"ariaLabel() || null\" [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\" [attr.aria-describedby]=\"describedBy()\" (input)=\"onInput($event)\" (blur)=\"onBlur($event)\" (keydown)=\"onKeydown($event)\" />\n    @if (suffix()) { <span class=\"orc-number-input__affix\">{{ suffix() }}</span> }\n    @if (showControls()) { <button type=\"button\" class=\"orc-number-input__control\" (click)=\"increment()\" [disabled]=\"effectiveDisabled() || readonly()\" aria-label=\"Aumentar\">+</button> }\n  </div>\n  @if (errorMessage() || helperText()) { <p class=\"orc-number-input__message\" [class.orc-number-input__message--error]=\"!!errorMessage()\" [id]=\"errorMessage() ? errorId() : helperId()\">{{ errorMessage() || helperText() }}</p> }\n</div>\n", styles: [":host{display:block;width:100%}.orc-number-input{display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-number-input__label{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-number-input__label span{color:var(--color-error, #fb2c36)}.orc-number-input__box{display:flex;align-items:center;min-height:44px;overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);transition:border-color .2s,box-shadow .2s}.orc-number-input__box:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-number-input__box--error{border-color:var(--color-error, #fb2c36)}.orc-number-input__box--success{border-color:var(--color-success, #006f4a)}.orc-number-input__native{flex:1;min-width:0;height:100%;padding:0 8px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:center}.orc-number-input__native::-webkit-inner-spin-button,.orc-number-input__native::-webkit-outer-spin-button{margin:0;-webkit-appearance:none}.orc-number-input__native[type=number]{-moz-appearance:textfield}.orc-number-input__control{align-self:stretch;min-width:38px;padding:0 10px;border:0;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);font-size:20px;cursor:pointer}.orc-number-input__control:hover:not(:disabled){background:var(--orc-border, #d9d9d9)}.orc-number-input__control:disabled{opacity:.4;cursor:not-allowed}.orc-number-input__control:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-number-input__affix{padding:0 10px;color:var(--orc-font-secondary, #666);font-size:13px}.orc-number-input--disabled{opacity:.55}.orc-number-input__message{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-number-input__message--error{color:var(--color-error, #fb2c36)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(NumberInputComponent, { className: "NumberInputComponent", filePath: "number-input.component.ts", lineNumber: 30 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { NumberInputComponent };
//# sourceMappingURL=ciag-orchestra-number-input.mjs.map
