import * as i0 from '@angular/core';
import { input, model, booleanAttribute, output, computed, ChangeDetectionStrategy, Component } from '@angular/core';

const _c0 = ["*"];
function CollapsibleComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "small");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.summary());
} }
function CollapsibleComponent_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 4);
    i0.ɵɵprojection(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("id", ctx_r0.contentId())("hidden", !ctx_r0.open());
    i0.ɵɵattribute("aria-labelledby", ctx_r0.triggerId());
} }
let nextCollapsibleId = 0;
class CollapsibleComponent {
    uniqueId = `orc-collapsible-${++nextCollapsibleId}`;
    id = input('');
    title = input('');
    summary = input('');
    open = model(false);
    disabled = input(false, { transform: booleanAttribute });
    lazy = input(false, { transform: booleanAttribute });
    toggleChange = output();
    effectiveId = computed(() => this.id() || this.uniqueId);
    triggerId = computed(() => `${this.effectiveId()}-trigger`);
    contentId = computed(() => `${this.effectiveId()}-content`);
    toggle() {
        if (this.disabled())
            return;
        this.open.update(value => !value);
        this.toggleChange.emit(this.open());
    }
    static ɵfac = function CollapsibleComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CollapsibleComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CollapsibleComponent, selectors: [["orc-collapsible"]], inputs: { id: [1, "id"], title: [1, "title"], summary: [1, "summary"], open: [1, "open"], disabled: [1, "disabled"], lazy: [1, "lazy"] }, outputs: { open: "openChange", toggleChange: "toggleChange" }, ngContentSelectors: _c0, decls: 9, vars: 11, consts: [[1, "orc-collapsible"], ["type", "button", 1, "orc-collapsible__trigger", 3, "click", "id", "disabled"], [1, "orc-collapsible__heading"], ["aria-hidden", "true", 1, "orc-collapsible__chevron"], ["role", "region", 1, "orc-collapsible__content", 3, "id", "hidden"]], template: function CollapsibleComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "section", 0)(1, "button", 1);
            i0.ɵɵlistener("click", function CollapsibleComponent_Template_button_click_1_listener() { return ctx.toggle(); });
            i0.ɵɵelementStart(2, "span", 2)(3, "strong");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, CollapsibleComponent_Conditional_5_Template, 2, 1, "small");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "span", 3);
            i0.ɵɵtext(7, "\u2304");
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(8, CollapsibleComponent_Conditional_8_Template, 2, 3, "div", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-collapsible--open", ctx.open())("orc-collapsible--disabled", ctx.disabled());
            i0.ɵɵadvance();
            i0.ɵɵproperty("id", ctx.triggerId())("disabled", ctx.disabled());
            i0.ɵɵattribute("aria-controls", ctx.contentId())("aria-expanded", ctx.open());
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(ctx.title());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.summary() ? 5 : -1);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional(ctx.open() || !ctx.lazy() ? 8 : -1);
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-collapsible[_ngcontent-%COMP%]{overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-collapsible__trigger[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;padding:14px 16px;border:0;background:transparent;color:var(--orc-font-main, #141414);text-align:left;cursor:pointer}.orc-collapsible__trigger[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--orc-th, #f7f8fa)}.orc-collapsible__trigger[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-collapsible__trigger[_ngcontent-%COMP%]:disabled{cursor:not-allowed}.orc-collapsible__heading[_ngcontent-%COMP%]{display:grid;gap:3px;min-width:0}.orc-collapsible__heading[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:14px}.orc-collapsible__heading[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--orc-font-secondary, #666);font-size:12px;font-weight:400}.orc-collapsible__chevron[_ngcontent-%COMP%]{transition:transform .2s;font-size:18px}.orc-collapsible--open[_ngcontent-%COMP%]   .orc-collapsible__chevron[_ngcontent-%COMP%]{transform:rotate(180deg)}.orc-collapsible__content[_ngcontent-%COMP%]{padding:0 16px 16px;color:var(--orc-font-secondary, #666);line-height:1.5}.orc-collapsible--disabled[_ngcontent-%COMP%]{opacity:.55}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CollapsibleComponent, [{
        type: Component,
        args: [{ selector: 'orc-collapsible', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"orc-collapsible\" [class.orc-collapsible--open]=\"open()\" [class.orc-collapsible--disabled]=\"disabled()\">\n  <button type=\"button\" class=\"orc-collapsible__trigger\" [id]=\"triggerId()\" [attr.aria-controls]=\"contentId()\" [attr.aria-expanded]=\"open()\" [disabled]=\"disabled()\" (click)=\"toggle()\">\n    <span class=\"orc-collapsible__heading\"><strong>{{ title() }}</strong>@if (summary()) { <small>{{ summary() }}</small> }</span>\n    <span class=\"orc-collapsible__chevron\" aria-hidden=\"true\">\u2304</span>\n  </button>\n  @if (open() || !lazy()) { <div class=\"orc-collapsible__content\" [id]=\"contentId()\" role=\"region\" [attr.aria-labelledby]=\"triggerId()\" [hidden]=\"!open()\"><ng-content /></div> }\n</section>\n", styles: [":host{display:block;width:100%}.orc-collapsible{overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff)}.orc-collapsible__trigger{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;padding:14px 16px;border:0;background:transparent;color:var(--orc-font-main, #141414);text-align:left;cursor:pointer}.orc-collapsible__trigger:hover:not(:disabled){background:var(--orc-th, #f7f8fa)}.orc-collapsible__trigger:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-collapsible__trigger:disabled{cursor:not-allowed}.orc-collapsible__heading{display:grid;gap:3px;min-width:0}.orc-collapsible__heading strong{font-size:14px}.orc-collapsible__heading small{color:var(--orc-font-secondary, #666);font-size:12px;font-weight:400}.orc-collapsible__chevron{transition:transform .2s;font-size:18px}.orc-collapsible--open .orc-collapsible__chevron{transform:rotate(180deg)}.orc-collapsible__content{padding:0 16px 16px;color:var(--orc-font-secondary, #666);line-height:1.5}.orc-collapsible--disabled{opacity:.55}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CollapsibleComponent, { className: "CollapsibleComponent", filePath: "collapsible.component.ts", lineNumber: 12 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { CollapsibleComponent };
//# sourceMappingURL=ciag-orchestra-collapsible.mjs.map
