import * as i0 from '@angular/core';
import { inject, ApplicationRef, EnvironmentInjector, signal, computed, createComponent, Injectable, DestroyRef, input, output, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT, CommonModule } from '@angular/common';

class ToastService {
    appRef = inject(ApplicationRef);
    injector = inject(EnvironmentInjector);
    document = inject(DOCUMENT);
    // ── Sinais Reativos Globais ───────────────────────────────
    toasts = signal([]);
    activeCount = computed(() => this.toasts().length);
    // ── Configurações Padrão ──────────────────────────────────
    defaultPosition = 'top-right';
    defaultDuration = 5000;
    containerRef = null;
    isCreatingContainer = false;
    idCounter = 0;
    // ── Inicialização Dinâmica do Container Overlay (Sem Circular Dependency) ──
    async ensureContainer() {
        if (this.containerRef || this.isCreatingContainer || typeof window === 'undefined')
            return;
        try {
            this.isCreatingContainer = true;
            const { ToastContainerComponent } = await Promise.resolve().then(function () { return toastContainer_component; });
            if (!this.containerRef) {
                const containerComponentRef = createComponent(ToastContainerComponent, {
                    environmentInjector: this.injector,
                });
                this.appRef.attachView(containerComponentRef.hostView);
                const domElem = containerComponentRef.hostView.rootNodes[0];
                this.document.body.appendChild(domElem);
                this.containerRef = containerComponentRef;
            }
        }
        catch {
            // Ignora caso já esteja instanciado
        }
        finally {
            this.isCreatingContainer = false;
        }
    }
    // ── Métodos de Configuração Global ────────────────────────
    setDefaultPosition(position) {
        this.defaultPosition = position;
    }
    setDefaultDuration(duration) {
        this.defaultDuration = duration;
    }
    // ── Disparo Principal de Toasts ───────────────────────────
    show(optionsOrMessage) {
        this.ensureContainer();
        const options = typeof optionsOrMessage === 'string'
            ? { message: optionsOrMessage }
            : optionsOrMessage;
        const id = options.id || `orc-toast-${++this.idCounter}-${Date.now()}`;
        const type = options.type || 'info';
        // Determina título padrão caso não informado
        let title = options.title || '';
        if (!title && !options.message) {
            switch (type) {
                case 'success':
                    title = 'Sucesso';
                    break;
                case 'error':
                    title = 'Erro';
                    break;
                case 'warning':
                    title = 'Atenção';
                    break;
                case 'info':
                    title = 'Informação';
                    break;
                case 'loading':
                    title = 'Carregando';
                    break;
                case 'notification':
                    title = 'Notificação';
                    break;
            }
        }
        const toastItem = {
            ...options,
            id,
            type,
            title,
            message: options.message || '',
            duration: options.duration !== undefined ? options.duration : this.defaultDuration,
            showProgressBar: Boolean(options.showProgressBar),
            dismissible: options.dismissible !== undefined ? options.dismissible : true,
            showIcon: options.showIcon !== undefined ? options.showIcon : true,
            position: options.position || this.defaultPosition,
            pauseOnHover: options.pauseOnHover !== undefined ? options.pauseOnHover : true,
            createdAt: Date.now(),
        };
        this.toasts.update(current => [...current, toastItem]);
        return id;
    }
    // ── Atalhos Semânticos ────────────────────────────────────
    success(message, options) {
        return this.show({
            ...options,
            type: 'success',
            title: options?.title || 'Sucesso',
            message,
        });
    }
    info(message, options) {
        return this.show({
            ...options,
            type: 'info',
            title: options?.title || 'Informação',
            message,
        });
    }
    warning(message, options) {
        return this.show({
            ...options,
            type: 'warning',
            title: options?.title || 'Atenção',
            message,
        });
    }
    error(message, options) {
        return this.show({
            ...options,
            type: 'error',
            title: options?.title || 'Erro',
            message,
        });
    }
    loading(message, options) {
        return this.show({
            ...options,
            type: 'loading',
            title: options?.title || 'Carregando',
            message,
            duration: options?.duration !== undefined ? options.duration : 0,
        });
    }
    notification(message, options) {
        return this.show({
            ...options,
            type: 'notification',
            title: options?.title || 'Notificações',
            message,
        });
    }
    // ── Fechamento e Limpeza ──────────────────────────────────
    dismiss(id) {
        this.toasts.update(current => current.filter(t => t.id !== id));
    }
    clear() {
        this.toasts.set([]);
    }
    static ɵfac = function ToastService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ToastService)(); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ToastService, factory: ToastService.ɵfac, providedIn: 'root' });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ToastService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], null, null); })();

function ToastComponent_Conditional_1_Case_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 8);
    i0.ɵɵelement(1, "circle", 14)(2, "path", 15);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Case_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 9);
    i0.ɵɵelement(1, "circle", 14)(2, "path", 16)(3, "circle", 17);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Case_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 10);
    i0.ɵɵelement(1, "path", 18)(2, "path", 19)(3, "circle", 20);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Case_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 11);
    i0.ɵɵelement(1, "circle", 14)(2, "path", 21);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Case_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 12);
    i0.ɵɵelement(1, "circle", 22)(2, "path", 23);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Case_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 13);
    i0.ɵɵelement(1, "path", 24)(2, "path", 25);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵtemplate(1, ToastComponent_Conditional_1_Case_1_Template, 3, 0, ":svg:svg", 8)(2, ToastComponent_Conditional_1_Case_2_Template, 4, 0, ":svg:svg", 9)(3, ToastComponent_Conditional_1_Case_3_Template, 4, 0, ":svg:svg", 10)(4, ToastComponent_Conditional_1_Case_4_Template, 3, 0, ":svg:svg", 11)(5, ToastComponent_Conditional_1_Case_5_Template, 3, 0, ":svg:svg", 12)(6, ToastComponent_Conditional_1_Case_6_Template, 3, 0, ":svg:svg", 13);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_1_0;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵconditional((tmp_1_0 = ctx_r0.toast().type) === "success" ? 1 : tmp_1_0 === "info" ? 2 : tmp_1_0 === "warning" ? 3 : tmp_1_0 === "error" ? 4 : tmp_1_0 === "loading" ? 5 : tmp_1_0 === "notification" ? 6 : -1);
} }
function ToastComponent_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 3);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.toast().title);
} }
function ToastComponent_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p", 4);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r0.toast().message);
} }
function ToastComponent_Conditional_5_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(0, "svg", 27);
    i0.ɵɵelement(1, "path", 28);
    i0.ɵɵelementEnd();
} }
function ToastComponent_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 26);
    i0.ɵɵlistener("click", function ToastComponent_Conditional_5_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.handleAction()); });
    i0.ɵɵtemplate(1, ToastComponent_Conditional_5_Conditional_1_Template, 2, 0, ":svg:svg", 27);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const action_r3 = ctx;
    i0.ɵɵadvance();
    i0.ɵɵconditional(action_r3.icon === "undo" || action_r3.label.toLowerCase() === "desfazer" ? 1 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(action_r3.label);
} }
function ToastComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 29);
    i0.ɵɵlistener("click", function ToastComponent_Conditional_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r0 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r0.handleClose()); });
    i0.ɵɵnamespaceSVG();
    i0.ɵɵelementStart(1, "svg", 30);
    i0.ɵɵelement(2, "path", 31);
    i0.ɵɵelementEnd()();
} }
function ToastComponent_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 32);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("width", ctx_r0.progress(), "%");
    i0.ɵɵclassProp("orc-toast__progress--paused", ctx_r0.isHovered() && ctx_r0.toast().pauseOnHover);
} }
class ToastComponent {
    destroyRef = inject(DestroyRef);
    // ── Inputs (Signals API) ──────────────────────────────────
    toast = input.required();
    // ── Outputs (Signals API) ─────────────────────────────────
    dismiss = output();
    actionClick = output();
    // ── Estados Internos Reativos ─────────────────────────────
    isHovered = signal(false);
    isExiting = signal(false);
    progress = signal(100);
    timerInterval = null;
    remainingTime = 0;
    totalDuration = 0;
    lastTick = 0;
    // ── Sinais Computados ─────────────────────────────────────
    computedRole = computed(() => {
        if (this.toast().role)
            return this.toast().role;
        const type = this.toast().type;
        return type === 'error' || type === 'warning' ? 'alert' : 'status';
    });
    computedAriaLive = computed(() => {
        if (this.toast().ariaLive)
            return this.toast().ariaLive;
        const type = this.toast().type;
        return type === 'error' ? 'assertive' : 'polite';
    });
    hasProgressBar = computed(() => {
        const t = this.toast();
        const d = t.duration;
        return Boolean(t.showProgressBar) && d > 0 && isFinite(d);
    });
    constructor() {
        // Inicialização do timer reativo de auto-dismiss com suporte a hover pause
        effect(() => {
            const item = this.toast();
            this.initTimer(item);
        });
        this.destroyRef.onDestroy(() => {
            this.clearTimer();
        });
    }
    initTimer(item) {
        this.clearTimer();
        this.totalDuration = item.duration;
        this.remainingTime = item.duration;
        this.progress.set(100);
        if (this.totalDuration <= 0 || !isFinite(this.totalDuration)) {
            return; // Sem auto-dismiss
        }
        this.lastTick = Date.now();
        const intervalMs = 25;
        this.timerInterval = setInterval(() => {
            if (this.isHovered() && item.pauseOnHover) {
                this.lastTick = Date.now();
                return;
            }
            const now = Date.now();
            const elapsed = now - this.lastTick;
            this.lastTick = now;
            this.remainingTime -= elapsed;
            const pct = Math.max(0, (this.remainingTime / this.totalDuration) * 100);
            this.progress.set(pct);
            if (this.remainingTime <= 0) {
                this.clearTimer();
                this.handleClose();
            }
        }, intervalMs);
    }
    clearTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }
    onMouseEnter() {
        this.isHovered.set(true);
    }
    onMouseLeave() {
        this.isHovered.set(false);
        this.lastTick = Date.now();
    }
    handleClose() {
        if (this.isExiting())
            return;
        this.isExiting.set(true);
        this.clearTimer();
        // Permite animação de saída antes da remoção final
        setTimeout(() => {
            this.dismiss.emit(this.toast().id);
        }, 200);
    }
    handleAction() {
        if (this.toast().action) {
            this.toast().action.onClick(this.toast());
            this.actionClick.emit(this.toast());
        }
    }
    static ɵfac = function ToastComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ToastComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ToastComponent, selectors: [["orc-toast"]], hostAttrs: [1, "orc-toast-host"], hostBindings: function ToastComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mouseenter", function ToastComponent_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); })("mouseleave", function ToastComponent_mouseleave_HostBindingHandler() { return ctx.onMouseLeave(); });
        } }, inputs: { toast: [1, "toast"] }, outputs: { dismiss: "dismiss", actionClick: "actionClick" }, decls: 8, vars: 24, consts: [["tabindex", "0", 1, "orc-toast", 3, "keydown.escape"], ["aria-hidden", "true", 1, "orc-toast__icon-wrap"], [1, "orc-toast__content"], [1, "orc-toast__title"], [1, "orc-toast__message"], ["type", "button", 1, "orc-toast__action"], ["type", "button", "aria-label", "Fechar notifica\u00E7\u00E3o", 1, "orc-toast__close"], [1, "orc-toast__progress", 3, "width", "orc-toast__progress--paused"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--success"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--info"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--warning"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--error"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--loading"], ["viewBox", "0 0 20 20", "fill", "none", 1, "orc-toast__icon", "orc-toast__icon--notification"], ["cx", "10", "cy", "10", "r", "8", "stroke", "currentColor", "stroke-width", "1.6"], ["d", "M6.5 10.2L8.8 12.5L13.5 7.5", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M10 13.5V10", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "10", "cy", "6.8", "r", "0.9", "fill", "currentColor"], ["d", "M10 2.5L1.8 16.5H18.2L10 2.5Z", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linejoin", "round"], ["d", "M10 8V11.5", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "10", "cy", "14", "r", "0.8", "fill", "currentColor"], ["d", "M12.5 7.5L7.5 12.5M7.5 7.5L12.5 12.5", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "10", "cy", "10", "r", "7.5", "stroke", "var(--border-default)", "stroke-width", "2"], ["d", "M10 2.5A7.5 7.5 0 0 1 17.5 10", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round"], ["d", "M15 14H5L6.5 12.5V8.5C6.5 6.3 8.1 4.5 10 4.5C11.9 4.5 13.5 6.3 13.5 8.5V12.5L15 14Z", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M8.5 14C8.5 14.8 9.2 15.5 10 15.5C10.8 15.5 11.5 14.8 11.5 14", "stroke", "currentColor", "stroke-width", "1.6", "stroke-linecap", "round"], ["type", "button", 1, "orc-toast__action", 3, "click"], ["viewBox", "0 0 24 24", "fill", "none", "aria-hidden", "true", 1, "orc-toast__action-icon"], ["d", "M9 14L4 9M4 9L9 4M4 9H15C17.7614 9 20 11.2386 20 14C20 16.7614 17.7614 19 15 19H8", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["type", "button", "aria-label", "Fechar notifica\u00E7\u00E3o", 1, "orc-toast__close", 3, "click"], ["viewBox", "0 0 16 16", "fill", "none", "aria-hidden", "true", 1, "orc-toast__close-icon"], ["d", "M12 4L4 12M4 4L12 12", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "orc-toast__progress"]], template: function ToastComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("keydown.escape", function ToastComponent_Template_div_keydown_escape_0_listener() { return ctx.handleClose(); });
            i0.ɵɵtemplate(1, ToastComponent_Conditional_1_Template, 7, 1, "div", 1);
            i0.ɵɵelementStart(2, "div", 2);
            i0.ɵɵtemplate(3, ToastComponent_Conditional_3_Template, 2, 1, "p", 3)(4, ToastComponent_Conditional_4_Template, 2, 1, "p", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ToastComponent_Conditional_5_Template, 4, 2, "button", 5)(6, ToastComponent_Conditional_6_Template, 3, 0, "button", 6)(7, ToastComponent_Conditional_7_Template, 1, 4, "div", 7);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            let tmp_14_0;
            i0.ɵɵclassProp("orc-toast--exiting", ctx.isExiting())("orc-toast--type-success", ctx.toast().type === "success")("orc-toast--type-info", ctx.toast().type === "info")("orc-toast--type-warning", ctx.toast().type === "warning")("orc-toast--type-error", ctx.toast().type === "error")("orc-toast--type-loading", ctx.toast().type === "loading")("orc-toast--type-notification", ctx.toast().type === "notification");
            i0.ɵɵattribute("role", ctx.computedRole())("aria-live", ctx.computedAriaLive())("aria-atomic", true)("aria-label", ctx.toast().ariaLabel || undefined);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.toast().showIcon ? 1 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.toast().title ? 3 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.toast().message ? 4 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional((tmp_14_0 = ctx.toast().action) ? 5 : -1, tmp_14_0);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.toast().dismissible ? 6 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.hasProgressBar() ? 7 : -1);
        } }, dependencies: [CommonModule], styles: ["[_nghost-%COMP%]{display:block;width:100%;max-width:448px;pointer-events:auto}.orc-toast[_ngcontent-%COMP%]{position:relative;display:flex;align-items:center;gap:12px;width:100%;min-height:58px;padding:17px;background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--border-default, #D9D9D9);border-radius:var(--radius-md, 10px);box-shadow:0 4px 14px #00000014,0 1px 3px #0000000a;font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;overflow:hidden;outline:none;animation:_ngcontent-%COMP%_orc-toast-enter var(--transition-base, .25s) cubic-bezier(.16,1,.3,1) forwards;transition:transform var(--transition-fast, .15s ease),box-shadow var(--transition-fast, .15s ease),opacity var(--transition-fast, .15s ease)}.orc-toast[_ngcontent-%COMP%]:hover{box-shadow:0 6px 20px #0000001f,0 2px 6px #0000000f}.orc-toast[_ngcontent-%COMP%]:focus-visible{border-color:var(--orc-color-azul-eletrico, #1C6AED);box-shadow:0 0 0 3px #1c6aed33}.orc-toast--exiting[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_orc-toast-exit var(--transition-base, .2s) cubic-bezier(.4,0,1,1) forwards!important}.orc-toast__icon-wrap[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px}.orc-toast__icon[_ngcontent-%COMP%]{width:20px;height:20px;display:block}.orc-toast__icon--success[_ngcontent-%COMP%]{color:var(--color-success, #006F4A)}.orc-toast__icon--info[_ngcontent-%COMP%]{color:var(--color-info, #2B7FFF)}.orc-toast__icon--warning[_ngcontent-%COMP%]{color:var(--color-warning, #FE9A00)}.orc-toast__icon--error[_ngcontent-%COMP%]{color:var(--color-error, #FB2C36)}.orc-toast__icon--loading[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414);animation:_ngcontent-%COMP%_orc-toast-spin .9s linear infinite}.orc-toast__icon--notification[_ngcontent-%COMP%]{color:var(--orc-font-main, #141414)}.orc-toast__content[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;gap:4px;min-width:0;word-break:break-word}.orc-toast__title[_ngcontent-%COMP%]{margin:0;padding:0;font-size:16px;font-weight:500;line-height:24px;letter-spacing:-.3px;color:var(--orc-font-main, #141414)}.orc-toast__message[_ngcontent-%COMP%]{margin:0;padding:0;font-size:14px;font-weight:400;line-height:20px;color:var(--orc-font-secondary, #666666)}.orc-toast__action[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:32px;padding:0 13px;border:1px solid var(--border-default, #D9D9D9);border-radius:var(--radius-sm, 8px);background-color:var(--orc-bg, #FFFFFF);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:500;line-height:20px;cursor:pointer;flex-shrink:0;white-space:nowrap;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),transform var(--transition-fast, .12s ease)}.orc-toast__action[_ngcontent-%COMP%]:hover{background-color:var(--bg-muted, #EDEDED);border-color:var(--border-strong, #BDBDBD)}.orc-toast__action[_ngcontent-%COMP%]:active{transform:scale(.97)}.orc-toast__action[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1C6AED);outline-offset:2px}.orc-toast__action-icon[_ngcontent-%COMP%]{width:18px;height:18px;flex-shrink:0}.orc-toast__close[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-font-secondary, #666666);cursor:pointer;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-toast__close[_ngcontent-%COMP%]:hover{background-color:var(--bg-muted, rgba(0, 0, 0, .06));color:var(--orc-font-main, #141414)}.orc-toast__close[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1C6AED);outline-offset:2px}.orc-toast__close-icon[_ngcontent-%COMP%]{width:14px;height:14px}.orc-toast__progress[_ngcontent-%COMP%]{position:absolute;bottom:0;left:0;height:3px;background-color:var(--orc-color-azul-eletrico, #1C6AED);opacity:.6;border-radius:0 0 0 10px;transition:width 25ms linear}.orc-toast__progress--paused[_ngcontent-%COMP%]{background-color:var(--orc-color-laranja, #FF6A1C)}.orc-toast--type-success[_ngcontent-%COMP%]   .orc-toast__progress[_ngcontent-%COMP%]{background-color:var(--color-success, #006F4A)}.orc-toast--type-error[_ngcontent-%COMP%]   .orc-toast__progress[_ngcontent-%COMP%]{background-color:var(--color-error, #FB2C36)}.orc-toast--type-warning[_ngcontent-%COMP%]   .orc-toast__progress[_ngcontent-%COMP%]{background-color:var(--color-warning, #FE9A00)}.orc-toast--type-info[_ngcontent-%COMP%]   .orc-toast__progress[_ngcontent-%COMP%]{background-color:var(--color-info, #2B7FFF)}@keyframes _ngcontent-%COMP%_orc-toast-enter{0%{opacity:0;transform:translateY(16px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes _ngcontent-%COMP%_orc-toast-exit{0%{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-8px) scale(.95)}}@keyframes _ngcontent-%COMP%_orc-toast-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-toast[_ngcontent-%COMP%]{animation:none!important;transition:opacity .15s ease!important}.orc-toast--exiting[_ngcontent-%COMP%]{animation:none!important;opacity:0!important}.orc-toast__icon--loading[_ngcontent-%COMP%]{animation:none!important}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ToastComponent, [{
        type: Component,
        args: [{ selector: 'orc-toast', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    'class': 'orc-toast-host',
                    '(mouseenter)': 'onMouseEnter()',
                    '(mouseleave)': 'onMouseLeave()',
                }, template: "<div\n  class=\"orc-toast\"\n  [class.orc-toast--exiting]=\"isExiting()\"\n  [class.orc-toast--type-success]=\"toast().type === 'success'\"\n  [class.orc-toast--type-info]=\"toast().type === 'info'\"\n  [class.orc-toast--type-warning]=\"toast().type === 'warning'\"\n  [class.orc-toast--type-error]=\"toast().type === 'error'\"\n  [class.orc-toast--type-loading]=\"toast().type === 'loading'\"\n  [class.orc-toast--type-notification]=\"toast().type === 'notification'\"\n  [attr.role]=\"computedRole()\"\n  [attr.aria-live]=\"computedAriaLive()\"\n  [attr.aria-atomic]=\"true\"\n  [attr.aria-label]=\"toast().ariaLabel || undefined\"\n  tabindex=\"0\"\n  (keydown.escape)=\"handleClose()\"\n>\n  <!-- \u00CDcone Sem\u00E2ntico (Figma Node 382:5265) -->\n  @if (toast().showIcon) {\n    <div class=\"orc-toast__icon-wrap\" aria-hidden=\"true\">\n      @switch (toast().type) {\n        @case ('success') {\n          <svg class=\"orc-toast__icon orc-toast__icon--success\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <circle cx=\"10\" cy=\"10\" r=\"8\" stroke=\"currentColor\" stroke-width=\"1.6\" />\n            <path d=\"M6.5 10.2L8.8 12.5L13.5 7.5\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n          </svg>\n        }\n        @case ('info') {\n          <svg class=\"orc-toast__icon orc-toast__icon--info\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <circle cx=\"10\" cy=\"10\" r=\"8\" stroke=\"currentColor\" stroke-width=\"1.6\" />\n            <path d=\"M10 13.5V10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n            <circle cx=\"10\" cy=\"6.8\" r=\"0.9\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case ('warning') {\n          <svg class=\"orc-toast__icon orc-toast__icon--warning\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <path d=\"M10 2.5L1.8 16.5H18.2L10 2.5Z\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linejoin=\"round\" />\n            <path d=\"M10 8V11.5\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n            <circle cx=\"10\" cy=\"14\" r=\"0.8\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case ('error') {\n          <svg class=\"orc-toast__icon orc-toast__icon--error\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <circle cx=\"10\" cy=\"10\" r=\"8\" stroke=\"currentColor\" stroke-width=\"1.6\" />\n            <path d=\"M12.5 7.5L7.5 12.5M7.5 7.5L12.5 12.5\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n          </svg>\n        }\n        @case ('loading') {\n          <svg class=\"orc-toast__icon orc-toast__icon--loading\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <circle cx=\"10\" cy=\"10\" r=\"7.5\" stroke=\"var(--border-default)\" stroke-width=\"2\" />\n            <path d=\"M10 2.5A7.5 7.5 0 0 1 17.5 10\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" />\n          </svg>\n        }\n        @case ('notification') {\n          <svg class=\"orc-toast__icon orc-toast__icon--notification\" viewBox=\"0 0 20 20\" fill=\"none\">\n            <path d=\"M15 14H5L6.5 12.5V8.5C6.5 6.3 8.1 4.5 10 4.5C11.9 4.5 13.5 6.3 13.5 8.5V12.5L15 14Z\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n            <path d=\"M8.5 14C8.5 14.8 9.2 15.5 10 15.5C10.8 15.5 11.5 14.8 11.5 14\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\"/>\n          </svg>\n        }\n      }\n    </div>\n  }\n\n  <!-- Corpo do Texto -->\n  <div class=\"orc-toast__content\">\n    @if (toast().title) {\n      <p class=\"orc-toast__title\">{{ toast().title }}</p>\n    }\n    @if (toast().message) {\n      <p class=\"orc-toast__message\">{{ toast().message }}</p>\n    }\n  </div>\n\n  <!-- A\u00E7\u00E3o Customizada (Bot\u00E3o Desfazer / Saiba mais) -->\n  @if (toast().action; as action) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__action\"\n      (click)=\"handleAction()\"\n    >\n      @if (action.icon === 'undo' || action.label.toLowerCase() === 'desfazer') {\n        <svg class=\"orc-toast__action-icon\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\">\n          <path d=\"M9 14L4 9M4 9L9 4M4 9H15C17.7614 9 20 11.2386 20 14C20 16.7614 17.7614 19 15 19H8\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n        </svg>\n      }\n      <span>{{ action.label }}</span>\n    </button>\n  }\n\n  <!-- Bot\u00E3o Manual de Fechar -->\n  @if (toast().dismissible) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__close\"\n      aria-label=\"Fechar notifica\u00E7\u00E3o\"\n      (click)=\"handleClose()\"\n    >\n      <svg viewBox=\"0 0 16 16\" fill=\"none\" class=\"orc-toast__close-icon\" aria-hidden=\"true\">\n        <path d=\"M12 4L4 12M4 4L12 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n      </svg>\n    </button>\n  }\n\n  <!-- Barra de Progresso de Auto-Dismiss -->\n  @if (hasProgressBar()) {\n    <div\n      class=\"orc-toast__progress\"\n      [style.width.%]=\"progress()\"\n      [class.orc-toast__progress--paused]=\"isHovered() && toast().pauseOnHover\"\n    ></div>\n  }\n</div>\n", styles: [":host{display:block;width:100%;max-width:448px;pointer-events:auto}.orc-toast{position:relative;display:flex;align-items:center;gap:12px;width:100%;min-height:58px;padding:17px;background-color:var(--orc-bg, #FFFFFF);border:1px solid var(--border-default, #D9D9D9);border-radius:var(--radius-md, 10px);box-shadow:0 4px 14px #00000014,0 1px 3px #0000000a;font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;overflow:hidden;outline:none;animation:orc-toast-enter var(--transition-base, .25s) cubic-bezier(.16,1,.3,1) forwards;transition:transform var(--transition-fast, .15s ease),box-shadow var(--transition-fast, .15s ease),opacity var(--transition-fast, .15s ease)}.orc-toast:hover{box-shadow:0 6px 20px #0000001f,0 2px 6px #0000000f}.orc-toast:focus-visible{border-color:var(--orc-color-azul-eletrico, #1C6AED);box-shadow:0 0 0 3px #1c6aed33}.orc-toast--exiting{animation:orc-toast-exit var(--transition-base, .2s) cubic-bezier(.4,0,1,1) forwards!important}.orc-toast__icon-wrap{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px}.orc-toast__icon{width:20px;height:20px;display:block}.orc-toast__icon--success{color:var(--color-success, #006F4A)}.orc-toast__icon--info{color:var(--color-info, #2B7FFF)}.orc-toast__icon--warning{color:var(--color-warning, #FE9A00)}.orc-toast__icon--error{color:var(--color-error, #FB2C36)}.orc-toast__icon--loading{color:var(--orc-font-main, #141414);animation:orc-toast-spin .9s linear infinite}.orc-toast__icon--notification{color:var(--orc-font-main, #141414)}.orc-toast__content{flex:1 1 auto;display:flex;flex-direction:column;gap:4px;min-width:0;word-break:break-word}.orc-toast__title{margin:0;padding:0;font-size:16px;font-weight:500;line-height:24px;letter-spacing:-.3px;color:var(--orc-font-main, #141414)}.orc-toast__message{margin:0;padding:0;font-size:14px;font-weight:400;line-height:20px;color:var(--orc-font-secondary, #666666)}.orc-toast__action{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:32px;padding:0 13px;border:1px solid var(--border-default, #D9D9D9);border-radius:var(--radius-sm, 8px);background-color:var(--orc-bg, #FFFFFF);color:var(--orc-font-main, #141414);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:500;line-height:20px;cursor:pointer;flex-shrink:0;white-space:nowrap;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),transform var(--transition-fast, .12s ease)}.orc-toast__action:hover{background-color:var(--bg-muted, #EDEDED);border-color:var(--border-strong, #BDBDBD)}.orc-toast__action:active{transform:scale(.97)}.orc-toast__action:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1C6AED);outline-offset:2px}.orc-toast__action-icon{width:18px;height:18px;flex-shrink:0}.orc-toast__close{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-font-secondary, #666666);cursor:pointer;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-toast__close:hover{background-color:var(--bg-muted, rgba(0, 0, 0, .06));color:var(--orc-font-main, #141414)}.orc-toast__close:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1C6AED);outline-offset:2px}.orc-toast__close-icon{width:14px;height:14px}.orc-toast__progress{position:absolute;bottom:0;left:0;height:3px;background-color:var(--orc-color-azul-eletrico, #1C6AED);opacity:.6;border-radius:0 0 0 10px;transition:width 25ms linear}.orc-toast__progress--paused{background-color:var(--orc-color-laranja, #FF6A1C)}.orc-toast--type-success .orc-toast__progress{background-color:var(--color-success, #006F4A)}.orc-toast--type-error .orc-toast__progress{background-color:var(--color-error, #FB2C36)}.orc-toast--type-warning .orc-toast__progress{background-color:var(--color-warning, #FE9A00)}.orc-toast--type-info .orc-toast__progress{background-color:var(--color-info, #2B7FFF)}@keyframes orc-toast-enter{0%{opacity:0;transform:translateY(16px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes orc-toast-exit{0%{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-8px) scale(.95)}}@keyframes orc-toast-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-toast{animation:none!important;transition:opacity .15s ease!important}.orc-toast--exiting{animation:none!important;opacity:0!important}.orc-toast__icon--loading{animation:none!important}}\n"] }]
    }], () => [], null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ToastComponent, { className: "ToastComponent", filePath: "toast.component.ts", lineNumber: 28 }); })();

const _forTrack0 = ($index, $item) => $item.id;
function ToastContainerComponent_For_1_Conditional_0_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "orc-toast", 3);
    i0.ɵɵlistener("dismiss", function ToastContainerComponent_For_1_Conditional_0_For_2_Template_orc_toast_dismiss_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.handleDismiss($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵproperty("toast", item_r3);
} }
function ToastContainerComponent_For_1_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵrepeaterCreate(1, ToastContainerComponent_For_1_Conditional_0_For_2_Template, 1, 1, "orc-toast", 2, _forTrack0);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const pos_r4 = i0.ɵɵnextContext().$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassMap("orc-toast-stack--" + pos_r4);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(ctx_r1.toastsByPosition()[pos_r4]);
} }
function ToastContainerComponent_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, ToastContainerComponent_For_1_Conditional_0_Template, 3, 2, "div", 0);
} if (rf & 2) {
    const pos_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵconditional(ctx_r1.toastsByPosition()[pos_r4].length > 0 ? 0 : -1);
} }
class ToastContainerComponent {
    toastService = inject(ToastService);
    // ── Inputs e Outputs para suporte declarativo e via serviço ──
    toasts = input();
    dismiss = output();
    positions = [
        'top-right',
        'top-left',
        'top-center',
        'bottom-right',
        'bottom-left',
        'bottom-center',
    ];
    /** Lista consolidada de toasts (input declarativo com fallback para o ToastService) */
    activeToasts = computed(() => this.toasts() ?? this.toastService.toasts());
    /** Agrupa os toasts de forma reativa e memorizada por posição */
    toastsByPosition = computed(() => {
        const all = this.activeToasts();
        const map = {
            'top-right': [],
            'top-left': [],
            'top-center': [],
            'bottom-right': [],
            'bottom-left': [],
            'bottom-center': [],
        };
        for (const toast of all) {
            if (map[toast.position]) {
                map[toast.position].push(toast);
            }
        }
        return map;
    });
    handleDismiss(id) {
        this.dismiss.emit(id);
        this.toastService.dismiss(id);
    }
    static ɵfac = function ToastContainerComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ToastContainerComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ToastContainerComponent, selectors: [["orc-toast-container"]], hostAttrs: [1, "orc-toast-container-host"], inputs: { toasts: [1, "toasts"] }, outputs: { dismiss: "dismiss" }, decls: 2, vars: 0, consts: [["role", "region", "aria-label", "Notifica\u00E7\u00F5es", "aria-live", "polite", 1, "orc-toast-stack", 3, "class"], ["role", "region", "aria-label", "Notifica\u00E7\u00F5es", "aria-live", "polite", 1, "orc-toast-stack"], [3, "toast"], [3, "dismiss", "toast"]], template: function ToastContainerComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵrepeaterCreate(0, ToastContainerComponent_For_1_Template, 1, 1, null, null, i0.ɵɵrepeaterTrackByIdentity);
        } if (rf & 2) {
            i0.ɵɵrepeater(ctx.positions);
        } }, dependencies: [CommonModule, ToastComponent], styles: ["[_nghost-%COMP%]{display:contents;pointer-events:none}.orc-toast-stack[_ngcontent-%COMP%]{position:fixed;z-index:9999;display:flex;flex-direction:column;gap:12px;max-width:calc(100vw - 32px);width:448px;pointer-events:none;box-sizing:border-box}.orc-toast-stack--top-right[_ngcontent-%COMP%]{top:24px;right:24px;align-items:flex-end}.orc-toast-stack--top-left[_ngcontent-%COMP%]{top:24px;left:24px;align-items:flex-start}.orc-toast-stack--top-center[_ngcontent-%COMP%]{top:24px;left:50%;transform:translate(-50%);align-items:center}.orc-toast-stack--bottom-right[_ngcontent-%COMP%]{bottom:24px;right:24px;align-items:flex-end;flex-direction:column-reverse}.orc-toast-stack--bottom-left[_ngcontent-%COMP%]{bottom:24px;left:24px;align-items:flex-start;flex-direction:column-reverse}.orc-toast-stack--bottom-center[_ngcontent-%COMP%]{bottom:24px;left:50%;transform:translate(-50%);align-items:center;flex-direction:column-reverse}@media(max-width:640px){.orc-toast-stack[_ngcontent-%COMP%]{left:16px!important;right:16px!important;width:auto!important;max-width:none!important;transform:none!important;align-items:stretch!important}.orc-toast-stack--top-right[_ngcontent-%COMP%], .orc-toast-stack--top-left[_ngcontent-%COMP%], .orc-toast-stack--top-center[_ngcontent-%COMP%]{top:16px}.orc-toast-stack--bottom-right[_ngcontent-%COMP%], .orc-toast-stack--bottom-left[_ngcontent-%COMP%], .orc-toast-stack--bottom-center[_ngcontent-%COMP%]{bottom:16px}}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ToastContainerComponent, [{
        type: Component,
        args: [{ selector: 'orc-toast-container', standalone: true, imports: [CommonModule, ToastComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    'class': 'orc-toast-container-host',
                }, template: "@for (pos of positions; track pos) {\n  @if (toastsByPosition()[pos].length > 0) {\n    <div\n      class=\"orc-toast-stack\"\n      [class]=\"'orc-toast-stack--' + pos\"\n      role=\"region\"\n      aria-label=\"Notifica\u00E7\u00F5es\"\n      aria-live=\"polite\"\n    >\n      @for (item of toastsByPosition()[pos]; track item.id) {\n        <orc-toast\n          [toast]=\"item\"\n          (dismiss)=\"handleDismiss($event)\"\n        />\n      }\n    </div>\n  }\n}\n", styles: [":host{display:contents;pointer-events:none}.orc-toast-stack{position:fixed;z-index:9999;display:flex;flex-direction:column;gap:12px;max-width:calc(100vw - 32px);width:448px;pointer-events:none;box-sizing:border-box}.orc-toast-stack--top-right{top:24px;right:24px;align-items:flex-end}.orc-toast-stack--top-left{top:24px;left:24px;align-items:flex-start}.orc-toast-stack--top-center{top:24px;left:50%;transform:translate(-50%);align-items:center}.orc-toast-stack--bottom-right{bottom:24px;right:24px;align-items:flex-end;flex-direction:column-reverse}.orc-toast-stack--bottom-left{bottom:24px;left:24px;align-items:flex-start;flex-direction:column-reverse}.orc-toast-stack--bottom-center{bottom:24px;left:50%;transform:translate(-50%);align-items:center;flex-direction:column-reverse}@media(max-width:640px){.orc-toast-stack{left:16px!important;right:16px!important;width:auto!important;max-width:none!important;transform:none!important;align-items:stretch!important}.orc-toast-stack--top-right,.orc-toast-stack--top-left,.orc-toast-stack--top-center{top:16px}.orc-toast-stack--bottom-right,.orc-toast-stack--bottom-left,.orc-toast-stack--bottom-center{bottom:16px}}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ToastContainerComponent, { className: "ToastContainerComponent", filePath: "toast-container.component.ts", lineNumber: 25 }); })();

var toastContainer_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ToastContainerComponent: ToastContainerComponent
});

/**
 * Generated bundle index. Do not edit.
 */

export { ToastComponent, ToastContainerComponent, ToastService };
//# sourceMappingURL=ciag-orchestra-toast.mjs.map
