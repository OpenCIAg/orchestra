import * as i0 from '@angular/core';
import { viewChild, input, booleanAttribute, output, ChangeDetectionStrategy, Component, HostListener } from '@angular/core';

const _c0 = ["nativeForm"];
const _c1 = ["*"];
class FormComponent {
    nativeForm = viewChild('nativeForm');
    layout = input('stacked');
    name = input('');
    ariaLabel = input('Formulário');
    disabled = input(false, { transform: booleanAttribute });
    novalidate = input(true, { transform: booleanAttribute });
    formSubmit = output();
    formReset = output();
    onSubmit(event) {
        event.preventDefault();
        const form = this.nativeForm()?.nativeElement;
        if (!form || this.disabled())
            return;
        const valid = form.checkValidity();
        if (!valid) {
            form.reportValidity();
        }
        this.formSubmit.emit({ event, valid });
    }
    onReset() { this.formReset.emit(); }
    reset() { this.nativeForm()?.nativeElement.reset(); this.onReset(); }
    submit() { this.nativeForm()?.nativeElement.requestSubmit(); }
    onKeydown(event) { if (this.disabled() && event.key === 'Enter')
        event.preventDefault(); }
    static ɵfac = function FormComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FormComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FormComponent, selectors: [["orc-form"]], viewQuery: function FormComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.nativeForm, _c0, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance();
        } }, hostBindings: function FormComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("keydown", function FormComponent_keydown_HostBindingHandler($event) { return ctx.onKeydown($event); });
        } }, inputs: { layout: [1, "layout"], name: [1, "name"], ariaLabel: [1, "ariaLabel"], disabled: [1, "disabled"], novalidate: [1, "novalidate"] }, outputs: { formSubmit: "formSubmit", formReset: "formReset" }, ngContentSelectors: _c1, decls: 4, vars: 8, consts: [["nativeForm", ""], [1, "orc-form", 3, "submit", "reset"], [3, "disabled"]], template: function FormComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "form", 1, 0);
            i0.ɵɵlistener("submit", function FormComponent_Template_form_submit_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onSubmit($event)); })("reset", function FormComponent_Template_form_reset_0_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onReset()); });
            i0.ɵɵelementStart(2, "fieldset", 2);
            i0.ɵɵprojection(3);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("orc-form--inline", ctx.layout() === "inline")("orc-form--disabled", ctx.disabled());
            i0.ɵɵattribute("name", ctx.name() || null)("aria-label", ctx.ariaLabel())("novalidate", ctx.novalidate() ? "" : null);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.disabled());
        } }, styles: ["[_nghost-%COMP%]{display:block;width:100%}.orc-form[_ngcontent-%COMP%]{width:100%}.orc-form[_ngcontent-%COMP%]   fieldset[_ngcontent-%COMP%]{display:grid;gap:16px;min-width:0;margin:0;padding:0;border:0}.orc-form--inline[_ngcontent-%COMP%]   fieldset[_ngcontent-%COMP%]{grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end}.orc-form--disabled[_ngcontent-%COMP%]{opacity:.6}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FormComponent, [{
        type: Component,
        args: [{ selector: 'orc-form', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<form #nativeForm class=\"orc-form\" [class.orc-form--inline]=\"layout() === 'inline'\" [attr.name]=\"name() || null\" [attr.aria-label]=\"ariaLabel()\" [attr.novalidate]=\"novalidate() ? '' : null\" [class.orc-form--disabled]=\"disabled()\" (submit)=\"onSubmit($event)\" (reset)=\"onReset()\">\n  <fieldset [disabled]=\"disabled()\"><ng-content /></fieldset>\n</form>\n", styles: [":host{display:block;width:100%}.orc-form{width:100%}.orc-form fieldset{display:grid;gap:16px;min-width:0;margin:0;padding:0;border:0}.orc-form--inline fieldset{grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end}.orc-form--disabled{opacity:.6}\n"] }]
    }], null, { onKeydown: [{
            type: HostListener,
            args: ['keydown', ['$event']]
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FormComponent, { className: "FormComponent", filePath: "form.component.ts", lineNumber: 17 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { FormComponent };
//# sourceMappingURL=ciag-orchestra-form.mjs.map
