import * as i0 from '@angular/core';
import { input, output, ChangeDetectionStrategy, Component } from '@angular/core';

const _forTrack0 = ($index, $item) => $item.id;
function ListComponent_For_2_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 5);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(item_r2.description);
} }
function ListComponent_For_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 3);
    i0.ɵɵlistener("click", function ListComponent_For_2_Template_button_click_0_listener() { const item_r2 = i0.ɵɵrestoreView(_r1).$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.select(item_r2)); });
    i0.ɵɵelementStart(1, "span", 4);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, ListComponent_For_2_Conditional_3_Template, 2, 1, "span", 5);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", item_r2.disabled);
    i0.ɵɵattribute("aria-selected", ctx_r2.selection() !== "none" ? item_r2.selected : null);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(item_r2.label);
    i0.ɵɵadvance();
    i0.ɵɵconditional(item_r2.description ? 3 : -1);
} }
function ListComponent_ForEmpty_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 2);
    i0.ɵɵtext(1, "Nenhum item");
    i0.ɵɵelementEnd();
} }
class ListComponent {
    items = input([]);
    label = input('Lista');
    selection = input('none');
    itemSelect = output();
    select(item) { if (!item.disabled)
        this.itemSelect.emit(item); }
    static ɵfac = function ListComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ListComponent)(); };
    static ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListComponent, selectors: [["orc-list"]], inputs: { items: [1, "items"], label: [1, "label"], selection: [1, "selection"] }, outputs: { itemSelect: "itemSelect" }, decls: 4, vars: 3, consts: [["role", "listbox", 1, "orc-list"], ["type", "button", "role", "option", 1, "orc-list__item", 3, "disabled"], [1, "orc-list__empty"], ["type", "button", "role", "option", 1, "orc-list__item", 3, "click", "disabled"], [1, "orc-list__label"], [1, "orc-list__description"]], template: function ListComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵrepeaterCreate(1, ListComponent_For_2_Template, 4, 4, "button", 1, _forTrack0, false, ListComponent_ForEmpty_3_Template, 2, 0, "div", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵattribute("aria-label", ctx.label())("aria-multiselectable", ctx.selection() === "multiple" ? "true" : null);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.items());
        } }, styles: [".orc-list[_ngcontent-%COMP%]{display:grid;background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);overflow:hidden}.orc-list__item[_ngcontent-%COMP%]{display:grid;gap:var(--space-1);padding:var(--space-3) var(--space-4);text-align:left;background:transparent;color:inherit;border:0;border-bottom:1px solid var(--border-default);cursor:pointer}.orc-list__item[_ngcontent-%COMP%]:last-child{border-bottom:0}.orc-list__item[_ngcontent-%COMP%]:hover:not(:disabled), .orc-list__item[aria-selected=true][_ngcontent-%COMP%]{background:var(--bg-muted)}.orc-list__item[_ngcontent-%COMP%]:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-list__item[_ngcontent-%COMP%]:disabled{opacity:.5;cursor:not-allowed}.orc-list__label[_ngcontent-%COMP%]{font-weight:600}.orc-list__description[_ngcontent-%COMP%], .orc-list__empty[_ngcontent-%COMP%]{font-size:.8125rem;color:var(--text-secondary)}.orc-list__empty[_ngcontent-%COMP%]{padding:var(--space-4)}"], changeDetection: 0 });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListComponent, [{
        type: Component,
        args: [{ selector: 'orc-list', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-list\" role=\"listbox\" [attr.aria-label]=\"label()\" [attr.aria-multiselectable]=\"selection()==='multiple' ? 'true' : null\">@for(item of items();track item.id){<button type=\"button\" class=\"orc-list__item\" role=\"option\" [disabled]=\"item.disabled\" [attr.aria-selected]=\"selection()!=='none' ? item.selected : null\" (click)=\"select(item)\"><span class=\"orc-list__label\">{{item.label}}</span>@if(item.description){<span class=\"orc-list__description\">{{item.description}}</span>}</button>}@empty{<div class=\"orc-list__empty\">Nenhum item</div>}</div>\n", styles: [".orc-list{display:grid;background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);overflow:hidden}.orc-list__item{display:grid;gap:var(--space-1);padding:var(--space-3) var(--space-4);text-align:left;background:transparent;color:inherit;border:0;border-bottom:1px solid var(--border-default);cursor:pointer}.orc-list__item:last-child{border-bottom:0}.orc-list__item:hover:not(:disabled),.orc-list__item[aria-selected=true]{background:var(--bg-muted)}.orc-list__item:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-list__item:disabled{opacity:.5;cursor:not-allowed}.orc-list__label{font-weight:600}.orc-list__description,.orc-list__empty{font-size:.8125rem;color:var(--text-secondary)}.orc-list__empty{padding:var(--space-4)}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ListComponent, { className: "ListComponent", filePath: "list.component.ts", lineNumber: 4 }); })();

/**
 * Generated bundle index. Do not edit.
 */

export { ListComponent };
//# sourceMappingURL=ciag-orchestra-list.mjs.map
