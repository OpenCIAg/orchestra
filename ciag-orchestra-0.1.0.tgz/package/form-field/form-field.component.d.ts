import * as i0 from "@angular/core";
export declare class FormFieldComponent {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly helperText: import("@angular/core").InputSignal<string>;
    readonly error: import("@angular/core").InputSignal<string>;
    readonly required: import("@angular/core").InputSignal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "orc-form-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
