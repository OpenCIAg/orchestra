import { ChipSize, ChipVariant } from './chip.types';
import * as i0 from "@angular/core";
export declare class ChipComponent {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly value: import("@angular/core").InputSignal<string | number>;
    readonly variant: import("@angular/core").InputSignal<ChipVariant>;
    readonly size: import("@angular/core").InputSignal<ChipSize>;
    readonly selectable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly selected: import("@angular/core").ModelSignal<boolean>;
    readonly removed: import("@angular/core").OutputEmitterRef<string | number>;
    toggle(): void;
    remove(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChipComponent, "orc-chip", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "removed": "removed"; }, never, never, true, never>;
}
