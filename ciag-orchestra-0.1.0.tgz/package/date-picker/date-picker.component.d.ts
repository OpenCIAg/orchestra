import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DatePickerComponent implements ControlValueAccessor {
    readonly value: import("@angular/core").ModelSignal<string>;
    readonly label: import("@angular/core").InputSignal<string>;
    readonly min: import("@angular/core").InputSignal<string>;
    readonly max: import("@angular/core").InputSignal<string>;
    readonly helperText: import("@angular/core").InputSignal<string>;
    readonly error: import("@angular/core").InputSignal<string>;
    readonly required: import("@angular/core").InputSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    protected readonly cvaDisabled: import("@angular/core").WritableSignal<boolean>;
    private onChange;
    private onTouched;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    update(event: Event): void;
    touch(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "orc-date-picker", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
