import * as i0 from "@angular/core";
export type DrawerPlacement = 'left' | 'right' | 'top' | 'bottom';
export declare class DrawerComponent {
    readonly open: import("@angular/core").ModelSignal<boolean>;
    readonly placement: import("@angular/core").InputSignal<DrawerPlacement>;
    readonly label: import("@angular/core").InputSignal<string>;
    readonly closeOnBackdrop: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly dismissible: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    close(): void;
    onBackdrop(): void;
    onEscape(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerComponent, "orc-drawer", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "closeOnBackdrop": { "alias": "closeOnBackdrop"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "closed": "closed"; }, never, ["[drawer-title]", "*", "[drawer-actions]"], true, never>;
}
