import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface FormSubmitEvent {
    event: SubmitEvent;
    valid: boolean;
}
export type FormLayout = 'stacked' | 'inline';
export declare class FormComponent {
    readonly nativeForm: import("@angular/core").Signal<ElementRef<HTMLFormElement> | undefined>;
    readonly layout: import("@angular/core").InputSignal<FormLayout>;
    readonly name: import("@angular/core").InputSignal<string>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly novalidate: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly formSubmit: import("@angular/core").OutputEmitterRef<FormSubmitEvent>;
    readonly formReset: import("@angular/core").OutputEmitterRef<void>;
    onSubmit(event: SubmitEvent): void;
    onReset(): void;
    reset(): void;
    submit(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormComponent, "orc-form", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "novalidate": { "alias": "novalidate"; "required": false; "isSignal": true; }; }, { "formSubmit": "formSubmit"; "formReset": "formReset"; }, never, ["*"], true, never>;
}
