import * as i0 from "@angular/core";
export declare class CollapsibleComponent {
    private readonly uniqueId;
    readonly id: import("@angular/core").InputSignal<string>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly summary: import("@angular/core").InputSignal<string>;
    readonly open: import("@angular/core").ModelSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly lazy: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly toggleChange: import("@angular/core").OutputEmitterRef<boolean>;
    readonly effectiveId: import("@angular/core").Signal<string>;
    readonly triggerId: import("@angular/core").Signal<string>;
    readonly contentId: import("@angular/core").Signal<string>;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CollapsibleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CollapsibleComponent, "orc-collapsible", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "summary": { "alias": "summary"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "toggleChange": "toggleChange"; }, never, ["*"], true, never>;
}
