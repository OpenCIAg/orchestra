import { OnDestroy } from '@angular/core';
import { CarouselItem, CarouselOrientation } from './carousel.types';
import * as i0 from "@angular/core";
export declare class CarouselComponent implements OnDestroy {
    private readonly carouselId;
    private autoplayTimer;
    readonly items: import("@angular/core").InputSignal<CarouselItem[]>;
    readonly activeIndex: import("@angular/core").ModelSignal<number>;
    readonly orientation: import("@angular/core").InputSignal<CarouselOrientation>;
    readonly loop: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly autoplay: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly interval: import("@angular/core").InputSignalWithTransform<number, unknown>;
    readonly showArrows: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly showIndicators: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly slideChange: import("@angular/core").OutputEmitterRef<{
        index: number;
        item: CarouselItem;
    }>;
    readonly activeItem: import("@angular/core").Signal<CarouselItem>;
    readonly safeIndex: import("@angular/core").Signal<number>;
    readonly canGoPrevious: import("@angular/core").Signal<boolean>;
    readonly canGoNext: import("@angular/core").Signal<boolean>;
    readonly itemId: (index: number) => string;
    constructor();
    ngOnDestroy(): void;
    previous(): void;
    next(): void;
    goTo(index: number): void;
    trackItem(index: number, item: CarouselItem): string | number;
    onKeydown(event: KeyboardEvent): void;
    private findIndex;
    private stopAutoplay;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CarouselComponent, "orc-carousel", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "loop": { "alias": "loop"; "required": false; "isSignal": true; }; "autoplay": { "alias": "autoplay"; "required": false; "isSignal": true; }; "interval": { "alias": "interval"; "required": false; "isSignal": true; }; "showArrows": { "alias": "showArrows"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "activeIndex": "activeIndexChange"; "slideChange": "slideChange"; }, never, never, true, never>;
}
