import { InjectionToken, Provider } from '@angular/core';
import { IconSize, OrcIconDefinition, IconFill } from './icon.types';
import * as i0 from "@angular/core";
export declare const ORC_ICON_FALLBACK: OrcIconDefinition;
export declare const ORC_ICON_REGISTRY: InjectionToken<OrcIconRegistry>;
export interface OrcIconRegistry {
    get(name: string): OrcIconDefinition | undefined;
}
export declare function provideOrcIcons(...icons: OrcIconDefinition[]): Provider;
export declare class IconComponent {
    readonly name: import("@angular/core").InputSignal<string>;
    readonly icon: import("@angular/core").InputSignal<OrcIconDefinition | null>;
    readonly size: import("@angular/core").InputSignal<IconSize>;
    readonly fill: import("@angular/core").InputSignal<IconFill>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly title: import("@angular/core").InputSignal<string>;
    private readonly registry;
    readonly definition: import("@angular/core").Signal<OrcIconDefinition>;
    readonly paths: import("@angular/core").Signal<readonly import("@ciag/orchestra/icon").OrcIconPath[]>;
    readonly sizeValue: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "orc-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
