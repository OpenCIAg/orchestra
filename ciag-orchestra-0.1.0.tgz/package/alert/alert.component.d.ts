import { AlertSeverity, AlertVariant } from './alert.types';
import * as i0 from "@angular/core";
export declare class AlertComponent {
    /** Status / Severidade do alerta */
    readonly severity: import("@angular/core").InputSignal<AlertSeverity>;
    /** Alias para severity */
    readonly status: import("@angular/core").InputSignal<AlertSeverity | undefined>;
    /** Variante visual: soft/subtle (fundo claro), filled (sólido) ou outline (apenas borda) */
    readonly variant: import("@angular/core").InputSignal<AlertVariant>;
    /** Título principal do alerta (opcional) */
    readonly title: import("@angular/core").InputSignal<string>;
    /** Texto descritivo (opcional se fornecido via ng-content) */
    readonly message: import("@angular/core").InputSignal<string>;
    /** Controla se o ícone do alerta deve ser exibido */
    readonly showIcon: import("@angular/core").InputSignal<boolean>;
    /** Define se o alerta pode ser dispensado pelo usuário exibindo o botão 'X' */
    readonly dismissible: import("@angular/core").InputSignal<boolean>;
    /** Sobrescreve o atributo role WCAG (padrão: 'alert' para error/warning e 'status' para info/success) */
    readonly role: import("@angular/core").InputSignal<string | undefined>;
    /** Rótulo acessível opcional para leitores de tela */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    /** Rótulo acessível do botão de fechar */
    readonly closeAriaLabel: import("@angular/core").InputSignal<string>;
    /** Emitido quando o usuário clica no botão de fechar */
    readonly onClose: import("@angular/core").OutputEmitterRef<MouseEvent>;
    /** Alias do evento de fechamento */
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly isVisible: import("@angular/core").WritableSignal<boolean>;
    /** Normaliza o tipo de severidade ativo */
    readonly activeSeverity: import("@angular/core").Signal<AlertSeverity>;
    /** Normaliza a variante */
    readonly activeVariant: import("@angular/core").Signal<"subtle" | "filled" | "outline">;
    /** Computa o atributo role WCAG ideal conforme o tipo de severidade */
    readonly computedRole: import("@angular/core").Signal<string>;
    /** Computa aria-live: 'assertive' para erros críticos e 'polite' para informativos */
    readonly computedAriaLive: import("@angular/core").Signal<"assertive" | "polite">;
    handleDismiss(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "orc-alert", never, { "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; }, { "onClose": "onClose"; "closed": "closed"; }, never, ["[alert-icon], [alertIcon]", "[alert-title], [alertTitle]", "*", "[alert-actions], [alertActions]"], true, never>;
}
