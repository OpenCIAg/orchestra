import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const ORC_ICON_CATALOG: Readonly<Record<string, OrcIconDefinition>>;
export declare const ORC_ICON_METADATA: readonly [{
    readonly name: "search";
    readonly rank: 1;
    readonly popularity: 862750;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["browse", "circle", "discover", "discover icon", "explore", "explore icon", "filter", "find", "find icon", "glass", "handle", "inspect", "investigate", "locate", "locate icon", "look", "magnifier", "magnify", "magnifying", "mode", "options", "query", "query icon", "scope", "search", "search bar", "search button", "see", "stick", "tool", "view", "zoom"];
}, {
    readonly name: "home";
    readonly rank: 2;
    readonly popularity: 797334;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["abode", "address", "app", "application--house", "architecture", "beginning", "building", "button", "components", "dashboard", "design", "domicile", "dwelling", "estate", "filled", "geometry", "home", "homepage", "house", "interface", "layout", "link", "lodging", "main", "menu", "navigation", "outline", "place", "property", "real", "real estate", "residence", "residential", "screen", "shape", "shelter", "site", "solid", "start", "startup", "stroke", "structure", "tab", "ui", "unit", "ux", "web", "website", "window"];
}, {
    readonly name: "account_circle";
    readonly rank: 3;
    readonly popularity: 644846;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "account circle", "account details", "account icon", "account management", "account settings", "avatar", "bust", "circle", "face", "filled account", "full account", "head", "human", "login", "my account", "people", "person", "person icon", "personal", "personal information", "personal mode", "profile", "profile icon", "shoulders", "sign in", "thumbnail", "user", "user icon", "user profile", "user settings"];
}, {
    readonly name: "settings";
    readonly rank: 4;
    readonly popularity: 610701;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjustments", "administration", "administration panel", "application", "change", "cog", "cogwheel", "configuration", "control", "control panel", "customization settings", "customize", "details", "fine tune", "gear", "gear wheel", "info", "information", "machinery", "manage", "management", "management tools", "mechanism", "modify", "options", "options button", "panel", "parameter", "personal", "preference settings", "preferences", "service", "settings", "setup", "system", "tools"];
}, {
    readonly name: "info";
    readonly rank: 5;
    readonly popularity: 466307;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["about", "alert", "announcement", "assistance", "circle", "content", "data", "details", "dialog", "dot", "guide", "help", "i", "important", "indicator", "info", "information", "knowledge", "learn", "letter i", "line", "message", "notice", "popup", "query", "question", "read", "round", "service", "support", "symbol", "tip"];
}, {
    readonly name: "close";
    readonly rank: 6;
    readonly popularity: 431617;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["abort", "action", "alert", "cancel", "cancel button", "clear", "close", "confirmation", "cross", "delete", "delete button", "dialog close", "dismiss", "error", "exit", "exit button", "interface control", "modal close", "multiply", "notification", "remove", "remove item", "stop", "times", "warning", "window close", "x", "x mark"];
}, {
    readonly name: "check_circle";
    readonly rank: 7;
    readonly popularity: 422017;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accept", "approval", "approve", "check", "checkmark", "circle", "complete", "completion", "confirm", "confirmation", "correct", "done", "filled", "finished", "indicator", "mark", "ok", "option", "outline", "passed", "select", "selection", "status", "success", "task", "tick", "true", "valid", "validate", "validation", "verified", "yes"];
}, {
    readonly name: "delete";
    readonly rank: 8;
    readonly popularity: 388102;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "basket", "bin", "can", "cancel", "clean up", "clear", "control", "delete", "delete content", "delete file", "destroy", "discard", "dispose", "dustbin", "edit", "eliminate", "empty", "erase", "garbage", "get rid of", "junk", "management", "obliterate", "outline", "recycle", "remove", "remove item", "trash", "waste"];
}, {
    readonly name: "person";
    readonly rank: 9;
    readonly popularity: 379595;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["account", "avatar", "avatar filled", "avatar outline", "body", "circle", "contact", "face", "figure", "filled", "head", "human", "identity", "individual", "login", "member", "my account", "my profile", "outline", "people", "perm identity", "person", "profile", "register", "shoulders", "silhouette", "user", "user account", "user identity", "user profile"];
}, {
    readonly name: "menu";
    readonly rank: 10;
    readonly popularity: 371902;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["action menu", "app", "app menu", "application", "application menu", "bars", "burger", "collapse", "components", "control", "drawer", "expand", "expandable menu", "hamburger", "horizontal lines", "interface", "kebab", "layers", "line", "lines", "list", "main menu", "menu", "more", "more options", "navigation", "navigation menu", "options", "screen", "settings", "side menu", "sidebar", "site", "stack", "stacked bars", "stripes", "three bars", "ui", "ux", "web", "website"];
}, {
    readonly name: "add";
    readonly rank: 11;
    readonly popularity: 352199;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["+", "add", "addition", "append", "arithmetic", "attach", "combine", "create", "cross", "expand", "grow", "increase", "insert", "join", "mathematical symbol", "merge", "more", "new", "plus", "positive", "sum", "symbol", "total", "two lines"];
}, {
    readonly name: "visibility";
    readonly rank: 12;
    readonly popularity: 330555;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["display", "eye", "glance", "hidden", "hidden text", "insight", "look", "observe", "on", "optic", "password visibility", "peek", "perspective", "private", "public", "reveal", "security", "see", "show", "sighted", "spy", "stare", "toggle visibility", "unhide", "view", "visibility", "visible", "visual", "watch"];
}, {
    readonly name: "shopping_cart";
    readonly rank: 13;
    readonly popularity: 320267;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["add", "add to cart", "basket", "bill", "buy", "buying", "card", "carriage", "cart", "cash", "checkout", "coin", "commerce", "credit", "currency", "dollars", "e-commerce", "general store", "goods", "grocery", "items", "local", "market", "merchandise", "money", "online", "online shopping", "pay", "payment", "products", "purchase", "retail", "retail store", "sale", "shop", "shopping", "shopping bag", "shopping cart", "store", "trolley"];
}, {
    readonly name: "edit";
    readonly rank: 14;
    readonly popularity: 314185;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["action", "alter", "author", "change", "compose", "control", "create", "document", "edit", "editing", "form", "glyph", "input", "mode", "mode_edit", "mode_edit_outline", "modify", "new", "outline", "pen", "pencil", "revise", "shape", "stroke", "text", "tool", "update", "write", "writing"];
}, {
    readonly name: "favorite";
    readonly rank: 15;
    readonly popularity: 284624;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["affection", "appreciate", "appreciation", "bookmark", "border", "button", "collection", "data", "empty", "engagement", "favorite", "feedback", "full", "heart", "icon", "interest", "item", "like", "love", "media", "object", "outline", "rating", "remember", "save", "shape", "social", "solid", "status", "symbol", "toggle", "wish list"];
}, {
    readonly name: "description";
    readonly rank: 16;
    readonly popularity: 268313;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["article", "content", "data", "description", "details", "doc", "document", "draft", "drive", "earmark", "file", "folded corner", "folder", "folders", "format", "info", "information", "lines", "list", "note", "notes", "office", "page", "paper", "read", "report", "sheet", "slide", "summary", "template", "text", "work", "write", "writing"];
}, {
    readonly name: "logout";
    readonly rank: 17;
    readonly popularity: 260231;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "app", "application", "arrow", "arrow pointing right", "arrow right", "authentication", "away", "components", "design", "door", "door icon", "exit", "exit symbol", "interface", "leave", "line", "log", "log out", "login", "logout", "off", "open door", "profile", "rectangle", "right", "screen", "security", "session", "sign out", "signing off", "site", "square", "system", "ui", "user", "ux", "web", "website"];
}, {
    readonly name: "arrow_back";
    readonly rank: 18;
    readonly popularity: 250315;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["DISABLE_IOS", "app", "application", "arrow", "back", "back button", "backward", "chevron", "components", "direction", "directional", "disable_ios", "escape", "exit", "go back", "history", "indicator", "interface", "last", "lead back", "left", "move", "navigation", "past", "pointer", "previous", "prior", "reply", "retreat", "return", "reverse", "revert", "screen", "site", "step back", "turn back", "ui", "undo", "ux", "way back", "web", "website"];
}, {
    readonly name: "chevron_right";
    readonly rank: 19;
    readonly popularity: 224653;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["advance", "angle", "arrow", "arrows", "bracket", "caret", "carousel", "chevron", "continue", "direction", "drilldown", "entry", "expand", "forward", "go", "greater than", "indicator", "item", "link", "list", "menu", "more", "move", "navigate", "next", "pagination", "pointer", "proceed", "right", "show", "slider"];
}, {
    readonly name: "lock";
    readonly rank: 20;
    readonly popularity: 224283;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "authentication", "authorization", "browser", "closed", "confidential", "connection", "data", "digital", "encryption", "https", "internet", "key", "lock", "locked", "network", "outline", "padlock", "password", "privacy", "private", "protected", "protection", "protocol", "restrict", "safe", "safeguard", "safety", "secure", "security", "ssl", "tls", "website"];
}, {
    readonly name: "local_shipping";
    readonly rank: 21;
    readonly popularity: 224124;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["automobile", "box", "business", "car", "cargo", "cars", "commerce", "delivery", "distribution", "drive", "freight", "goods", "letters", "local", "logistics", "lorry", "mail", "maps", "merchandise", "move", "office", "package", "parcel", "post", "postal", "road", "send", "shipping", "shopping", "stamp", "supply chain", "transport", "transportation", "travel", "truck", "van", "vehicle", "wheels"];
}, {
    readonly name: "location_on";
    readonly rank: 22;
    readonly popularity: 211794;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["address", "area", "current location", "destination", "direction", "drop", "find", "geography", "geotag", "gps", "landmark", "locate", "location", "map", "maps", "marker", "navigation", "nearby", "on", "pin", "place", "point of interest", "pointer", "position", "proximity", "region", "route", "site", "spot", "stop", "teardrop", "travel", "venue"];
}, {
    readonly name: "schedule";
    readonly rank: 23;
    readonly popularity: 208570;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alarm", "appointment", "calendar", "chronometer", "clock", "countdown", "date", "deadline", "delay", "duration", "event", "future", "history", "hour", "minute", "organize", "past", "pending", "period", "plan", "present", "recent", "reminder", "schedule", "second", "stopwatch", "time", "timer", "upcoming", "waiting", "watch"];
}, {
    readonly name: "notifications";
    readonly rank: 24;
    readonly popularity: 208525;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["active", "alarm", "alert", "announcement", "app", "bell", "chime", "communication", "control", "ding", "follow", "hear", "icon", "inbox", "listen", "mail", "message", "none", "notification", "notifications", "notify", "outline", "preferences", "reminder", "ring", "setting", "shape", "sound", "subscribe", "symbol", "system", "toggle", "unread", "update"];
}, {
    readonly name: "call";
    readonly rank: 25;
    readonly popularity: 192238;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["audio", "business", "call", "cell", "communication", "connect", "connection", "contact", "contact us", "customer service", "device", "dial", "directory", "emergency", "handset", "hardware", "help", "incoming", "local phone", "mobile", "office", "outgoing", "phone", "phone alt", "receiver", "ring", "speak", "support", "talk", "telecommunication", "telephone", "voice"];
}, {
    readonly name: "language";
    readonly rank: 26;
    readonly popularity: 190348;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["announcement", "bubble", "caption", "chat", "communicate", "communication", "dialogue", "discussion", "globe", "headline", "internet", "language", "language switcher", "menu", "multiple languages", "news", "options", "planet", "preferences", "settings", "speak", "speech", "talk", "talking", "text", "text balloon", "thought bubble", "translate", "translation", "typography", "website", "words", "world", "www"];
}, {
    readonly name: "cancel";
    readonly rank: 27;
    readonly popularity: 177824;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["abort", "action", "block", "button", "cancel", "circle", "clear", "close", "cross", "delete", "deny", "deselect", "discard", "dismiss", "error", "exit", "failure", "forbidden", "highlight off", "invalid", "negative", "quit", "reject", "remove", "revoke", "round", "stop", "turn off", "unselect", "x"];
}, {
    readonly name: "groups";
    readonly rank: 28;
    readonly popularity: 177480;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["audience", "avatars", "body", "club", "collaboration", "collective", "community", "connected", "crowd", "figures", "gathering", "graphic", "groups", "human", "icon", "joined", "many", "meeting", "members", "multiple", "network", "outline", "participants", "people", "person", "profiles", "shape", "silhouettes", "social", "solid", "symbol", "team", "teams", "together", "ui", "users"];
}, {
    readonly name: "arrow_forward_ios";
    readonly rank: 29;
    readonly popularity: 177448;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["advance", "angle", "app", "application", "arrow", "caret", "chevron", "components", "detail", "direction", "expand", "forward", "go", "greater than", "indicator", "interface", "ios", "link", "list", "menu", "mobile", "more", "move", "navigate", "navigation", "next", "page", "pointer", "proceed", "right", "right-facing", "screen", "scroll", "site", "step", "triangle", "ui", "ux", "web", "website"];
}, {
    readonly name: "arrow_back_ios";
    readonly rank: 30;
    readonly popularity: 176044;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["DISABLE_IOS", "app", "application", "arrow", "back", "back arrow", "backward", "breadcrumb", "caret", "chevron", "components", "control", "direction", "directional", "disable_ios", "earlier", "go back", "history", "interface", "ios", "left", "mobile", "navigate", "navigation", "page", "point left", "pointer", "precede", "previous", "return", "reverse", "rewind", "screen", "site", "step back", "ui", "undo", "ux", "web", "website"];
}, {
    readonly name: "arrow_drop_down";
    readonly rank: 31;
    readonly popularity: 165034;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["app", "application", "arrow", "carat", "caret", "chevron", "collapse", "components", "control", "direction", "down", "drop", "dropdown", "expand", "expand/collapse", "expander", "filter", "indicator", "interface", "list", "menu", "more", "navigation", "options", "pointer", "pointy", "screen", "select", "selector", "simple", "site", "small", "sort", "triangle", "triangle down", "ui", "ux", "web", "website"];
}, {
    readonly name: "verified";
    readonly rank: 32;
    readonly popularity: 162772;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accepted", "accreditation", "approval", "approval icon", "approve", "authentic", "authorized", "badge", "burst", "certified", "check", "checkmark", "checkmark in circle", "complete", "completed", "confirmation", "confirmed", "credentials", "done", "green checkmark", "identity", "legitimacy", "mark", "official", "ok", "registered", "select", "stamp of approval", "star", "success", "tick", "trusted", "valid", "validate", "verified", "verified account", "verified user", "yes"];
}, {
    readonly name: "face";
    readonly rank: 33;
    readonly popularity: 161383;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "authentication", "authorized", "biometric", "biometric scan", "emoji", "eyes", "face", "faceid", "head", "human", "identification", "identity", "lock", "log", "login", "logout", "passcode", "people", "person", "personal", "portrait", "private", "profile", "protected", "recognition", "safe", "scan", "secure", "security", "social", "thumbnail", "unlock", "user", "verify"];
}, {
    readonly name: "manage_accounts";
    readonly rank: 34;
    readonly popularity: 160558;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "accounts", "administration", "avatar", "bust", "change", "circle", "control", "customization", "data", "details", "editing", "face", "figure", "gear", "group", "human", "identity", "individual", "information", "manage", "members", "options", "people", "permissions", "person", "preferences", "profile", "security", "service", "settings", "team", "user", "users"];
}, {
    readonly name: "play_arrow";
    readonly rank: 35;
    readonly popularity: 158867;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["app", "application", "arrow", "audio", "back", "begin", "button", "cinema", "components", "control", "controls", "direction", "entertainment", "episode", "forward", "icon", "interface", "media", "movie", "music", "navigation", "play", "playback", "player", "resume", "right", "screen", "show", "site", "sound", "start", "stream", "triangle", "ui", "ux", "video", "web", "website"];
}, {
    readonly name: "more_vert";
    readonly rank: 36;
    readonly popularity: 151441;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["3", "DISABLE_IOS", "actions", "additional options", "android", "app", "application", "components", "context menu", "controls", "detail menu", "disable_ios", "dots", "dropdown menu", "ellipsis", "etc", "expand menu", "expanded menu", "extra options", "hidden options", "interface", "list menu", "list options", "menu", "more", "more actions", "more options", "options menu", "overflow", "overflow menu", "pop-up menu", "screen", "settings", "site", "submenu", "tertiary actions", "three", "ui", "ux", "vert", "vertical", "vertical dots", "web", "website"];
}, {
    readonly name: "thumb_up";
    readonly rank: 37;
    readonly popularity: 150800;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["acknowledgement", "agree", "approve", "button", "choice", "confirmation", "content interaction", "control", "endorsement", "excellent", "favorite", "feedback", "fingers", "gesture", "good", "hand", "hand gesture", "hand sign", "hands", "indicator", "like", "option", "positive", "preference", "rank", "ranking", "rate", "rating", "reaction", "recommend", "selection", "share", "social media", "thumb", "thumbs up", "up", "vote", "yes"];
}, {
    readonly name: "filter_alt";
    readonly rank: 38;
    readonly popularity: 148078;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "arrange", "choose", "control", "customize", "data", "edit", "filter", "find", "funnel", "icon", "information", "inverted triangle", "line", "list", "narrow", "options", "organize", "preferences", "refine", "refinement", "search", "select", "settings", "sift", "sort", "sorting", "three lines", "tool", "triangle"];
}, {
    readonly name: "dashboard";
    readonly rank: 39;
    readonly popularity: 144202;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["add", "administration", "analytics", "cards", "chart", "circle", "control", "dashboard", "data", "dial", "display", "format", "gauge", "graph", "grid", "indicator", "layout", "management", "measurement", "meter", "metrics", "monitor", "needle", "overview", "panel", "performance", "plus", "pointer", "progress", "rectangle", "report", "round", "shapes", "speed", "speedometer", "square", "statistics", "summary", "tachometer", "view", "web", "website"];
}, {
    readonly name: "star";
    readonly rank: 40;
    readonly popularity: 144053;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["add to favorite", "best", "bookmark", "border", "empty", "empty star", "favorite", "five pointed star", "five points", "grade", "highlight", "hollow", "hollow star", "important", "mark", "news", "not filled", "outline", "point", "ranking", "rate", "rating", "rating symbol", "save", "shape", "star", "symbol", "toggle", "ui action", "ui element", "unselected"];
}, {
    readonly name: "event";
    readonly rank: 41;
    readonly popularity: 143717;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["add", "add event", "add invitation", "add to calendar", "agenda", "appointment", "booking", "calendar", "daily", "date", "day", "event", "insert invitation", "invitation", "invite", "mark", "meeting", "month", "monthly", "new event", "new invitation", "organizing", "planning", "plus", "range", "remember", "reminder", "reservation", "schedule", "schedule event", "square", "time", "today", "week", "weekly"];
}, {
    readonly name: "fingerprint";
    readonly rank: 42;
    readonly popularity: 142097;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "authentication", "authorized", "biometric", "circles", "confirm", "curves", "data", "digit", "digital", "finger", "fingerprint", "human", "id", "identification", "identity", "lines", "log in", "oval", "personal", "print", "privacy", "reader", "scan", "security", "sign in", "swirls", "technology", "thumbprint", "touch id", "unique", "unlock", "verification", "verify"];
}, {
    readonly name: "list";
    readonly rank: 43;
    readonly popularity: 141986;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "bullet points", "bulleted list", "catalog", "checklist", "content list", "directory", "enumeration", "expandable menu", "file", "format", "hamburger", "index", "itemize", "items", "list", "menu", "navigation menu", "options", "order", "organized list", "sequence", "stacked lines", "steps", "table of contents", "task list", "three lines", "to-do list", "vertical lines"];
}, {
    readonly name: "content_copy";
    readonly rank: 44;
    readonly popularity: 140818;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "clipboard", "clone", "content", "copy", "copy content", "create", "cut", "data", "doc", "document", "duplicate", "edit", "entry", "file", "information", "make copy", "menu", "multiple", "new", "object", "option", "overlapping", "pages", "paper", "paste", "record", "rectangle", "replicate", "sheet", "square", "stack", "text", "toolbar"];
}, {
    readonly name: "visibility_off";
    readonly rank: 45;
    readonly popularity: 134668;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["conceal", "crossed out eye", "diagonal line", "disabled", "disabled view", "enabled", "eye", "form", "hidden", "hide", "input", "invisible", "line through", "masked", "not visible", "obscured", "off", "on", "password", "password field", "privacy", "private", "reveal", "secret", "security", "see", "show", "show/hide", "slash", "surveillance", "toggle", "toggle button", "unviewable", "unwatch", "view", "visibility", "watch"];
}, {
    readonly name: "add_circle";
    readonly rank: 46;
    readonly popularity: 134476;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["+", "action", "add", "append", "button", "circle", "circular", "content", "control", "counter", "create", "data", "document", "element", "entry", "file", "form", "generate", "increase", "insert", "item", "list", "make", "new", "option", "outline", "plus", "point", "record", "round", "row", "tool"];
}, {
    readonly name: "login";
    readonly rank: 47;
    readonly popularity: 132588;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "app", "application", "arrow", "authentication", "authorization", "avatar", "circle", "components", "design", "enter", "entrance", "entry", "head", "human", "id", "identity", "in", "interface", "left", "log", "login", "member", "outline", "person", "personal", "privacy", "profile", "registration", "screen", "secure", "sign", "sign in", "sign on", "silhouette", "site", "ui", "user", "ux", "web", "website"];
}, {
    readonly name: "arrow_forward";
    readonly rank: 48;
    readonly popularity: 131487;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["advance", "app", "application", "arrow", "arrows", "button", "components", "continue", "control", "direction", "entry", "expand", "forward", "go", "graphic", "indicator", "interface", "link", "media", "more", "move", "navigate", "navigation", "next", "open", "play", "pointer", "proceed", "progress", "progression", "right", "rightward", "screen", "simple", "site", "submit", "ui", "ux", "web", "website"];
}, {
    readonly name: "send";
    readonly rank: 49;
    readonly popularity: 131214;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "airplane", "arrow", "chat", "communication", "complete", "data", "deliver", "direct message", "dispatch", "document", "email", "flight", "form", "forward", "give", "mail", "message", "outgoing", "paper", "paper plane", "plane", "point", "post", "publish", "reply", "right", "send", "share", "submit", "transfer", "transmit", "upload"];
}, {
    readonly name: "warning";
    readonly rank: 50;
    readonly popularity: 130498;
    readonly categories: readonly ["alert"];
    readonly tags: readonly ["!", "alert", "app", "attention", "caution", "danger", "error", "exclamation", "flag", "hazard", "important", "interface", "issue", "mark", "message", "notification", "problem", "risk", "security", "shield", "sign", "signal", "status", "symbol", "system", "triangle", "ui", "urgent", "ux", "warning", "website"];
}, {
    readonly name: "check_box";
    readonly rank: 51;
    readonly popularity: 129431;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["activate", "agree", "approved", "binary", "box", "button", "check", "check box", "checkbox", "checked", "choice", "complete", "component", "confirm", "consent", "control", "done", "enable", "false", "field", "form", "input", "list", "mark", "marked", "ok", "option", "select", "selected", "selection", "square", "task", "tick", "toggle", "true", "ui", "yes"];
}, {
    readonly name: "chevron_left";
    readonly rank: 52;
    readonly popularity: 129329;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["DISABLE_IOS", "angle", "arrow", "arrows", "back", "backward", "before", "caret", "carousel", "chevron", "direction", "directional", "disable_ios", "go back", "history", "indicator", "left", "less than", "media control", "move left", "navigate", "navigation", "page", "pagination", "pointer", "previous", "prior", "retreat", "return", "rewind", "scroll", "slider", "step back"];
}, {
    readonly name: "calendar_today";
    readonly rank: 53;
    readonly popularity: 128774;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "appointment", "booking", "calendar", "calendaricon", "calendartoday", "daily", "date", "dating", "day", "diary", "event", "grid", "lines", "month", "monthly", "organizer", "plan", "planning", "punctual", "rectangle", "reminder", "schedule", "square", "time", "today", "todaycalendar", "week", "year", "yearly"];
}, {
    readonly name: "share";
    readonly rank: 54;
    readonly popularity: 126674;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["DISABLE_IOS", "activity", "andriod share", "android", "arrow", "communication", "communication icon", "connect", "connection", "contect", "data", "disable_ios", "distribute", "export", "forward", "geometric", "line", "lines", "link", "media", "multimedia", "multiple", "network", "options", "outreach", "point", "pointing", "send", "send to", "send to friends", "send to others", "send to social", "share", "shared", "sharing", "social", "three dots", "up arrow"];
}, {
    readonly name: "help";
    readonly rank: 55;
    readonly popularity: 119629;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["?", "about", "answer", "assistance", "button", "circle", "circular", "documentation", "element", "faq", "guide", "guide me", "help", "icon", "info", "information", "instructions", "knowledge", "line", "link", "manual", "outline", "punctuation", "query", "question", "question mark", "recent", "restore", "shape", "stroke", "support", "symbol", "tutorial", "ui", "user manual", "what is"];
}, {
    readonly name: "paid";
    readonly rank: 56;
    readonly popularity: 116179;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["amount", "balance", "banknote", "bill", "business", "buy", "card", "cash", "circle", "coin", "commerce", "cost", "credit", "currency", "debt", "dollar", "dollars", "e-commerce", "economic", "expense", "finance", "income", "monetization", "money", "on", "online", "paid", "pay", "payment", "price", "purchase", "savings", "shopping", "symbol", "transaction", "value", "wealth"];
}, {
    readonly name: "task_alt";
    readonly rank: 57;
    readonly popularity: 115007;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["approval", "approve", "check", "checklist", "checkmark", "circle", "complete", "completed", "correct", "done", "finish", "mark", "ok", "ring", "select", "selected", "status", "success", "task", "tick", "todo", "valid", "validate", "validation", "verification", "verified", "verify", "yes"];
}, {
    readonly name: "check";
    readonly rank: 58;
    readonly popularity: 111479;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["!", "DISABLE_IOS", "acceptance", "achievement", "alert", "apply", "approve", "attention", "caution", "check", "checkmark", "complete", "completion", "confirm", "confirmation", "correct", "danger", "disable_ios", "done", "enter", "error", "exclamation", "final", "finished", "good", "input", "mark", "notification", "ok", "okay", "option", "right", "select", "selection", "submit", "success", "task", "tick", "validated", "verified", "verify", "yes"];
}, {
    readonly name: "error";
    readonly rank: 59;
    readonly popularity: 111288;
    readonly categories: readonly ["alert"];
    readonly tags: readonly ["!", "alert", "attention", "bug", "caution", "circle", "critical", "danger", "error", "exception", "exclamation", "failure", "important", "information", "invalid", "issue", "mark", "message", "mistake", "notification", "outline", "problem", "round", "security", "status", "stop", "symbol", "system", "trouble", "validation", "warning", "wrong"];
}, {
    readonly name: "article";
    readonly rank: 60;
    readonly popularity: 108536;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["article", "blog", "content", "description", "doc", "document", "documentation", "editorial", "feed", "file", "horizontal lines", "information", "layout", "lines", "news", "newsletter", "note", "page", "paper", "post", "publishing", "read", "report", "rounded square", "sheet", "square", "summary", "text", "writing"];
}, {
    readonly name: "date_range";
    readonly rank: 61;
    readonly popularity: 107628;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "appointment", "booking", "calendar", "calendar grid", "calendar picker", "calendar view", "choose date", "date", "date selection", "day", "deadline", "event", "lines", "month", "period", "planner", "range", "rectangle", "remember", "reminder", "reservation", "schedule", "select date", "square", "time", "timeline", "today", "week", "year"];
}, {
    readonly name: "open_in_new";
    readonly rank: 62;
    readonly popularity: 105562;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "action", "app", "application", "arrow", "box", "button", "components", "depart", "destination", "exit", "expand", "external", "follow", "forward", "go", "in", "interface", "launch", "link", "navigate", "new", "open", "out", "page", "pop out", "portal", "redirect", "reference", "right", "screen", "share", "site", "square", "tab", "ui", "up", "url", "ux", "web", "website", "window"];
}, {
    readonly name: "check_box_outline_blank";
    readonly rank: 63;
    readonly popularity: 104454;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["blank", "boundary", "box", "button", "check", "checkbox", "choice", "component", "control", "dash", "dashed", "data entry", "deselect", "deselected", "empty", "field", "form", "frame", "inactive", "input", "list", "mark", "option", "outline", "pending", "preference", "rectangle", "select", "selection", "setting", "square", "task", "tick", "todo", "toggle", "ui", "unchecked", "unselected", "widget"];
}, {
    readonly name: "photo_camera";
    readonly rank: 64;
    readonly popularity: 104238;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["analog", "button", "camera", "capture", "circle", "device", "digital", "film", "icon", "image", "input", "lens", "media", "movie", "multimedia", "multimedia input", "photo", "photograph", "photography", "picture", "record", "shoot", "shutter", "square", "symbol", "technology", "video", "videography", "visual"];
}, {
    readonly name: "more_horiz";
    readonly rank: 65;
    readonly popularity: 103846;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["3", "DISABLE_IOS", "actions", "additional", "app", "application", "bar menu", "button", "choices", "components", "content menu", "context menu", "control", "disable_ios", "dots", "dropdown", "edit", "ellipsis", "etc", "expand", "further", "horiz", "horizontal", "indicator", "interface", "ios", "kebab menu", "manage", "menu", "more", "options", "overflow", "preference", "reveal", "screen", "see more", "selection", "settings", "show more", "site", "three", "three dots", "tool", "ui", "ux", "web", "website"];
}, {
    readonly name: "image";
    readonly rank: 66;
    readonly popularity: 101037;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["add", "adjust", "album", "asset", "camera", "collection", "crop", "display", "edit", "editor", "file", "frame", "gallery", "graphic", "image", "import", "insert", "landscape", "library", "media", "mountain", "mountains", "original", "photo", "photography", "picture", "rectangle", "restore", "square", "upload", "view", "visual"];
}, {
    readonly name: "school";
    readonly rank: 67;
    readonly popularity: 100635;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["academic", "academics", "academy", "achievement", "architecture", "building", "building facade", "campus", "cap", "class", "college", "college building", "columns", "doorway", "education", "educational institution", "entrance", "entrance way", "gateway", "graduation", "hat", "institution", "knowledge", "learning", "learning institution", "pillars", "portal", "public building", "school", "steps", "structure", "student", "studying", "teaching", "university", "university building"];
}, {
    readonly name: "refresh";
    readonly rank: 68;
    readonly popularity: 99691;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["application", "around", "arrow", "arrows", "browser", "circular", "content", "current", "curved", "cycle", "data", "direction", "feed", "inprogress", "latest", "load", "loading", "loading refresh", "loop", "navigation", "page", "process", "redo", "refresh", "reload", "renew", "repeat", "reprocess", "reset", "restart", "revert", "right", "rotate", "round", "spin", "sync", "synchronize", "turn", "update"];
}, {
    readonly name: "support_agent";
    readonly rank: 69;
    readonly popularity: 99198;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["advisor", "agent", "answer", "assistance", "avatar", "bubble", "call", "care", "chat", "communication", "consultant", "contact", "conversation", "customer", "customer service", "dialog", "dialogue", "face", "head", "headphone", "headset", "help", "online", "operator", "person", "profile", "question", "representative", "service", "speech bubble", "support", "talk", "tech support"];
}, {
    readonly name: "shopping_bag";
    readonly rank: 70;
    readonly popularity: 99103;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["acquire", "bag", "basket", "bill", "business", "buy", "card", "carry bag", "cart", "cash", "checkout", "coin", "commerce", "container", "credit", "currency", "dollars", "e-commerce", "goods", "handle", "handle bag", "hold", "items", "line", "merchandise", "money", "online", "order", "outline", "pay", "payment", "product", "purchase", "rectangle", "retail", "shop", "shopping", "shopping bag", "square", "store", "storefront", "stroke", "transaction", "transport"];
}, {
    readonly name: "lightbulb";
    readonly rank: 71;
    readonly popularity: 98416;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alert", "announcement", "bright", "bulb", "concept", "creativity", "disabled", "education", "empty", "glow", "hint", "idea", "inactive", "incandescent", "info", "information", "innovation", "inspiration", "invention", "knowledge", "learning", "led", "light", "lightbulb", "not lit", "outline", "smart", "solution", "suggestion", "thinking", "thought", "tip", "turned off", "unlit"];
}, {
    readonly name: "credit_card";
    readonly rank: 72;
    readonly popularity: 96022;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "account information", "amex", "balance", "bank", "banking", "bill", "buy", "card", "cash", "checkout", "chip", "coin", "commerce", "cost", "credit", "credit card", "currency", "discover", "dollars", "e-commerce", "finance", "financial", "funding", "mastercard", "money", "online", "pay", "payment", "plastic", "price", "purchase", "rectangle", "secure", "shopping", "spend", "stripe", "symbol", "transaction", "visa", "wallet"];
}, {
    readonly name: "history";
    readonly rank: 73;
    readonly popularity: 95914;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["activity", "arrow", "back", "backup", "backwards", "circular", "clear", "clock", "cycle", "data", "date", "defaults", "device", "factory", "history", "home", "initialize", "log", "nest", "previous", "reboot", "recover", "refresh", "renew", "repair", "reset", "restart", "restore", "retrieve", "reverse", "revert", "rollback", "rotate", "save", "schedule", "settings", "system", "time", "timeline", "turn", "undo", "update"];
}, {
    readonly name: "trending_up";
    readonly rank: 74;
    readonly popularity: 93274;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["analysis", "analytics", "arrow", "ascending", "business", "chart", "data", "diagram", "direction", "finance", "gain", "graph", "growth", "improve", "increase", "infographic", "line graph", "measure", "metric", "metrics", "movement", "performance", "positive", "progress", "rate", "rating", "report", "rising", "statistics", "status", "tracking", "trend", "trending", "trending up", "up"];
}, {
    readonly name: "account_balance";
    readonly rank: 75;
    readonly popularity: 92691;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "accounting", "balance", "bank", "banking", "bill", "building", "business", "card", "cash", "coin", "columns", "commerce", "courthouse", "credit", "currency", "dollars", "economic", "federal", "finance", "financial", "financial institution", "government", "institution", "investment", "loan", "money", "mortgage", "online", "pay", "payment", "pillars", "prosperity", "savings", "structure", "transaction", "treasury", "wealth"];
}, {
    readonly name: "attach_money";
    readonly rank: 76;
    readonly popularity: 91105;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["add money", "amount", "attach", "banking", "bill", "business", "buy", "card", "cash", "circle", "coin", "commerce", "connect", "cost", "credit", "currency", "dollar sign", "dollars", "economy", "exchange", "finance", "financial", "funds", "income", "investment", "link", "monetization", "money", "on", "online", "pay", "payment", "price", "profit", "purchase", "revenue", "sell", "shopping", "symbol", "transaction", "value", "wealth"];
}, {
    readonly name: "person_add";
    readonly rank: 77;
    readonly popularity: 90243;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["+", "account", "account outline", "add", "add contact", "add friend", "add person", "add user", "avatar", "contact", "contact outline", "create", "face", "friend", "friend request", "head and shoulders", "human", "invite", "invite friend", "invite user", "man", "new", "new person", "new user", "people", "person", "person outline", "plus", "plus sign", "profile", "profile outline", "symbol", "user", "user outline"];
}, {
    readonly name: "save";
    readonly rank: 78;
    readonly popularity: 89442;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "backup", "button", "computer", "control", "data", "disk", "document", "drive", "file", "flat", "floppy", "function", "memory", "multimedia", "object", "old technology", "progress", "recording", "retro", "save", "save button", "save icon", "shape", "solid", "storage", "store", "tool", "vintage"];
}, {
    readonly name: "public";
    readonly rank: 79;
    readonly popularity: 88890;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["access", "accessibility", "circle", "community", "connection", "country", "earth", "everybody", "geography", "global", "globe", "international", "internet", "location", "map", "network", "open", "planet", "public", "round", "share", "social", "space", "sphere", "unlocked", "visible", "web", "world", "worldwide"];
}, {
    readonly name: "verified_user";
    readonly rank: 80;
    readonly popularity: 87879;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["approve", "badge", "certified", "check", "complete", "confirmation", "data", "done", "endorsed", "excellent", "exemption", "good", "gpp", "guard", "mark", "ok", "pass", "positive", "privacy", "private", "protect", "protected", "protection", "quality", "safety", "security", "select", "shield", "success", "tick", "trust", "user", "valid", "validate", "validation", "verification", "verified", "yes"];
}, {
    readonly name: "assignment";
    readonly rank: 81;
    readonly popularity: 87090;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "assignment", "checklist", "class", "clipboard", "course", "deliverable", "doc", "document", "duty", "education", "file", "form", "homework", "learning", "list", "manage", "memo", "note", "organize", "page", "paper", "plan", "project", "report", "school", "sheet", "submission", "task", "text", "to do", "work", "writing"];
}, {
    readonly name: "mail";
    readonly rank: 82;
    readonly popularity: 86902;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["communication", "communication icon", "contact", "contact icon", "correspondence", "diagonal lines", "digital", "electronic mail", "email", "empty", "envelop", "envelope", "fold", "icon", "inbox", "inbox icon", "internet", "letter", "letters", "mail", "message", "message icon", "new message", "online", "outline", "paper", "receive", "rectangle", "send", "symbol", "thin line", "unread"];
}, {
    readonly name: "radio_button_unchecked";
    readonly rank: 83;
    readonly popularity: 86665;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["blank radio button", "bullet", "button", "choice", "choose", "circle", "control", "deselect", "deselected", "empty radio button", "form", "input", "multiple choice", "off", "on", "option", "outlined circle", "point", "preferences", "radio", "radio button", "record", "ring", "select", "selection", "settings", "survey", "switch", "toggle", "ui control", "unchecked", "unselected"];
}, {
    readonly name: "fact_check";
    readonly rank: 84;
    readonly popularity: 86513;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accuracy", "accurate", "approval", "approve", "audit", "authentic", "authenticity", "certification", "certify", "check", "complete", "confirm", "confirmation", "correct", "correctness", "data", "document", "done", "evidence", "fact", "fact check", "information", "list", "mark", "ok", "quality", "reliability", "reliable", "review", "select", "tick", "true", "truth", "validate", "validation", "verification", "verified", "verify", "yes"];
}, {
    readonly name: "link";
    readonly rank: 85;
    readonly popularity: 84085;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["anchor", "arrow", "attach", "attachment", "chain", "circle", "circular", "clip", "connect", "connection", "direction", "external", "global", "globe", "hyperlink", "international", "internet", "join", "line", "link", "linked", "links", "multimedia", "navigation", "network", "point", "reference", "round", "sphere", "url", "web", "website", "world", "www"];
}, {
    readonly name: "star_rate";
    readonly rank: 86;
    readonly popularity: 81437;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "assessment", "award", "bookmark", "celestial", "evaluation", "excellence", "favorite", "feedback", "five points", "geometry", "highlight", "important", "mark", "marked", "pointed", "positive", "preference", "quality", "ranking", "rate", "rating", "rating rank", "review", "reward", "save", "saved", "selection", "shape", "special", "star"];
}, {
    readonly name: "download";
    readonly rank: 87;
    readonly popularity: 80563;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["acquire", "action", "app", "application", "archive", "arrow", "bar", "button", "cloud", "computer", "control", "data", "document", "down", "download", "downloads", "drive", "file", "get", "incoming", "install", "internet", "line", "move", "network", "obtain", "pointed", "receive", "save", "storage", "symbol", "transfer", "underscore", "upload"];
}, {
    readonly name: "calendar_month";
    readonly rank: 88;
    readonly popularity: 80238;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "appointment", "button", "calendar", "clock", "date", "day", "duration", "element", "event", "icon", "interface", "lines", "month", "navigation", "organise", "period", "plan", "record", "rectangle", "schedule", "square", "symbol", "time", "today", "widget"];
}, {
    readonly name: "remove";
    readonly rank: 89;
    readonly popularity: 79335;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["bar", "basic", "can", "cancel", "clean", "clear", "close", "cut", "delete", "detach", "dissociate", "division", "eliminate", "erase", "essential", "exclude", "exit", "garbage", "horizontal line", "line", "minimal", "minus", "negative", "remove", "segment", "sever", "simple", "substract", "subtract", "trash", "unlink"];
}, {
    readonly name: "apps";
    readonly rank: 90;
    readonly popularity: 76019;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["3x3 grid", "access", "all", "all apps", "application", "applications", "apps", "circles", "collection", "components", "dashboard", "desktop", "display", "dots", "features", "functions", "general", "grid", "home", "icons", "interface", "launcher", "launchpad", "menu", "mobile", "navigation", "nine squares", "options", "programs", "quick access", "services", "settings", "shortcut", "software", "squares", "system", "tiles", "ui", "ux"];
}, {
    readonly name: "chat";
    readonly rank: 91;
    readonly popularity: 75765;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["alert", "bubble", "chat", "comment", "communicate", "communication", "connect", "contact", "conversation", "dialogue", "discussion", "feedback", "help", "im", "inbox", "instant message", "message", "messaging", "messenger", "new", "notification", "receive", "send", "sms", "social", "speak", "speech", "support", "talk", "text"];
}, {
    readonly name: "arrow_right_alt";
    readonly rank: 92;
    readonly popularity: 75758;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "alt", "arrow", "arrow symbol", "arrows", "button", "carat", "caret", "chevron", "continue", "details", "direction", "east", "enter", "expand", "follow", "forward", "geometry", "go", "hyperlink", "indicator", "learn more", "line", "link", "move", "navigation", "next", "pointer", "pointing", "proceed", "read more", "right", "straight", "symbol"];
}, {
    readonly name: "filter_list";
    readonly rank: 93;
    readonly popularity: 75451;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["arrange", "bar", "bar graph", "bars", "categorize", "control", "criteria", "filter", "filtering", "horizontal", "lines", "list", "manage", "menu", "narrow", "options", "options menu", "organize", "preferences", "preferences menu", "refine", "settings", "settings menu", "sort", "sorting", "stacked", "three bars", "three lines"];
}, {
    readonly name: "menu_book";
    readonly rank: 94;
    readonly popularity: 75321;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["book", "catalog", "dictionary", "dining", "directory", "documentation", "education", "food", "glossary", "guide", "help", "information", "journal", "knowledge", "learn", "library", "list", "literature", "manual", "meal", "menu", "notebook", "novel", "pages", "reading", "recipe", "reference", "research", "restaurant", "school", "story", "study", "textbook", "wisdom"];
}, {
    readonly name: "folder";
    readonly rank: 95;
    readonly popularity: 75187;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["administration", "archive", "browse", "business", "category", "collection", "computer", "container", "data", "directory", "doc", "document", "drive", "explore", "file", "file system", "folder", "folders", "group", "hierarchy", "manage", "office", "open", "organize", "portfolio", "project", "record", "save", "sheet", "slide", "storage", "structure", "system", "tab", "work"];
}, {
    readonly name: "payments";
    readonly rank: 96;
    readonly popularity: 74805;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["bank", "banking", "bill", "bills", "buy", "card", "cash", "coin", "commerce", "cost", "credit", "credit card", "currency", "debit card", "dollar", "dollars", "expense", "finance", "financial", "income", "layer", "money", "multiple", "online", "pay", "payment", "payments", "price", "purchase", "rectangle", "shop", "shopping", "store", "symbol", "transaction", "wallet"];
}, {
    readonly name: "autorenew";
    readonly rank: 97;
    readonly popularity: 74050;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "around", "arrow", "arrows", "autorenew", "cache", "cached", "circle", "circular", "circular arrow", "content", "continuous", "curved arrow", "cycle", "data", "direction", "endless", "inprogress", "load", "loading refresh", "loop", "media", "navigation", "playback", "process", "redo", "refresh", "refresh data", "refresh page", "reload", "renew", "repeat", "repeat playlist", "repeat song", "restart", "rotate", "synchronize", "turn", "update"];
}, {
    readonly name: "account_balance_wallet";
    readonly rank: 98;
    readonly popularity: 73872;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "assets", "balance", "bank", "banking", "bill", "budget", "card", "cash", "coin", "commerce", "credit", "credit card", "currency", "dollar", "dollars", "economics", "economy", "expense", "finance", "finances", "financial", "funds", "income", "investment", "money", "online", "pay", "payment", "purse", "rectangle", "revenue", "savings", "square", "transaction", "wallet", "wealth"];
}, {
    readonly name: "build";
    readonly rank: 99;
    readonly popularity: 73739;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "adjustment", "build", "building", "configuration", "construction", "control", "engineering", "equipment", "fix", "fixing", "gear", "general", "hardware", "home", "industrial", "instrument", "machinery", "maintenance", "mechanical", "nest", "options", "repair", "service", "settings", "spanner", "tool", "toolkit", "tools", "utility", "work", "wrench"];
}, {
    readonly name: "keyboard_arrow_down";
    readonly rank: 100;
    readonly popularity: 73425;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["access", "arrow", "arrows", "bottom", "caret", "chevron", "collapse", "control", "direction", "down", "dropdown", "expand", "filter", "hide", "indicator", "keyboard", "menu", "more", "navigation", "next", "page", "point", "pointer", "reveal", "scroll", "select", "selector", "show", "sort", "triangle", "unfold", "v-shape"];
}, {
    readonly name: "view_list";
    readonly rank: 101;
    readonly popularity: 71914;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrangement", "bulleted", "catalog", "compact", "content", "data", "design", "directory", "display", "document", "filter", "format", "grid", "index", "information", "inventory", "items", "layout", "lines", "list", "menu", "navigation", "numbered", "options", "order", "organization", "presentation", "rows", "sequence", "sort", "stacked", "structure", "view", "website"];
}, {
    readonly name: "tune";
    readonly rank: 102;
    readonly popularity: 70540;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["adjust", "adjustments", "audio", "balance", "bars", "bass", "configure", "control", "controls", "custom", "customize", "edit", "editing", "equalizer", "filter", "filters", "instant", "levels", "lines", "mix", "modify", "music", "options", "preferences", "setting", "settings", "setup", "slider", "sliders", "sound", "switches", "three lines", "tone", "treble", "tune", "volume"];
}, {
    readonly name: "print";
    readonly rank: 103;
    readonly popularity: 70458;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["copier", "copy", "device", "document", "draft", "fax", "hardware", "ink", "local", "machine", "office", "output", "paper", "press", "print", "printer", "printing", "printing press", "printshop", "publication", "publish", "scanner", "send"];
}, {
    readonly name: "work";
    readonly rank: 104;
    readonly popularity: 70415;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "bag", "baggage", "briefcase", "business", "career", "case", "commerce", "corporate", "deal", "document", "duty", "economy", "employee", "employer", "employment", "executive", "financial", "folder", "job", "manager", "occupation", "office", "portfolio", "professional", "projects", "responsibility", "success", "suitcase", "tasks", "transaction", "work"];
}, {
    readonly name: "store";
    readonly rank: 105;
    readonly popularity: 70382;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["address", "aisle", "bill", "building", "business", "buying", "card", "cash", "coin", "commerce", "commercial", "company", "credit", "currency", "destination", "directory", "dollars", "establishment", "goods", "location", "mall", "map", "marker", "market", "marketplace", "merchandise", "money", "navigation", "online", "pay", "payment", "pin", "place", "pointer", "retail", "retail building", "selling", "shop", "shop building", "shopping", "store", "storefront"];
}, {
    readonly name: "analytics";
    readonly rank: 106;
    readonly popularity: 69954;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["analysis", "analytics", "assessment", "bar", "bar chart", "bars", "business", "chart", "dashboard", "data", "diagram", "economic", "finance", "graph", "growth", "infographic", "information", "insights", "intelligence", "measure", "measurement", "metrics", "performance", "progress", "rectangular bars", "report", "results", "sales", "statistics", "survey", "tracking", "trends", "vertical bars", "visualization"];
}, {
    readonly name: "delete_forever";
    readonly rank: 107;
    readonly popularity: 69927;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "archive", "bin", "button", "can", "cancel", "clean", "clear", "clear all", "control", "delete", "delete forever", "destroy", "discard", "dispose", "eliminate", "erase", "exit", "forever", "garbage", "get rid of", "glyph", "icon", "interface", "management", "obliterate", "purge", "remove", "storage", "sweep", "symbol", "trash", "wipe out", "x", "zero out"];
}, {
    readonly name: "videocam";
    readonly rank: 108;
    readonly popularity: 69611;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["broadcast", "broadcasting", "cam", "camera", "capture", "conference", "electronic", "film", "filming", "hardware", "image", "lens", "live", "media", "motion", "movie", "picture", "playback", "record", "recording", "shutter", "stream", "streaming", "technology", "video", "video recording", "videocam", "videography"];
}, {
    readonly name: "play_circle";
    readonly rank: 109;
    readonly popularity: 69136;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["arrow", "audio", "begin", "broadcast", "button", "circle", "content", "continue", "control", "controls", "entertainment", "launch", "listen", "live", "media", "movie", "music", "play", "playback", "player", "podcast", "record", "replay", "resume", "round", "show", "start", "stream", "triangle", "video", "watch"];
}, {
    readonly name: "radio_button_checked";
    readonly rank: 110;
    readonly popularity: 68721;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["active", "app", "application", "bullet", "button", "checked", "checked circle", "checked state", "choice", "circle", "components", "control", "design", "dot", "enabled", "filled circle", "form", "form element", "input", "interactive", "interface", "mutually exclusive", "off", "on", "option", "picker", "picker control", "point", "radio", "radio button", "record", "round", "screen", "select", "selected", "selected state", "single choice", "site", "toggle", "ui", "ui control", "ux", "web", "website"];
}, {
    readonly name: "arrow_upward";
    readonly rank: 111;
    readonly popularity: 67137;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["above", "app", "application", "arrow", "ascend", "components", "direction", "elevate", "expand", "export", "go up", "grow", "increase", "indicator", "interface", "move", "movement", "navigate", "navigation", "pointer", "reorder", "return", "screen", "scroll", "scroll up", "send", "share", "site", "sort", "sort ascending", "superior", "to top", "top", "ui", "up", "upload", "upward", "ux", "web", "website"];
}, {
    readonly name: "admin_panel_settings";
    readonly rank: 112;
    readonly popularity: 66463;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "adjust", "admin", "administrator", "avatar", "certified", "cog", "configuration", "control", "customize", "dashboard", "edit", "face", "gear", "human", "key", "lock", "management", "options", "panel", "people", "permissions", "person", "preferences", "privacy", "private", "profile", "protect", "protection", "security", "settings", "setup", "shield", "system", "tool", "tools", "user", "verified"];
}, {
    readonly name: "today";
    readonly rank: 113;
    readonly popularity: 66449;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "appointment", "calendar", "circle", "circle with dot", "clock", "contemporary", "current", "date", "day", "dot", "dot in circle", "event", "filled circle", "indicator", "mark", "marker", "month", "now", "outline", "plan", "point", "present", "remember", "reminder", "ring", "round", "schedule", "solid circle", "time", "today"];
}, {
    readonly name: "grid_view";
    readonly rank: 114;
    readonly popularity: 65729;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["app", "application square", "arrangement", "block layout", "blocks", "boxes", "components", "content", "dashboard", "data display", "design", "display", "elements", "grid", "grid layout", "grid view", "information display", "interface", "items", "layout", "matrix", "multiple items", "organization", "organize", "organized", "pattern", "screen", "site", "square grid", "squares", "structure", "structured", "system", "tile view", "tiles", "ui", "ux", "view", "visual display", "web", "website", "window"];
}, {
    readonly name: "picture_as_pdf";
    readonly rank: 115;
    readonly popularity: 65608;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["adobe", "adobe acrobat", "alphabet", "as", "character", "copy", "digital document", "digital file", "document", "document icon", "document preview", "document representation", "document symbol", "document viewer", "duplicate", "electronic document", "electronic file", "electronic file icon", "file", "file format", "file symbol", "file type", "font", "format", "image", "letters", "multiple", "pages", "paper", "paper icon", "pdf", "pdf file", "pdf icon", "pdf symbol", "photo", "photography", "picture", "portable document format", "show document", "show file", "stack", "symbol", "text", "type", "view document", "view file"];
}, {
    readonly name: "east";
    readonly rank: 116;
    readonly popularity: 64872;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["angle", "arrow", "compass", "direction", "directional", "east", "element", "forward", "go", "indicator", "journey", "line", "maps", "move", "navigation", "next", "path", "point", "pointer", "position", "right", "signage", "symbol", "travel", "triangle"];
}, {
    readonly name: "group";
    readonly rank: 117;
    readonly popularity: 64687;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accounts", "administration", "audience", "basic", "committee", "community", "contacts", "crowd", "directory", "employees", "face", "family", "figures", "friends", "group", "heads", "humans", "list", "management", "members", "network", "outline", "people", "persons", "profile", "profiles", "roster", "shape", "silhouettes", "simple", "social", "staff", "team", "users"];
}, {
    readonly name: "mic";
    readonly rank: 118;
    readonly popularity: 64424;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["audio", "audio button", "audio capture", "audio input", "audio recording", "chat", "communication", "dictate", "dictation", "hear", "hearing", "input", "keyboard", "messaging", "mic", "mic button", "microphone", "microphone button", "multimedia", "noise", "record", "recorder", "recording", "recording button", "sound", "sound capture", "sound input", "sound recording", "speak", "speaker", "speech", "talk", "voice", "voice button", "voice command", "voice input"];
}, {
    readonly name: "lock_open";
    readonly rank: 119;
    readonly popularity: 64165;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "action open", "authorized", "button open", "control open", "freedom", "grant access", "keyhole", "lock", "lock open", "open", "open door", "padlock open", "password", "permission", "privacy", "privacy open", "private", "protection", "protection open", "release", "safety", "safety open", "secure", "security", "security open", "state open", "symbol open", "toggle lock", "unblocked", "unlock", "unlocked", "unrestricted", "unsecure", "vulnerability"];
}, {
    readonly name: "receipt_long";
    readonly rank: 120;
    readonly popularity: 62996;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["accounting", "bill", "bill icon", "business", "check", "checkout", "details", "document", "document icon", "expense", "expense icon", "financial", "financial icon", "history", "invoice", "list", "long", "long receipt", "long receipt icon", "order", "paper", "paper icon", "paperwork", "payment", "payment icon", "purchase", "receipt", "receipt icon", "record", "register", "shopping", "store", "transaction", "transaction icon"];
}, {
    readonly name: "volume_up";
    readonly rank: 121;
    readonly popularity: 62883;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["acoustic", "adjust volume", "amplify", "audio", "audio bars", "audio control", "audio output", "control", "controls", "decibels", "hearing", "high volume", "icon", "increase volume", "listen", "loud", "media", "multimedia", "music", "playback", "settings", "sound", "sound bars", "sound levels", "sound setting", "sound wave", "speaker", "symbol", "tv", "up", "video", "volume", "volume control", "volume up"];
}, {
    readonly name: "inventory_2";
    readonly rank: 122;
    readonly popularity: 62471;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["archive", "assets", "box", "boxes", "collection", "container", "count", "crate", "delivery", "file", "goods", "inventory", "items", "items.", "logistics", "management", "objects", "organize", "package", "packages", "product", "quantity", "resources", "shipping", "square", "stack", "stock", "storage", "supply", "three dimensional", "warehouse"];
}, {
    readonly name: "circle";
    readonly rank: 123;
    readonly popularity: 62199;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["active", "angle", "bullet", "button", "circle", "circular", "complete", "disc", "dot", "empty", "eye", "fish", "focus", "full", "geometry", "graphic", "image", "indicator", "lens", "mark", "moon", "orb", "outline", "panorama", "photo", "photography", "picture", "point", "progress", "radio", "record", "round", "select", "shape", "solid", "sphere", "status", "stop", "target", "whole", "wide"];
}, {
    readonly name: "update";
    readonly rank: 124;
    readonly popularity: 61753;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["app", "arrow", "arrow circle", "back", "backwards", "circle", "circular", "clock", "counter-clockwise", "cycle", "data", "download", "forward", "history", "internet", "load", "loading", "loop", "process", "program", "progress", "redo", "refresh", "reload", "renewal", "reverse", "rotate", "schedule", "software", "spin", "sync", "synchronize", "system", "technology", "time", "undo", "update", "upload", "web"];
}, {
    readonly name: "inventory";
    readonly rank: 125;
    readonly popularity: 61423;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["archive", "box", "boxes", "chain", "clipboard", "commerce", "container", "containers", "control", "crate", "crates", "distribution", "doc", "document", "e-commerce", "file", "goods", "inventory", "items", "logistics", "manage", "management", "organize", "package", "packages", "product", "products", "receive", "retail", "send", "shipping", "stack", "stacking", "stock", "storage", "supply", "warehouse"];
}, {
    readonly name: "badge";
    readonly rank: 126;
    readonly popularity: 61340;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["accolade", "account", "achievement", "approval", "avatar", "award", "badge", "card", "certificate", "certified", "champion", "crest", "distinction", "emblem", "employee", "endorsed", "excellence", "face", "guarantee", "honor", "human", "id", "id card", "identification", "mark", "merit", "name", "official", "people", "person", "premium", "prize", "profile", "quality", "recognition", "reward", "seal", "security", "stamp", "star", "symbol", "token", "user", "verified", "warranty", "winner", "work"];
}, {
    readonly name: "edit_note";
    readonly rank: 127;
    readonly popularity: 60940;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["changes", "compose", "compose note", "corrections", "create", "create document", "create note", "document", "draft", "edit", "edit document", "edit file", "edit text", "editing", "editor", "file", "input", "lines", "memo", "modify", "new", "new document", "note", "notepad", "paper", "pen", "pencil", "revision", "text", "write", "writing", "writing tool"];
}, {
    readonly name: "savings";
    readonly rank: 128;
    readonly popularity: 60723;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "bank", "banking", "banking icon", "bill", "budget", "card", "cash", "coin", "commerce", "cost", "credit", "currency", "currency exchange", "deposit", "dollars", "earnings", "economy", "finance", "financial literacy", "financial planning", "fund", "income", "investment", "money", "online", "pay", "payment", "pig", "piggy", "piggy bank", "reserve", "revenue", "saving", "savings", "symbol", "transaction", "wealth", "wealth creation", "wealth management"];
}, {
    readonly name: "map";
    readonly rank: 129;
    readonly popularity: 60505;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["address", "atlas", "cartography", "city", "continent", "country", "destination", "direction", "directions", "discover", "earth", "explore", "geography", "gps", "guide", "journey", "location", "map", "maps", "marker", "navigation", "pin", "place", "point of interest", "position", "region", "route", "stop", "street", "territory", "track", "travel", "world"];
}, {
    readonly name: "code";
    readonly rank: 130;
    readonly popularity: 60313;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["algorithm", "application", "backend", "brackets", "build", "code", "coding", "commands", "compile", "computer", "console", "css", "develop", "developer", "development", "editor", "engineer", "engineering", "frontend", "function", "html", "language", "logic", "markup", "platform", "programmer", "programming", "script", "software", "source", "syntax", "technology", "terminal", "variable", "web"];
}, {
    readonly name: "light_mode";
    readonly rank: 131;
    readonly popularity: 59553;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["adjustment", "appearance", "application", "bright", "brightness", "celestial body", "circle", "clear", "day", "daytime", "device", "display", "illumination", "interface", "light", "light mode", "lighting", "lines", "mode", "morning", "option", "preference", "radial", "setting", "sky", "star", "sun", "sun rays", "sunny", "switch", "theme", "toggle", "visibility"];
}, {
    readonly name: "add_shopping_cart";
    readonly rank: 132;
    readonly popularity: 59457;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["acquisition", "add", "add to cart", "basket", "buy", "card", "cart", "cash", "checkout", "coin", "commerce", "credit", "currency", "dollars", "e-commerce", "e-shop", "item", "market", "money", "online", "online shopping", "online store", "order", "pay", "payment", "plus", "product", "purchase", "retail", "retail experience", "retail therapy", "shop", "shopping", "shopping cart", "store"];
}, {
    readonly name: "contact_support";
    readonly rank: 133;
    readonly popularity: 58797;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["?", "ask", "assistance", "bubble", "bubble icon", "chat", "chat bubble", "chatbot", "comment", "communicate", "communication", "communication icon", "contact", "conversation", "customer service", "dialog", "dialog box", "faq", "help", "help icon", "info", "information", "interaction", "mark", "message", "messaging", "punctuation", "query", "question", "question icon", "question mark", "service", "speech", "speech bubble", "support", "support icon", "symbol", "talk"];
}, {
    readonly name: "category";
    readonly rank: 134;
    readonly popularity: 58653;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["categories", "category", "chain", "chains", "chart", "charts", "circle", "circles", "collection", "concept", "concepts", "connection", "connections", "diagram", "diagrams", "flow", "hierarchical", "hierarchy", "idea", "ideas", "items", "link", "links", "network", "networks", "orb", "orbs", "organization", "organize", "product", "relate", "related", "relationship", "relationships", "shapes", "sort", "square", "structure", "structures", "three circles", "tree", "trees", "triangle"];
}, {
    readonly name: "receipt";
    readonly rank: 135;
    readonly popularity: 58211;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accounting", "bill", "cash", "check", "checkout", "commerce", "cost", "document", "expense", "finance", "financial", "invoice", "list", "money", "order", "paper", "payment", "price", "purchase", "receipt", "record", "report", "retail", "sale", "shop", "shopping", "statement", "store", "summary", "transaction"];
}, {
    readonly name: "campaign";
    readonly rank: 136;
    readonly popularity: 57703;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["achievement", "action", "advertisement", "alert", "announcement", "banner", "campaign", "celebration", "concept", "curve", "direction", "emblem", "event", "flag", "goal", "line", "loud", "marketing", "megaphone", "microphone", "milestone", "navigation", "notification", "object", "pennant", "point", "progress", "promotion", "shape", "speaker", "success", "symbol", "triangle", "victory", "wave", "wind"];
}, {
    readonly name: "power_settings_new";
    readonly rank: 137;
    readonly popularity: 57341;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "button", "circle", "command", "control", "device", "electrical", "electronics", "energy", "info", "information", "interface control", "line", "machine", "off", "on", "power", "rounded", "save", "settings", "shutdown", "start", "stop", "switch", "symbol", "system", "toggle", "utility"];
}, {
    readonly name: "format_list_bulleted";
    readonly rank: 138;
    readonly popularity: 56557;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["align", "alignment", "arrangement", "bullet list", "bulleted", "bullets", "content", "display", "doc", "document", "edit", "editing", "editor", "enumeration", "format", "formatting", "itemize", "items", "layout", "list", "notes", "order", "organize", "outline", "points", "rich text", "selection", "sequence", "sheet", "spreadsheet", "structure", "text", "type", "unordered", "word processing", "writing"];
}, {
    readonly name: "pause";
    readonly rank: 139;
    readonly popularity: 55922;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["action", "audio", "break", "button", "command", "control", "controls", "function", "halt", "hold", "inactivity", "interlude", "media", "media control", "music", "parallel lines", "pause", "pending", "playback control", "player", "rectangle", "standby", "stop", "suspend", "temporary", "two lines", "vertical lines", "video", "waiting"];
}, {
    readonly name: "done_all";
    readonly rank: 140;
    readonly popularity: 55574;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "all", "all done", "approval", "approve", "approved", "check", "checked", "checkmarks", "complete", "completion", "confirmation", "confirmed", "correct", "done", "double check", "finished", "indicator", "layers", "list", "mark", "message", "multiple", "ok", "process", "read", "select", "sent", "stack", "status", "success", "task", "task complete", "tick", "tick marks", "two checks", "valid", "validate", "validation", "verified", "workflow", "yes"];
}, {
    readonly name: "restart_alt";
    readonly rank: 141;
    readonly popularity: 55453;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["alt", "around", "arrow", "begin again", "circular", "curved", "cycle", "inprogress", "load", "loading refresh", "loop", "play again", "playback", "process", "reboot", "refresh", "refresh content", "refresh data", "reload", "renew", "repeat", "rerun", "reset", "reset data", "reset form", "restart", "restart app", "restore", "retry", "rotation", "start over", "sync", "synchronize", "turn", "undo", "update"];
}, {
    readonly name: "pets";
    readonly rank: 142;
    readonly popularity: 54611;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adoption", "animal", "animal foot", "animal icon", "animal print", "animal shelter", "animal symbol", "animal tracks", "animals", "cat", "dog", "footprint", "hand", "mark", "paw", "paw mark", "paw print", "pet", "pet care", "pet friendly", "pet icon", "pet symbol", "pets", "print", "rescue", "shape", "tracking", "trail", "vet", "veterinary", "walk"];
}, {
    readonly name: "arrow_back_ios_new";
    readonly rank: 143;
    readonly popularity: 54506;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["DISABLE_IOS", "action", "angle", "app", "application", "arrow", "back", "back button", "backward", "chevron", "components", "control", "direction", "disable_ios", "exit", "go back", "history", "interface", "ios", "left", "less than", "mobile", "move", "navigate", "navigation", "point left", "pointer", "preceding", "previous", "prior", "return", "reverse", "rewind", "screen", "site", "step back", "ui", "undo", "ux", "web", "website"];
}, {
    readonly name: "wifi";
    readonly rank: 144;
    readonly popularity: 54065;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["access point", "antenna", "bars", "broadcast", "communication", "computer", "connection", "connectivity", "data", "device", "hotspot", "indicator", "internet", "network", "online", "phone", "reception", "scan", "service", "signal", "status", "strength", "symbol", "technology", "waves", "wifi", "wireless"];
}, {
    readonly name: "list_alt";
    readonly rank: 145;
    readonly popularity: 53974;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["agenda", "alt", "box", "bullet", "bullet-list", "catalog", "checklist", "contained", "database", "details", "document", "dots", "form", "format", "index", "items", "lines", "list", "list-alt", "log", "menu", "navigation", "options", "order", "organization", "playlist", "record", "reorder", "rounded-square", "square", "stacked", "structure", "tasks", "title", "to-do", "view"];
}, {
    readonly name: "engineering";
    readonly rank: 146;
    readonly popularity: 53731;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["adjustment", "automation", "body", "building", "cog", "cogs", "cogwheel", "configuration", "construction", "control", "customize", "development", "engineering", "fix", "fixing", "function", "gear", "gears", "hat", "helmet", "human", "industrial", "industry", "machinery", "maintenance", "management", "mechanics", "operation", "options", "people", "person", "process", "repair", "setting", "settings", "setup", "system", "technical", "technology", "tools", "worker"];
}, {
    readonly name: "storefront";
    readonly rank: 147;
    readonly popularity: 53239;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["brick and mortar", "building", "business", "buy", "buying", "cafe", "commerce", "commercial", "e-commerce", "economy", "establishment", "front", "goods", "lines", "market", "marketplace", "merchant", "online store", "places", "products", "purchase", "rectangular", "restaurant", "retail", "sale", "sell", "selling", "shop", "shop icon", "shopping", "store", "store building", "storefront", "storefront icon", "trade", "vendor", "window"];
}, {
    readonly name: "bolt";
    readonly rank: 148;
    readonly popularity: 52730;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["alert", "bolt", "charge", "current", "danger", "electric", "electricity", "energy", "fast", "flash", "graphic", "icon", "instant", "lightning", "power", "quick", "shape", "speed", "storm", "surge", "symbol", "thunderbolt", "urgent", "warning", "weather", "zap"];
}, {
    readonly name: "notifications_active";
    readonly rank: 149;
    readonly popularity: 52608;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["active", "alarm", "alert", "attention", "bell", "broadcast", "chime", "communication", "current", "enabled", "engaged", "incoming", "indicator", "live", "message", "new", "notification", "notifications", "notify", "priority", "reminder", "ring", "ringing", "ringing bell", "signal", "sound", "status", "symbol", "ui element", "update", "urgent"];
}, {
    readonly name: "toggle_on";
    readonly rank: 150;
    readonly popularity: 52417;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["activate", "active", "button", "circle", "component", "components", "configuration", "control", "control on", "disable", "element", "enable", "enabled", "feature", "function", "horizontal", "inable", "inactive", "indicator", "interface", "off", "on", "option", "oval", "power", "selection", "setting", "setting on", "settings", "site", "slider", "state", "switch", "switch on", "toggle", "toggle on", "turn on", "ui", "ui control", "ux", "web", "website"];
}, {
    readonly name: "construction";
    readonly rank: 151;
    readonly popularity: 52404;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["build", "builder", "building", "carpenter", "construction", "developing", "development", "engineer", "engineering", "equipment", "fix", "fixing", "hammer", "handyman", "improvement", "in progress", "industrial", "industry", "maintain", "maintenance", "renovate", "renovation", "repair", "site", "site work", "technical", "technician", "tools", "tradesman", "tradesperson", "under construction", "work", "worker", "working", "wrench"];
}, {
    readonly name: "dark_mode";
    readonly rank: 152;
    readonly popularity: 51952;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["accessibility", "ambient", "app", "appearance", "application", "atmosphere", "bedtime", "circle", "comfort", "contrast", "crescent", "customization", "dark", "dark mode", "darkness", "device", "display", "element", "evening", "eye strain", "graphic", "interface", "low light", "mode", "moon", "night", "part", "personalization", "settings", "shape", "silent", "switch", "theme", "toggle", "ui", "ux", "view", "visual", "website"];
}, {
    readonly name: "sort";
    readonly rank: 153;
    readonly popularity: 51877;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["alphabetize", "arrange", "arrow", "ascending", "categorize", "change order", "content", "data", "descending", "direction", "display", "down", "filter", "group", "hierarchy", "list", "management", "options", "order", "organize", "organize data", "preference", "rearrange", "reorder", "sequence", "settings", "sort", "table", "up", "view"];
}, {
    readonly name: "arrow_downward";
    readonly rank: 154;
    readonly popularity: 51488;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["app", "application", "arrow", "collapse", "components", "continue", "descending", "direction", "down", "download", "downward", "dropdown", "expand", "export", "flow", "forward", "indicate", "install", "interface", "list", "menu", "minimize", "move", "navigation", "next", "next step", "pointer", "reveal", "save", "screen", "scroll", "show more", "site", "sort", "symbol", "transfer", "ui", "ux", "web", "website"];
}, {
    readonly name: "qr_code_scanner";
    readonly rank: 155;
    readonly popularity: 51352;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["access", "app", "application", "authentication", "barcode", "bars", "camera", "code", "corners", "data matrix", "digital", "information", "lines", "link", "matrix code", "media", "mobile", "optical code", "pattern", "payment", "phone", "product", "qr", "qr code", "quick", "quick response code", "reader", "rectangular", "response", "scan", "scanner", "smartphone", "square", "technology", "url", "urls", "website"];
}, {
    readonly name: "explore";
    readonly rank: 156;
    readonly popularity: 51113;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adventure", "browse", "compass", "curiosity", "destination", "direction", "discover", "discovery", "east", "explore", "find", "globe", "guide", "investigate", "journey", "location", "map", "maps", "marker", "navigate", "navigation", "needle", "new", "north", "path", "pin", "roam", "search", "seek", "sightseeing", "south", "travel", "uncharted", "wander", "west", "world"];
}, {
    readonly name: "attach_file";
    readonly rank: 157;
    readonly popularity: 50828;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["add", "append", "attach", "attachment", "binding", "chain", "choose", "clip", "communication", "connect", "correspondence", "data", "document", "email", "fastener", "file", "input", "insert", "link", "mail", "media", "message", "office", "paper", "paperclip", "record", "report", "secure", "select", "send", "share", "upload"];
}, {
    readonly name: "bookmark";
    readonly rank: 158;
    readonly popularity: 50656;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["app", "archive", "article", "book", "bookmark", "browser", "collection", "content", "corner", "document", "favorite", "file", "fold", "guide", "keep", "label", "library", "mark", "mobile", "organize", "page", "pin", "read", "reading", "remember", "ribbon", "save", "site", "tag", "tutorial", "web page"];
}, {
    readonly name: "account_box";
    readonly rank: 159;
    readonly popularity: 50586;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "account icon", "accounts", "avatar", "box", "bust", "contact", "contact icon", "face", "figure", "head", "human", "identity", "individual", "login", "man", "member", "outline", "people", "person", "person outline", "person symbol", "profile", "register", "shape", "shoulders", "sign in", "sign up", "silhouette", "square", "thumbnail", "user", "user icon", "user profile"];
}, {
    readonly name: "note_add";
    readonly rank: 160;
    readonly popularity: 49753;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["+", "add", "add document", "add note", "create", "create document", "data", "doc", "document", "document add", "drive", "entry", "file", "folder", "folders", "form", "form add", "insert", "list", "memo", "message", "new", "new file", "new note", "note", "notepad", "page", "paper", "plus", "plus document", "plus note", "sheet", "slide", "symbol", "text", "to do", "writing"];
}, {
    readonly name: "vpn_key";
    readonly rank: 161;
    readonly popularity: 49450;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["access", "authenticate", "authentication", "authorization", "authorize", "closed", "code", "connection", "data", "digital", "door", "encrypted", "encryption", "entry", "internet", "key", "lock", "login", "network", "passcode", "password", "privacy", "private", "protection", "safety", "secret", "secure", "security", "shield", "sign in", "technology", "unlock", "vpn"];
}, {
    readonly name: "timer";
    readonly rank: 162;
    readonly popularity: 49250;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["alarm", "alert", "appointment", "bell", "chronometer", "circular", "clock", "countdown", "deadline", "deadline management", "deadline tracking", "disabled", "duration", "enabled", "event", "event tracking", "hand", "hour hand", "measurement", "minute hand", "notification", "pointer", "reminder", "ringing", "round", "running time", "schedule", "second hand", "speed", "stopwatch", "time", "time limit", "timekeeping", "timer", "watch"];
}, {
    readonly name: "pending_actions";
    readonly rank: 163;
    readonly popularity: 48809;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["actions", "agenda", "alert", "backlog", "calendar", "clipboard", "clock", "date", "delay", "doc", "document", "future", "history", "incomplete", "list", "log", "notification", "paper", "pending", "pending actions", "processing", "progress", "queue", "remember", "reminder", "schedule", "tasks", "time", "to do", "upcoming", "waiting", "workflow"];
}, {
    readonly name: "upload_file";
    readonly rank: 164;
    readonly popularity: 48498;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["action", "add", "arrow", "button", "cloud", "data", "doc", "document", "download", "drive", "element", "file", "folder", "folders", "graphic", "icon", "import", "line", "page", "paper", "save", "send", "sheet", "slide", "store", "symbol", "transfer", "transmit", "ui", "up", "upload", "writing"];
}, {
    readonly name: "arrow_right";
    readonly rank: 165;
    readonly popularity: 48490;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["advance", "angle", "app", "application", "arrow", "button", "caret", "chevron", "components", "continuation", "cue", "direction", "enter", "exit", "forward", "go", "greater than", "indicator", "interface", "line", "link", "move", "navigation", "next", "path", "point", "pointer", "proceed", "progress", "return", "right", "screen", "shortcut", "site", "triangle", "ui", "ux", "way", "web", "website"];
}, {
    readonly name: "reorder";
    readonly rank: 166;
    readonly popularity: 48444;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "arrows", "bars", "burger", "dots", "down", "drag", "drag and drop", "drop", "ellipses", "format", "grid", "grip", "handle", "horizontal", "layout", "lines", "list", "menu", "move", "navigation", "order", "organize", "parallel", "rearrange", "reorder", "sort", "stacked", "structure", "up", "vertical"];
}, {
    readonly name: "account_tree";
    readonly rank: 167;
    readonly popularity: 48253;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["account", "account structure", "analytics", "branches", "chart", "connect", "connected", "connections", "corporate structure", "data", "diagram", "flow", "graph", "grouped", "hierarchy", "infographic", "layers", "levels", "linked", "management", "mapping", "measure", "metrics", "nested", "network", "nodes", "organization", "organizational chart", "outline", "process", "project structure", "relationships", "square", "statistics", "structure", "system", "team structure", "tracking", "tree", "tree structure", "visual hierarchy"];
}, {
    readonly name: "flag";
    readonly rank: 168;
    readonly popularity: 47539;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["achievement", "banner", "bookmark", "border", "country", "destination", "emoji", "empty", "flag", "flags", "goal", "highlight", "indicator", "label", "landmark", "location", "mark", "marker", "milepost", "milestone", "nation", "national", "notice", "outline", "pennant", "pin", "place", "pole", "report", "save", "signal", "social", "standard", "start", "territory", "unfilled", "world"];
}, {
    readonly name: "apartment";
    readonly rank: 169;
    readonly popularity: 47325;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["accommodation", "address", "apartment", "architecture", "area", "block", "building", "business", "city", "commercial", "company", "complex", "downtown", "estate", "flat", "home", "house", "housing", "lines", "location", "navigation", "office", "outline", "places", "property", "real", "real estate", "rectangle", "region", "residence", "residential", "shelter", "silhouette", "skyscraper", "square", "structure", "tower", "units", "urban", "windows", "workplace"];
}, {
    readonly name: "sync";
    readonly rank: 170;
    readonly popularity: 46928;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["360", "align", "around", "arrow", "arrows", "circular", "cloud", "connection", "consistency", "continuous", "current", "cycle", "data", "direction", "exchange", "inprogress", "latest", "load", "loading refresh", "loop", "process", "recurring", "refresh", "reload", "renew", "reorder", "retrieve", "rotate", "rotation", "sync", "synchronization", "synchronize", "transfer", "turn", "update"];
}, {
    readonly name: "shopping_basket";
    readonly rank: 171;
    readonly popularity: 46790;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["add", "add to cart", "bag", "basket", "bill", "buy", "card", "cart", "cash", "checkout", "coin", "commerce", "container", "credit", "currency", "dollars", "e-commerce", "ecommerce", "ellipse", "goods", "groceries", "handle", "items", "market", "marketplace", "merchandise", "money", "online", "online store", "oval", "pay", "payment", "purchase", "retail", "shop", "shopping", "shopping basket", "shopping cart", "store"];
}, {
    readonly name: "restaurant";
    readonly rank: 172;
    readonly popularity: 46164;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["bar", "breakfast", "breakfast place", "building", "cafe", "cafeteria", "culinary", "cutlery", "dine", "diner", "dining", "dining establishment", "dinner", "dinner place", "eat", "eatery", "eating", "establishment", "fast food", "food", "food court", "food place", "food service", "fork", "gastronomy", "knife", "local", "lunch", "lunch place", "meal", "place", "restaurant", "spoon", "utensils"];
}, {
    readonly name: "reply";
    readonly rank: 173;
    readonly popularity: 45648;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["arrow", "backward", "bubble", "chat", "chat box", "chat bubble", "comment", "communicate", "communication", "conversation", "dialogue", "direct message", "email", "feedback", "forward", "interaction", "left", "mail", "message", "message bubble", "messenger", "receive", "reply", "respond", "response", "send", "share", "social media", "speak", "speech", "square", "talk", "talk bubble", "text"];
}, {
    readonly name: "task";
    readonly rank: 174;
    readonly popularity: 45638;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["accepted", "agenda", "approve", "assignment", "box", "check", "check box", "checklist", "checkmark", "complete", "confirmed", "data", "doc", "document", "done", "drive", "file", "folder", "folders", "list", "management", "mark", "memo", "note", "notification", "ok", "organize", "page", "paper", "plan", "productivity", "progress", "project", "reminder", "schedule", "select", "sheet", "slide", "square", "task", "tick", "to do", "validate", "verified", "workflow", "writing", "yes"];
}, {
    readonly name: "manage_search";
    readonly rank: 175;
    readonly popularity: 45464;
    readonly categories: readonly ["search"];
    readonly tags: readonly ["administration", "configure", "control", "discover", "explore", "filter", "find", "find and manage", "glass", "history", "interface", "lens", "locate", "magnifying", "magnifying glass", "manage", "options", "organize", "preferences", "query", "results", "search", "search and organize", "search filters", "search results", "settings", "system", "text", "tool", "utility"];
}, {
    readonly name: "touch_app";
    readonly rank: 176;
    readonly popularity: 45025;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "app", "application", "button", "click", "command", "control", "cursor", "device", "digital", "element", "finger", "fingers", "gesture", "hand", "input", "interact", "mobile", "navigation", "phone", "pointer", "press", "screen", "select", "software", "tablet", "tap", "touch", "ui element"];
}, {
    readonly name: "add_box";
    readonly rank: 177;
    readonly popularity: 44993;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "add", "addition", "border", "box", "build", "button", "construct", "container", "content", "control", "create", "element", "empty", "feature", "form", "frame", "function", "geometric", "geometry", "insert", "item", "new", "new square", "object", "outline", "plus", "shape", "square", "stroke", "symbol"];
}, {
    readonly name: "directions_car";
    readonly rank: 178;
    readonly popularity: 44893;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["auto", "automobile", "automotive", "car", "car symbol", "cars", "destination", "direction", "directions", "drive", "drive time", "driving", "estimated time", "eta", "journey", "maps", "mobility", "navigate", "navigation", "passenger vehicle", "public", "road", "route", "sedan", "time", "transport", "transport symbol", "transportation", "travel", "travel time", "trip", "vehicle", "vehicle icon"];
}, {
    readonly name: "supervisor_account";
    readonly rank: 179;
    readonly popularity: 44841;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "account settings", "admin", "administrator", "avatar", "block", "configuration", "control", "control panel", "custodian", "face", "family", "filter", "guardian", "human", "kids", "manage", "options", "parent", "parental", "parental control", "parental controls", "parents", "people", "person", "preferences", "profile", "restriction settings", "restrictions", "safety", "security", "settings", "supervised", "supervisor", "supervisor account", "tv settings", "user", "user profile", "viewing restrictions"];
}, {
    readonly name: "drag_indicator";
    readonly rank: 180;
    readonly popularity: 44797;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "app", "application", "circles", "column", "components", "control", "design", "dots", "drag", "drop", "element", "gesture", "grab", "grip", "handle", "icon", "indicator", "indicators", "interaction", "interface", "item", "layout", "list", "marker", "menu", "mobile", "monitor", "move", "organize", "phone", "points", "position", "rearrange", "reorder", "screen", "selector", "shape", "shift", "site", "sort", "tablet", "touch", "ui", "ux", "vertical", "web", "website", "window"];
}, {
    readonly name: "pending";
    readonly rank: 181;
    readonly popularity: 44770;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accordion", "arrow down", "bottom", "choose", "circle", "close", "collapse", "details", "direction", "dots", "down arrow", "dropdown", "dropdown menu", "expand", "hide", "indicator", "list", "loading", "menu", "more", "navigation", "open", "pending", "point", "pointer", "progress", "reveal", "scroll down", "section", "select", "south", "triangle", "view more", "wait", "waiting"];
}, {
    readonly name: "menu_open";
    readonly rank: 182;
    readonly popularity: 44585;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["app", "application", "arrow", "back", "bar menu", "burger", "chevron", "close", "close menu", "collapse", "components", "details", "directional", "expand", "forward", "hamburger", "hamburger menu", "hide", "interface", "items", "left", "line", "lines", "list", "menu", "menu open", "more", "navigation", "open", "open menu", "options", "panel", "right", "screen", "settings", "show", "side menu", "sidebar", "site", "three lines", "toggle", "ui", "ux", "web", "website"];
}, {
    readonly name: "zoom_in";
    readonly rank: 183;
    readonly popularity: 44102;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "add", "big", "bigger", "button", "circle", "command", "control", "cross", "detail", "enlarge", "find", "function", "glass", "grow", "in", "increase", "input", "interface tool", "lens", "line", "look", "magnifier", "magnify", "magnifying", "magnifying glass", "plus", "positive", "scale", "search", "see", "size", "tool", "ui tool", "view", "zoom", "zoom in"];
}, {
    readonly name: "local_fire_department";
    readonly rank: 184;
    readonly popularity: 44039;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["911", "alert", "blaze", "burning", "climate", "danger", "department", "discovery", "emergency", "explore", "fire", "fire department", "fire icon", "firefighter", "flame", "flame icon", "heat", "home", "hot", "hot topics", "ignition", "inferno", "local", "nest", "news", "popular", "social media", "spark", "thermostat", "top videos", "trending", "trending topics", "trending videos", "video", "viral", "warning", "youtube"];
}, {
    readonly name: "priority_high";
    readonly rank: 185;
    readonly popularity: 44004;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["!", "alarm", "alert", "attention", "caution", "critical", "danger", "error", "exclamation", "exclamation mark", "exclamation point", "flag", "high", "high priority", "important", "indicator", "mark", "message", "note", "notification", "outline", "point", "priority", "reminder", "signal", "symbol", "triangle", "triangular", "urgent", "warning"];
}, {
    readonly name: "group_add";
    readonly rank: 186;
    readonly popularity: 43876;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accounts", "add", "add friend", "add member", "add user", "avatar", "circle", "collaborate", "collective", "committee", "contact", "face", "family", "friend", "friends", "group", "human", "humans", "inclusion", "increase", "invite", "join", "member", "membership", "more", "network", "new", "people", "person", "persons", "plus", "profile", "profiles", "roster", "silhouette", "social", "team", "user profile", "users"];
}, {
    readonly name: "leaderboard";
    readonly rank: 187;
    readonly popularity: 43568;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "achievements", "analytics", "bar", "bar chart", "bars", "best", "chart", "columns", "competition", "competitive", "data", "diagram", "graph", "high score", "highscores", "infographic", "leaderboard", "levels", "list", "measure", "medal", "metrics", "podium", "points", "progress", "rank", "ranking", "score", "scores", "statistics", "stats", "tiers", "top", "tracking", "winner", "winners"];
}, {
    readonly name: "block";
    readonly rank: 188;
    readonly popularity: 43562;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["alert", "avoid", "ban", "block", "cancel", "circle", "close", "control", "diagonal", "disable", "disturb", "do not disturb", "entry", "exclude", "exit", "forbidden", "interrupt", "limit", "line", "mute", "no", "notification", "off", "preference", "prohibited", "quiet", "quit", "remove", "restricted", "setting", "silent", "slash", "state", "status", "stop", "unavailable"];
}, {
    readonly name: "summarize";
    readonly rank: 189;
    readonly popularity: 42736;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["arrows", "aspect ratio", "button", "control", "corners", "corners out", "display", "doc", "document", "enlarge", "expand", "form", "four arrows", "fullscreen", "growth", "image", "in", "increase", "list", "magnify", "maximize", "media", "menu", "mode", "note", "out", "presentation", "report", "scale", "size", "square", "summary", "toggle", "video", "view", "viewer", "window", "zoom in"];
}, {
    readonly name: "event_available";
    readonly rank: 190;
    readonly popularity: 42517;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["agenda", "appointment", "approve", "availability", "availability icon", "available", "booked", "booking", "calendar", "calendar icon", "check", "check icon", "checkmark", "complete", "confirmed", "confirmed appointment", "confirmed event", "date", "date available", "date confirmed", "date icon", "done", "event", "event icon", "event planning", "mark", "ok", "plan", "reminder", "schedule", "scheduled date", "scheduled event", "select", "tick", "time", "validate", "verified", "yes"];
}, {
    readonly name: "auto_stories";
    readonly rank: 191;
    readonly popularity: 41778;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["archive", "articles", "auto", "bibliography", "book", "books", "chapter", "collection", "content", "education", "feed", "flipping", "information", "journal", "learning", "library", "literature", "magazine", "narration", "narrative", "news", "open book", "pages", "publication", "read", "reading", "series", "stories", "story", "stream", "tales", "textbook"];
}, {
    readonly name: "calculate";
    readonly rank: 192;
    readonly popularity: 41380;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["+", "-", "=", "addition", "arithmetic", "calculate", "calculator", "count", "counting", "digits", "division", "equals", "equation", "filled", "finance calculator", "geometry", "keypad", "line", "math", "math operations", "multiplication", "number pad", "numbers", "numpad", "object", "result", "shape", "solid", "subtraction", "sum", "symbol", "technology", "tool", "total"];
}, {
    readonly name: "open_in_full";
    readonly rank: 193;
    readonly popularity: 41350;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "arrow", "arrows", "box", "corners", "dimensions", "display", "document", "enlarge", "expand", "frame", "full", "full screen", "fullscreen", "grow", "image", "in", "maximize", "media", "move", "open", "out", "photo", "player", "presentation", "resize", "screen", "size", "square", "video", "view", "visual", "window", "zoom"];
}, {
    readonly name: "post_add";
    readonly rank: 194;
    readonly popularity: 40844;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["+", "add", "add new", "add post", "adding content", "article", "blog", "compose", "compose new", "content", "create", "create new", "create post", "data", "doc", "document", "drive", "entry", "file", "folder", "folders", "message", "new", "new post", "notes", "page", "paper", "plus", "post", "post add", "publish", "publish new", "publishing", "sheet", "slide", "social media", "text", "write", "writing"];
}, {
    readonly name: "cloud_upload";
    readonly rank: 195;
    readonly popularity: 40823;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["app", "application", "arrow", "backup", "cloud", "computing", "connection", "data", "digital", "document upload", "download", "drive", "file upload", "files", "folders", "image upload", "internet", "move", "network", "online", "remote storage", "save", "send", "send data", "server", "share", "sky", "software", "storage", "sync", "system", "transfer", "up", "up arrow", "upload", "video upload", "weather"];
}, {
    readonly name: "bar_chart";
    readonly rank: 196;
    readonly popularity: 40519;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["analysis", "analytics", "bar", "bar chart", "bars", "business", "chart", "columns", "dashboard", "data", "data analysis", "diagram", "finance", "financial data", "graph", "growth", "growth icon", "infographic", "information", "measure", "metrics", "performance", "progress", "quantitative", "report", "report icon", "statistics", "statistics icon", "tracking", "trends", "visual representation", "visualization"];
}, {
    readonly name: "assignment_ind";
    readonly rank: 197;
    readonly popularity: 40075;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "apply", "assignment", "badge", "card", "clipboard", "data", "details", "doc", "document", "enroll", "face", "file", "form", "graphic", "icon", "id", "identification", "ind", "individual", "information", "membership", "paper", "people", "person", "profile", "record", "register", "shape", "sheet", "symbol", "ui element", "user"];
}, {
    readonly name: "alternate_email";
    readonly rank: 198;
    readonly popularity: 40045;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["@", "address", "address book", "alternate", "alternate contact", "alternate email", "communicate", "communication", "contact", "contact form", "correspondence", "email", "email address", "email client", "envelope", "inbox", "inbox icon", "letter", "mail", "message", "messaging", "outline", "outline email", "outline envelope", "outline mail", "receive", "receive message", "send", "send message", "stroke", "tag"];
}, {
    readonly name: "preview";
    readonly rank: 199;
    readonly popularity: 39517;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["check", "design", "discern", "disclosed", "discover", "display", "examine", "explore", "exposed", "eye", "glimpse", "inspect", "layout", "look", "monitor", "notice", "observe", "optic", "peek", "preview", "reveal", "revealed", "screen", "scrutinize", "see", "show", "sight", "site", "spot", "spy", "view", "visible", "vision", "watch", "web", "website", "window", "www"];
}, {
    readonly name: "psychology";
    readonly rank: 200;
    readonly popularity: 39462;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["awareness", "behavior", "body", "brain", "brainstorm", "clever", "cognitive", "concept", "education", "function", "gear", "head", "health", "human", "idea", "insight", "intellectual", "intelligence", "knowledge", "learning", "memory", "mental", "mind", "neurological", "people", "person", "preferences", "psychiatric", "psychiatrist", "psychoanalysis", "psychology", "research", "science", "settings", "smart", "social", "therapy", "thinking", "thought", "thoughts", "understanding", "wise"];
}, {
    readonly name: "done_outline";
    readonly rank: 201;
    readonly popularity: 39442;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accepted", "achievement", "agreement", "all", "approval", "approve", "approved", "check", "checkbox", "complete", "completed", "confirmed", "consent", "correct", "done", "finished", "green light", "mark", "ok", "outline", "right", "select", "selection", "sign", "status", "success", "task", "task complete", "tick", "validate", "validation", "verification", "verified", "yes"];
}, {
    readonly name: "checklist";
    readonly rank: 202;
    readonly popularity: 39432;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["align", "alignment", "approve", "check", "check marks", "checked", "checklist", "checkmark", "complete", "completed", "doc", "done", "edit", "editing", "editor", "entries", "finished", "format", "item", "items", "line", "lines", "list", "list items", "mark", "notes", "ok", "organization", "planning", "productivity", "project management", "select", "sheet", "spreadsheet", "square", "squares", "task", "task list", "text", "tick", "tick mark", "tick marks", "ticks", "to do list", "type", "validate", "verified", "writing", "yes"];
}, {
    readonly name: "password";
    readonly rank: 203;
    readonly popularity: 39426;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["access", "access code", "account", "authentication", "authorization", "code", "credentials", "data protection", "encrypted", "key", "key symbol", "keyhole", "lock", "lock and key", "login", "padlock", "password", "password protection", "pin", "privacy", "private", "protection", "restricted", "secret", "secure", "secure access", "secure connection", "security", "sign in", "sign up", "star", "unlock"];
}, {
    readonly name: "exit_to_app";
    readonly rank: 204;
    readonly popularity: 39373;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["abandon", "access", "account", "app", "application", "arrow", "block", "box", "close", "components", "depart", "design", "door", "exit", "export", "forward", "gate", "interface", "layout", "leave", "line", "log off", "logout", "mobile", "monitor", "move", "navigate", "navigation", "out", "output", "outside", "phone", "portal", "quit", "rectangle", "right arrow", "screen", "session", "sign out", "site", "square", "tablet", "to", "ui", "user", "ux", "web", "website", "window"];
}, {
    readonly name: "published_with_changes";
    readonly rank: 205;
    readonly popularity: 39114;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["approve", "approved", "arrow", "arrows", "article", "blog", "changes", "check", "commit", "complete", "content", "document", "done", "draft", "edit", "file", "finalize", "inprogress", "lines", "load", "loading", "mark", "modify", "ok", "page", "paper", "post", "publish", "published", "rectangle", "refresh", "renew", "replace", "revision", "rotate", "save", "select", "share", "sheet", "square", "text", "tick", "update", "upload", "validate", "verified", "version", "with", "writing", "yes"];
}, {
    readonly name: "volunteer_activism";
    readonly rank: 206;
    readonly popularity: 38982;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["activism", "aid", "assistance", "care", "cause", "charity", "community", "compassion", "contribution", "donate", "donation", "donation box", "fingers", "fund", "funding", "gesture", "giving", "good", "hand", "hands", "heart", "helping", "helping hand", "humanity", "kindness", "love", "non-profit", "organization", "philanthropy", "sharing", "social", "support", "volunteer"];
}, {
    readonly name: "sell";
    readonly rank: 207;
    readonly popularity: 37729;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["bargain", "bill", "card", "cart", "cash", "coin", "commerce", "coupon", "credit", "currency", "deal", "discount", "dollars", "label", "market", "money", "offer", "online", "pay", "payment", "pointed shape", "price", "promotion", "retail", "sale", "sell", "shape", "shop", "shopping", "special offer", "store", "tag", "tag shape", "voucher"];
}, {
    readonly name: "undo";
    readonly rank: 208;
    readonly popularity: 37692;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "arrow", "back", "backward", "cancel", "change", "command", "correction", "curved", "cycle", "delete", "editing", "error", "fix", "go back", "history", "left", "mail", "mistake", "operation", "previous", "redo", "remove", "repeat", "restore", "retrograde", "return", "reversal", "revert", "revise", "rollback", "rotate", "step back", "un-do", "undo"];
}, {
    readonly name: "view_in_ar";
    readonly rank: 209;
    readonly popularity: 37077;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["3d", "3d model", "ar", "ar experience", "augmented", "augmented reality", "box", "cube", "daydream", "digital", "display", "future", "headset", "hologram", "immersive", "immersive view", "in", "overlay", "perspective", "real world", "reality", "reality view", "science fiction", "scifi", "screen", "spatial", "square", "technology", "three dimensional", "view", "view in", "view in ar", "virtual reality", "virtual_reality", "vr"];
}, {
    readonly name: "add_a_photo";
    readonly rank: 210;
    readonly popularity: 36946;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["+", "a photo", "add", "album", "button", "camera", "capture", "create", "file", "gallery", "graphic", "icon", "image", "input", "insert", "interface", "lens", "library", "media", "new", "photo", "photograph", "photography", "picture", "plus", "shutter", "symbol", "ui", "ui element", "upload", "ux", "visual"];
}, {
    readonly name: "fullscreen";
    readonly rank: 211;
    readonly popularity: 36931;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["adjust", "app", "application", "aspect ratio", "big", "cinema mode", "components", "display", "enlarge", "expand", "extend", "frame", "full", "full screen", "fullscreen", "immersive", "interface", "magnify", "maximize", "media", "mode", "monitor", "picture", "player", "presentation", "scale", "screen", "site", "size", "stretch", "toggle", "ui", "ux", "video", "view", "web", "website", "wide", "window", "zoom"];
}, {
    readonly name: "keyboard_arrow_right";
    readonly rank: 212;
    readonly popularity: 36638;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["advance", "angle", "arrow", "arrows", "caret", "carousel", "chevron", "continue", "direction", "expand", "forward", "go", "greater than", "indicator", "item", "keyboard", "link", "list", "menu", "more", "move", "navigate", "navigation", "next", "open", "pointer", "proceed", "prompt", "right", "select", "slider"];
}, {
    readonly name: "health_and_safety";
    readonly rank: 213;
    readonly popularity: 36479;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["+", "add", "aid", "and", "care", "certified", "cross", "cross symbol", "defense", "guard", "health", "health shield", "health symbol", "healthcare", "home", "immune", "medical", "medical shield", "medical symbol", "medicare", "nest", "plus", "preventative", "privacy", "private", "protect", "protected", "protection", "reliable", "safe", "safeguard", "safety", "safety shield", "safety symbol", "secure", "security", "shield", "shield symbol", "symbol", "trust", "verified", "wellness"];
}, {
    readonly name: "water_drop";
    readonly rank: 214;
    readonly popularity: 36094;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["adjustments", "aqua", "blob", "concentration", "conservation", "density", "drink", "drip", "drop", "droplet", "eco", "ecology", "element", "environment", "filter", "fluid", "humidity", "hydration", "liquid", "moisture", "nature", "ocean", "oval", "point", "purification", "rain", "resource", "settings", "social", "tear", "teardrop", "water", "weather", "wet"];
}, {
    readonly name: "arrow_drop_up";
    readonly rank: 215;
    readonly popularity: 36089;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["app", "application", "arrow", "caret", "caret up", "collapse", "collapse button", "components", "control", "direction", "directional indicator", "drop", "drop up", "dropdown", "expand", "expander", "fold", "fold up", "hide", "indicator", "interface", "maximize", "minimize", "navigation", "point up", "reveal", "screen", "show", "shrink", "site", "sort button", "sort up", "toggle", "triangle", "triangle up", "ui", "ui control", "up", "up arrow", "ux", "web", "website"];
}, {
    readonly name: "swap_horiz";
    readonly rank: 216;
    readonly popularity: 35940;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alternate", "arrow", "arrows", "back", "change", "data transfer", "direction", "double-ended arrow", "exchange", "flow", "forward", "horizontal", "horizontal swap", "left arrow", "move", "movement", "opposing arrows", "orientation", "rearrange", "reorder", "replace", "right arrow", "shift", "sort", "swap", "switch", "transaction", "transfer", "transform", "two arrows"];
}, {
    readonly name: "feedback";
    readonly rank: 217;
    readonly popularity: 35918;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["!", "alert", "announcement", "attention", "broadcast", "caution", "chat", "chat bubble", "comment", "communicate", "communication", "conversation", "danger", "delivery failed", "element", "error", "exclamation", "fail", "failed", "feedback", "icon", "important", "mark", "megaphone", "message", "news", "notification", "public address", "send failed", "service", "sms", "sound", "speaker", "speech", "symbol", "text message", "volume", "warning"];
}, {
    readonly name: "label";
    readonly rank: 218;
    readonly popularity: 35906;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["angled shape", "badge", "bookmark", "category", "classification", "corner", "designation", "detail", "details", "emblem", "favorite", "geometric", "highlight", "identification", "indent", "indicator", "information", "label", "library", "mail", "marker", "name", "organize", "outline", "pointed shape", "polygon", "price tag", "remember", "save", "shape", "stamp", "sticker", "tag", "title"];
}, {
    readonly name: "computer";
    readonly rank: 219;
    readonly popularity: 35862;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["Android", "OS", "accessory", "chrome", "communication", "computer", "computing", "data", "desk", "desktop", "device", "digital", "display", "electronic", "electronic device", "gadget", "hardware", "iOS", "internet", "laptop", "mac", "monitor", "network", "notebook", "office", "pc", "peripheral", "personal computer", "screen", "server", "system", "technology", "technology device", "web", "window", "work", "workstation"];
}, {
    readonly name: "unfold_more";
    readonly rank: 220;
    readonly popularity: 35507;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "arrows", "caret", "chevron", "collapse", "control", "data", "direction", "direction change", "down", "expand", "expand less", "expand more", "expandable", "fold", "fold less", "fold more", "hide", "hierarchy", "indicator", "less", "list", "more", "navigation", "reveal", "sort", "table", "toggle", "unfold", "unfold less", "up"];
}, {
    readonly name: "travel_explore";
    readonly rank: 221;
    readonly popularity: 35491;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["adventure", "browser", "circle", "destination", "discover", "discovery", "earth", "explore", "explore world", "find", "glass", "global", "globe", "international", "journey", "location", "look", "magnify", "magnifying", "magnifying glass", "map", "navigate", "navigation", "network", "plan", "planet", "search", "see", "social", "space", "sphere", "tourism", "tourist", "travel", "trip", "wander", "web", "world", "worldwide", "zoom"];
}, {
    readonly name: "palette";
    readonly rank: 222;
    readonly popularity: 35303;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["appearance", "art", "artist", "artistic", "brush", "color", "colors", "creative", "customization", "customize", "design", "designer", "draw", "drawing", "editor", "filters", "graphic", "hues", "paint", "painting", "palette", "shades", "spectrum", "style", "swatch", "theme", "tint", "tints", "tone", "tones", "visual"];
}, {
    readonly name: "assignment_turned_in";
    readonly rank: 223;
    readonly popularity: 35268;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accepted", "approve", "approved", "assignment", "box", "check", "checklist", "checkmark", "clipboard", "complete", "completed", "doc", "document", "documentation", "done", "file", "finished", "in", "line", "lines", "mark", "ok", "paper", "progress", "project", "rectangle", "report", "select", "square", "submission", "task", "tick", "to do list", "turn", "turned in", "validate", "validated", "verified", "work", "yes"];
}, {
    readonly name: "timeline";
    readonly rank: 224;
    readonly popularity: 35103;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["chart", "chronological", "data", "dates", "diagram", "dots", "duration", "events", "flow", "future", "history", "journey", "line", "milestones", "movement", "past", "path", "period", "point", "points", "points in time", "progress", "progression", "roadmap", "schedule", "sequence", "stages", "steps", "timeline", "tracking", "trending", "visual representation", "zigzag"];
}, {
    readonly name: "stars";
    readonly rank: 225;
    readonly popularity: 35087;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "alert", "badge", "bookmark", "bright", "circle", "favorite", "feature", "five point", "geometric", "glowing", "highlight", "important", "indicator", "magic", "marked", "new", "notification", "points", "premium", "quality", "ranking", "rate", "rating", "rating rank", "reward", "save", "saved", "shape", "shiny", "sparkle", "special", "star", "stars", "success", "update"];
}, {
    readonly name: "replay";
    readonly rank: 226;
    readonly popularity: 35000;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["again", "arrow", "arrows", "audio", "back", "back arrow", "circular", "circular arrow", "continuous", "control", "controls", "curve", "curving arrow", "cycle", "loop", "media", "media control", "music", "navigation", "playback", "playback control", "player", "redo", "refresh", "renew", "repeat", "replay", "restart", "return", "rewind", "rewind arrow", "start over", "video"];
}, {
    readonly name: "sync_alt";
    readonly rank: 227;
    readonly popularity: 34904;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alt", "arrow", "arrows", "back and forth", "change", "circle", "circular", "connecting", "connection", "cycle", "data", "direction", "double arrow", "exchange", "flow", "horizontal", "interaction", "internet", "link", "loop", "oval", "process", "reciprocal", "refresh", "relationship", "round", "swap", "switch", "sync", "synchronize", "technology", "transfer", "two way", "up", "update", "wifi"];
}, {
    readonly name: "library_books";
    readonly rank: 228;
    readonly popularity: 34771;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["academy", "add", "album", "archives", "audio", "bibliography", "book", "books", "bookstore", "catalog", "collection", "content", "database", "directory", "documents", "education", "files", "index", "information", "knowledge", "learning", "library", "list", "literature", "publications", "read", "reading", "records", "research", "resources", "stacked", "stacked books", "study"];
}, {
    readonly name: "how_to_reg";
    readonly rank: 229;
    readonly popularity: 34602;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["accept", "access", "account", "add user", "approve", "authorization", "ballot", "check", "checkmark", "circle", "complete", "confirmed", "done", "election", "entry", "head", "how", "join", "mark", "member", "new user", "ok", "permission", "person", "poll", "profile", "register", "registration", "select", "shape", "shoulders", "sign up", "silhouette", "successful", "tick", "to reg", "user", "validate", "verified", "vote", "yes"];
}, {
    readonly name: "dns";
    readonly rank: 230;
    readonly popularity: 34549;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["abstract", "address", "administration", "bars", "circles", "communication", "configuration", "connection", "data", "dns", "domain", "domain name system", "dots", "globe", "hostname", "information", "internet", "ip", "ip address", "list", "lookup", "name", "network", "resolution", "server", "settings", "symbol", "system", "technology", "url", "website", "world"];
}, {
    readonly name: "double_arrow";
    readonly rank: 231;
    readonly popularity: 34439;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["abstract", "arrow", "arrowheads", "arrows", "bidirectional", "direction", "double", "double arrow", "exchange", "flow", "geometric", "indicator", "line", "minimal", "move", "movement", "multiple", "navigation", "opposite", "path", "pointed", "pointer", "reverse", "right", "rotate", "shift", "sign", "simple", "swap", "switch", "symbol", "transfer", "transport"];
}, {
    readonly name: "skip_next";
    readonly rank: 232;
    readonly popularity: 34435;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["advance", "arrow", "audio player", "bar", "button", "control", "controls", "fast forward", "forward", "jump", "media button", "media control", "media player", "move forward", "music", "navigation", "next", "next track", "play", "playback", "previous", "right arrow", "sequence", "skip", "skip next", "triangle", "vertical bar", "video", "video player"];
}, {
    readonly name: "forum";
    readonly rank: 233;
    readonly popularity: 34424;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["answers", "bubble", "chat", "comment", "comments", "communicate", "communication", "communication bubble", "community", "conversation", "debate", "dialogue", "discussion", "empty", "feedback", "forum", "help", "hub", "message", "online chat", "outline", "qa", "question_answer", "questions", "rectangle", "speaking", "speech", "speech balloon", "speech bubble", "support", "tail", "talk", "talk bubble", "talking", "thinking", "thought"];
}, {
    readonly name: "flight_takeoff";
    readonly rank: 234;
    readonly popularity: 34396;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["air", "air transport", "air travel", "aircraft", "airplane", "airplanes", "airport", "arrival", "arriving", "arrow", "ascending", "aviation", "departing", "departure", "diagonal", "flight", "flights", "fly", "flying", "journey", "landing", "mobility", "moving", "moving forward", "plane", "planes", "signal", "takeoff", "takeoff runway", "transport", "transportation", "travel", "trip", "up", "voyage", "wing"];
}, {
    readonly name: "signal_cellular_alt";
    readonly rank: 235;
    readonly popularity: 34381;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["alt", "analytics", "ascending bars", "bar", "bars", "cell", "cellular", "chart", "communication", "connection", "connectivity", "data", "device", "diagram", "full signal", "good signal", "graph", "indicator", "infographic", "internet", "level", "measure", "measurement", "metrics", "mobile", "mobile network", "network", "phone", "reception", "signal", "signal strength", "statistics", "status", "strength", "technology", "telecommunication", "tracking", "vertical bars", "wifi", "wireless"];
}, {
    readonly name: "volume_off";
    readonly rank: 236;
    readonly popularity: 34370;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["accessibility", "audio", "audio control", "audio off", "control", "cross out", "diagonal line", "disabled", "enabled", "forbidden", "hearing", "low", "media control", "multimedia", "music", "mute", "no sound", "off", "off state", "on", "prohibited", "quiet", "silent", "slash", "sound", "sound off", "speaker", "speaker off", "triangle", "tv", "volume", "volume control", "volume off"];
}, {
    readonly name: "security";
    readonly rank: 237;
    readonly popularity: 34123;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["access", "allowed", "authentication", "certified", "data security", "defense", "encrypted", "guard", "mobile security", "network security", "permission", "privacy", "privacy policy", "private", "protect", "protected", "protection", "safe", "safety", "secure", "secure access", "secure connection", "secure data", "security", "shield", "ssl", "system security", "trust", "trusted", "verified", "vpn", "web security"];
}, {
    readonly name: "folder_open";
    readonly rank: 238;
    readonly popularity: 33937;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["access", "archive", "browse", "collection", "computer", "container", "content", "data", "directory", "doc", "document", "drive", "expand", "explore", "file", "file management", "folder", "folders", "hierarchy", "information", "locate", "navigation", "open", "organization", "organize", "project", "retrieve", "reveal", "save", "sheet", "slide", "storage", "system", "tab", "view"];
}, {
    readonly name: "devices";
    readonly rank: 239;
    readonly popularity: 33869;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["Android", "OS", "cast", "communication", "computer", "connect", "connection", "connectivity", "data transfer", "desktop", "device", "devices", "display", "hardware", "iOS", "laptop", "link", "mobile", "monitor", "multiple devices", "network", "phone", "remote control", "screen", "screen mirroring", "sharing", "smartphone", "streaming", "sync", "synchronize", "tablet", "technology", "transfer", "watch", "wearable", "web"];
}, {
    readonly name: "chat_bubble";
    readonly rank: 240;
    readonly popularity: 33839;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["bubble", "chat", "chat outline", "chatbox", "comment", "communicate", "communication", "communication bubble", "contact", "conversation", "dialog", "dialogue", "discuss", "feedback", "forum", "help", "interaction", "message", "message outline", "messaging", "new message", "notification", "social", "speak", "speech", "speech outline", "support", "talk", "text", "texting", "thoughts"];
}, {
    readonly name: "cloud";
    readonly rank: 241;
    readonly popularity: 33719;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["air", "atmosphere", "climate", "cloud", "cloudy", "connection", "environment", "filled", "forecast", "graphic", "icon", "internet", "meteorology", "minimal", "nature", "network", "outline", "overcast", "queue", "rain", "round", "rounded", "shape", "simple", "sky", "snow", "solid", "symbol", "temperature", "ui", "ui element", "upload", "weather", "white"];
}, {
    readonly name: "content_paste";
    readonly rank: 242;
    readonly popularity: 33719;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "add", "application", "attach", "button", "clip", "clipboard", "content", "control", "copy", "cut", "data", "doc", "document", "edit", "entry", "file", "fill", "form", "function", "insert", "memo", "multiple", "notes", "office", "paper", "paste", "productivity", "record", "report", "sheet", "text", "tool", "write"];
}, {
    readonly name: "fiber_manual_record";
    readonly rank: 243;
    readonly popularity: 33691;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["active", "alert", "audio", "broadcast", "button", "circle", "connection", "current", "dot", "fiber", "filled circle", "indicator", "live", "manual", "marker", "media", "notification", "online", "play", "point", "presence", "record", "recording", "session", "signal", "solid circle", "status", "streaming", "video", "watch"];
}, {
    readonly name: "alarm";
    readonly rank: 244;
    readonly popularity: 33355;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "adjust", "alarm", "alert", "appointment", "bell", "calendar", "circle", "clock", "control", "countdown", "date", "deadline", "future", "hands", "history", "indicator", "manage", "mark", "notification", "point", "reminder", "ring", "schedule", "setting", "sound", "time", "timer", "wake up", "watch"];
}, {
    readonly name: "text_snippet";
    readonly rank: 245;
    readonly popularity: 33196;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["article", "character", "communication", "content", "data", "doc", "document", "excerpt", "extract", "file", "fragment", "information", "language", "letter", "literature", "note", "notes", "partial", "piece", "portion", "preview", "quotation", "quote", "reading", "report", "section", "segment", "snippet", "storage", "summary", "text", "typography", "words", "writing"];
}, {
    readonly name: "my_location";
    readonly rank: 246;
    readonly popularity: 33089;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["area", "center location", "circle", "compass", "coordinates", "current location", "destination", "detection", "direction", "find location", "fixed location", "geographic", "geolocate", "gps", "locate me", "location", "map", "maps", "marker", "my location", "navigation", "pin", "pinpoint", "place", "point", "position", "precise", "spot", "stop", "target location", "track location", "user location", "where am i"];
}, {
    readonly name: "sports_esports";
    readonly rank: 247;
    readonly popularity: 32885;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["asset", "competitive gaming", "computer games", "console", "console controller", "console games", "control", "controller", "device", "digital", "digital entertainment", "entertainment", "esports", "game", "game console", "game controller", "game input", "gamepad", "gaming", "gaming controller", "google", "handheld", "hardware", "hobby", "joystick", "leisure", "online", "online gaming", "play", "play games", "playstation", "remote", "social", "sports", "stadia", "technology", "tournament", "video", "video game", "video game controller", "video games", "videogame", "xbox"];
}, {
    readonly name: "workspace_premium";
    readonly rank: 248;
    readonly popularity: 32792;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["achievement", "approval", "authentic", "authority", "award", "badge", "certification", "circle", "degree", "ecommerce", "emblem", "excellence", "geometric", "guarantee", "honor", "mark", "medal", "medallion", "official", "permit", "points", "premium", "quality", "recognition", "reward", "ribbon", "seal", "shape", "stamp", "star", "status", "symbol", "verification", "verified", "winner", "workspace"];
}, {
    readonly name: "request_quote";
    readonly rank: 249;
    readonly popularity: 32556;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["ask for a quote", "asking", "bill", "bubble", "business", "card", "cash", "chat", "coin", "comment", "commerce", "communication", "conversation", "cost", "credit", "currency", "dialog", "dialogue", "dollars", "estimate", "finance", "inquiry", "message", "money", "online", "pay", "payment", "price", "pricing", "quotation", "quote", "rectangle", "request", "request a quote", "shape", "shopping", "speech", "speech bubble", "square", "symbol", "talk", "text", "transaction"];
}, {
    readonly name: "rocket_launch";
    readonly rank: 250;
    readonly popularity: 32444;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accelerate", "ascent", "astronaut", "boost", "cosmic", "exploration", "fast", "flight", "forward", "ignition", "journey", "launch", "lift off", "mission", "momentum", "new", "progress", "projectile", "quick", "rocket", "science fiction", "space", "spaceship", "speed", "start", "startup", "successful", "takeoff", "thrust", "transport", "upward", "vehicle"];
}, {
    readonly name: "cached";
    readonly rank: 251;
    readonly popularity: 32261;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "around", "arrows", "cache", "cached", "circle", "cloud", "connection", "data", "database", "directory", "download", "files", "folder", "information", "inprogress", "load", "loading refresh", "loop", "memory", "network", "offline", "processing", "refresh", "reload", "renew", "retrieve", "rotate", "save", "server", "storage", "store", "sync", "synchronize", "system", "two arrows", "update"];
}, {
    readonly name: "speed";
    readonly rank: 252;
    readonly popularity: 32243;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["acceleration", "arrow", "automotive", "car", "circle", "circular", "control", "controls", "dashboard", "data", "decreasing", "dial", "fast", "gauge", "increasing", "indicator", "information", "lines", "measurement", "meter", "motion", "music", "needle", "performance", "pointed", "progress", "setting", "settings", "slow", "speed", "speedometer", "ticks", "values", "velocity", "video"];
}, {
    readonly name: "toggle_off";
    readonly rank: 253;
    readonly popularity: 32085;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["action", "active", "button", "choice", "circle", "components", "configuration", "control", "device", "disable", "disabled", "elliptical", "inable", "inactive", "indicator", "interface", "interface control", "management", "off", "on", "on-off", "on/off", "option", "oval", "power", "preference", "preference control", "selection", "setting", "settings", "site", "slider", "slider switch", "state", "status", "switch", "system", "toggle", "ui", "ui control", "ux", "web", "website"];
}, {
    readonly name: "question_mark";
    readonly rank: 254;
    readonly popularity: 31929;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["?", "ask", "assistance", "circle", "clue", "curious", "curve", "dot", "doubt", "education", "faq", "glyph", "guidance", "help", "hint", "info", "information", "inquire", "interrogation", "learning", "mark", "problem", "punctuation", "puzzle", "query", "question mark", "stroke", "support", "symbol", "unknown", "unsure"];
}, {
    readonly name: "space_dashboard";
    readonly rank: 255;
    readonly popularity: 31913;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["analytics", "arrangement", "blocks", "cards", "composition", "dashboard", "dashboard view", "data", "display", "format", "grid", "layout", "layout arrangement", "metrics", "modular", "module", "organize", "overview", "panels", "rectangle", "rectangular", "report", "sections", "segments", "shapes", "space", "square", "squares", "structure", "system", "tiles", "view", "web", "website", "windows"];
}, {
    readonly name: "stop";
    readonly rank: 256;
    readonly popularity: 31723;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["action", "audio", "basic", "block", "button", "close", "command", "control", "control panel", "controls", "end", "exit", "filled", "finish", "geometric", "halt", "icon", "media", "music", "pause", "play", "playback", "player", "recorder", "recording", "shape", "simple", "solid", "square", "stop", "symbol", "video"];
}, {
    readonly name: "report";
    readonly rank: 257;
    readonly popularity: 31679;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["!", "abuse", "alert", "attention", "caution", "complaint", "danger", "error", "exclamation", "feedback", "flag", "important", "issue", "mark", "notification", "octagon", "outline", "problem", "report", "send", "shape", "spam", "stroke", "submit", "symbol", "triangle", "warning"];
}, {
    readonly name: "bug_report";
    readonly rank: 258;
    readonly popularity: 31655;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alert", "animal", "application", "bug", "case", "circle", "communicate", "complaint", "creature", "debugging", "document", "error", "feedback", "file", "fix", "help", "insect", "issue", "message", "note", "notify", "paper", "problem", "report", "software", "submit", "support", "system", "testing", "ticket", "troubleshooting", "virus", "warning"];
}, {
    readonly name: "book";
    readonly rank: 259;
    readonly popularity: 31637;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["academic", "academy", "book", "book icon", "bookmark", "class", "class icon", "course", "education", "education icon", "favorite", "knowledge", "knowledge icon", "label", "learning", "learning icon", "library", "literature", "literature icon", "novel", "open book", "open book icon", "read", "reading", "reading icon", "reading material", "remember", "ribbon", "save", "school", "school icon", "study", "tag", "textbook", "university", "university icon"];
}, {
    readonly name: "contact_page";
    readonly rank: 260;
    readonly popularity: 31568;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "address book", "avatar", "book", "business", "circle", "contact", "data", "details", "directory", "doc", "document", "drive", "face", "file", "folder", "folders", "form", "human", "icon", "identity", "information", "list", "office", "outline", "page", "paper", "people", "person", "personal", "profile", "record", "rectangle", "shape", "sheet", "slide", "square", "storage", "symbol", "user", "writing"];
}, {
    readonly name: "sentiment_very_satisfied";
    readonly rank: 261;
    readonly popularity: 31548;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["approval", "avatar", "character", "cheerful", "circle", "delight", "emoticon", "emotion", "emotions", "excellent", "expression", "expressions", "face", "feedback", "feeling", "feelings", "glad", "happiness", "happy", "human", "joyful", "like", "mood", "people", "person", "pleased", "positive", "profile", "rating", "satisfied", "sentiment", "simple", "smile", "smiley face", "smiling", "survey", "user", "very", "very happy"];
}, {
    readonly name: "translate";
    readonly rank: 262;
    readonly popularity: 31506;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrow", "bidirectional", "bubble", "change", "chat", "communication", "conversion", "dictionary", "direction", "double", "exchange", "global", "international", "language", "left", "linguistics", "meaning", "phrase", "right", "speak", "speaking", "speech", "swap", "talk", "text", "translate", "translator", "word", "words"];
}, {
    readonly name: "gavel";
    readonly rank: 263;
    readonly popularity: 31455;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agreement", "attorney", "auction", "authority", "command", "contract", "court", "courtroom", "decision", "document", "formal", "gavel", "government", "hammer", "judge", "judgment", "judgment call", "judiciary", "justice", "law", "lawyer", "legal", "legal proceedings", "legislation", "mallet", "official", "order", "police", "rule", "rules", "terms", "trial", "verdict", "wood", "wood object"];
}, {
    readonly name: "edit_calendar";
    readonly rank: 264;
    readonly popularity: 31378;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agenda", "annotate", "appointment", "booking", "calendar", "change", "compose", "create", "date", "day", "deadline", "draft", "edit", "editing", "element", "event", "icon", "interface", "manage", "modify", "month", "organizer", "pen", "pencil", "planner", "reminder", "reschedule", "schedule", "symbol", "timestamp", "update", "write", "writing", "year"];
}, {
    readonly name: "file_copy";
    readonly rank: 265;
    readonly popularity: 31255;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["archive", "backup", "clone", "content", "copy", "create copy", "cut", "data", "doc", "document", "duplicate", "entry", "file", "form", "information", "make a copy", "memo", "multiple", "note", "page", "paperwork", "past", "paste", "print", "record", "record book", "report", "save a copy", "sheet", "stack", "text", "transcript", "version"];
}, {
    readonly name: "cloud_download";
    readonly rank: 266;
    readonly popularity: 31195;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["access", "app", "application", "arrow", "backup", "cloud", "cloud computing", "cloud storage", "computer", "connection", "data", "document", "down", "download", "download file", "drive", "file", "files", "folders", "get", "internet", "move", "network", "receive", "retrieve", "save", "server", "sky", "storage", "sync", "synchronization", "transfer", "transfer file", "upload"];
}, {
    readonly name: "person_search";
    readonly rank: 267;
    readonly popularity: 31116;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["account", "avatar", "body", "circle", "contact", "contact search", "diagonal line", "discover", "face", "find", "find contact", "find friend", "find person", "find profile", "find user", "friend", "friend search", "glass", "handle", "head", "human", "investigate", "locate contact", "locate person", "locate profile", "locate user", "look", "lookup", "loupe", "magnify", "magnifying", "magnifying glass", "people", "person", "person search", "profile", "profile search", "search", "silhouette", "torso", "user", "user search", "zoom"];
}, {
    readonly name: "pan_tool";
    readonly rank: 268;
    readonly popularity: 31092;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["application", "control", "cursor", "drag", "editor", "fingers", "gesture", "glove", "grab", "graphic", "hand", "hands", "hold", "human", "icon", "interface element", "manipulation", "map", "move", "navigation", "pan", "pointer", "position", "scan", "select", "software", "stop", "symbol", "tool", "view"];
}, {
    readonly name: "quiz";
    readonly rank: 269;
    readonly popularity: 31037;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["?", "academic", "answer", "assessment", "assistance", "certification", "challenge", "clipboard", "comprehension", "document", "e-learning", "education", "evaluate", "evaluation", "exam", "faq", "feedback", "game", "grade", "help", "info", "information", "knowledge", "learning", "paper", "poll", "punctuation", "question mark", "questions", "quiz", "report", "results", "review", "score", "study", "support", "survey", "symbol", "test", "trivia"];
}, {
    readonly name: "supervised_user_circle";
    readonly rank: 270;
    readonly popularity: 30719;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "account settings", "avatar", "child", "circle", "control", "face", "family", "figure", "guardian", "head", "human", "kid", "limited access", "monitored", "parent", "parental", "parents", "people", "person", "privacy", "profile", "restricted", "safety", "secure", "shoulders", "silhouette", "supervised", "supervised user circle", "supervision", "supervisor", "user", "user avatar", "user profile", "youth"];
}, {
    readonly name: "desktop_windows";
    readonly rank: 271;
    readonly popularity: 30699;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["Android", "OS", "cast", "chrome", "computer", "desktop", "device", "digital", "display", "electronic", "hardware", "home", "iOS", "mac", "mirroring", "monitor", "office", "pc", "presentation", "rectangular", "remote", "screen", "sharing", "technology", "television", "tv", "web", "window", "windows", "work", "workstation"];
}, {
    readonly name: "qr_code";
    readonly rank: 272;
    readonly popularity: 30687;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["2d barcode", "access", "barcode", "camera", "code", "computer", "connect", "contactless", "data matrix", "decode", "device", "digital code", "identification", "information", "link", "machine readable", "media", "mobile", "modern", "pattern", "payment", "product", "qr", "qr code", "quick", "quick response code", "read", "response", "scan", "scannable", "share", "smartphone", "square", "technology", "transaction", "url", "urls", "verification", "website"];
}, {
    readonly name: "contact_mail";
    readonly rank: 273;
    readonly popularity: 30561;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["account", "address", "address book", "avatar", "business card", "communicate", "communication", "connection", "contact", "contact information", "correspondence", "details", "digital mail", "directory", "email", "envelope", "face", "human", "inbox", "info", "information", "letter", "mail", "message", "network", "online communication", "people", "person", "personal", "postcard", "profile", "receive", "send", "user", "user data", "user profile"];
}, {
    readonly name: "minimize";
    readonly rank: 274;
    readonly popularity: 30535;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "app", "application", "bar", "basic", "bottom", "button", "close", "collapse", "compact", "components", "contract", "control", "design", "down", "element", "essential", "exit", "hide", "horizontal", "interaction", "interface", "less", "line", "minimize", "reduce", "remove", "screen", "shape", "shrink", "simple", "site", "smaller", "standard", "system", "ui", "ux", "web", "website", "window"];
}, {
    readonly name: "location_city";
    readonly rank: 275;
    readonly popularity: 30221;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["apartments", "architecture", "area", "building", "buildings", "business", "city", "community", "construction", "destination", "district", "downtown", "estate", "geography", "home", "landmark", "landscape", "location", "map marker", "metropolis", "neighborhood", "place", "point of interest", "real", "real estate", "rectangle", "region", "residence", "residential", "shelter", "skyline", "square", "structure", "town", "travel", "urban"];
}, {
    readonly name: "extension";
    readonly rank: 276;
    readonly popularity: 30127;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["addon", "app", "browser-extension", "compatibility", "component", "connect", "connection", "extended", "extension", "feature", "fit", "game", "integration", "interlocking", "jigsaw", "logic", "modular", "module", "piece", "plugin", "plugin add", "problem-solving", "puzzle", "shape", "software", "solve", "system", "tool", "utility"];
}, {
    readonly name: "widgets";
    readonly rank: 277;
    readonly popularity: 29904;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["add", "app", "arrange", "blocks", "box", "boxes", "components", "customize", "dashboard", "display", "elements", "grid", "layout", "menu", "modules", "mosaic", "options", "organize", "panels", "personalize", "rearrange", "rectangles", "remove", "sections", "setting", "settings", "squares", "ui", "view", "widgets"];
}, {
    readonly name: "flight";
    readonly rank: 278;
    readonly popularity: 29580;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["ai", "air", "air travel", "aircraft", "airplane", "airplanes", "airport", "arrival", "arrow", "artificial intelligence", "automation", "clover", "departure", "direction", "flight", "flight mode", "flights", "fly", "flying", "flying mode", "forward", "genai", "icon", "intelligence", "jet", "magic", "mode", "move", "navigation", "on", "plane", "planes", "point", "settings", "signal", "silhouette", "sky", "spark", "sparkle", "speed", "star", "symbol", "transport", "transportation", "travel", "trip", "vehicle"];
}, {
    readonly name: "ios_share";
    readonly rank: 279;
    readonly popularity: 29533;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["action", "app", "apple", "arrow", "box", "button", "communication", "connect", "content", "distribute", "export", "forward", "ios", "link", "menu", "mobile", "network", "post", "publish", "rectangle", "send", "share", "sharing", "social", "square", "transfer", "up", "upload"];
}, {
    readonly name: "precision_manufacturing";
    readonly rank: 280;
    readonly popularity: 29427;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accurate", "advanced", "arm", "assembly", "assembly line", "automated", "automatic", "automation", "automation arm", "chain", "conveyor", "crane", "create", "engineering", "fabrication", "factory", "industrial", "industrial automation", "industrial machinery", "industrial robot", "industry", "machine", "machinery", "manufacturing", "manufacturing process", "mechanic", "mechanical", "precise", "precision", "precision manufacturing", "produce", "production", "repairing", "robot", "robotic arm", "robotics", "supply", "technology", "warehouse"];
}, {
    readonly name: "fitness_center";
    readonly rank: 281;
    readonly popularity: 29224;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["active", "athlete", "athletics", "barbell", "bodybuilding", "center", "dumbbell", "exercise", "fitness", "fitness center", "fitness club", "gym", "gym class", "gym equipment", "health", "health club", "hobby", "lifting", "muscle", "personal training", "physical activity", "places", "sport", "strength", "training", "training equipment", "weightlifting", "weights", "workout", "workout center"];
}, {
    readonly name: "music_note";
    readonly rank: 282;
    readonly popularity: 29106;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["audio", "audio file", "audio icon", "audiotrack", "clef", "composition", "eighth note", "key", "listen", "media", "media controls", "melody", "music", "music icon", "musical", "note", "play", "player", "playlist", "quaver", "rhythm", "score", "song", "sound", "sound icon", "track", "tune", "waveform"];
}, {
    readonly name: "qr_code_2";
    readonly rank: 283;
    readonly popularity: 29071;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["2d barcode", "barcode", "business", "camera", "code", "connection", "contact", "data", "digital", "encoding", "identification", "information", "link", "machine readable", "marketing", "matrix code", "media", "mobile", "pattern", "payment", "product", "qr", "qr code", "quick", "quick response code", "reading", "response", "scan", "scanner", "sharing", "smartphone", "square", "square code", "technology", "url", "urls", "website"];
}, {
    readonly name: "local_mall";
    readonly rank: 284;
    readonly popularity: 29037;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["bag", "basket", "bill", "boutique", "building", "business", "buy", "buying", "card", "cart", "cash", "coin", "commerce", "commercial", "consumer", "consumerism", "credit", "currency", "department store", "dollars", "e-commerce", "goods", "handbag", "items", "local", "mall", "market", "marketplace", "money", "online", "outlet", "pay", "payment", "products", "purchase", "purchasing", "retail", "retail store", "shop", "shopping", "shopping bag", "shopping center", "store", "storefront"];
}, {
    readonly name: "android";
    readonly rank: 285;
    readonly popularity: 28596;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alien", "android", "antenna", "application", "brand", "bugdroid", "character", "developer", "device", "digital", "eyes", "google", "head", "logo", "mascot", "mobile", "operating system", "os", "platform", "robot", "smart", "smartphone", "software", "system", "tech", "technology", "toy"];
}, {
    readonly name: "near_me";
    readonly rank: 286;
    readonly popularity: 28324;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["area", "arrow", "compass", "current location", "destination", "direction", "directions", "discover", "explore", "find", "geolocation", "geotagging", "local", "locate", "locate me", "locate user", "location", "maps", "me", "my location", "navigation", "near", "nearby", "neighborhood", "pin", "pinpoint", "place", "point", "pointer", "points of interest", "position", "precise", "precise location", "stop", "travel", "vicinity"];
}, {
    readonly name: "storage";
    readonly rank: 287;
    readonly popularity: 28314;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["archive", "backup", "boxes", "capacity", "cloud", "computer", "computing", "data", "database", "digital", "disk", "documents", "drive", "files", "hard drive", "horizontal", "information", "layers", "lines", "memory", "rectangle", "save", "server", "server rack", "space", "square", "stack", "storage", "technology", "vertical"];
}, {
    readonly name: "record_voice_over";
    readonly rank: 288;
    readonly popularity: 28292;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "announce", "audio", "avatar", "broadcast", "character", "circle", "commentary", "communicate", "dictation", "face", "geometric", "human", "lines", "microphone", "narrate", "narration", "outline", "over", "people", "person", "person speaking", "person talking", "profile", "record", "recording", "silhouette", "sound", "speak", "speaking", "speech", "studio", "talk", "transcript", "user", "voice", "voice over"];
}, {
    readonly name: "backspace";
    readonly rank: 289;
    readonly popularity: 28288;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["arrow", "back", "backspace", "box", "button", "cancel", "character", "clear", "computer", "control", "correct", "delete", "edit", "editing", "entry", "erase", "form", "input", "input field", "keyboard", "left", "navigation", "pointed", "rectangular", "remove", "symbol", "text", "triangle", "typing", "ui", "undo", "ux"];
}, {
    readonly name: "shield";
    readonly rank: 290;
    readonly popularity: 28244;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["access", "authorized", "certified", "confidential", "cyber security", "data security", "defense", "digital security", "encryption", "internet security", "lock", "network security", "online security", "permission", "privacy", "private", "protect", "protection", "safe", "safeguard", "safety", "secret", "secure", "secure connection", "security", "shield", "ssl", "tls", "verified", "vpn", "web security"];
}, {
    readonly name: "drag_handle";
    readonly rank: 291;
    readonly popularity: 28120;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["action", "app", "application ui", "bars", "components", "control", "design", "drag", "element", "grip", "handle", "handle.", "indicator", "interactive", "interface", "item", "layout", "lines", "list", "list item", "menu", "move", "parallel", "rearrange", "reorder", "reordering", "screen", "site", "sort", "sortable", "three lines", "ui", "ux", "vertical", "web", "website", "widget", "window"];
}, {
    readonly name: "smart_display";
    readonly rank: 292;
    readonly popularity: 28118;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["airplay", "appliance", "automation", "base", "cast", "chrome", "connect", "connected", "connected device", "control", "device", "digital assistant", "display", "electronic", "entertainment", "entertainment device", "home", "home control", "household", "information", "interactive", "kitchen", "living room", "media", "monitor", "play", "rectangular", "screen", "screencast", "smart", "smart display", "smart home", "stand", "stream", "technology", "television", "touch screen", "tv", "video", "voice assistant", "voice control"];
}, {
    readonly name: "accessibility";
    readonly rank: 293;
    readonly popularity: 28077;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "accessibility", "accessible", "aid", "assistance", "barrier-free", "body", "disability", "disabled", "easy access", "feature", "figure", "handicap", "help", "human", "inclusion", "inclusive", "inclusivity", "mobility", "navigation", "options", "people", "person", "pictogram", "ramp", "services", "setting", "special needs", "support", "symbol", "universal", "wheelchair"];
}, {
    readonly name: "add_task";
    readonly rank: 294;
    readonly popularity: 27954;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["+", "accept", "add", "addition", "agenda", "approve", "assignment", "check", "checkbox", "checkmark", "circle", "complete", "completed", "create", "done", "goal", "increase", "insert", "list", "manage", "mark", "new", "ok", "plus", "positive", "project", "reminder", "schedule", "select", "task", "tick", "todo", "work", "yes"];
}, {
    readonly name: "handyman";
    readonly rank: 295;
    readonly popularity: 27669;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["adjust", "build", "builder", "cog", "configuration", "construction", "craftsman", "customize", "engineering", "equipment", "fix", "gear", "hammer", "handyman", "job", "maintenance", "mechanic", "options", "preferences", "professional", "repair", "screw", "screwdriver", "service", "settings", "spanner", "toolbox", "tools", "utility", "work", "workshop", "wrench"];
}, {
    readonly name: "science";
    readonly rank: 296;
    readonly popularity: 27643;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["analysis", "beaker", "beaker icon", "chemical", "chemistry", "chemistry icon", "container", "discovery", "education", "experiment", "experiment icon", "flask", "fluid", "glass", "glassware", "innovation", "knowledge", "lab", "lab icon", "laboratory", "learning", "liquid", "reaction", "research", "research icon", "science", "scientific", "solution", "study", "test tube", "tube"];
}, {
    readonly name: "show_chart";
    readonly rank: 297;
    readonly popularity: 27640;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["analysis", "analytics", "bar", "bars", "business", "chart", "data", "diagram", "display", "economy", "finance", "graph", "growth", "infographic", "line", "line chart", "measure", "metrics", "performance", "plotting", "presentation", "progress", "report", "show", "show chart", "statistics", "stock", "tracking", "trends", "view", "visualization"];
}, {
    readonly name: "hourglass_empty";
    readonly rank: 298;
    readonly popularity: 27603;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["abstract", "clock", "countdown", "delay", "duration", "empty", "full", "future", "history", "hourglass", "indicator", "interval", "lapse", "loading", "measure", "minutes", "outline", "passage", "past", "pending", "period", "processing", "progress", "sand", "shape", "status", "time", "timer", "ui element", "wait", "waiting"];
}, {
    readonly name: "west";
    readonly rank: 299;
    readonly popularity: 27476;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "away", "back", "chevron", "direction", "directional", "exit", "guide", "indicator", "journey", "left", "map", "maps", "move", "navigation", "orientation", "path", "point", "pointer", "previous", "retreat", "return", "route", "signage", "travel", "triangle", "undo", "voyage", "way", "west", "withdraw"];
}, {
    readonly name: "help_center";
    readonly rank: 300;
    readonly popularity: 27348;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["?", "advice", "aid", "ask", "assistance", "center", "circle", "customer service", "documentation", "dot", "faq", "guide", "help", "help center", "info", "information", "information symbol", "knowledge base", "learn", "manual", "punctuation", "query", "query symbol", "question", "question mark", "recent", "resource", "restore", "service", "shape", "suggestion", "support", "symbol", "tutorial"];
}, {
    readonly name: "military_tech";
    readonly rank: 301;
    readonly popularity: 27141;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accomplishment", "achievement", "air force", "army", "award", "badge", "decoration", "defense", "excellence", "guarantee", "high quality", "honor", "insignia", "marines", "medal", "merit", "military", "navy", "order", "premium", "privilege", "prize", "quality", "rank", "ranking", "reward", "ribbon", "soldier", "star", "status", "success", "symbol", "tech", "technology", "trophy", "verified", "veteran", "warfare", "win", "winner"];
}, {
    readonly name: "directions_run";
    readonly rank: 302;
    readonly popularity: 27132;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["activity", "athlete", "beginning", "body", "destination", "directions", "exercise", "figure", "fitness", "human", "jogging", "location", "map", "maps", "marathon", "movement", "navigation", "path", "people", "person", "pin", "point", "race", "route", "run", "running", "silhouette", "sports", "sprint", "start", "track", "training", "walk", "walking"];
}, {
    readonly name: "sentiment_satisfied";
    readonly rank: 303;
    readonly popularity: 27070;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["cheerful", "circle", "emoji", "emoticon", "emotion", "emotions", "expression", "expressions", "eyes", "face", "feeling", "feelings", "glad", "happiness", "happy", "happy face", "joy", "like", "mood", "mouth", "person", "pleased", "positive", "satisfaction", "satisfied", "sentiment", "smile", "smiley", "smiley face", "smiling", "survey"];
}, {
    readonly name: "trending_flat";
    readonly rank: 304;
    readonly popularity: 26843;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrow", "average", "change", "chart", "constant", "data", "direction", "equal", "flat", "forward arrow", "graph", "horizontal arrow", "indicator", "level", "line", "metric", "movement", "no change", "normal", "progress", "rate", "representation", "right", "right arrow", "stable", "standard", "status", "steady", "straight arrow", "track", "tracking", "trend", "trending", "trending flat", "visual"];
}, {
    readonly name: "rule";
    readonly rank: 305;
    readonly popularity: 26668;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["approve", "automation", "check", "command", "commands", "complete", "condition", "conditions", "configuration", "configurations", "criteria", "done", "govern", "guideline", "guidelines", "incomplete", "instruction", "instructions", "law", "laws", "line", "logic", "mark", "missing", "no", "ok", "policies", "policy", "principle", "principles", "regulate", "regulation", "regulations", "rule", "rules", "select", "setting", "settings", "standard", "standards", "tick", "validate", "verified", "workflow", "wrong", "x", "yes"];
}, {
    readonly name: "emoji_objects";
    readonly rank: 306;
    readonly popularity: 26403;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["avatar", "bulb", "cartoon", "character", "chat", "cheerful", "circle", "communication", "creative", "emoji", "emoticon", "expression", "face", "feeling", "happy", "idea", "joy", "light", "message", "objects", "positive", "reaction", "round", "smile", "smiley", "solution", "thinking"];
}, {
    readonly name: "movie";
    readonly rank: 307;
    readonly popularity: 26356;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["action", "camera", "cinema", "clapper", "clapperboard", "clip", "creation", "diagonal", "director", "editor", "entertainment", "film", "filmmaking", "hollywood", "media", "movie", "multimedia", "production", "recording", "rectangle", "shoot", "show", "slate", "stripes", "studio", "take", "video"];
}, {
    readonly name: "thumb_down";
    readonly rank: 308;
    readonly popularity: 26259;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["ate", "cancel", "disagree", "disapproval", "dislike", "down", "favorite", "feedback", "fingers", "gesture", "hand", "hand gesture", "hands", "hate", "like", "negative", "negative feedback", "no", "opposite", "rank", "ranking", "rating", "refusal", "reject", "rejection", "thumb", "thumbs down", "unlike", "unlike button", "vote", "vote down"];
}, {
    readonly name: "accessibility_new";
    readonly rank: 309;
    readonly popularity: 26215;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "accessibility", "accessibility icon", "accessibility statement", "accessible", "assistance", "barrier-free", "body", "disability", "disabled", "figure", "handicap", "help", "human", "inclusion", "inclusive", "moving", "needs", "new", "outline", "people", "person", "pictogram", "shape", "silhouette", "special needs", "standing", "support", "symbol", "universal access", "user"];
}, {
    readonly name: "confirmation_number";
    readonly rank: 310;
    readonly popularity: 25768;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["access", "account", "admission", "authorization", "booking", "code", "confirmation", "credential", "digits", "entertainment", "entry", "event", "identifier", "key", "lock", "login", "number", "numbers", "order", "pass", "password", "pin", "receipt", "reference", "reservation", "secret", "secure", "sequence", "symbol", "ticket", "token", "unique", "validation", "verification"];
}, {
    readonly name: "event_note";
    readonly rank: 311;
    readonly popularity: 25730;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["activity", "agenda", "appointment", "booking", "calendar", "date", "diary", "document", "due date", "entry", "event", "important", "journal", "list", "meeting", "memo", "note", "organize", "paper", "plan", "planning", "record", "reminder", "reservations", "schedule", "task", "tasks", "text", "time", "timelog", "timestamp", "to do", "writing"];
}, {
    readonly name: "ads_click";
    readonly rank: 312;
    readonly popularity: 25661;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["ads", "ads click", "advertisement", "analytics", "arrow", "browser", "button", "call to action", "campaign", "click", "clicks", "conversion", "cursor", "destination", "digital", "engagement", "finger", "interaction", "internet", "link", "marketing", "measurement", "network", "online", "performance", "pointer", "promotion", "reach", "select", "tap", "target", "touch", "tracking", "traffic", "web"];
}, {
    readonly name: "comment";
    readonly rank: 313;
    readonly popularity: 25629;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["add", "add comment", "balloon", "bubble", "chat", "comment", "communicate", "communication", "conversation", "create", "create comment", "dialogue", "discussion", "feedback", "insert", "message", "new", "new comment", "outline", "plus", "rectangle", "reply", "respond", "speech", "square", "square bubble", "talk", "text", "text bubble", "write comment"];
}, {
    readonly name: "format_quote";
    readonly rank: 314;
    readonly popularity: 25573;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["block quote", "citation", "citation format", "closing quote", "comment", "content", "dialogue", "doc", "document", "double quotes", "edit", "editing", "editor", "editorial", "format", "format quote", "opening quote", "paragraph", "punctuation", "quotation", "quotation mark", "quote", "quote marks", "quote symbol", "reference", "sheet", "speech", "spreadsheet", "text", "text formatting", "type", "typography", "writing"];
}, {
    readonly name: "contacts";
    readonly rank: 315;
    readonly popularity: 25458;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["account", "accounts", "address book", "avatar", "avatars", "call", "cell", "communication", "connect", "connection", "contact", "contacts", "directory", "face", "figures", "friends", "group", "human", "humans", "info", "information", "list", "management", "member", "members", "mobile", "network", "people", "person", "phone", "profile", "profiles", "silhouette", "social", "team", "user", "users"];
}, {
    readonly name: "business_center";
    readonly rank: 316;
    readonly popularity: 25412;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["accessory", "assets", "bag", "baggage", "belongings", "box", "briefcase", "business", "career", "carrying", "case", "center", "commerce", "container", "corporate", "goods", "handle", "holding", "item", "job", "luggage", "object", "office", "personal", "places", "portfolio", "professional", "purse", "rectangle", "storage", "strap", "suitcase", "travel", "work"];
}, {
    readonly name: "upload";
    readonly rank: 317;
    readonly popularity: 25390;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["add", "arrow", "arrows", "attach", "backup", "cloud", "data", "direction", "document", "download", "drive", "export", "file", "import", "input", "internet", "memory", "move", "network", "open", "pointer", "publish", "save", "select", "send", "server", "share", "store", "submit", "transfer", "up", "upload"];
}, {
    readonly name: "swap_vert";
    readonly rank: 318;
    readonly popularity: 25349;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrow", "arrows", "bidirectional", "connection", "data", "direction", "direction change", "document", "down", "exchange", "export", "file", "flow", "import", "interchange", "link", "move", "navigation", "process", "reorder", "shuffle", "sort", "sorting", "swap", "switch", "sync", "synchronize", "transaction", "transfer", "up", "up down", "vert", "vertical"];
}, {
    readonly name: "archive";
    readonly rank: 319;
    readonly popularity: 25269;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["archive", "archive box", "backup", "bin", "box", "categorize", "collection", "container", "data", "document", "file", "filing", "folder", "history", "inbox", "library", "mail", "manage", "memory", "organization", "organize", "past", "record", "rectangular", "repository", "retrieve", "save", "sort", "storage", "store", "symbol", "system"];
}, {
    readonly name: "settings_applications";
    readonly rank: 320;
    readonly popularity: 25100;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "administration", "app", "application", "applications", "change", "circle", "cog", "computer", "configuration", "configure", "control", "customize", "details", "device", "engineering", "gear", "gears", "industrial", "info", "information", "internet", "machinery", "manage", "mechanical", "mechanism", "mobile", "options", "personal", "preference", "service", "settings", "setup", "software", "system", "technology", "tools", "web", "wheel"];
}, {
    readonly name: "add_photo_alternate";
    readonly rank: 321;
    readonly popularity: 25089;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["+", "add", "addition", "album", "alternate", "art", "capture", "choose", "collection", "creation", "file", "gallery", "graphic", "image", "import", "insert", "landscape", "media", "mountain", "mountains", "new", "photo", "photography", "picture", "plus", "rectangle", "select", "square", "sun", "symbol", "upload", "visual"];
}, {
    readonly name: "query_stats";
    readonly rank: 322;
    readonly popularity: 25063;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["analysis", "analytics", "chart", "circle", "dashboard", "data", "diagram", "examine", "explore", "find", "glass", "graph", "infographic", "information", "insights", "investigate", "line", "look", "magnify", "magnifying", "magnifying glass", "measure", "measurement", "metrics", "monitoring", "performance", "query", "reporting", "research", "results", "review", "search", "see", "statistics", "stats", "tracking", "trends"];
}, {
    readonly name: "history_edu";
    readonly rank: 323;
    readonly popularity: 25043;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["academic", "archive", "book", "clock", "college", "degree", "diploma", "document", "edu", "education", "exam", "feather", "future", "graduation", "history", "hour", "knowledge", "learning", "lesson", "letters", "memory", "minute", "paper", "past", "pen", "present", "quill", "reading", "school", "second", "story", "student", "study", "teaching", "test", "time", "timeline", "tools", "university", "write", "writing"];
}, {
    readonly name: "skip_previous";
    readonly rank: 324;
    readonly popularity: 25036;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["arrow", "audio", "back", "bar", "beginning", "button", "control", "controls", "double line", "file", "go back", "history", "interface control", "line", "media", "media controls", "multimedia", "music", "next", "play", "playback", "player", "previous", "previous song", "previous track", "rewind", "skip", "skip previous", "song", "start", "track", "transport controls", "triangle", "ui icon", "vertical line", "video"];
}, {
    readonly name: "find_in_page";
    readonly rank: 325;
    readonly popularity: 24775;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["content search", "data", "doc", "document", "document icon", "document search", "drive", "file", "file icon", "file search", "find", "find icon", "find in page", "folder", "folders", "glass", "in", "information retrieval", "locate", "locate text", "look", "look up", "loupe", "magnifier", "magnify", "magnifying", "magnifying glass", "magnifying glass on document", "open document", "page", "page search", "paper", "paper search", "rectangle", "scan", "search", "search icon", "search tool", "see", "sheet", "sheet of paper", "slide", "text icon", "text search", "view document", "writing"];
}, {
    readonly name: "sticky_note_2";
    readonly rank: 326;
    readonly popularity: 24756;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["2", "angle", "bookmark", "communication", "corner", "data", "document", "fold", "ideas", "information", "list", "mark", "memo", "message", "note", "office", "organization", "page", "paper", "peel", "planning", "post it", "records", "rectangle", "reminder", "square", "stationery", "sticky", "sticky note", "tab", "task", "text", "thoughts", "work", "writing"];
}, {
    readonly name: "handshake";
    readonly rank: 327;
    readonly popularity: 24708;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accord", "agreement", "alliance", "business", "collaboration", "connection", "contract", "cooperation", "deal", "glyph", "greeting", "hand", "hands", "handshake", "joining hands", "line icon", "meeting", "negotiation", "outline", "partnership", "pictogram", "relationship", "shake", "solidarity", "support", "trust", "two hands", "unity", "welcome"];
}, {
    readonly name: "arrow_circle_right";
    readonly rank: 328;
    readonly popularity: 24669;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["app", "arrow", "arrow in circle", "button", "circle", "circular arrow", "continue", "control", "direction", "directional arrow", "forward", "geometry", "go", "graphic", "icon", "illustration", "interface element", "link", "move", "navigation", "next", "pointer", "proceed", "right", "right arrow", "shape", "symbol", "ui", "user interface", "ux", "web"];
}, {
    readonly name: "cake";
    readonly rank: 329;
    readonly popularity: 24545;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["add", "anniversary", "baked", "baked goods", "bakery", "birthday", "cake", "candle", "candles", "celebration", "confection", "delicious", "dessert", "edible", "event", "festive", "food", "frosting", "happy birthday", "holiday", "new", "occasion", "party", "pastries", "pastry", "patisserie", "plus", "slice", "snack", "social", "special occasion", "sugar", "sweet", "symbol", "treat"];
}, {
    readonly name: "credit_score";
    readonly rank: 330;
    readonly popularity: 24518;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["analysis", "approve", "assessment", "banking", "bill", "card", "cash", "check", "circle", "coin", "commerce", "complete", "cost", "credit", "credit score", "currency", "debt", "dial", "digits", "dollars", "done", "evaluation", "ficoscore", "finance", "financial", "gauge", "indicator", "level", "loan", "mark", "measurement", "meter", "money", "number", "numerical", "ok", "online", "pay", "payment", "performance", "personal finance", "progress", "ranking", "rating", "report", "score", "select", "summary", "symbol", "three digits", "tick", "validate", "verified", "yes"];
}, {
    readonly name: "dashboard_customize";
    readonly rank: 331;
    readonly popularity: 24493;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "arrange", "blocks", "boxes", "cards", "change", "configure", "control", "customize", "dashboard", "edit", "format", "grid", "layout", "management", "modify", "modules", "options", "organize", "panel", "personalize", "preferences", "rectangle", "reorganize", "settings", "setup", "shapes", "square", "squares", "tailor", "tiles", "view", "web", "website", "widget"];
}, {
    readonly name: "playlist_add";
    readonly rank: 332;
    readonly popularity: 24214;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["+", "add", "add to playlist", "audio", "audio list", "bar", "bars", "collection", "create", "create list", "file", "files", "item", "items", "library", "line", "lines", "list", "media", "media list", "music", "music list", "new", "new playlist", "playlist", "playlist add", "plus", "row", "rows", "song list", "sound", "symbol"];
}, {
    readonly name: "key";
    readonly rank: 333;
    readonly popularity: 24131;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["access", "access key", "authentication", "authorization", "code", "data", "decryption key", "digital", "door", "encryption", "encryption key", "entry", "information", "key", "lock", "login", "padlock", "password", "permission", "private", "private access", "private key", "secret", "secure", "secure access", "security", "technology", "unlock"];
}, {
    readonly name: "redeem";
    readonly rank: 334;
    readonly popularity: 24100;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["bill", "bonus", "bonus points", "bow", "buy", "card", "cart", "cash", "celebration", "certificate", "coin", "commerce", "coupon", "credit", "currency", "discount", "dollars", "event", "gift", "gift card", "giftcard", "giving", "holiday", "loyalty", "loyalty program", "money", "online", "pay", "payment", "present", "prize", "purchase", "rectangle", "redeem", "reward", "reward system", "ribbon", "shopping", "special offer", "transaction", "voucher"];
}, {
    readonly name: "loyalty";
    readonly rank: 335;
    readonly popularity: 24045;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["achievement", "award", "benefit", "benefits", "best", "bonus", "card", "client", "credit", "customer", "exclusive", "five point star", "gift", "good", "gratitude", "heart", "loyalty", "membership", "miles", "perk", "points", "points system", "premium", "present", "prize", "program", "quality", "recognition", "reward", "sparkle", "special", "star", "subscription", "tag", "travel", "trip", "value", "vip"];
}, {
    readonly name: "spa";
    readonly rank: 336;
    readonly popularity: 23972;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["aromatherapy", "bath", "beauty", "body", "flower", "glyph", "graphic", "health", "healthcare", "hot springs", "hotel", "icon", "leaf", "luxury", "massage", "meditation", "nature", "petals", "places", "rejuvenation", "relax", "relaxation", "resort", "sauna", "spa", "steam room", "symbol", "therapy", "treatment", "water", "wellbeing", "wellness"];
}, {
    readonly name: "layers";
    readonly rank: 337;
    readonly popularity: 23895;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["arrange", "composition", "content", "depth", "disabled", "display", "document", "enabled", "file", "group", "hierarchy", "interaction", "layers", "levels", "manage", "maps", "multiple", "off", "on", "order", "organize", "overlap", "overlay", "pages", "panels", "planes", "sections", "segments", "sheets", "slash", "stack", "structure", "view"];
}, {
    readonly name: "support";
    readonly rank: 338;
    readonly popularity: 23852;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["advice", "agent", "assist", "assistance", "avatar", "basic", "buoy", "call", "common", "communication", "contact", "essential", "general", "head", "headphones", "headset", "help", "human", "information", "life", "lifebuoy", "line art", "outline", "person", "phone", "question", "representative", "rescue", "safe", "safety", "service", "silhouette", "simple", "support", "universal"];
}, {
    readonly name: "wb_sunny";
    readonly rank: 339;
    readonly popularity: 23805;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["balance", "beams", "bright", "celestial", "circle", "climate", "day", "daylight", "environment", "evening", "forecast", "heat", "light", "lighting", "lines", "morning", "nature", "noon", "orb", "outdoors", "rays", "season", "sky", "solar", "star", "summer", "sun", "sunny", "temperature", "warm", "wb", "weather", "white"];
}, {
    readonly name: "attachment";
    readonly rank: 340;
    readonly popularity: 23757;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["add file", "attach", "attachment", "clip", "communication", "compose", "connect", "connect file", "document", "document icon", "document management", "email", "file", "image", "insert document", "insert file", "link", "office", "office supplies", "paperclip", "paperclip icon", "productivity", "send", "share", "share document", "upload document", "upload file"];
}, {
    readonly name: "close_fullscreen";
    readonly rank: 341;
    readonly popularity: 23757;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "arrow", "arrows", "arrows inward", "box", "button", "close", "collapse", "contract", "control", "corners", "diagonal arrows", "direction", "display", "exit fullscreen", "full", "fullscreen", "interaction", "interface", "media", "minimize", "mode", "presentation", "rectangle", "reduce", "restore", "screen", "shrink", "square", "system", "toggle", "video", "view", "window"];
}, {
    readonly name: "thermostat";
    readonly rank: 342;
    readonly popularity: 23703;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["adjustment", "automation", "climate", "control", "cool", "cooling", "device", "energy", "environmental control", "forecast", "gauge", "heat", "heating", "home automation", "hvac", "measure", "meter", "monitor", "regulate", "setting", "smart home", "temperature", "temperature setting", "thermometer", "thermostat", "utility", "weather"];
}, {
    readonly name: "flutter_dash";
    readonly rank: 343;
    readonly popularity: 23632;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["abstract", "animal", "app", "app development", "application", "bird", "brand", "cartoon", "character", "coding", "cross-platform", "dash", "development", "fast", "flutter", "framework", "futuristic", "google", "logo", "mascot", "mobile", "open source", "program", "programming", "software", "speed", "stylized", "technology", "winged"];
}, {
    readonly name: "format_list_numbered";
    readonly rank: 344;
    readonly popularity: 23406;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["align", "alignment", "arrangement", "bullet points", "digit", "doc", "document", "edit", "editing", "editor", "enumeration", "format", "format options", "formatting", "indent", "items", "layout", "lines", "list", "notes", "numbered", "numbered list", "numbering", "numbering style", "numbers", "order", "ordered items", "ordered list", "organizing", "outline", "paragraph", "points", "sequence", "sequence order", "sheet", "spreadsheet", "structure", "symbol", "text", "type", "writing"];
}, {
    readonly name: "expand_circle_down";
    readonly rank: 345;
    readonly popularity: 23368;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "arrows", "button", "chevron", "circle", "circle button", "close", "collapse", "collapse down", "control", "details", "direction", "down", "down arrow", "down arrow button", "dropdown", "dropdown indicator", "expand", "expand down", "expandable", "hide", "indicator", "information", "list", "maximize", "menu", "minimize", "more", "more options", "navigation", "reveal", "show"];
}, {
    readonly name: "currency_exchange";
    readonly rank: 346;
    readonly popularity: 23339;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["360", "around", "arrow", "arrows", "banking", "buy", "cash", "coin", "commerce", "conversion", "convert", "currency", "currency exchange", "direction", "dollar", "dollars", "economy", "euro", "exchange", "finance", "financial", "foreign exchange", "forex", "inprogress", "international money", "investment", "left arrow", "money", "money transfer", "pay", "payment", "pound", "renew", "right arrow", "rotate", "sell", "swap", "sync", "trade", "transaction", "transfer", "turn", "universal", "yen"];
}, {
    readonly name: "directions_walk";
    readonly rank: 347;
    readonly popularity: 23187;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["activity", "assist", "body", "direction", "directions", "exercise", "figure", "find", "fitness", "foot", "go", "guide", "human", "jogging", "journey", "lead", "locate", "map", "maps", "move", "movement", "navigation", "outdoor", "path", "pedestrian", "people", "person", "point a to point b", "route", "run", "steps", "stick figure", "travel", "walk", "walking"];
}, {
    readonly name: "medical_services";
    readonly rank: 348;
    readonly popularity: 23022;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["aid", "assistance", "bag", "briefcase", "care", "clinic", "cross", "doctor", "doctor's bag", "emergency", "first", "first aid", "health", "health services", "health symbol", "healthcare", "healthcare services", "hospital", "kit", "medic", "medical", "medical cross", "medical facility", "medical help", "medical kit", "medical symbol", "medicine", "pharmacy", "plus", "rescue", "services", "treatment", "wellness"];
}, {
    readonly name: "keyboard_backspace";
    readonly rank: 349;
    readonly popularity: 23009;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["action", "arrow", "back", "backspace", "caret", "clear", "close", "control", "delete", "direction", "editor", "erase", "escape", "exit", "go back", "input", "keyboard", "left", "left arrow", "line", "navigation", "point", "previous", "remove", "return", "shape", "symbol", "text", "undo"];
}, {
    readonly name: "view_headline";
    readonly rank: 350;
    readonly popularity: 22998;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["area", "arrangement", "article", "bars", "block", "component", "content", "design", "display", "document", "element", "format", "formatting", "grid", "grouping", "heading", "headline", "layout", "lines", "list", "order", "organization", "paragraph", "presentation", "screen", "section", "structure", "text", "title", "topic", "view", "visual", "website", "window"];
}, {
    readonly name: "dangerous";
    readonly rank: 351;
    readonly popularity: 22840;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alarming", "alert", "attention", "be careful", "broken", "caution", "critical", "danger", "dangerous", "error", "exclamation", "fix", "flag", "forbidden", "halt", "hazard", "important", "issue", "mark", "no", "note", "notification", "point", "pointy", "problem", "restricted", "risk", "sharp", "sign", "stop", "symbol", "triangle", "update", "urgent", "warning", "watch out", "wrong", "x"];
}, {
    readonly name: "policy";
    readonly rank: 352;
    readonly popularity: 22821;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["administration", "agreement", "certified", "checklist", "compliance", "conditions", "contract", "data", "declaration", "document", "ethics", "file", "find", "glass", "governance", "guidelines", "information", "law", "legal", "list", "look", "magnify", "magnifying", "management", "official", "paper", "policy", "privacy", "private", "protect", "protection", "regulation", "report", "rules", "search", "security", "see", "shield", "standards", "statement", "terms", "text", "verified"];
}, {
    readonly name: "sms";
    readonly rank: 353;
    readonly popularity: 22529;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["3", "alert", "app", "bubble", "chat", "communicate", "communication", "conversation", "dialog", "dialogue", "dots", "inbox", "lines", "mail", "message", "message bubble", "messaging", "mobile", "more", "new", "notification", "phone", "pointer", "receive", "rectangle", "send", "service", "sms", "social", "speech", "speech bubble", "square", "talk", "text", "texting", "three"];
}, {
    readonly name: "keyboard_arrow_up";
    readonly rank: 354;
    readonly popularity: 22442;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["accordion", "angle", "arrow", "arrows", "ascend", "caret", "chevron", "collapse", "control", "direction", "dropdown", "expand", "expandable", "hide", "indicator", "less", "list", "menu", "move up", "navigate", "navigation", "paginate", "point", "pointer", "previous", "return to top", "scroll", "scroll up", "show", "sort", "top", "triangle", "up"];
}, {
    readonly name: "sentiment_dissatisfied";
    readonly rank: 355;
    readonly popularity: 22264;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["angry", "avatar", "bad", "circle", "disappointed", "dislike", "dissatisfied", "emoticon", "emotion", "emotions", "expression", "expressions", "face", "feedback", "feeling", "feelings", "frown", "head", "human", "mood", "negative", "person", "poor", "profile", "rating", "review", "sad", "sentiment", "survey", "unhappy", "unsatisfied", "upset", "user"];
}, {
    readonly name: "table_chart";
    readonly rank: 356;
    readonly popularity: 21936;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["analytics", "arrange", "bar", "bars", "business", "chart", "columns", "data", "diagram", "display", "document", "finance", "graph", "grid", "infographic grid", "information", "lines", "matrix", "measure", "metrics", "numbers", "organize", "outline", "plot", "presentation", "rectangle", "report", "rows", "shape", "spreadsheet", "squares", "statistics", "table", "tracking", "view"];
}, {
    readonly name: "keyboard_double_arrow_right";
    readonly rank: 357;
    readonly popularity: 21855;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["accelerate", "advance", "arrow", "arrows", "chevron", "chevrons", "control", "direction", "double", "double arrow", "double chevron", "fast forward", "forward", "go", "input", "key", "keyboard", "move", "movement", "multiple", "navigation", "next", "next page", "progress", "right", "right arrow", "rightward", "skip", "step forward", "symbol"];
}, {
    readonly name: "sensors";
    readonly rank: 358;
    readonly popularity: 21823;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["antenna", "bar graph", "bars", "communication", "connection", "connection status", "connectivity", "data", "device", "device status", "graduated bars", "indicator", "internet", "levels", "measurement", "network", "radio waves", "reception", "scan", "sensing", "sensors", "signal", "signal strength", "status", "technology", "three bars", "transfer", "transmission", "waves", "wifi", "wireless"];
}, {
    readonly name: "border_color";
    readonly rank: 359;
    readonly popularity: 21819;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["adjust", "all", "art", "border", "border color", "change", "color", "colour", "customize", "design", "diagonal", "doc", "draw", "edit", "editing", "editor", "format", "graphic", "line", "modify", "outline", "pen", "pencil", "pointed", "rectangle", "shape", "sheet", "sketch", "spreadsheet", "square", "stroke", "style", "text", "tool", "type", "write", "writing"];
}, {
    readonly name: "euro_symbol";
    readonly rank: 360;
    readonly popularity: 21695;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["banking", "bill", "business", "buy", "card", "cash", "coin", "commerce", "cost", "credit", "currency", "dollars", "economy", "euro", "european", "exchange", "finance", "financial", "international", "monetary", "money", "online", "pay", "payment", "price", "sell", "symbol", "transaction", "value", "wealth"];
}, {
    readonly name: "meeting_room";
    readonly rank: 361;
    readonly popularity: 21540;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["access", "arch", "building", "business", "closed", "collaboration", "communication", "conference", "door", "doorway", "entrance", "exit", "gathering", "group", "home", "house", "interior", "meeting", "meeting room", "office", "open", "people", "places", "rectangular", "room", "space", "square", "team", "threshold", "work"];
}, {
    readonly name: "compare_arrows";
    readonly rank: 362;
    readonly popularity: 21527;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alternative", "arrow", "arrows", "balance", "bidirectional", "change", "choices", "collide", "compare", "cross", "data transfer", "direction", "exchange", "flow", "horizontal", "left", "left and right", "move", "opposing arrows", "opposite", "options", "parallel arrows", "pressure", "push", "reciprocal", "right", "swap", "switch", "symmetry", "sync", "synchronize", "together", "toggle", "transfer", "two", "x-axis"];
}, {
    readonly name: "sentiment_very_dissatisfied";
    readonly rank: 363;
    readonly popularity: 21476;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["angry", "avatar", "character", "circle", "disappointed", "disapproval", "dislike", "dissatisfied", "dissatisfied face", "emoji", "emoticon", "emotion", "emotions", "expressions", "face", "facial expression", "feedback", "feeling", "feelings", "frowning", "human", "indicator", "low rating", "mood", "negative", "outline", "person", "reaction", "review", "sad", "sentiment", "sorrow", "status", "survey", "unhappy", "unsatisfied", "upset", "very"];
}, {
    readonly name: "keyboard_return";
    readonly rank: 364;
    readonly popularity: 21446;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["angle", "arrow", "back", "bend", "break line", "carriage return", "coding", "command", "computer key", "curved arrow", "directional arrow", "down arrow", "enter key", "function", "glyph", "icon", "input", "keyboard", "keyboard return", "keyboard symbol", "left", "left arrow", "newline", "programming", "return", "return key", "shape", "symbol", "text editing", "text entry", "text formatting", "typography"];
}, {
    readonly name: "change_circle";
    readonly rank: 365;
    readonly popularity: 21376;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["alter", "around", "arrow", "arrows", "change", "circle", "circular", "cycle", "direction", "exchange", "flow", "loop", "modification", "movement", "navigation", "ongoing", "process", "progress", "refresh", "reload", "renew", "repeat", "replace", "rotate", "round", "status", "switch", "transition", "update"];
}, {
    readonly name: "table_view";
    readonly rank: 366;
    readonly popularity: 21370;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrangement", "cell", "chart", "columns", "data", "data visualization", "display", "format", "geometry", "grid", "group", "information", "layout", "lines", "list", "matrix", "multiple", "order", "organize", "organized data", "presentation", "rectangular", "report", "rows", "segmented", "spreadsheet", "square", "structure", "table", "tabular", "tabular data", "view"];
}, {
    readonly name: "brush";
    readonly rank: 367;
    readonly popularity: 21360;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["art", "artist", "artistic", "bristle", "brush", "color", "creative", "design", "designer", "draw", "drawing", "drawing tool", "edit", "editing", "editor", "fill", "graphics", "handle", "illustration", "instrument", "line", "object", "paint", "painter", "painting", "painting tool", "shape", "stroke", "style", "tip", "tool", "tools"];
}, {
    readonly name: "group_work";
    readonly rank: 368;
    readonly popularity: 21300;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alliance", "assembly", "association", "avatars", "business", "circular", "collaboration", "collective", "community", "congregation", "crowd", "employees", "figures", "gathering", "group", "huddle", "members", "network", "organization", "oval", "partnership", "people", "profiles", "round", "silhouettes", "social", "staff", "team", "teamwork", "together", "users", "work"];
}, {
    readonly name: "notification_important";
    readonly rank: 369;
    readonly popularity: 21203;
    readonly categories: readonly ["alert"];
    readonly tags: readonly ["!", "active", "alarm", "alert", "app icon", "attention", "bell", "caution", "chime", "communication", "critical", "danger", "error", "exclamation", "icon", "important", "inbox", "information", "mark", "message", "new", "notification", "notification bell", "notifications", "notify", "reminder", "ring", "sound", "status", "status update", "symbol", "system", "timely", "ui element", "ui icon", "update", "urgent", "urgent message", "warning"];
}, {
    readonly name: "battery_full";
    readonly rank: 370;
    readonly popularity: 21191;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["bar", "battery", "battery icon", "battery level", "battery meter", "cell", "charge", "device", "device status", "electronic", "energy", "energy level", "full", "full battery", "full charge", "gadget", "indicator", "level", "max charge", "mobile", "percentage", "power", "power indicator", "power status", "rectangular", "signal", "standard battery", "status", "technology"];
}, {
    readonly name: "celebration";
    readonly rank: 371;
    readonly popularity: 21070;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["achievement", "activity", "award", "birthday", "burst", "celebration", "confetti", "congratulations", "emblem", "event", "excitement", "explode", "festive", "fireworks", "fun", "glitter", "glyph", "graphic", "happy", "joy", "light", "magic", "party", "reward", "shape", "sparkle", "special", "star", "success", "surprise", "symbol", "victory"];
}, {
    readonly name: "arrow_left";
    readonly rank: 372;
    readonly popularity: 21059;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["angle", "app", "application", "arrow", "back", "backward", "basic", "components", "curve", "direction", "directionality", "forward", "go back", "indicator", "interface", "left", "line", "minimal", "move", "navigation", "next", "outline", "point", "pointer", "previous", "return", "reverse", "right", "screen", "shape", "simple", "site", "triangle", "ui", "undo", "ux", "way", "web", "website"];
}, {
    readonly name: "local_hospital";
    readonly rank: 373;
    readonly popularity: 21039;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["911", "aid", "ambulance", "building", "care", "clinic", "cross", "doctor", "emergency", "facility", "first", "health", "healthcare", "help", "hospital", "local", "location", "map", "medical", "medicine", "navigation", "nurse", "pharmacy", "pin", "plus", "pointer", "treatment"];
}, {
    readonly name: "house";
    readonly rank: 374;
    readonly popularity: 20997;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["abode", "architecture", "basic", "building", "button", "door", "dwelling", "element", "estate", "family", "geometric", "graphic", "home", "homepage", "house", "icon", "line", "navigation", "outline", "place", "places", "property", "real", "real estate", "rectangle", "residence", "residential", "roof", "shelter", "simple", "square", "structure", "symbol", "triangle", "wall", "window"];
}, {
    readonly name: "disabled_by_default";
    readonly rank: 375;
    readonly popularity: 20961;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access denied", "alert", "blocked", "box", "by", "cancel", "caution", "clear", "close", "cross", "default", "denied", "diagonal", "disabled", "error", "exit", "failure", "forbidden", "inactive", "indicator", "invalid", "issue", "line", "no", "not allowed", "off", "problem", "quit", "rejected", "remove", "restricted", "shape", "square", "state", "status", "stop", "symbol", "ui control", "unavailable", "warning", "x"];
}, {
    readonly name: "smart_toy";
    readonly rank: 376;
    readonly popularity: 20913;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["ai", "android", "artificial intelligence", "assistant", "automation", "bot", "character", "chatbot", "companion", "computing", "digital", "droid", "future", "futuristic", "games", "head", "icon", "innovation", "intelligence", "interaction", "interface", "machine learning", "mechanical", "playful", "robot", "round eyes", "smart", "smart toy", "square", "symbol", "technology", "toy", "virtual"];
}, {
    readonly name: "south";
    readonly rank: 377;
    readonly popularity: 20805;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "arrow down", "below", "bottom", "button", "chevron", "control", "cursor", "direction", "directional", "down", "down arrow", "downward", "graphic", "guide", "indicator", "interface element", "location", "maps", "move down", "movement", "navigation", "pointer", "pointing down", "position", "scroll down", "south", "symbol", "triangle", "vertical"];
}, {
    readonly name: "tag";
    readonly rank: 378;
    readonly popularity: 20717;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["app", "banner", "bookmark", "button", "categorize", "classification", "corner", "diagonal", "document", "favorite", "file", "fold", "folded corner", "hash", "hashtag", "key", "label", "marker", "media", "note", "numbers", "organise", "page", "paper", "pound", "ribbon", "save", "shape", "slant", "social", "symbol", "tag", "trend", "triangle", "ui", "ui element", "web"];
}, {
    readonly name: "import_contacts";
    readonly rank: 379;
    readonly popularity: 20641;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["address", "address book", "book", "communicate", "contacts", "data", "diary", "directory", "download", "education", "import", "info", "information", "journal", "knowledge", "learning", "library", "literature", "migration", "notebook", "open", "opened book", "pages", "reading", "receive", "send", "share", "sync", "synchronize", "textbook", "transfer", "upload"];
}, {
    readonly name: "subject";
    readonly rank: 380;
    readonly popularity: 20553;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["alignment", "answer", "assistance", "balloon", "bubble", "chat", "comment", "communication", "dialogue", "doc", "document", "email", "full", "help", "help bubble", "icon", "information", "information bubble", "isolated", "justify", "list", "note", "problem", "query", "query bubble", "question", "question mark", "rounded corners", "shape", "square", "subject", "support", "symbol", "text", "writing"];
}, {
    readonly name: "lunch_dining";
    readonly rank: 381;
    readonly popularity: 20420;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["bar", "breakfast", "breakfast time", "brunch", "cafe", "canteen", "cutlery", "dining", "dining area", "dining location", "dining room", "dinner", "dinner time", "drink", "eat", "eating", "eating area", "eating place", "fastfood", "food", "fork", "hamburger", "kitchen", "knife", "lunch", "lunch time", "meal", "meal time", "restaurant", "restaurant location", "service", "silverware", "spoon", "supper"];
}, {
    readonly name: "privacy_tip";
    readonly rank: 382;
    readonly popularity: 20357;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "advice", "alert", "announcement", "assist", "assistance", "certified", "confidentiality", "control", "data", "details", "encrypted", "guide", "help", "hint", "i", "info", "information", "notification", "personal", "policy", "privacy", "private", "protect", "protection", "safe", "safeguard", "secret", "secure", "security", "sensitive", "service", "settings", "shield", "suggestion", "support", "tip", "user", "verified", "warning"];
}, {
    readonly name: "app_registration";
    readonly rank: 383;
    readonly popularity: 20252;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["app", "app registration", "application", "apps", "create account", "data entry", "details", "documentation", "edit", "enroll", "entry", "form", "information", "join", "new account", "onboarding", "pencil", "profile creation", "record", "register", "registration", "registration form", "sign up", "sign up form", "signup", "signup form", "subscription", "user registration", "web form"];
}, {
    readonly name: "equalizer";
    readonly rank: 384;
    readonly popularity: 20094;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["adjust", "adjustment", "analytics", "audio", "audio control", "bars", "chart", "control", "customize", "data", "digital", "equalizer", "filter", "fine tune", "frequency", "graph", "levels", "lines", "measure", "metrics", "mix", "mixing", "multimedia", "music", "noise", "parameters", "playback", "preferences", "settings", "settings icon", "sound", "sound adjustment", "spectrum", "static", "statistics", "tone", "tracking", "vertical", "visualizer", "volume"];
}, {
    readonly name: "euro";
    readonly rank: 385;
    readonly popularity: 20025;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["banking", "bill", "card", "cash", "coin", "commerce", "cost", "credit", "currency", "currency symbol", "dollars", "economics", "euro", "europe", "european", "european currency", "euros", "exchange", "finance", "financial symbol", "glyph", "horizontal lines", "international currency", "line", "monetary", "money", "money symbol", "online", "pay", "payment", "price", "shape", "shopping", "stroke", "symbol", "trade", "value", "wealth"];
}, {
    readonly name: "local_library";
    readonly rank: 386;
    readonly popularity: 20003;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["academy", "archive", "book", "book icon", "book stack", "book symbol", "books", "collection", "community learning", "education", "education icon", "information", "knowledge", "knowledge base", "knowledge icon", "learn", "learning icon", "library", "literacy", "literature", "literature stack", "local", "local library", "read", "reading", "reading icon", "research", "resources", "school", "stack of books", "study", "university"];
}, {
    readonly name: "corporate_fare";
    readonly rank: 387;
    readonly popularity: 19980;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["abstract", "architecture", "banking", "building", "business", "city", "company", "corporate", "estate", "fare", "finance", "full", "government", "graphic", "headquarters", "icon", "institution", "law", "line", "office", "organization", "place", "real", "real estate", "rectangle", "residence", "residential", "shape", "shelter", "skyscraper", "solid", "structure", "symbol", "tower", "urban"];
}, {
    readonly name: "price_check";
    readonly rank: 388;
    readonly popularity: 19880;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["approve", "barcode scanner", "bill", "card", "cash", "check", "check price", "coin", "commerce", "compare price", "complete", "cost", "credit", "currency", "deal", "discount", "dollars", "done", "finance", "inquiry", "label", "lookup", "mark", "money", "offer", "ok", "online", "pay", "payment", "price", "price check", "purchase", "retail", "sale", "savings", "scan", "scan price", "scanner", "search price", "select", "shopping", "symbol", "tag", "tick", "transaction", "validate", "value", "verified", "yes"];
}, {
    readonly name: "flash_on";
    readonly rank: 389;
    readonly popularity: 19858;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["activate", "alert", "bolt", "bright", "camera", "camera flash", "danger", "disabled", "electric", "electricity", "enabled", "energy", "fast", "flash", "glow", "illuminate", "indication", "instant", "light", "lighting", "lightning", "notification", "off", "on", "photo", "photo flash", "photography", "power", "shine", "slash", "status", "thunder", "thunderbolt", "toggle", "turn on", "warning"];
}, {
    readonly name: "keyboard_arrow_left";
    readonly rank: 390;
    readonly popularity: 19840;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["angle", "arrow", "arrows", "back", "basic", "button", "chevron", "control", "direction", "indicator", "key", "keyboard", "left", "list", "menu", "minimal", "move", "move left", "navigate", "navigation", "page", "point", "pointer", "previous", "scroll", "sideways", "simple", "triangle", "ui control"];
}, {
    readonly name: "ac_unit";
    readonly rank: 391;
    readonly popularity: 19797;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["ac", "air", "air conditioning", "asterisk", "climate", "cold", "condition", "conditioner", "control", "cool", "cooling", "crystal", "flake", "frost", "frozen", "ice", "point", "points", "polygon", "six pointed star", "six points", "snow", "snowflake", "star", "temperature", "unit", "weather", "winter"];
}, {
    readonly name: "pin_drop";
    readonly rank: 392;
    readonly popularity: 19678;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["address", "area", "coordinate", "current location", "destination", "direction", "drop", "explore", "find", "geography", "geotag", "gps", "locate", "location", "map pin", "maps", "mark", "marker", "navigate", "navigation", "pin", "pinpoint", "place", "point", "position", "pushpin", "region", "save location", "search", "spot", "stop", "track", "travel"];
}, {
    readonly name: "arrow_circle_up";
    readonly rank: 393;
    readonly popularity: 19616;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "arrow", "button", "circle", "circular arrow", "control", "data transfer", "direction", "direction up", "file upload", "forward", "go to top", "icon", "indicator", "move forward", "move up", "navigate up", "navigation", "order", "positive direction", "progress up", "return to top", "scroll up", "send", "share", "sort", "symbol", "top", "ui element", "up", "up arrow", "upload"];
}, {
    readonly name: "newspaper";
    readonly rank: 394;
    readonly popularity: 19550;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["article", "book", "communication", "current events", "daily", "data", "doc", "document", "drive", "file", "folder", "folders", "headline", "information", "journalism", "lines", "magazine", "media", "news", "newspaper", "notes", "page", "pages", "paper", "press", "print", "publication", "reading", "rectangle", "report", "sheet", "slide", "square", "text", "update", "writing"];
}, {
    readonly name: "input";
    readonly rank: 395;
    readonly popularity: 19548;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["accept", "apply", "approve", "arrow", "box", "button", "check", "circle", "complete", "confirmed", "correct", "done", "download", "finished", "input", "login", "mark", "marker", "move", "ok", "ready", "right", "round", "shape", "success", "tick", "valid", "verified"];
}, {
    readonly name: "bookmarks";
    readonly rank: 396;
    readonly popularity: 19513;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["bookmark", "bookmarks", "browser", "collection", "document", "favorite", "favorites", "file", "flag", "highlighted", "important", "label", "layers", "library", "list", "management", "marker", "multiple", "navigation", "organize", "paper", "read", "reading", "remember", "ribbon", "save", "saved", "shape", "stack", "tag", "triangular", "web"];
}, {
    readonly name: "contact_phone";
    readonly rank: 397;
    readonly popularity: 19452;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["account", "address book", "avatar", "call", "circle", "communicate", "communication", "contact", "directory", "face", "filled", "glyph", "head", "human", "info", "information", "message", "mobile", "outline", "people", "person", "phone", "profile", "profile picture", "round", "shoulders", "user"];
}, {
    readonly name: "live_tv";
    readonly rank: 398;
    readonly popularity: 19436;
    readonly categories: readonly ["notification"];
    readonly tags: readonly ["Android", "OS", "antenna", "antennas hardware", "broadcast", "broadcasting", "channel", "chrome", "content", "desktop", "device", "display", "electronic", "entertainment", "film", "iOS", "live", "live tv", "mac", "media", "monitor", "movie", "on demand", "ondemand video", "play", "playback", "rectangle", "screen", "show", "signal", "stream", "streaming", "technology", "television", "tv", "video", "watch", "web", "window"];
}, {
    readonly name: "track_changes";
    readonly rank: 399;
    readonly popularity: 19427;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["bullseye", "changes", "circle", "collaboration", "compare", "comparison", "content", "differences", "document editing", "document history", "document management", "document versions", "draft", "editing", "editing features", "editorial", "evolve", "file history", "history", "lines", "movement", "review", "revisions", "revisions history", "rotate", "shift", "target", "text", "track", "track changes", "version control", "version history", "workflow", "writing"];
}, {
    readonly name: "view_module";
    readonly rank: 400;
    readonly popularity: 19353;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrange", "arrangement", "blocks", "collection", "components", "content", "dashboard", "data", "design", "display", "format", "gallery", "grid", "grouping", "groups", "information", "items", "layout", "module", "organization", "organize", "overview", "pattern", "presentation", "rectangle", "representation", "sections", "square", "squares", "stacked", "structure", "tiles", "view", "visual", "website"];
}, {
    readonly name: "api";
    readonly rank: 401;
    readonly popularity: 19325;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "api", "application", "backend", "bridge", "cloud", "code", "coding", "communication", "computer", "connection", "data", "developer", "development", "enterprise", "frontend", "integration", "internet", "link", "network", "programming", "programming interface", "service", "software", "system", "tech", "technology", "transfer", "web service"];
}, {
    readonly name: "toc";
    readonly rank: 402;
    readonly popularity: 19303;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["bullet points", "chapter list", "chapters", "content", "document", "document navigation", "document sections", "file", "format", "hierarchy", "index", "index list", "lines", "list", "menu", "navigation", "options", "order", "organize", "outline", "overview", "points", "reorder", "section list", "sections", "stacked", "structure", "structure of a document", "summary", "table", "table of contents", "text", "title", "titles", "toc"];
}, {
    readonly name: "self_improvement";
    readonly rank: 403;
    readonly popularity: 19262;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["balance", "body", "brain", "calm", "care", "chi", "coaching", "counseling", "development", "emotional", "growth", "healing", "health", "help", "human", "improvement", "life", "meditate", "meditation", "mental", "mind", "mindfullness", "peace", "people", "person", "personal", "progress", "relax", "self", "self-care", "sitting", "spiritual", "support", "therapy", "well-being", "wellbeing", "wellness", "yoga", "zen"];
}, {
    readonly name: "park";
    readonly rank: 404;
    readonly popularity: 19260;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["area", "attraction", "destination", "environment", "fresh", "garden", "green space", "land", "landscape", "leisure", "local", "location", "map", "monument", "nature", "outdoor", "outside", "park", "pin", "plant", "preserve", "public space", "recreation", "relaxation", "tree", "trees"];
}, {
    readonly name: "emoji_people";
    readonly rank: 405;
    readonly popularity: 19234;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["accounts", "arm", "assembly", "audience", "avatars", "body", "community", "contacts", "crowd", "directory", "emoji", "employees", "figures", "friends", "gathering", "greeting", "group", "human", "individuals", "members", "membership", "multitude", "network", "outlines", "people", "person", "profile", "profiles", "representation", "roster", "silhouettes", "social", "staff", "team", "users", "waving"];
}, {
    readonly name: "pie_chart";
    readonly rank: 406;
    readonly popularity: 19154;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["analysis", "analytics", "bar", "bars", "business", "chart", "circle", "comparison", "data", "diagram", "division", "economics", "finance", "graph", "growth", "infographic", "information", "insights", "marketing", "measure", "metrics", "overview", "percentage", "pie", "pie chart", "progress", "reports", "results", "sales", "segment", "slice", "statistics", "summary", "tracking", "visualization"];
}, {
    readonly name: "looks_one";
    readonly rank: 407;
    readonly popularity: 19083;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["1", "beginning", "competition", "count", "counting", "digit", "exclusive", "first", "initial", "leading", "looks", "major", "math", "mathematics", "number one", "numbers", "numeral", "numerical", "one", "original", "position", "primary", "principal", "ranked", "ranking", "single", "sole", "square", "start", "symbol", "top", "unique", "winner"];
}, {
    readonly name: "grading";
    readonly rank: 408;
    readonly popularity: 19078;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["approved", "assess", "check", "checklist", "complete", "document", "done", "evaluation", "fail", "form", "grade", "grading", "list", "mark", "marking", "paper", "pass", "quality control", "rating", "report", "review", "score", "survey", "tally", "task list", "test", "tick", "to do list", "validation", "verification"];
}, {
    readonly name: "medication";
    readonly rank: 409;
    readonly popularity: 19039;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["capsule", "doctor", "drug", "drug icon", "emergency", "health", "healthcare", "healthcare icon", "healthcare item", "hospital", "medical", "medical icon", "medical treatment", "medication", "medication icon", "medicine", "medicine icon", "pharmaceutical", "pharmacy", "pharmacy icon", "pill", "pill icon", "pills", "prescription", "tablet", "treatment", "treatment and cure", "treatment icon", "wellness"];
}, {
    readonly name: "download_for_offline";
    readonly rank: 410;
    readonly popularity: 19034;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["access", "arrow", "available offline", "backup", "caching", "circle", "cloud", "cloud arrow", "cloud icon", "connection", "data transfer", "down", "download", "download cloud", "download icon", "file transfer", "for offline", "get file", "install", "internet", "network", "no internet", "offline", "offline icon", "retrieve", "retrieve data", "save", "save icon", "storage", "store", "sync", "synchronization", "transfer", "upload"];
}, {
    readonly name: "directions_bus";
    readonly rank: 411;
    readonly popularity: 18987;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["automobile", "bus", "car", "cars", "commute", "directions", "filled", "journey", "maps", "navigation", "passenger", "public", "public transport", "rectangle", "ride", "road", "rounded corners", "route", "solid", "street", "transportation", "travel", "vehicle", "wheel", "window"];
}, {
    readonly name: "fast_forward";
    readonly rank: 412;
    readonly popularity: 18954;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["accelerate", "action", "advance", "arrow", "audio", "audio visual", "button", "content", "control", "direction", "double arrow", "entertainment", "fast", "fast forward", "forward", "media", "media control", "move forward", "music", "next", "play", "playback", "player", "progress", "right arrow", "skip", "speed", "streaming", "symbol", "time", "timeline", "tv", "ui element", "video"];
}, {
    readonly name: "build_circle";
    readonly rank: 413;
    readonly popularity: 18766;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "build", "circle", "cog", "configuration", "construct", "contained", "create", "development", "engineer", "fix", "gear", "machinery", "maintenance", "mechanical", "options", "outlined", "preferences", "repair", "round", "settings", "setup", "spanner", "technical", "tool", "wrench"];
}, {
    readonly name: "copyright";
    readonly rank: 414;
    readonly popularity: 18760;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["agreement", "alphabet", "attribution", "brand", "c", "character", "circle", "copyright", "credit", "disclaimer", "emblem", "font", "identifier", "identity", "intellectual property", "label", "legal", "letter c", "letters", "licensing", "logo", "mark", "notice", "owner", "ownership", "property", "protection", "registered", "rights", "seal", "signature", "stamp", "surrounding circle", "symbol", "text"];
}, {
    readonly name: "live_help";
    readonly rank: 415;
    readonly popularity: 18745;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["?", "advice", "aid", "answer", "assistance", "bubble", "chat", "comment", "communicate", "communication", "contact", "conversation", "customer service", "dialog", "faq", "guidance", "guide", "help", "info", "information", "instant", "interaction", "live", "message", "problem", "punctuation", "query", "question", "question mark", "quick help", "real-time", "recent", "restore", "solution", "speech", "speech bubble", "support", "symbol", "talk", "troubleshooting"];
}, {
    readonly name: "perm_media";
    readonly rank: 416;
    readonly popularity: 18724;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["archive", "arrangement", "collection", "content", "copy", "data", "digital library", "doc", "document", "documents", "duplicate", "file", "files", "folder", "folders", "grouping", "image", "landscape", "layers", "layers of files", "library", "media", "media library", "mountain", "mountains", "multimedia", "multiple", "order", "organization", "organized files", "paper documents", "papers", "perm", "perm media", "photo", "photography", "picture", "records", "sheets", "sheets of paper", "stack", "stacked documents", "storage"];
}, {
    readonly name: "pin";
    readonly rank: 417;
    readonly popularity: 18715;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["1", "2", "3", "address", "cartography", "destination", "digit", "directional", "drop pin", "favorite location", "find", "geo", "geography", "geotag", "gps", "here", "key", "location", "login", "logout", "map marker", "mapping", "marker", "navigation", "numbers", "password", "pattern", "pin", "place", "point of interest", "pointer", "position", "pushpin", "saved location", "security", "spatial", "star", "symbol", "tracking", "travel", "unlock", "where"];
}, {
    readonly name: "person_remove";
    readonly rank: 418;
    readonly popularity: 18636;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["account", "avatar", "ban", "blacklist", "block", "cancellation", "circle", "contact", "delete", "depart", "diagonal line", "exclude", "exit", "face", "friend", "human", "line", "minus", "negative", "people", "person", "profile", "prohibition", "refusal", "rejection", "remove", "slash", "unfollow", "unfriend", "unsubscribe", "user", "withdrawal"];
}, {
    readonly name: "forward_to_inbox";
    readonly rank: 419;
    readonly popularity: 18618;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["arrow", "arrow icon", "arrows", "communication", "communication icon", "correspondence", "delivery", "destination", "direction", "directions", "document", "email", "envelop", "envelope", "envelope icon", "forward", "inbox", "inbox icon", "letter", "letter icon", "letters", "mail", "mail icon", "message", "message forwarding", "message transfer", "move", "navigation", "outgoing", "paper", "right", "send", "send mail", "send message", "to", "transfer", "transport"];
}, {
    readonly name: "local_atm";
    readonly rank: 420;
    readonly popularity: 18562;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["atm", "automated teller machine", "bank", "banking", "bill", "brick and mortar", "building", "card", "cart", "cash", "cash machine", "coin", "commerce", "credit", "currency", "debit", "deposit", "dollars", "establishment", "finance", "financial", "find", "local", "locate", "location", "machine", "money", "navigate", "nearby", "online", "pay", "payment", "point of interest", "retail", "service", "shopping", "structure", "symbol", "transaction", "withdrawal"];
}, {
    readonly name: "hourglass_bottom";
    readonly rank: 421;
    readonly popularity: 18482;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["bottom", "clock", "completed", "completion", "countdown", "deadline", "deadline exceeded", "delay", "duration", "end", "expiration", "final", "finished", "future", "half", "half full", "history", "hourglass", "loading", "measure", "measurement", "minute", "minutes", "past", "pending", "processing", "progress", "remaining", "sand", "time", "timer", "wait", "waiting"];
}, {
    readonly name: "redo";
    readonly rank: 422;
    readonly popularity: 18437;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "advancement", "again", "arrow", "backward", "clockwise", "command", "control", "curved", "document", "edit", "forward", "future", "history", "iteration", "move", "next", "next action", "previous action", "progress", "redo", "repeat", "repeat action", "restore", "restore state", "return", "reverse undo", "revision", "right", "rotate", "sequence", "step", "undo", "workflow"];
}, {
    readonly name: "memory";
    readonly rank: 423;
    readonly popularity: 18426;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["access", "card", "chip", "circuit", "component", "computer", "connection", "data", "device", "digital", "electronic", "hardware", "information", "integrated circuit", "lines", "memory", "micro", "module", "pins", "processing", "processor", "ram", "rectangle", "sd", "square", "storage", "system", "technical", "technology"];
}, {
    readonly name: "coronavirus";
    readonly rank: 424;
    readonly popularity: 18392;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["19", "bacteria", "biohazard", "biology", "cell", "circle", "contagious", "coronavirus", "covid", "covid-19", "disease", "epidemic", "germ", "germs", "global", "health", "healthcare", "illness", "infection", "medical", "microbe", "outbreak", "pandemic", "pathogen", "points", "research", "science", "sick", "sickness", "social", "sphere", "spikes", "virus"];
}, {
    readonly name: "north_east";
    readonly rank: 425;
    readonly popularity: 18338;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "corner", "diagonal", "direction", "direction indicator", "east", "external", "external link", "follow link", "go to", "internet", "link", "link arrow", "location", "map", "maps", "move", "navigate", "navigation", "new tab", "north east", "noth", "open", "outbound", "path", "point", "redirect", "right", "share link", "up", "url", "visit", "website", "window"];
}, {
    readonly name: "web";
    readonly rank: 426;
    readonly popularity: 18321;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["advertising", "banner", "blocks", "browser", "campaign", "cms", "columns", "content", "dashboard", "display", "grid", "internet", "layout", "marketing", "page", "panels", "portal", "preview", "promotion", "rounded-rectangle", "screen", "sidebar", "site", "split-screen", "structure", "template", "web", "webpage", "website", "window", "wireframe", "www"];
}, {
    readonly name: "forward";
    readonly rank: 427;
    readonly popularity: 18209;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["arrow", "communication", "content sharing", "forward", "forward icon", "google plus", "google plus share", "mail", "message", "playback", "reshare", "reshare icon", "right", "right arrow", "send", "send icon", "send to", "sent", "share", "share arrow", "share content", "share icon", "share link", "share post", "share to", "share with", "shortcut", "social icon", "social media", "social share"];
}, {
    readonly name: "design_services";
    readonly rank: 428;
    readonly popularity: 18141;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["architecture", "art", "build", "compose", "create", "design", "draft", "drafting", "draw", "drawing", "edit", "editing", "education", "engineering", "geometry", "graphic", "illustration", "implements", "input", "instrument", "learn", "line", "measure", "object", "office", "pen", "pencil", "ruler", "school", "service", "services", "shape", "sketch", "stationery", "tools", "triangle", "work", "write", "writing"];
}, {
    readonly name: "local_activity";
    readonly rank: 429;
    readonly popularity: 18079;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["access", "activity", "admission", "attendance", "cinema", "coupon", "cutout", "entertainment", "entertainment pass", "entry", "event", "event pass", "event ticket", "local", "movie", "movie ticket", "pass", "perforation", "play", "rectangular", "shape", "show", "star", "stub", "tear-off", "theater", "things", "ticket", "ticket stub", "voucher"];
}, {
    readonly name: "hourglass_top";
    readonly rank: 430;
    readonly popularity: 17994;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["antique", "bulb", "classic", "countdown", "delay", "duration", "epoch", "era", "flow", "future", "glass", "half", "hourglass", "indicator", "loading", "measurement", "measuring", "minute", "minutes", "object", "past", "pending", "period", "progress", "sand", "science", "shape", "time", "timer", "tool", "top", "vessel", "vintage", "wait", "waiting"];
}, {
    readonly name: "playlist_add_check";
    readonly rank: 431;
    readonly popularity: 17975;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["add", "added", "and", "approve", "arrangement", "audio", "check", "checked", "collection", "complete", "completed", "confirmed", "done", "entries", "items", "library", "list", "mark", "multimedia", "music", "ok", "order", "playlist", "plus", "queue", "select", "sequence", "sorted", "success", "task", "tick", "validate", "verified", "video", "yes"];
}, {
    readonly name: "star_half";
    readonly rank: 432;
    readonly popularity: 17969;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["achievement", "assessment", "bookmark", "completion", "evaluation", "favorite", "favorite icon", "feedback", "half", "half filled star", "half star", "highlight", "important", "incomplete star", "mark", "mark icon", "marked", "partial star", "progress", "progress indicator", "ranking", "rate", "rating", "rating icon", "rating rank", "rating system", "review", "review icon", "reward", "save", "saved", "score", "score icon", "shape", "special", "star", "status", "toggle", "ui element", "user rating", "visual indicator"];
}, {
    readonly name: "north";
    readonly rank: 433;
    readonly popularity: 17896;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "arrow up", "compass", "destination", "direction", "direction indicator", "directional", "geomagnetic", "geospatial", "guide", "guidepost", "heading", "journey", "location", "magnetic north", "map", "maps", "navigate", "navigation", "north", "orientation", "orientation marker", "point", "pointer", "routing", "sign", "top", "travel", "true north", "up", "upwards"];
}, {
    readonly name: "person_pin";
    readonly rank: 434;
    readonly popularity: 17888;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["account", "address", "avatar", "circle", "colleague", "contact", "destination", "direction", "drop pin", "face", "figure", "find", "find person", "find user", "friend", "geotag", "human", "identify location", "identify user", "location", "map", "maps", "marker", "my location", "navigate", "people", "person", "pin", "place", "point of interest", "position", "profile", "silhouette", "stop", "team member", "user", "whereabouts"];
}, {
    readonly name: "video_library";
    readonly rank: 435;
    readonly popularity: 17860;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["archive", "arrow", "category", "collection", "content", "document", "education", "entertainment", "file", "film", "folder", "gallery", "group", "library", "list", "media", "movie", "multimedia", "multiple", "organized", "play", "rectangle", "shape", "square", "stack", "storage", "symbol", "video", "visual"];
}, {
    readonly name: "perm_contact_calendar";
    readonly rank: 436;
    readonly popularity: 17772;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["account", "address book", "appointment", "button", "calendar", "contact", "date", "day", "details", "directory", "element", "event", "face", "graphic", "human", "icon", "information", "interface", "meeting", "month", "organizer", "people", "perm", "permanent", "persistent", "person", "pictogram", "profile", "saved", "schedule", "symbol", "time", "ui element", "user", "year"];
}, {
    readonly name: "zoom_out";
    readonly rank: 437;
    readonly popularity: 17740;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["action", "adjust", "button", "control", "decrease", "decrease size", "discover", "document view", "enlarge", "explore", "find", "glass", "image view", "investigate", "lens", "look", "loupe", "magnify", "magnifying", "map view", "minus", "negative", "out", "pull back", "reduce view", "scale", "scale down", "search", "see", "setting", "shrink", "size", "small", "smaller", "telescopic", "tool", "view", "visual", "zoom", "zoom out"];
}, {
    readonly name: "settings_phone";
    readonly rank: 438;
    readonly popularity: 17639;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["adjust", "administration", "call", "cell", "cellular", "cog", "communication", "configuration", "connection", "contact", "control", "customize", "details", "device", "feature", "gear", "hardware", "manage", "mobile", "options", "personalization", "phone", "preferences", "settings", "setup", "system", "telephone", "tool", "wheel"];
}, {
    readonly name: "headphones";
    readonly rank: 439;
    readonly popularity: 17634;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["accessory", "audio", "audio device", "audio equipment", "call", "communication", "device", "ear", "ear cups", "earphone", "electronics", "entertainment", "equipment", "gaming", "headband", "headphones", "headphones icon", "headset", "headset icon", "listen", "listening", "listening device", "multimedia", "music", "over ear", "sound", "sound device", "stereo", "support", "technology", "virtual reality"];
}, {
    readonly name: "backup";
    readonly rank: 440;
    readonly popularity: 17573;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["archive", "arrow", "backup", "cloud", "computing", "copy", "data", "database", "digital", "document", "download", "drive", "duplicate", "file", "files folders", "folder", "history", "internet", "management", "network", "protection", "recovery", "restore", "save", "security", "server", "storage", "synchronize", "system", "technology", "transfer", "up", "upload"];
}, {
    readonly name: "circle_notifications";
    readonly rank: 441;
    readonly popularity: 17532;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["active", "activity", "alarm", "alert", "alert bell", "alert sound", "announcements", "attention", "bell", "bulletin", "chime", "circle", "circular", "contained", "current", "encircled", "incoming", "indication", "information", "message", "new", "news", "notification", "notifications", "notify", "ping", "prompt", "reminder", "reminders", "ring", "ringtone", "signal", "sound", "updates"];
}, {
    readonly name: "content_cut";
    readonly rank: 442;
    readonly popularity: 17454;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["action", "audio", "blade", "clip", "content", "copy", "craft", "cut", "divide", "doc", "document", "edit", "file", "media", "office", "paper", "paste", "remove", "scissors", "segment", "separate", "shape", "sharp", "snip", "text", "tool", "trim", "utensil", "video"];
}, {
    readonly name: "point_of_sale";
    readonly rank: 443;
    readonly popularity: 17425;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["accounting", "business", "buy", "buying", "cash", "cash register", "checkout", "commerce", "cost", "counter", "machine", "marketplace", "merchant", "money", "of", "pay", "payment", "payment terminal", "point", "point of purchase", "point of sale", "pos", "purchase", "register", "retail", "retail point of sale", "sale", "sales", "sell", "selling", "shop", "store", "system", "terminal", "till", "till machine", "till register", "transaction"];
}, {
    readonly name: "first_page";
    readonly rank: 444;
    readonly popularity: 17407;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["arrow", "back", "beginning", "book", "caret", "chevron", "control", "data", "document", "file", "first", "jump", "jump back", "left", "list", "media", "media control", "move", "navigation", "page", "play", "playback", "presentation", "previous", "reverse", "rewind", "skip back", "slide", "start", "step", "transport"];
}, {
    readonly name: "home_work";
    readonly rank: 445;
    readonly popularity: 17351;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["address", "architecture", "building", "business", "commercial", "company", "destination", "dwelling", "employment", "estate", "factory", "headquarters", "home", "house", "industry", "job", "location", "maps", "navigation", "office", "place", "real", "real estate", "residence", "residential", "shelter", "structure", "work", "workplace"];
}, {
    readonly name: "local_cafe";
    readonly rank: 446;
    readonly popularity: 17330;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["beverage", "bottle", "break", "breakfast", "cafe", "caffeine", "ceramic", "coffee", "cup", "diner", "dining", "drink", "eatery", "food", "handle", "hot drink", "kitchen", "local", "morning", "mug", "order", "refreshment", "relax", "restaurant", "service", "shop", "steam", "store", "tea", "warm"];
}, {
    readonly name: "open_with";
    readonly rank: 447;
    readonly popularity: 17324;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["application", "arrow", "arrows", "arrows pointing out", "box", "corners", "dimensions", "direction", "display", "document", "enlarge", "enter", "expand", "file", "four arrows", "frame", "full screen", "fullscreen", "maximize", "media", "mode", "move", "open", "outward arrows", "pan", "resize", "scale", "size", "square", "stretch", "view", "visual", "window", "with", "zoom"];
}, {
    readonly name: "rate_review";
    readonly rank: 448;
    readonly popularity: 17307;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["assessment", "box", "bubble", "chat bubble", "comment", "comment box", "dialogue", "enter", "evaluation", "feedback", "fill", "form", "input", "message", "opinion", "pen", "pencil", "rate", "rating", "rectangle", "review", "score", "shape", "speak", "speech bubble", "star", "stars", "talk", "text", "thought bubble", "write"];
}, {
    readonly name: "whatshot";
    readonly rank: 449;
    readonly popularity: 17303;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["alert", "alerts", "arrow", "blaze", "burning", "circle", "dangerous", "direction", "energy", "excitement", "fiery", "fire", "flame", "frames", "hazard", "heat", "hot", "ignition", "important", "inferno", "intense", "new", "news", "notification", "passion", "popular", "round", "significant", "spicy", "trending", "updates", "vital", "warmth", "warning", "whatshot"];
}, {
    readonly name: "cottage";
    readonly rank: 450;
    readonly popularity: 17217;
    readonly categories: readonly ["places"];
    readonly tags: readonly ["abode", "accommodation", "architecture", "beach", "building", "cabin", "cottage", "countryside", "door", "dwelling", "dwelling place", "estate", "home", "house", "housing", "lake", "lodge", "lodging.", "maps", "place", "property", "real", "rectangle", "residence", "residential", "roof", "rural", "shelter", "simple house", "small house", "square", "stay", "structure", "traveling", "triangle", "village", "wall", "window"];
}, {
    readonly name: "keyboard";
    readonly rank: 451;
    readonly popularity: 17195;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["access", "chat", "code", "communication", "computer", "control", "data entry", "device", "device input", "digital", "edit", "grid", "hardware", "input", "keyboard", "keypad", "keys", "letters", "message", "office", "peripheral", "programming", "rectangle", "search", "software", "squares", "technology", "text", "text field", "type", "typing", "virtual keyboard", "writing"];
}, {
    readonly name: "rss_feed";
    readonly rank: 452;
    readonly popularity: 17036;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["antenna", "application", "arc", "atom", "blog", "broadcast", "channel", "circle", "communication", "connection", "content", "curve", "data", "distribution", "dot", "feed", "information", "internet", "network", "news", "online", "point", "pulsate", "radiate", "rss", "service", "signal", "streaming", "subscribe", "syndication", "updates", "waves", "web", "website", "wifi", "wireless"];
}, {
    readonly name: "headset_mic";
    readonly rank: 453;
    readonly popularity: 16956;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["accessory", "audio", "audio device", "band", "boom mic", "call", "chat", "communication", "device", "double earpiece", "ear", "earphone", "earpieces", "entertainment", "gadget", "headphones", "headset", "listen", "listen and talk", "mic", "microphone", "music", "podcast", "record", "sound", "speak", "speak and listen", "talk", "technology", "telecommunication", "voice"];
}, {
    readonly name: "notes";
    readonly rank: 454;
    readonly popularity: 16913;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["add", "article", "checklist", "comment", "content", "create", "diary", "doc", "document", "draft", "edit", "entry", "file", "journal", "lines", "list", "manage", "memo", "message", "note", "notes", "page", "paper", "paragraph", "record", "reminder", "report", "scratchpad", "sheet", "text", "write", "writing", "written"];
}, {
    readonly name: "perm_phone_msg";
    readonly rank: 455;
    readonly popularity: 16875;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["always", "avatar", "bubble", "business", "call", "cell", "chat", "chat support", "comment", "communicate", "communication", "connected", "contact", "conversation", "device", "feedback", "glyph", "icon", "message", "mobile", "msg", "outline", "perm", "permanent", "person", "personal", "phone", "portrait", "profile", "recording", "smartphone", "speech", "speech bubble", "support", "symbol", "telephone", "user", "voice"];
}, {
    readonly name: "style";
    readonly rank: 456;
    readonly popularity: 16864;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["adjust", "alignment", "arrangement", "block", "booklet", "cards", "configure", "content", "design", "document", "edit", "editor", "filters", "formatting", "indent", "layout", "lines", "menu", "options", "paragraph", "paragraphs", "preferences", "presentation", "rich text", "settings", "spacing", "structure", "style", "tags", "text", "typeface", "typography", "visual", "writing"];
}, {
    readonly name: "label_important";
    readonly rank: 457;
    readonly popularity: 16808;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["angled", "bookmark", "categorization", "categorize", "chevron", "corner", "data", "favorite", "filled", "filter", "flag", "geometry", "highlight", "identifier", "important", "indent", "indication", "information.", "label", "library", "mail", "mark", "marker", "note", "organization", "organize", "outline", "point", "record", "remember", "right", "save", "shape", "sharp", "sort", "stamp", "sticker", "tag", "wing"];
}, {
    readonly name: "create_new_folder";
    readonly rank: 458;
    readonly popularity: 16791;
    readonly categories: readonly ["file"];
    readonly tags: readonly ["+", "add", "addition", "archive", "build", "collection", "content", "create", "data", "directory", "doc", "document", "drive", "file", "folder", "generate", "group", "library", "make", "management", "new", "organization", "plus", "produce", "rectangle", "save", "sheet", "slide", "storage", "symbol", "tab"];
}, {
    readonly name: "arrow_circle_down";
    readonly rank: 459;
    readonly popularity: 16721;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["arrow", "button", "circle", "collapse", "contained", "control", "cursor", "direction", "down", "download", "enclosed", "expand", "inside", "mover", "navigation", "point", "pointer", "round", "scroll", "shape", "within"];
}, {
    readonly name: "wysiwyg";
    readonly rank: 460;
    readonly popularity: 16699;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["Rich text editor", "basic editor", "composer", "composition", "content creation", "document", "document editing", "document editor", "document formatting", "editing", "editor", "formatting", "input field", "layout", "lines", "mode", "page", "paragraphs", "plain text editor", "screen", "simple editor", "site", "software", "styling", "system", "text", "text area", "text editing", "text editor", "text entry", "text formatting", "view", "visibility", "web", "website", "what you see is what you get", "window", "writing", "wysiwyg"];
}, {
    readonly name: "speaker_notes";
    readonly rank: 461;
    readonly popularity: 16692;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["annotation", "audio", "bubble", "bullet points", "chat", "comment", "communicate", "detail", "dialogue", "document", "explanation", "format", "information", "lecture", "lines", "list", "meeting", "message", "mute", "notes", "page", "paper", "presentation", "record", "rectangle", "sound", "speaker", "speaker notes", "speech", "square", "talking", "text", "three lines", "transcript", "voice", "volume"];
}, {
    readonly name: "indeterminate_check_box";
    readonly rank: 462;
    readonly popularity: 16688;
    readonly categories: readonly ["toggle"];
    readonly tags: readonly ["app", "application", "box", "box with line", "button", "check", "checkbox", "checkbox with line", "components", "control", "dash", "design", "form", "form control", "half", "horizontal line", "incomplete", "indeterminate", "indeterminate state", "input", "interface", "mark", "mixed", "option", "option box", "partial", "screen", "select", "selected", "selection", "selection box", "site", "square", "state", "tick", "toggle", "toggle box", "ui", "ui element", "undetermined", "ux", "web", "website"];
}, {
    readonly name: "card_membership";
    readonly rank: 463;
    readonly popularity: 16676;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["access", "account", "bill", "bookmark", "card", "cash", "certificate", "club", "club card", "coin", "commerce", "cost", "credit", "currency", "document", "dollars", "enrollment", "entry pass", "finance", "id", "identification", "identity", "login", "loyalty", "loyalty card", "membership", "money", "online", "pass", "pay", "payment", "permit", "premium", "profile", "rectangle", "registration", "shape", "shopping", "sign up", "square", "subscription", "user", "vip"];
}, {
    readonly name: "battery_charging_full";
    readonly rank: 464;
    readonly popularity: 16644;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["battery", "bolt", "capacity", "cell", "charge", "charged", "charging", "charging up", "complete", "connection", "device", "electric", "electricity", "electronic", "energy", "full", "gadget", "indicator", "instant", "level", "lightning", "low", "mobile", "plugged in", "power", "power supply", "power up", "rectangle", "status", "symbol", "technology", "thunder", "thunderbolt"];
}, {
    readonly name: "file_present";
    readonly rank: 465;
    readonly popularity: 16573;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["business", "clip", "collaboration", "communication", "conference", "content", "data", "display", "doc", "document", "drive", "education", "file", "folder", "folders", "information", "meeting", "monitor", "note", "office", "paper", "present", "presentation", "project", "projector", "reminder", "report", "reveal", "screen", "screen sharing", "share", "sheet", "show", "slide", "slideshow", "speaker", "storage", "view", "webinar", "writing"];
}, {
    readonly name: "sports_soccer";
    readonly rank: 466;
    readonly popularity: 16507;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["activity", "athlete", "athletic", "ball", "championship", "circle", "competition", "dribble", "entertainment", "exercise", "field", "fitness", "football", "game", "goal", "hexagon", "hobby", "kick", "league", "leisure", "match", "pentagon", "play", "recreation", "soccer", "social", "sport", "sports", "stadium", "team", "training", "workout"];
}, {
    readonly name: "mark_email_read";
    readonly rank: 467;
    readonly popularity: 16502;
    readonly categories: readonly ["communication"];
    readonly tags: readonly ["acknowledge", "approve", "archive", "box", "check", "checked", "communication", "complete", "confirmation", "correspondence", "correspondence.", "delivered", "document", "done", "email", "envelop", "envelope", "inbox", "letter", "letters", "mail", "mark", "mark as read", "message", "note", "notification", "ok", "opened", "paper", "read", "received", "reviewed", "select", "send", "sent", "success", "tick", "validated", "verified", "yes"];
}, {
    readonly name: "fullscreen_exit";
    readonly rank: 468;
    readonly popularity: 16449;
    readonly categories: readonly ["navigation"];
    readonly tags: readonly ["adjust", "app", "application", "arrows", "cinema", "close", "collapse", "components", "contract", "default view", "display", "escape", "exit", "exit full screen", "exit fullscreen", "full", "full screen exit", "fullscreen", "fullscreen exit", "go back", "interface", "media", "minimize", "mode", "monitor", "normal view", "player", "presentation", "reduce", "restore", "return", "revert", "screen", "shrink", "site", "size", "theatre", "ui", "ux", "video", "view", "web", "website", "window"];
}, {
    readonly name: "adjust";
    readonly rank: 469;
    readonly popularity: 16448;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["adjust", "alter", "auto click", "bar", "bars", "calibration", "center", "change", "circle", "circles", "configuration", "control panel", "controls", "customize", "dot", "filter", "fine tune", "fix", "focus", "hamburger menu", "horizontal lines", "image", "levels", "lines", "management", "menu", "modify", "move", "options", "preferences", "refine", "regulation", "settings", "sliders", "target", "three lines", "triple bar", "tuning"];
}, {
    readonly name: "percent";
    readonly rank: 470;
    readonly popularity: 16320;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["analysis", "arithmetic", "calculation", "chart", "circle", "completion", "data", "diagonal line", "discount", "dot", "geometry", "graph", "interest", "math", "metric", "number", "numbers", "numerical", "percent", "percentage", "progress", "proportion", "rate", "ratio", "representation", "savings", "sign", "slash", "statistics", "symbol", "value"];
}, {
    readonly name: "price_change";
    readonly rank: 471;
    readonly popularity: 16293;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["analysis", "arrow", "arrows", "bill", "card", "cash", "change", "chart", "coin", "commerce", "cost", "credit", "currency", "data", "decline", "decrease", "diagram", "dollars", "down", "down arrow", "fall", "finance", "financial", "graph", "growth", "increase", "market", "money", "online", "pay", "payment", "price", "price change", "report", "rise", "shopping", "statistics", "stats", "stock", "stocks", "symbol", "trend", "trending", "up", "up arrow", "value"];
}, {
    readonly name: "library_add";
    readonly rank: 472;
    readonly popularity: 16218;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["+", "add", "archive", "book", "catalog", "collection", "content", "create", "data", "document", "entry", "file", "index", "insert", "item", "layers", "library", "list", "media", "multiple", "music", "new", "organize", "page", "playlist", "plus", "queue", "record", "register", "save", "stacked", "store", "symbol", "video"];
}, {
    readonly name: "domain";
    readonly rank: 473;
    readonly popularity: 16131;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["address", "apartment", "architecture", "building", "business", "circle", "communication", "concept", "connection", "domain", "estate", "global", "globe", "home", "icon", "internet", "link", "navigation", "network", "online", "place", "real", "representation", "residence", "residential", "round", "shelter", "sphere", "symbol", "technology", "ui", "url", "web", "web address", "website", "world", "www"];
}, {
    readonly name: "pageview";
    readonly rank: 474;
    readonly popularity: 16107;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["add", "book", "browse", "circle", "content", "create", "data", "details", "doc", "document", "enlarge", "entry", "explore", "file", "find", "form", "glass", "information", "locate", "magnify", "magnifying", "new", "note", "page", "paper", "plus", "reading", "rectangle", "scan", "search", "text", "view", "zoom"];
}, {
    readonly name: "local_police";
    readonly rank: 475;
    readonly popularity: 16102;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["911", "authority", "authority symbol", "badge", "crime", "emblem", "government", "identification", "identification badge", "investigation", "justice", "law", "law and order", "law enforcement", "local", "local police", "military", "officer", "official", "police", "police department", "police emblem", "police star", "protect", "protection", "safety", "security", "shield", "star", "symbol", "uniform"];
}, {
    readonly name: "pause_circle";
    readonly rank: 476;
    readonly popularity: 16063;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["audio", "bars", "break", "button", "circle", "circular", "control", "controls", "filled", "hold", "interface", "media", "media controls", "music", "outline", "pause", "play", "playback", "player", "resume", "rounded", "shape", "stop", "suspend", "symbol", "two lines", "vertical", "video", "wait"];
}, {
    readonly name: "tv";
    readonly rank: 477;
    readonly popularity: 15986;
    readonly categories: readonly ["hardware"];
    readonly tags: readonly ["device", "display", "entertainment", "entertainment center", "glyph", "home", "house", "living room", "media", "monitor", "outline", "personal", "rectangle", "screen", "screencast", "solid fill", "squared corners", "stream", "streaming", "television", "tv", "video", "wireless"];
}, {
    readonly name: "inbox";
    readonly rank: 478;
    readonly popularity: 15911;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["archive", "arrival", "box", "category", "communication", "container", "correspondence", "email", "folder", "inbox", "inbox folder", "incoming", "letters", "mail", "mail folder", "message", "message box", "messages", "messages list", "new messages", "notifications", "receive", "receive mail", "storage", "tray", "unread"];
}, {
    readonly name: "straighten";
    readonly rank: 479;
    readonly popularity: 15911;
    readonly categories: readonly ["image"];
    readonly tags: readonly ["adjust", "align", "angle", "arrangement", "bend", "calibrate", "curve", "distribute", "evenly", "grid", "horizontal", "layout", "length", "levels", "line", "linear", "measure", "measurement", "order", "organize", "parallel", "perpendicular", "position", "right angle", "ruler", "size", "straight", "straighten", "structure", "symmetrical", "tidy", "uniform", "vertical"];
}, {
    readonly name: "stop_circle";
    readonly rank: 480;
    readonly popularity: 15865;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["audio", "block", "button", "cancel", "caution", "circle", "command", "control", "controls", "end", "exit", "finish", "forbidden", "halt", "media", "media control", "music", "pause", "play", "playback", "playback control", "player", "prevent", "prohibit", "record stop", "recording", "restricted", "round", "square", "stop", "terminate", "video", "warning"];
}, {
    readonly name: "recommend";
    readonly rank: 481;
    readonly popularity: 15813;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["affirm", "agree", "agreement", "approval", "approved", "assess", "choice", "circle", "confirm", "endorse", "evaluate", "favorite", "feedback", "gesture", "good", "hand", "like", "opinion", "positive", "preference", "rating", "reaction", "recommend", "selection", "social", "social media", "support", "thumbs", "thumbs up", "up", "upvote", "validation", "vote", "well"];
}, {
    readonly name: "chair";
    readonly rank: 482;
    readonly popularity: 15803;
    readonly categories: readonly ["search"];
    readonly tags: readonly ["balcony", "bedroom", "chair", "comfort", "couch", "decoration", "dining", "furniture", "garden", "graphic", "home", "house", "illustration", "indoors", "item", "living", "living room", "lounge", "lounging", "loveseat", "object", "office", "outline", "patio", "pictogram", "relax", "rest", "room", "seat", "seating", "simple", "sofa", "symbol"];
}, {
    readonly name: "trending_down";
    readonly rank: 483;
    readonly popularity: 15700;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["analysis", "analytics", "arrow", "arrow down", "arrow icon", "business", "chart", "data", "decline", "decrease", "decrease icon", "diagonal arrow", "diagonal line", "diagram", "dip", "direction", "down", "downtrend", "downward", "drop", "falling", "finance", "graph", "infographic", "line graph", "lowering", "measure", "metrics", "movement", "negative trend", "rate", "rating", "slump", "statistics", "stock market", "tracking", "trend icon", "trending", "trending down"];
}, {
    readonly name: "reviews";
    readonly rank: 484;
    readonly popularity: 15693;
    readonly categories: readonly ["device"];
    readonly tags: readonly ["approve", "attempt", "best", "bubble", "chat", "comment", "communicate", "evaluation", "excellence", "favorite", "feedback", "gold star", "grade", "highlighted", "important", "marked", "message", "preferred", "premium", "quality", "rank", "ranking", "rate", "rating", "recommendation", "recommended", "review", "reviews", "score", "special", "speech", "star", "top", "try", "trying", "valued"];
}, {
    readonly name: "link_off";
    readonly rank: 485;
    readonly popularity: 15669;
    readonly categories: readonly ["content"];
    readonly tags: readonly ["attached", "broken chain", "broken connection", "broken hyperlink", "broken link", "broken link icon", "chain", "clip", "connection", "connection broken", "connection off", "disable hyperlink", "disable link", "disabled", "disconnect icon", "disconnect web link", "disconnected", "enabled", "hyperlink", "link", "link broken", "link disabled", "link icon", "link off", "link removed", "linked", "links", "multimedia", "off", "on", "remove hyperlink", "remove link", "remove web link", "slash", "unlink", "url", "web address", "web icon", "web link", "website"];
}, {
    readonly name: "checklist_rtl";
    readonly rank: 486;
    readonly popularity: 15625;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["align", "alignment", "approve", "bullet points", "check", "checklist", "complete", "content list", "data", "doc", "document", "done", "edit", "editing", "editor", "entries", "form", "format", "horizontal lines", "information", "items", "lined list", "list", "management", "mark", "notes", "numbered list", "ok", "order", "organization", "plan", "planning", "progress", "report", "right-to-left", "rtl", "select", "sequence", "sheet", "spreadsheet", "survey", "tasks", "text", "tick", "to-do", "type", "validate", "verified", "writing", "yes"];
}, {
    readonly name: "mic_off";
    readonly rank: 487;
    readonly popularity: 15593;
    readonly categories: readonly ["av"];
    readonly tags: readonly ["audio", "audio input disabled", "audio off", "audio settings", "bar", "call control", "communication", "diagonal line", "disabled", "enabled", "hear", "hearing", "input settings", "meeting control", "mic", "mic disabled", "mic symbol", "microphone", "microphone icon", "microphone muted", "microphone off", "mute", "no audio", "no sound", "noise", "off", "on", "privacy", "quiet", "record", "recording", "recording mute", "recording off", "security", "silenced", "slash", "sound", "sound off", "speak off", "talk mute", "voice", "voice input off", "voice mute", "voice off"];
}, {
    readonly name: "fastfood";
    readonly rank: 488;
    readonly popularity: 15592;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["american food", "bun", "burger", "burger icon", "cheeseburger", "circle", "circle with rectangle", "cuisine", "delivery", "dinner", "drink", "eat", "fast food", "fast food icon", "fastfood", "food", "food and drink", "food and drink icon", "food icon", "hamburger", "lunch", "maps", "meal", "order food", "patty", "places", "restaurant", "restaurant icon", "round", "sandwich", "sesame seeds", "snack", "takeaway"];
}, {
    readonly name: "directions_bike";
    readonly rank: 489;
    readonly popularity: 15574;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["activity", "bicycle", "bike", "cycling", "direction", "directions", "exercise", "fitness", "green transport", "health", "human", "journey", "map", "maps", "mobility", "navigation", "outdoor", "path", "person", "public", "recreation", "ride", "riding", "road", "route", "sport", "street", "transport", "transportation", "travel", "two wheels", "urban", "vehicle", "workout"];
}, {
    readonly name: "change_history";
    readonly rank: 490;
    readonly popularity: 15555;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["audit trail", "change", "change history", "chronology", "development", "edits", "events", "evolution", "flow", "history", "journal", "journey", "log", "modifications", "past", "path", "process", "progression", "record", "revisions", "sequence", "shape", "time", "timeline", "track changes", "triangle", "updates", "version history"];
}, {
    readonly name: "mood";
    readonly rank: 491;
    readonly popularity: 15524;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["add", "character", "chat", "cheerful", "circle", "communication", "emoji", "emoticon", "emotion", "emotions", "expression", "expressions", "face", "feeling", "feelings", "glad", "grin", "happiness", "happy", "insert", "joy", "like", "message", "mood", "outline", "person", "pleased", "reaction", "round", "select", "smile", "smiley", "smiling", "social", "survey", "symbol", "tag", "text"];
}, {
    readonly name: "upgrade";
    readonly rank: 492;
    readonly popularity: 15516;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["above", "advance", "arrow", "ascent", "better", "direction", "elevation", "enhance", "export", "growth", "higher", "improve", "increase", "instal", "level up", "line", "new version", "next", "progress", "promotion", "replace", "rise", "top", "up", "update", "upgrade", "upward"];
}, {
    readonly name: "integration_instructions";
    readonly rank: 493;
    readonly popularity: 15477;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["automation", "brackets", "build", "clipboard", "code", "coding", "combine", "connect", "connection", "consolidate", "css", "data", "develop", "developer", "development", "diagram", "direction", "doc", "document", "engineer", "engineering clipboard", "flow", "guide", "help", "html", "information", "instructions", "integration", "join", "link", "merge", "network", "platform", "process", "programming", "relation", "steps", "structure", "system", "unified", "workflow"];
}, {
    readonly name: "3d_rotation";
    readonly rank: 494;
    readonly popularity: 15387;
    readonly categories: readonly ["action"];
    readonly tags: readonly ["3", "3d", "D", "alphabet", "angle", "application", "arrow", "arrows", "av", "axis", "button", "camera", "character", "control", "digit", "font", "graphic", "letters", "manipulation", "menu", "model", "numbers", "object", "option", "orientation", "perspective", "rendering", "revolve", "rotate", "rotation", "shape", "software", "spatial", "spin", "symbol", "text", "three-dimensional", "tilt", "tool", "transform", "turning", "type", "view", "virtual_reality", "visualization", "vr"];
}, {
    readonly name: "home_repair_service";
    readonly rank: 495;
    readonly popularity: 15324;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["adjustable wrench", "box", "building", "construction", "equipment", "fix", "gear", "hammer", "handyman", "home", "house", "improvement", "installation", "job", "kit", "labor", "maintenance", "mechanic", "pliers", "professional", "renovation", "repair", "repairing", "screwdriver", "service", "setup", "spanner", "technician", "tool", "toolbox", "tools", "work", "workshop", "wrench"];
}, {
    readonly name: "cleaning_services";
    readonly rank: 496;
    readonly popularity: 15294;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["broom", "care", "chore", "clean", "cleaning", "commercial", "domestic", "dust", "floor", "home", "house", "housekeeping", "hygiene", "janitorial", "maintenance", "mop", "organized", "polish", "professional", "refresh", "residential", "sanitation", "scrub", "service", "services", "sparkle", "squeaky clean", "sweep", "tidy", "wash"];
}, {
    readonly name: "recycling";
    readonly rank: 497;
    readonly popularity: 15176;
    readonly categories: readonly ["social"];
    readonly tags: readonly ["arrows", "arrows in a loop", "bio", "circle", "conservation", "cycle", "eco", "ecological", "ecology", "emblem", "environment", "environmental", "garbage", "green", "loop", "material", "materials", "process", "recyclable", "recycle", "recycling", "reduce", "remake", "remanufacture", "renewable", "renewal", "reuse", "rotate", "sustainability", "sustainable", "symbol", "three arrows", "transform", "trash", "waste"];
}, {
    readonly name: "text_fields";
    readonly rank: 498;
    readonly popularity: 15160;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["T", "add", "add text", "alphabet", "blank", "blinking cursor", "box", "character", "compose", "control", "cursor", "data entry", "document", "edit field", "edit text", "enter text", "entry", "field", "fields", "font", "form", "input", "insert", "interface", "keyboard", "letters", "lines", "point", "space", "symbol", "text", "text box", "text fields", "type", "typing", "underscore", "user input", "writer", "writing"];
}, {
    readonly name: "zoom_out_map";
    readonly rank: 499;
    readonly popularity: 15117;
    readonly categories: readonly ["maps"];
    readonly tags: readonly ["area", "arrow", "arrows", "box", "button", "center", "compass", "contract", "control", "corner", "destination", "direction", "exit full screen", "expand", "full screen", "globe", "location", "map", "maps", "marker", "middle", "minimize", "move", "navigation", "out", "place", "pointer", "rectangle", "scale", "shape", "shrink", "square", "stop", "view", "world", "zoom", "zoom out map"];
}, {
    readonly name: "table_rows";
    readonly rank: 500;
    readonly popularity: 15116;
    readonly categories: readonly ["editor"];
    readonly tags: readonly ["array", "background", "chart", "data", "database", "document", "entries", "file", "filter", "graph", "grid", "horizontal lines", "information", "layout", "lines", "list", "organize", "parallel lines", "presentation", "records", "report", "rows", "section", "sort", "spreadsheet", "stacked", "structure", "table", "view"];
}];
