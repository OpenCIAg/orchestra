import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcGridViewIcon: OrcIconDefinition;
