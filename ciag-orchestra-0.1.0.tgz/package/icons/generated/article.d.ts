import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcArticleIcon: OrcIconDefinition;
