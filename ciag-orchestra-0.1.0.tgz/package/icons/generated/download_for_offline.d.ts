import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcDownloadForOfflineIcon: OrcIconDefinition;
