import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcLocalFireDepartmentIcon: OrcIconDefinition;
