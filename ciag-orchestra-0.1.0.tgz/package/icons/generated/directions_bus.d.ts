import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcDirectionsBusIcon: OrcIconDefinition;
