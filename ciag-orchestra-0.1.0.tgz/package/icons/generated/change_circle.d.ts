import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcChangeCircleIcon: OrcIconDefinition;
