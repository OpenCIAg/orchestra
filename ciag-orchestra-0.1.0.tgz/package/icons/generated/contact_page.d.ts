import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcContactPageIcon: OrcIconDefinition;
