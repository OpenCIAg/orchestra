import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcArrowRightIcon: OrcIconDefinition;
