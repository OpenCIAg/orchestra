import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcArrowRightAltIcon: OrcIconDefinition;
