import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcLocalCafeIcon: OrcIconDefinition;
