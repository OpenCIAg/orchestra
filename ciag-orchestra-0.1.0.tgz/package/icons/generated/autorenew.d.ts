import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcAutorenewIcon: OrcIconDefinition;
