import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcAccessibilityNewIcon: OrcIconDefinition;
