import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcDashboardIcon: OrcIconDefinition;
