import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcDeleteForeverIcon: OrcIconDefinition;
