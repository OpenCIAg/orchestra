import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcGradingIcon: OrcIconDefinition;
