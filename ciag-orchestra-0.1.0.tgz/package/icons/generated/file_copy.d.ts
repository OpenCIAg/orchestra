import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcFileCopyIcon: OrcIconDefinition;
