import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcFilterListIcon: OrcIconDefinition;
