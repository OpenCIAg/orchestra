import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orc3dRotationIcon: OrcIconDefinition;
