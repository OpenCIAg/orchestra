import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcEventIcon: OrcIconDefinition;
