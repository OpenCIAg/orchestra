import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcDateRangeIcon: OrcIconDefinition;
