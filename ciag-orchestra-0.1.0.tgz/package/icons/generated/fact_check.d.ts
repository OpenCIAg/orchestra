import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcFactCheckIcon: OrcIconDefinition;
