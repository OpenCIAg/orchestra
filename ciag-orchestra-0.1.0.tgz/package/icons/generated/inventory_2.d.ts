import type { OrcIconDefinition } from '@ciag/orchestra/icon';
export declare const orcInventory2Icon: OrcIconDefinition;
