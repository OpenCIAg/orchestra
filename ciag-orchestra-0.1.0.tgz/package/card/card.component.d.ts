import * as i0 from "@angular/core";
export declare class CardComponent {
    clickable: import("@angular/core").InputSignal<boolean>;
    selected: import("@angular/core").InputSignal<boolean>;
    variant: import("@angular/core").InputSignal<"simple" | "dashboard">;
    cardClick: import("@angular/core").OutputEmitterRef<void>;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "orc-card", never, { "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "cardClick": "cardClick"; }, never, ["*"], true, never>;
}
