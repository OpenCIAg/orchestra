import * as i0 from "@angular/core";
export declare class CardHeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardHeaderComponent, "orc-card-header", never, {}, {}, never, ["*"], true, never>;
}
