import { AvatarColorVariant, AvatarItem, AvatarShape, AvatarSize } from './avatar.types';
import * as i0 from "@angular/core";
export declare class AvatarGroupComponent {
    readonly items: import("@angular/core").InputSignal<AvatarItem[]>;
    readonly max: import("@angular/core").InputSignal<number>;
    readonly size: import("@angular/core").InputSignal<AvatarSize>;
    readonly shape: import("@angular/core").InputSignal<AvatarShape>;
    readonly excessCount: import("@angular/core").InputSignal<number>;
    readonly excessColorVariant: import("@angular/core").InputSignal<AvatarColorVariant>;
    readonly bordered: import("@angular/core").InputSignal<boolean>;
    readonly visibleItems: import("@angular/core").Signal<AvatarItem[]>;
    readonly calculatedExcess: import("@angular/core").Signal<number>;
    readonly excessText: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AvatarGroupComponent, "orc-avatar-group", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "excessCount": { "alias": "excessCount"; "required": false; "isSignal": true; }; "excessColorVariant": { "alias": "excessColorVariant"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
