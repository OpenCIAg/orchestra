import * as i0 from "@angular/core";
export type DividerOrientation = 'horizontal' | 'vertical';
export type DividerVariant = 'solid' | 'dashed' | 'dotted';
export declare class DividerComponent {
    readonly orientation: import("@angular/core").InputSignal<DividerOrientation>;
    readonly variant: import("@angular/core").InputSignal<DividerVariant>;
    readonly label: import("@angular/core").InputSignal<string>;
    readonly inset: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    readonly classes: import("@angular/core").Signal<{
        [x: string]: boolean;
        'orc-divider': boolean;
        'orc-divider--vertical': boolean;
        'orc-divider--inset': boolean;
        'orc-divider--labeled': boolean;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DividerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DividerComponent, "orc-divider", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "inset": { "alias": "inset"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
