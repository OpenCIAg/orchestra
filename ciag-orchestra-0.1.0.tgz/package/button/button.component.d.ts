import { SafeHtml } from '@angular/platform-browser';
import { ButtonVariant, ButtonSize } from './button.types';
import * as i0 from "@angular/core";
export declare class ButtonComponent {
    readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
    readonly size: import("@angular/core").InputSignal<ButtonSize>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    readonly loading: import("@angular/core").InputSignal<boolean>;
    readonly fullWidth: import("@angular/core").InputSignal<boolean>;
    readonly iconLeft: import("@angular/core").InputSignal<string | undefined>;
    readonly iconRight: import("@angular/core").InputSignal<string | undefined>;
    readonly iconOnly: import("@angular/core").InputSignal<boolean>;
    readonly type: import("@angular/core").InputSignal<"button" | "submit" | "reset">;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    private readonly sanitizer;
    readonly click: import("@angular/core").OutputEmitterRef<MouseEvent>;
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    readonly safeIconLeft: import("@angular/core").Signal<{
        isSvg: boolean;
        content: SafeHtml;
    } | null>;
    readonly safeIconRight: import("@angular/core").Signal<{
        isSvg: boolean;
        content: SafeHtml;
    } | null>;
    readonly buttonClasses: import("@angular/core").Signal<{
        [x: string]: boolean;
        'orc-button': boolean;
        'orc-button--disabled': boolean;
        'orc-button--loading': boolean;
        'orc-button--full-width': boolean;
        'orc-button--icon-only': boolean;
    }>;
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "orc-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "iconLeft": { "alias": "iconLeft"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "click": "click"; }, never, ["[iconLeft]", "*", "[iconRight]"], true, never>;
}
