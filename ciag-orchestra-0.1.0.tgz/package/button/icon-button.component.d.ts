import { SafeHtml } from '@angular/platform-browser';
import { ButtonVariant, ButtonSize } from './button.types';
import * as i0 from "@angular/core";
export declare class IconButtonComponent {
    readonly variant: import("@angular/core").InputSignal<ButtonVariant>;
    readonly size: import("@angular/core").InputSignal<ButtonSize>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    readonly loading: import("@angular/core").InputSignal<boolean>;
    readonly icon: import("@angular/core").InputSignal<string | undefined>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    private readonly sanitizer;
    readonly click: import("@angular/core").OutputEmitterRef<MouseEvent>;
    readonly isDisabled: import("@angular/core").Signal<boolean>;
    readonly safeIcon: import("@angular/core").Signal<{
        isSvg: boolean;
        content: SafeHtml;
    } | null>;
    readonly buttonClasses: import("@angular/core").Signal<{
        [x: string]: boolean;
        'orc-icon-button': boolean;
        'orc-icon-button--disabled': boolean;
        'orc-icon-button--loading': boolean;
    }>;
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconButtonComponent, "orc-icon-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; }, { "click": "click"; }, never, ["*"], true, never>;
}
