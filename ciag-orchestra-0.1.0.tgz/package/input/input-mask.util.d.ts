/**
 * Utilitário de máscara leve e sem dependências externas.
 * Suporta tokens padrão:
 * - `0` ou `9`: Apenas dígitos numéricos (0-9)
 * - `A` ou `a`: Apenas letras (a-z, A-Z)
 * - `*`: Alfanumérico (letras e números)
 */
export declare function applyMask(rawVal: string, maskPattern: string): string;
export declare function cleanMask(formattedVal: string, maskPattern: string): string;
