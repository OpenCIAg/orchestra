import { AccordionToggleEvent, AccordionVariant } from './accordion.types';
import type { AccordionItemComponent } from './accordion-item.component';
import * as i0 from "@angular/core";
export declare class AccordionComponent {
    readonly multiple: import("@angular/core").InputSignal<boolean>;
    readonly variant: import("@angular/core").InputSignal<AccordionVariant>;
    readonly expandedChange: import("@angular/core").OutputEmitterRef<AccordionToggleEvent>;
    private readonly items;
    registerItem(item: AccordionItemComponent): void;
    unregisterItem(item: AccordionItemComponent): void;
    onItemToggle(targetItem: AccordionItemComponent, isExpanded: boolean): void;
    handleKeyNavigation(event: KeyboardEvent, currentItem: AccordionItemComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "orc-accordion", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; }, never, ["*"], true, never>;
}
