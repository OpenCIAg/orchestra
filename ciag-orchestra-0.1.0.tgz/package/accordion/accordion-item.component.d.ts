import { OnInit, OnDestroy, ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AccordionItemComponent implements OnInit, OnDestroy {
    private readonly accordion;
    readonly id: import("@angular/core").InputSignal<string>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly subtitle: import("@angular/core").InputSignal<string>;
    readonly icon: import("@angular/core").InputSignal<string>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    readonly hideToggle: import("@angular/core").InputSignal<boolean>;
    readonly expanded: import("@angular/core").ModelSignal<boolean>;
    readonly opened: import("@angular/core").OutputEmitterRef<void>;
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly toggle: import("@angular/core").OutputEmitterRef<boolean>;
    readonly headerButton: import("@angular/core").Signal<ElementRef<HTMLButtonElement> | undefined>;
    private readonly fallbackId;
    readonly itemId: import("@angular/core").Signal<string>;
    readonly headerId: import("@angular/core").Signal<string>;
    readonly panelId: import("@angular/core").Signal<string>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleExpanded(): void;
    focusHeader(): void;
    onKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionItemComponent, "orc-accordion-item", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; "opened": "opened"; "closed": "closed"; "toggle": "toggle"; }, never, ["[accordion-header], [accordionHeader]", "*"], true, never>;
}
