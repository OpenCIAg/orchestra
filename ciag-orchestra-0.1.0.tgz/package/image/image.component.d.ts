import * as i0 from "@angular/core";
export type ImageFit = 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
export declare class ImageComponent {
    readonly src: import("@angular/core").InputSignal<string>;
    readonly alt: import("@angular/core").InputSignal<string>;
    readonly fallbackSrc: import("@angular/core").InputSignal<string>;
    readonly fit: import("@angular/core").InputSignal<ImageFit>;
    readonly width: import("@angular/core").InputSignal<string | number>;
    readonly height: import("@angular/core").InputSignal<string | number>;
    readonly loading: import("@angular/core").InputSignal<"eager" | "lazy">;
    readonly radius: import("@angular/core").InputSignal<"none" | "sm" | "md" | "lg" | "full">;
    readonly placeholder: import("@angular/core").InputSignal<string>;
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    private readonly usingFallback;
    readonly failed: import("@angular/core").WritableSignal<boolean>;
    readonly renderedSrc: import("@angular/core").Signal<string>;
    readonly loaded: import("@angular/core").OutputEmitterRef<void>;
    readonly error: import("@angular/core").OutputEmitterRef<Event>;
    onLoad(): void;
    onError(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageComponent, "orc-image", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "fallbackSrc": { "alias": "fallbackSrc"; "required": false; "isSignal": true; }; "fit": { "alias": "fit"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "loaded": "loaded"; "error": "error"; }, never, never, true, never>;
}
