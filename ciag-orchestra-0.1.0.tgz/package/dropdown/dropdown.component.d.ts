import { AfterViewInit, TemplateRef } from '@angular/core';
import { DropdownItem } from './dropdown.types';
import * as i0 from "@angular/core";
export declare class DropdownComponent implements AfterViewInit {
    readonly items: import("@angular/core").InputSignal<DropdownItem[]>;
    readonly placement: import("@angular/core").InputSignal<string>;
    readonly itemSelect: import("@angular/core").OutputEmitterRef<DropdownItem>;
    private overlayRef;
    private portal;
    private hostEl;
    private viewContainerRef;
    private overlay;
    readonly dropdownPanel: import("@angular/core").Signal<TemplateRef<unknown>>;
    readonly isOpen: import("@angular/core").WritableSignal<boolean>;
    ngAfterViewInit(): void;
    open(): void;
    close(): void;
    toggle(): void;
    onItemClick(item: DropdownItem, $event: MouseEvent): void;
    onItemKeydown(event: KeyboardEvent): void;
    private createPositionStrategy;
    private getConnectedPositions;
    onDocumentClick(target: EventTarget | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "orc-dropdown", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; }, never, ["*"], true, never>;
}
