import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

type DrawerPlacement = 'left' | 'right' | 'top' | 'bottom';
declare class DrawerComponent {
    readonly open: _angular_core.ModelSignal<boolean>;
    /** PrimeNG-compatible visibility alias. */
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly placement: _angular_core.InputSignal<DrawerPlacement>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly closeOnBackdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly id: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showCloseIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | null>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly panel: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly backdrop: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    private releaseIsolation?;
    private readonly document;
    private readonly destroyRef;
    private previousOpen;
    private previousVisible;
    constructor();
    show(): void;
    close(): void;
    onBackdrop(): void;
    onKeydown(event: KeyboardEvent): void;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DrawerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DrawerComponent, "orc-drawer, orc-sidebar", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "closeOnBackdrop": { "alias": "closeOnBackdrop"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "showCloseIcon": { "alias": "showCloseIcon"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "visible": "visibleChange"; "closed": "closed"; "onShow": "onShow"; "onHide": "onHide"; }, never, ["[drawer-title]", "*", "[drawer-actions]"], true, never>;
}

export { DrawerComponent };
export type { DrawerPlacement };
