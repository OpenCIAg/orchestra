import * as _angular_core from '@angular/core';

type BadgeVariant = 'soft' | 'solid' | 'outline' | 'dot' | 'ghost';
type BadgeStatus = 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'pending' | 'active' | 'inactive' | 'new' | 'completed';
type BadgeSize = 'sm' | 'md' | 'lg';

declare class BadgeComponent {
    readonly variant: _angular_core.InputSignal<BadgeVariant>;
    readonly status: _angular_core.InputSignal<BadgeStatus>;
    readonly severity: _angular_core.InputSignal<BadgeStatus | undefined>;
    readonly size: _angular_core.InputSignal<BadgeSize>;
    readonly text: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string | number | undefined>;
    readonly count: _angular_core.InputSignal<number | undefined>;
    readonly maxCount: _angular_core.InputSignal<number>;
    readonly dot: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showDefaultIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pill: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly dismiss: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly effectiveStatus: _angular_core.Signal<BadgeStatus>;
    readonly displayValue: _angular_core.Signal<string>;
    readonly normalizedStatus: _angular_core.Signal<string>;
    readonly isDotOnly: _angular_core.Signal<boolean>;
    readonly accessibleLabel: _angular_core.Signal<string | undefined>;
    onDismissClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BadgeComponent, "orc-badge", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "maxCount": { "alias": "maxCount"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; "showDefaultIcon": { "alias": "showDefaultIcon"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "pill": { "alias": "pill"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "dismiss": "dismiss"; }, never, ["[badge-icon-left], [badgeIconLeft]", "*", "[badge-icon-right], [badgeIconRight]"], true, never>;
}

export { BadgeComponent };
export type { BadgeSize, BadgeStatus, BadgeVariant };
