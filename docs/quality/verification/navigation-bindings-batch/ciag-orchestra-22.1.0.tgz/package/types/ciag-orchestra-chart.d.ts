export { ChartComponent, ChartData, ChartDataset, ChartType } from '@ciag/orchestra/p2';
