import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type SliderValue = number | [number, number];
type SliderSize = 'sm' | 'md' | 'lg';
type SliderTooltipMode = 'auto' | 'always' | 'never';
interface SliderMark {
    value: number;
    label?: string;
}
interface ParsedSliderMark {
    value: number;
    percent: number;
    label: string;
}
interface SliderChangeEvent {
    value: SliderValue;
}

declare class SliderComponent implements ControlValueAccessor, OnDestroy {
    private readonly document;
    private activeWindow;
    private readonly uniqueId;
    readonly trackRef: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly startThumbRef: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly endThumbRef: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly id: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string>;
    readonly range: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly animate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly min: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly max: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly step: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly size: _angular_core.InputSignal<SliderSize>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showTicks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showLabels: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly marks: _angular_core.InputSignal<Record<number, string> | SliderMark[] | number[] | undefined>;
    readonly showTooltip: _angular_core.InputSignal<SliderTooltipMode>;
    readonly tooltip: _angular_core.InputSignal<string | undefined>;
    readonly tooltipPosition: _angular_core.InputSignal<"top" | "bottom" | "left" | "right">;
    readonly valueFormatter: _angular_core.InputSignal<((val: number) => string) | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelMin: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelMax: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.ModelSignal<SliderValue>;
    readonly sliderChange: _angular_core.OutputEmitterRef<SliderValue>;
    readonly sliderInput: _angular_core.OutputEmitterRef<SliderValue>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        value: SliderValue;
    }>;
    readonly onSlideEnd: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        value: SliderValue;
    }>;
    protected readonly activeThumb: _angular_core.WritableSignal<"start" | "end" | null>;
    protected readonly isDragging: _angular_core.WritableSignal<boolean>;
    protected readonly hoveredThumb: _angular_core.WritableSignal<"start" | "end" | null>;
    protected readonly focusedThumb: _angular_core.WritableSignal<"start" | "end" | null>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private activePointerId;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly helperId: _angular_core.Signal<string>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly minVal: _angular_core.Signal<number>;
    readonly maxVal: _angular_core.Signal<number>;
    readonly stepVal: _angular_core.Signal<number>;
    readonly normalizedValues: _angular_core.Signal<[number, number]>;
    readonly currentStartValue: _angular_core.Signal<number>;
    readonly currentEndValue: _angular_core.Signal<number>;
    readonly startPercent: _angular_core.Signal<number>;
    readonly endPercent: _angular_core.Signal<number>;
    readonly fillLeftPercent: _angular_core.Signal<number>;
    readonly fillWidthPercent: _angular_core.Signal<number>;
    readonly formattedStartValue: _angular_core.Signal<string>;
    readonly formattedEndValue: _angular_core.Signal<string>;
    readonly parsedMarks: _angular_core.Signal<ParsedSliderMark[]>;
    readonly ticks: _angular_core.Signal<number[]>;
    private onModelChange;
    private onTouched;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    protected onTrackPointerDown(event: PointerEvent): void;
    private onGlobalPointerMove;
    private onGlobalPointerUp;
    protected onKeyDown(event: KeyboardEvent, thumb: 'start' | 'end'): void;
    protected onThumbFocus(thumb: 'start' | 'end'): void;
    protected onThumbBlur(): void;
    protected onThumbMouseEnter(thumb: 'start' | 'end'): void;
    protected onThumbMouseLeave(): void;
    private updateValueByTarget;
    private snapToStep;
    private calculatePercent;
    private percentToValue;
    private pointerPercent;
    private clamp;
    shouldShowTooltip(thumb: 'start' | 'end'): boolean;
    ngOnDestroy(): void;
    private removeGlobalListeners;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SliderComponent, "orc-slider", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "range": { "alias": "range"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "animate": { "alias": "animate"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "showTicks": { "alias": "showTicks"; "required": false; "isSignal": true; }; "showLabels": { "alias": "showLabels"; "required": false; "isSignal": true; }; "marks": { "alias": "marks"; "required": false; "isSignal": true; }; "showTooltip": { "alias": "showTooltip"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "valueFormatter": { "alias": "valueFormatter"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelMin": { "alias": "ariaLabelMin"; "required": false; "isSignal": true; }; "ariaLabelMax": { "alias": "ariaLabelMax"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "sliderChange": "sliderChange"; "sliderInput": "sliderInput"; "onChange": "onChange"; "onSlideEnd": "onSlideEnd"; }, never, never, true, never>;
}

export { SliderComponent };
export type { ParsedSliderMark, SliderChangeEvent, SliderMark, SliderSize, SliderTooltipMode, SliderValue };
