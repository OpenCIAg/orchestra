import * as _angular_core from '@angular/core';
import { TemplateRef, OnInit } from '@angular/core';
import * as _ciag_orchestra_table from '@ciag/orchestra/table';
import { CheckboxChangeEvent } from '@ciag/orchestra/checkbox';

type SortDirection = 'asc' | 'desc' | 'none';
type ColumnAlign = 'left' | 'center' | 'right';
interface TableSortEvent {
    column: string;
    direction: SortDirection;
}
interface TableRowSelectEvent<T = any> {
    row: T;
    selected: boolean;
    selectedRows: T[];
}
interface TableColumnConfig {
    key: string;
    header: string;
    sortable?: boolean;
    width?: string;
    align?: ColumnAlign;
}
/** Controlled query emitted by `orc-table` in server-driven mode. */
interface TableQuery {
    first: number;
    rows: number;
    sort?: {
        column: string;
        direction: SortDirection;
    };
    filter?: string;
    filters: Record<string, unknown>;
}

declare class CellDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CellDefDirective, "[orcCellDef], [appCellDef]", never, {}, {}, never, never, true, never>;
}
declare class HeaderCellDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HeaderCellDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<HeaderCellDefDirective, "[orcHeaderCellDef], [appHeaderCellDef]", never, {}, {}, never, never, true, never>;
}

declare class ColumnDirective {
    /** Chave do objeto que identifica a propriedade da coluna */
    readonly key: _angular_core.InputSignal<string>;
    /** Título do cabeçalho da coluna */
    readonly header: _angular_core.InputSignal<string>;
    /** Habilita ordenação para esta coluna */
    readonly sortable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Largura customizada da coluna (ex: '120px', '20%') */
    readonly width: _angular_core.InputSignal<string>;
    /** Alinhamento do conteúdo: 'left' | 'center' | 'right' */
    readonly align: _angular_core.InputSignal<ColumnAlign>;
    /** Template customizado de corpo da célula */
    readonly cellTemplate: _angular_core.Signal<CellDefDirective | undefined>;
    /** Template customizado de cabeçalho da coluna */
    readonly headerTemplate: _angular_core.Signal<HeaderCellDefDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColumnDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ColumnDirective, "orc-column, app-column", never, { "key": { "alias": "key"; "required": true; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, ["cellTemplate", "headerTemplate"], never, true, never>;
}

declare class TableFooterDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableFooterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TableFooterDirective, "[orcTableFooter]", never, {}, {}, never, never, true, never>;
}
declare class TableRowExpansionDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableRowExpansionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TableRowExpansionDirective, "[orcRowExpansion]", never, {}, {}, never, never, true, never>;
}

interface TableColumnView {
    key(): string;
    header(): string;
    sortable(): boolean;
    width(): string;
    align(): 'left' | 'center' | 'right';
    cellTemplate(): CellDefDirective | undefined;
    headerTemplate(): HeaderCellDefDirective | undefined;
}
interface TablePageChangeEvent {
    page: number;
    pageSize: number;
    startIndex: number;
}
declare class TableComponent<T = any> implements OnInit {
    /** Dados a serem exibidos na tabela */
    readonly data: _angular_core.InputSignal<T[]>;
    readonly value: _angular_core.InputSignal<T[] | undefined>;
    readonly frozenColumns: _angular_core.InputSignal<any[] | undefined>;
    readonly frozenValue: _angular_core.InputSignal<T[] | undefined>;
    /** Configuração direta de colunas (alternativa ao uso de <orc-column>) */
    readonly columnsConfig: _angular_core.InputSignal<TableColumnConfig[] | undefined>;
    /** Propriedade identificadora única de cada linha (padrão: 'id') */
    readonly rowKey: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly selectAllAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly rowAriaLabel: _angular_core.InputSignal<string | undefined>;
    /** Habilita seleção de linhas com checkbox na primeira coluna */
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | undefined>;
    /** Linhas selecionadas (Two-Way Binding) */
    readonly selectedRows: _angular_core.ModelSignal<T[]>;
    /** Evento emitido quando a seleção muda */
    readonly selectionChange: _angular_core.OutputEmitterRef<T[]>;
    readonly rowSelect: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly rowUnselect: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly onRowSelect: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly onRowUnselect: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly selectAllChange: _angular_core.OutputEmitterRef<{
        checked: boolean;
        data: T[];
    }>;
    /** Chave da coluna ordenada atualmente */
    readonly sortColumn: _angular_core.ModelSignal<string>;
    /** Direção da ordenação atual: 'asc' | 'desc' | 'none' */
    readonly sortDirection: _angular_core.ModelSignal<SortDirection>;
    readonly sortField: _angular_core.ModelSignal<string>;
    readonly sortOrder: _angular_core.ModelSignal<number>;
    readonly sorting: _angular_core.WritableSignal<TableSortEvent>;
    /** Evento emitido quando o usuário clica para ordenar uma coluna */
    readonly sortChange: _angular_core.OutputEmitterRef<TableSortEvent>;
    readonly onSort: _angular_core.OutputEmitterRef<TableSortEvent>;
    /** Linhas zebradas alternadas */
    readonly striped: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Bordas ao redor da tabela e células */
    readonly bordered: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Realce visual no hover sobre as linhas */
    readonly hoverable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly tableStyleClass: _angular_core.InputSignal<string>;
    readonly tableStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly rowHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showGridlines: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stripedRows: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly responsiveLayout: _angular_core.InputSignal<string>;
    readonly breakpoint: _angular_core.InputSignal<string>;
    readonly autoLayout: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollDirection: _angular_core.InputSignal<"vertical" | "horizontal" | "both">;
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly resizableColumns: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly reorderableColumns: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly customSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showInitialSortBadge: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly exportFilename: _angular_core.InputSignal<string>;
    readonly csvSeparator: _angular_core.InputSignal<string>;
    readonly exportHeader: _angular_core.InputSignal<string | undefined>;
    readonly stateKey: _angular_core.InputSignal<string | undefined>;
    readonly stateStorage: _angular_core.InputSignal<"session" | "local">;
    readonly editMode: _angular_core.InputSignal<"cell" | "row">;
    readonly rowExpandMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly groupRowsBy: _angular_core.InputSignal<any>;
    readonly rowGroupMode: _angular_core.InputSignal<"subheader" | "rowspan" | undefined>;
    readonly rowTrackBy: _angular_core.InputSignal<((index: number, row: T) => unknown) | undefined>;
    readonly contextMenuSelection: _angular_core.ModelSignal<T | null>;
    readonly contextMenuSelectionMode: _angular_core.InputSignal<"separate" | "joint">;
    readonly filters: _angular_core.InputSignal<Record<string, unknown>>;
    /** Consumer owns fetching, filtering and paging; the table only emits queries. */
    readonly serverDriven: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly queryChange: _angular_core.OutputEmitterRef<_ciag_orchestra_table.TableQuery>;
    readonly filterDelay: _angular_core.InputSignal<number>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filter: _angular_core.ModelSignal<string>;
    readonly globalFilterFields: _angular_core.InputSignal<string[]>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    /** Exibe estado de carregamento com Skeletons */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Quantidade de linhas skeleton a renderizar durante loading */
    readonly loadingRowsCount: _angular_core.InputSignal<number>;
    /** Título principal do estado vazio */
    readonly emptyTitle: _angular_core.InputSignal<string | undefined>;
    /** Mensagem descritiva do estado vazio */
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    /** Habilita rodapé com PaginatorComponent integrado */
    readonly paginated: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly paginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Quantidade de itens por página (Two-Way Binding) */
    readonly pageSize: _angular_core.ModelSignal<number>;
    readonly rowsInput: _angular_core.InputSignal<number | undefined>;
    readonly first: _angular_core.ModelSignal<number>;
    /** Página atual (1-indexed, Two-Way Binding) */
    readonly currentPage: _angular_core.ModelSignal<number>;
    /** Total de itens para paginação do lado do servidor (se omitido, usa data().length) */
    readonly totalItems: _angular_core.InputSignal<number | undefined>;
    readonly totalRecords: _angular_core.InputSignal<number | undefined>;
    /** Opções de tamanho de página */
    readonly pageSizeOptions: _angular_core.InputSignal<number[]>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[] | undefined>;
    readonly pageLinks: _angular_core.InputSignal<number>;
    readonly alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly paginatorPosition: _angular_core.InputSignal<"both" | "top" | "bottom">;
    readonly paginatorStyleClass: _angular_core.InputSignal<string>;
    readonly currentPageReportTemplate: _angular_core.InputSignal<string | undefined>;
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectionPageOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly rowSelectable: _angular_core.InputSignal<((row: {
        data: T;
        index: number;
    }) => boolean) | undefined>;
    readonly paginatorDropdownAppendTo: _angular_core.InputSignal<unknown>;
    readonly paginatorDropdownScrollHeight: _angular_core.InputSignal<string>;
    readonly virtualScrollDelay: _angular_core.InputSignal<number>;
    readonly contextMenu: _angular_core.InputSignal<unknown>;
    readonly defaultSortOrder: _angular_core.InputSignal<number>;
    readonly sortMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly resetPageOnSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly compareSelectionBy: _angular_core.InputSignal<"equals" | "deepEquals">;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly showLoader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly onPage: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onRowExpand: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly onRowCollapse: _angular_core.OutputEmitterRef<{
        data: T;
    }>;
    readonly onContextMenuSelect: _angular_core.OutputEmitterRef<{
        data: T;
        originalEvent: Event;
    }>;
    readonly onColResize: _angular_core.OutputEmitterRef<unknown>;
    readonly onColReorder: _angular_core.OutputEmitterRef<unknown>;
    readonly onRowReorder: _angular_core.OutputEmitterRef<unknown>;
    readonly onEditInit: _angular_core.OutputEmitterRef<unknown>;
    readonly onEditComplete: _angular_core.OutputEmitterRef<unknown>;
    readonly onEditCancel: _angular_core.OutputEmitterRef<unknown>;
    readonly onHeaderCheckboxToggle: _angular_core.OutputEmitterRef<unknown>;
    readonly onStateSave: _angular_core.OutputEmitterRef<unknown>;
    readonly onStateRestore: _angular_core.OutputEmitterRef<unknown>;
    readonly sortFunction: _angular_core.OutputEmitterRef<unknown>;
    readonly rowClick: _angular_core.OutputEmitterRef<T>;
    readonly declaredColumns: _angular_core.Signal<readonly ColumnDirective[]>;
    readonly footerTemplate: _angular_core.Signal<TableFooterDirective | undefined>;
    readonly rowExpansionTemplate: _angular_core.Signal<TableRowExpansionDirective | undefined>;
    readonly expandedRows: _angular_core.ModelSignal<T[]>;
    readonly effectiveData: _angular_core.Signal<T[]>;
    readonly effectivePageSize: _angular_core.WritableSignal<number>;
    private readonly requestedFirst;
    readonly remoteData: _angular_core.Signal<boolean>;
    readonly effectiveRowsPerPageOptions: _angular_core.Signal<number[]>;
    readonly effectivePaginated: _angular_core.Signal<boolean>;
    readonly selectionEnabled: _angular_core.Signal<boolean>;
    /** Uses projected columns when present, otherwise adapts the direct config API. */
    readonly effectiveColumns: _angular_core.Signal<readonly TableColumnView[]>;
    readonly effectiveTotalItems: _angular_core.Signal<number>;
    /** Dados ordenados localmente */
    readonly filteredData: _angular_core.Signal<T[]>;
    private readonly collator;
    readonly sortedData: _angular_core.Signal<T[]>;
    readonly displayFirst: _angular_core.Signal<number>;
    readonly displayedPage: _angular_core.Signal<number>;
    /** Dados exibidos na página atual */
    readonly displayData: _angular_core.Signal<T[]>;
    readonly selectableRows: _angular_core.Signal<T[]>;
    private readonly selectedKeys;
    /** Verifica se todas as linhas da página atual estão selecionadas */
    readonly isAllSelected: _angular_core.Signal<boolean>;
    /** Verifica se parte das linhas está selecionada (estado indeterminado) */
    readonly isSomeSelected: _angular_core.Signal<boolean>;
    getRowId(row: any): any;
    trackRow(index: number, row: T): unknown;
    isRowSelected(row: T, selected?: T[]): boolean;
    private selectionKey;
    private sameRow;
    isRowSelectable(row: T, index: number): boolean;
    displayRowIndex(index: number): number;
    toggleRowSelect(row: any, event: CheckboxChangeEvent | boolean): void;
    toggleSelectAll(event: CheckboxChangeEvent | boolean): void;
    handleSort(columnKey: string, isSortable?: boolean, originalEvent?: Event): void;
    ngOnInit(): void;
    applyFilter(value: string): void;
    handlePageChange(event: TablePageChangeEvent): void;
    toggleRowExpansion(row: T): void;
    isExpanded(row: T): boolean;
    private emitQuery;
    handleRowClick(row: T, event?: Event): void;
    onRowKeydown(row: T, event: KeyboardEvent): void;
    onHeaderKeydown(column: TableColumnView, event: KeyboardEvent): void;
    getAriaSort(columnKey: string, isSortable?: boolean): 'ascending' | 'descending' | 'none' | null;
    getCellValue(row: any, key: string): any;
    getSkeletonArray(): number[];
    reset(): void;
    exportCSV(options?: {
        selectionOnly?: boolean;
    }): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableComponent<any>, "orc-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "frozenColumns": { "alias": "frozenColumns"; "required": false; "isSignal": true; }; "frozenValue": { "alias": "frozenValue"; "required": false; "isSignal": true; }; "columnsConfig": { "alias": "columnsConfig"; "required": false; "isSignal": true; }; "rowKey": { "alias": "rowKey"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "selectAllAriaLabel": { "alias": "selectAllAriaLabel"; "required": false; "isSignal": true; }; "rowAriaLabel": { "alias": "rowAriaLabel"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "selectedRows": { "alias": "selectedRows"; "required": false; "isSignal": true; }; "sortColumn": { "alias": "sortColumn"; "required": false; "isSignal": true; }; "sortDirection": { "alias": "sortDirection"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "hoverable": { "alias": "hoverable"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "tableStyleClass": { "alias": "tableStyleClass"; "required": false; "isSignal": true; }; "tableStyle": { "alias": "tableStyle"; "required": false; "isSignal": true; }; "rowHover": { "alias": "rowHover"; "required": false; "isSignal": true; }; "showGridlines": { "alias": "showGridlines"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "responsiveLayout": { "alias": "responsiveLayout"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "autoLayout": { "alias": "autoLayout"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "scrollDirection": { "alias": "scrollDirection"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "resizableColumns": { "alias": "resizableColumns"; "required": false; "isSignal": true; }; "reorderableColumns": { "alias": "reorderableColumns"; "required": false; "isSignal": true; }; "customSort": { "alias": "customSort"; "required": false; "isSignal": true; }; "showInitialSortBadge": { "alias": "showInitialSortBadge"; "required": false; "isSignal": true; }; "exportFilename": { "alias": "exportFilename"; "required": false; "isSignal": true; }; "csvSeparator": { "alias": "csvSeparator"; "required": false; "isSignal": true; }; "exportHeader": { "alias": "exportHeader"; "required": false; "isSignal": true; }; "stateKey": { "alias": "stateKey"; "required": false; "isSignal": true; }; "stateStorage": { "alias": "stateStorage"; "required": false; "isSignal": true; }; "editMode": { "alias": "editMode"; "required": false; "isSignal": true; }; "rowExpandMode": { "alias": "rowExpandMode"; "required": false; "isSignal": true; }; "groupRowsBy": { "alias": "groupRowsBy"; "required": false; "isSignal": true; }; "rowGroupMode": { "alias": "rowGroupMode"; "required": false; "isSignal": true; }; "rowTrackBy": { "alias": "rowTrackBy"; "required": false; "isSignal": true; }; "contextMenuSelection": { "alias": "contextMenuSelection"; "required": false; "isSignal": true; }; "contextMenuSelectionMode": { "alias": "contextMenuSelectionMode"; "required": false; "isSignal": true; }; "filters": { "alias": "filters"; "required": false; "isSignal": true; }; "serverDriven": { "alias": "serverDriven"; "required": false; "isSignal": true; }; "filterDelay": { "alias": "filterDelay"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingRowsCount": { "alias": "loadingRowsCount"; "required": false; "isSignal": true; }; "emptyTitle": { "alias": "emptyTitle"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "paginated": { "alias": "paginated"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "rowsInput": { "alias": "rows"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showJumpToPageInput": { "alias": "showJumpToPageInput"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "selectionPageOnly": { "alias": "selectionPageOnly"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "rowSelectable": { "alias": "rowSelectable"; "required": false; "isSignal": true; }; "paginatorDropdownAppendTo": { "alias": "paginatorDropdownAppendTo"; "required": false; "isSignal": true; }; "paginatorDropdownScrollHeight": { "alias": "paginatorDropdownScrollHeight"; "required": false; "isSignal": true; }; "virtualScrollDelay": { "alias": "virtualScrollDelay"; "required": false; "isSignal": true; }; "contextMenu": { "alias": "contextMenu"; "required": false; "isSignal": true; }; "defaultSortOrder": { "alias": "defaultSortOrder"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "resetPageOnSort": { "alias": "resetPageOnSort"; "required": false; "isSignal": true; }; "compareSelectionBy": { "alias": "compareSelectionBy"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "showLoader": { "alias": "showLoader"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "expandedRows": { "alias": "expandedRows"; "required": false; "isSignal": true; }; }, { "selectedRows": "selectedRowsChange"; "selectionChange": "selectionChange"; "rowSelect": "rowSelect"; "rowUnselect": "rowUnselect"; "onRowSelect": "onRowSelect"; "onRowUnselect": "onRowUnselect"; "selectAllChange": "selectAllChange"; "sortColumn": "sortColumnChange"; "sortDirection": "sortDirectionChange"; "sortField": "sortFieldChange"; "sortOrder": "sortOrderChange"; "sortChange": "sortChange"; "onSort": "onSort"; "contextMenuSelection": "contextMenuSelectionChange"; "queryChange": "queryChange"; "filter": "filterChange"; "onFilter": "onFilter"; "pageSize": "pageSizeChange"; "first": "firstChange"; "currentPage": "currentPageChange"; "onPage": "onPage"; "onLazyLoad": "onLazyLoad"; "onRowExpand": "onRowExpand"; "onRowCollapse": "onRowCollapse"; "onContextMenuSelect": "onContextMenuSelect"; "onColResize": "onColResize"; "onColReorder": "onColReorder"; "onRowReorder": "onRowReorder"; "onEditInit": "onEditInit"; "onEditComplete": "onEditComplete"; "onEditCancel": "onEditCancel"; "onHeaderCheckboxToggle": "onHeaderCheckboxToggle"; "onStateSave": "onStateSave"; "onStateRestore": "onStateRestore"; "sortFunction": "sortFunction"; "rowClick": "rowClick"; "expandedRows": "expandedRowsChange"; }, ["declaredColumns", "footerTemplate", "rowExpansionTemplate"], never, true, never>;
}

export { CellDefDirective, ColumnDirective, HeaderCellDefDirective, TableComponent, TableFooterDirective, TableRowExpansionDirective };
export type { ColumnAlign, SortDirection, TableColumnConfig, TableQuery, TableRowSelectEvent, TableSortEvent };
