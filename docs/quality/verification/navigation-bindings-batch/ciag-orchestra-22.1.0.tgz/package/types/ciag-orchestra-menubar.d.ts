export { MenubarComponent, MenubarItem } from '@ciag/orchestra/p2';
