import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type SwitchSize = 'sm' | 'md' | 'lg';
type SwitchLabelPosition = 'start' | 'end';
interface SwitchChangeEvent<T = any> {
    originalEvent?: Event;
    checked: boolean;
    value?: T;
}

declare class SwitchComponent implements ControlValueAccessor {
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<any>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly trueValue: _angular_core.InputSignal<any>;
    readonly falseValue: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<SwitchSize>;
    readonly labelPosition: _angular_core.InputSignal<SwitchLabelPosition>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledby: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly change: _angular_core.OutputEmitterRef<SwitchChangeEvent<any>>;
    readonly onChange: _angular_core.OutputEmitterRef<SwitchChangeEvent<any>>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly buttonElement: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    readonly uniqueId: string;
    private readonly cvaDisabled;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly labelId: _angular_core.Signal<string>;
    readonly descriptionId: _angular_core.Signal<string>;
    readonly errorId: _angular_core.Signal<string>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isError: _angular_core.Signal<boolean>;
    readonly computedAriaLabelledBy: _angular_core.Signal<string | null>;
    readonly computedAriaDescribedBy: _angular_core.Signal<string | null>;
    readonly hasContent: _angular_core.Signal<boolean>;
    private onModelChange;
    private onTouched;
    writeValue(val: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onToggle(event: Event): void;
    handleBlur(event?: Event): void;
    toggle(): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SwitchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SwitchComponent, "orc-switch, orc-toggle-switch, orc-toggle", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "ariaDescribedby"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "change": "change"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, ["*", "*", "*"], true, never>;
}

export { SwitchComponent };
export type { SwitchChangeEvent, SwitchLabelPosition, SwitchSize };
