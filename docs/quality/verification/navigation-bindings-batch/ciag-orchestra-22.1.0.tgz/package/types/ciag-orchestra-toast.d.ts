import * as _angular_core from '@angular/core';

type ToastStatus = 'success' | 'info' | 'warning' | 'error' | 'loading' | 'notification';
type ToastPosition = 'top-right' | 'top-left' | 'top-center' | 'bottom-right' | 'bottom-left' | 'bottom-center';
interface ToastAction {
    /** Rótulo textual do botão de ação (ex: 'Desfazer', 'Saiba mais') */
    label: string;
    /** Ícone opcional exibido no botão ('undo' | 'arrow' | 'info' | custom svg) */
    icon?: 'undo' | 'arrow' | 'info' | string;
    /** Callback executado quando o usuário clica na ação */
    onClick: (toast: ToastItem) => void;
}
interface ToastOptions {
    /** PrimeNG message aliases. */
    key?: string;
    severity?: 'success' | 'info' | 'warn' | 'error' | 'secondary' | 'contrast';
    summary?: string;
    detail?: string;
    life?: number;
    sticky?: boolean;
    /** Identificador único opcional (se omitido, será gerado automaticamente) */
    id?: string;
    /** Tipo / severidade da notificação */
    type?: ToastStatus;
    /** Título principal do Toast (opcional se fornecido message) */
    title?: string;
    /** Mensagem ou descrição contextual */
    message?: string;
    /** Tempo de exibição em milissegundos antes do auto-dismiss (padrão: 5000ms. 0 ou Infinity para desativar) */
    duration?: number;
    /** Exibe a barra de progresso / contador visual de tempo restante na base do toast (padrão: false) */
    showProgressBar?: boolean;
    /** Exibe o botão manual de fechar 'X' (padrão: true) */
    dismissible?: boolean;
    /** Exibe o ícone do tipo à esquerda (padrão: true) */
    showIcon?: boolean;
    /** Posição do toast na tela (padrão: 'top-right') */
    position?: ToastPosition;
    /** Ação customizada com botão dentro do toast */
    action?: ToastAction;
    /** Pausa o timer de auto-dismiss quando o usuário passa o mouse por cima (padrão: true) */
    pauseOnHover?: boolean;
    /** Sobrescreve o atributo role WCAG (padrão: 'alert' para erro/atenção, 'status' para sucesso/info/notificação) */
    role?: 'status' | 'alert';
    /** Sobrescreve o atributo aria-live WCAG */
    ariaLive?: 'polite' | 'assertive' | 'off';
    /** Rótulo de acessibilidade customizado */
    ariaLabel?: string;
    /** Rótulo de acessibilidade do controle de fechamento */
    closeAriaLabel?: string;
}
interface ToastItem extends ToastOptions {
    id: string;
    type: ToastStatus;
    title: string;
    message: string;
    duration: number;
    showProgressBar?: boolean;
    dismissible: boolean;
    showIcon: boolean;
    position: ToastPosition;
    pauseOnHover: boolean;
    createdAt: number;
}

declare class ToastService {
    private readonly appRef;
    private readonly injector;
    private readonly document;
    readonly toasts: _angular_core.WritableSignal<ToastItem[]>;
    readonly activeCount: _angular_core.Signal<number>;
    private defaultPosition;
    private defaultDuration;
    private preventDuplicates;
    private preventOpenDuplicates;
    private containerRef;
    private isCreatingContainer;
    private idCounter;
    private destroyed;
    private readonly containers;
    /** A service stream is rendered once; explicit toast arrays remain independent. */
    registerContainer(owner: symbol): () => void;
    isContainerOwner(owner: symbol): boolean;
    private disposeContainer;
    constructor();
    private ensureContainer;
    setDefaultPosition(position: ToastPosition): void;
    setDefaultDuration(duration: number): void;
    setPreventDuplicates(value: boolean): void;
    setPreventOpenDuplicates(value: boolean): void;
    show(optionsOrMessage: ToastOptions | string): string;
    add(message: ToastOptions): string;
    addAll(messages: ToastOptions[]): string[];
    remove(id: string): void;
    success(message: string, options?: Partial<ToastOptions>): string;
    info(message: string, options?: Partial<ToastOptions>): string;
    warning(message: string, options?: Partial<ToastOptions>): string;
    error(message: string, options?: Partial<ToastOptions>): string;
    loading(message: string, options?: Partial<ToastOptions>): string;
    notification(message: string, options?: Partial<ToastOptions>): string;
    dismiss(id: string): void;
    clear(key?: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ToastService>;
}

declare class ToastComponent {
    private readonly destroyRef;
    private readonly element;
    readonly toast: _angular_core.InputSignal<ToastItem>;
    readonly dismiss: _angular_core.OutputEmitterRef<string>;
    readonly actionClick: _angular_core.OutputEmitterRef<ToastItem>;
    readonly onClose: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        message: ToastItem;
    }>;
    readonly onClick: _angular_core.OutputEmitterRef<{
        originalEvent: MouseEvent;
        message: ToastItem;
    }>;
    readonly isHovered: _angular_core.WritableSignal<boolean>;
    readonly isFocused: _angular_core.WritableSignal<boolean>;
    readonly isPaused: _angular_core.Signal<boolean>;
    readonly isExiting: _angular_core.WritableSignal<boolean>;
    readonly progress: _angular_core.WritableSignal<number>;
    private timerInterval;
    private dismissTimeout;
    private remainingTime;
    private totalDuration;
    private deadline;
    private expiryTimeout;
    readonly computedRole: _angular_core.Signal<string>;
    readonly computedAriaLive: _angular_core.Signal<string>;
    readonly hasProgressBar: _angular_core.Signal<boolean>;
    constructor();
    private initTimer;
    private resumeTimer;
    private pauseTimer;
    private clearTimer;
    private clearDismissTimeout;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onFocusIn(): void;
    onFocusOut(event: FocusEvent): void;
    handleClose(originalEvent?: Event): void;
    handleToastClick(event: MouseEvent): void;
    handleAction(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToastComponent, "orc-toast", never, { "toast": { "alias": "toast"; "required": true; "isSignal": true; }; }, { "dismiss": "dismiss"; "actionClick": "actionClick"; "onClose": "onClose"; "onClick": "onClick"; }, never, never, true, never>;
}

declare class ToastContainerComponent {
    private readonly toastService;
    readonly toasts: _angular_core.InputSignal<ToastItem[] | undefined>;
    readonly dismiss: _angular_core.OutputEmitterRef<string>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly preventOpenDuplicates: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly preventDuplicates: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /** @internal Used by the service's automatically mounted outlet. */
    readonly automatic: _angular_core.InputSignal<boolean>;
    private readonly owner;
    readonly showTransformOptions: _angular_core.InputSignal<string>;
    readonly hideTransformOptions: _angular_core.InputSignal<string>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    constructor();
    readonly positions: ToastPosition[];
    /** Lista consolidada de toasts (input declarativo com fallback para o ToastService) */
    readonly activeToasts: _angular_core.Signal<ToastItem[]>;
    /** Agrupa os toasts de forma reativa e memorizada por posição */
    readonly toastsByPosition: _angular_core.Signal<Record<ToastPosition, ToastItem[]>>;
    handleDismiss(id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastContainerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToastContainerComponent, "orc-toast-container", never, { "toasts": { "alias": "toasts"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "preventOpenDuplicates": { "alias": "preventOpenDuplicates"; "required": false; "isSignal": true; }; "preventDuplicates": { "alias": "preventDuplicates"; "required": false; "isSignal": true; }; "automatic": { "alias": "automatic"; "required": false; "isSignal": true; }; "showTransformOptions": { "alias": "showTransformOptions"; "required": false; "isSignal": true; }; "hideTransformOptions": { "alias": "hideTransformOptions"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "dismiss": "dismiss"; }, never, never, true, never>;
}

export { ToastComponent, ToastContainerComponent, ToastService };
export type { ToastAction, ToastItem, ToastOptions, ToastPosition, ToastStatus };
