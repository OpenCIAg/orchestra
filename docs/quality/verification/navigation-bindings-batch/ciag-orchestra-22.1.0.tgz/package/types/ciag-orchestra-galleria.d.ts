export { GalleriaComponent, GalleryImage } from '@ciag/orchestra/p2';
