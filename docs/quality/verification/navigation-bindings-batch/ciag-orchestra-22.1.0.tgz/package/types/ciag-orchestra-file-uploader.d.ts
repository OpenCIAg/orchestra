import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';

type FileStatus = 'pending' | 'uploading' | 'success' | 'error';
interface FileItemData {
    id: string;
    file: File;
    name: string;
    size: number;
    formattedSize: string;
    type: string;
    progress: number;
    status: FileStatus;
    errorMessage?: string;
    previewUrl?: string;
}

declare class FileUploaderComponent implements ControlValueAccessor, OnDestroy {
    fileInputRef?: ElementRef<HTMLInputElement>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly url: _angular_core.InputSignal<string | undefined>;
    readonly method: _angular_core.InputSignal<"post" | "put">;
    readonly headers: _angular_core.InputSignal<HttpHeaders | undefined>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly auto: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly withCredentials: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maxFiles: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly fileLimit: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly maxFileSize: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly invalidFileSizeMessageSummary: _angular_core.InputSignal<string | undefined>;
    readonly invalidFileSizeMessageDetail: _angular_core.InputSignal<string | undefined>;
    readonly invalidFileTypeMessageSummary: _angular_core.InputSignal<string | undefined>;
    readonly invalidFileTypeMessageDetail: _angular_core.InputSignal<string | undefined>;
    readonly invalidFileLimitMessageSummary: _angular_core.InputSignal<string | undefined>;
    readonly invalidFileLimitMessageDetail: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly subLabel: _angular_core.InputSignal<string | undefined>;
    readonly dropzoneAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly chooseLabel: _angular_core.InputSignal<string | undefined>;
    readonly uploadLabel: _angular_core.InputSignal<string | undefined>;
    readonly cancelLabel: _angular_core.InputSignal<string | undefined>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly uploadingLabel: _angular_core.InputSignal<string | undefined>;
    readonly uploadedLabel: _angular_core.InputSignal<string | undefined>;
    readonly errorLabel: _angular_core.InputSignal<string | undefined>;
    readonly pendingLabel: _angular_core.InputSignal<string | undefined>;
    readonly previewWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<string | Record<string, string | number> | undefined>;
    readonly chooseIcon: _angular_core.InputSignal<string | undefined>;
    readonly uploadIcon: _angular_core.InputSignal<string | undefined>;
    readonly cancelIcon: _angular_core.InputSignal<string | undefined>;
    readonly showUploadButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showCancelButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly mode: _angular_core.InputSignal<"advanced" | "basic">;
    readonly customUpload: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly uploadStyleClass: _angular_core.InputSignal<string>;
    readonly cancelStyleClass: _angular_core.InputSignal<string>;
    readonly chooseStyleClass: _angular_core.InputSignal<string>;
    readonly removeStyleClass: _angular_core.InputSignal<string>;
    readonly forceDragover: _angular_core.InputSignal<boolean>;
    readonly onSelect: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        files: File[];
        currentFiles: File[];
    }>;
    readonly onRemove: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        file: File;
    }>;
    readonly onClear: _angular_core.OutputEmitterRef<Event>;
    readonly onUpload: _angular_core.OutputEmitterRef<{
        originalEvent: unknown;
        files: File[];
    }>;
    readonly onError: _angular_core.OutputEmitterRef<{
        files: File[];
        error?: ErrorEvent;
    }>;
    readonly onProgress: _angular_core.OutputEmitterRef<{
        originalEvent: unknown;
        progress: number;
    }>;
    readonly onBeforeUpload: _angular_core.OutputEmitterRef<{
        formData: FormData;
    }>;
    readonly uploadHandler: _angular_core.OutputEmitterRef<{
        files: File[];
    }>;
    readonly onSend: _angular_core.OutputEmitterRef<{
        originalEvent: unknown;
        formData: FormData;
    }>;
    readonly onImageError: _angular_core.OutputEmitterRef<{
        file: File;
        originalEvent: Event;
    }>;
    readonly onRemoveUploadedFile: _angular_core.OutputEmitterRef<{
        file: File;
        originalEvent: Event;
    }>;
    readonly files: _angular_core.WritableSignal<FileItemData[]>;
    readonly isDragging: _angular_core.WritableSignal<boolean>;
    private readonly cvaDisabled;
    private readonly http;
    private uploadSubscription?;
    private readonly ownedPreviewUrls;
    readonly validationMessage: _angular_core.WritableSignal<string>;
    readonly uploading: _angular_core.WritableSignal<boolean>;
    private onChange;
    private onTouched;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly effectiveFileLimit: _angular_core.Signal<number>;
    readonly hasReachedMaxFiles: _angular_core.Signal<boolean>;
    readonly canUpload: _angular_core.Signal<boolean>;
    writeValue(value: FileItemData[] | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onDragOver(event: DragEvent): void;
    onDragLeave(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    onAreaClick(): void;
    onAreaKeyDown(event: KeyboardEvent): void;
    onFileSelected(event: Event): void;
    onRemoveFile(id: string, originalEvent?: Event): void;
    clear(originalEvent?: Event): void;
    upload(): void;
    private cancelUpload;
    choose(): void;
    uploader(): void;
    private handleFiles;
    private createFileItem;
    private fileKey;
    private emitValidationError;
    private emitLimitError;
    private revokePreview;
    private formatBytes;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FileUploaderComponent, "orc-file-uploader, orc-file-upload", never, { "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "method": { "alias": "method"; "required": false; "isSignal": true; }; "headers": { "alias": "headers"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "auto": { "alias": "auto"; "required": false; "isSignal": true; }; "withCredentials": { "alias": "withCredentials"; "required": false; "isSignal": true; }; "maxFiles": { "alias": "maxFiles"; "required": false; "isSignal": true; }; "fileLimit": { "alias": "fileLimit"; "required": false; "isSignal": true; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; "isSignal": true; }; "invalidFileSizeMessageSummary": { "alias": "invalidFileSizeMessageSummary"; "required": false; "isSignal": true; }; "invalidFileSizeMessageDetail": { "alias": "invalidFileSizeMessageDetail"; "required": false; "isSignal": true; }; "invalidFileTypeMessageSummary": { "alias": "invalidFileTypeMessageSummary"; "required": false; "isSignal": true; }; "invalidFileTypeMessageDetail": { "alias": "invalidFileTypeMessageDetail"; "required": false; "isSignal": true; }; "invalidFileLimitMessageSummary": { "alias": "invalidFileLimitMessageSummary"; "required": false; "isSignal": true; }; "invalidFileLimitMessageDetail": { "alias": "invalidFileLimitMessageDetail"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "subLabel": { "alias": "subLabel"; "required": false; "isSignal": true; }; "dropzoneAriaLabel": { "alias": "dropzoneAriaLabel"; "required": false; "isSignal": true; }; "chooseLabel": { "alias": "chooseLabel"; "required": false; "isSignal": true; }; "uploadLabel": { "alias": "uploadLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; "uploadingLabel": { "alias": "uploadingLabel"; "required": false; "isSignal": true; }; "uploadedLabel": { "alias": "uploadedLabel"; "required": false; "isSignal": true; }; "errorLabel": { "alias": "errorLabel"; "required": false; "isSignal": true; }; "pendingLabel": { "alias": "pendingLabel"; "required": false; "isSignal": true; }; "previewWidth": { "alias": "previewWidth"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "chooseIcon": { "alias": "chooseIcon"; "required": false; "isSignal": true; }; "uploadIcon": { "alias": "uploadIcon"; "required": false; "isSignal": true; }; "cancelIcon": { "alias": "cancelIcon"; "required": false; "isSignal": true; }; "showUploadButton": { "alias": "showUploadButton"; "required": false; "isSignal": true; }; "showCancelButton": { "alias": "showCancelButton"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "customUpload": { "alias": "customUpload"; "required": false; "isSignal": true; }; "uploadStyleClass": { "alias": "uploadStyleClass"; "required": false; "isSignal": true; }; "cancelStyleClass": { "alias": "cancelStyleClass"; "required": false; "isSignal": true; }; "chooseStyleClass": { "alias": "chooseStyleClass"; "required": false; "isSignal": true; }; "removeStyleClass": { "alias": "removeStyleClass"; "required": false; "isSignal": true; }; "forceDragover": { "alias": "forceDragover"; "required": false; "isSignal": true; }; }, { "onSelect": "onSelect"; "onRemove": "onRemove"; "onClear": "onClear"; "onUpload": "onUpload"; "onError": "onError"; "onProgress": "onProgress"; "onBeforeUpload": "onBeforeUpload"; "uploadHandler": "uploadHandler"; "onSend": "onSend"; "onImageError": "onImageError"; "onRemoveUploadedFile": "onRemoveUploadedFile"; }, never, never, true, never>;
}

declare class FileItemComponent {
    readonly fileData: _angular_core.InputSignal<FileItemData>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly uploadingLabel: _angular_core.InputSignal<string | undefined>;
    readonly uploadedLabel: _angular_core.InputSignal<string | undefined>;
    readonly errorLabel: _angular_core.InputSignal<string | undefined>;
    readonly pendingLabel: _angular_core.InputSignal<string | undefined>;
    readonly previewWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly removeStyleClass: _angular_core.InputSignal<string>;
    private readonly failedPreview;
    readonly showPreview: _angular_core.Signal<boolean>;
    readonly effectivePreviewWidth: _angular_core.Signal<number>;
    readonly remove: _angular_core.OutputEmitterRef<string>;
    readonly imageError: _angular_core.OutputEmitterRef<{
        file: File;
        originalEvent: Event;
    }>;
    readonly isImage: _angular_core.Signal<boolean>;
    readonly badgeVariant: _angular_core.Signal<"soft" | "outline">;
    readonly badgeStatus: _angular_core.Signal<"success" | "danger" | "primary" | "neutral">;
    readonly showProgress: _angular_core.Signal<boolean>;
    onRemove(): void;
    onImageError(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FileItemComponent, "orc-file-item", never, { "fileData": { "alias": "fileData"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; "uploadingLabel": { "alias": "uploadingLabel"; "required": false; "isSignal": true; }; "uploadedLabel": { "alias": "uploadedLabel"; "required": false; "isSignal": true; }; "errorLabel": { "alias": "errorLabel"; "required": false; "isSignal": true; }; "pendingLabel": { "alias": "pendingLabel"; "required": false; "isSignal": true; }; "previewWidth": { "alias": "previewWidth"; "required": false; "isSignal": true; }; "removeStyleClass": { "alias": "removeStyleClass"; "required": false; "isSignal": true; }; }, { "remove": "remove"; "imageError": "imageError"; }, never, never, true, never>;
}

export { FileItemComponent, FileUploaderComponent };
export type { FileItemData, FileStatus };
