import * as _angular_core from '@angular/core';
import { InjectionToken, Signal, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as _ciag_orchestra_otp_input from '@ciag/orchestra/otp-input';

interface OtpInputContext {
    readonly length: Signal<number>;
    readonly inputMode: Signal<'numeric' | 'text'>;
    readonly placeholder: Signal<string>;
    readonly ariaLabel: Signal<string | undefined>;
    readonly readonly: Signal<boolean>;
    readonly tabindex: Signal<number | null>;
    readonly mask: Signal<boolean>;
    readonly autofocus: Signal<boolean>;
    readonly isDisabled: Signal<boolean>;
    readonly inputValues: Signal<string[]>;
    onSlotInput(event: Event, index: number): void;
    onSlotKeyDown(event: KeyboardEvent, index: number): void;
    onSlotPaste(event: ClipboardEvent, index: number): void;
    onSlotFocus(index: number): void;
    onSlotFocusEvent(event: Event): void;
    onSlotBlur(event: Event): void;
}
declare const ORC_OTP_INPUT: InjectionToken<OtpInputContext>;

declare class OtpInputComponent implements ControlValueAccessor, OtpInputContext {
    readonly length: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number | null>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly mask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly integerOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<"outlined" | "filled" | undefined>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly inputMode: _angular_core.InputSignal<"numeric" | "text">;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly firstHalfIndices: _angular_core.Signal<number[]>;
    readonly secondHalfIndices: _angular_core.Signal<number[]>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly completed: _angular_core.OutputEmitterRef<string>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly inputValues: _angular_core.WritableSignal<string[]>;
    private readonly cvaDisabled;
    readonly isDisabled: _angular_core.Signal<boolean>;
    private readonly slots;
    private onModelChange;
    private onTouched;
    constructor();
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onSlotInput(event: Event, index: number): void;
    onSlotKeyDown(event: KeyboardEvent, index: number): void;
    onSlotFocus(index: number): void;
    onSlotPaste(event: ClipboardEvent, index: number): void;
    private pasteCode;
    private updateValues;
    focusInput(index: number): void;
    onSlotFocusEvent(event: Event): void;
    onSlotBlur(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OtpInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OtpInputComponent, "orc-otp-input, orc-input-otp", never, { "length": { "alias": "length"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "integerOnly": { "alias": "integerOnly"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "inputMode": { "alias": "inputMode"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "completed": "completed"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}

declare class OtpSlotComponent {
    readonly index: _angular_core.InputSignal<number>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly isFirst: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly isLast: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputElement: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly parentContext: _ciag_orchestra_otp_input.OtpInputContext | null;
    readonly value: _angular_core.Signal<string>;
    readonly inputMode: _angular_core.Signal<"numeric" | "text">;
    readonly effectivePlaceholder: _angular_core.Signal<string>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isReadonly: _angular_core.Signal<boolean>;
    readonly isMasked: _angular_core.Signal<boolean>;
    readonly slotTabIndex: _angular_core.Signal<number>;
    readonly isAutofocus: _angular_core.Signal<boolean | undefined>;
    readonly ariaLabel: _angular_core.Signal<string | undefined>;
    onInput(event: Event): void;
    onKeyDown(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    onFocus(): void;
    onFocusEvent(event: Event): void;
    onBlur(event: Event): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OtpSlotComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OtpSlotComponent, "orc-otp-slot", never, { "index": { "alias": "index"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "isFirst": { "alias": "isFirst"; "required": false; "isSignal": true; }; "isLast": { "alias": "isLast"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class OtpSeparatorComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OtpSeparatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OtpSeparatorComponent, "orc-otp-separator", never, {}, {}, never, never, true, never>;
}

declare class OtpGroupComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OtpGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OtpGroupComponent, "orc-otp-group", never, {}, {}, never, ["*"], true, never>;
}

export { ORC_OTP_INPUT, OtpGroupComponent, OtpInputComponent, OtpSeparatorComponent, OtpSlotComponent };
export type { OtpInputContext };
