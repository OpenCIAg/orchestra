import * as _angular_core from '@angular/core';

declare class BreadcrumbItemComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly routerLink: _angular_core.InputSignal<string | any[] | undefined>;
    readonly href: _angular_core.InputSignal<string | undefined>;
    readonly active: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly itemClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly hasLink: _angular_core.Signal<boolean>;
    handleClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BreadcrumbItemComponent, "orc-breadcrumb-item", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "routerLink": { "alias": "routerLink"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, never, ["*", "*", "*", "*"], true, never>;
}

type BreadcrumbSeparator = 'chevron' | 'slash' | 'arrow';
type BreadcrumbVariant = 'default' | 'underlined';
interface BreadcrumbItemData {
    label: string;
    url?: string;
    routerLink?: string | any[];
    icon?: string;
    disabled?: boolean;
}

interface ProcessedBreadcrumbItem extends Partial<BreadcrumbItemData> {
    label: string;
    isEllipsis: boolean;
    isLast: boolean;
    originalIndex: number;
}
declare class BreadcrumbComponent {
    readonly items: _angular_core.InputSignal<BreadcrumbItemData[] | undefined>;
    readonly model: _angular_core.InputSignal<BreadcrumbItemData[] | undefined>;
    readonly home: _angular_core.InputSignal<BreadcrumbItemData | undefined>;
    readonly homeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly separator: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<BreadcrumbVariant>;
    readonly maxItems: _angular_core.InputSignal<number | undefined>;
    readonly itemsBeforeCollapse: _angular_core.InputSignal<number>;
    readonly itemsAfterCollapse: _angular_core.InputSignal<number>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly itemClick: _angular_core.OutputEmitterRef<{
        item: BreadcrumbItemData;
        index: number;
    }>;
    readonly onItemClick: _angular_core.OutputEmitterRef<{
        item: BreadcrumbItemData;
        index: number;
    }>;
    readonly breadcrumbItems: _angular_core.Signal<readonly BreadcrumbItemComponent[]>;
    readonly effectiveItems: _angular_core.Signal<BreadcrumbItemData[] | undefined>;
    readonly isExpanded: _angular_core.WritableSignal<boolean>;
    readonly processedItems: _angular_core.Signal<ProcessedBreadcrumbItem[]>;
    expand(): void;
    onItemClicked(item: ProcessedBreadcrumbItem, index: number, event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BreadcrumbComponent, "orc-breadcrumb", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "home": { "alias": "home"; "required": false; "isSignal": true; }; "homeAriaLabel": { "alias": "homeAriaLabel"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "maxItems": { "alias": "maxItems"; "required": false; "isSignal": true; }; "itemsBeforeCollapse": { "alias": "itemsBeforeCollapse"; "required": false; "isSignal": true; }; "itemsAfterCollapse": { "alias": "itemsAfterCollapse"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; "onItemClick": "onItemClick"; }, ["breadcrumbItems"], ["*"], true, never>;
}

export { BreadcrumbComponent, BreadcrumbItemComponent };
export type { BreadcrumbItemData, BreadcrumbSeparator, BreadcrumbVariant, ProcessedBreadcrumbItem };
