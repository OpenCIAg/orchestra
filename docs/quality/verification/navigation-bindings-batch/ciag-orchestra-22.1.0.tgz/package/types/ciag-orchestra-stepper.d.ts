import * as _angular_core from '@angular/core';

type StepperOrientation = 'horizontal' | 'vertical';
type StepperType = 'numeric' | 'icon';
type StepStatus = 'pending' | 'active' | 'completed' | 'loading' | 'error';
interface StepItem {
    id?: string | number;
    title: string;
    subtitle?: string;
    description?: string;
    icon?: string;
    status?: StepStatus;
    progress?: number;
    disabled?: boolean;
}

declare class StepperComponent {
    private readonly host;
    /** Lista de etapas a serem exibidas */
    readonly steps: _angular_core.InputSignal<StepItem[]>;
    /** Índice da etapa ativa atual (0-indexed) */
    readonly currentStep: _angular_core.ModelSignal<number>;
    readonly activeIndex: _angular_core.ModelSignal<number>;
    readonly model: _angular_core.InputSignal<StepItem[] | undefined>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly exact: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly styleClass: _angular_core.InputSignal<string>;
    /** Orientação do layout: 'horizontal' ou 'vertical' */
    readonly orientation: _angular_core.InputSignal<StepperOrientation>;
    /** Estilo dos marcadores de etapa: 'numeric' (1, 2, 3...) ou 'icon' */
    readonly type: _angular_core.InputSignal<StepperType>;
    /** Permite que o usuário clique nos passos para navegar */
    readonly clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Automatically activate a step when it receives keyboard focus. */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Accessible label for the stepper navigation. */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** Modo linear: impede pular etapas à frente */
    readonly linear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Evento emitido quando o usuário clica em uma etapa */
    readonly stepChange: _angular_core.OutputEmitterRef<{
        step: StepItem;
        index: number;
    }>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        index: number;
        step: StepItem;
    }>;
    readonly completed: _angular_core.OutputEmitterRef<void>;
    readonly effectiveSteps: _angular_core.Signal<StepItem[]>;
    private boundStep;
    private firstReachable;
    constructor();
    private initialized;
    private lastCurrentStep;
    private lastActiveIndex;
    readonly focusedIndex: _angular_core.WritableSignal<number | undefined>;
    getStepStatus(index: number, step: StepItem): StepStatus;
    isStepClickable(index: number, step: StepItem): boolean;
    private reachableIndices;
    selectStep(index: number, step: StepItem): void;
    onFocus(index: number): void;
    onKeydown(event: KeyboardEvent, index: number): void;
    next(): void;
    previous(): void;
    reset(): void;
    isConnectorCompleted(index: number): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StepperComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StepperComponent, "orc-stepper, orc-steps", never, { "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "currentStep": { "alias": "currentStep"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "exact": { "alias": "exact"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "linear": { "alias": "linear"; "required": false; "isSignal": true; }; }, { "currentStep": "currentStepChange"; "activeIndex": "activeIndexChange"; "stepChange": "stepChange"; "onChange": "onChange"; "completed": "completed"; }, never, never, true, never>;
}

export { StepperComponent };
export type { StepItem, StepStatus, StepperOrientation, StepperType };
