declare function registerOverlay(element: HTMLElement, options?: {
    interactive?: boolean;
    anchor?: HTMLElement;
    onParentClose?: () => void;
}): () => void;
declare function isTopOverlay(element: HTMLElement): boolean;
declare function isolateModalBackground(element: HTMLElement, additionalRoots?: readonly HTMLElement[]): () => void;
/** Each caller receives an idempotent release function that preserves consumer inline styles. */
declare function lockDocumentScroll(document: Document): () => void;
declare function eventIsInside(event: Event, roots: readonly (HTMLElement | null | undefined)[]): boolean;
/** Capture phase also observes interactions inside consumers that stop bubbling events. */
declare function listenForOutsideInteraction(document: Document, roots: () => readonly (HTMLElement | null | undefined)[], onOutside: (event: MouseEvent) => void): () => void;
declare function focusableElements(container: HTMLElement): HTMLElement[];
declare function focusInitialElement(container: HTMLElement): void;
declare function trapTabKey(event: KeyboardEvent, container: HTMLElement): void;

declare function overlayContains(root: Element, child: Element): boolean;
/** Locate the native modal that owns an anchor, including anchors in shadow DOM. */
declare function nativeModalFor(anchor: HTMLElement): HTMLDialogElement | null;
/** A popup must remain a descendant of its native modal to escape native inertness. */
declare function overlayAttachmentTarget(anchor: HTMLElement, requested: unknown, fallback?: HTMLElement): HTMLElement;

type OverlayPanelPlacement = 'top' | 'right' | 'bottom' | 'left';
type OverlayPanelAlign = 'start' | 'center' | 'end';
interface Rectangle {
    top: number;
    right: number;
    bottom: number;
    left: number;
    width: number;
    height: number;
}
interface Size {
    width: number;
    height: number;
}
/** Resolve viewport geometry independently from DOM attachment and lifecycle. */
declare function positionOverlayPanel(origin: Rectangle, panel: Size, viewport: Size, requested: OverlayPanelPlacement, align: OverlayPanelAlign, rtl?: boolean, gap?: number): {
    left: number;
    top: number;
    placement: OverlayPanelPlacement;
};

/**
 * Attach an already-rendered popup without losing its Angular view ownership.
 * Native popovers escape clipping while retaining inherited styles and dialog
 * ancestry. The fallback portals to the document (or owning native dialog).
 * Consumers constrain their content with the available-width/height variables.
 */
declare function attachAnchoredPopup(anchor: HTMLElement, panel: HTMLElement, appendTo?: unknown): () => void;

export { attachAnchoredPopup, eventIsInside, focusInitialElement, focusableElements, isTopOverlay, isolateModalBackground, listenForOutsideInteraction, lockDocumentScroll, nativeModalFor, overlayAttachmentTarget, overlayContains, positionOverlayPanel, registerOverlay, trapTabKey };
export type { OverlayPanelAlign, OverlayPanelPlacement };
