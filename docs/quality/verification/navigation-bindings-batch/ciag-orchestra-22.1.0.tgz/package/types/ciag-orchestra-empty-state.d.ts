import * as _angular_core from '@angular/core';

declare class EmptyStateComponent {
    readonly title: _angular_core.InputSignal<string | undefined>;
    readonly description: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly actionLabel: _angular_core.InputSignalWithTransform<string, string | undefined>;
    readonly action: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmptyStateComponent, "orc-empty-state", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "action": "action"; }, never, ["*"], true, never>;
}

export { EmptyStateComponent };
