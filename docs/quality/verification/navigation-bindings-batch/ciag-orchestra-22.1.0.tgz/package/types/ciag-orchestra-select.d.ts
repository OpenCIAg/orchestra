import * as _angular_core from '@angular/core';
import { ElementRef, AfterViewInit, OnDestroy, TemplateRef, InjectionToken } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

interface SelectOption<T = any> {
    label: string;
    value: T;
    description?: string;
    icon?: string;
    avatarUrl?: string;
    group?: string;
    disabled?: boolean;
}

type SelectSize = 'sm' | 'md' | 'lg';
type SelectStatus = 'default' | 'error' | 'success';
interface SelectOptionItem<T = any> {
    label: string;
    value: T;
    description?: string;
    icon?: string;
    avatarUrl?: string;
    group?: string;
    disabled?: boolean;
}

declare class OptionComponent {
    private select;
    protected readonly elementRef: ElementRef<any>;
    readonly defaultId: string;
    readonly id: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly avatarUrl: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly isSelected: _angular_core.WritableSignal<boolean>;
    readonly isActive: _angular_core.WritableSignal<boolean>;
    readonly isHidden: _angular_core.WritableSignal<boolean>;
    readonly displayText: _angular_core.Signal<any>;
    onClick(event: MouseEvent): void;
    onMouseEnter(): void;
    getOptionText(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OptionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OptionComponent, "orc-option", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SelectComponent implements ControlValueAccessor, AfterViewInit, OnDestroy {
    private readonly uniqueId;
    private hostEl;
    private viewContainerRef;
    private overlay;
    private readonly document;
    private overlayRef;
    private portal;
    private layerCleanup?;
    private outsideCleanup?;
    private focusTimer?;
    readonly triggerEl: _angular_core.Signal<ElementRef<HTMLDivElement> | undefined>;
    readonly searchInputRef: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly dropdownPanel: _angular_core.Signal<TemplateRef<unknown>>;
    readonly projectedOptions: _angular_core.Signal<readonly OptionComponent[]>;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly status: _angular_core.InputSignal<SelectStatus>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly searchable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly searchPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly searchEmptyText: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly clearable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly options: _angular_core.InputSignal<SelectOption<any>[] | undefined>;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterFields: _angular_core.InputSignal<string[] | undefined>;
    readonly filterMatchMode: _angular_core.InputSignal<"contains" | "startsWith" | "endsWith" | "equals" | "notEquals" | "in" | "lt" | "lte" | "gt" | "gte">;
    readonly emptyFilterMessage: _angular_core.InputSignal<string | undefined>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly panelStyle: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly panelStyleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly overlayOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocusFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly editable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checkmark: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dropdownIcon: _angular_core.InputSignal<string>;
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionGroupChildren: _angular_core.InputSignal<string>;
    readonly autoDisplayFirst: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly group: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly itemSize: _angular_core.InputSignal<number | undefined>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maxlength: _angular_core.InputSignal<number | undefined>;
    readonly showTransitionOptions: _angular_core.InputSignal<string | undefined>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string | undefined>;
    readonly resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tooltip: _angular_core.InputSignal<string>;
    readonly tooltipPosition: _angular_core.InputSignal<"top" | "left" | "right" | "bottom">;
    readonly tooltipPositionStyle: _angular_core.InputSignal<string>;
    readonly tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    readonly scrollHeight: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly removeOptionAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<any>;
    readonly selectionChange: _angular_core.OutputEmitterRef<any>;
    readonly searchChange: _angular_core.OutputEmitterRef<string>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly blur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly focus: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: any;
    }>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        filter: string;
    }>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onClear: _angular_core.OutputEmitterRef<Event>;
    readonly onOptionSelect: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: any;
    }>;
    readonly onOptionUnselect: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: any;
    }>;
    readonly onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        last: number;
    }>;
    readonly isOpen: _angular_core.WritableSignal<boolean>;
    readonly isFocused: _angular_core.WritableSignal<boolean>;
    readonly searchTerm: _angular_core.WritableSignal<string>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    readonly activeOptionIndex: _angular_core.WritableSignal<number>;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly filterEnabled: _angular_core.Signal<boolean>;
    readonly listboxId: _angular_core.Signal<string>;
    readonly activeOptionId: _angular_core.Signal<string | null>;
    readonly labelId: _angular_core.Signal<string>;
    readonly helperId: _angular_core.Signal<string>;
    readonly errorId: _angular_core.Signal<string>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly isInvalid: _angular_core.Signal<boolean>;
    readonly computedAriaDescribedBy: _angular_core.Signal<string | null>;
    /** Close an open panel when a parent changes the control into a state that
     * cannot interact with the list anymore. */
    private readonly closeWhenUnavailable;
    readonly dataOptions: _angular_core.Signal<SelectOption<any>[]>;
    readonly isDataMode: _angular_core.Signal<boolean>;
    readonly filteredDataOptions: _angular_core.Signal<SelectOption<any>[]>;
    private matchesFilter;
    private compareNumericFilter;
    getOptionValue(option: any): any;
    sameOptionValue(left: any, right: any): boolean;
    isDataOptionSelected(option: SelectOption): boolean;
    getOptionLabel(option: any): string;
    isOptionDisabled(option: any): boolean;
    readonly selectedItems: _angular_core.Signal<{
        label: string;
        value: any;
        icon?: string;
        avatarUrl?: string;
    }[]>;
    readonly hasValue: _angular_core.Signal<boolean>;
    private onModelChange;
    private onTouched;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    togglePanel(): void;
    openPanel(): void;
    closePanel(restoreFocus?: boolean): void;
    private createPositionStrategy;
    onOptionSelected(optionComponent: OptionComponent, event?: Event): void;
    onDataOptionClick(option: SelectOption, event?: Event): void;
    private selectValue;
    removeSelectedItem(itemValue: any, event: MouseEvent): void;
    clearValue(event: MouseEvent): void;
    setActiveOption(optionComponent: OptionComponent): void;
    private getVisibleOptions;
    private updateActiveHighlight;
    onSearchInput(event: Event): void;
    onKeyDown(event: KeyboardEvent): void;
    private navigateOption;
    dataOptionIndex(option: SelectOption): number;
    private confirmActiveOption;
    onTriggerFocus(event: FocusEvent): void;
    onTriggerBlur(event: FocusEvent): void;
    onDocumentClick(target: EventTarget | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectComponent, "orc-select", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "searchEmptyText": { "alias": "searchEmptyText"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "autofocusFilter": { "alias": "autofocusFilter"; "required": false; "isSignal": true; }; "editable": { "alias": "editable"; "required": false; "isSignal": true; }; "checkmark": { "alias": "checkmark"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "autoDisplayFirst": { "alias": "autoDisplayFirst"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "itemSize": { "alias": "itemSize"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipPositionStyle": { "alias": "tooltipPositionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "removeOptionAriaLabel": { "alias": "removeOptionAriaLabel"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "ariaDescribedby"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "selectionChange": "selectionChange"; "searchChange": "searchChange"; "opened": "opened"; "closed": "closed"; "blur": "blur"; "focus": "focus"; "onChange": "onChange"; "onFilter": "onFilter"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; "onOptionSelect": "onOptionSelect"; "onOptionUnselect": "onOptionUnselect"; "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onLazyLoad": "onLazyLoad"; }, ["projectedOptions"], ["[orcSelectTrigger], [selectTrigger]", "[orcSelectHeader]", "*", "[orcSelectFooter]"], true, never>;
}

/** Narrow parent contract used by projected options. */
interface SelectHost {
    onOptionSelected(option: {
        value(): any;
    }, event?: Event): void;
    setActiveOption(option: {
        value(): any;
    }): void;
}
declare const SELECT_HOST: InjectionToken<SelectHost>;

export { OptionComponent, SELECT_HOST, SelectComponent };
export type { SelectHost, SelectOption, SelectOptionItem, SelectSize, SelectStatus };
