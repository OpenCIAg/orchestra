import * as _angular_core from '@angular/core';

type AlertSeverity = 'info' | 'success' | 'warning' | 'warn' | 'error' | 'secondary' | 'contrast';
type AlertStatus = AlertSeverity;
type AlertVariant = 'subtle' | 'soft' | 'filled' | 'solid' | 'outline';

declare class AlertComponent {
    /** Status / Severidade do alerta */
    readonly severity: _angular_core.InputSignal<AlertSeverity>;
    /** Alias para severity */
    readonly status: _angular_core.InputSignal<AlertSeverity | undefined>;
    /** Variante visual: soft/subtle (fundo claro), filled (sólido) ou outline (apenas borda) */
    readonly variant: _angular_core.InputSignal<AlertVariant>;
    /** Título principal do alerta (opcional) */
    readonly title: _angular_core.InputSignal<string>;
    /** Texto descritivo (opcional se fornecido via ng-content) */
    readonly message: _angular_core.InputSignal<string>;
    readonly text: _angular_core.InputSignal<string | undefined>;
    /** Controla se o ícone do alerta deve ser exibido */
    readonly showIcon: _angular_core.InputSignal<boolean>;
    /** Define se o alerta pode ser dispensado pelo usuário exibindo o botão 'X' */
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly life: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    /** Sobrescreve o atributo role WCAG (padrão: 'alert' para error/warning e 'status' para info/success) */
    readonly role: _angular_core.InputSignal<string | undefined>;
    /** Rótulo acessível opcional para leitores de tela */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Rótulo acessível do botão de fechar */
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    /** Emitido quando o usuário clica no botão de fechar */
    readonly onClose: _angular_core.OutputEmitterRef<MouseEvent>;
    /** Alias do evento de fechamento */
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly isVisible: _angular_core.WritableSignal<boolean>;
    /** Normaliza o tipo de severidade ativo */
    readonly activeSeverity: _angular_core.Signal<AlertSeverity>;
    readonly activeMessage: _angular_core.Signal<string>;
    readonly isClosable: _angular_core.Signal<boolean>;
    /** Normaliza a variante */
    readonly activeVariant: _angular_core.Signal<"subtle" | "filled" | "outline">;
    /** Computa o atributo role WCAG ideal conforme o tipo de severidade */
    readonly computedRole: _angular_core.Signal<string>;
    /** Computa aria-live: 'assertive' para erros críticos e 'polite' para informativos */
    readonly computedAriaLive: _angular_core.Signal<"assertive" | "polite">;
    handleDismiss(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AlertComponent, "orc-alert, orc-message", never, { "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; }, { "onClose": "onClose"; "closed": "closed"; }, never, ["[alert-icon], [alertIcon]", "[alert-title], [alertTitle]", "*", "[alert-actions], [alertActions]"], true, never>;
}

export { AlertComponent };
export type { AlertSeverity, AlertStatus, AlertVariant };
