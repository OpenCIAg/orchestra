export { MultiSelectComponent, P2Option as MultiSelectOption } from '@ciag/orchestra/p2';
