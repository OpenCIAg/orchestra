import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, AfterViewInit, TemplateRef, ElementRef, Renderer2 } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
export { EmptyStateComponent } from '@ciag/orchestra/empty-state';
export { OverlayPanelComponent } from '@ciag/orchestra/overlay-panel';
export { PopoverComponent } from '@ciag/orchestra/popover';
export { SegmentedControlComponent } from '@ciag/orchestra/segmented-control';
export { TagComponent, TagVariant } from '@ciag/orchestra/tag';

interface P2Option<T = string> {
    value: T;
    label: string;
    description?: string;
    disabled?: boolean;
    icon?: string;
}
type P2Size = 'sm' | 'md' | 'lg';
type P2Orientation = 'horizontal' | 'vertical';
declare const P2_SHARED_STYLES = "\n:host {\n  display: block;\n  box-sizing: border-box;\n  font-family: var(--font-sans, Inter, system-ui, sans-serif);\n  --orc-component-surface: var(--orc-surface, var(--bg-app, #fff));\n  --orc-component-surface-raised: var(--orc-surface-raised, var(--orc-component-surface));\n  --orc-component-surface-subtle: var(--orc-surface-subtle, var(--bg-subtle, #f8fafc));\n  --orc-component-surface-muted: var(--orc-surface-muted, var(--bg-muted, #f1f5f9));\n  --orc-component-control: var(--orc-control-surface, var(--orc-component-surface));\n  --orc-component-text: var(--orc-text, var(--text-primary, #0f172a));\n  --orc-component-text-secondary: var(--orc-text-secondary, var(--text-secondary, #475569));\n  --orc-component-text-muted: var(--orc-text-muted, var(--text-muted, #64748b));\n  --orc-component-border: var(--orc-border-default, var(--border-default, #e2e8f0));\n  --orc-component-border-strong: var(--orc-border-strong, var(--border-strong, #cbd5e1));\n  --orc-component-interactive: var(--orc-interactive, #2563eb);\n  --orc-component-interactive-hover: var(--orc-interactive-hover, #1d4ed8);\n  --orc-component-interactive-soft: var(--orc-interactive-soft, #eff6ff);\n  --orc-component-on-interactive: var(--orc-on-interactive, #fff);\n  --orc-component-on-dark: var(--orc-on-dark, #fff);\n  --orc-terminal-surface: var(--orc-terminal-bg, #0f172a);\n  --orc-component-shadow-color: var(--orc-shadow-color, rgb(15 23 42 / 0.14));\n  --orc-component-interactive-shadow: var(--orc-interactive-shadow, rgb(37 99 235 / 0.25));\n  --orc-component-surface-overlay: var(--orc-surface-overlay, var(--orc-surface-raised));\n  --orc-component-code-surface: var(--orc-code-surface, #0f172a);\n  --orc-component-code-surface-raised: var(--orc-code-surface-raised, #1e293b);\n  --orc-component-code-border: var(--orc-code-border, #334155);\n  --orc-component-code-text: var(--orc-code-text, #e2e8f0);\n  --orc-component-code-muted: var(--orc-code-muted, #94a3b8);\n  --orc-component-code-accent: var(--orc-code-accent, #4ade80);\n  --orc-component-status-info-bg: var(--orc-status-info-bg, #eff6ff);\n  --orc-component-status-info-fg: var(--orc-status-info-fg, #1e3a8a);\n  --orc-component-status-success-bg: var(--orc-status-success-bg, #dcfce7);\n  --orc-component-status-success-fg: var(--orc-status-success-fg, #166534);\n  --orc-component-status-warning-bg: var(--orc-status-warning-bg, #fef3c7);\n  --orc-component-status-warning-fg: var(--orc-status-warning-fg, #92400e);\n  --orc-component-status-danger-bg: var(--orc-status-danger-bg, #fee2e2);\n  --orc-component-status-danger-fg: var(--orc-status-danger-fg, #991b1b);\n  --orc-component-status-info-border: var(--orc-status-info-border, var(--orc-component-interactive));\n  --orc-component-status-success-border: var(--orc-status-success-border, #86efac);\n  --orc-component-status-warning-border: var(--orc-status-warning-border, #fcd34d);\n  --orc-component-status-danger-border: var(--orc-status-danger-border, #fca5a5);\n  --orc-component-danger: var(--orc-danger, #b91c1c);\n  --orc-component-scrim: var(--orc-scrim, rgb(15 23 42 / 0.56));\n  --orc-component-overlay-shadow: var(--orc-shadow-overlay, var(--shadow-lg));\n}\n*, *::before, *::after { box-sizing: border-box; }\nbutton, input { font: inherit; }\nbutton { cursor: pointer; }\nbutton:disabled { cursor: not-allowed; opacity: .55; }\n.orc-p2-muted { color: var(--orc-component-text-muted); }\n.orc-p2-focus:focus-visible, button:focus-visible, input:focus-visible, [tabindex]:focus-visible { outline: 2px solid var(--orc-component-interactive); outline-offset: 2px; }\n";

interface CalendarDay {
    iso: string;
    day: number;
    inCurrentMonth: boolean;
    today: boolean;
    disabled: boolean;
}
declare class CalendarComponent {
    private readonly uniqueId;
    readonly value: _angular_core.ModelSignal<string | string[]>;
    readonly currentMonth: _angular_core.ModelSignal<string>;
    readonly min: _angular_core.InputSignal<string>;
    readonly max: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly cvaDisabled;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly locale: _angular_core.InputSignal<string | undefined>;
    readonly previousMonthLabel: _angular_core.InputSignal<string | undefined>;
    readonly nextMonthLabel: _angular_core.InputSignal<string | undefined>;
    readonly todayLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearLabel: _angular_core.InputSignal<string | undefined>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showTime: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dateFormat: _angular_core.InputSignal<string>;
    readonly showButtonBar: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "range">;
    readonly disabledDates: _angular_core.InputSignal<Date[]>;
    readonly disabledDays: _angular_core.InputSignal<number[]>;
    readonly showOtherMonths: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectOtherMonths: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dateSelected: _angular_core.OutputEmitterRef<string>;
    readonly onSelect: _angular_core.OutputEmitterRef<{
        value: string | string[];
    }>;
    readonly onClear: _angular_core.OutputEmitterRef<void>;
    readonly onTodayClick: _angular_core.OutputEmitterRef<string>;
    private readonly effectiveLocale;
    readonly weekdays: _angular_core.Signal<string[]>;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly monthLabel: _angular_core.Signal<string>;
    isSelected(iso: string): boolean;
    readonly days: _angular_core.Signal<CalendarDay[]>;
    previousMonth(): void;
    nextMonth(): void;
    selectDay(day: CalendarDay): void;
    clear(): void;
    today(): void;
    private onModelChange;
    private onModelTouched;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: string | string[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    private shiftMonth;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CalendarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CalendarComponent, "orc-calendar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "currentMonth": { "alias": "currentMonth"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "previousMonthLabel": { "alias": "previousMonthLabel"; "required": false; "isSignal": true; }; "nextMonthLabel": { "alias": "nextMonthLabel"; "required": false; "isSignal": true; }; "todayLabel": { "alias": "todayLabel"; "required": false; "isSignal": true; }; "clearLabel": { "alias": "clearLabel"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "showTime": { "alias": "showTime"; "required": false; "isSignal": true; }; "dateFormat": { "alias": "dateFormat"; "required": false; "isSignal": true; }; "showButtonBar": { "alias": "showButtonBar"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "disabledDates": { "alias": "disabledDates"; "required": false; "isSignal": true; }; "disabledDays": { "alias": "disabledDays"; "required": false; "isSignal": true; }; "showOtherMonths": { "alias": "showOtherMonths"; "required": false; "isSignal": true; }; "selectOtherMonths": { "alias": "selectOtherMonths"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "currentMonth": "currentMonthChange"; "dateSelected": "dateSelected"; "onSelect": "onSelect"; "onClear": "onClear"; "onTodayClick": "onTodayClick"; }, never, never, true, never>;
}
declare class ComboboxComponent<T = unknown> implements ControlValueAccessor {
    private static nextId;
    readonly inputId: string;
    readonly listId: string;
    readonly options: _angular_core.InputSignal<P2Option<T>[]>;
    readonly value: _angular_core.ModelSignal<T | null>;
    readonly query: _angular_core.ModelSignal<string>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly optionSelected: _angular_core.OutputEmitterRef<P2Option<T>>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly filteredOptions: _angular_core.Signal<P2Option<T>[]>;
    optionId(index: number): string;
    writeValue(value: T | null): void;
    registerOnChange(fn: (value: T | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    onInput(event: Event): void;
    select(option: P2Option<T>): void;
    clear(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ComboboxComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ComboboxComponent<any>, "orc-combobox", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "query": { "alias": "query"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "query": "queryChange"; "open": "openChange"; "optionSelected": "optionSelected"; }, never, never, true, never>;
}
declare class DateInputComponent implements ControlValueAccessor {
    private readonly uniqueId;
    readonly value: _angular_core.ModelSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly min: _angular_core.InputSignal<string>;
    readonly max: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onChange;
    private onTouchedCallback;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly effectiveId: _angular_core.Signal<string>;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    onInput(event: Event): void;
    onTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateInputComponent, "orc-date-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
declare class InputGroupComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputGroupComponent, "orc-input-group", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class ListboxComponent<T = unknown> implements ControlValueAccessor {
    readonly options: _angular_core.InputSignal<any[]>;
    readonly value: _angular_core.ModelSignal<T | T[] | null>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly emptyFilterMessage: _angular_core.InputSignal<string | undefined>;
    readonly searchMessage: _angular_core.InputSignal<string | undefined>;
    readonly selectionMessage: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly listStyle: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly listStyleClass: _angular_core.InputSignal<string>;
    readonly striped: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checkbox: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checkmark: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showToggleAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly group: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly scrollHeight: _angular_core.InputSignal<string>;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionDisabled: _angular_core.InputSignal<string | ((option: any) => boolean) | undefined>;
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionGroupChildren: _angular_core.InputSignal<string | undefined>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterFields: _angular_core.InputSignal<string[] | undefined>;
    readonly filterMatchMode: _angular_core.InputSignal<string>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly optionSelected: _angular_core.OutputEmitterRef<any>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: T | T[] | null;
    }>;
    readonly onClick: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        option: any;
    }>;
    readonly onDblClick: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        option: any;
    }>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        filter: string;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onSelectAllChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        checked: boolean;
    }>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        last: number;
    }>;
    readonly onDrop: _angular_core.OutputEmitterRef<unknown>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    protected onModelTouched: () => void;
    readonly filteredOptions: _angular_core.Signal<any[]>;
    readonly activeOptionId: _angular_core.Signal<string | null>;
    writeValue(value: T | T[] | null): void;
    registerOnChange(fn: (value: T | T[] | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    getOptionValue(option: any): any;
    optionId(index: number): string;
    getOptionLabel(option: any): string;
    isOptionDisabled(option: any): boolean;
    isSelected(option: any): boolean;
    private sameValue;
    select(option: any, event?: Event): void;
    onKeydown(event: KeyboardEvent): void;
    onFilterInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListboxComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ListboxComponent<any>, "orc-listbox", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "searchMessage": { "alias": "searchMessage"; "required": false; "isSignal": true; }; "selectionMessage": { "alias": "selectionMessage"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "listStyle": { "alias": "listStyle"; "required": false; "isSignal": true; }; "listStyleClass": { "alias": "listStyleClass"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "checkbox": { "alias": "checkbox"; "required": false; "isSignal": true; }; "checkmark": { "alias": "checkmark"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; "showToggleAll": { "alias": "showToggleAll"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "filterValue": "filterValueChange"; "optionSelected": "optionSelected"; "onChange": "onChange"; "onClick": "onClick"; "onDblClick": "onDblClick"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onSelectAllChange": "onSelectAllChange"; "onLazyLoad": "onLazyLoad"; "onDrop": "onDrop"; }, never, never, true, never>;
}
declare class MultiSelectComponent<T = unknown> implements ControlValueAccessor {
    private readonly uniqueId;
    readonly options: _angular_core.InputSignal<P2Option<T>[]>;
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly panelStyle: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly panelStyleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly overlayOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionGroupChildren: _angular_core.InputSignal<string>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly group: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterFields: _angular_core.InputSignal<string[] | undefined>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterMatchMode: _angular_core.InputSignal<"in" | "equals" | "contains" | "startsWith" | "endsWith" | "notEquals" | "lt" | "lte" | "gt" | "gte">;
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly selectAllLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAllLabel: _angular_core.InputSignal<string | undefined>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showToggleAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maxSelectedLabels: _angular_core.InputSignal<number | undefined>;
    readonly selectedItemsLabel: _angular_core.InputSignal<string | undefined>;
    readonly selectionLimit: _angular_core.InputSignal<number | undefined>;
    readonly emptyFilterMessage: _angular_core.InputSignal<string | undefined>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocusFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dropdownIcon: _angular_core.InputSignal<string>;
    readonly chipIcon: _angular_core.InputSignal<string | undefined>;
    readonly display: _angular_core.InputSignal<"comma" | "chip">;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly tooltip: _angular_core.InputSignal<string>;
    readonly tooltipPosition: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly tooltipPositionStyle: _angular_core.InputSignal<string>;
    readonly tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly optionSelected: _angular_core.OutputEmitterRef<P2Option<T>>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: T[];
    }>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        filter: string;
    }>;
    readonly onSelectAllChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        checked: boolean;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onClear: _angular_core.OutputEmitterRef<Event>;
    readonly onPanelShow: _angular_core.OutputEmitterRef<void>;
    readonly onPanelHide: _angular_core.OutputEmitterRef<void>;
    readonly onRemove: _angular_core.OutputEmitterRef<{
        value: T;
        originalEvent: Event;
    }>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly activeOptionId: _angular_core.Signal<string | null>;
    readonly filteredOptions: _angular_core.Signal<P2Option<T>[]>;
    writeValue(value: T[] | null): void;
    registerOnChange(fn: (value: T[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    getOptionValue(option: any): any;
    getOptionLabel(option: any): string;
    isOptionDisabled(option: any): boolean;
    private sameValue;
    isSelected(option: P2Option<T>): boolean;
    selectedLabels(): string;
    toggleOpen(): void;
    onKeydown(event: KeyboardEvent): void;
    select(option: P2Option<T>, event?: Event): void;
    clear(event?: Event): void;
    selectAll(event?: Event): void;
    allOptionsSelected(): boolean;
    onFilterInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiSelectComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultiSelectComponent<any>, "orc-multi-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; "clearAllLabel": { "alias": "clearAllLabel"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "showToggleAll": { "alias": "showToggleAll"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "maxSelectedLabels": { "alias": "maxSelectedLabels"; "required": false; "isSignal": true; }; "selectedItemsLabel": { "alias": "selectedItemsLabel"; "required": false; "isSignal": true; }; "selectionLimit": { "alias": "selectionLimit"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "autofocusFilter": { "alias": "autofocusFilter"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "chipIcon": { "alias": "chipIcon"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipPositionStyle": { "alias": "tooltipPositionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "filterValue": "filterValueChange"; "open": "openChange"; "optionSelected": "optionSelected"; "onChange": "onChange"; "onFilter": "onFilter"; "onSelectAllChange": "onSelectAllChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onClear": "onClear"; "onPanelShow": "onPanelShow"; "onPanelHide": "onPanelHide"; "onRemove": "onRemove"; }, never, never, true, never>;
}
declare class TagsInputComponent implements ControlValueAccessor {
    private readonly uniqueId;
    readonly value: _angular_core.ModelSignal<string[]>;
    readonly draft: _angular_core.WritableSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly suggestions: _angular_core.InputSignal<string[]>;
    readonly maxTags: _angular_core.InputSignal<number | undefined>;
    readonly max: _angular_core.InputSignal<number | undefined>;
    readonly maxLength: _angular_core.InputSignal<number | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly allowDuplicate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly caseSensitiveDuplication: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly addOnTab: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly addOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly separator: _angular_core.InputSignal<string | RegExp | undefined>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly tagAdded: _angular_core.OutputEmitterRef<string>;
    readonly tagRemoved: _angular_core.OutputEmitterRef<string>;
    readonly onAdd: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    readonly onRemove: _angular_core.OutputEmitterRef<{
        value: string;
        index: number;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onChipClick: _angular_core.OutputEmitterRef<{
        value: string;
        index: number;
        originalEvent: Event;
    }>;
    readonly onClear: _angular_core.OutputEmitterRef<Event>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    readonly effectiveId: _angular_core.Signal<string>;
    private onChange;
    private onTouchedCallback;
    readonly filteredSuggestions: _angular_core.Signal<string[]>;
    writeValue(value: string[] | null): void;
    registerOnChange(fn: (value: string[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    onKeydown(event: KeyboardEvent): void;
    onBlurCommit(): void;
    addTag(tag: string): void;
    removeTag(index: number): void;
    clear(event: Event): void;
    onTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TagsInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TagsInputComponent, "orc-tags-input, orc-chips, orc-input-chips", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "suggestions": { "alias": "suggestions"; "required": false; "isSignal": true; }; "maxTags": { "alias": "maxTags"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "allowDuplicate": { "alias": "allowDuplicate"; "required": false; "isSignal": true; }; "caseSensitiveDuplication": { "alias": "caseSensitiveDuplication"; "required": false; "isSignal": true; }; "addOnTab": { "alias": "addOnTab"; "required": false; "isSignal": true; }; "addOnBlur": { "alias": "addOnBlur"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "tagAdded": "tagAdded"; "tagRemoved": "tagRemoved"; "onAdd": "onAdd"; "onRemove": "onRemove"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onChipClick": "onChipClick"; "onClear": "onClear"; }, never, never, true, never>;
}

declare class ButtonGroupComponent {
    readonly orientation: _angular_core.InputSignal<P2Orientation>;
    readonly attached: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonGroupComponent, "orc-button-group", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "attached": { "alias": "attached"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class GridComponent {
    readonly columns: _angular_core.InputSignal<number>;
    readonly minColumnWidth: _angular_core.InputSignal<string>;
    readonly gap: _angular_core.InputSignal<string>;
    readonly alignItems: _angular_core.InputSignal<"center" | "start" | "end" | "stretch">;
    readonly label: _angular_core.InputSignal<string>;
    readonly columnsStyle: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GridComponent, "orc-grid", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "minColumnWidth": { "alias": "minColumnWidth"; "required": false; "isSignal": true; }; "gap": { "alias": "gap"; "required": false; "isSignal": true; }; "alignItems": { "alias": "alignItems"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class AspectRatioComponent {
    readonly ratio: _angular_core.InputSignal<string>;
    readonly overflow: _angular_core.InputSignal<"hidden" | "visible">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AspectRatioComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AspectRatioComponent, "orc-aspect-ratio", never, { "ratio": { "alias": "ratio"; "required": false; "isSignal": true; }; "overflow": { "alias": "overflow"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class ContainerComponent {
    readonly maxWidth: _angular_core.InputSignal<string>;
    readonly padding: _angular_core.InputSignal<string>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContainerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ContainerComponent, "orc-container", never, { "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class FlexComponent {
    readonly direction: _angular_core.InputSignal<"row" | "row-reverse" | "column" | "column-reverse">;
    readonly gap: _angular_core.InputSignal<string>;
    readonly align: _angular_core.InputSignal<"center" | "start" | "end" | "stretch" | "baseline">;
    readonly justify: _angular_core.InputSignal<"center" | "start" | "end" | "space-between" | "space-around" | "space-evenly">;
    readonly wrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FlexComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FlexComponent, "orc-flex", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "gap": { "alias": "gap"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "justify": { "alias": "justify"; "required": false; "isSignal": true; }; "wrap": { "alias": "wrap"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class StackComponent {
    readonly direction: _angular_core.InputSignal<"row" | "column">;
    readonly gap: _angular_core.InputSignal<string>;
    readonly align: _angular_core.InputSignal<"center" | "start" | "end" | "stretch">;
    readonly justify: _angular_core.InputSignal<"center" | "start" | "end" | "space-between">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StackComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StackComponent, "orc-stack", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "gap": { "alias": "gap"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "justify": { "alias": "justify"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class SpaceComponent {
    readonly size: _angular_core.InputSignal<string>;
    readonly direction: _angular_core.InputSignal<"row" | "column">;
    readonly wrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpaceComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpaceComponent, "orc-space", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "wrap": { "alias": "wrap"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class BoxComponent {
    readonly padding: _angular_core.InputSignal<string>;
    readonly margin: _angular_core.InputSignal<string>;
    readonly background: _angular_core.InputSignal<string>;
    readonly radius: _angular_core.InputSignal<string>;
    readonly width: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BoxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BoxComponent, "orc-box", never, { "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "margin": { "alias": "margin"; "required": false; "isSignal": true; }; "background": { "alias": "background"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class SeparatorComponent {
    readonly orientation: _angular_core.InputSignal<P2Orientation>;
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SeparatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SeparatorComponent, "orc-separator", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class VisuallyHiddenComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VisuallyHiddenComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VisuallyHiddenComponent, "orc-visually-hidden", never, {}, {}, never, ["*"], true, never>;
}
declare class TypographyComponent {
    readonly as: _angular_core.InputSignal<"h1" | "h2" | "h3" | "p" | "span">;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg" | "xs" | "xl">;
    readonly weight: _angular_core.InputSignal<string | number>;
    readonly color: _angular_core.InputSignal<string>;
    readonly truncate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TypographyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TypographyComponent, "orc-typography", never, { "as": { "alias": "as"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "weight": { "alias": "weight"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "truncate": { "alias": "truncate"; "required": false; "isSignal": true; }; }, {}, never, ["*", "*", "*", "*", "*"], true, never>;
}
declare class TextComponent {
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg">;
    readonly muted: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly truncate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextComponent, "orc-text", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "muted": { "alias": "muted"; "required": false; "isSignal": true; }; "truncate": { "alias": "truncate"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class KbdComponent {
    readonly keys: _angular_core.InputSignal<string | string[]>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly normalizedKeys: _angular_core.Signal<string[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KbdComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<KbdComponent, "orc-kbd", never, { "keys": { "alias": "keys"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class LinkComponent {
    readonly href: _angular_core.InputSignal<string>;
    readonly target: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly underline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly activated: _angular_core.OutputEmitterRef<MouseEvent>;
    onClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LinkComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LinkComponent, "orc-link", never, { "href": { "alias": "href"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "underline": { "alias": "underline"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "activated": "activated"; }, never, ["*"], true, never>;
}

declare class CodeComponent {
    readonly code: _angular_core.InputSignal<string>;
    readonly language: _angular_core.InputSignal<string | undefined>;
    readonly copyLabel: _angular_core.InputSignal<string | undefined>;
    readonly copiedLabel: _angular_core.InputSignal<string | undefined>;
    readonly copied: _angular_core.WritableSignal<boolean>;
    readonly copiedEvent: _angular_core.OutputEmitterRef<string>;
    copy(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CodeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CodeComponent, "orc-code", never, { "code": { "alias": "code"; "required": false; "isSignal": true; }; "language": { "alias": "language"; "required": false; "isSignal": true; }; "copyLabel": { "alias": "copyLabel"; "required": false; "isSignal": true; }; "copiedLabel": { "alias": "copiedLabel"; "required": false; "isSignal": true; }; }, { "copiedEvent": "copiedEvent"; }, never, never, true, never>;
}
interface MenubarItem extends P2Option<string> {
    shortcut?: string;
    children?: MenubarItem[];
    visible?: boolean;
    badge?: string;
}
declare class MenubarComponent {
    readonly items: _angular_core.InputSignal<MenubarItem[]>;
    readonly model: _angular_core.InputSignal<MenubarItem[] | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly loop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly openItem: _angular_core.WritableSignal<MenubarItem | null>;
    readonly itemSelect: _angular_core.OutputEmitterRef<MenubarItem>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly menuKeydown: _angular_core.OutputEmitterRef<KeyboardEvent>;
    effectiveItems(): MenubarItem[];
    activate(item: MenubarItem): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenubarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenubarComponent, "orc-menubar", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "loop": { "alias": "loop"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; "onFocus": "onFocus"; "onBlur": "onBlur"; "menuKeydown": "menuKeydown"; }, never, never, true, never>;
}

declare class HoverCardComponent {
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    openCard(): void;
    closeCard(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HoverCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HoverCardComponent, "orc-hover-card", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "open": "openChange"; }, never, ["[hover-card-trigger]", "*"], true, never>;
}
interface DataTableColumn {
    key: string;
    header: string;
    sortable?: boolean;
}
declare class DataTableComponent implements OnInit {
    readonly data: _angular_core.InputSignal<Record<string, unknown>[]>;
    readonly value: _angular_core.InputSignal<Record<string, unknown>[] | undefined>;
    readonly columns: _angular_core.InputSignal<DataTableColumn[]>;
    readonly rowKey: _angular_core.InputSignal<string>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly first: _angular_core.ModelSignal<number>;
    readonly rowsInput: _angular_core.InputSignal<number | undefined>;
    readonly totalRecords: _angular_core.InputSignal<number | undefined>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rowHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stripedRows: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showGridlines: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly sortMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | undefined>;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly sortField: _angular_core.ModelSignal<string>;
    readonly sortOrder: _angular_core.ModelSignal<number>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly tableStyleClass: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly selectAllAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly rowAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly paginatorAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filter: _angular_core.ModelSignal<string>;
    readonly paginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly page: _angular_core.ModelSignal<number>;
    readonly selected: _angular_core.ModelSignal<Record<string, unknown>[]>;
    set selectionAlias(value: Record<string, unknown>[]);
    readonly sortKey: _angular_core.WritableSignal<string>;
    readonly sortDirection: _angular_core.WritableSignal<"ascending" | "descending">;
    readonly selectionEnabled: _angular_core.Signal<boolean>;
    readonly rowClick: _angular_core.OutputEmitterRef<Record<string, unknown>>;
    readonly sortChange: _angular_core.OutputEmitterRef<{
        key: string;
        direction: "ascending" | "descending";
    }>;
    readonly onSort: _angular_core.OutputEmitterRef<{
        key: string;
        direction: "ascending" | "descending";
    }>;
    readonly onPage: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly rowSelect: _angular_core.OutputEmitterRef<Record<string, unknown>>;
    readonly rowUnselect: _angular_core.OutputEmitterRef<Record<string, unknown>>;
    readonly onRowHover: _angular_core.OutputEmitterRef<Record<string, unknown>>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    readonly onHeaderCheckboxToggle: _angular_core.OutputEmitterRef<{
        checked: boolean;
    }>;
    ngOnInit(): void;
    readonly rows: _angular_core.Signal<Record<string, unknown>[]>;
    readonly filteredRows: _angular_core.Signal<Record<string, unknown>[]>;
    readonly effectivePageSize: _angular_core.Signal<number>;
    readonly pageCount: _angular_core.Signal<number>;
    readonly pageRows: _angular_core.Signal<Record<string, unknown>[]>;
    readonly allSelected: _angular_core.Signal<boolean>;
    readonly someSelected: _angular_core.Signal<boolean>;
    getRowId(row: Record<string, unknown>): string;
    getCell(row: Record<string, unknown>, key: string): unknown;
    isSelected(row: Record<string, unknown>): boolean;
    setFilter(value: string): void;
    toggleRow(row: Record<string, unknown>, checked: boolean): void;
    toggleAll(checked: boolean): void;
    sortBy(column: DataTableColumn): void;
    goToPage(page: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataTableComponent, "orc-data-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "rowKey": { "alias": "rowKey"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "rowsInput": { "alias": "rows"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "rowHover": { "alias": "rowHover"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "showGridlines": { "alias": "showGridlines"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tableStyleClass": { "alias": "tableStyleClass"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "selectAllAriaLabel": { "alias": "selectAllAriaLabel"; "required": false; "isSignal": true; }; "rowAriaLabel": { "alias": "rowAriaLabel"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "paginatorAriaLabel": { "alias": "paginatorAriaLabel"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "selectionAlias": { "alias": "selection"; "required": false; }; }, { "first": "firstChange"; "sortField": "sortFieldChange"; "sortOrder": "sortOrderChange"; "filter": "filterChange"; "page": "pageChange"; "selected": "selectedChange"; "rowClick": "rowClick"; "sortChange": "sortChange"; "onSort": "onSort"; "onPage": "onPage"; "onLazyLoad": "onLazyLoad"; "rowSelect": "rowSelect"; "rowUnselect": "rowUnselect"; "onRowHover": "onRowHover"; "onFilter": "onFilter"; "onHeaderCheckboxToggle": "onHeaderCheckboxToggle"; }, never, never, true, never>;
}

declare class VirtualScrollerComponent {
    readonly items: _angular_core.InputSignal<unknown[]>;
    readonly itemHeight: _angular_core.InputSignal<number>;
    readonly itemSize: _angular_core.InputSignal<number>;
    readonly viewportHeight: _angular_core.InputSignal<string>;
    readonly overscan: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly itemLabelKey: _angular_core.InputSignal<string>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollTop: _angular_core.WritableSignal<number>;
    readonly rangeChange: _angular_core.OutputEmitterRef<{
        start: number;
        end: number;
    }>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        last: number;
    }>;
    readonly startIndex: _angular_core.Signal<number>;
    readonly endIndex: _angular_core.Signal<number>;
    readonly viewportPixels: _angular_core.Signal<number>;
    readonly visibleItems: _angular_core.Signal<unknown[]>;
    readonly topSpacer: _angular_core.Signal<number>;
    readonly bottomSpacer: _angular_core.Signal<number>;
    onScroll(event: Event): void;
    itemLabel(item: unknown): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VirtualScrollerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VirtualScrollerComponent, "orc-virtual-scroller, orc-scroller", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "itemHeight": { "alias": "itemHeight"; "required": false; "isSignal": true; }; "viewportHeight": { "alias": "viewportHeight"; "required": false; "isSignal": true; }; "overscan": { "alias": "overscan"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "itemLabelKey": { "alias": "itemLabelKey"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, { "rangeChange": "rangeChange"; "onLazyLoad": "onLazyLoad"; }, never, never, true, never>;
}

declare class FloatingActionButtonComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly extended: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly clicked: _angular_core.OutputEmitterRef<MouseEvent>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FloatingActionButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FloatingActionButtonComponent, "orc-floating-action-button", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "extended": { "alias": "extended"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, never, true, never>;
}
declare class CloseButtonComponent {
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg">;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly close: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CloseButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CloseButtonComponent, "orc-close-button", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, never, true, never>;
}
interface ContextMenuItem extends P2Option<string> {
    danger?: boolean;
    shortcut?: string;
    visible?: boolean;
    badge?: string;
}
declare class ContextMenuComponent implements OnDestroy {
    private readonly host;
    readonly items: _angular_core.InputSignal<ContextMenuItem[]>;
    readonly model: _angular_core.InputSignal<ContextMenuItem[] | undefined>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly popup: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly target: _angular_core.InputSignal<string | HTMLElement | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<string | HTMLElement | null | undefined>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly breakpoint: _angular_core.InputSignal<string>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly position: _angular_core.WritableSignal<{
        x: number;
        y: number;
    }>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly itemSelect: _angular_core.OutputEmitterRef<ContextMenuItem>;
    readonly opened: _angular_core.OutputEmitterRef<{
        x: number;
        y: number;
    }>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    private targetElement;
    private readonly targetContextMenu;
    constructor();
    private resolveTarget;
    private bindTarget;
    effectiveItems(): ContextMenuItem[];
    private selectableItems;
    isActive(item: ContextMenuItem): boolean;
    openAt(event: MouseEvent): void;
    show(event?: MouseEvent): void;
    hide(): void;
    toggle(event?: MouseEvent): void;
    activate(item: ContextMenuItem): void;
    onKeydown(event: KeyboardEvent): void;
    onDocumentClick(event: MouseEvent): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContextMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ContextMenuComponent, "orc-context-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "popup": { "alias": "popup"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "itemSelect": "itemSelect"; "opened": "opened"; "onShow": "onShow"; "onHide": "onHide"; }, never, ["*"], true, never>;
}
declare class SplitterPanelContentDirective {
    readonly templateRef: TemplateRef<unknown>;
    readonly orcSplitterPanel: _angular_core.InputSignal<string>;
    constructor(templateRef: TemplateRef<unknown>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitterPanelContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SplitterPanelContentDirective, "[orcSplitterPanel]", never, { "orcSplitterPanel": { "alias": "orcSplitterPanel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class OverlayComponent {
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly mode: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly contentStyle: _angular_core.InputSignal<Record<string, string> | null>;
    readonly contentStyleClass: _angular_core.InputSignal<string>;
    readonly target: _angular_core.InputSignal<string | HTMLElement | null>;
    readonly appendTo: _angular_core.InputSignal<HTMLElement | "body" | undefined>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    show(): void;
    hide(): void;
    toggle(): void;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverlayComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverlayComponent, "orc-overlay", never, { "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "contentStyle": { "alias": "contentStyle"; "required": false; "isSignal": true; }; "contentStyleClass": { "alias": "contentStyleClass"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; }, never, ["*"], true, never>;
}

interface SpeedDialAction extends P2Option<string> {
    color?: string;
}
declare class SpeedDialComponent {
    private readonly host;
    readonly actions: _angular_core.InputSignal<SpeedDialAction[]>;
    readonly model: _angular_core.InputSignal<SpeedDialAction[] | null>;
    readonly direction: _angular_core.InputSignal<"up" | "down" | "left" | "right" | "up-left" | "up-right" | "down-left" | "down-right">;
    readonly type: _angular_core.InputSignal<"linear" | "circle" | "semi-circle" | "quarter-circle">;
    readonly radius: _angular_core.InputSignal<number>;
    readonly transitionDelay: _angular_core.InputSignal<number>;
    readonly mask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly hideOnClickOutside: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly buttonClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly openLabel: _angular_core.InputSignal<string | undefined>;
    readonly closeLabel: _angular_core.InputSignal<string | undefined>;
    readonly actionSelect: _angular_core.OutputEmitterRef<SpeedDialAction>;
    readonly visibleChange: _angular_core.OutputEmitterRef<boolean>;
    readonly onVisibleChange: _angular_core.OutputEmitterRef<boolean>;
    readonly onShow: _angular_core.OutputEmitterRef<Event>;
    readonly onHide: _angular_core.OutputEmitterRef<Event>;
    readonly onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    effectiveActions(): SpeedDialAction[];
    toggleButton(event: MouseEvent): void;
    show(event?: Event): void;
    hide(event?: Event): void;
    activate(action: SpeedDialAction): void;
    onDocumentClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpeedDialComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpeedDialComponent, "orc-speed-dial", never, { "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; "transitionDelay": { "alias": "transitionDelay"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "hideOnClickOutside": { "alias": "hideOnClickOutside"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "buttonClass": { "alias": "buttonClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "openLabel": { "alias": "openLabel"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "actionSelect": "actionSelect"; "visibleChange": "visibleChange"; "onVisibleChange": "onVisibleChange"; "onShow": "onShow"; "onHide": "onHide"; "onClick": "onClick"; }, never, never, true, never>;
}
declare class PortalComponent implements AfterViewInit, OnDestroy {
    readonly target: _angular_core.InputSignal<HTMLElement | null>;
    private readonly host;
    private nodes;
    constructor();
    ngAfterViewInit(): void;
    private move;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PortalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PortalComponent, "orc-portal", never, { "target": { "alias": "target"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
interface SplitterPanel {
    id: string;
    label?: string;
    size?: number;
    minSize?: number;
}
declare class SplitterComponent {
    readonly panels: _angular_core.InputSignal<SplitterPanel[]>;
    readonly orientation: _angular_core.InputSignal<P2Orientation>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly resizeLabel: _angular_core.InputSignal<string | undefined>;
    readonly sizes: _angular_core.ModelSignal<number[]>;
    readonly onResizeStart: _angular_core.OutputEmitterRef<{
        index: number;
    }>;
    readonly onResizeEnd: _angular_core.OutputEmitterRef<KeyboardEvent>;
    readonly onResize: _angular_core.OutputEmitterRef<{
        index: number;
        sizes: number[];
    }>;
    private readonly panelContents;
    contentFor(id: string): SplitterPanelContentDirective | undefined;
    readonly normalizedSizes: _angular_core.Signal<number[]>;
    panelSize(index: number): number;
    setSizes(sizes: number[]): void;
    resize(index: number, delta: number): void;
    private normalize;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SplitterComponent, "orc-splitter", never, { "panels": { "alias": "panels"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "resizeLabel": { "alias": "resizeLabel"; "required": false; "isSignal": true; }; "sizes": { "alias": "sizes"; "required": false; "isSignal": true; }; }, { "sizes": "sizesChange"; "onResizeStart": "onResizeStart"; "onResizeEnd": "onResizeEnd"; "onResize": "onResize"; }, ["panelContents"], ["*"], true, never>;
}

interface P2Message {
    severity?: 'success' | 'info' | 'warn' | 'error' | 'secondary' | 'contrast';
    summary?: string;
    detail?: string;
    id?: string | number;
    closable?: boolean;
}
declare class MessagesComponent {
    readonly messages: _angular_core.ModelSignal<P2Message[]>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLive: _angular_core.InputSignal<"polite" | "assertive">;
    readonly closeLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly messageClose: _angular_core.OutputEmitterRef<P2Message>;
    readonly clear: _angular_core.OutputEmitterRef<void>;
    messageRole(message: P2Message): 'alert' | 'status';
    remove(index: number): void;
    clearMessages(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MessagesComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MessagesComponent, "orc-messages", never, { "messages": { "alias": "messages"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLive": { "alias": "ariaLive"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "messages": "messagesChange"; "messageClose": "messageClose"; "clear": "clear"; }, never, never, true, never>;
}

interface TreeSelectNode extends P2Option<string> {
    children?: TreeSelectNode[];
}
interface VisibleTreeSelectNode {
    node: TreeSelectNode;
    level: number;
}
declare class TreeSelectComponent implements ControlValueAccessor {
    private readonly uniqueId;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly nodes: _angular_core.InputSignal<TreeSelectNode[]>;
    readonly value: _angular_core.ModelSignal<string | string[] | null>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<string | number | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly display: _angular_core.InputSignal<"comma" | "chip">;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly panelStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly panelStyleClass: _angular_core.InputSignal<string>;
    readonly panelClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly overlayOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly scrollHeight: _angular_core.InputSignal<string>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterBy: _angular_core.InputSignal<string>;
    readonly filterMode: _angular_core.InputSignal<string>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly collapseAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filterInputAutoFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly propagateSelectionDown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly propagateSelectionUp: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox">;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly expanded: _angular_core.WritableSignal<ReadonlySet<string>>;
    readonly nodeSelect: _angular_core.OutputEmitterRef<TreeSelectNode>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: string | string[] | null;
    }>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onClear: _angular_core.OutputEmitterRef<Event>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        filter: string;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onNodeExpand: _angular_core.OutputEmitterRef<TreeSelectNode>;
    readonly onNodeCollapse: _angular_core.OutputEmitterRef<TreeSelectNode>;
    readonly nodeUnselect: _angular_core.OutputEmitterRef<TreeSelectNode>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly activeTreeIndex: _angular_core.WritableSignal<number>;
    readonly activeTreeOptionId: _angular_core.Signal<string | null>;
    readonly visibleNodes: _angular_core.Signal<VisibleTreeSelectNode[]>;
    readonly filteredVisibleNodes: _angular_core.Signal<VisibleTreeSelectNode[]>;
    writeValue(value: string | string[] | null): void;
    registerOnChange(fn: (value: string | string[] | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    selectedLabel(): string;
    isNodeSelected(node: TreeSelectNode): boolean;
    toggleOpen(): void;
    toggle(node: TreeSelectNode): void;
    select(node: TreeSelectNode, event?: Event): void;
    private descendantValues;
    private ancestorValues;
    clear(event?: Event): void;
    onFilterInput(event: Event): void;
    treeOptionId(index: number): string;
    onKeydown(event: KeyboardEvent): void;
    private findNode;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeSelectComponent, "orc-tree-select", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "panelClass": { "alias": "panelClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "collapseAriaLabel": { "alias": "collapseAriaLabel"; "required": false; "isSignal": true; }; "filterInputAutoFocus": { "alias": "filterInputAutoFocus"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "propagateSelectionDown": { "alias": "propagateSelectionDown"; "required": false; "isSignal": true; }; "propagateSelectionUp": { "alias": "propagateSelectionUp"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "filterValue": "filterValueChange"; "open": "openChange"; "nodeSelect": "nodeSelect"; "onChange": "onChange"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; "nodeUnselect": "nodeUnselect"; }, never, never, true, never>;
}

declare class PanelComponent {
    readonly header: _angular_core.InputSignal<string>;
    readonly legend: _angular_core.InputSignal<string | undefined>;
    readonly toggleable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly transitionOptions: _angular_core.InputSignal<string>;
    readonly collapsed: _angular_core.ModelSignal<boolean>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly expandLabel: _angular_core.InputSignal<string | undefined>;
    readonly collapseLabel: _angular_core.InputSignal<string | undefined>;
    readonly onBeforeToggle: _angular_core.OutputEmitterRef<{
        collapsed: boolean;
    }>;
    readonly onAfterToggle: _angular_core.OutputEmitterRef<{
        collapsed: boolean;
    }>;
    hasHeader(): boolean;
    toggle(): void;
    expand(): void;
    collapse(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PanelComponent, "orc-panel", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "expandLabel": { "alias": "expandLabel"; "required": false; "isSignal": true; }; "collapseLabel": { "alias": "collapseLabel"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsedChange"; "onBeforeToggle": "onBeforeToggle"; "onAfterToggle": "onAfterToggle"; }, never, ["[orcPanelHeader]", "*"], true, never>;
}
declare class FieldsetComponent {
    readonly legend: _angular_core.InputSignal<string>;
    readonly toggleable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly collapsed: _angular_core.ModelSignal<boolean>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly expandLabel: _angular_core.InputSignal<string | undefined>;
    readonly collapseLabel: _angular_core.InputSignal<string | undefined>;
    readonly onBeforeToggle: _angular_core.OutputEmitterRef<{
        collapsed: boolean;
    }>;
    readonly onAfterToggle: _angular_core.OutputEmitterRef<{
        collapsed: boolean;
    }>;
    toggle(): void;
    expand(): void;
    collapse(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FieldsetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FieldsetComponent, "orc-fieldset", never, { "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "expandLabel": { "alias": "expandLabel"; "required": false; "isSignal": true; }; "collapseLabel": { "alias": "collapseLabel"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsedChange"; "onBeforeToggle": "onBeforeToggle"; "onAfterToggle": "onAfterToggle"; }, never, ["*"], true, never>;
}
declare class FloatLabelComponent {
    readonly variant: _angular_core.InputSignal<"in" | "over" | "on">;
    readonly styleClass: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FloatLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FloatLabelComponent, "orc-float-label", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class FluidComponent {
    readonly styleClass: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FluidComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FluidComponent, "orc-fluid", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class OverlayBadgeComponent {
    readonly value: _angular_core.InputSignal<string | number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverlayBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverlayBadgeComponent, "orc-overlay-badge", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
interface MeterItem {
    value: number;
    label?: string;
    color?: string;
}
declare class MeterGroupComponent {
    readonly values: _angular_core.InputSignal<MeterItem[]>;
    readonly value: _angular_core.InputSignal<MeterItem[] | undefined>;
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly color: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly labelPosition: _angular_core.InputSignal<"start" | "end">;
    readonly labelOrientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    effectiveValues(): MeterItem[];
    total(): number;
    percent(item: MeterItem): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MeterGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MeterGroupComponent, "orc-meter-group", never, { "values": { "alias": "values"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "labelOrientation": { "alias": "labelOrientation"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class PasswordComponent implements ControlValueAccessor {
    readonly value: _angular_core.ModelSignal<string>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly inputStyleClass: _angular_core.InputSignal<string>;
    readonly inputStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly maxLength: _angular_core.InputSignal<number | undefined>;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly feedback: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly toggleMask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly hidePasswordLabel: _angular_core.InputSignal<string | undefined>;
    readonly showPasswordLabel: _angular_core.InputSignal<string | undefined>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly promptLabel: _angular_core.InputSignal<string | undefined>;
    readonly weakLabel: _angular_core.InputSignal<string | undefined>;
    readonly mediumLabel: _angular_core.InputSignal<string | undefined>;
    readonly strongLabel: _angular_core.InputSignal<string | undefined>;
    readonly mediumRegex: _angular_core.InputSignal<string>;
    readonly strongRegex: _angular_core.InputSignal<string>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onClear: _angular_core.OutputEmitterRef<void>;
    readonly focused: _angular_core.WritableSignal<boolean>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    readonly strength: _angular_core.Signal<"strong" | "weak" | "medium">;
    readonly strengthLabel: _angular_core.Signal<string | undefined>;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    onInput(event: Event): void;
    handleFocus(event: Event): void;
    handleBlur(event: Event): void;
    toggleVisible(): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PasswordComponent, "orc-password, orc-input-password", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputStyleClass": { "alias": "inputStyleClass"; "required": false; "isSignal": true; }; "inputStyle": { "alias": "inputStyle"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "feedback": { "alias": "feedback"; "required": false; "isSignal": true; }; "toggleMask": { "alias": "toggleMask"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "hidePasswordLabel": { "alias": "hidePasswordLabel"; "required": false; "isSignal": true; }; "showPasswordLabel": { "alias": "showPasswordLabel"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "promptLabel": { "alias": "promptLabel"; "required": false; "isSignal": true; }; "weakLabel": { "alias": "weakLabel"; "required": false; "isSignal": true; }; "mediumLabel": { "alias": "mediumLabel"; "required": false; "isSignal": true; }; "strongLabel": { "alias": "strongLabel"; "required": false; "isSignal": true; }; "mediumRegex": { "alias": "mediumRegex"; "required": false; "isSignal": true; }; "strongRegex": { "alias": "strongRegex"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "visible": "visibleChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onClear": "onClear"; }, never, never, true, never>;
}
declare class SplitButtonComponent {
    readonly model: _angular_core.InputSignal<{
        label: string;
        icon?: string;
        disabled?: boolean;
        visible?: boolean;
        command?: () => void;
    }[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly iconPos: _angular_core.InputSignal<"left" | "right">;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly menuStyle: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly menuStyleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly tooltip: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly buttonDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly menuButtonDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly severity: _angular_core.InputSignal<string | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly primaryClick: _angular_core.OutputEmitterRef<Event>;
    readonly onClick: _angular_core.OutputEmitterRef<Event>;
    readonly dropdownClick: _angular_core.OutputEmitterRef<Event>;
    readonly onDropdownClick: _angular_core.OutputEmitterRef<Event>;
    readonly onMenuShow: _angular_core.OutputEmitterRef<void>;
    readonly onMenuHide: _angular_core.OutputEmitterRef<void>;
    effectiveModel(): Array<{
        label: string;
        icon?: string;
        disabled?: boolean;
        visible?: boolean;
        command?: () => void;
    }>;
    activate(item: {
        command?: () => void;
    }): void;
    onDefaultButtonClick(event: MouseEvent): void;
    toggleOpen(event?: Event): void;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SplitButtonComponent, "orc-split-button", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "menuStyle": { "alias": "menuStyle"; "required": false; "isSignal": true; }; "menuStyleClass": { "alias": "menuStyleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "buttonDisabled": { "alias": "buttonDisabled"; "required": false; "isSignal": true; }; "menuButtonDisabled": { "alias": "menuButtonDisabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "primaryClick": "primaryClick"; "onClick": "onClick"; "dropdownClick": "dropdownClick"; "onDropdownClick": "onDropdownClick"; "onMenuShow": "onMenuShow"; "onMenuHide": "onMenuHide"; }, never, ["*"], true, never>;
}
declare class ScrollTopComponent implements AfterViewInit, OnDestroy {
    private readonly host;
    readonly threshold: _angular_core.InputSignal<number>;
    readonly target: _angular_core.InputSignal<"window" | "parent">;
    readonly behavior: _angular_core.InputSignal<"auto" | "smooth">;
    readonly icon: _angular_core.InputSignal<string>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly buttonAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    private parent;
    private readonly parentScroll;
    constructor(host: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    private bindParent;
    ngOnDestroy(): void;
    onScroll(): void;
    onParentScroll(): void;
    scroll(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollTopComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ScrollTopComponent, "orc-scroll-top", never, { "threshold": { "alias": "threshold"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "behavior": { "alias": "behavior"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "buttonAriaLabel": { "alias": "buttonAriaLabel"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "clicked": "clicked"; }, never, never, true, never>;
}

interface PrimeMenuItem {
    label: string;
    value?: string;
    icon?: string;
    disabled?: boolean;
    visible?: boolean;
    url?: string;
    target?: string;
    badge?: string;
    separator?: boolean;
    items?: PrimeMenuItem[];
    command?: () => void;
}
declare class MenuComponent {
    readonly model: _angular_core.InputSignal<PrimeMenuItem[] | undefined>;
    readonly items: _angular_core.InputSignal<PrimeMenuItem[]>;
    readonly popup: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<string | HTMLElement | null | undefined>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly itemSelect: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onItemClick: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly activeItem: _angular_core.WritableSignal<PrimeMenuItem | null>;
    effectiveModel(): PrimeMenuItem[];
    isActive(item: PrimeMenuItem): boolean;
    activate(item: PrimeMenuItem): void;
    show(): void;
    hide(): void;
    toggle(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuComponent, "orc-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "popup": { "alias": "popup"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "itemSelect": "itemSelect"; "onItemClick": "onItemClick"; "onShow": "onShow"; "onHide": "onHide"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class TieredMenuComponent {
    readonly items: _angular_core.InputSignal<PrimeMenuItem[]>;
    readonly model: _angular_core.InputSignal<PrimeMenuItem[] | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<string | HTMLElement | null | undefined>;
    readonly breakpoint: _angular_core.InputSignal<string>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly autoDisplay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly popup: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly openItem: _angular_core.WritableSignal<PrimeMenuItem | null>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly itemSelect: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onItemClick: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    effectiveItems(): PrimeMenuItem[];
    isActiveItem(item: PrimeMenuItem): boolean;
    activate(item: PrimeMenuItem): void;
    show(): void;
    hide(): void;
    toggle(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TieredMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TieredMenuComponent, "orc-tiered-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "autoDisplay": { "alias": "autoDisplay"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "popup": { "alias": "popup"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "itemSelect": "itemSelect"; "onItemClick": "onItemClick"; "onShow": "onShow"; "onHide": "onHide"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class PanelMenuComponent {
    readonly items: _angular_core.InputSignal<PrimeMenuItem[]>;
    readonly model: _angular_core.InputSignal<PrimeMenuItem[] | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly transitionOptions: _angular_core.InputSignal<string>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly open: _angular_core.ModelSignal<ReadonlySet<PrimeMenuItem>>;
    readonly itemSelect: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onItemExpand: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onItemCollapse: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onNodeSelect: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onNodeExpand: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onNodeCollapse: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    effectiveItems(): PrimeMenuItem[];
    isActive(item: PrimeMenuItem): boolean;
    onKeydown(event: KeyboardEvent, _index: number): void;
    toggle(item: PrimeMenuItem): void;
    select(item: PrimeMenuItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PanelMenuComponent, "orc-panel-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "itemSelect": "itemSelect"; "onItemExpand": "onItemExpand"; "onItemCollapse": "onItemCollapse"; "onNodeSelect": "onNodeSelect"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; }, never, never, true, never>;
}
declare class MegaMenuComponent {
    readonly items: _angular_core.InputSignal<PrimeMenuItem[]>;
    readonly model: _angular_core.InputSignal<PrimeMenuItem[] | undefined>;
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly itemSelect: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onItemClick: _angular_core.OutputEmitterRef<PrimeMenuItem>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    effectiveItems(): PrimeMenuItem[];
    select(item: PrimeMenuItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MegaMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MegaMenuComponent, "orc-mega-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; "onItemClick": "onItemClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class BlockUiComponent {
    readonly blocked: _angular_core.ModelSignal<boolean>;
    readonly target: _angular_core.InputSignal<string | HTMLElement | null>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly message: _angular_core.InputSignal<string | undefined>;
    readonly onBlock: _angular_core.OutputEmitterRef<void>;
    readonly onUnblock: _angular_core.OutputEmitterRef<void>;
    block(): void;
    unblock(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BlockUiComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BlockUiComponent, "orc-block-ui", never, { "blocked": { "alias": "blocked"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; }, { "blocked": "blockedChange"; "onBlock": "onBlock"; "onUnblock": "onUnblock"; }, never, ["*"], true, never>;
}
declare class ConfirmationService {
    readonly request: _angular_core.WritableSignal<ConfirmationRequest | null>;
    confirm(request: ConfirmationRequest): void;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmationService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfirmationService>;
}
interface ConfirmationRequest {
    message: string;
    header?: string;
    icon?: string;
    acceptLabel?: string;
    rejectLabel?: string;
    acceptIcon?: string;
    rejectIcon?: string;
    acceptAriaLabel?: string;
    rejectAriaLabel?: string;
    acceptVisible?: boolean;
    rejectVisible?: boolean;
    acceptButtonStyleClass?: string;
    rejectButtonStyleClass?: string;
    key?: string;
    accept?: () => void;
    reject?: () => void;
}
declare class ConfirmDialogComponent {
    private readonly service;
    readonly request: ConfirmationService['request'];
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismissableMask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly blockScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rtl: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly maskStyleClass: _angular_core.InputSignal<string>;
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly defaultFocus: _angular_core.InputSignal<"close" | "accept" | "reject" | "none">;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onAccept: _angular_core.OutputEmitterRef<void>;
    readonly onReject: _angular_core.OutputEmitterRef<void>;
    readonly acceptButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    readonly rejectButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    readonly closeButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    private restoreFocus;
    constructor(service: ConfirmationService);
    acceptLabel(): string;
    rejectLabel(): string;
    private focusDefault;
    private restorePreviousFocus;
    accept(): void;
    reject(): void;
    close(): void;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmDialogComponent, "orc-confirm-dialog", never, { "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "dismissableMask": { "alias": "dismissableMask"; "required": false; "isSignal": true; }; "blockScroll": { "alias": "blockScroll"; "required": false; "isSignal": true; }; "rtl": { "alias": "rtl"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "maskStyleClass": { "alias": "maskStyleClass"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "defaultFocus": { "alias": "defaultFocus"; "required": false; "isSignal": true; }; }, { "onHide": "onHide"; "onAccept": "onAccept"; "onReject": "onReject"; }, never, never, true, never>;
}
declare class DataViewComponent<T = Record<string, unknown>> implements OnInit {
    readonly value: _angular_core.InputSignal<T[]>;
    readonly layout: _angular_core.ModelSignal<"list" | "grid">;
    readonly header: _angular_core.InputSignal<string>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly itemTemplate: _angular_core.InputSignal<any>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly gridStyleClass: _angular_core.InputSignal<string>;
    readonly listStyleClass: _angular_core.InputSignal<string>;
    readonly trackBy: _angular_core.InputSignal<((index: number, item: T) => unknown) | undefined>;
    readonly paginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly first: _angular_core.ModelSignal<number>;
    readonly totalRecords: _angular_core.InputSignal<number | undefined>;
    readonly pageLinks: _angular_core.InputSignal<number>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[] | undefined>;
    readonly paginatorPosition: _angular_core.InputSignal<"top" | "bottom" | "both">;
    readonly paginatorStyleClass: _angular_core.InputSignal<string>;
    readonly alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly currentPageReportTemplate: _angular_core.InputSignal<string | undefined>;
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly paginatorAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly sortField: _angular_core.InputSignal<string | undefined>;
    readonly sortOrder: _angular_core.ModelSignal<1 | -1>;
    readonly onPage: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onSort: _angular_core.OutputEmitterRef<{
        sortField: string;
        sortOrder: 1 | -1;
    }>;
    readonly onLayoutChange: _angular_core.OutputEmitterRef<"list" | "grid">;
    readonly onChangeLayout: _angular_core.OutputEmitterRef<"list" | "grid">;
    readonly sortedItems: _angular_core.Signal<T[]>;
    readonly pageCount: _angular_core.Signal<number>;
    readonly filteredItems: _angular_core.Signal<T[]>;
    readonly pageItems: _angular_core.Signal<T[]>;
    effectiveTotalRecords(): number;
    getItemKey(item: T, index: number): unknown;
    itemLabel(item: T): string;
    pageReport(): string;
    ngOnInit(): void;
    setLayout(layout: 'list' | 'grid'): void;
    goToPage(first: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataViewComponent<any>, "orc-data-view", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "gridStyleClass": { "alias": "gridStyleClass"; "required": false; "isSignal": true; }; "listStyleClass": { "alias": "listStyleClass"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "paginatorAriaLabel": { "alias": "paginatorAriaLabel"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; }, { "layout": "layoutChange"; "first": "firstChange"; "filterValue": "filterValueChange"; "sortOrder": "sortOrderChange"; "onPage": "onPage"; "onLazyLoad": "onLazyLoad"; "onSort": "onSort"; "onLayoutChange": "onLayoutChange"; "onChangeLayout": "onChangeLayout"; }, never, never, true, never>;
}

declare class InputGroupAddonComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputGroupAddonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputGroupAddonComponent, "orc-input-group-addon", never, {}, {}, never, ["*"], true, never>;
}
declare class IconFieldComponent {
    readonly icon: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconFieldComponent, "orc-icon-field", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
declare class IftaLabelComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IftaLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IftaLabelComponent, "orc-ifta-label", never, {}, {}, never, ["*"], true, never>;
}
declare class InplaceComponent {
    readonly active: _angular_core.ModelSignal<boolean>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly preventClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly closeLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly activated: _angular_core.OutputEmitterRef<void>;
    readonly deactivated: _angular_core.OutputEmitterRef<void>;
    readonly onActivate: _angular_core.OutputEmitterRef<Event>;
    readonly onDeactivate: _angular_core.OutputEmitterRef<Event>;
    activate(event?: Event): void;
    deactivate(event?: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InplaceComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InplaceComponent, "orc-inplace", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "preventClick": { "alias": "preventClick"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; "activated": "activated"; "deactivated": "deactivated"; "onActivate": "onActivate"; "onDeactivate": "onDeactivate"; }, never, ["[orcInplaceDisplay]", "[orcInplaceContent]", "*"], true, never>;
}
declare class TerminalComponent {
    readonly prompt: _angular_core.InputSignal<string>;
    readonly welcomeMessage: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly commandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly command: _angular_core.ModelSignal<string>;
    readonly history: _angular_core.ModelSignal<TerminalLine[]>;
    readonly commandRun: _angular_core.OutputEmitterRef<string>;
    readonly onCommand: _angular_core.OutputEmitterRef<string>;
    submit(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TerminalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TerminalComponent, "orc-terminal", never, { "prompt": { "alias": "prompt"; "required": false; "isSignal": true; }; "welcomeMessage": { "alias": "welcomeMessage"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "commandAriaLabel": { "alias": "commandAriaLabel"; "required": false; "isSignal": true; }; "command": { "alias": "command"; "required": false; "isSignal": true; }; "history": { "alias": "history"; "required": false; "isSignal": true; }; }, { "command": "commandChange"; "history": "historyChange"; "commandRun": "commandRun"; "onCommand": "onCommand"; }, never, never, true, never>;
}
interface TerminalLine {
    command: string;
    output?: string;
}
declare class ImageCompareComponent {
    readonly before: _angular_core.InputSignal<string>;
    readonly after: _angular_core.InputSignal<string>;
    readonly beforeAlt: _angular_core.InputSignal<string | undefined>;
    readonly afterAlt: _angular_core.InputSignal<string | undefined>;
    readonly aspectRatio: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly position: _angular_core.ModelSignal<number>;
    readonly onSlide: _angular_core.OutputEmitterRef<number>;
    setPosition(value: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageCompareComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ImageCompareComponent, "orc-image-compare", never, { "before": { "alias": "before"; "required": false; "isSignal": true; }; "after": { "alias": "after"; "required": false; "isSignal": true; }; "beforeAlt": { "alias": "beforeAlt"; "required": false; "isSignal": true; }; "afterAlt": { "alias": "afterAlt"; "required": false; "isSignal": true; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, { "position": "positionChange"; "onSlide": "onSlide"; }, never, never, true, never>;
}

interface HierarchyNode<T = Record<string, unknown>> {
    key: string;
    label: string;
    data?: T;
    children?: HierarchyNode<T>[];
    leaf?: boolean;
    disabled?: boolean;
}
interface FlatHierarchyNode<T> {
    node: HierarchyNode<T>;
    level: number;
}
declare class TreeComponent<T = Record<string, unknown>> {
    private readonly host;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly nodes: _angular_core.InputSignal<HierarchyNode<T>[]>;
    readonly value: _angular_core.InputSignal<HierarchyNode<T>[] | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox">;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly propagateSelectionUp: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly propagateSelectionDown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly filterBy: _angular_core.InputSignal<string>;
    readonly filterMode: _angular_core.InputSignal<string>;
    readonly filterInputAutoFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingMessage: _angular_core.InputSignal<string | undefined>;
    readonly loadingMode: _angular_core.InputSignal<"mask" | "icon">;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly collapseAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly contextMenu: _angular_core.InputSignal<unknown>;
    readonly draggableScope: _angular_core.InputSignal<unknown>;
    readonly droppableScope: _angular_core.InputSignal<unknown>;
    readonly draggableNodes: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly droppableNodes: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly indentation: _angular_core.InputSignal<number>;
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selected: _angular_core.ModelSignal<string | string[] | null>;
    readonly expanded: _angular_core.WritableSignal<ReadonlySet<string>>;
    readonly nodeSelect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeUnselect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeExpand: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeCollapse: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeSelect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeUnselect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeExpand: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeCollapse: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly selectionChange: _angular_core.OutputEmitterRef<string | string[] | null>;
    readonly onNodeContextMenuSelect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeDoubleClick: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeDrop: _angular_core.OutputEmitterRef<unknown>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<unknown>;
    readonly onScroll: _angular_core.OutputEmitterRef<Event>;
    readonly onScrollIndexChange: _angular_core.OutputEmitterRef<number>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        filter: string;
    }>;
    readonly effectiveNodes: _angular_core.Signal<HierarchyNode<T>[]>;
    readonly visibleNodes: _angular_core.Signal<FlatHierarchyNode<T>[]>;
    readonly filteredVisibleNodes: _angular_core.Signal<FlatHierarchyNode<T>[]>;
    toggle(node: HierarchyNode<T>): void;
    isSelected(key: string): boolean;
    select(node: HierarchyNode<T>, event?: Event): void;
    private descendantKeys;
    private normalizeParentSelection;
    onFilterInput(event: Event): void;
    onContextMenu(event: MouseEvent, node: HierarchyNode<T>): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeComponent<any>, "orc-tree", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "propagateSelectionUp": { "alias": "propagateSelectionUp"; "required": false; "isSignal": true; }; "propagateSelectionDown": { "alias": "propagateSelectionDown"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterInputAutoFocus": { "alias": "filterInputAutoFocus"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingMessage": { "alias": "loadingMessage"; "required": false; "isSignal": true; }; "loadingMode": { "alias": "loadingMode"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "collapseAriaLabel": { "alias": "collapseAriaLabel"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "contextMenu": { "alias": "contextMenu"; "required": false; "isSignal": true; }; "draggableScope": { "alias": "draggableScope"; "required": false; "isSignal": true; }; "droppableScope": { "alias": "droppableScope"; "required": false; "isSignal": true; }; "draggableNodes": { "alias": "draggableNodes"; "required": false; "isSignal": true; }; "droppableNodes": { "alias": "droppableNodes"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "indentation": { "alias": "indentation"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "filterValue": "filterValueChange"; "selected": "selectedChange"; "nodeSelect": "nodeSelect"; "nodeUnselect": "nodeUnselect"; "nodeExpand": "nodeExpand"; "nodeCollapse": "nodeCollapse"; "onNodeSelect": "onNodeSelect"; "onNodeUnselect": "onNodeUnselect"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; "selectionChange": "selectionChange"; "onNodeContextMenuSelect": "onNodeContextMenuSelect"; "onNodeDoubleClick": "onNodeDoubleClick"; "onNodeDrop": "onNodeDrop"; "onLazyLoad": "onLazyLoad"; "onScroll": "onScroll"; "onScrollIndexChange": "onScrollIndexChange"; "onFilter": "onFilter"; }, never, never, true, never>;
}
interface TreeTableColumn {
    key: string;
    header: string;
}
declare class TreeTableComponent<T = Record<string, unknown>> implements OnInit {
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox">;
    readonly propagateSelectionUp: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly propagateSelectionDown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly value: _angular_core.InputSignal<HierarchyNode<T>[]>;
    readonly columns: _angular_core.InputSignal<TreeTableColumn[]>;
    readonly frozenColumns: _angular_core.InputSignal<TreeTableColumn[] | undefined>;
    readonly frozenWidth: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly treeColumnHeader: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly showLoader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly collapseAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly tableStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly tableStyleClass: _angular_core.InputSignal<string>;
    readonly autoLayout: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly paginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rows: _angular_core.InputSignal<number | undefined>;
    readonly first: _angular_core.ModelSignal<number>;
    readonly pageLinks: _angular_core.InputSignal<number>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[] | undefined>;
    readonly alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly paginatorPosition: _angular_core.InputSignal<"top" | "bottom" | "both">;
    readonly paginatorStyleClass: _angular_core.InputSignal<string>;
    readonly currentPageReportTemplate: _angular_core.InputSignal<string | undefined>;
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly defaultSortOrder: _angular_core.InputSignal<number>;
    readonly sortMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly resetPageOnSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly customSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly compareSelectionBy: _angular_core.InputSignal<string>;
    readonly contextMenuSelection: _angular_core.InputSignal<HierarchyNode<T> | null>;
    readonly contextMenuSelectionMode: _angular_core.InputSignal<"separate" | "joint">;
    readonly rowHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    readonly virtualScrollOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly virtualScrollDelay: _angular_core.InputSignal<number>;
    readonly resizableColumns: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly reorderableColumns: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly columnResizeMode: _angular_core.InputSignal<string>;
    readonly showGridlines: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly globalFilterFields: _angular_core.InputSignal<string[]>;
    readonly filterDelay: _angular_core.InputSignal<number>;
    readonly filterMode: _angular_core.InputSignal<string>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly paginatorLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly expanded: _angular_core.WritableSignal<ReadonlySet<string>>;
    readonly selected: _angular_core.ModelSignal<ReadonlySet<string>>;
    readonly nodeSelect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeUnselect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeExpand: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly nodeCollapse: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeSelect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onNodeUnselect: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly selectionChange: _angular_core.OutputEmitterRef<ReadonlySet<string>>;
    readonly contextMenuSelectionChange: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onContextMenuSelect: _angular_core.OutputEmitterRef<{
        data: HierarchyNode<T>;
        originalEvent: Event;
    }>;
    readonly rowExpand: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly rowCollapse: _angular_core.OutputEmitterRef<HierarchyNode<T>>;
    readonly onFilter: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    readonly onPage: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onSort: _angular_core.OutputEmitterRef<unknown>;
    readonly onLazyLoad: _angular_core.OutputEmitterRef<{
        first: number;
        rows: number;
    }>;
    readonly onHeaderCheckboxToggle: _angular_core.OutputEmitterRef<{
        checked: boolean;
    }>;
    readonly onColResize: _angular_core.OutputEmitterRef<unknown>;
    readonly onColReorder: _angular_core.OutputEmitterRef<unknown>;
    readonly visibleNodes: _angular_core.Signal<FlatHierarchyNode<T>[]>;
    ngOnInit(): void;
    readonly displayNodes: _angular_core.Signal<FlatHierarchyNode<T>[]>;
    toggle(item: FlatHierarchyNode<T>): void;
    select(item: FlatHierarchyNode<T>, checked: boolean): void;
    private descendantKeys;
    private normalizeParentSelection;
    cellValue(node: HierarchyNode<T>, key: string): unknown;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeTableComponent<any>, "orc-tree-table", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "propagateSelectionUp": { "alias": "propagateSelectionUp"; "required": false; "isSignal": true; }; "propagateSelectionDown": { "alias": "propagateSelectionDown"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "frozenColumns": { "alias": "frozenColumns"; "required": false; "isSignal": true; }; "frozenWidth": { "alias": "frozenWidth"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "treeColumnHeader": { "alias": "treeColumnHeader"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "showLoader": { "alias": "showLoader"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "collapseAriaLabel": { "alias": "collapseAriaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "tableStyle": { "alias": "tableStyle"; "required": false; "isSignal": true; }; "tableStyleClass": { "alias": "tableStyleClass"; "required": false; "isSignal": true; }; "autoLayout": { "alias": "autoLayout"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "defaultSortOrder": { "alias": "defaultSortOrder"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "resetPageOnSort": { "alias": "resetPageOnSort"; "required": false; "isSignal": true; }; "customSort": { "alias": "customSort"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "compareSelectionBy": { "alias": "compareSelectionBy"; "required": false; "isSignal": true; }; "contextMenuSelection": { "alias": "contextMenuSelection"; "required": false; "isSignal": true; }; "contextMenuSelectionMode": { "alias": "contextMenuSelectionMode"; "required": false; "isSignal": true; }; "rowHover": { "alias": "rowHover"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "virtualScrollDelay": { "alias": "virtualScrollDelay"; "required": false; "isSignal": true; }; "resizableColumns": { "alias": "resizableColumns"; "required": false; "isSignal": true; }; "reorderableColumns": { "alias": "reorderableColumns"; "required": false; "isSignal": true; }; "columnResizeMode": { "alias": "columnResizeMode"; "required": false; "isSignal": true; }; "showGridlines": { "alias": "showGridlines"; "required": false; "isSignal": true; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; "isSignal": true; }; "filterDelay": { "alias": "filterDelay"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "paginatorLocale": { "alias": "paginatorLocale"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "first": "firstChange"; "filterValue": "filterValueChange"; "selected": "selectedChange"; "nodeSelect": "nodeSelect"; "nodeUnselect": "nodeUnselect"; "nodeExpand": "nodeExpand"; "nodeCollapse": "nodeCollapse"; "onNodeSelect": "onNodeSelect"; "onNodeUnselect": "onNodeUnselect"; "selectionChange": "selectionChange"; "contextMenuSelectionChange": "contextMenuSelectionChange"; "onContextMenuSelect": "onContextMenuSelect"; "rowExpand": "rowExpand"; "rowCollapse": "rowCollapse"; "onFilter": "onFilter"; "onPage": "onPage"; "onSort": "onSort"; "onLazyLoad": "onLazyLoad"; "onHeaderCheckboxToggle": "onHeaderCheckboxToggle"; "onColResize": "onColResize"; "onColReorder": "onColReorder"; }, never, never, true, never>;
}

type ChartType = 'bar' | 'line' | 'doughnut';
interface ChartDataset {
    label?: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string;
}
interface ChartData {
    labels: string[];
    datasets: ChartDataset[];
}
interface EditorAction {
    command: string;
    icon?: string;
    label?: string;
}
declare class ChartComponent {
    readonly type: _angular_core.InputSignal<ChartType | "scatter" | "bubble" | "pie" | "polarArea" | "radar">;
    readonly data: _angular_core.InputSignal<ChartData>;
    readonly plugins: _angular_core.InputSignal<any[]>;
    readonly width: _angular_core.InputSignal<string | undefined>;
    readonly height: _angular_core.InputSignal<string>;
    readonly responsive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly pointClick: _angular_core.OutputEmitterRef<number>;
    readonly onDataSelect: _angular_core.OutputEmitterRef<{
        index: number;
        originalEvent?: Event;
    }>;
    readonly chartSvg: _angular_core.Signal<ElementRef<SVGSVGElement> | undefined>;
    readonly renderVersion: _angular_core.WritableSignal<number>;
    refresh(): void;
    reinit(): void;
    getBase64Image(): string | undefined;
    generateLegend(): string;
    selectPoint(index: number, event?: Event): void;
    private color;
    private maxValue;
    bars(): Array<{
        x: number;
        y: number;
        width: number;
        height: number;
        color: string;
        index: number;
    }>;
    lines(): Array<{
        points: string;
        color: string;
        pointList: Array<{
            x: number;
            y: number;
            index: number;
        }>;
    }>;
    doughnutSlices(): Array<{
        path: string;
        color: string;
        index: number;
    }>;
    legend(): Array<{
        label: string;
        color: string;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChartComponent, "orc-chart", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "plugins": { "alias": "plugins"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, { "pointClick": "pointClick"; "onDataSelect": "onDataSelect"; }, never, never, true, never>;
}
declare class EditorComponent implements ControlValueAccessor, AfterViewInit {
    readonly value: _angular_core.ModelSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly formats: _angular_core.InputSignal<string[] | undefined>;
    readonly modules: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly bounds: _angular_core.InputSignal<string | HTMLElement | undefined>;
    readonly scrollingContainer: _angular_core.InputSignal<string | HTMLElement | undefined>;
    readonly debug: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly actions: _angular_core.InputSignal<EditorAction[]>;
    readonly blur: _angular_core.OutputEmitterRef<string>;
    readonly onInit: _angular_core.OutputEmitterRef<unknown>;
    readonly onTextChange: _angular_core.OutputEmitterRef<{
        html: string;
        text: string;
        delta?: unknown;
        source?: string;
        editor?: unknown;
    }>;
    readonly onSelectionChange: _angular_core.OutputEmitterRef<{
        range: {
            index: number;
            length: number;
        } | null;
        oldRange?: {
            index: number;
            length: number;
        } | null;
        source?: string;
    }>;
    readonly editorSurface: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    private onModelChange;
    private onModelTouched;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    onInput(event: Event): void;
    handleBlur(): void;
    exec(command: string): void;
    emitSelectionChange(_event: Event): void;
    ngAfterViewInit(): void;
    getQuill(): {
        root: HTMLElement;
        getText: () => string;
        getHTML: () => string;
        getLength: () => number;
        format: (name: string, value: unknown) => void;
        insertText: (index: number, text: string) => void;
        getSelection: () => {
            index: number;
            length: number;
        } | null;
        setSelection: (index: number, length?: number) => void;
    } | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EditorComponent, "orc-editor", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "formats": { "alias": "formats"; "required": false; "isSignal": true; }; "modules": { "alias": "modules"; "required": false; "isSignal": true; }; "bounds": { "alias": "bounds"; "required": false; "isSignal": true; }; "scrollingContainer": { "alias": "scrollingContainer"; "required": false; "isSignal": true; }; "debug": { "alias": "debug"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "blur": "blur"; "onInit": "onInit"; "onTextChange": "onTextChange"; "onSelectionChange": "onSelectionChange"; }, never, never, true, never>;
}

declare class OrderListComponent<T = unknown> implements ControlValueAccessor {
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly header: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly moveUpLabel: _angular_core.InputSignal<string | undefined>;
    readonly moveDownLabel: _angular_core.InputSignal<string | undefined>;
    readonly listStyle: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filter: _angular_core.ModelSignal<string>;
    readonly dragdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly selectedIndex: _angular_core.ModelSignal<number>;
    readonly selected: _angular_core.ModelSignal<T | T[] | null>;
    readonly valueChangeEvent: _angular_core.OutputEmitterRef<T[]>;
    readonly reorder: _angular_core.OutputEmitterRef<{
        value: T[];
        direction: "up" | "down";
    }>;
    readonly onReorder: _angular_core.OutputEmitterRef<{
        value: T[];
        direction: "up" | "down";
    }>;
    readonly onFilterEvent: _angular_core.OutputEmitterRef<{
        filter: string;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    private onModelChange;
    private onModelTouched;
    readonly filteredValue: _angular_core.Signal<T[]>;
    readonly selectedItems: _angular_core.Signal<Set<T>>;
    itemLabel(item: T): string;
    canMove(delta: number): boolean;
    selection(): T | T[] | null;
    select(index: number): void;
    setFilter(value: string): void;
    move(delta: number): void;
    writeValue(value: T[] | null): void;
    registerOnChange(fn: (value: T[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrderListComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OrderListComponent<any>, "orc-order-list", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "moveUpLabel": { "alias": "moveUpLabel"; "required": false; "isSignal": true; }; "moveDownLabel": { "alias": "moveDownLabel"; "required": false; "isSignal": true; }; "listStyle": { "alias": "listStyle"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "dragdrop": { "alias": "dragdrop"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; "isSignal": true; }; "selected": { "alias": "selection"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "filter": "filterChange"; "selectedIndex": "selectedIndexChange"; "selected": "selectionChange"; "valueChangeEvent": "valueChangeEvent"; "reorder": "reorder"; "onReorder": "onReorder"; "onFilterEvent": "onFilterEvent"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class PickListComponent<T extends P2Option = P2Option> implements OnDestroy {
    private readonly host;
    readonly source: _angular_core.ModelSignal<T[]>;
    readonly target: _angular_core.ModelSignal<T[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly sourceHeader: _angular_core.InputSignal<string | undefined>;
    readonly targetHeader: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly responsive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    readonly filterMatchMode: _angular_core.InputSignal<string>;
    readonly sourceFilter: _angular_core.ModelSignal<string>;
    readonly targetFilter: _angular_core.ModelSignal<string>;
    readonly sourceFilterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly targetFilterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly ariaSourceFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaTargetFilterLabel: _angular_core.InputSignal<string | undefined>;
    readonly moveToTargetLabel: _angular_core.InputSignal<string>;
    readonly moveToSourceLabel: _angular_core.InputSignal<string>;
    readonly moveAllToTargetLabel: _angular_core.InputSignal<string>;
    readonly moveAllToSourceLabel: _angular_core.InputSignal<string>;
    readonly sourceStyle: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly targetStyle: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly dragdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stripedRows: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly breakpoint: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly sourceSelected: _angular_core.ModelSignal<ReadonlySet<T["value"]>>;
    readonly targetSelected: _angular_core.ModelSignal<ReadonlySet<T["value"]>>;
    readonly transfer: _angular_core.OutputEmitterRef<{
        source: T[];
        target: T[];
    }>;
    readonly selectionChange: _angular_core.OutputEmitterRef<{
        source: ReadonlySet<T["value"]>;
        target: ReadonlySet<T["value"]>;
    }>;
    readonly onMoveToTarget: _angular_core.OutputEmitterRef<{
        items: T[];
        source: T[];
        target: T[];
    }>;
    readonly onMoveToSource: _angular_core.OutputEmitterRef<{
        items: T[];
        source: T[];
        target: T[];
    }>;
    readonly onMoveAllToTarget: _angular_core.OutputEmitterRef<{
        items: T[];
        source: T[];
        target: T[];
    }>;
    readonly onMoveAllToSource: _angular_core.OutputEmitterRef<{
        items: T[];
        source: T[];
        target: T[];
    }>;
    readonly onSourceReorder: _angular_core.OutputEmitterRef<{
        value: T[];
    }>;
    readonly onTargetReorder: _angular_core.OutputEmitterRef<{
        value: T[];
    }>;
    readonly filteredSource: _angular_core.Signal<T[]>;
    readonly filteredTarget: _angular_core.Signal<T[]>;
    private readonly sourceFocus;
    private readonly targetFocus;
    private readonly sourceFocusItem;
    private readonly targetFocusItem;
    private focusRequest;
    private focusedPane;
    private ownedFocusElement;
    private destroyed;
    constructor();
    sourceFocusValue(): T['value'] | null;
    targetFocusValue(): T['value'] | null;
    private filterItems;
    private recoverFocus;
    private pruneSelection;
    private sameValues;
    private pruneValues;
    private currentItem;
    toggleSource(item: T): void;
    toggleTarget(item: T): void;
    private toggleValue;
    onSourceKeydown(event: KeyboardEvent, item: T): void;
    onTargetKeydown(event: KeyboardEvent, item: T): void;
    private onOptionKeydown;
    onOptionFocus(event: FocusEvent, item: T, source: boolean): void;
    onOptionBlur(event: FocusEvent): void;
    private focusOption;
    private scheduleFocusRecovery;
    private clearFocusOwnership;
    ngOnDestroy(): void;
    canTransferSelectedToTarget(): boolean;
    canTransferSelectedToSource(): boolean;
    canTransferAllToTarget(): boolean;
    canTransferAllToSource(): boolean;
    transferSelected(): void;
    transferBack(): void;
    transferAllToTarget(): void;
    transferAllToSource(): void;
    private emitSelectionChange;
    private emitTransfer;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PickListComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PickListComponent<any>, "orc-pick-list", never, { "source": { "alias": "source"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "sourceHeader": { "alias": "sourceHeader"; "required": false; "isSignal": true; }; "targetHeader": { "alias": "targetHeader"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "sourceFilter": { "alias": "sourceFilter"; "required": false; "isSignal": true; }; "targetFilter": { "alias": "targetFilter"; "required": false; "isSignal": true; }; "sourceFilterPlaceholder": { "alias": "sourceFilterPlaceholder"; "required": false; "isSignal": true; }; "targetFilterPlaceholder": { "alias": "targetFilterPlaceholder"; "required": false; "isSignal": true; }; "ariaSourceFilterLabel": { "alias": "ariaSourceFilterLabel"; "required": false; "isSignal": true; }; "ariaTargetFilterLabel": { "alias": "ariaTargetFilterLabel"; "required": false; "isSignal": true; }; "moveToTargetLabel": { "alias": "moveToTargetLabel"; "required": false; "isSignal": true; }; "moveToSourceLabel": { "alias": "moveToSourceLabel"; "required": false; "isSignal": true; }; "moveAllToTargetLabel": { "alias": "moveAllToTargetLabel"; "required": false; "isSignal": true; }; "moveAllToSourceLabel": { "alias": "moveAllToSourceLabel"; "required": false; "isSignal": true; }; "sourceStyle": { "alias": "sourceStyle"; "required": false; "isSignal": true; }; "targetStyle": { "alias": "targetStyle"; "required": false; "isSignal": true; }; "dragdrop": { "alias": "dragdrop"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "sourceSelected": { "alias": "sourceSelected"; "required": false; "isSignal": true; }; "targetSelected": { "alias": "targetSelected"; "required": false; "isSignal": true; }; }, { "source": "sourceChange"; "target": "targetChange"; "sourceFilter": "sourceFilterChange"; "targetFilter": "targetFilterChange"; "sourceSelected": "sourceSelectedChange"; "targetSelected": "targetSelectedChange"; "transfer": "transfer"; "selectionChange": "selectionChange"; "onMoveToTarget": "onMoveToTarget"; "onMoveToSource": "onMoveToSource"; "onMoveAllToTarget": "onMoveAllToTarget"; "onMoveAllToSource": "onMoveAllToSource"; "onSourceReorder": "onSourceReorder"; "onTargetReorder": "onTargetReorder"; }, never, never, true, never>;
}
interface GalleryImage {
    src: string;
    alt?: string;
    thumbnail?: string;
    title?: string;
}
declare class GalleriaComponent implements OnDestroy {
    readonly images: _angular_core.InputSignal<GalleryImage[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly roleDescription: _angular_core.InputSignal<string | undefined>;
    readonly closeLabel: _angular_core.InputSignal<string | undefined>;
    readonly previousLabel: _angular_core.InputSignal<string | undefined>;
    readonly nextLabel: _angular_core.InputSignal<string | undefined>;
    readonly thumbnailLabel: _angular_core.InputSignal<string | undefined>;
    readonly activeIndex: _angular_core.ModelSignal<number>;
    readonly fullScreen: _angular_core.ModelSignal<boolean>;
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly numVisible: _angular_core.InputSignal<number>;
    readonly responsiveOptions: _angular_core.InputSignal<unknown[] | undefined>;
    readonly showItemNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showThumbnailNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showItemNavigatorsOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly changeItemOnIndicatorHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly shouldStopAutoplayByClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoPlay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly transitionInterval: _angular_core.InputSignal<number>;
    readonly showThumbnails: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly thumbnailsPosition: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showIndicatorsOnItem: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly indicatorsPosition: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly maskClass: _angular_core.InputSignal<string>;
    readonly containerClass: _angular_core.InputSignal<string>;
    readonly containerStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    readonly imageChange: _angular_core.OutputEmitterRef<{
        index: number;
        image: GalleryImage;
    }>;
    readonly canPrevious: _angular_core.Signal<boolean>;
    readonly canNext: _angular_core.Signal<boolean>;
    private slideshowTimer;
    readonly hovered: _angular_core.WritableSignal<boolean>;
    readonly showNavigators: _angular_core.Signal<boolean>;
    constructor();
    startSlideShow(): void;
    stopSlideShow(): void;
    restartSlideShow(): void;
    ngOnDestroy(): void;
    show(): void;
    hide(): void;
    toggle(): void;
    goTo(index: number): void;
    previous(): void;
    next(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GalleriaComponent, "orc-galleria, orc-gallery", never, { "images": { "alias": "images"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "roleDescription": { "alias": "roleDescription"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "thumbnailLabel": { "alias": "thumbnailLabel"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "fullScreen": { "alias": "fullScreen"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; "isSignal": true; }; "showItemNavigators": { "alias": "showItemNavigators"; "required": false; "isSignal": true; }; "showThumbnailNavigators": { "alias": "showThumbnailNavigators"; "required": false; "isSignal": true; }; "showItemNavigatorsOnHover": { "alias": "showItemNavigatorsOnHover"; "required": false; "isSignal": true; }; "changeItemOnIndicatorHover": { "alias": "changeItemOnIndicatorHover"; "required": false; "isSignal": true; }; "shouldStopAutoplayByClick": { "alias": "shouldStopAutoplayByClick"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "autoPlay": { "alias": "autoPlay"; "required": false; "isSignal": true; }; "transitionInterval": { "alias": "transitionInterval"; "required": false; "isSignal": true; }; "showThumbnails": { "alias": "showThumbnails"; "required": false; "isSignal": true; }; "thumbnailsPosition": { "alias": "thumbnailsPosition"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "showIndicatorsOnItem": { "alias": "showIndicatorsOnItem"; "required": false; "isSignal": true; }; "indicatorsPosition": { "alias": "indicatorsPosition"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "maskClass": { "alias": "maskClass"; "required": false; "isSignal": true; }; "containerClass": { "alias": "containerClass"; "required": false; "isSignal": true; }; "containerStyle": { "alias": "containerStyle"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; }, { "activeIndex": "activeIndexChange"; "fullScreen": "fullScreenChange"; "visible": "visibleChange"; "imageChange": "imageChange"; }, never, never, true, never>;
}

declare class SelectButtonComponent<T = unknown> implements ControlValueAccessor {
    readonly options: _angular_core.InputSignal<any[]>;
    readonly value: _angular_core.ModelSignal<T | T[] | null>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    readonly unselectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly valueChangeEvent: _angular_core.OutputEmitterRef<T | T[] | null>;
    readonly onOptionClick: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        option: any;
        index: number;
    }>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        value: T | T[] | null;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<void>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    writeValue(value: T | T[] | null): void;
    registerOnChange(fn: (value: T | T[] | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    getOptionValue(option: any): any;
    getOptionLabel(option: any): string;
    isOptionDisabled(option: any): boolean;
    isSelected(option: any): boolean;
    private sameValue;
    select(option: any, event?: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButtonComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectButtonComponent<any>, "orc-select-button", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "unselectable": { "alias": "unselectable"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChangeEvent": "valueChangeEvent"; "onOptionClick": "onOptionClick"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class ToggleButtonComponent implements ControlValueAccessor {
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly onLabel: _angular_core.InputSignal<string | undefined>;
    readonly offLabel: _angular_core.InputSignal<string | undefined>;
    readonly onIcon: _angular_core.InputSignal<string>;
    readonly offIcon: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly style: _angular_core.InputSignal<Record<string, any> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly change: _angular_core.OutputEmitterRef<boolean>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        checked: boolean;
    }>;
    readonly onBlur: _angular_core.OutputEmitterRef<void>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    protected onModelTouched: () => void;
    writeValue(value: boolean | null): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    toggle(event?: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToggleButtonComponent, "orc-toggle-button", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "onLabel": { "alias": "onLabel"; "required": false; "isSignal": true; }; "offLabel": { "alias": "offLabel"; "required": false; "isSignal": true; }; "onIcon": { "alias": "onIcon"; "required": false; "isSignal": true; }; "offIcon": { "alias": "offIcon"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "change": "change"; "onChange": "onChange"; "onBlur": "onBlur"; }, never, ["*"], true, never>;
}
interface CascadeOption extends P2Option<string> {
    children?: CascadeOption[];
}
declare class CascadeSelectComponent implements ControlValueAccessor {
    readonly options: _angular_core.InputSignal<CascadeOption[]>;
    readonly value: _angular_core.ModelSignal<string | null>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly selected: _angular_core.WritableSignal<CascadeOption[]>;
    readonly optionSelect: _angular_core.OutputEmitterRef<CascadeOption>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    private onModelChange;
    private onModelTouched;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly panelStyleClass: _angular_core.InputSignal<string>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterValue: _angular_core.ModelSignal<string>;
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly filterAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        value: string | null;
    }>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onClear: _angular_core.OutputEmitterRef<void>;
    readonly levels: _angular_core.Signal<CascadeOption[][]>;
    selectedLabel(): string;
    getOptionLabel(option: CascadeOption): string;
    choose(option: CascadeOption, level: number): void;
    getOptionValue(option: CascadeOption): string;
    isOptionDisabled(option: CascadeOption): boolean;
    toggle(): void;
    clear(): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    private findPath;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadeSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CascadeSelectComponent, "orc-cascade-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "open": "openChange"; "optionSelect": "optionSelect"; "filterValue": "filterValueChange"; "onChange": "onChange"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; }, never, never, true, never>;
}
declare class KeyFilterDirective {
    readonly pattern: _angular_core.InputSignal<string | RegExp>;
    readonly validateOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ngModelChange: _angular_core.OutputEmitterRef<string | number>;
    private matches;
    onKeydown(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    onInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KeyFilterDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<KeyFilterDirective, "[orcKeyFilter],[pKeyFilter]", never, { "pattern": { "alias": "pattern"; "required": false; "isSignal": true; }; "validateOnly": { "alias": "pValidateOnly"; "required": false; "isSignal": true; }; }, { "ngModelChange": "ngModelChange"; }, never, never, true, never>;
}
declare class InputMaskDirective implements ControlValueAccessor {
    private readonly host;
    readonly mask: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<string>;
    readonly slotChar: _angular_core.InputSignal<string>;
    readonly autoClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly unmask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly characterPattern: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly maxlength: _angular_core.InputSignal<number | undefined>;
    readonly tabindex: _angular_core.InputSignal<string | number | undefined>;
    readonly title: _angular_core.InputSignal<string | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaRequired: _angular_core.InputSignal<boolean | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autocomplete: _angular_core.InputSignal<string | undefined>;
    readonly keepBuffer: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly onComplete: _angular_core.OutputEmitterRef<string>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly onInput: _angular_core.OutputEmitterRef<Event>;
    readonly onKeydown: _angular_core.OutputEmitterRef<Event>;
    readonly onClear: _angular_core.OutputEmitterRef<void>;
    private onModelChange;
    private onModelTouched;
    private cvaDisabled;
    constructor(host: ElementRef<HTMLInputElement>);
    writeValue(value: unknown): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    private accepts;
    private format;
    handleInput(event: Event): void;
    handleFocus(event: Event): void;
    handleBlur(event: Event): void;
    handleKeydown(event: KeyboardEvent): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputMaskDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<InputMaskDirective, "[orcInputMask],[pInputMask]", never, { "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "slotChar": { "alias": "slotChar"; "required": false; "isSignal": true; }; "autoClear": { "alias": "autoClear"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "unmask": { "alias": "unmask"; "required": false; "isSignal": true; }; "characterPattern": { "alias": "characterPattern"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaRequired": { "alias": "ariaRequired"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "keepBuffer": { "alias": "keepBuffer"; "required": false; "isSignal": true; }; }, { "onComplete": "onComplete"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onInput": "onInput"; "onKeydown": "onKeydown"; "onClear": "onClear"; }, never, never, true, never>;
}

interface OrganizationNode {
    key: string;
    label: string;
    subtitle?: string;
    image?: string;
    children?: OrganizationNode[];
    disabled?: boolean;
}
interface FlatOrganizationNode {
    node: OrganizationNode;
    level: number;
    last: boolean;
}
declare class OrganizationChartComponent {
    readonly value: _angular_core.InputSignal<OrganizationNode[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly toggleChildrenLabel: _angular_core.InputSignal<string | undefined>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple">;
    readonly collapsible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selected: _angular_core.ModelSignal<string | string[] | null>;
    readonly expanded: _angular_core.ModelSignal<ReadonlySet<string>>;
    readonly nodeSelect: _angular_core.OutputEmitterRef<OrganizationNode>;
    readonly nodeUnselect: _angular_core.OutputEmitterRef<OrganizationNode>;
    readonly nodeExpand: _angular_core.OutputEmitterRef<OrganizationNode>;
    readonly nodeCollapse: _angular_core.OutputEmitterRef<OrganizationNode>;
    readonly selectionChange: _angular_core.OutputEmitterRef<string | string[] | null>;
    readonly flatNodes: _angular_core.Signal<FlatOrganizationNode[]>;
    isSelected(key: string): boolean;
    toggle(node: OrganizationNode): void;
    select(node: OrganizationNode): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrganizationChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OrganizationChartComponent, "orc-organization-chart", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "toggleChildrenLabel": { "alias": "toggleChildrenLabel"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "expanded": "expandedChange"; "nodeSelect": "nodeSelect"; "nodeUnselect": "nodeUnselect"; "nodeExpand": "nodeExpand"; "nodeCollapse": "nodeCollapse"; "selectionChange": "selectionChange"; }, never, never, true, never>;
}
declare class KnobComponent implements ControlValueAccessor {
    readonly value: _angular_core.ModelSignal<number>;
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly step: _angular_core.InputSignal<number>;
    readonly suffix: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<number | undefined>;
    readonly strokeWidth: _angular_core.InputSignal<number>;
    readonly valueColor: _angular_core.InputSignal<string>;
    readonly rangeColor: _angular_core.InputSignal<string>;
    readonly valueTemplate: _angular_core.InputSignal<string | undefined>;
    readonly valueChangeEvent: _angular_core.OutputEmitterRef<number>;
    readonly onChange: _angular_core.OutputEmitterRef<number>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    protected cvaDisabled: boolean;
    private onModelChange;
    protected onModelTouched: () => void;
    readonly circumference: number;
    readonly dashOffset: _angular_core.Signal<number>;
    writeValue(value: number | null): void;
    registerOnChange(fn: (value: number) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    private normalizeValue;
    onInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KnobComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<KnobComponent, "orc-knob", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "valueColor": { "alias": "valueColor"; "required": false; "isSignal": true; }; "rangeColor": { "alias": "rangeColor"; "required": false; "isSignal": true; }; "valueTemplate": { "alias": "valueTemplate"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChangeEvent": "valueChangeEvent"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, never>;
}

declare class RippleDirective implements OnDestroy {
    private readonly host;
    private readonly renderer;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly color: _angular_core.InputSignal<string>;
    private readonly timers;
    constructor(host: ElementRef<HTMLElement>, renderer: Renderer2);
    onClick(event: MouseEvent): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RippleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RippleDirective, "[orcRipple]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class StyleClassDirective {
    private readonly host;
    private readonly renderer;
    readonly targetClass: _angular_core.InputSignal<string>;
    readonly toggleClass: _angular_core.InputSignal<string>;
    readonly enterClass: _angular_core.InputSignal<string>;
    readonly leaveClass: _angular_core.InputSignal<string>;
    readonly hideOnOutsideClick: _angular_core.InputSignal<boolean>;
    private open;
    constructor(host: ElementRef<HTMLElement>, renderer: Renderer2);
    onClick(): void;
    onDocumentClick(event: MouseEvent): void;
    toggle(force?: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StyleClassDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<StyleClassDirective, "[orcStyleClass]", never, { "targetClass": { "alias": "targetClass"; "required": false; "isSignal": true; }; "toggleClass": { "alias": "toggleClass"; "required": false; "isSignal": true; }; "enterClass": { "alias": "enterClass"; "required": false; "isSignal": true; }; "leaveClass": { "alias": "leaveClass"; "required": false; "isSignal": true; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class InputColorComponent {
    readonly value: _angular_core.ModelSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly valueChangeEvent: _angular_core.OutputEmitterRef<string>;
    onInput(event: Event): void;
    onTextInput(event: Event): void;
    private update;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputColorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputColorComponent, "orc-input-color", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChangeEvent": "valueChangeEvent"; }, never, never, true, never>;
}
declare class AutoFocusDirective implements AfterViewInit, OnDestroy {
    private readonly element;
    readonly disabled: _angular_core.InputSignal<boolean>;
    private destroyed;
    constructor(element: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onEscape(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutoFocusDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AutoFocusDirective, "[orcAutoFocus]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface DockItem extends P2Option<string> {
    command?: () => void;
}
declare class DockComponent {
    readonly items: _angular_core.InputSignal<DockItem[]>;
    readonly position: _angular_core.InputSignal<"top" | "bottom">;
    readonly label: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DockComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DockComponent, "orc-dock", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class ScrollPanelComponent {
    readonly panel: _angular_core.Signal<ElementRef<HTMLDivElement> | undefined>;
    readonly height: _angular_core.InputSignal<string>;
    readonly maxHeight: _angular_core.InputSignal<string>;
    readonly step: _angular_core.InputSignal<number>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly contentId: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    scrollTop(value: number): void;
    onKeydown(event: KeyboardEvent): void;
    refresh(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ScrollPanelComponent, "orc-scroll-panel", never, { "height": { "alias": "height"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "contentId": { "alias": "contentId"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface CommandItem {
    label: string;
    shortcut?: string;
    icon?: string;
    keywords?: string[];
    disabled?: boolean;
    command?: () => void;
}
declare class CommandMenuComponent {
    readonly items: _angular_core.InputSignal<CommandItem[]>;
    readonly query: _angular_core.ModelSignal<string>;
    readonly activeIndex: _angular_core.ModelSignal<number>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly searchAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly emptyText: _angular_core.InputSignal<string | undefined>;
    readonly itemSelect: _angular_core.OutputEmitterRef<CommandItem>;
    filteredItems(): CommandItem[];
    keydown(event: KeyboardEvent): void;
    activate(item: CommandItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CommandMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CommandMenuComponent, "orc-command-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "query": { "alias": "query"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "searchAriaLabel": { "alias": "searchAriaLabel"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; }, { "query": "queryChange"; "activeIndex": "activeIndexChange"; "itemSelect": "itemSelect"; }, never, never, true, never>;
}

declare class AnimateOnScrollDirective implements AfterViewInit, OnDestroy {
    private readonly element;
    private readonly renderer;
    readonly animationClass: _angular_core.InputSignal<string>;
    readonly once: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly threshold: _angular_core.InputSignal<number>;
    readonly visible: _angular_core.OutputEmitterRef<IntersectionObserverEntry>;
    private observer;
    constructor(element: ElementRef<HTMLElement>, renderer: Renderer2);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnimateOnScrollDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AnimateOnScrollDirective, "[orcAnimateOnScroll]", never, { "animationClass": { "alias": "animationClass"; "required": false; "isSignal": true; }; "once": { "alias": "once"; "required": false; "isSignal": true; }; "threshold": { "alias": "threshold"; "required": false; "isSignal": true; }; }, { "visible": "visible"; }, never, never, true, never>;
}
declare class FocusTrapDirective implements AfterViewInit {
    private readonly element;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor(element: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    private focusables;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FocusTrapDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FocusTrapDirective, "[orcFocusTrap]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "autoFocus": { "alias": "autoFocus"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class UseStyleDirective {
    private readonly element;
    private readonly renderer;
    readonly styles: _angular_core.InputSignal<Record<string, string | number>>;
    constructor(element: ElementRef<HTMLElement>, renderer: Renderer2);
    private applied;
    ngOnChanges(): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UseStyleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UseStyleDirective, "[orcUseStyle]", never, { "styles": { "alias": "styles"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface PopupConfirmation {
    message: string;
    header?: string;
    acceptLabel?: string;
    rejectLabel?: string;
    acceptAriaLabel?: string;
    rejectAriaLabel?: string;
    accept?: () => void;
    reject?: () => void;
    x?: number;
    y?: number;
}
declare class ConfirmPopupService {
    readonly request: _angular_core.WritableSignal<PopupConfirmation | null>;
    confirm(request: PopupConfirmation): void;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmPopupService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfirmPopupService>;
}
declare class ConfirmPopupComponent {
    private readonly service;
    readonly request: ConfirmPopupService['request'];
    readonly acceptButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    readonly rejectButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    constructor(service: ConfirmPopupService);
    acceptLabel(): string;
    rejectLabel(): string;
    accept(): void;
    reject(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmPopupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmPopupComponent, "orc-confirm-popup", never, {}, {}, never, never, true, never>;
}

export { AnimateOnScrollDirective, AspectRatioComponent, AutoFocusDirective, BlockUiComponent, BoxComponent, ButtonGroupComponent, CalendarComponent, CascadeSelectComponent, ChartComponent, CloseButtonComponent, CodeComponent, ComboboxComponent, CommandMenuComponent, ConfirmDialogComponent, ConfirmPopupComponent, ConfirmPopupService, ConfirmationService, ContainerComponent, ContextMenuComponent, DataTableComponent, DataViewComponent, DateInputComponent, DockComponent, EditorComponent, FieldsetComponent, FlexComponent, FloatLabelComponent, FloatingActionButtonComponent, FluidComponent, FocusTrapDirective, GalleriaComponent, GridComponent, HoverCardComponent, IconFieldComponent, IftaLabelComponent, ImageCompareComponent, InplaceComponent, InputColorComponent, InputGroupAddonComponent, InputGroupComponent, InputMaskDirective, KbdComponent, KeyFilterDirective, KnobComponent, LinkComponent, ListboxComponent, MegaMenuComponent, MenuComponent, MenubarComponent, MessagesComponent, MeterGroupComponent, MultiSelectComponent, OrderListComponent, OrganizationChartComponent, OverlayBadgeComponent, OverlayComponent, P2_SHARED_STYLES, PanelComponent, PanelMenuComponent, PasswordComponent, PickListComponent, PortalComponent, RippleDirective, ScrollPanelComponent, ScrollTopComponent, SelectButtonComponent, SeparatorComponent, SpaceComponent, SpeedDialComponent, SplitButtonComponent, SplitterComponent, SplitterPanelContentDirective, StackComponent, StyleClassDirective, TagsInputComponent, TerminalComponent, TextComponent, TieredMenuComponent, ToggleButtonComponent, TreeComponent, TreeSelectComponent, TreeTableComponent, TypographyComponent, UseStyleDirective, VirtualScrollerComponent, VisuallyHiddenComponent };
export type { CalendarDay, CascadeOption, ChartData, ChartDataset, ChartType, CommandItem, ConfirmationRequest, ContextMenuItem, DataTableColumn, DockItem, EditorAction, GalleryImage, HierarchyNode, MenubarItem, MeterItem, OrganizationNode, P2Message, P2Option, P2Orientation, P2Size, PopupConfirmation, PrimeMenuItem, SpeedDialAction, SplitterPanel, TerminalLine, TreeSelectNode, TreeTableColumn };
