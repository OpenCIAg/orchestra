import * as _angular_core from '@angular/core';
import { TemplateRef, AfterViewInit, OnDestroy, ElementRef } from '@angular/core';

type TabVariant = 'line' | 'filled';
type TabSize = 'sm' | 'md' | 'lg';
type TabIconPosition = 'start' | 'end';
interface TabChangeEvent {
    index: number;
    tab: any;
}

declare class TabComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly iconPosition: _angular_core.InputSignal<TabIconPosition>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly cache: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tooltip: _angular_core.InputSignal<string | undefined>;
    readonly tooltipPosition: _angular_core.InputSignal<"top" | "bottom" | "left" | "right">;
    readonly headerStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly headerStyleClass: _angular_core.InputSignal<string>;
    readonly selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly badge: _angular_core.InputSignal<string | number | undefined>;
    readonly id: _angular_core.InputSignal<string>;
    readonly contentTemplate: _angular_core.Signal<TemplateRef<unknown> | undefined>;
    readonly customLabelTemplate: _angular_core.Signal<TemplateRef<unknown> | undefined>;
    private readonly fallbackId;
    readonly tabId: _angular_core.Signal<string>;
    readonly panelId: _angular_core.Signal<string>;
    readonly closed: _angular_core.ModelSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabComponent, "orc-tab", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "cache": { "alias": "cache"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "headerStyle": { "alias": "headerStyle"; "required": false; "isSignal": true; }; "headerStyleClass": { "alias": "headerStyleClass"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "closed": { "alias": "closed"; "required": false; "isSignal": true; }; }, { "closed": "closedChange"; }, never, ["*", "[tab-label], [tabLabel]"], true, never>;
}

declare class TabGroupComponent implements AfterViewInit, OnDestroy {
    private readonly host;
    readonly selectedIndex: _angular_core.ModelSignal<number>;
    readonly value: _angular_core.ModelSignal<string | number | undefined>;
    readonly variant: _angular_core.InputSignal<TabVariant>;
    readonly size: _angular_core.InputSignal<TabSize>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly controlClose: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly nextButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly prevButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly autoHideButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly tabChange: _angular_core.OutputEmitterRef<TabChangeEvent>;
    readonly onChange: _angular_core.OutputEmitterRef<TabChangeEvent>;
    readonly tabFocus: _angular_core.OutputEmitterRef<{
        index: number;
        tab: TabComponent;
    }>;
    readonly onClose: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        index: number;
        tab: TabComponent;
    }>;
    readonly tabs: _angular_core.Signal<readonly TabComponent[]>;
    readonly visibleTabs: _angular_core.Signal<TabComponent[]>;
    readonly loadedTabs: Set<TabComponent>;
    private readonly selectionIntent;
    private lastSelectedIndex;
    private lastValue;
    private initialized;
    readonly focusedIndex: _angular_core.WritableSignal<number | undefined>;
    readonly tabButtons: _angular_core.Signal<readonly ElementRef<HTMLButtonElement>[]>;
    readonly tabHeader: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly navigation: _angular_core.WritableSignal<{
        previous: boolean;
        next: boolean;
    }>;
    private resizeObserver?;
    private mutationObserver?;
    private readonly observedTabItems;
    private rtlScrollMode?;
    private focusRequest;
    private destroyed;
    readonly activeIndex: _angular_core.Signal<number>;
    constructor();
    private boundIndex;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    updateNavigation(): void;
    scrollTabs(direction: 'previous' | 'next'): void;
    isRtl(): boolean;
    private maxScroll;
    private logicalScrollLeft;
    private observeTabItems;
    private nearestEnabledIndex;
    selectTab(index: number): void;
    onKeydown(event: KeyboardEvent, currentIndex: number): void;
    onFocus(index: number): void;
    private focusTab;
    closeTab(index: number, event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabGroupComponent, "orc-tab-group", never, { "selectedIndex": { "alias": "selectedIndex"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "controlClose": { "alias": "controlClose"; "required": false; "isSignal": true; }; "showNavigators": { "alias": "showNavigators"; "required": false; "isSignal": true; }; "nextButtonAriaLabel": { "alias": "nextButtonAriaLabel"; "required": false; "isSignal": true; }; "prevButtonAriaLabel": { "alias": "prevButtonAriaLabel"; "required": false; "isSignal": true; }; "autoHideButtons": { "alias": "autoHideButtons"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "selectedIndex": "selectedIndexChange"; "value": "valueChange"; "tabChange": "tabChange"; "onChange": "onChange"; "tabFocus": "tabFocus"; "onClose": "onClose"; }, ["tabs"], ["*"], true, never>;
}

export { TabComponent, TabGroupComponent };
export type { TabChangeEvent, TabIconPosition, TabSize, TabVariant };
