export { NumberInputComponent as InputNumber, NumberInputComponent as InputNumberComponent } from '@ciag/orchestra/number-input';
