export { DatePickerComponent as DatePicker, DatePickerComponent as DatepickerComponent } from '@ciag/orchestra/date-picker';
