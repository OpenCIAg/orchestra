import * as _angular_core from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class ChipInputComponent implements ControlValueAccessor {
    readonly id: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg">;
    readonly allowDuplicates: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly allowDuplicate: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly maxChips: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly max: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly separator: _angular_core.InputSignal<string | undefined>;
    readonly addOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly separatorKeyCodes: _angular_core.InputSignal<string[]>;
    readonly suggestions: _angular_core.InputSignal<string[]>;
    /** Optional localized announcements for assistive technology. */
    readonly addAnnouncement: _angular_core.InputSignal<((item: string) => string | undefined) | undefined>;
    readonly removeAnnouncement: _angular_core.InputSignal<((item: string) => string | undefined) | undefined>;
    readonly chipsChange: _angular_core.OutputEmitterRef<string[]>;
    readonly maxReached: _angular_core.OutputEmitterRef<void>;
    readonly value: _angular_core.WritableSignal<string[]>;
    readonly inputValue: _angular_core.WritableSignal<string>;
    readonly a11yMessage: _angular_core.WritableSignal<string>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly status: _angular_core.Signal<"error" | "default">;
    readonly effectiveSeparators: _angular_core.Signal<string[]>;
    readonly filteredSuggestions: _angular_core.Signal<string[]>;
    readonly isSuggestionsVisible: _angular_core.Signal<boolean>;
    private onChange;
    private onTouched;
    writeValue(val: string[]): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onInputChange(val: string | number): void;
    onKeydown(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    onBlur(): void;
    selectSuggestion(item: string): void;
    private addChip;
    removeChip(index: number): void;
    private updateFormAndEmit;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipInputComponent, "orc-chip-input", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "allowDuplicates": { "alias": "allowDuplicates"; "required": false; "isSignal": true; }; "allowDuplicate": { "alias": "allowDuplicate"; "required": false; "isSignal": true; }; "maxChips": { "alias": "maxChips"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "addOnBlur": { "alias": "addOnBlur"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "separatorKeyCodes": { "alias": "separatorKeyCodes"; "required": false; "isSignal": true; }; "suggestions": { "alias": "suggestions"; "required": false; "isSignal": true; }; "addAnnouncement": { "alias": "addAnnouncement"; "required": false; "isSignal": true; }; "removeAnnouncement": { "alias": "removeAnnouncement"; "required": false; "isSignal": true; }; }, { "chipsChange": "chipsChange"; "maxReached": "maxReached"; }, never, never, true, never>;
}

export { ChipInputComponent };
