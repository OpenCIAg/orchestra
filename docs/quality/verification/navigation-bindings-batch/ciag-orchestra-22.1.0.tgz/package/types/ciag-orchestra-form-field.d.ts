import * as _angular_core from '@angular/core';

declare class FormFieldComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormFieldComponent, "orc-form-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { FormFieldComponent };
