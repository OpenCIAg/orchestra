import * as _angular_core from '@angular/core';

declare class CollapsibleComponent {
    private readonly uniqueId;
    readonly id: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly summary: _angular_core.InputSignal<string>;
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly toggleChange: _angular_core.OutputEmitterRef<boolean>;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly triggerId: _angular_core.Signal<string>;
    readonly contentId: _angular_core.Signal<string>;
    toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CollapsibleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CollapsibleComponent, "orc-collapsible", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "summary": { "alias": "summary"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "toggleChange": "toggleChange"; }, never, ["*"], true, never>;
}

export { CollapsibleComponent };
