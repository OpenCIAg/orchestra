import * as _angular_core from '@angular/core';
import { OnDestroy } from '@angular/core';

type CarouselOrientation = 'horizontal' | 'vertical';
interface CarouselItem {
    id?: string | number;
    label: string;
    description?: string;
    image?: string;
    alt?: string;
    disabled?: boolean;
}

declare class CarouselComponent implements OnDestroy {
    private readonly carouselId;
    private autoplayTimer;
    readonly items: _angular_core.InputSignal<CarouselItem[]>;
    readonly value: _angular_core.InputSignal<CarouselItem[] | undefined>;
    readonly activeIndex: _angular_core.ModelSignal<number>;
    readonly page: _angular_core.ModelSignal<number>;
    readonly numVisible: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly numScroll: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly responsiveOptions: _angular_core.InputSignal<unknown[] | undefined>;
    readonly orientation: _angular_core.InputSignal<CarouselOrientation>;
    readonly loop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly circular: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly autoplay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoplayInterval: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly pauseOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly interval: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly showArrows: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showNavigators: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly previousLabel: _angular_core.InputSignal<string | undefined>;
    readonly nextLabel: _angular_core.InputSignal<string | undefined>;
    readonly indicatorsLabel: _angular_core.InputSignal<string | undefined>;
    readonly slideChange: _angular_core.OutputEmitterRef<{
        index: number;
        item: CarouselItem;
    }>;
    readonly onPage: _angular_core.OutputEmitterRef<{
        first: number;
        last: number;
        page: number;
        pageCount: number;
    }>;
    readonly onPlay: _angular_core.OutputEmitterRef<void>;
    readonly onPause: _angular_core.OutputEmitterRef<void>;
    readonly hovered: _angular_core.WritableSignal<boolean>;
    readonly effectiveItems: _angular_core.Signal<CarouselItem[]>;
    readonly effectiveCircular: _angular_core.Signal<boolean>;
    readonly effectiveInterval: _angular_core.Signal<number>;
    readonly effectiveShowNavigators: _angular_core.Signal<boolean>;
    readonly activeItem: _angular_core.Signal<CarouselItem>;
    readonly safeIndex: _angular_core.Signal<number>;
    readonly canGoPrevious: _angular_core.Signal<boolean>;
    readonly canGoNext: _angular_core.Signal<boolean>;
    readonly itemId: (index: number) => string;
    constructor();
    ngOnDestroy(): void;
    previous(): void;
    next(): void;
    goTo(index: number): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    trackItem(index: number, item: CarouselItem): string | number;
    onKeydown(event: KeyboardEvent): void;
    private findIndex;
    private stopAutoplay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CarouselComponent, "orc-carousel", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "numScroll": { "alias": "numScroll"; "required": false; "isSignal": true; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "loop": { "alias": "loop"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "autoplay": { "alias": "autoplay"; "required": false; "isSignal": true; }; "autoplayInterval": { "alias": "autoplayInterval"; "required": false; "isSignal": true; }; "pauseOnHover": { "alias": "pauseOnHover"; "required": false; "isSignal": true; }; "interval": { "alias": "interval"; "required": false; "isSignal": true; }; "showArrows": { "alias": "showArrows"; "required": false; "isSignal": true; }; "showNavigators": { "alias": "showNavigators"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "indicatorsLabel": { "alias": "indicatorsLabel"; "required": false; "isSignal": true; }; }, { "activeIndex": "activeIndexChange"; "page": "pageChange"; "slideChange": "slideChange"; "onPage": "onPage"; "onPlay": "onPlay"; "onPause": "onPause"; }, never, never, true, never>;
}

export { CarouselComponent };
export type { CarouselItem, CarouselOrientation };
