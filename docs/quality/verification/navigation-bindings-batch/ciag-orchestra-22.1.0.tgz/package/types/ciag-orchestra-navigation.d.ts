import * as _angular_core from '@angular/core';

interface NavigationItem {
    id: string;
    label: string;
    icon?: string;
    href?: string;
    disabled?: boolean;
    badge?: string | number;
    children?: NavigationItem[];
}

declare class NavigationShellComponent {
    readonly open: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rail: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationShellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationShellComponent, "orc-navigation-shell", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "rail": { "alias": "rail"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, ["[navigation-logo]", "*", "[navigation-footer]"], true, never>;
}
declare class NavigationItemComponent {
    readonly item: _angular_core.InputSignal<NavigationItem>;
    readonly active: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly activated: _angular_core.OutputEmitterRef<NavigationItem>;
    select(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationItemComponent, "orc-navigation-item", never, { "item": { "alias": "item"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; }, { "activated": "activated"; }, never, never, true, never>;
}

export { NavigationItemComponent, NavigationShellComponent };
export type { NavigationItem };
