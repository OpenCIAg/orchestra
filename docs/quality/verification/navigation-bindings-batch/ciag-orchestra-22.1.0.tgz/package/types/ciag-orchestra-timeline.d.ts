import * as _angular_core from '@angular/core';

type TimelineOrientation = 'vertical' | 'horizontal';
type TimelineItemStatus = 'pending' | 'current' | 'completed' | 'error';
interface TimelineItem {
    id?: string | number;
    title: string;
    description?: string;
    date?: string;
    icon?: string;
    status?: TimelineItemStatus;
}

declare class TimelineComponent {
    readonly items: _angular_core.InputSignal<TimelineItem[]>;
    readonly value: _angular_core.InputSignal<TimelineItem[] | undefined>;
    readonly align: _angular_core.InputSignal<string>;
    readonly layout: _angular_core.InputSignal<TimelineOrientation>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly orientation: _angular_core.InputSignal<TimelineOrientation>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly itemSelect: _angular_core.OutputEmitterRef<{
        item: TimelineItem;
        index: number;
    }>;
    readonly onItemClick: _angular_core.OutputEmitterRef<{
        item: TimelineItem;
        index: number;
    }>;
    trackItem(index: number, item: TimelineItem): string | number;
    selectItem(item: TimelineItem, index: number): void;
    onItemKeydown(event: KeyboardEvent, item: TimelineItem, index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimelineComponent, "orc-timeline", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; }, { "itemSelect": "itemSelect"; "onItemClick": "onItemClick"; }, never, never, true, never>;
}

export { TimelineComponent };
export type { TimelineItem, TimelineItemStatus, TimelineOrientation };
