import * as _angular_core from '@angular/core';

type TagVariant = 'neutral' | 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'secondary' | 'contrast';
declare class TagComponent {
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.InputSignal<string | undefined>;
    readonly variant: _angular_core.InputSignal<TagVariant>;
    readonly severity: _angular_core.InputSignal<TagVariant | undefined>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly removable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly removed: _angular_core.OutputEmitterRef<string>;
    readonly onRemove: _angular_core.OutputEmitterRef<{
        value: string;
    }>;
    effectiveLabel(): string;
    effectiveVariant(): TagVariant;
    remove(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TagComponent, "orc-tag", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; }, { "removed": "removed"; "onRemove": "onRemove"; }, never, never, true, never>;
}

export { TagComponent };
export type { TagVariant };
