import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';

type ProgressMode = 'determinate' | 'indeterminate';
type ProgressVariant = 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger';
type ProgressSize = 'sm' | 'md' | 'lg' | 'xl';
interface ProgressMarker {
    value: number;
    label?: string;
    tone?: ProgressVariant;
}

declare class ProgressBarComponent {
    /** PrimeNG-compatible projected content template (`#content`, implicit value). */
    readonly contentTemplate?: TemplateRef<unknown>;
    /** Valor percentual atual do progresso (0 a 100) */
    readonly value: _angular_core.InputSignal<number>;
    /** Modo de operação: 'determinate' (valor numérico) ou 'indeterminate' (animação contínua) */
    readonly mode: _angular_core.InputSignal<ProgressMode>;
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    readonly variant: _angular_core.InputSignal<ProgressVariant>;
    /** Espessura / tamanho da barra: 'sm' (4px) | 'md' (8px - padrão Figma) | 'lg' (12px) */
    readonly size: _angular_core.InputSignal<ProgressSize>;
    /** Rótulo textual opcional exibido no topo à esquerda (ex: 'Progresso', 'Upload') */
    readonly label: _angular_core.InputSignal<string>;
    /** Exibe a porcentagem numérica no topo à direita */
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly unit: _angular_core.InputSignal<string>;
    readonly color: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly valueStyleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, any> | undefined>;
    /** Prefixo opcional para exibição de valor (ex: '$') */
    readonly valuePrefix: _angular_core.InputSignal<string>;
    /** Sufixo para exibição de valor (padrão: '%') */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Cantos arredondados tipo pílula (padrão Figma: true) */
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Suporte a etapas segmentadas (ex: 3 barras discretas) */
    readonly segments: _angular_core.InputSignal<number>;
    /** Etapa ativa atual no modo segmentado (1-indexed ou 0-indexed) */
    readonly currentSegment: _angular_core.InputSignal<number>;
    /** Altura customizada (ex: '6px' ou número 6) */
    readonly customHeight: _angular_core.InputSignal<string | number>;
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    readonly customColor: _angular_core.InputSignal<string>;
    /** Cor customizada da trilha / fundo da barra */
    readonly customTrackColor: _angular_core.InputSignal<string>;
    readonly markers: _angular_core.InputSignal<ProgressMarker[]>;
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** Sobrescreve a descrição audível aria-valuetext */
    readonly ariaValueText: _angular_core.InputSignal<string | undefined>;
    readonly isIndeterminate: _angular_core.Signal<boolean>;
    readonly normalizedValue: _angular_core.Signal<number>;
    readonly formattedValue: _angular_core.Signal<string>;
    readonly effectiveColor: _angular_core.Signal<string>;
    readonly hasHeader: _angular_core.Signal<boolean>;
    readonly segmentArray: _angular_core.Signal<number[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressBarComponent, "orc-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "unit": { "alias": "unit"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "valueStyleClass": { "alias": "valueStyleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "valuePrefix": { "alias": "valuePrefix"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "segments": { "alias": "segments"; "required": false; "isSignal": true; }; "currentSegment": { "alias": "currentSegment"; "required": false; "isSignal": true; }; "customHeight": { "alias": "customHeight"; "required": false; "isSignal": true; }; "customColor": { "alias": "customColor"; "required": false; "isSignal": true; }; "customTrackColor": { "alias": "customTrackColor"; "required": false; "isSignal": true; }; "markers": { "alias": "markers"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaValueText": { "alias": "ariaValueText"; "required": false; "isSignal": true; }; }, {}, ["contentTemplate"], never, true, never>;
}

declare class ProgressCircleComponent {
    /** Valor percentual atual do progresso circular (0 a 100) */
    readonly value: _angular_core.InputSignal<number>;
    /** Modo de operação: 'determinate' (valor exato) ou 'indeterminate' (spinner contínuo) */
    readonly mode: _angular_core.InputSignal<ProgressMode>;
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    readonly variant: _angular_core.InputSignal<ProgressVariant>;
    /** Dimensão do círculo: 'sm' (32px) | 'md' (48px) | 'lg' (64px) | 'xl' (96px) ou número em px */
    readonly size: _angular_core.InputSignal<number | ProgressSize>;
    /** Espessura do traço (em px). Se omitido, é calculado proporcionalmente ao tamanho */
    readonly strokeWidth: _angular_core.InputSignal<string | number | undefined>;
    readonly animation: _angular_core.InputSignal<"spin" | "none">;
    /** Exibe o valor numérico centralizado dentro do círculo */
    readonly showValue: _angular_core.InputSignal<boolean>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, any> | undefined>;
    readonly animationDuration: _angular_core.InputSignal<string>;
    readonly fill: _angular_core.InputSignal<string>;
    /** Cantos arredondados na ponta do arco (stroke-linecap: round) */
    readonly rounded: _angular_core.InputSignal<boolean>;
    /** Prefixo opcional para exibição de valor (ex: '$') */
    readonly valuePrefix: _angular_core.InputSignal<string>;
    /** Sufixo para exibição de valor (padrão: '%') */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Rótulo textual opcional */
    readonly label: _angular_core.InputSignal<string>;
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    readonly customColor: _angular_core.InputSignal<string>;
    /** Cor customizada da trilha de fundo */
    readonly customTrackColor: _angular_core.InputSignal<string>;
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** Sobrescreve a descrição audível aria-valuetext */
    readonly ariaValueText: _angular_core.InputSignal<string | undefined>;
    readonly isIndeterminate: _angular_core.Signal<boolean>;
    readonly normalizedValue: _angular_core.Signal<number>;
    readonly pixelSize: _angular_core.Signal<number>;
    readonly computedStrokeWidth: _angular_core.Signal<number>;
    readonly center: _angular_core.Signal<number>;
    readonly radius: _angular_core.Signal<number>;
    readonly circumference: _angular_core.Signal<number>;
    readonly strokeDashOffset: _angular_core.Signal<number>;
    readonly formattedValue: _angular_core.Signal<string>;
    readonly effectiveColor: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressCircleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressCircleComponent, "orc-progress-circle", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "animationDuration": { "alias": "animationDuration"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "valuePrefix": { "alias": "valuePrefix"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "customColor": { "alias": "customColor"; "required": false; "isSignal": true; }; "customTrackColor": { "alias": "customTrackColor"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaValueText": { "alias": "ariaValueText"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ProgressSpinnerComponent {
    readonly strokeWidth: _angular_core.InputSignal<string | number>;
    readonly fill: _angular_core.InputSignal<string>;
    readonly color: _angular_core.InputSignal<string>;
    readonly animationDuration: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<number>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly animation: _angular_core.InputSignal<"spin" | "none">;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | null | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressSpinnerComponent, "orc-progress-spinner", never, { "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "animationDuration": { "alias": "animationDuration"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { ProgressBarComponent, ProgressCircleComponent, ProgressSpinnerComponent };
export type { ProgressMarker, ProgressMode, ProgressSize, ProgressVariant };
