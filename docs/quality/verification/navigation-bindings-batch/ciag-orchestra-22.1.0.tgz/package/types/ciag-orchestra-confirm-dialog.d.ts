export { ConfirmDialogComponent, ConfirmationRequest, ConfirmationService } from '@ciag/orchestra/p2';
