import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, ElementRef } from '@angular/core';

type AccordionVariant = 'default' | 'separated' | 'bordered';
interface AccordionToggleEvent {
    id: string;
    expanded: boolean;
    originalEvent?: Event;
    index?: number;
}

declare class AccordionItemComponent implements OnInit, OnDestroy {
    private readonly accordion;
    readonly id: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly header: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.InputSignal<string | number | undefined>;
    readonly headerStyleClass: _angular_core.InputSignal<string>;
    readonly contentStyleClass: _angular_core.InputSignal<string>;
    readonly closable: _angular_core.InputSignal<boolean>;
    readonly cache: _angular_core.InputSignal<boolean>;
    readonly subtitle: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly hideToggle: _angular_core.InputSignal<boolean>;
    readonly iconPos: _angular_core.InputSignal<"start" | "end">;
    readonly headerAriaLevel: _angular_core.InputSignal<number | undefined>;
    readonly expanded: _angular_core.ModelSignal<boolean>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly toggle: _angular_core.OutputEmitterRef<boolean>;
    readonly headerButton: _angular_core.Signal<ElementRef<HTMLButtonElement> | undefined>;
    private readonly fallbackId;
    readonly itemId: _angular_core.Signal<string>;
    readonly effectiveTitle: _angular_core.Signal<string>;
    readonly headerId: _angular_core.Signal<string>;
    readonly panelId: _angular_core.Signal<string>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleExpanded(originalEvent?: Event): void;
    focusHeader(): void;
    onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccordionItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccordionItemComponent, "orc-accordion-item", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "headerStyleClass": { "alias": "headerStyleClass"; "required": false; "isSignal": true; }; "contentStyleClass": { "alias": "contentStyleClass"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "cache": { "alias": "cache"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "headerAriaLevel": { "alias": "headerAriaLevel"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; "opened": "opened"; "closed": "closed"; "toggle": "toggle"; }, never, ["[accordion-header], [accordionHeader]", "*"], true, never>;
}

declare class AccordionComponent {
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly value: _angular_core.ModelSignal<string | number | (string | number)[]>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly variant: _angular_core.InputSignal<AccordionVariant>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly expandIcon: _angular_core.InputSignal<string | undefined>;
    readonly collapseIcon: _angular_core.InputSignal<string | undefined>;
    readonly selectOnFocus: _angular_core.InputSignal<boolean>;
    readonly transitionOptions: _angular_core.InputSignal<string>;
    readonly headerAriaLevel: _angular_core.InputSignal<number>;
    readonly activeIndex: _angular_core.ModelSignal<number | number[] | null>;
    private previousValue;
    private previousActiveIndex;
    private selectionSource;
    constructor();
    readonly expandedChange: _angular_core.OutputEmitterRef<AccordionToggleEvent>;
    readonly onOpen: _angular_core.OutputEmitterRef<AccordionToggleEvent>;
    readonly onClose: _angular_core.OutputEmitterRef<AccordionToggleEvent>;
    private readonly items;
    registerItem(item: AccordionItemComponent): void;
    unregisterItem(item: AccordionItemComponent): void;
    onItemToggle(targetItem: AccordionItemComponent, isExpanded: boolean, originalEvent?: Event): void;
    handleKeyNavigation(event: KeyboardEvent, currentItem: AccordionItemComponent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccordionComponent, "orc-accordion", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "expandIcon": { "alias": "expandIcon"; "required": false; "isSignal": true; }; "collapseIcon": { "alias": "collapseIcon"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "headerAriaLevel": { "alias": "headerAriaLevel"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "activeIndex": "activeIndexChange"; "expandedChange": "expandedChange"; "onOpen": "onOpen"; "onClose": "onClose"; }, never, ["*"], true, never>;
}

export { AccordionComponent, AccordionItemComponent };
export type { AccordionToggleEvent, AccordionVariant };
