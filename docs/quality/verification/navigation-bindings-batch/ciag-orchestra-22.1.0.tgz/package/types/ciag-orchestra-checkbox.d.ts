import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

interface CheckboxChangeEvent<T = any> {
    checked: boolean;
    indeterminate: boolean;
    value?: T;
}
type CheckboxAriaChecked = 'true' | 'false' | 'mixed';

declare class CheckboxComponent implements ControlValueAccessor {
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledby: _angular_core.InputSignal<string | undefined>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly binary: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly trueValue: _angular_core.InputSignal<any>;
    readonly falseValue: _angular_core.InputSignal<any>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly indeterminate: _angular_core.ModelSignal<boolean>;
    readonly change: _angular_core.OutputEmitterRef<CheckboxChangeEvent<any>>;
    readonly onChange: _angular_core.OutputEmitterRef<CheckboxChangeEvent<any>>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly inputElement: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly uniqueId: string;
    private readonly cvaDisabled;
    private readonly cvaValue;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly labelId: _angular_core.Signal<string>;
    readonly descriptionId: _angular_core.Signal<string>;
    readonly errorId: _angular_core.Signal<string>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isError: _angular_core.Signal<boolean>;
    readonly ariaChecked: _angular_core.Signal<CheckboxAriaChecked>;
    readonly computedAriaDescribedBy: _angular_core.Signal<string | null>;
    readonly hasContent: _angular_core.Signal<boolean>;
    private onModelChange;
    private onTouched;
    constructor();
    writeValue(val: any): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onNativeChange(event: Event): void;
    handleBlur(event?: Event): void;
    handleFocus(event: Event): void;
    modelValue(): any;
    onLegacyBlur(): void;
    toggle(): void;
    focus(): void;
    private nextModelValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckboxComponent, "orc-checkbox", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "ariaDescribedby"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "indeterminate": "indeterminateChange"; "change": "change"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, ["*", "*"], true, never>;
}

export { CheckboxComponent };
export type { CheckboxAriaChecked, CheckboxChangeEvent };
