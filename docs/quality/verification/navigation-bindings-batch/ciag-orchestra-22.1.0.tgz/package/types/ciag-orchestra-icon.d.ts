import * as _angular_core from '@angular/core';

/** Material Symbols names use the Google Fonts snake_case ligature name. */
type IconName = string;
type IconFamily = 'outlined' | 'rounded' | 'sharp';
type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
type IconFill = 'outline' | 'filled';
type IconWeight = number;
type IconGrade = number;
type IconOpticalSize = number | 'auto';
interface OrcMaterialSymbolMetadata {
    readonly name: string;
    readonly rank: number;
    readonly popularity: number;
    readonly categories: readonly string[];
    readonly tags: readonly string[];
    readonly codepoint?: number;
    readonly version?: number;
}

declare const ORC_MATERIAL_SYMBOL_FAMILIES: readonly IconFamily[];
declare class IconComponent {
    readonly name: _angular_core.InputSignal<string>;
    readonly family: _angular_core.InputSignal<IconFamily>;
    readonly size: _angular_core.InputSignal<IconSize>;
    readonly fill: _angular_core.InputSignal<IconFill>;
    readonly weight: _angular_core.InputSignal<number>;
    readonly grade: _angular_core.InputSignal<number>;
    readonly opticalSize: _angular_core.InputSignal<IconOpticalSize>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly fontFamily: _angular_core.Signal<string>;
    readonly sizeValue: _angular_core.Signal<string>;
    readonly opticalSizeValue: _angular_core.Signal<number>;
    readonly opticalSizing: _angular_core.Signal<string>;
    readonly fontVariationSettings: _angular_core.Signal<string>;
    readonly accessibleName: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconComponent, "orc-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "family": { "alias": "family"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "weight": { "alias": "weight"; "required": false; "isSignal": true; }; "grade": { "alias": "grade"; "required": false; "isSignal": true; }; "opticalSize": { "alias": "opticalSize"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { IconComponent, ORC_MATERIAL_SYMBOL_FAMILIES };
export type { IconFamily, IconFill, IconGrade, IconName, IconOpticalSize, IconSize, IconWeight, OrcMaterialSymbolMetadata };
