import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef } from '@angular/core';

interface TreeNode {
    id: string;
    label: string;
    children?: TreeNode[];
    disabled?: boolean;
}
interface TreeNodeItem {
    node: TreeNode;
    index?: number;
    level?: number;
    expandable?: boolean;
    position?: number;
    setSize?: number;
    parentId?: string | null;
}
interface VisibleTreeNode extends TreeNodeItem {
    index: number;
    level: number;
    expandable: boolean;
    position: number;
    setSize: number;
    parentId: string | null;
}
declare class TreeViewComponent implements OnDestroy {
    readonly nodes: _angular_core.InputSignal<TreeNode[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly collapseLabel: _angular_core.InputSignal<string | undefined>;
    readonly expandLabel: _angular_core.InputSignal<string | undefined>;
    readonly nodeSelect: _angular_core.OutputEmitterRef<TreeNode>;
    readonly expanded: _angular_core.WritableSignal<ReadonlySet<string>>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    private readonly injector;
    private readonly treeElement;
    readonly treeId: string;
    readonly visibleNodes: _angular_core.Signal<VisibleTreeNode[]>;
    readonly normalizedActiveIndex: _angular_core.Signal<number>;
    readonly visibleNodeById: _angular_core.Signal<Map<string, VisibleTreeNode>>;
    /** All rendered treeitems, including descendants rendered by the recursive template. */
    readonly treeItems: () => ElementRef<HTMLElement>[];
    private previousVisibleIds;
    private previousActiveIndex;
    private typeahead;
    private typeaheadAt;
    private focusRequest;
    private focusTimer;
    constructor();
    visibleItem(node: TreeNode): VisibleTreeNode | undefined;
    itemId(node: TreeNode): string;
    groupId(node: TreeNode): string;
    labelId(node: TreeNode): string;
    toggle(node: TreeNode): void;
    activate(node: TreeNode, index?: number, event?: Event): void;
    keydown(event: KeyboardEvent, item: TreeNodeItem, index?: number): void;
    setActiveIndex(index: number, focus?: boolean): void;
    focusItem(event: FocusEvent, index: number): void;
    private moveTo;
    private rememberCurrentVisibleState;
    private isDescendant;
    private focusNode;
    private itemDomId;
    ngOnDestroy(): void;
    private itemElements;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeViewComponent, "orc-tree-view", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "collapseLabel": { "alias": "collapseLabel"; "required": false; "isSignal": true; }; "expandLabel": { "alias": "expandLabel"; "required": false; "isSignal": true; }; }, { "nodeSelect": "nodeSelect"; }, never, never, true, never>;
}

export { TreeViewComponent };
export type { TreeNode };
