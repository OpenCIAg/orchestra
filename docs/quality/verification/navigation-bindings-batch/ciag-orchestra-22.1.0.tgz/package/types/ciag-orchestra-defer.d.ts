import * as i0 from '@angular/core';
import { AfterViewInit, OnDestroy, TemplateRef, ViewContainerRef, ElementRef } from '@angular/core';

declare class DeferDirective implements AfterViewInit, OnDestroy {
    private readonly template;
    private readonly container;
    private readonly host;
    readonly onLoad: i0.OutputEmitterRef<Event>;
    private observer?;
    private view?;
    private loaded;
    constructor(template: TemplateRef<unknown>, container: ViewContainerRef, host: ElementRef<Node>);
    ngAfterViewInit(): void;
    shouldLoad(): boolean;
    isLoaded(): boolean;
    load(event?: Event): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeferDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DeferDirective, "[orcDefer], [pDefer]", never, {}, { "onLoad": "onLoad"; }, never, never, true, never>;
}

export { DeferDirective };
