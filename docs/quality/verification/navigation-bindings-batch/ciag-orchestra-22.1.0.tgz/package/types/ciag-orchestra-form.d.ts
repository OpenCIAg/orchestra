import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

interface FormSubmitEvent {
    event: SubmitEvent;
    valid: boolean;
}
type FormLayout = 'stacked' | 'inline';
declare class FormComponent {
    readonly nativeForm: _angular_core.Signal<ElementRef<HTMLFormElement> | undefined>;
    readonly layout: _angular_core.InputSignal<FormLayout>;
    readonly name: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly novalidate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly formSubmit: _angular_core.OutputEmitterRef<FormSubmitEvent>;
    readonly formReset: _angular_core.OutputEmitterRef<void>;
    onSubmit(event: SubmitEvent): void;
    onReset(): void;
    reset(): void;
    submit(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormComponent, "orc-form", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "novalidate": { "alias": "novalidate"; "required": false; "isSignal": true; }; }, { "formSubmit": "formSubmit"; "formReset": "formReset"; }, never, ["*"], true, never>;
}

export { FormComponent };
export type { FormLayout, FormSubmitEvent };
