export { InputComponent as InputText, InputComponent as InputTextComponent } from '@ciag/orchestra/input';
