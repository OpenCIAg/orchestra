import * as _angular_core from '@angular/core';

type DividerOrientation = 'horizontal' | 'vertical';
type DividerVariant = 'solid' | 'dashed' | 'dotted';
declare class DividerComponent {
    readonly orientation: _angular_core.InputSignal<DividerOrientation>;
    readonly variant: _angular_core.InputSignal<DividerVariant>;
    readonly label: _angular_core.InputSignal<string>;
    readonly inset: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly decorative: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly classes: _angular_core.Signal<{
        [x: string]: boolean;
        'orc-divider': boolean;
        'orc-divider--vertical': boolean;
        'orc-divider--inset': boolean;
        'orc-divider--labeled': boolean;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DividerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DividerComponent, "orc-divider", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "inset": { "alias": "inset"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { DividerComponent };
export type { DividerOrientation, DividerVariant };
