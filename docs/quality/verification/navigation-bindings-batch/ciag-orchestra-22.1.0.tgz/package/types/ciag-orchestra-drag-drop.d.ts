import * as _angular_core from '@angular/core';
import { AfterViewInit, ElementRef } from '@angular/core';

declare class DraggableDirective implements AfterViewInit {
    private readonly element;
    readonly scope: _angular_core.InputSignal<string | string[] | undefined>;
    readonly pScope: _angular_core.InputSignal<string | string[] | undefined>;
    readonly dragEffect: _angular_core.InputSignal<"none" | "copy" | "copyLink" | "copyMove" | "link" | "linkMove" | "move" | "all" | "uninitialized">;
    readonly dragHandle: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly onDragStart: _angular_core.OutputEmitterRef<DragEvent>;
    readonly onDragEnd: _angular_core.OutputEmitterRef<DragEvent>;
    readonly onDrag: _angular_core.OutputEmitterRef<DragEvent>;
    constructor(element: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    private isDisabled;
    dragStart(event: DragEvent): void;
    drag(event: DragEvent): void;
    dragEnd(event: DragEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DraggableDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DraggableDirective, "[orcDraggable], [pDraggable]", never, { "scope": { "alias": "orcDraggable"; "required": false; "isSignal": true; }; "pScope": { "alias": "pDraggable"; "required": false; "isSignal": true; }; "dragEffect": { "alias": "dragEffect"; "required": false; "isSignal": true; }; "dragHandle": { "alias": "dragHandle"; "required": false; "isSignal": true; }; "disabled": { "alias": "orcDraggableDisabled"; "required": false; "isSignal": true; }; "pDisabled": { "alias": "pDraggableDisabled"; "required": false; "isSignal": true; }; }, { "onDragStart": "onDragStart"; "onDragEnd": "onDragEnd"; "onDrag": "onDrag"; }, never, never, true, never>;
}
declare class DroppableDirective implements AfterViewInit {
    private readonly element;
    readonly scope: _angular_core.InputSignal<string | string[] | undefined>;
    readonly pScope: _angular_core.InputSignal<string | string[] | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dropEffect: _angular_core.InputSignal<"none" | "copy" | "link" | "move">;
    readonly onDragEnter: _angular_core.OutputEmitterRef<DragEvent>;
    readonly onDragLeave: _angular_core.OutputEmitterRef<DragEvent>;
    readonly onDrop: _angular_core.OutputEmitterRef<DragEvent>;
    private active;
    constructor(element: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    private isDisabled;
    dragOver(event: DragEvent): void;
    dragEnter(event: DragEvent): void;
    dragLeave(event: DragEvent): void;
    drop(event: DragEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DroppableDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DroppableDirective, "[orcDroppable], [pDroppable]", never, { "scope": { "alias": "orcDroppable"; "required": false; "isSignal": true; }; "pScope": { "alias": "pDroppable"; "required": false; "isSignal": true; }; "disabled": { "alias": "orcDroppableDisabled"; "required": false; "isSignal": true; }; "pDisabled": { "alias": "pDroppableDisabled"; "required": false; "isSignal": true; }; "dropEffect": { "alias": "dropEffect"; "required": false; "isSignal": true; }; }, { "onDragEnter": "onDragEnter"; "onDragLeave": "onDragLeave"; "onDrop": "onDrop"; }, never, never, true, never>;
}

export { DraggableDirective, DroppableDirective };
