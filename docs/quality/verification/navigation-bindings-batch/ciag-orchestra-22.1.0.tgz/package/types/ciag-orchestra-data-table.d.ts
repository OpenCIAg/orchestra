export { DataTableColumn, DataTableComponent } from '@ciag/orchestra/p2';
