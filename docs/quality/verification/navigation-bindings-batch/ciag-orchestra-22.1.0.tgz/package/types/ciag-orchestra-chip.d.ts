import * as _angular_core from '@angular/core';

type ChipVariant = 'neutral' | 'primary' | 'success' | 'warning' | 'danger';
type ChipSize = 'sm' | 'md' | 'lg';

declare class ChipComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string | number>;
    readonly variant: _angular_core.InputSignal<ChipVariant>;
    readonly size: _angular_core.InputSignal<ChipSize>;
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly removable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly image: _angular_core.InputSignal<string | undefined>;
    readonly removeIcon: _angular_core.InputSignal<string>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly removeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly selected: _angular_core.ModelSignal<boolean>;
    readonly removed: _angular_core.OutputEmitterRef<string | number>;
    readonly onRemove: _angular_core.OutputEmitterRef<Event>;
    toggle(): void;
    remove(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipComponent, "orc-chip", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "removeIcon": { "alias": "removeIcon"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "removeAriaLabel": { "alias": "removeAriaLabel"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "removed": "removed"; "onRemove": "onRemove"; }, never, never, true, never>;
}

export { ChipComponent };
export type { ChipSize, ChipVariant };
