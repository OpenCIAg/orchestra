import * as _angular_core from '@angular/core';

declare class CardComponent {
    clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    variant: _angular_core.InputSignal<"simple" | "dashboard">;
    readonly flush: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly media: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly padding: _angular_core.InputSignal<string | number | undefined>;
    readonly clip: _angular_core.InputSignalWithTransform<boolean, unknown>;
    header: _angular_core.InputSignal<string | undefined>;
    subheader: _angular_core.InputSignal<string | undefined>;
    styleClass: _angular_core.InputSignal<string>;
    style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    ariaLabel: _angular_core.InputSignal<string>;
    cardClick: _angular_core.OutputEmitterRef<void>;
    onClickEvent: _angular_core.OutputEmitterRef<MouseEvent>;
    onClick(): void;
    onCardClick(event: MouseEvent): void;
    onPrimaryClick(event: MouseEvent): void;
    private activate;
    private isNestedInteractive;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardComponent, "orc-card", never, { "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "flush": { "alias": "flush"; "required": false; "isSignal": true; }; "media": { "alias": "media"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "clip": { "alias": "clip"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "subheader": { "alias": "subheader"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "cardClick": "cardClick"; "onClickEvent": "onClickEvent"; }, never, ["*"], true, never>;
}

declare class CardHeaderComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardHeaderComponent, "orc-card-header", never, {}, {}, never, ["*"], true, never>;
}

declare class CardBodyComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardBodyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardBodyComponent, "orc-card-body", never, {}, {}, never, ["*"], true, never>;
}

declare class CardFooterComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardFooterComponent, "orc-card-footer", never, {}, {}, never, ["*"], true, never>;
}

export { CardBodyComponent, CardComponent, CardFooterComponent, CardHeaderComponent };
