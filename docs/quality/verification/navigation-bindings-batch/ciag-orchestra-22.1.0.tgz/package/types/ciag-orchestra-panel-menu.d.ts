export { PanelMenuComponent, PrimeMenuItem } from '@ciag/orchestra/p2';
