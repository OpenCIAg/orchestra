import * as _angular_platform_browser from '@angular/platform-browser';
import * as _angular_core from '@angular/core';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'link' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

declare class ButtonComponent {
    readonly variant: _angular_core.InputSignal<ButtonVariant>;
    readonly severity: _angular_core.InputSignal<ButtonVariant | undefined>;
    readonly size: _angular_core.InputSignal<ButtonSize>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly raised: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly link: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly iconPos: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaExpanded: _angular_core.InputSignal<boolean | undefined>;
    readonly ariaControls: _angular_core.InputSignal<string | undefined>;
    readonly form: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly badge: _angular_core.InputSignal<string | number | undefined>;
    readonly badgeClass: _angular_core.InputSignal<string>;
    readonly iconLeft: _angular_core.InputSignal<string | undefined>;
    readonly iconRight: _angular_core.InputSignal<string | undefined>;
    readonly iconOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    private readonly document;
    private readonly sanitizer;
    /**
     * The native button already bubbles a `click` event through the host.
     * Keep the TypeScript property for consumers, but expose the component
     * output under a distinct alias so `(click)` is not delivered twice.
     */
    readonly click: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly effectiveIconLeft: _angular_core.Signal<string | undefined>;
    readonly effectiveIconRight: _angular_core.Signal<string | undefined>;
    readonly safeIconLeft: _angular_core.Signal<{
        isSvg: boolean;
        content: string | _angular_platform_browser.SafeHtml;
    } | null>;
    readonly safeIconRight: _angular_core.Signal<{
        isSvg: boolean;
        content: string | _angular_platform_browser.SafeHtml;
    } | null>;
    readonly buttonClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'orc-button': boolean;
        'orc-button--disabled': boolean;
        'orc-button--loading': boolean;
        'orc-button--full-width': boolean;
        'orc-button--icon-only': boolean;
        'orc-button--text': boolean;
        'orc-button--outlined': boolean;
        'orc-button--raised': boolean;
        'orc-button--rounded': boolean;
        'orc-button--plain': boolean;
        'orc-button--fluid': boolean;
    }>;
    readonly buttonClassString: _angular_core.Signal<string>;
    handleClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonComponent, "orc-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaExpanded": { "alias": "ariaExpanded"; "required": false; "isSignal": true; }; "ariaControls": { "alias": "ariaControls"; "required": false; "isSignal": true; }; "form": { "alias": "form"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "badgeClass": { "alias": "badgeClass"; "required": false; "isSignal": true; }; "iconLeft": { "alias": "iconLeft"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "click": "clicked"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, ["[iconLeft]", "*", "[iconRight]"], true, never>;
}

declare class IconButtonComponent {
    readonly variant: _angular_core.InputSignal<ButtonVariant>;
    readonly size: _angular_core.InputSignal<ButtonSize>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    private readonly document;
    private readonly sanitizer;
    /** Keep the public property while avoiding a native/output `click` collision. */
    readonly click: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly safeIcon: _angular_core.Signal<{
        isSvg: boolean;
        content: string | _angular_platform_browser.SafeHtml;
    } | null>;
    readonly buttonClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'orc-icon-button': boolean;
        'orc-icon-button--disabled': boolean;
        'orc-icon-button--loading': boolean;
    }>;
    handleClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconButtonComponent, "orc-icon-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; }, { "click": "clicked"; }, never, ["*"], true, never>;
}

export { ButtonComponent, IconButtonComponent };
export type { ButtonSize, ButtonVariant };
