export { AlertComponent as MessageComponent } from '@ciag/orchestra/alert';
export { P2Message as MessageItem, MessagesComponent } from '@ciag/orchestra/p2';
