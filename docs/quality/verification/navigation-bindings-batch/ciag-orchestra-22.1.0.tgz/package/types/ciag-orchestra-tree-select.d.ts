export { TreeSelectComponent, TreeSelectNode } from '@ciag/orchestra/p2';
