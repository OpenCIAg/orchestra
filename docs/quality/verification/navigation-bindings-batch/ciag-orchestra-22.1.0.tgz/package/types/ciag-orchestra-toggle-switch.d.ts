export { SwitchComponent as ToggleSwitch, SwitchComponent as ToggleSwitchComponent } from '@ciag/orchestra/switch';
