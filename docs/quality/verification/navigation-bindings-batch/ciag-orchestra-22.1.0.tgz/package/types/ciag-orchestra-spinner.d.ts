import * as _angular_core from '@angular/core';

type SpinnerSize = 'sm' | 'md' | 'lg';
type SpinnerVariant = 'primary' | 'secondary' | 'neutral' | 'white';
type SpinnerType = 'ring' | 'star' | 'dots';
type SpinnerTextPosition = 'right' | 'bottom';
interface SpinnerConfig {
    size?: SpinnerSize;
    variant?: SpinnerVariant;
    type?: SpinnerType;
    text?: string;
    textPosition?: SpinnerTextPosition;
    fullScreen?: boolean;
    backdrop?: boolean;
    ariaLabel?: string;
}

declare class LoadingSpinnerComponent {
    readonly size: _angular_core.InputSignal<SpinnerSize>;
    readonly customSize: _angular_core.InputSignal<string | number>;
    readonly variant: _angular_core.InputSignal<SpinnerVariant>;
    readonly type: _angular_core.InputSignal<SpinnerType>;
    readonly text: _angular_core.InputSignal<string>;
    readonly textPosition: _angular_core.InputSignal<SpinnerTextPosition>;
    readonly fullScreen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly backdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly strokeWidth: _angular_core.InputSignal<number>;
    readonly fill: _angular_core.InputSignal<string>;
    readonly animation: _angular_core.InputSignal<"none" | "spin">;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    get isFullScreen(): boolean;
    readonly customSizeCss: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoadingSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LoadingSpinnerComponent, "orc-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "customSize": { "alias": "customSize"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "textPosition": { "alias": "textPosition"; "required": false; "isSignal": true; }; "fullScreen": { "alias": "fullScreen"; "required": false; "isSignal": true; }; "backdrop": { "alias": "backdrop"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { LoadingSpinnerComponent };
export type { SpinnerConfig, SpinnerSize, SpinnerTextPosition, SpinnerType, SpinnerVariant };
