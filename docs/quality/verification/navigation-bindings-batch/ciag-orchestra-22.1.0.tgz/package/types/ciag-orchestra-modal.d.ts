import * as _angular_core from '@angular/core';
import { AfterViewInit, OnDestroy, ElementRef, ComponentRef, ApplicationRef, EnvironmentInjector, Type, InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

type ModalSize = 'sm' | 'md' | 'lg' | 'xl' | 'fullScreen' | 'custom';
type ModalStatus = 'neutral' | 'danger';
declare class ModalComponent implements AfterViewInit, OnDestroy {
    private readonly document;
    readonly titleId: string;
    readonly hasTitle: _angular_core.WritableSignal<boolean>;
    headerContent?: ElementRef<HTMLElement>;
    private lastIsOpen;
    private lastVisible;
    private releaseLayer?;
    private releaseKeyboardListener?;
    private releaseScroll?;
    dialogRef: ElementRef<HTMLDialogElement>;
    readonly isOpen: _angular_core.ModelSignal<boolean>;
    /** PrimeNG Dialog-compatible visibility model; isOpen remains supported for Orchestra callers. */
    readonly visible: _angular_core.ModelSignal<boolean>;
    readonly header: _angular_core.InputSignal<string | undefined>;
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismissableMask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly draggable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly resizable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maximizable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly focusOnShow: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly focusTrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly blockScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignal<number>;
    readonly position: _angular_core.InputSignal<"center" | "top" | "bottom" | "left" | "right" | "topleft" | "topright" | "bottomleft" | "bottomright">;
    readonly style: _angular_core.InputSignal<string | Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly maskStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly maskStyleClass: _angular_core.InputSignal<string>;
    readonly contentStyle: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly contentStyleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<unknown>;
    readonly role: _angular_core.InputSignal<string>;
    readonly showHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeIcon: _angular_core.InputSignal<string>;
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly minimizeIcon: _angular_core.InputSignal<string>;
    readonly maximizeIcon: _angular_core.InputSignal<string>;
    readonly restoreAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly maximizeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly closeTabindex: _angular_core.InputSignal<string>;
    readonly breakpoints: _angular_core.InputSignal<Record<string, string> | undefined>;
    readonly size: _angular_core.InputSignal<ModalSize>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly status: _angular_core.InputSignal<ModalStatus>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnBackdropClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showCloseButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string>;
    readonly ariaDescribedBy: _angular_core.InputSignal<string>;
    readonly zIndex: _angular_core.InputSignal<number>;
    readonly effectiveZIndex: _angular_core.Signal<number>;
    readonly keepInViewport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly minX: _angular_core.InputSignal<number>;
    readonly minY: _angular_core.InputSignal<number>;
    readonly transitionOptions: _angular_core.InputSignal<string>;
    readonly rtl: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly onShow: _angular_core.OutputEmitterRef<void>;
    readonly onHide: _angular_core.OutputEmitterRef<void>;
    readonly onMaximize: _angular_core.OutputEmitterRef<{
        maximized: boolean;
    }>;
    readonly maximized: _angular_core.ModelSignal<boolean>;
    private platformId;
    private isBrowser;
    private previousActiveElement;
    constructor();
    ngAfterViewInit(): void;
    private syncDialogState;
    readonly modalClasses: _angular_core.Signal<{
        [x: string]: boolean;
        'orc-modal': boolean;
        'orc-modal--inline': boolean;
        'orc-modal--status-danger': boolean;
        'orc-modal--fullscreen': boolean;
        'orc-modal--maximized': boolean;
    }>;
    /**
     * Angular string interpolation coerces a class map to "[object Object]".
     * Convert the map explicitly so every modal selector receives its base,
     * size, status, inline, and maximized classes.
     */
    readonly modalClassNames: _angular_core.Signal<string>;
    onClose(): void;
    onCancel(event: Event): void;
    onBackdropClick(event: MouseEvent): void;
    show(): void;
    close(): void;
    toggleMaximize(): void;
    private acquireScrollLock;
    private releaseScrollLock;
    private finishClose;
    onNativeClose(): void;
    private focusInitialElement;
    trapFocus(event: KeyboardEvent): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalComponent, "orc-modal, orc-dialog, orc-dynamic-dialog", never, { "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "dismissableMask": { "alias": "dismissableMask"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "draggable": { "alias": "draggable"; "required": false; "isSignal": true; }; "resizable": { "alias": "resizable"; "required": false; "isSignal": true; }; "maximizable": { "alias": "maximizable"; "required": false; "isSignal": true; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; "isSignal": true; }; "focusTrap": { "alias": "focusTrap"; "required": false; "isSignal": true; }; "blockScroll": { "alias": "blockScroll"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "maskStyle": { "alias": "maskStyle"; "required": false; "isSignal": true; }; "maskStyleClass": { "alias": "maskStyleClass"; "required": false; "isSignal": true; }; "contentStyle": { "alias": "contentStyle"; "required": false; "isSignal": true; }; "contentStyleClass": { "alias": "contentStyleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "closeIcon": { "alias": "closeIcon"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "minimizeIcon": { "alias": "minimizeIcon"; "required": false; "isSignal": true; }; "maximizeIcon": { "alias": "maximizeIcon"; "required": false; "isSignal": true; }; "restoreAriaLabel": { "alias": "restoreAriaLabel"; "required": false; "isSignal": true; }; "maximizeAriaLabel": { "alias": "maximizeAriaLabel"; "required": false; "isSignal": true; }; "closeTabindex": { "alias": "closeTabindex"; "required": false; "isSignal": true; }; "breakpoints": { "alias": "breakpoints"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "closeOnBackdropClick": { "alias": "closeOnBackdropClick"; "required": false; "isSignal": true; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; "zIndex": { "alias": "zIndex"; "required": false; "isSignal": true; }; "keepInViewport": { "alias": "keepInViewport"; "required": false; "isSignal": true; }; "minX": { "alias": "minX"; "required": false; "isSignal": true; }; "minY": { "alias": "minY"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "rtl": { "alias": "rtl"; "required": false; "isSignal": true; }; "maximized": { "alias": "maximized"; "required": false; "isSignal": true; }; }, { "isOpen": "isOpenChange"; "visible": "visibleChange"; "closed": "closed"; "onShow": "onShow"; "onHide": "onHide"; "onMaximize": "onMaximize"; "maximized": "maximizedChange"; }, never, ["[modal-header]", "[modal-body]", "*", "[modal-footer]"], true, never>;
}

declare class ModalRef<TComponent = unknown, TResult = unknown> {
    private componentRef;
    private destroyCallback;
    private readonly closed;
    private hasClosed;
    private result;
    readonly afterClosed$: Observable<TResult | undefined>;
    constructor(componentRef: ComponentRef<TComponent>, destroyCallback: () => void);
    get instance(): TComponent;
    close(result?: TResult): void;
    /** Backwards-compatible synchronous access to the close result. */
    afterClosed(): TResult | undefined;
    /** Promise-friendly alternative to `afterClosed$`. */
    afterClosedPromise(): Promise<TResult | undefined>;
}

declare const ORC_MODAL_DATA: InjectionToken<unknown>;
declare class ModalService {
    private appRef;
    private injector;
    constructor(appRef: ApplicationRef, injector: EnvironmentInjector);
    /**
     * Abre um componente dinamicamente.
     * O componente injetado DEVE conter a tag <orc-modal> com [isOpen]="true" internamente,
     * para que o modal nativo assuma a camada de visualização (Top Layer do HTML5).
     */
    open<TComponent, TData = undefined, TResult = undefined>(component: Type<TComponent>, config?: {
        data?: TData;
        inputs?: Partial<Record<keyof TComponent, unknown>>;
    }): ModalRef<TComponent, TResult>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ModalService>;
}

export { ModalComponent, ModalRef, ModalService, ORC_MODAL_DATA };
export type { ModalSize, ModalStatus };
