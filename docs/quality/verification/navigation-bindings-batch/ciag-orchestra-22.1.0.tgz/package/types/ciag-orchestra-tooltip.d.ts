import * as _angular_core from '@angular/core';
import { ElementRef, OnDestroy } from '@angular/core';

type TooltipPosition = 'top' | 'bottom' | 'left' | 'right';
type TooltipTheme = 'dark' | 'light';
interface TooltipConfig {
    position?: TooltipPosition;
    theme?: TooltipTheme;
    showDelay?: number;
    hideDelay?: number;
    disabled?: boolean;
}

declare class TooltipComponent {
    readonly elementRef: ElementRef<any>;
    readonly text: _angular_core.WritableSignal<string>;
    readonly theme: _angular_core.WritableSignal<TooltipTheme>;
    readonly position: _angular_core.WritableSignal<TooltipPosition>;
    readonly actualPosition: _angular_core.WritableSignal<TooltipPosition>;
    readonly visible: _angular_core.WritableSignal<boolean>;
    readonly id: _angular_core.WritableSignal<string>;
    readonly styleClass: _angular_core.WritableSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TooltipComponent, "orc-tooltip-overlay", never, {}, {}, never, never, true, never>;
}

declare class TooltipDirective implements OnDestroy {
    private readonly elementRef;
    private readonly viewContainerRef;
    private readonly renderer;
    readonly appTooltip: _angular_core.InputSignal<string | null | undefined>;
    readonly uiTooltip: _angular_core.InputSignal<string | null | undefined>;
    readonly orcTooltip: _angular_core.InputSignal<string | null | undefined>;
    readonly tooltipPosition: _angular_core.InputSignal<TooltipPosition>;
    readonly tooltipTheme: _angular_core.InputSignal<TooltipTheme>;
    readonly tooltipShowDelay: _angular_core.InputSignal<number>;
    readonly tooltipHideDelay: _angular_core.InputSignal<number>;
    readonly showDelay: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly hideDelay: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly tooltipEvent: _angular_core.InputSignal<"hover" | "focus" | "both">;
    readonly positionStyle: _angular_core.InputSignal<string | undefined>;
    readonly tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    readonly tooltipZIndex: _angular_core.InputSignal<string | undefined>;
    readonly escape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly life: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly fitContent: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly content: _angular_core.InputSignal<string | undefined>;
    readonly tooltipOptions: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly position: _angular_core.InputSignal<TooltipPosition | undefined>;
    readonly autoHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly hideOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tooltipDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly appendTo: _angular_core.InputSignal<"body" | "self">;
    readonly tooltipText: _angular_core.Signal<string>;
    readonly effectiveShowDelay: _angular_core.Signal<number>;
    readonly effectiveHideDelay: _angular_core.Signal<number>;
    readonly effectivePosition: _angular_core.Signal<TooltipPosition>;
    private componentRef;
    private showTimeoutId;
    private hideTimeoutId;
    private readonly tooltipId;
    private readonly document;
    private hovered;
    private focused;
    private frame;
    private lifetimeTimer;
    private readonly fading;
    private stopPositioning?;
    private releaseLayer?;
    constructor();
    onMouseEnter(): void;
    onMouseLeave(): void;
    onFocusIn(): void;
    onFocusOut(event?: FocusEvent): void;
    onEscape(): void;
    private scheduleShow;
    private scheduleHide;
    private show;
    private hide;
    private hideImmediately;
    private restoreDescribedBy;
    private startPositioning;
    private stopLiveResources;
    private updatePosition;
    private clearShowTimeout;
    private clearHideTimeout;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TooltipDirective, "[orcTooltip]", never, { "appTooltip": { "alias": "appTooltip"; "required": false; "isSignal": true; }; "uiTooltip": { "alias": "uiTooltip"; "required": false; "isSignal": true; }; "orcTooltip": { "alias": "orcTooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipTheme": { "alias": "tooltipTheme"; "required": false; "isSignal": true; }; "tooltipShowDelay": { "alias": "tooltipShowDelay"; "required": false; "isSignal": true; }; "tooltipHideDelay": { "alias": "tooltipHideDelay"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "tooltipEvent": { "alias": "tooltipEvent"; "required": false; "isSignal": true; }; "positionStyle": { "alias": "positionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "tooltipZIndex": { "alias": "tooltipZIndex"; "required": false; "isSignal": true; }; "escape": { "alias": "escape"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "fitContent": { "alias": "fitContent"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "tooltipOptions": { "alias": "tooltipOptions"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "autoHide": { "alias": "autoHide"; "required": false; "isSignal": true; }; "hideOnEscape": { "alias": "hideOnEscape"; "required": false; "isSignal": true; }; "tooltipDisabled": { "alias": "tooltipDisabled"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { TooltipComponent, TooltipDirective };
export type { TooltipConfig, TooltipPosition, TooltipTheme };
