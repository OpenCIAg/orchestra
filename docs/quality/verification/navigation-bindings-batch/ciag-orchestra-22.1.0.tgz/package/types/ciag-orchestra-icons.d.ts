import { OrcMaterialSymbolMetadata } from '@ciag/orchestra/icon';

/** All Material Symbols available in the Rounded family at generation time. */
declare const ORC_MATERIAL_SYMBOLS: readonly OrcMaterialSymbolMetadata[];
declare const ORC_MATERIAL_SYMBOL_CATALOG: Readonly<Record<string, OrcMaterialSymbolMetadata>>;

export { ORC_MATERIAL_SYMBOLS, ORC_MATERIAL_SYMBOL_CATALOG };
