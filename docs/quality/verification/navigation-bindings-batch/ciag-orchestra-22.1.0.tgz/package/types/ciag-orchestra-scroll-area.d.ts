import * as _angular_core from '@angular/core';
import { AfterViewInit, ElementRef } from '@angular/core';

type ScrollAreaOrientation = 'vertical' | 'horizontal' | 'both';
declare class ScrollAreaComponent implements AfterViewInit {
    private readonly host;
    readonly orientation: _angular_core.InputSignal<ScrollAreaOrientation>;
    readonly maxHeight: _angular_core.InputSignal<string | number>;
    readonly maxWidth: _angular_core.InputSignal<string | number>;
    readonly alwaysShowScrollbar: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly scrolled: _angular_core.OutputEmitterRef<{
        top: number;
        left: number;
    }>;
    readonly canScrollBack: _angular_core.WritableSignal<boolean>;
    readonly canScrollForward: _angular_core.WritableSignal<boolean>;
    readonly viewportStyle: _angular_core.Signal<{
        'max-height': string | number | null;
        'max-width': string | number | null;
    }>;
    readonly viewport: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    ngAfterViewInit(): void;
    private measure;
    onScroll(event: Event): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollAreaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ScrollAreaComponent, "orc-scroll-area", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "maxWidth": { "alias": "maxWidth"; "required": false; "isSignal": true; }; "alwaysShowScrollbar": { "alias": "alwaysShowScrollbar"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "scrolled": "scrolled"; }, never, ["*"], true, never>;
}

export { ScrollAreaComponent };
export type { ScrollAreaOrientation };
