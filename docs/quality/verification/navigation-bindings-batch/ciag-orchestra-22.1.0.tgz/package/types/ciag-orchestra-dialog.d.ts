export { ModalComponent as Dialog, ModalComponent as DialogComponent, ModalRef as DialogRef, ModalService as DialogService } from '@ciag/orchestra/modal';
