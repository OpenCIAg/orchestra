export { ModalComponent as DynamicDialogComponent, ModalRef as DynamicDialogRef, ModalService as DynamicDialogService } from '@ciag/orchestra/modal';
