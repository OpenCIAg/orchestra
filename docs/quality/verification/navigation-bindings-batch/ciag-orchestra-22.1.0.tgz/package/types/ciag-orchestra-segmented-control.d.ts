import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

interface SegmentedControlOption<T = unknown> {
    label: string;
    value: T;
    icon?: string;
    disabled?: boolean;
}
declare class SegmentedControlComponent<T = unknown> implements ControlValueAccessor {
    readonly options: _angular_core.InputSignal<SegmentedControlOption<T>[]>;
    readonly value: _angular_core.ModelSignal<T | null>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly change: _angular_core.OutputEmitterRef<T>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        value: T;
    }>;
    /** Compatibility output retained for the P2 import path. */
    readonly valueChangeEvent: _angular_core.OutputEmitterRef<T>;
    readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    private readonly focusedIndex;
    readonly segments: _angular_core.Signal<readonly ElementRef<HTMLButtonElement>[]>;
    private readonly host;
    private onModelChange;
    private onTouched;
    readonly tabStopIndex: _angular_core.Signal<number>;
    writeValue(value: T | null): void;
    registerOnChange(fn: (value: T | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(value: boolean): void;
    isSelected(option: SegmentedControlOption<T>): boolean;
    isTabStop(option: SegmentedControlOption<T>): boolean;
    onKeydown(event: KeyboardEvent, index?: number): void;
    select(option: SegmentedControlOption<T>): void;
    onFocus(index: number): void;
    onFocusOut(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SegmentedControlComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SegmentedControlComponent<any>, "orc-segmented-control", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "change": "change"; "onChange": "onChange"; "valueChangeEvent": "valueChangeEvent"; }, never, never, true, never>;
}

export { SegmentedControlComponent };
export type { SegmentedControlOption };
