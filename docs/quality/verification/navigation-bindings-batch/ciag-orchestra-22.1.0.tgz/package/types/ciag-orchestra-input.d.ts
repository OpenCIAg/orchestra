import * as _angular_core from '@angular/core';
import { ElementRef, AfterViewInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type InputType = 'text' | 'password' | 'email' | 'number' | 'search' | 'tel' | 'url';
type InputSize = 'sm' | 'md' | 'lg';
type InputStatus = 'default' | 'error' | 'success';
type TextareaResize = 'none' | 'vertical' | 'horizontal' | 'both';

/**
 * Utilitário de máscara leve e sem dependências externas.
 * Suporta tokens padrão:
 * - `0` ou `9`: Apenas dígitos numéricos (0-9)
 * - `A` ou `a`: Apenas letras (a-z, A-Z)
 * - `*`: Alfanumérico (letras e números)
 */
declare function applyMask(rawVal: string, maskPattern: string): string;
declare function cleanMask(formattedVal: string, maskPattern: string): string;

declare class InputComponent implements ControlValueAccessor {
    private readonly uniqueId;
    readonly nativeInputRef: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly id: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<InputType>;
    readonly size: _angular_core.InputSignal<InputSize>;
    readonly status: _angular_core.InputSignal<InputStatus>;
    /** Optional consumer-provided hint. The library never invents placeholder copy. */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly clearable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly mask: _angular_core.InputSignal<string>;
    readonly unmaskValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maxLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly minLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly min: _angular_core.InputSignal<string | number | undefined>;
    readonly max: _angular_core.InputSignal<string | number | undefined>;
    readonly step: _angular_core.InputSignal<string | number | undefined>;
    readonly showCharCount: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly prefixText: _angular_core.InputSignal<string>;
    readonly suffixText: _angular_core.InputSignal<string>;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly clearAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly showPasswordAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly hidePasswordAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<string | number>;
    readonly inputChange: _angular_core.OutputEmitterRef<string | number>;
    readonly blur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly focus: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly clear: _angular_core.OutputEmitterRef<void>;
    protected readonly isFocused: _angular_core.WritableSignal<boolean>;
    protected readonly isPasswordVisible: _angular_core.WritableSignal<boolean>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    /**
     * Keeps browser editing state independent from the public model input.
     * Angular may re-apply a parent model value during the same input event;
     * binding the native control to this writable state prevents keystrokes
     * from being visually rolled back before the parent receives valueChange.
     */
    protected readonly viewValue: _angular_core.WritableSignal<string | number>;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly helperId: _angular_core.Signal<string>;
    readonly errorId: _angular_core.Signal<string>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly currentType: _angular_core.Signal<InputType>;
    readonly stringValue: _angular_core.Signal<string>;
    readonly charCount: _angular_core.Signal<number>;
    readonly effectiveMaxLength: _angular_core.Signal<number | undefined>;
    readonly isClearVisible: _angular_core.Signal<boolean>;
    readonly isPasswordToggleVisible: _angular_core.Signal<boolean>;
    readonly computedAriaDescribedBy: _angular_core.Signal<string | null>;
    private onChange;
    private onTouched;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    protected onInput(event: Event): void;
    protected onFocus(event: FocusEvent): void;
    protected onBlur(event: FocusEvent): void;
    protected onClear(event: MouseEvent): void;
    protected togglePasswordVisibility(event: MouseEvent): void;
    focusNative(): void;
    select(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputComponent, "orc-input, orc-input-text", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "unmaskValue": { "alias": "unmaskValue"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "showCharCount": { "alias": "showCharCount"; "required": false; "isSignal": true; }; "prefixText": { "alias": "prefixText"; "required": false; "isSignal": true; }; "suffixText": { "alias": "suffixText"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "showPasswordAriaLabel": { "alias": "showPasswordAriaLabel"; "required": false; "isSignal": true; }; "hidePasswordAriaLabel": { "alias": "hidePasswordAriaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "ariaDescribedby"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "inputChange": "inputChange"; "blur": "blur"; "focus": "focus"; "clear": "clear"; }, never, ["[prefix], [orcPrefix]", "[suffix], [orcSuffix]"], true, never>;
}

declare class TextareaComponent implements ControlValueAccessor, AfterViewInit {
    private readonly uniqueId;
    readonly nativeTextareaRef: _angular_core.Signal<ElementRef<HTMLTextAreaElement> | undefined>;
    readonly id: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<InputSize>;
    readonly status: _angular_core.InputSignal<InputStatus>;
    /** Optional consumer-provided hint. The library never invents placeholder copy. */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly helperText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rows: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly cols: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly resize: _angular_core.InputSignal<TextareaResize>;
    readonly autoResize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maxLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly minLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly showCharCount: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly inputChange: _angular_core.OutputEmitterRef<string>;
    readonly blur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly focus: _angular_core.OutputEmitterRef<FocusEvent>;
    protected readonly isFocused: _angular_core.WritableSignal<boolean>;
    protected readonly cvaDisabled: _angular_core.WritableSignal<boolean>;
    /** Writable browser state that cannot be rolled back mid-keystroke. */
    protected readonly viewValue: _angular_core.WritableSignal<string>;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly helperId: _angular_core.Signal<string>;
    readonly errorId: _angular_core.Signal<string>;
    readonly effectiveDisabled: _angular_core.Signal<boolean>;
    readonly stringValue: _angular_core.Signal<string>;
    readonly charCount: _angular_core.Signal<number>;
    readonly computedAriaDescribedBy: _angular_core.Signal<string | null>;
    private onChange;
    private onTouched;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    ngAfterViewInit(): void;
    protected onInput(event: Event): void;
    protected onFocus(event: FocusEvent): void;
    protected onBlur(event: FocusEvent): void;
    private adjustHeight;
    focusNative(): void;
    select(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextareaComponent, "orc-textarea, orc-input-textarea", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "cols": { "alias": "cols"; "required": false; "isSignal": true; }; "resize": { "alias": "resize"; "required": false; "isSignal": true; }; "autoResize": { "alias": "autoResize"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "showCharCount": { "alias": "showCharCount"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "ariaDescribedby"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "inputChange": "inputChange"; "blur": "blur"; "focus": "focus"; }, never, never, true, never>;
}

export { InputComponent, TextareaComponent, applyMask, cleanMask };
export type { InputSize, InputStatus, InputType, TextareaResize };
