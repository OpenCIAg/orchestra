import * as _angular_core from '@angular/core';

type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
type AvatarShape = 'circular' | 'rounded' | 'square';
type AvatarStatus = 'online' | 'offline' | 'busy' | 'away';
type AvatarStatusPosition = 'top-right' | 'bottom-right' | 'top-left' | 'bottom-left';
type AvatarColorVariant = 'default' | 'primary' | 'royal' | 'orange' | 'purple' | 'cyan' | 'auto';
interface AvatarItem {
    src?: string;
    name?: string;
    initials?: string;
    alt?: string;
    status?: AvatarStatus;
    colorVariant?: AvatarColorVariant;
}

declare class AvatarComponent {
    readonly src: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly initials: _angular_core.InputSignal<string>;
    readonly alt: _angular_core.InputSignal<string>;
    readonly statusLabel: _angular_core.InputSignal<string | undefined>;
    readonly size: _angular_core.InputSignal<AvatarSize>;
    readonly shape: _angular_core.InputSignal<AvatarShape>;
    readonly status: _angular_core.InputSignal<AvatarStatus | undefined>;
    readonly statusPosition: _angular_core.InputSignal<AvatarStatusPosition>;
    readonly colorVariant: _angular_core.InputSignal<AvatarColorVariant>;
    readonly bordered: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly imageError: _angular_core.OutputEmitterRef<Event>;
    readonly avatarClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly imageFailed: _angular_core.WritableSignal<boolean>;
    constructor();
    readonly showImage: _angular_core.Signal<boolean>;
    readonly computedInitials: _angular_core.Signal<string>;
    readonly hasInitials: _angular_core.Signal<boolean>;
    readonly showIcon: _angular_core.Signal<boolean>;
    readonly effectiveColorVariant: _angular_core.Signal<AvatarColorVariant>;
    readonly accessibleLabel: _angular_core.Signal<string | undefined>;
    readonly statusText: _angular_core.Signal<string>;
    onImageError(event: Event): void;
    onClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AvatarComponent, "orc-avatar", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "initials": { "alias": "initials"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "statusLabel": { "alias": "statusLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "statusPosition": { "alias": "statusPosition"; "required": false; "isSignal": true; }; "colorVariant": { "alias": "colorVariant"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "imageError": "imageError"; "avatarClick": "avatarClick"; }, never, never, true, never>;
}

declare class AvatarGroupComponent {
    readonly items: _angular_core.InputSignal<AvatarItem[]>;
    readonly max: _angular_core.InputSignal<number>;
    readonly size: _angular_core.InputSignal<AvatarSize>;
    readonly shape: _angular_core.InputSignal<AvatarShape>;
    readonly excessCount: _angular_core.InputSignal<number>;
    readonly excessColorVariant: _angular_core.InputSignal<AvatarColorVariant>;
    readonly bordered: _angular_core.InputSignal<boolean>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly visibleItems: _angular_core.Signal<AvatarItem[]>;
    readonly calculatedExcess: _angular_core.Signal<number>;
    readonly excessText: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AvatarGroupComponent, "orc-avatar-group", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "excessCount": { "alias": "excessCount"; "required": false; "isSignal": true; }; "excessColorVariant": { "alias": "excessColorVariant"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { AvatarComponent, AvatarGroupComponent };
export type { AvatarColorVariant, AvatarItem, AvatarShape, AvatarSize, AvatarStatus, AvatarStatusPosition };
