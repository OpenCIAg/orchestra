export { MenuComponent, PrimeMenuItem as MenuItem } from '@ciag/orchestra/p2';
