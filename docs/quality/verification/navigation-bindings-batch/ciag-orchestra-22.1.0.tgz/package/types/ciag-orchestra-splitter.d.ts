export { SplitterComponent, SplitterPanel } from '@ciag/orchestra/p2';
