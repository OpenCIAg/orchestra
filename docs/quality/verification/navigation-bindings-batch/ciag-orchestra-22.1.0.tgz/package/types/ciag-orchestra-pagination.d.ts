export { PaginatorComponent as PaginationComponent, PageChangeEvent as PaginationPageEvent } from '@ciag/orchestra/paginator';
