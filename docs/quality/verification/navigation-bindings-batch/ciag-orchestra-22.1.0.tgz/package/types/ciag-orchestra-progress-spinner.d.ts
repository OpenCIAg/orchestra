export { ProgressSpinnerComponent as ProgressSpinner, ProgressSpinnerComponent } from '@ciag/orchestra/progress';
