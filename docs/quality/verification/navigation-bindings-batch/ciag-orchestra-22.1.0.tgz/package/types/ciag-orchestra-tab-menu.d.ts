import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

interface TabMenuItem {
    label?: string;
    icon?: string;
    disabled?: boolean;
    visible?: boolean;
    command?: (event?: Event) => void;
    routerLink?: string | unknown[];
    [key: string]: unknown;
}
declare class TabMenuComponent {
    readonly model: _angular_core.InputSignal<TabMenuItem[]>;
    readonly activeItem: _angular_core.ModelSignal<TabMenuItem | undefined>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly itemSelect: _angular_core.OutputEmitterRef<TabMenuItem>;
    readonly effectiveAriaLabel: _angular_core.Signal<string | undefined>;
    readonly visibleItems: _angular_core.Signal<TabMenuItem[]>;
    readonly enabledItems: _angular_core.Signal<TabMenuItem[]>;
    readonly tabItems: _angular_core.Signal<readonly ElementRef<HTMLButtonElement>[]>;
    readonly selectedItem: _angular_core.Signal<TabMenuItem>;
    isActive(item: TabMenuItem): boolean;
    /**
     * @deprecated Popup mode has no trigger or open-state API and therefore has no effect.
     * Use MenuComponent for popup navigation.
     */
    readonly popup: _angular_core.InputSignalWithTransform<boolean, unknown>;
    hasRouterLink(item: TabMenuItem): boolean;
    trackItem(item: TabMenuItem, index: number): unknown;
    activate(item: TabMenuItem, event: Event): void;
    onKeydown(event: KeyboardEvent, index: number): void;
    private isRtl;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabMenuComponent, "orc-tab-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "activeItem": { "alias": "activeItem"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "popup": { "alias": "popup"; "required": false; "isSignal": true; }; }, { "activeItem": "activeItemChange"; "itemSelect": "itemSelect"; }, never, never, true, never>;
}

export { TabMenuComponent };
export type { TabMenuItem };
