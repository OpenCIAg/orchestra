export { SpeedDialAction, SpeedDialComponent } from '@ciag/orchestra/p2';
