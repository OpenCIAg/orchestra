export { ConfirmPopupComponent, ConfirmPopupService, PopupConfirmation } from '@ciag/orchestra/p2';
