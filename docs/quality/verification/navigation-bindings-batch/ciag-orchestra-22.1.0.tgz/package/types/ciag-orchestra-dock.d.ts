export { DockComponent, DockItem } from '@ciag/orchestra/p2';
