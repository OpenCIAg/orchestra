import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

interface ListItem {
    id: string;
    label: string;
    description?: string;
    disabled?: boolean;
    selected?: boolean;
}
declare class ListComponent {
    readonly items: _angular_core.InputSignal<ListItem[]>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    readonly selection: _angular_core.InputSignal<"none" | "single" | "multiple">;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly selectedIds: _angular_core.ModelSignal<string[]>;
    readonly itemSelect: _angular_core.OutputEmitterRef<ListItem>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly listItems: _angular_core.Signal<readonly ElementRef<HTMLButtonElement>[]>;
    isSelected(item: ListItem): boolean;
    select(item: ListItem): void;
    onKeydown(event: KeyboardEvent, index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ListComponent, "orc-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "selectedIds": { "alias": "selectedIds"; "required": false; "isSignal": true; }; }, { "selectedIds": "selectedIdsChange"; "itemSelect": "itemSelect"; }, never, never, true, never>;
}

export { ListComponent };
export type { ListItem };
