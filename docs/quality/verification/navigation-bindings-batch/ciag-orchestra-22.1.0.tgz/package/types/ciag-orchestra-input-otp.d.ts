export { OtpInputComponent as InputOtp, OtpInputComponent as InputOtpComponent } from '@ciag/orchestra/otp-input';
