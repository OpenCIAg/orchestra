import * as _ciag_orchestra_radio from '@ciag/orchestra/radio';
import * as _angular_core from '@angular/core';
import { InjectionToken, Signal, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

interface RadioButtonItem {
    readonly value: Signal<any>;
    readonly isDisabled: Signal<boolean>;
    focus(): void;
}
interface RadioGroupContext {
    readonly name: Signal<string>;
    readonly value: Signal<any>;
    readonly isDisabled: Signal<boolean>;
    readonly isError: Signal<boolean>;
    registerRadio(radio: RadioButtonItem): void;
    unregisterRadio(radio: RadioButtonItem): void;
    select(value: any, event?: Event): void;
    hasSelectedRadio(): boolean;
    isFirstEnabled(radio: RadioButtonItem): boolean;
    handleKeydown(event: KeyboardEvent, currentRadio: RadioButtonItem): void;
}
declare const ORC_RADIO_GROUP: InjectionToken<RadioGroupContext>;

declare class RadioButtonComponent implements OnInit, OnDestroy, RadioButtonItem {
    readonly value: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly name: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly tabindex: _angular_core.InputSignal<number | undefined>;
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly binary: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<"outlined" | "filled" | undefined>;
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    readonly select: _angular_core.OutputEmitterRef<any>;
    readonly onClick: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        value: any;
    }>;
    readonly onFocus: _angular_core.OutputEmitterRef<Event>;
    readonly onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly inputElement: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly uniqueId: string;
    readonly radioGroup: _ciag_orchestra_radio.RadioGroupContext | null;
    readonly effectiveId: _angular_core.Signal<string>;
    readonly effectiveName: _angular_core.Signal<string>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isError: _angular_core.Signal<boolean>;
    private readonly standaloneChecked;
    readonly isChecked: _angular_core.Signal<boolean>;
    readonly checked: _angular_core.WritableSignal<boolean | null>;
    readonly tabIndex: _angular_core.Signal<0 | -1>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onSelect(event?: Event): void;
    onKeyDown(event: KeyboardEvent): void;
    focus(): void;
    onFocusEvent(event: Event): void;
    onBlurEvent(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioButtonComponent, "orc-radio-button", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "select": "select"; "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, ["*", "*"], true, never>;
}

declare class RadioGroupComponent implements ControlValueAccessor, RadioGroupContext {
    readonly name: _angular_core.InputSignal<string>;
    readonly layout: _angular_core.InputSignal<"vertical" | "horizontal">;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<any>;
    readonly onChange: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        value: any;
    }>;
    private readonly cvaDisabled;
    private readonly radios;
    readonly groupId: string;
    readonly labelId: string;
    readonly hintId: string;
    readonly errorId: string;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isError: _angular_core.Signal<boolean>;
    private onModelChange;
    private onTouched;
    writeValue(val: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    registerRadio(radio: RadioButtonItem): void;
    unregisterRadio(radio: RadioButtonItem): void;
    select(val: any, originalEvent?: Event): void;
    hasSelectedRadio(): boolean;
    isFirstEnabled(radio: RadioButtonItem): boolean;
    handleKeydown(event: KeyboardEvent, currentRadio: RadioButtonItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioGroupComponent, "orc-radio-group", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "onChange": "onChange"; }, never, ["*"], true, never>;
}

export { ORC_RADIO_GROUP, RadioButtonComponent, RadioGroupComponent };
export type { RadioButtonItem, RadioGroupContext };
