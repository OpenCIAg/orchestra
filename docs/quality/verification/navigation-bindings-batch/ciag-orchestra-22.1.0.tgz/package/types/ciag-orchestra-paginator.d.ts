import * as _angular_core from '@angular/core';

interface PageChangeEvent {
    /** PrimeNG-compatible zero-based first row index. */
    first: number;
    /** PrimeNG-compatible rows-per-page value. */
    rows: number;
    /** Página atual selecionada (1-indexed) */
    page: number;
    /** Quantidade de itens por página */
    pageSize: number;
    /** Total de páginas calculadas */
    totalPages: number;
    /** Índice do primeiro item visível (1-indexed) */
    startIndex: number;
    /** Índice do último item visível (1-indexed) */
    endIndex: number;
    /** Total geral de itens */
    totalItems: number;
}
type PageItem = number | 'ellipsis';
type PaginatorSize = 'sm' | 'md' | 'lg';
type PaginatorVariant = 'default' | 'bordered' | 'subtle';

declare class PaginatorComponent {
    /** Total de itens na coleção de dados */
    readonly totalItems: _angular_core.InputSignal<number>;
    /** PrimeNG naming alias for totalItems. */
    readonly totalRecords: _angular_core.InputSignal<number | undefined>;
    /** Quantidade de itens por página (Two-Way Data Binding) */
    readonly pageSize: _angular_core.ModelSignal<number>;
    /** PrimeNG naming alias for pageSize. */
    readonly rowsInput: _angular_core.InputSignal<number | undefined>;
    readonly rows: _angular_core.ModelSignal<number>;
    /** PrimeNG zero-based first-row model. */
    readonly first: _angular_core.ModelSignal<number>;
    /** Página atual selecionada (1-indexed, Two-Way Data Binding) */
    readonly currentPage: _angular_core.ModelSignal<number>;
    /** Optional controlled 1-indexed page alias. */
    readonly pageInput: _angular_core.InputSignal<number | undefined>;
    readonly page: _angular_core.InputSignal<number | undefined>;
    /** Optional controlled zero-indexed page alias. */
    readonly pageIndexInput: _angular_core.InputSignal<number | undefined>;
    readonly pageIndex: _angular_core.InputSignal<number | undefined>;
    /** Opções de quantidade de itens por página */
    readonly pageSizeOptions: _angular_core.InputSignal<number[]>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[] | undefined>;
    /** Se deve exibir o seletor de quantidade de itens por página */
    readonly showPageSizeSelector: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Se deve exibir os botões de Primeira e Última página */
    readonly showFirstLastButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Se deve exibir os botões Anterior e Próximo */
    readonly showPrevNextButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Se deve exibir o texto informativo de total (ex: 1-20 de 100 itens) */
    readonly showTotalInfo: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly currentPageReportTemplate: _angular_core.InputSignal<string | undefined>;
    readonly alwaysShow: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showJumpToPageInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly locale: _angular_core.InputSignal<string | undefined>;
    readonly dropdownAppendTo: _angular_core.InputSignal<string | HTMLElement | null | undefined>;
    readonly appendTo: _angular_core.InputSignal<string | HTMLElement | null | undefined>;
    readonly dropdownScrollHeight: _angular_core.InputSignal<string>;
    readonly templateLeft: _angular_core.InputSignal<unknown>;
    readonly templateRight: _angular_core.InputSignal<unknown>;
    readonly style: _angular_core.InputSignal<Record<string, string> | null>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /** Se o componente está desabilitado */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Tamanho visual do componente ('sm' | 'md' | 'lg') */
    readonly size: _angular_core.InputSignal<PaginatorSize>;
    /** Quantidade máxima de botões numéricos visíveis antes de colapsar */
    readonly maxVisiblePages: _angular_core.InputSignal<number>;
    readonly pageLinkSizeInput: _angular_core.InputSignal<number | undefined>;
    /** Rótulo do botão Anterior */
    readonly previousLabel: _angular_core.InputSignal<string | undefined>;
    /** Rótulo do botão Próximo */
    readonly nextLabel: _angular_core.InputSignal<string | undefined>;
    /** Rótulo do botão Primeira Página */
    readonly firstLabel: _angular_core.InputSignal<string | undefined>;
    /** Rótulo do botão Última Página */
    readonly lastLabel: _angular_core.InputSignal<string | undefined>;
    /** Sufixo exibido no seletor de itens (ex: "20 / Página") */
    readonly itemsPerPageLabel: _angular_core.InputSignal<string | undefined>;
    /** Atributo de acessibilidade aria-label da tag nav */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly jumpAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly pageAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly pageNumberAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly pageSizeAriaLabel: _angular_core.InputSignal<string | undefined>;
    readonly jumpPageInput: _angular_core.ModelSignal<string>;
    private readonly pageSizeOverride;
    private readonly localPageSizeWrite;
    private previousRowsInput;
    private previousPageInput;
    private previousPageIndexInput;
    private previousPageSizeInput;
    private previousFirst;
    private previousPage;
    private previousPageSize;
    /** Disparado sempre que a página ou o pageSize é alterado */
    readonly pageChange: _angular_core.OutputEmitterRef<PageChangeEvent>;
    readonly onPageChange: _angular_core.OutputEmitterRef<PageChangeEvent>;
    readonly effectiveTotalRecords: _angular_core.Signal<number>;
    readonly effectivePageSize: _angular_core.Signal<number>;
    readonly effectivePageSizeOptions: _angular_core.Signal<number[]>;
    readonly effectivePageLinkSize: _angular_core.Signal<number>;
    readonly effectiveShowFirstLast: _angular_core.Signal<boolean>;
    constructor();
    private normalizePageSize;
    private normalizeTotal;
    private normalizeFirst;
    private normalizePage;
    /** Total de páginas calculado dinamicamente */
    readonly totalPages: _angular_core.Signal<number>;
    readonly effectiveCurrentPage: _angular_core.Signal<number>;
    readonly shouldRender: _angular_core.Signal<boolean>;
    /** Índice inicial do intervalo visível (1-indexed) */
    readonly startIndex: _angular_core.Signal<number>;
    /** Índice final do intervalo visível (1-indexed) */
    readonly endIndex: _angular_core.Signal<number>;
    readonly pageReport: _angular_core.Signal<string>;
    /** Se está na primeira página */
    readonly isFirstPage: _angular_core.Signal<boolean>;
    /** Se está na última página */
    readonly isLastPage: _angular_core.Signal<boolean>;
    /** Lista inteligente de páginas e reticências a serem renderizadas */
    readonly visiblePages: _angular_core.Signal<PageItem[]>;
    readonly allPages: _angular_core.Signal<number[]>;
    /** Navega para uma página específica */
    goToPage(page: number): void;
    jumpToPage(): void;
    onJumpInputKeydown(event: KeyboardEvent): void;
    /** Navega para a página anterior */
    prevPage(): void;
    /** Navega para a próxima página */
    nextPage(): void;
    /** Navega para a primeira página */
    firstPage(): void;
    /** Navega para a última página */
    lastPage(): void;
    /** Manipula a mudança de itens por página via select */
    onPageSizeChange(event: Event): void;
    /** Emite o evento unificado de alteração */
    private emitPageChangeEvent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PaginatorComponent, "orc-paginator, orc-pagination", never, { "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "rowsInput": { "alias": "rows"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "pageInput": { "alias": "page"; "required": false; "isSignal": true; }; "pageIndexInput": { "alias": "pageIndex"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; "isSignal": true; }; "showFirstLastButtons": { "alias": "showFirstLastButtons"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPrevNextButtons": { "alias": "showPrevNextButtons"; "required": false; "isSignal": true; }; "showTotalInfo": { "alias": "showTotalInfo"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "alwaysShow": { "alias": "alwaysShow"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showJumpToPageInput": { "alias": "showJumpToPageInput"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "dropdownAppendTo": { "alias": "dropdownAppendTo"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "dropdownScrollHeight": { "alias": "dropdownScrollHeight"; "required": false; "isSignal": true; }; "templateLeft": { "alias": "templateLeft"; "required": false; "isSignal": true; }; "templateRight": { "alias": "templateRight"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "maxVisiblePages": { "alias": "maxVisiblePages"; "required": false; "isSignal": true; }; "pageLinkSizeInput": { "alias": "pageLinkSize"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "firstLabel": { "alias": "firstLabel"; "required": false; "isSignal": true; }; "lastLabel": { "alias": "lastLabel"; "required": false; "isSignal": true; }; "itemsPerPageLabel": { "alias": "itemsPerPageLabel"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "jumpAriaLabel": { "alias": "jumpAriaLabel"; "required": false; "isSignal": true; }; "pageAriaLabel": { "alias": "pageAriaLabel"; "required": false; "isSignal": true; }; "pageNumberAriaLabel": { "alias": "pageNumberAriaLabel"; "required": false; "isSignal": true; }; "pageSizeAriaLabel": { "alias": "pageSizeAriaLabel"; "required": false; "isSignal": true; }; "jumpPageInput": { "alias": "jumpPageInput"; "required": false; "isSignal": true; }; }, { "pageSize": "pageSizeChange"; "first": "firstChange"; "currentPage": "currentPageChange"; "jumpPageInput": "jumpPageInputChange"; "pageChange": "pageChange"; "onPageChange": "onPageChange"; }, never, never, true, never>;
}

export { PaginatorComponent as Paginator, PaginatorComponent };
export type { PageChangeEvent, PageItem, PaginatorSize, PaginatorVariant };
