import * as _angular_core from '@angular/core';
import { AfterContentInit, QueryList, ElementRef } from '@angular/core';

declare class ToolbarItemDirective {
    readonly elementRef: ElementRef<HTMLElement>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor(elementRef: ElementRef<HTMLElement>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToolbarItemDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ToolbarItemDirective, "[orcToolbarItem]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
type ToolbarOrientation = 'horizontal' | 'vertical';
declare class ToolbarComponent implements AfterContentInit {
    readonly items: QueryList<ToolbarItemDirective>;
    readonly orientation: _angular_core.InputSignal<ToolbarOrientation>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    readonly loop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ngAfterContentInit(): void;
    private updateTabStops;
    onFocusIn(): void;
    onKeydown(event: KeyboardEvent): void;
    handleKeydown(event: KeyboardEvent): void;
    handleFocusIn(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToolbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToolbarComponent, "orc-toolbar", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "loop": { "alias": "loop"; "required": false; "isSignal": true; }; }, {}, ["items"], ["*"], true, never>;
}

export { ToolbarComponent, ToolbarItemDirective };
export type { ToolbarOrientation };
