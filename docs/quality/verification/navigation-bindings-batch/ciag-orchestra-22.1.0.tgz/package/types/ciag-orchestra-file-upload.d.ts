export { FileUploaderComponent as FileUpload, FileUploaderComponent as FileUploadComponent } from '@ciag/orchestra/file-uploader';
