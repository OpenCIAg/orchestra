import * as _angular_core from '@angular/core';

type SkeletonVariant = 'text' | 'circular' | 'rectangular';
type SkeletonAnimation = 'shimmer' | 'pulse' | 'wave' | 'none';
interface SkeletonConfig {
    variant?: SkeletonVariant;
    animation?: SkeletonAnimation;
    width?: string | number;
    height?: string | number;
    borderRadius?: string;
    shape?: 'rectangle' | 'square' | 'circle';
    size?: string | number;
    styleClass?: string;
    style?: Record<string, string | number>;
    ariaLabel?: string;
}

declare class SkeletonComponent {
    readonly variant: _angular_core.InputSignal<SkeletonVariant>;
    readonly animation: _angular_core.InputSignal<SkeletonAnimation>;
    readonly shape: _angular_core.InputSignal<"rectangle" | "square" | "circle" | undefined>;
    readonly size: _angular_core.InputSignal<string | number | undefined>;
    readonly width: _angular_core.InputSignal<string | number>;
    readonly height: _angular_core.InputSignal<string | number>;
    readonly borderRadius: _angular_core.InputSignal<string>;
    readonly fitContent: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly display: _angular_core.InputSignal<"block" | "inline-block" | "inline">;
    readonly styleClass: _angular_core.InputSignal<string>;
    readonly style: _angular_core.InputSignal<Record<string, string | number> | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    get hostDisplay(): string;
    get hostWidth(): string;
    readonly hostVerticalAlign = "middle";
    readonly computedWidth: _angular_core.Signal<string>;
    readonly computedHeight: _angular_core.Signal<string>;
    readonly computedBorderRadius: _angular_core.Signal<string>;
    readonly effectiveVariant: _angular_core.Signal<SkeletonVariant>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkeletonComponent, "orc-skeleton", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "borderRadius": { "alias": "borderRadius"; "required": false; "isSignal": true; }; "fitContent": { "alias": "fitContent"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { SkeletonComponent };
export type { SkeletonAnimation, SkeletonConfig, SkeletonVariant };
