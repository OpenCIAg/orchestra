export { PasswordComponent as InputPassword, PasswordComponent as InputPasswordComponent } from '@ciag/orchestra/p2';
