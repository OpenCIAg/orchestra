export * from '@ciag/orchestra/avatar-group';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-avatargroup.mjs.map
