/** Follow the rendered ancestry, including slotted content and shadow roots. */
function parentOf(node) {
    if ('assignedSlot' in node && node.assignedSlot)
        return node.assignedSlot;
    if (node.parentNode)
        return node.parentNode;
    return node.nodeType === 11 && 'host' in node
        ? node.host
        : null;
}
function contains(root, child) {
    for (let node = child; node; node = parentOf(node))
        if (node === root)
            return true;
    return false;
}
/** Own only the background branches outside the current modal and its later overlays. */
function createModalIsolation(document, getLayers) {
    let scopes = [];
    const managed = new Map();
    let observer;
    function restore(element, original) {
        // Preserve a consumer's distinct attribute value if it changed while open.
        if (element.getAttribute('inert') !== '' &&
            element.getAttribute('inert') !== original)
            return;
        if (original === null)
            element.removeAttribute('inert');
        else
            element.setAttribute('inert', original);
    }
    function refresh() {
        const scope = scopes.filter((item) => item.element.isConnected).at(-1);
        const desired = new Set();
        if (scope && document.body) {
            const layers = getLayers();
            let index = layers.length - 1;
            while (index >= 0 && layers[index].element !== scope.element)
                index--;
            const later = index < 0 ? [] : layers.slice(index + 1).map((layer) => layer.element);
            const roots = [scope.element, ...scope.additionalRoots, ...later].filter((element) => element.isConnected);
            const shadowRoots = new Map();
            for (const root of roots) {
                for (let node = root; node; node = parentOf(node)) {
                    if (node.nodeType === 11 && 'host' in node) {
                        const shadow = node;
                        shadowRoots.set(shadow.host, shadow);
                    }
                }
            }
            const visit = (container) => {
                for (const child of Array.from(container.children)) {
                    if (roots.some((root) => contains(root, child)))
                        continue;
                    if (roots.some((root) => contains(child, root))) {
                        visit(child);
                        const shadow = shadowRoots.get(child);
                        if (shadow)
                            visit(shadow);
                    }
                    else if (!child.matches('script, style, link, meta, template'))
                        desired.add(child);
                }
            };
            visit(document.body);
            for (const shadow of shadowRoots.values())
                observer?.observe(shadow, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['inert'],
                });
        }
        if (!scopes.length) {
            observer?.disconnect();
            observer = undefined;
        }
        for (const [element, original] of managed) {
            if (!desired.has(element)) {
                restore(element, original);
                managed.delete(element);
            }
        }
        for (const element of desired) {
            if (!managed.has(element))
                managed.set(element, element.getAttribute('inert'));
            if (!element.hasAttribute('inert'))
                element.setAttribute('inert', '');
        }
    }
    function register(element, additionalRoots = []) {
        const scope = { element, additionalRoots };
        scopes.push(scope);
        if (!observer && document.body && typeof MutationObserver !== 'undefined') {
            observer = new MutationObserver(refresh);
            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['inert'],
            });
        }
        refresh();
        let released = false;
        return () => {
            if (released)
                return;
            released = true;
            scopes = scopes.filter((item) => item !== scope);
            refresh();
        };
    }
    return { register, refresh };
}

function parentElement(element) {
    return (element.assignedSlot ??
        element.parentElement ??
        element.getRootNode().host ??
        null);
}
function overlayContains(root, child) {
    for (let current = child; current; current = parentElement(current))
        if (current === root)
            return true;
    return false;
}
/** Locate the native modal that owns an anchor, including anchors in shadow DOM. */
function nativeModalFor(anchor) {
    let current = anchor;
    while (current) {
        if (current.matches('dialog:modal'))
            return current;
        current = parentElement(current);
    }
    return null;
}
/** A popup must remain a descendant of its native modal to escape native inertness. */
function overlayAttachmentTarget(anchor, requested, fallback = anchor) {
    const document = anchor.ownerDocument;
    let target = fallback;
    if (requested === 'body')
        target = document.body;
    else if (typeof HTMLElement !== 'undefined' &&
        requested instanceof HTMLElement)
        target = requested;
    else if (typeof requested === 'string' && requested !== 'self') {
        try {
            target = document.querySelector(requested) ?? fallback;
        }
        catch {
            // An invalid selector has the same fallback as a missing target.
        }
    }
    const modal = nativeModalFor(anchor);
    return modal && nativeModalFor(target) !== modal ? modal : target;
}

const documents = new WeakMap();
function stateFor(document) {
    let state = documents.get(document);
    if (!state) {
        state = {
            layers: [],
            locks: 0,
            overflow: '',
            overflowPriority: '',
            isolation: createModalIsolation(document, () => documents.get(document)?.layers ?? []),
        };
        documents.set(document, state);
    }
    return state;
}
function registerOverlay(element, options = {}) {
    const state = stateFor(element.ownerDocument);
    const layer = {
        element,
        interactive: options.interactive !== false,
        parent: state.layers
            .slice()
            .reverse()
            .find((candidate) => candidate.interactive &&
            (overlayContains(candidate.element, options.anchor ?? element) ||
                overlayContains(candidate.element, element))),
        onParentClose: options.onParentClose,
    };
    state.layers.push(layer);
    state.isolation.refresh();
    let released = false;
    return () => {
        if (released)
            return;
        released = true;
        const descendants = state.layers.filter((candidate) => {
            for (let parent = candidate.parent; parent; parent = parent.parent)
                if (parent === layer)
                    return true;
            return false;
        });
        state.layers = state.layers.filter((candidate) => candidate !== layer && !descendants.includes(candidate));
        // Close deepest children first. Each child can safely release its own registration.
        for (const child of descendants.reverse())
            child.onParentClose?.();
        state.isolation.refresh();
    };
}
function isTopOverlay(element) {
    const layers = stateFor(element.ownerDocument).layers.filter((layer) => layer.interactive && layer.element.isConnected);
    return layers.length === 0 || layers[layers.length - 1].element === element;
}
function isolateModalBackground(element, additionalRoots = []) {
    return stateFor(element.ownerDocument).isolation.register(element, additionalRoots);
}
/** Each caller receives an idempotent release function that preserves consumer inline styles. */
function lockDocumentScroll(document) {
    const body = document.body;
    if (!body)
        return () => { };
    const state = stateFor(document);
    if (state.locks++ === 0) {
        state.overflow = body.style.getPropertyValue('overflow');
        state.overflowPriority = body.style.getPropertyPriority('overflow');
        body.style.setProperty('overflow', 'hidden');
    }
    let released = false;
    return () => {
        if (released)
            return;
        released = true;
        if (--state.locks === 0) {
            if (state.overflow)
                body.style.setProperty('overflow', state.overflow, state.overflowPriority);
            else
                body.style.removeProperty('overflow');
        }
    };
}
function eventIsInside(event, roots) {
    const path = event.composedPath?.() ?? [];
    return roots.some((root) => root &&
        (path.includes(root) ||
            (event.target != null && root.contains(event.target))));
}
/** Capture phase also observes interactions inside consumers that stop bubbling events. */
function listenForOutsideInteraction(document, roots, onOutside) {
    const listener = (event) => {
        if (!eventIsInside(event, roots()))
            onOutside(event);
    };
    document.addEventListener('pointerdown', listener, true);
    document.addEventListener('click', listener, true);
    return () => {
        document.removeEventListener('pointerdown', listener, true);
        document.removeEventListener('click', listener, true);
    };
}
function isAvailableFocusTarget(element) {
    return (!element.matches(':disabled, [aria-disabled="true"]') &&
        !element.closest('[hidden], [inert], [aria-hidden="true"]') &&
        element.getClientRects().length > 0 &&
        element.ownerDocument.defaultView?.getComputedStyle(element).visibility !==
            'hidden');
}
function focusableElements(container) {
    return Array.from(container.querySelectorAll('button, [href], input, select, textarea, [tabindex], [contenteditable="true"]')).filter((element) => element.tabIndex >= 0 && isAvailableFocusTarget(element));
}
function focusInitialElement(container) {
    const preferred = Array.from(container.querySelectorAll('[autofocus], [cdkFocusInitial]')).find((element) => (element.tabIndex >= 0 || element.hasAttribute('tabindex')) &&
        isAvailableFocusTarget(element));
    (preferred ?? focusableElements(container)[0] ?? container).focus({
        preventScroll: true,
    });
}
function trapTabKey(event, container) {
    if (event.key !== 'Tab' || event.defaultPrevented || !isTopOverlay(container))
        return;
    const elements = focusableElements(container);
    const first = elements[0];
    const last = elements[elements.length - 1];
    const active = container.ownerDocument.activeElement;
    if (!first) {
        event.preventDefault();
        container.focus({ preventScroll: true });
    }
    else if (event.shiftKey &&
        (active === first || !elements.includes(active))) {
        event.preventDefault();
        last.focus();
    }
    else if (!event.shiftKey &&
        (active === last || !elements.includes(active))) {
        event.preventDefault();
        first.focus();
    }
}

/** Resolve viewport geometry independently from DOM attachment and lifecycle. */
function positionOverlayPanel(origin, panel, viewport, requested, align, rtl = false, gap = 8) {
    const opposite = {
        top: 'bottom',
        bottom: 'top',
        left: 'right',
        right: 'left',
    };
    const available = {
        top: origin.top,
        bottom: viewport.height - origin.bottom,
        left: origin.left,
        right: viewport.width - origin.right,
    };
    const required = requested === 'top' || requested === 'bottom'
        ? panel.height + gap
        : panel.width + gap;
    const placement = required > available[requested] &&
        available[opposite[requested]] > available[requested]
        ? opposite[requested]
        : requested;
    const horizontal = placement === 'top' || placement === 'bottom';
    const crossAlignment = horizontal && rtl && align !== 'center'
        ? align === 'start'
            ? 'end'
            : 'start'
        : align;
    let left = placement === 'left'
        ? origin.left - panel.width - gap
        : placement === 'right'
            ? origin.right + gap
            : origin.left;
    let top = placement === 'top'
        ? origin.top - panel.height - gap
        : placement === 'bottom'
            ? origin.bottom + gap
            : origin.top;
    if (horizontal && crossAlignment === 'center')
        left += (origin.width - panel.width) / 2;
    else if (horizontal && crossAlignment === 'end')
        left += origin.width - panel.width;
    else if (!horizontal && crossAlignment === 'center')
        top += (origin.height - panel.height) / 2;
    else if (!horizontal && crossAlignment === 'end')
        top += origin.height - panel.height;
    return {
        left: Math.max(gap, Math.min(left, viewport.width - panel.width - gap)),
        top: Math.max(gap, Math.min(top, viewport.height - panel.height - gap)),
        placement,
    };
}

/**
 * Attach an already-rendered popup without losing its Angular view ownership.
 * Native popovers escape clipping while retaining inherited styles and dialog
 * ancestry. The fallback portals to the document (or owning native dialog).
 * Consumers constrain their content with the available-width/height variables.
 */
function attachAnchoredPopup(anchor, panel, appendTo) {
    const document = anchor.ownerDocument;
    const view = document.defaultView;
    const parent = panel.parentElement;
    if (!view || !parent || !panel.isConnected)
        return () => { };
    const nextSibling = panel.nextSibling;
    const native = typeof panel.showPopover === 'function';
    const target = overlayAttachmentTarget(anchor, appendTo, native ? parent : document.body);
    const properties = [
        'position',
        'inset',
        'left',
        'top',
        'margin',
        '--orc-popup-available-width',
        '--orc-popup-available-height',
    ];
    const original = properties.map((name) => ({
        name,
        value: panel.style.getPropertyValue(name),
        priority: panel.style.getPropertyPriority(name),
    }));
    if (target !== parent)
        target.appendChild(panel);
    panel.style.position = native ? 'fixed' : 'absolute';
    panel.style.inset = 'auto';
    panel.style.margin = '0';
    if (native) {
        panel.setAttribute('popover', 'manual');
        panel.showPopover();
    }
    let frame = 0;
    let disposed = false;
    const position = () => {
        frame = 0;
        if (disposed || !panel.isConnected || !anchor.isConnected)
            return;
        const viewport = view.visualViewport;
        const width = Math.min(viewport?.width ?? view.innerWidth, document.documentElement.clientWidth || view.innerWidth);
        const height = viewport?.height ?? view.innerHeight;
        const offsetLeft = viewport?.offsetLeft ?? 0;
        const offsetTop = viewport?.offsetTop ?? 0;
        const rect = anchor.getBoundingClientRect();
        const availableHeight = Math.max(rect.top - offsetTop - 16, height - (rect.bottom - offsetTop) - 16);
        panel.style.setProperty('--orc-popup-available-width', `${Math.max(0, width - 16)}px`);
        panel.style.setProperty('--orc-popup-available-height', `${Math.max(0, Math.min(height - 16, availableHeight))}px`);
        const result = positionOverlayPanel({
            left: rect.left - offsetLeft,
            right: rect.right - offsetLeft,
            top: rect.top - offsetTop,
            bottom: rect.bottom - offsetTop,
            width: rect.width,
            height: rect.height,
        }, panel.getBoundingClientRect(), { width, height }, 'bottom', 'start', view.getComputedStyle(anchor).direction === 'rtl');
        let left = result.left + offsetLeft;
        let top = result.top + offsetTop;
        if (!native) {
            const offsetParent = panel.offsetParent;
            if (offsetParent &&
                view.getComputedStyle(offsetParent).position !== 'static') {
                const bounds = offsetParent.getBoundingClientRect();
                left += offsetParent.scrollLeft - bounds.left - offsetParent.clientLeft;
                top += offsetParent.scrollTop - bounds.top - offsetParent.clientTop;
            }
            else {
                left += view.scrollX;
                top += view.scrollY;
            }
        }
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
    };
    const schedule = () => {
        if (!disposed && !frame)
            frame = view.requestAnimationFrame(position);
    };
    position();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(schedule);
    observer?.observe(anchor);
    observer?.observe(panel);
    view.addEventListener('resize', schedule);
    document.addEventListener('scroll', schedule, true);
    view.visualViewport?.addEventListener('resize', schedule);
    view.visualViewport?.addEventListener('scroll', schedule);
    return () => {
        disposed = true;
        if (frame)
            view.cancelAnimationFrame(frame);
        observer?.disconnect();
        view.removeEventListener('resize', schedule);
        document.removeEventListener('scroll', schedule, true);
        view.visualViewport?.removeEventListener('resize', schedule);
        view.visualViewport?.removeEventListener('scroll', schedule);
        if (native) {
            if (panel.isConnected && panel.matches(':popover-open'))
                panel.hidePopover();
            panel.removeAttribute('popover');
        }
        for (const { name, value, priority } of original) {
            if (value)
                panel.style.setProperty(name, value, priority);
            else
                panel.style.removeProperty(name);
        }
        if (target !== parent && panel.isConnected) {
            if (parent.isConnected)
                parent.insertBefore(panel, nextSibling?.parentNode === parent ? nextSibling : null);
            else
                panel.remove();
        }
    };
}

/** Shared implementation helpers. This entry point is not a public component API. */

/**
 * Generated bundle index. Do not edit.
 */

export { attachAnchoredPopup, eventIsInside, focusInitialElement, focusableElements, isTopOverlay, isolateModalBackground, listenForOutsideInteraction, lockDocumentScroll, nativeModalFor, overlayAttachmentTarget, overlayContains, positionOverlayPanel, registerOverlay, trapTabKey };
//# sourceMappingURL=ciag-orchestra-internal.mjs.map
