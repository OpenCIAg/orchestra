import * as i0 from '@angular/core';
import { inject, ElementRef, Injector, model, input, booleanAttribute, numberAttribute, output, signal, computed, afterNextRender, ChangeDetectionStrategy, Component, DestroyRef, viewChildren, viewChild, effect, forwardRef } from '@angular/core';
import * as i1 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { attachAnchoredPopup, registerOverlay, listenForOutsideInteraction, eventIsInside, trapTabKey } from '@ciag/orchestra/internal';

function localDate(year, month, day) {
    const date = new Date(0);
    date.setFullYear(year, month - 1, day);
    date.setHours(0, 0, 0, 0);
    return date;
}
function dateKey(value) {
    if (value instanceof Date) {
        if (!Number.isFinite(value.getTime()))
            return '';
        return `${String(value.getFullYear()).padStart(4, '0')}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}`;
    }
    const key = typeof value === 'string' ? value.slice(0, 10) : '';
    return parseDate(key) ? key : '';
}
/** Parse a calendar date without UTC conversion or JavaScript's invalid-day rollover. */
function parseDate(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if (!match)
        return null;
    const [, year, month, day] = match.map(Number);
    const date = localDate(year, month, day);
    return date.getFullYear() === year &&
        date.getMonth() === month - 1 &&
        date.getDate() === day
        ? date
        : null;
}
function parseTime(value) {
    const match = /^(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(AM|PM))?$/i.exec(value);
    if (!match)
        return null;
    let hour = Number(match[1]);
    const minute = Number(match[2]);
    const second = Number(match[3] ?? 0);
    if (match[4]) {
        if (hour < 1 || hour > 12)
            return null;
        hour = (hour % 12) + (match[4].toUpperCase() === 'PM' ? 12 : 0);
    }
    return hour <= 23 && minute <= 59 && second <= 59
        ? { hour, minute, second }
        : null;
}
function parseDateTime(value, timeOnly = false) {
    if (value instanceof Date)
        return Number.isFinite(value.getTime()) ? new Date(value) : null;
    if (typeof value !== 'string' || !value)
        return null;
    const [day, time] = timeOnly
        ? ['1970-01-01', value]
        : value.split(/[T ](?=\d{1,2}:)/);
    const date = parseDate(day);
    if (!date)
        return null;
    if (time !== undefined) {
        const parts = parseTime(time);
        if (!parts)
            return null;
        date.setHours(parts.hour, parts.minute, parts.second, 0);
    }
    return date;
}
function pad(value) {
    return String(value).padStart(2, '0');
}
function timeString(value, seconds) {
    return `${pad(value.hour)}:${pad(value.minute)}${seconds ? `:${pad(value.second)}` : ''}`;
}
function monthKey(value) {
    return dateKey(value).slice(0, 7);
}
function positiveInteger(value, fallback, max = Number.MAX_SAFE_INTEGER) {
    return Number.isFinite(value) && value > 0
        ? Math.min(max, Math.max(1, Math.trunc(value)))
        : fallback;
}
function isoWeekNumber(date) {
    const day = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    day.setUTCDate(day.getUTCDate() + 4 - (day.getUTCDay() || 7));
    return Math.ceil(((day.getTime() - Date.UTC(day.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7);
}

let nextCalendarId = 0;
class DatePickerCalendarComponent {
    document = inject(DOCUMENT);
    host = inject(ElementRef);
    injector = inject(Injector);
    titleId = `orc-calendar-title-${++nextCalendarId}`;
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    selectedValues = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedValues" }] : /* istanbul ignore next */ []));
    currentMonth = model(monthKey(new Date()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentMonth" }] : /* istanbul ignore next */ []));
    min = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabledDates = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledDates" }] : /* istanbul ignore next */ []));
    disabledDays = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledDays" }] : /* istanbul ignore next */ []));
    firstDayOfWeek = input(0, { ...(ngDevMode ? { debugName: "firstDayOfWeek" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    showOtherMonths = input(true, { ...(ngDevMode ? { debugName: "showOtherMonths" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectOtherMonths = input(false, { ...(ngDevMode ? { debugName: "selectOtherMonths" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showWeek = input(false, { ...(ngDevMode ? { debugName: "showWeek" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    embedded = input(false, { ...(ngDevMode ? { debugName: "embedded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    view = input('date', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    locale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "locale" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    previousMonthLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "previousMonthLabel" }] : /* istanbul ignore next */ []));
    nextMonthLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "nextMonthLabel" }] : /* istanbul ignore next */ []));
    weekLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "weekLabel" }] : /* istanbul ignore next */ []));
    monthOffset = input(0, { ...(ngDevMode ? { debugName: "monthOffset" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    dateSelected = output();
    viewDateChange = output();
    focusedDate = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    effectiveLocale = computed(() => this.locale() || this.document.documentElement.lang || undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveLocale" }] : /* istanbul ignore next */ []));
    firstWeekday = computed(() => Number.isFinite(this.firstDayOfWeek())
        ? ((Math.trunc(this.firstDayOfWeek()) % 7) + 7) % 7
        : 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstWeekday" }] : /* istanbul ignore next */ []));
    monthDate = computed(() => {
        const base = parseDate(`${this.currentMonth()}-01`) ?? new Date();
        return localDate(base.getFullYear(), base.getMonth() + 1 + this.monthOffset(), 1);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "monthDate" }] : /* istanbul ignore next */ []));
    monthLabel = computed(() => this.monthDate().toLocaleDateString(this.effectiveLocale(), {
        month: 'long',
        year: 'numeric',
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "monthLabel" }] : /* istanbul ignore next */ []));
    weekdayLabels = computed(() => Array.from({ length: 7 }, (_, index) => new Intl.DateTimeFormat(this.effectiveLocale(), {
        weekday: 'short',
    }).format(new Date(2021, 7, 1 + ((index + this.firstWeekday()) % 7)))), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weekdayLabels" }] : /* istanbul ignore next */ []));
    disabledKeys = computed(() => new Set(this.disabledDates().map(dateKey)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledKeys" }] : /* istanbul ignore next */ []));
    days = computed(() => {
        const month = this.monthDate();
        const offset = (month.getDay() - this.firstWeekday() + 7) % 7;
        const formatter = new Intl.DateTimeFormat(this.effectiveLocale(), {
            dateStyle: 'full',
        });
        return Array.from({ length: 42 }, (_, index) => {
            const date = localDate(month.getFullYear(), month.getMonth() + 1, 1 - offset + index);
            const iso = dateKey(date);
            const inCurrentMonth = date.getMonth() === month.getMonth();
            return {
                iso,
                day: date.getDate(),
                label: formatter.format(date),
                weekNumber: index % 7 === 0 ? isoWeekNumber(localDate(date.getFullYear(), date.getMonth() + 1, date.getDate() + 3)) : undefined,
                inCurrentMonth,
                disabled: !this.isAllowed(date) ||
                    (!inCurrentMonth && !this.selectOtherMonths()),
            };
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []));
    weeks = computed(() => Array.from({ length: 6 }, (_, index) => this.days().slice(index * 7, index * 7 + 7)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weeks" }] : /* istanbul ignore next */ []));
    activeDate = computed(() => {
        const visible = this.days().filter((day) => day.inCurrentMonth || this.showOtherMonths());
        return ([this.focusedDate(), this.value(), dateKey(new Date())].find((key) => key && visible.some((day) => day.iso === key)) ??
            visible.find((day) => day.inCurrentMonth && !day.disabled)?.iso ??
            visible[0]?.iso);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeDate" }] : /* istanbul ignore next */ []));
    months = computed(() => Array.from({ length: 12 }, (_, index) => ({
        index,
        label: localDate(2000, index + 1, 1).toLocaleDateString(this.effectiveLocale(), { month: 'long' }),
        iso: dateKey(localDate(this.monthDate().getFullYear(), index + 1, 1)),
    })), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []));
    years = computed(() => Array.from({ length: 12 }, (_, index) => this.monthDate().getFullYear() - 5 + index), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "years" }] : /* istanbul ignore next */ []));
    periods = computed(() => (this.view() === 'month'
        ? this.months()
        : this.years().map((year) => ({
            label: String(year),
            iso: dateKey(localDate(year, 1, 1)),
        }))).map((period) => ({
        ...period,
        selected: this.isSelected(period.iso),
        selection: this.periodSelection(period.iso),
    })), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "periods" }] : /* istanbul ignore next */ []));
    activePeriod = computed(() => this.periods().find((period) => period.selected && period.selection)
        ?.iso ?? this.periods().find((period) => period.selection)?.iso, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activePeriod" }] : /* istanbul ignore next */ []));
    periodRows = computed(() => Array.from({ length: 4 }, (_, index) => this.periods().slice(index * 3, index * 3 + 3)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "periodRows" }] : /* istanbul ignore next */ []));
    isAllowed(date) {
        const key = dateKey(date);
        return (!this.disabled() &&
            (!this.min() || key >= this.min()) &&
            (!this.max() || key <= this.max()) &&
            !this.disabledDays().includes(date.getDay()) &&
            !this.disabledKeys().has(key));
    }
    periodSelection(iso) {
        const start = parseDate(iso);
        if (!start || this.disabled())
            return null;
        const end = this.view() === 'year'
            ? localDate(start.getFullYear() + 1, 1, 1)
            : localDate(start.getFullYear(), start.getMonth() + 2, 1);
        for (const day = new Date(start); day < end; day.setDate(day.getDate() + 1)) {
            if (this.isAllowed(day))
                return dateKey(day);
        }
        return null;
    }
    isSelected(iso) {
        const length = this.view() === 'month' ? 7 : this.view() === 'year' ? 4 : 10;
        return [...this.selectedValues(), this.value()].some((value) => value && value.slice(0, length) === iso.slice(0, length));
    }
    shift(delta) {
        if (this.disabled())
            return;
        const base = parseDate(`${this.currentMonth()}-01`) ?? new Date();
        const step = this.view() === 'date' ? 1 : this.view() === 'month' ? 12 : 144;
        this.setMonth(localDate(base.getFullYear(), base.getMonth() + 1 + delta * step, 1));
    }
    setMonth(date) {
        this.currentMonth.set(monthKey(date));
        this.viewDateChange.emit({
            month: date.getMonth() + 1,
            year: date.getFullYear(),
        });
    }
    select(iso) {
        const date = parseDate(iso);
        if (!date || this.disabled())
            return;
        if (this.view() === 'date') {
            if (!this.isAllowed(date) ||
                (monthKey(date) !== monthKey(this.monthDate()) &&
                    !this.selectOtherMonths()))
                return;
        }
        else {
            const selected = this.periodSelection(iso);
            if (!selected)
                return;
            iso = selected;
        }
        this.value.set(iso);
        this.dateSelected.emit(iso);
    }
    focusSelected() {
        this.host.nativeElement
            .querySelector('[data-active="true"]')
            ?.focus();
    }
    onDayKeydown(event, iso) {
        const next = parseDate(iso);
        if (!next || this.disabled())
            return;
        switch (event.key) {
            case 'ArrowRight':
                next.setDate(next.getDate() + 1);
                break;
            case 'ArrowLeft':
                next.setDate(next.getDate() - 1);
                break;
            case 'ArrowDown':
                next.setDate(next.getDate() + 7);
                break;
            case 'ArrowUp':
                next.setDate(next.getDate() - 7);
                break;
            case 'Home':
                next.setDate(next.getDate() - ((next.getDay() - this.firstWeekday() + 7) % 7));
                break;
            case 'End':
                next.setDate(next.getDate() + 6 - ((next.getDay() - this.firstWeekday() + 7) % 7));
                break;
            case 'PageUp':
            case 'PageDown': {
                const day = next.getDate();
                next.setDate(1);
                next.setMonth(next.getMonth() +
                    (event.key === 'PageDown' ? 1 : -1) * (event.shiftKey ? 12 : 1));
                next.setDate(Math.min(day, localDate(next.getFullYear(), next.getMonth() + 2, 0).getDate()));
                break;
            }
            default:
                return;
        }
        event.preventDefault();
        this.focusedDate.set(dateKey(next));
        if (monthKey(next) !== monthKey(this.monthDate()))
            this.setMonth(localDate(next.getFullYear(), next.getMonth() + 1 - this.monthOffset(), 1));
        afterNextRender(() => this.focusSelected(), { injector: this.injector });
    }
    onPeriodKeydown(event) {
        const buttons = Array.from(this.host.nativeElement.querySelectorAll('.period-button:not(:disabled)'));
        const index = buttons.indexOf(event.target);
        const delta = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: 3, ArrowUp: -3 }[event.key];
        const next = event.key === 'Home'
            ? 0
            : event.key === 'End'
                ? buttons.length - 1
                : delta === undefined
                    ? -1
                    : Math.max(0, Math.min(buttons.length - 1, index + delta));
        if (next >= 0 && buttons[next]) {
            event.preventDefault();
            buttons.forEach((button, i) => (button.tabIndex = i === next ? 0 : -1));
            buttons[next].focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DatePickerCalendarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: DatePickerCalendarComponent, isStandalone: true, selector: "orc-date-picker-calendar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, selectedValues: { classPropertyName: "selectedValues", publicName: "selectedValues", isSignal: true, isRequired: false, transformFunction: null }, currentMonth: { classPropertyName: "currentMonth", publicName: "currentMonth", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, disabledDates: { classPropertyName: "disabledDates", publicName: "disabledDates", isSignal: true, isRequired: false, transformFunction: null }, disabledDays: { classPropertyName: "disabledDays", publicName: "disabledDays", isSignal: true, isRequired: false, transformFunction: null }, firstDayOfWeek: { classPropertyName: "firstDayOfWeek", publicName: "firstDayOfWeek", isSignal: true, isRequired: false, transformFunction: null }, showOtherMonths: { classPropertyName: "showOtherMonths", publicName: "showOtherMonths", isSignal: true, isRequired: false, transformFunction: null }, selectOtherMonths: { classPropertyName: "selectOtherMonths", publicName: "selectOtherMonths", isSignal: true, isRequired: false, transformFunction: null }, showWeek: { classPropertyName: "showWeek", publicName: "showWeek", isSignal: true, isRequired: false, transformFunction: null }, embedded: { classPropertyName: "embedded", publicName: "embedded", isSignal: true, isRequired: false, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, previousMonthLabel: { classPropertyName: "previousMonthLabel", publicName: "previousMonthLabel", isSignal: true, isRequired: false, transformFunction: null }, nextMonthLabel: { classPropertyName: "nextMonthLabel", publicName: "nextMonthLabel", isSignal: true, isRequired: false, transformFunction: null }, weekLabel: { classPropertyName: "weekLabel", publicName: "weekLabel", isSignal: true, isRequired: false, transformFunction: null }, monthOffset: { classPropertyName: "monthOffset", publicName: "monthOffset", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", currentMonth: "currentMonthChange", dateSelected: "dateSelected", viewDateChange: "viewDateChange" }, ngImport: i0, template: "<section\n  class=\"orc-date-picker-calendar\"\n  [class.orc-date-picker-calendar--embedded]=\"embedded()\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n>\n  <header>\n    <button\n      type=\"button\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"\n        previousMonthLabel() ||\n        (view() === 'date' ? 'Previous month' : 'Previous year')\n      \"\n      (click)=\"shift(-1)\"\n    >\n      \u2039\n    </button>\n    <strong [id]=\"titleId\" aria-live=\"polite\">{{ monthLabel() }}</strong>\n    <button\n      type=\"button\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"\n        nextMonthLabel() || (view() === 'date' ? 'Next month' : 'Next year')\n      \"\n      (click)=\"shift(1)\"\n    >\n      \u203A\n    </button>\n  </header>\n  @if (view() === \"date\") {\n    <table class=\"days\" role=\"grid\" [attr.aria-labelledby]=\"titleId\">\n      <thead>\n        <tr class=\"weekdays\">\n          @if (showWeek()) {\n            <th scope=\"col\" class=\"week-heading\">\n              {{ weekLabel() || \"Week\" }}\n            </th>\n          }\n          @for (day of weekdayLabels(); track $index) {\n            <th scope=\"col\">{{ day }}</th>\n          }\n        </tr>\n      </thead>\n      <tbody>\n        @for (week of weeks(); track week[0].iso) {\n          <tr>\n            @if (showWeek()) {\n              <th\n                scope=\"row\"\n                class=\"week-number\"\n                [attr.aria-label]=\"\n                  (weekLabel() || 'Week') + ' ' + week[0].weekNumber\n                \"\n              >\n                {{ week[0].weekNumber }}\n              </th>\n            }\n            @for (day of week; track day.iso) {\n              <td [attr.aria-selected]=\"isSelected(day.iso)\">\n                @if (showOtherMonths() || day.inCurrentMonth) {\n                  <button\n                    type=\"button\"\n                    [disabled]=\"disabled()\"\n                    [attr.aria-disabled]=\"day.disabled\"\n                    [class.outside]=\"!day.inCurrentMonth\"\n                    [class.unavailable]=\"day.disabled\"\n                    [class.selected]=\"isSelected(day.iso)\"\n                    [attr.aria-label]=\"day.label\"\n                    [attr.data-date]=\"day.iso\"\n                    [attr.data-active]=\"day.iso === activeDate()\"\n                    [tabIndex]=\"day.iso === activeDate() ? 0 : -1\"\n                    (keydown)=\"onDayKeydown($event, day.iso)\"\n                    (click)=\"select(day.iso)\"\n                  >\n                    {{ day.day }}\n                  </button>\n                }\n              </td>\n            }\n          </tr>\n        }\n      </tbody>\n    </table>\n  } @else {\n    <table\n      role=\"grid\"\n      [class]=\"view() === 'month' ? 'month-grid' : 'year-grid'\"\n      [attr.aria-labelledby]=\"titleId\"\n    >\n      <tbody>\n        @for (row of periodRows(); track $index) {\n          <tr>\n            @for (period of row; track period.iso) {\n              <td [attr.aria-selected]=\"period.selected\">\n                <button\n                  type=\"button\"\n                  class=\"period-button\"\n                  [disabled]=\"!period.selection\"\n                  [class.selected]=\"period.selected\"\n                  [attr.data-active]=\"period.iso === activePeriod()\"\n                  [tabIndex]=\"period.iso === activePeriod() ? 0 : -1\"\n                  (keydown)=\"onPeriodKeydown($event)\"\n                  (click)=\"select(period.iso)\"\n                >\n                  {{ period.label }}\n                </button>\n              </td>\n            }\n          </tr>\n        }\n      </tbody>\n    </table>\n  }\n</section>\n", styles: [":host{display:block;flex:0 0 auto;max-width:100%}.orc-date-picker-calendar{box-sizing:border-box;width:20rem;max-width:100%;padding:var(--space-3, .75rem);border:1px solid var(--orc-border-default, #cbd5e1);border-radius:var(--radius-md, .625rem);background:var(--orc-surface-raised, #fff);color:var(--orc-text, #141414);font:inherit}.orc-date-picker-calendar--embedded{border:0;border-radius:0;background:transparent}header{display:grid;grid-template-columns:2.25rem 1fr 2.25rem;align-items:center;gap:var(--space-2, .5rem);margin-block-end:var(--space-2, .5rem);text-align:center}table{width:100%;border-spacing:2px;table-layout:fixed}th,td{padding:0;height:2.25rem;text-align:center}th{font-size:.75rem;font-weight:500;color:var(--orc-text-secondary, #666)}button{box-sizing:border-box;display:grid;place-items:center;width:100%;min-height:2.25rem;padding:var(--space-1, .25rem);border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:inherit;font:inherit;cursor:pointer}header button{font-size:1.5rem}button:hover:not(:disabled):not(.unavailable){background:var(--orc-interactive-soft, #eff6ff)}button:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:-2px}button.selected{background:var(--orc-interactive, #1c6aed);color:var(--orc-on-interactive, #fff)}button.outside{color:var(--orc-text-muted, #737373)}button:disabled,button.unavailable{opacity:.45;cursor:not-allowed}.period-button{min-height:2.75rem;font-size:.875rem}.week-number{width:2rem;font-size:.65rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DatePickerCalendarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-date-picker-calendar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section\n  class=\"orc-date-picker-calendar\"\n  [class.orc-date-picker-calendar--embedded]=\"embedded()\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n>\n  <header>\n    <button\n      type=\"button\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"\n        previousMonthLabel() ||\n        (view() === 'date' ? 'Previous month' : 'Previous year')\n      \"\n      (click)=\"shift(-1)\"\n    >\n      \u2039\n    </button>\n    <strong [id]=\"titleId\" aria-live=\"polite\">{{ monthLabel() }}</strong>\n    <button\n      type=\"button\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"\n        nextMonthLabel() || (view() === 'date' ? 'Next month' : 'Next year')\n      \"\n      (click)=\"shift(1)\"\n    >\n      \u203A\n    </button>\n  </header>\n  @if (view() === \"date\") {\n    <table class=\"days\" role=\"grid\" [attr.aria-labelledby]=\"titleId\">\n      <thead>\n        <tr class=\"weekdays\">\n          @if (showWeek()) {\n            <th scope=\"col\" class=\"week-heading\">\n              {{ weekLabel() || \"Week\" }}\n            </th>\n          }\n          @for (day of weekdayLabels(); track $index) {\n            <th scope=\"col\">{{ day }}</th>\n          }\n        </tr>\n      </thead>\n      <tbody>\n        @for (week of weeks(); track week[0].iso) {\n          <tr>\n            @if (showWeek()) {\n              <th\n                scope=\"row\"\n                class=\"week-number\"\n                [attr.aria-label]=\"\n                  (weekLabel() || 'Week') + ' ' + week[0].weekNumber\n                \"\n              >\n                {{ week[0].weekNumber }}\n              </th>\n            }\n            @for (day of week; track day.iso) {\n              <td [attr.aria-selected]=\"isSelected(day.iso)\">\n                @if (showOtherMonths() || day.inCurrentMonth) {\n                  <button\n                    type=\"button\"\n                    [disabled]=\"disabled()\"\n                    [attr.aria-disabled]=\"day.disabled\"\n                    [class.outside]=\"!day.inCurrentMonth\"\n                    [class.unavailable]=\"day.disabled\"\n                    [class.selected]=\"isSelected(day.iso)\"\n                    [attr.aria-label]=\"day.label\"\n                    [attr.data-date]=\"day.iso\"\n                    [attr.data-active]=\"day.iso === activeDate()\"\n                    [tabIndex]=\"day.iso === activeDate() ? 0 : -1\"\n                    (keydown)=\"onDayKeydown($event, day.iso)\"\n                    (click)=\"select(day.iso)\"\n                  >\n                    {{ day.day }}\n                  </button>\n                }\n              </td>\n            }\n          </tr>\n        }\n      </tbody>\n    </table>\n  } @else {\n    <table\n      role=\"grid\"\n      [class]=\"view() === 'month' ? 'month-grid' : 'year-grid'\"\n      [attr.aria-labelledby]=\"titleId\"\n    >\n      <tbody>\n        @for (row of periodRows(); track $index) {\n          <tr>\n            @for (period of row; track period.iso) {\n              <td [attr.aria-selected]=\"period.selected\">\n                <button\n                  type=\"button\"\n                  class=\"period-button\"\n                  [disabled]=\"!period.selection\"\n                  [class.selected]=\"period.selected\"\n                  [attr.data-active]=\"period.iso === activePeriod()\"\n                  [tabIndex]=\"period.iso === activePeriod() ? 0 : -1\"\n                  (keydown)=\"onPeriodKeydown($event)\"\n                  (click)=\"select(period.iso)\"\n                >\n                  {{ period.label }}\n                </button>\n              </td>\n            }\n          </tr>\n        }\n      </tbody>\n    </table>\n  }\n</section>\n", styles: [":host{display:block;flex:0 0 auto;max-width:100%}.orc-date-picker-calendar{box-sizing:border-box;width:20rem;max-width:100%;padding:var(--space-3, .75rem);border:1px solid var(--orc-border-default, #cbd5e1);border-radius:var(--radius-md, .625rem);background:var(--orc-surface-raised, #fff);color:var(--orc-text, #141414);font:inherit}.orc-date-picker-calendar--embedded{border:0;border-radius:0;background:transparent}header{display:grid;grid-template-columns:2.25rem 1fr 2.25rem;align-items:center;gap:var(--space-2, .5rem);margin-block-end:var(--space-2, .5rem);text-align:center}table{width:100%;border-spacing:2px;table-layout:fixed}th,td{padding:0;height:2.25rem;text-align:center}th{font-size:.75rem;font-weight:500;color:var(--orc-text-secondary, #666)}button{box-sizing:border-box;display:grid;place-items:center;width:100%;min-height:2.25rem;padding:var(--space-1, .25rem);border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:inherit;font:inherit;cursor:pointer}header button{font-size:1.5rem}button:hover:not(:disabled):not(.unavailable){background:var(--orc-interactive-soft, #eff6ff)}button:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:-2px}button.selected{background:var(--orc-interactive, #1c6aed);color:var(--orc-on-interactive, #fff)}button.outside{color:var(--orc-text-muted, #737373)}button:disabled,button.unavailable{opacity:.45;cursor:not-allowed}.period-button{min-height:2.75rem;font-size:.875rem}.week-number{width:2rem;font-size:.65rem}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], selectedValues: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedValues", required: false }] }], currentMonth: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentMonth", required: false }] }, { type: i0.Output, args: ["currentMonthChange"] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], disabledDates: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledDates", required: false }] }], disabledDays: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledDays", required: false }] }], firstDayOfWeek: [{ type: i0.Input, args: [{ isSignal: true, alias: "firstDayOfWeek", required: false }] }], showOtherMonths: [{ type: i0.Input, args: [{ isSignal: true, alias: "showOtherMonths", required: false }] }], selectOtherMonths: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOtherMonths", required: false }] }], showWeek: [{ type: i0.Input, args: [{ isSignal: true, alias: "showWeek", required: false }] }], embedded: [{ type: i0.Input, args: [{ isSignal: true, alias: "embedded", required: false }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], previousMonthLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousMonthLabel", required: false }] }], nextMonthLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextMonthLabel", required: false }] }], weekLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "weekLabel", required: false }] }], monthOffset: [{ type: i0.Input, args: [{ isSignal: true, alias: "monthOffset", required: false }] }], dateSelected: [{ type: i0.Output, args: ["dateSelected"] }], viewDateChange: [{ type: i0.Output, args: ["viewDateChange"] }] } });

let nextDatePickerId = 0;
class DatePickerComponent {
    host = inject(ElementRef);
    document = inject(DOCUMENT);
    destroyRef = inject(DestroyRef);
    uniqueId = `orc-date-picker-${++nextDatePickerId}`;
    calendars = viewChildren(DatePickerCalendarComponent, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calendars" }] : /* istanbul ignore next */ []));
    maxDateCount = input(undefined, { ...(ngDevMode ? { debugName: "maxDateCount" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    hideOnDateTimeSelect = input(true, { ...(ngDevMode ? { debugName: "hideOnDateTimeSelect" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** PrimeNG-compatible value and configuration surface. */
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    min = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    dateFormat = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dateFormat" }] : /* istanbul ignore next */ []));
    selectionMode = input('single', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    showIcon = input(false, { ...(ngDevMode ? { debugName: "showIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showButtonBar = input(false, { ...(ngDevMode ? { debugName: "showButtonBar" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showTime = input(false, { ...(ngDevMode ? { debugName: "showTime" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    timeOnly = input(false, { ...(ngDevMode ? { debugName: "timeOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showSeconds = input(false, { ...(ngDevMode ? { debugName: "showSeconds" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    touchUI = input(false, { ...(ngDevMode ? { debugName: "touchUI" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showWeek = input(false, { ...(ngDevMode ? { debugName: "showWeek" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showOtherMonths = input(true, { ...(ngDevMode ? { debugName: "showOtherMonths" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectOtherMonths = input(false, { ...(ngDevMode ? { debugName: "selectOtherMonths" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonlyInput = input(false, { ...(ngDevMode ? { debugName: "readonlyInput" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    hourFormat = input('24', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hourFormat" }] : /* istanbul ignore next */ []));
    firstDayOfWeek = input(0, { ...(ngDevMode ? { debugName: "firstDayOfWeek" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    numberOfMonths = input(1, { ...(ngDevMode ? { debugName: "numberOfMonths" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    minDate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    maxDate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []));
    disabledDates = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledDates" }] : /* istanbul ignore next */ []));
    disabledDays = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledDays" }] : /* istanbul ignore next */ []));
    view = input('date', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    name = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    panelStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    panelStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    inputStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputStyle" }] : /* istanbul ignore next */ []));
    inputStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputStyleClass" }] : /* istanbul ignore next */ []));
    dataType = input('string', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dataType" }] : /* istanbul ignore next */ []));
    defaultDate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultDate" }] : /* istanbul ignore next */ []));
    viewDate = model(new Date(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewDate" }] : /* istanbul ignore next */ []));
    showOnFocus = input(true, { ...(ngDevMode ? { debugName: "showOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    keepInvalid = input(false, { ...(ngDevMode ? { debugName: "keepInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    focusOnShow = input(true, { ...(ngDevMode ? { debugName: "focusOnShow" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    focusTrap = input(true, { ...(ngDevMode ? { debugName: "focusTrap" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    mask = input(false, { ...(ngDevMode ? { debugName: "mask" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    multipleSeparator = input(', ', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multipleSeparator" }] : /* istanbul ignore next */ []));
    rangeSeparator = input(' - ', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rangeSeparator" }] : /* istanbul ignore next */ []));
    yearNavigator = input(false, { ...(ngDevMode ? { debugName: "yearNavigator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    monthNavigator = input(false, { ...(ngDevMode ? { debugName: "monthNavigator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    yearRange = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "yearRange" }] : /* istanbul ignore next */ []));
    stepHour = input(1, { ...(ngDevMode ? { debugName: "stepHour" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    stepMinute = input(1, { ...(ngDevMode ? { debugName: "stepMinute" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    stepSecond = input(1, { ...(ngDevMode ? { debugName: "stepSecond" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    showTransitionOptions = input('150ms cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input('150ms cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    clearButtonStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearButtonStyleClass" }] : /* istanbul ignore next */ []));
    todayButtonStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "todayButtonStyleClass" }] : /* istanbul ignore next */ []));
    icon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    iconAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconAriaLabel" }] : /* istanbul ignore next */ []));
    iconDisplay = input('button', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconDisplay" }] : /* istanbul ignore next */ []));
    defaultViewDate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultViewDate" }] : /* istanbul ignore next */ []));
    locale = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    panelAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelAriaLabel" }] : /* istanbul ignore next */ []));
    previousMonthLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousMonthLabel" }] : /* istanbul ignore next */ []));
    nextMonthLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextMonthLabel" }] : /* istanbul ignore next */ []));
    timePickerAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "timePickerAriaLabel" }] : /* istanbul ignore next */ []));
    previousHourLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousHourLabel" }] : /* istanbul ignore next */ []));
    nextHourLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextHourLabel" }] : /* istanbul ignore next */ []));
    previousMinuteLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousMinuteLabel" }] : /* istanbul ignore next */ []));
    nextMinuteLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextMinuteLabel" }] : /* istanbul ignore next */ []));
    previousSecondLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousSecondLabel" }] : /* istanbul ignore next */ []));
    nextSecondLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextSecondLabel" }] : /* istanbul ignore next */ []));
    toggleMeridiemLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toggleMeridiemLabel" }] : /* istanbul ignore next */ []));
    todayLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "todayLabel" }] : /* istanbul ignore next */ []));
    clearLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearLabel" }] : /* istanbul ignore next */ []));
    onFocus = output();
    onBlur = output();
    onClose = output();
    onSelect = output();
    onClear = output();
    onInput = output();
    onTodayClick = output();
    onClearClick = output();
    onShow = output();
    onViewDateChange = output();
    onMonthChange = output();
    onYearChange = output();
    onClickOutside = output();
    overlayVisible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayVisible" }] : /* istanbul ignore next */ []));
    effectiveInputId = computed(() => this.inputId() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveInputId" }] : /* istanbul ignore next */ []));
    panelId = computed(() => `${this.effectiveInputId()}-panel`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelId" }] : /* istanbul ignore next */ []));
    injector = inject(Injector);
    panel = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    anchor = viewChild('anchor', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "anchor" }] : /* istanbul ignore next */ []));
    restoringFocus = false;
    invalidInput = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidInput" }] : /* istanbul ignore next */ []));
    lastCalendarView = null;
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    constructor() {
        effect((onCleanup) => {
            if (this.disabled() || this.cvaDisabled()) {
                this.hide();
                return;
            }
            if (!this.overlayVisible() || this.inline())
                return;
            const panel = this.panel()?.nativeElement;
            const anchor = this.anchor()?.nativeElement;
            if (!panel || !anchor)
                return;
            const detach = attachAnchoredPopup(anchor, panel, this.appendTo());
            const release = registerOverlay(panel, {
                anchor: this.host.nativeElement,
                onParentClose: () => this.hide(),
            });
            const stop = listenForOutsideInteraction(this.document, () => [this.host.nativeElement, this.panel()?.nativeElement], (event) => this.onDocumentClick(event));
            const onFocus = (event) => {
                if (!eventIsInside(event, [
                    this.host.nativeElement,
                    this.panel()?.nativeElement,
                ]))
                    this.hide();
            };
            this.document.addEventListener('focusin', onFocus, true);
            onCleanup(() => {
                stop();
                release();
                this.document.removeEventListener('focusin', onFocus, true);
                detach();
                if (this.destroyRef.destroyed)
                    panel.remove();
            });
        });
        effect(() => {
            const key = this.calendarValue();
            const selected = parseDate(key) ?? this.defaultViewDate() ?? this.defaultDate();
            if (selected && Number.isFinite(selected.getTime()))
                this.viewDate.set(new Date(selected));
        });
    }
    viewMonth = computed(() => monthKey(Number.isFinite(this.viewDate().getTime()) ? this.viewDate() : new Date()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewMonth" }] : /* istanbul ignore next */ []));
    handleCalendarViewDateChange(view) {
        const previous = this.lastCalendarView;
        this.lastCalendarView = view;
        this.viewDate.set(new Date(view.year, view.month - 1, 1));
        this.onViewDateChange.emit(view);
        if (!previous ||
            previous.month !== view.month ||
            previous.year !== view.year)
            this.onMonthChange.emit(view);
        if (!previous || previous.year !== view.year)
            this.onYearChange.emit(view);
    }
    calendarValue = computed(() => {
        const value = this.value();
        return dateKey(Array.isArray(value) ? value[0] : value);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calendarValue" }] : /* istanbul ignore next */ []));
    calendarValues = computed(() => {
        const value = this.value();
        return (Array.isArray(value) ? value : [value])
            .map(dateKey)
            .filter(Boolean);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calendarValues" }] : /* istanbul ignore next */ []));
    timeParts = computed(() => {
        const value = this.value();
        const date = parseDateTime(Array.isArray(value) ? value[0] : value, this.timeOnly());
        return date
            ? {
                hour: date.getHours(),
                minute: date.getMinutes(),
                second: date.getSeconds(),
            }
            : { hour: 0, minute: 0, second: 0 };
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "timeParts" }] : /* istanbul ignore next */ []));
    calendarMin = computed(() => this.dateConstraint(this.minDate(), this.min()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calendarMin" }] : /* istanbul ignore next */ []));
    calendarMax = computed(() => this.dateConstraint(this.maxDate(), this.max()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calendarMax" }] : /* istanbul ignore next */ []));
    monthOffsets = computed(() => Array.from({ length: positiveInteger(this.numberOfMonths(), 1, 12) }, (_, index) => index), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "monthOffsets" }] : /* istanbul ignore next */ []));
    writeValue(value) {
        this.invalidInput.set(false);
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(value) {
        this.cvaDisabled.set(value);
    }
    inputValue() {
        const value = this.value();
        const format = (item) => this.formatInputValue(item);
        if (Array.isArray(value)) {
            const separator = this.selectionMode() === 'range'
                ? this.rangeSeparator()
                : this.multipleSeparator();
            return value.map(format).join(separator);
        }
        return value === undefined || value === null ? '' : format(value);
    }
    formatInputValue(value) {
        if (value instanceof Date)
            return Number.isNaN(value.valueOf()) ? '' : this.formatInputDate(value);
        const raw = String(value ?? '');
        if (!this.showTime() && !this.timeOnly() && /^\d{4}-\d{2}-\d{2}$/.test(raw))
            return this.formatDateParts(...raw.split('-').map(Number));
        return raw;
    }
    formatInputDate(date) {
        const pad = (value) => String(value).padStart(2, '0');
        if (!this.showTime() && !this.timeOnly())
            return this.formatDateParts(date.getFullYear(), date.getMonth() + 1, date.getDate());
        const day = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
        const time = `${pad(date.getHours())}:${pad(date.getMinutes())}${this.showSeconds() ? `:${pad(date.getSeconds())}` : ''}`;
        return this.timeOnly() ? time : `${day}T${time}`;
    }
    formatDateParts(year, month, day) {
        const format = this.dateFormat();
        const pad = (value) => String(value).padStart(2, '0');
        if (format) {
            const replacements = {
                dd: pad(day),
                d: String(day),
                mm: pad(month),
                m: String(month),
                yy: String(year),
                y: pad(year % 100),
            };
            return format.replace(/dd|d|mm|m|yy|y/g, (token) => replacements[token]);
        }
        return new Intl.DateTimeFormat(this.locale() || this.document.documentElement.lang || undefined, { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(year, month - 1, day));
    }
    parseValue(raw) {
        const separator = this.selectionMode() === 'range'
            ? this.rangeSeparator()
            : this.multipleSeparator();
        const values = raw
            .split(separator || ',')
            .map((item) => item.trim())
            .filter(Boolean)
            .map((item) => this.normalizeDateInput(item));
        const parsed = this.dataType() === 'date'
            ? values.map((item) => parseDateTime(item, this.timeOnly()) ?? item)
            : values;
        return this.selectionMode() === 'single' ? (parsed[0] ?? '') : parsed;
    }
    normalizeDateInput(value) {
        if (this.showTime() || this.timeOnly() || /^\d{4}-\d{2}-\d{2}$/.test(value))
            return value;
        const numbers = value.match(/\d+/g)?.map(Number);
        if (!numbers || numbers.length !== 3)
            return value;
        const configuredTokens = this.dateFormat()?.match(/dd|d|mm|m|yy|y/g);
        const localeTokens = new Intl.DateTimeFormat(this.locale() || this.document.documentElement.lang || undefined, { day: 'numeric', month: 'numeric', year: 'numeric' })
            .formatToParts(new Date(2006, 10, 22))
            .filter((part) => part.type === 'day' || part.type === 'month' || part.type === 'year')
            .map((part) => part.type === 'day' ? 'd' : part.type === 'month' ? 'm' : 'yy');
        const tokens = configuredTokens?.length === 3 ? configuredTokens : localeTokens;
        const parts = {
            day: 0,
            month: 0,
            year: 0,
        };
        tokens.forEach((token, index) => {
            parts[token.startsWith('d') ? 'day' : token.startsWith('m') ? 'month' : 'year'] = numbers[index];
        });
        if (parts.year < 100)
            parts.year += 2000;
        const date = new Date(parts.year, parts.month - 1, parts.day);
        if (date.getFullYear() !== parts.year ||
            date.getMonth() !== parts.month - 1 ||
            date.getDate() !== parts.day)
            return value;
        const pad = (part) => String(part).padStart(2, '0');
        return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
    }
    isDateSelectable(date) {
        if (!Number.isFinite(date.getTime()))
            return false;
        const min = this.minDate();
        const max = this.maxDate();
        const key = dateKey(date);
        if (this.timeOnly()) {
            const seconds = (item) => item.getHours() * 3600 + item.getMinutes() * 60 + item.getSeconds();
            return ((!min || seconds(date) >= seconds(min)) &&
                (!max || seconds(date) <= seconds(max)));
        }
        if ((this.calendarMin() && key < this.calendarMin()) ||
            (this.calendarMax() && key > this.calendarMax()))
            return false;
        if (this.showTime() && ((min && date < min) || (max && date > max)))
            return false;
        return (!this.disabledDays()?.includes(date.getDay()) &&
            !(this.disabledDates() || []).some((disabled) => dateKey(disabled) === key));
    }
    update(event) {
        if (this.disabled() || this.cvaDisabled() || this.readonlyInput())
            return;
        const raw = event.target.value;
        const value = this.parseValue(raw);
        const values = Array.isArray(value) ? value : value === '' ? [] : [value];
        const dates = values.map((item) => parseDateTime(item, this.timeOnly()));
        const maxCount = this.maxDateCount();
        const invalid = dates.some((date) => !date || !this.isDateSelectable(date)) ||
            (this.selectionMode() === 'range' &&
                (values.length > 2 ||
                    (values.length === 2 && dates[0] > dates[1]))) ||
            (this.selectionMode() === 'multiple' &&
                maxCount !== undefined &&
                values.length > maxCount);
        this.invalidInput.set(invalid);
        if (invalid) {
            if (this.keepInvalid()) {
                this.value.set(raw);
                this.onChange(raw);
            }
            this.onInput.emit(raw);
            return;
        }
        this.value.set(value);
        this.onChange(value);
        this.onInput.emit(value);
        this.onSelect.emit(value);
    }
    focus(event) {
        this.onFocus.emit(event);
        if (this.showOnFocus() && !this.restoringFocus)
            this.show();
    }
    touch(event) {
        if (event)
            this.onBlur.emit(event);
        this.onTouched();
    }
    onInputKeydown(event) {
        if (event.key === 'Escape' && this.overlayVisible()) {
            event.preventDefault();
            event.stopPropagation?.();
            this.hide(true);
        }
        else if (event.key === 'ArrowDown' ||
            (event.key === 'Enter' && !this.overlayVisible())) {
            event.preventDefault();
            this.show();
            this.focusCalendar();
        }
    }
    onPanelKeydown(event) {
        if (this.inline())
            return;
        if (event.key === 'Escape') {
            event.preventDefault();
            event.stopPropagation();
            this.hide(true);
        }
        else if (this.focusTrap() && this.panel())
            trapTabKey(event, this.panel().nativeElement);
    }
    focusCalendar() {
        if (!this.focusOnShow())
            return;
        afterNextRender(() => {
            if (this.overlayVisible()) {
                if (this.timeOnly())
                    this.panel()
                        ?.nativeElement.querySelector('button:not(:disabled)')
                        ?.focus();
                else
                    this.calendars()[0]?.focusSelected();
            }
        }, { injector: this.injector });
    }
    show() {
        if (!this.inline() &&
            !this.overlayVisible() &&
            !this.disabled() &&
            !this.cvaDisabled()) {
            this.overlayVisible.set(true);
            this.onShow.emit();
        }
    }
    hide(restoreFocus = false) {
        if (!this.overlayVisible())
            return;
        this.overlayVisible.set(false);
        this.onClose.emit();
        this.onTouched();
        if (restoreFocus) {
            this.restoringFocus = true;
            this.host.nativeElement
                .querySelector('input')
                ?.focus({ preventScroll: true });
            this.restoringFocus = false;
        }
    }
    toggle() {
        if (this.overlayVisible())
            this.hide(true);
        else {
            this.show();
            this.focusCalendar();
        }
    }
    onDocumentClick(event) {
        if (!this.inline() &&
            this.overlayVisible() &&
            !eventIsInside(event, [
                this.host.nativeElement,
                this.panel()?.nativeElement,
            ])) {
            this.onClickOutside.emit(event);
            this.hide();
        }
    }
    selectCalendarDate(iso) {
        if (this.disabled() || this.cvaDisabled())
            return;
        const date = parseDate(iso);
        if (!date)
            return;
        if (this.showTime()) {
            const time = this.timeParts();
            date.setHours(time.hour, time.minute, time.second);
        }
        if (!this.isDateSelectable(date))
            return;
        const selected = this.dataType() === 'date'
            ? date
            : this.showTime()
                ? `${iso}T${timeString(this.timeParts(), this.showSeconds())}`
                : iso;
        this.invalidInput.set(false);
        const mode = this.selectionMode();
        let next = selected;
        if (mode === 'multiple') {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            const index = current.findIndex((item) => this.calendarIso(item) === iso);
            if (index < 0 &&
                this.maxDateCount() !== undefined &&
                current.length >= this.maxDateCount())
                return;
            index >= 0 ? current.splice(index, 1) : current.push(selected);
            next = current;
        }
        else if (mode === 'range') {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            if (current.length !== 1 || this.calendarIso(current[0]) === iso)
                next = [selected];
            else
                next =
                    this.calendarIso(current[0]) < iso
                        ? [current[0], selected]
                        : [selected, current[0]];
        }
        this.value.set(next);
        this.onChange(next);
        this.onInput.emit(next);
        this.onSelect.emit(next);
        if (this.hideOnDateTimeSelect() &&
            (mode === 'single' ||
                (mode === 'range' && Array.isArray(next) && next.length === 2)))
            this.hide(true);
    }
    calendarIso(value) {
        return dateKey(value);
    }
    displayHour() {
        const hour = this.timeParts().hour;
        return this.hourFormat() === '12' ? hour % 12 || 12 : hour;
    }
    meridiem() {
        return this.timeParts().hour >= 12 ? 'PM' : 'AM';
    }
    adjustTime(part, delta) {
        const current = this.timeParts();
        const step = positiveInteger(part === 'hour'
            ? this.stepHour()
            : part === 'minute'
                ? this.stepMinute()
                : this.stepSecond(), 1) % (part === 'hour' ? 24 : 60);
        let hour = current.hour;
        let minute = current.minute;
        let second = current.second;
        if (part === 'hour')
            hour = (hour + delta * step + 24) % 24;
        if (part === 'minute')
            minute = (minute + delta * step + 60) % 60;
        if (part === 'second')
            second = (second + delta * step + 60) % 60;
        this.setTime(hour, minute, second);
    }
    toggleMeridiem() {
        const current = this.timeParts();
        this.setTime((current.hour + 12) % 24, current.minute, current.second);
    }
    setTime(hour, minute, second) {
        if (this.disabled() || this.cvaDisabled())
            return;
        const current = this.value();
        const first = Array.isArray(current) ? current[0] : current;
        const date = parseDateTime(first, this.timeOnly()) ??
            (this.timeOnly() ? parseDate('1970-01-01') : new Date());
        date.setHours(hour, minute, second, 0);
        if (!this.isDateSelectable(date))
            return;
        const text = timeString({ hour, minute, second }, this.showSeconds());
        const next = this.dataType() === 'date'
            ? date
            : this.timeOnly()
                ? text
                : `${dateKey(date)}T${text}`;
        const value = Array.isArray(current) ? [next, ...current.slice(1)] : next;
        this.invalidInput.set(false);
        this.value.set(value);
        this.onChange(value);
        this.onInput.emit(value);
    }
    dateConstraint(date, fallback) {
        return date instanceof Date && !Number.isNaN(date.valueOf())
            ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
            : fallback;
    }
    clear() {
        if (this.disabled() || this.cvaDisabled())
            return;
        this.invalidInput.set(false);
        this.value.set('');
        this.onChange('');
        this.onTouched();
        this.onInput.emit('');
        this.onClear.emit();
        this.onClearClick.emit();
    }
    today() {
        if (this.disabled() || this.cvaDisabled())
            return;
        const today = new Date();
        const day = parseDate(dateKey(today));
        if (this.showTime()) {
            const time = this.timeParts();
            day.setHours(time.hour, time.minute, time.second);
        }
        if (!this.isDateSelectable(day))
            return;
        this.selectCalendarDate(dateKey(today));
        this.onTodayClick.emit(today);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DatePickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: DatePickerComponent, isStandalone: true, selector: "orc-date-picker", inputs: { maxDateCount: { classPropertyName: "maxDateCount", publicName: "maxDateCount", isSignal: true, isRequired: false, transformFunction: null }, hideOnDateTimeSelect: { classPropertyName: "hideOnDateTimeSelect", publicName: "hideOnDateTimeSelect", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, dateFormat: { classPropertyName: "dateFormat", publicName: "dateFormat", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, showIcon: { classPropertyName: "showIcon", publicName: "showIcon", isSignal: true, isRequired: false, transformFunction: null }, showButtonBar: { classPropertyName: "showButtonBar", publicName: "showButtonBar", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null }, showTime: { classPropertyName: "showTime", publicName: "showTime", isSignal: true, isRequired: false, transformFunction: null }, timeOnly: { classPropertyName: "timeOnly", publicName: "timeOnly", isSignal: true, isRequired: false, transformFunction: null }, showSeconds: { classPropertyName: "showSeconds", publicName: "showSeconds", isSignal: true, isRequired: false, transformFunction: null }, touchUI: { classPropertyName: "touchUI", publicName: "touchUI", isSignal: true, isRequired: false, transformFunction: null }, showWeek: { classPropertyName: "showWeek", publicName: "showWeek", isSignal: true, isRequired: false, transformFunction: null }, showOtherMonths: { classPropertyName: "showOtherMonths", publicName: "showOtherMonths", isSignal: true, isRequired: false, transformFunction: null }, selectOtherMonths: { classPropertyName: "selectOtherMonths", publicName: "selectOtherMonths", isSignal: true, isRequired: false, transformFunction: null }, readonlyInput: { classPropertyName: "readonlyInput", publicName: "readonlyInput", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, hourFormat: { classPropertyName: "hourFormat", publicName: "hourFormat", isSignal: true, isRequired: false, transformFunction: null }, firstDayOfWeek: { classPropertyName: "firstDayOfWeek", publicName: "firstDayOfWeek", isSignal: true, isRequired: false, transformFunction: null }, numberOfMonths: { classPropertyName: "numberOfMonths", publicName: "numberOfMonths", isSignal: true, isRequired: false, transformFunction: null }, minDate: { classPropertyName: "minDate", publicName: "minDate", isSignal: true, isRequired: false, transformFunction: null }, maxDate: { classPropertyName: "maxDate", publicName: "maxDate", isSignal: true, isRequired: false, transformFunction: null }, disabledDates: { classPropertyName: "disabledDates", publicName: "disabledDates", isSignal: true, isRequired: false, transformFunction: null }, disabledDays: { classPropertyName: "disabledDays", publicName: "disabledDays", isSignal: true, isRequired: false, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, inputStyle: { classPropertyName: "inputStyle", publicName: "inputStyle", isSignal: true, isRequired: false, transformFunction: null }, inputStyleClass: { classPropertyName: "inputStyleClass", publicName: "inputStyleClass", isSignal: true, isRequired: false, transformFunction: null }, dataType: { classPropertyName: "dataType", publicName: "dataType", isSignal: true, isRequired: false, transformFunction: null }, defaultDate: { classPropertyName: "defaultDate", publicName: "defaultDate", isSignal: true, isRequired: false, transformFunction: null }, viewDate: { classPropertyName: "viewDate", publicName: "viewDate", isSignal: true, isRequired: false, transformFunction: null }, showOnFocus: { classPropertyName: "showOnFocus", publicName: "showOnFocus", isSignal: true, isRequired: false, transformFunction: null }, keepInvalid: { classPropertyName: "keepInvalid", publicName: "keepInvalid", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, focusOnShow: { classPropertyName: "focusOnShow", publicName: "focusOnShow", isSignal: true, isRequired: false, transformFunction: null }, focusTrap: { classPropertyName: "focusTrap", publicName: "focusTrap", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, mask: { classPropertyName: "mask", publicName: "mask", isSignal: true, isRequired: false, transformFunction: null }, multipleSeparator: { classPropertyName: "multipleSeparator", publicName: "multipleSeparator", isSignal: true, isRequired: false, transformFunction: null }, rangeSeparator: { classPropertyName: "rangeSeparator", publicName: "rangeSeparator", isSignal: true, isRequired: false, transformFunction: null }, yearNavigator: { classPropertyName: "yearNavigator", publicName: "yearNavigator", isSignal: true, isRequired: false, transformFunction: null }, monthNavigator: { classPropertyName: "monthNavigator", publicName: "monthNavigator", isSignal: true, isRequired: false, transformFunction: null }, yearRange: { classPropertyName: "yearRange", publicName: "yearRange", isSignal: true, isRequired: false, transformFunction: null }, stepHour: { classPropertyName: "stepHour", publicName: "stepHour", isSignal: true, isRequired: false, transformFunction: null }, stepMinute: { classPropertyName: "stepMinute", publicName: "stepMinute", isSignal: true, isRequired: false, transformFunction: null }, stepSecond: { classPropertyName: "stepSecond", publicName: "stepSecond", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, clearButtonStyleClass: { classPropertyName: "clearButtonStyleClass", publicName: "clearButtonStyleClass", isSignal: true, isRequired: false, transformFunction: null }, todayButtonStyleClass: { classPropertyName: "todayButtonStyleClass", publicName: "todayButtonStyleClass", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconAriaLabel: { classPropertyName: "iconAriaLabel", publicName: "iconAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, iconDisplay: { classPropertyName: "iconDisplay", publicName: "iconDisplay", isSignal: true, isRequired: false, transformFunction: null }, defaultViewDate: { classPropertyName: "defaultViewDate", publicName: "defaultViewDate", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, panelAriaLabel: { classPropertyName: "panelAriaLabel", publicName: "panelAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, previousMonthLabel: { classPropertyName: "previousMonthLabel", publicName: "previousMonthLabel", isSignal: true, isRequired: false, transformFunction: null }, nextMonthLabel: { classPropertyName: "nextMonthLabel", publicName: "nextMonthLabel", isSignal: true, isRequired: false, transformFunction: null }, timePickerAriaLabel: { classPropertyName: "timePickerAriaLabel", publicName: "timePickerAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, previousHourLabel: { classPropertyName: "previousHourLabel", publicName: "previousHourLabel", isSignal: true, isRequired: false, transformFunction: null }, nextHourLabel: { classPropertyName: "nextHourLabel", publicName: "nextHourLabel", isSignal: true, isRequired: false, transformFunction: null }, previousMinuteLabel: { classPropertyName: "previousMinuteLabel", publicName: "previousMinuteLabel", isSignal: true, isRequired: false, transformFunction: null }, nextMinuteLabel: { classPropertyName: "nextMinuteLabel", publicName: "nextMinuteLabel", isSignal: true, isRequired: false, transformFunction: null }, previousSecondLabel: { classPropertyName: "previousSecondLabel", publicName: "previousSecondLabel", isSignal: true, isRequired: false, transformFunction: null }, nextSecondLabel: { classPropertyName: "nextSecondLabel", publicName: "nextSecondLabel", isSignal: true, isRequired: false, transformFunction: null }, toggleMeridiemLabel: { classPropertyName: "toggleMeridiemLabel", publicName: "toggleMeridiemLabel", isSignal: true, isRequired: false, transformFunction: null }, todayLabel: { classPropertyName: "todayLabel", publicName: "todayLabel", isSignal: true, isRequired: false, transformFunction: null }, clearLabel: { classPropertyName: "clearLabel", publicName: "clearLabel", isSignal: true, isRequired: false, transformFunction: null }, overlayVisible: { classPropertyName: "overlayVisible", publicName: "overlayVisible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", viewDate: "viewDateChange", onFocus: "onFocus", onBlur: "onBlur", onClose: "onClose", onSelect: "onSelect", onClear: "onClear", onInput: "onInput", onTodayClick: "onTodayClick", onClearClick: "onClearClick", onShow: "onShow", onViewDateChange: "onViewDateChange", onMonthChange: "onMonthChange", onYearChange: "onYearChange", onClickOutside: "onClickOutside", overlayVisible: "overlayVisibleChange" }, host: { properties: { "attr.data-pc-name": "'datepicker'" }, classAttribute: "p-datepicker p-component" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => DatePickerComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "calendars", predicate: DatePickerCalendarComponent, descendants: true, isSignal: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }, { propertyName: "anchor", first: true, predicate: ["anchor"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-datepicker p-component orc-date-picker\"\n  [class]=\"'p-datepicker p-component orc-date-picker ' + (styleClass() || '')\"\n  [class.orc-date-picker--disabled]=\"disabled() || cvaDisabled()\"\n  [class.orc-date-picker--fluid]=\"fluid()\"\n  [style]=\"style()\"\n>\n  @if (label()) {\n    <label class=\"orc-date-picker__label\" [for]=\"effectiveInputId()\">\n      {{ label() }}\n      @if (required()) {\n        <span aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <div #anchor class=\"orc-date-picker__anchor\">\n    <div\n      class=\"orc-date-picker__control\"\n      [class.orc-date-picker__control--with-trigger]=\"showIcon()\"\n    >\n      <input\n        [class]=\"'orc-date-picker__input ' + (inputStyleClass() || '')\"\n        [style]=\"inputStyle()\"\n        [id]=\"effectiveInputId()\"\n        [attr.name]=\"name() || null\"\n        type=\"text\"\n        inputmode=\"numeric\"\n        autocomplete=\"off\"\n        [value]=\"inputValue()\"\n        [attr.min]=\"calendarMin() || null\"\n        [attr.max]=\"calendarMax() || null\"\n        [attr.placeholder]=\"placeholder() || null\"\n        [required]=\"required()\"\n        [disabled]=\"disabled() || cvaDisabled()\"\n        [readonly]=\"readonlyInput()\"\n        [autofocus]=\"autofocus()\"\n        [attr.aria-label]=\"ariaLabel() || null\"\n        [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n        [attr.aria-invalid]=\"error() || invalidInput() ? 'true' : null\"\n        [attr.aria-describedby]=\"\n          error()\n            ? effectiveInputId() + '-error'\n            : helperText()\n              ? effectiveInputId() + '-help'\n              : null\n        \"\n        role=\"combobox\"\n        [attr.aria-expanded]=\"inline() ? true : overlayVisible()\"\n        [attr.aria-controls]=\"panelId()\"\n        aria-haspopup=\"dialog\"\n        [attr.tabindex]=\"tabindex()\"\n        (focus)=\"focus($event)\"\n        (click)=\"showOnFocus() ? show() : null\"\n        (input)=\"update($event)\"\n        (keydown)=\"onInputKeydown($event)\"\n        (blur)=\"touch($event)\"\n      />\n\n      @if (showIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-date-picker__trigger\"\n          [disabled]=\"disabled() || cvaDisabled()\"\n          [attr.aria-label]=\"iconAriaLabel() || 'Choose date'\"\n          [attr.aria-expanded]=\"overlayVisible()\"\n          [attr.aria-controls]=\"panelId()\"\n          aria-haspopup=\"dialog\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"toggle()\"\n        >\n          @if (icon()) {\n            <span [class]=\"icon()\" aria-hidden=\"true\"></span>\n          } @else {\n            <svg\n              viewBox=\"0 0 24 24\"\n              fill=\"none\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.8\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n              aria-hidden=\"true\"\n            >\n              <path d=\"M7 3v3M17 3v3M4 9h16\"></path>\n              <rect x=\"4\" y=\"5\" width=\"16\" height=\"16\" rx=\"2\"></rect>\n            </svg>\n          }\n        </button>\n      }\n    </div>\n\n    @if (overlayVisible() || inline()) {\n      <div\n        class=\"p-datepicker-panel p-component orc-date-picker__panel\"\n        #panel\n        tabindex=\"-1\"\n        (keydown)=\"onPanelKeydown($event)\"\n        [class]=\"\n          'p-datepicker-panel p-component orc-date-picker__panel ' +\n          (panelStyleClass() || '')\n        \"\n        [class.orc-date-picker__panel--inline]=\"inline()\"\n        [style]=\"panelStyle()\"\n        [style.z-index]=\"\n          inline() ? null : autoZIndex() ? baseZIndex() + 1000 : baseZIndex()\n        \"\n        [id]=\"panelId()\"\n        role=\"dialog\"\n        [attr.aria-label]=\"\n          panelAriaLabel() || ariaLabel() || label() || 'Choose date'\n        \"\n        [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n        aria-modal=\"false\"\n      >\n        @if (!timeOnly()) {\n          <div class=\"orc-date-picker__calendars\">\n            @for (offset of monthOffsets(); track offset) {\n              <orc-date-picker-calendar\n                [value]=\"calendarValue()\"\n                [currentMonth]=\"viewMonth()\"\n                (viewDateChange)=\"handleCalendarViewDateChange($event)\"\n                [selectedValues]=\"calendarValues()\"\n                [monthOffset]=\"offset\"\n                [firstDayOfWeek]=\"firstDayOfWeek()\"\n                [min]=\"calendarMin()\"\n                [max]=\"calendarMax()\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                [disabledDates]=\"disabledDates() || []\"\n                [disabledDays]=\"disabledDays() || []\"\n                [showWeek]=\"showWeek()\"\n                [view]=\"view()\"\n                [showOtherMonths]=\"showOtherMonths()\"\n                [selectOtherMonths]=\"selectOtherMonths()\"\n                [locale]=\"locale()\"\n                [ariaLabel]=\"panelAriaLabel()\"\n                [previousMonthLabel]=\"previousMonthLabel()\"\n                [nextMonthLabel]=\"nextMonthLabel()\"\n                [embedded]=\"true\"\n                (dateSelected)=\"selectCalendarDate($event)\"\n              />\n            }\n          </div>\n        }\n\n        @if (showTime() || timeOnly()) {\n          <div\n            class=\"orc-date-picker__time\"\n            role=\"group\"\n            [attr.aria-label]=\"timePickerAriaLabel() || 'Time'\"\n          >\n            <div\n              class=\"orc-date-picker__time-field\"\n              role=\"group\"\n              aria-label=\"Hour\"\n            >\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"nextHourLabel() || 'Increase hour'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('hour', 1)\"\n              >\n                +\n              </button>\n              <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                displayHour()\n              }}</span>\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"previousHourLabel() || 'Decrease hour'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('hour', -1)\"\n              >\n                \u2212\n              </button>\n            </div>\n            <span>:</span>\n            <div\n              class=\"orc-date-picker__time-field\"\n              role=\"group\"\n              aria-label=\"Minute\"\n            >\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"nextMinuteLabel() || 'Increase minute'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('minute', 1)\"\n              >\n                +\n              </button>\n              <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                timeParts().minute | number: \"2.0-0\"\n              }}</span>\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"previousMinuteLabel() || 'Decrease minute'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('minute', -1)\"\n              >\n                \u2212\n              </button>\n            </div>\n            @if (showSeconds()) {\n              <span>:</span>\n              <div\n                class=\"orc-date-picker__time-field\"\n                role=\"group\"\n                aria-label=\"Second\"\n              >\n                <button\n                  type=\"button\"\n                  [attr.aria-label]=\"nextSecondLabel() || 'Increase second'\"\n                  [disabled]=\"disabled() || cvaDisabled()\"\n                  (click)=\"adjustTime('second', 1)\"\n                >\n                  +\n                </button>\n                <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                  timeParts().second | number: \"2.0-0\"\n                }}</span>\n                <button\n                  type=\"button\"\n                  [attr.aria-label]=\"previousSecondLabel() || 'Decrease second'\"\n                  [disabled]=\"disabled() || cvaDisabled()\"\n                  (click)=\"adjustTime('second', -1)\"\n                >\n                  \u2212\n                </button>\n              </div>\n            }\n            @if (hourFormat() === \"12\") {\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"toggleMeridiemLabel() || 'Toggle AM/PM'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"toggleMeridiem()\"\n              >\n                {{ meridiem() }}\n              </button>\n            }\n          </div>\n        }\n\n        @if (showButtonBar() || showClear()) {\n          <footer class=\"orc-date-picker__buttonbar\">\n            @if (showButtonBar()) {\n              <button\n                type=\"button\"\n                [class]=\"\n                  'orc-date-picker__panel-action ' +\n                  (todayButtonStyleClass() || '')\n                \"\n                (click)=\"today()\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n              >\n                {{ todayLabel() || \"Today\" }}\n              </button>\n            }\n            @if (showClear()) {\n              <button\n                type=\"button\"\n                [class]=\"\n                  'orc-date-picker__panel-action ' +\n                  (clearButtonStyleClass() || '')\n                \"\n                [disabled]=\"disabled() || cvaDisabled() || !inputValue()\"\n                (click)=\"clear()\"\n              >\n                {{ clearLabel() || \"Clear\" }}\n              </button>\n            }\n          </footer>\n        }\n      </div>\n    }\n  </div>\n\n  @if (error()) {\n    <span\n      [id]=\"effectiveInputId() + '-error'\"\n      class=\"orc-date-picker__error\"\n      role=\"alert\"\n      >{{ error() }}</span\n    >\n  } @else if (helperText()) {\n    <span\n      [id]=\"effectiveInputId() + '-help'\"\n      class=\"orc-date-picker__help\"\n      role=\"status\"\n      >{{ helperText() }}</span\n    >\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-date-picker{display:grid;gap:var(--space-2, .5rem);width:100%;color:var(--orc-text, var(--text-primary, #141414));font-family:var(--font-sans, system-ui, sans-serif)}.orc-date-picker__label{width:fit-content;font-size:.875rem;font-weight:600}.orc-date-picker__anchor{position:relative;width:100%}.orc-date-picker__control{position:relative;display:flex;align-items:center;width:100%}.orc-date-picker__input{width:100%;min-height:2.75rem;padding:0 var(--space-3, .75rem);box-sizing:border-box;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, .625rem);outline:0;background:var(--orc-control-surface, var(--orc-fill-input, #fff));color:var(--orc-text, var(--text-primary, #141414));font:inherit;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-date-picker__control--with-trigger .orc-date-picker__input{padding-inline-end:2.75rem}.orc-date-picker__input:hover:not(:disabled){border-color:var(--orc-border-strong, var(--border-strong, #a3a3a3))}.orc-date-picker__input:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-date-picker__trigger{position:absolute;inset-block:0;inset-inline-end:0;display:grid;place-items:center;width:2.75rem;padding:0;border:0;border-radius:0 var(--radius-md, .625rem) var(--radius-md, .625rem) 0;background:transparent;color:var(--orc-text-secondary, var(--text-secondary, #666));cursor:pointer}.orc-date-picker__trigger:hover:not(:disabled){color:var(--orc-text, var(--text-primary, #141414));background:var(--orc-surface-subtle, var(--bg-subtle, #f7f7f7))}.orc-date-picker__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-3px}.orc-date-picker__trigger svg{width:1.25rem;height:1.25rem}.orc-date-picker__panel{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + var(--space-1, .25rem));inset-inline-start:0;display:grid;width:max-content;max-width:min(var(--orc-popup-available-width, calc(100vw - 1rem) ),80rem);max-height:var(--orc-popup-available-height, calc(100vh - 1rem) );overflow:auto;padding:0;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, .625rem);background:var(--orc-surface-raised, var(--orc-fill-modal, #fff));color:var(--orc-text, var(--text-primary, #141414));box-shadow:var(--orc-shadow-overlay, var(--shadow-lg, 0 12px 28px rgba(0, 0, 0, .16)))}.orc-date-picker__panel--inline{position:static;width:fit-content;max-width:100%;max-height:none;margin-top:var(--space-1, .25rem);box-shadow:none}.orc-date-picker__calendars{display:flex;max-width:100%;overflow-x:auto}.orc-date-picker__time{display:flex;align-items:center;justify-content:center;gap:var(--space-2, .5rem);padding:var(--space-3, .75rem);border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-date-picker__time-field{display:grid;min-width:2rem;justify-items:center;gap:var(--space-1, .25rem)}.orc-date-picker__time-field>span{font-variant-numeric:tabular-nums}.orc-date-picker__time button{display:grid;place-items:center;min-width:2rem;min-height:2rem;padding:0;border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:inherit;cursor:pointer}.orc-date-picker__time button:hover{background:var(--orc-surface-subtle, var(--bg-subtle, #f7f7f7))}.orc-date-picker__buttonbar{display:flex;justify-content:space-between;gap:var(--space-3, .75rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-date-picker__panel-action{min-height:2rem;padding:0 var(--space-2, .5rem);border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font:inherit;font-size:.8125rem;font-weight:600;cursor:pointer}.orc-date-picker__panel-action:only-child{margin-inline-start:auto}.orc-date-picker__panel-action:hover:not(:disabled){background:var(--orc-interactive-soft, color-mix(in srgb, currentColor 10%, transparent))}.orc-date-picker__panel-action:disabled{opacity:.45;cursor:not-allowed}.orc-date-picker__help,.orc-date-picker__error{font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-date-picker__error{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-date-picker--disabled{opacity:.6}.orc-date-picker--fluid{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: DatePickerCalendarComponent, selector: "orc-date-picker-calendar", inputs: ["value", "selectedValues", "currentMonth", "min", "max", "disabled", "disabledDates", "disabledDays", "firstDayOfWeek", "showOtherMonths", "selectOtherMonths", "showWeek", "embedded", "view", "locale", "ariaLabel", "previousMonthLabel", "nextMonthLabel", "weekLabel", "monthOffset"], outputs: ["valueChange", "currentMonthChange", "dateSelected", "viewDateChange"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-date-picker', standalone: true, imports: [CommonModule, DatePickerCalendarComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'p-datepicker p-component',
                        '[attr.data-pc-name]': "'datepicker'",
                    }, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DatePickerComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-datepicker p-component orc-date-picker\"\n  [class]=\"'p-datepicker p-component orc-date-picker ' + (styleClass() || '')\"\n  [class.orc-date-picker--disabled]=\"disabled() || cvaDisabled()\"\n  [class.orc-date-picker--fluid]=\"fluid()\"\n  [style]=\"style()\"\n>\n  @if (label()) {\n    <label class=\"orc-date-picker__label\" [for]=\"effectiveInputId()\">\n      {{ label() }}\n      @if (required()) {\n        <span aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <div #anchor class=\"orc-date-picker__anchor\">\n    <div\n      class=\"orc-date-picker__control\"\n      [class.orc-date-picker__control--with-trigger]=\"showIcon()\"\n    >\n      <input\n        [class]=\"'orc-date-picker__input ' + (inputStyleClass() || '')\"\n        [style]=\"inputStyle()\"\n        [id]=\"effectiveInputId()\"\n        [attr.name]=\"name() || null\"\n        type=\"text\"\n        inputmode=\"numeric\"\n        autocomplete=\"off\"\n        [value]=\"inputValue()\"\n        [attr.min]=\"calendarMin() || null\"\n        [attr.max]=\"calendarMax() || null\"\n        [attr.placeholder]=\"placeholder() || null\"\n        [required]=\"required()\"\n        [disabled]=\"disabled() || cvaDisabled()\"\n        [readonly]=\"readonlyInput()\"\n        [autofocus]=\"autofocus()\"\n        [attr.aria-label]=\"ariaLabel() || null\"\n        [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n        [attr.aria-invalid]=\"error() || invalidInput() ? 'true' : null\"\n        [attr.aria-describedby]=\"\n          error()\n            ? effectiveInputId() + '-error'\n            : helperText()\n              ? effectiveInputId() + '-help'\n              : null\n        \"\n        role=\"combobox\"\n        [attr.aria-expanded]=\"inline() ? true : overlayVisible()\"\n        [attr.aria-controls]=\"panelId()\"\n        aria-haspopup=\"dialog\"\n        [attr.tabindex]=\"tabindex()\"\n        (focus)=\"focus($event)\"\n        (click)=\"showOnFocus() ? show() : null\"\n        (input)=\"update($event)\"\n        (keydown)=\"onInputKeydown($event)\"\n        (blur)=\"touch($event)\"\n      />\n\n      @if (showIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-date-picker__trigger\"\n          [disabled]=\"disabled() || cvaDisabled()\"\n          [attr.aria-label]=\"iconAriaLabel() || 'Choose date'\"\n          [attr.aria-expanded]=\"overlayVisible()\"\n          [attr.aria-controls]=\"panelId()\"\n          aria-haspopup=\"dialog\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"toggle()\"\n        >\n          @if (icon()) {\n            <span [class]=\"icon()\" aria-hidden=\"true\"></span>\n          } @else {\n            <svg\n              viewBox=\"0 0 24 24\"\n              fill=\"none\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.8\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n              aria-hidden=\"true\"\n            >\n              <path d=\"M7 3v3M17 3v3M4 9h16\"></path>\n              <rect x=\"4\" y=\"5\" width=\"16\" height=\"16\" rx=\"2\"></rect>\n            </svg>\n          }\n        </button>\n      }\n    </div>\n\n    @if (overlayVisible() || inline()) {\n      <div\n        class=\"p-datepicker-panel p-component orc-date-picker__panel\"\n        #panel\n        tabindex=\"-1\"\n        (keydown)=\"onPanelKeydown($event)\"\n        [class]=\"\n          'p-datepicker-panel p-component orc-date-picker__panel ' +\n          (panelStyleClass() || '')\n        \"\n        [class.orc-date-picker__panel--inline]=\"inline()\"\n        [style]=\"panelStyle()\"\n        [style.z-index]=\"\n          inline() ? null : autoZIndex() ? baseZIndex() + 1000 : baseZIndex()\n        \"\n        [id]=\"panelId()\"\n        role=\"dialog\"\n        [attr.aria-label]=\"\n          panelAriaLabel() || ariaLabel() || label() || 'Choose date'\n        \"\n        [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n        aria-modal=\"false\"\n      >\n        @if (!timeOnly()) {\n          <div class=\"orc-date-picker__calendars\">\n            @for (offset of monthOffsets(); track offset) {\n              <orc-date-picker-calendar\n                [value]=\"calendarValue()\"\n                [currentMonth]=\"viewMonth()\"\n                (viewDateChange)=\"handleCalendarViewDateChange($event)\"\n                [selectedValues]=\"calendarValues()\"\n                [monthOffset]=\"offset\"\n                [firstDayOfWeek]=\"firstDayOfWeek()\"\n                [min]=\"calendarMin()\"\n                [max]=\"calendarMax()\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                [disabledDates]=\"disabledDates() || []\"\n                [disabledDays]=\"disabledDays() || []\"\n                [showWeek]=\"showWeek()\"\n                [view]=\"view()\"\n                [showOtherMonths]=\"showOtherMonths()\"\n                [selectOtherMonths]=\"selectOtherMonths()\"\n                [locale]=\"locale()\"\n                [ariaLabel]=\"panelAriaLabel()\"\n                [previousMonthLabel]=\"previousMonthLabel()\"\n                [nextMonthLabel]=\"nextMonthLabel()\"\n                [embedded]=\"true\"\n                (dateSelected)=\"selectCalendarDate($event)\"\n              />\n            }\n          </div>\n        }\n\n        @if (showTime() || timeOnly()) {\n          <div\n            class=\"orc-date-picker__time\"\n            role=\"group\"\n            [attr.aria-label]=\"timePickerAriaLabel() || 'Time'\"\n          >\n            <div\n              class=\"orc-date-picker__time-field\"\n              role=\"group\"\n              aria-label=\"Hour\"\n            >\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"nextHourLabel() || 'Increase hour'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('hour', 1)\"\n              >\n                +\n              </button>\n              <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                displayHour()\n              }}</span>\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"previousHourLabel() || 'Decrease hour'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('hour', -1)\"\n              >\n                \u2212\n              </button>\n            </div>\n            <span>:</span>\n            <div\n              class=\"orc-date-picker__time-field\"\n              role=\"group\"\n              aria-label=\"Minute\"\n            >\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"nextMinuteLabel() || 'Increase minute'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('minute', 1)\"\n              >\n                +\n              </button>\n              <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                timeParts().minute | number: \"2.0-0\"\n              }}</span>\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"previousMinuteLabel() || 'Decrease minute'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"adjustTime('minute', -1)\"\n              >\n                \u2212\n              </button>\n            </div>\n            @if (showSeconds()) {\n              <span>:</span>\n              <div\n                class=\"orc-date-picker__time-field\"\n                role=\"group\"\n                aria-label=\"Second\"\n              >\n                <button\n                  type=\"button\"\n                  [attr.aria-label]=\"nextSecondLabel() || 'Increase second'\"\n                  [disabled]=\"disabled() || cvaDisabled()\"\n                  (click)=\"adjustTime('second', 1)\"\n                >\n                  +\n                </button>\n                <span aria-live=\"polite\" aria-atomic=\"true\">{{\n                  timeParts().second | number: \"2.0-0\"\n                }}</span>\n                <button\n                  type=\"button\"\n                  [attr.aria-label]=\"previousSecondLabel() || 'Decrease second'\"\n                  [disabled]=\"disabled() || cvaDisabled()\"\n                  (click)=\"adjustTime('second', -1)\"\n                >\n                  \u2212\n                </button>\n              </div>\n            }\n            @if (hourFormat() === \"12\") {\n              <button\n                type=\"button\"\n                [attr.aria-label]=\"toggleMeridiemLabel() || 'Toggle AM/PM'\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n                (click)=\"toggleMeridiem()\"\n              >\n                {{ meridiem() }}\n              </button>\n            }\n          </div>\n        }\n\n        @if (showButtonBar() || showClear()) {\n          <footer class=\"orc-date-picker__buttonbar\">\n            @if (showButtonBar()) {\n              <button\n                type=\"button\"\n                [class]=\"\n                  'orc-date-picker__panel-action ' +\n                  (todayButtonStyleClass() || '')\n                \"\n                (click)=\"today()\"\n                [disabled]=\"disabled() || cvaDisabled()\"\n              >\n                {{ todayLabel() || \"Today\" }}\n              </button>\n            }\n            @if (showClear()) {\n              <button\n                type=\"button\"\n                [class]=\"\n                  'orc-date-picker__panel-action ' +\n                  (clearButtonStyleClass() || '')\n                \"\n                [disabled]=\"disabled() || cvaDisabled() || !inputValue()\"\n                (click)=\"clear()\"\n              >\n                {{ clearLabel() || \"Clear\" }}\n              </button>\n            }\n          </footer>\n        }\n      </div>\n    }\n  </div>\n\n  @if (error()) {\n    <span\n      [id]=\"effectiveInputId() + '-error'\"\n      class=\"orc-date-picker__error\"\n      role=\"alert\"\n      >{{ error() }}</span\n    >\n  } @else if (helperText()) {\n    <span\n      [id]=\"effectiveInputId() + '-help'\"\n      class=\"orc-date-picker__help\"\n      role=\"status\"\n      >{{ helperText() }}</span\n    >\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-date-picker{display:grid;gap:var(--space-2, .5rem);width:100%;color:var(--orc-text, var(--text-primary, #141414));font-family:var(--font-sans, system-ui, sans-serif)}.orc-date-picker__label{width:fit-content;font-size:.875rem;font-weight:600}.orc-date-picker__anchor{position:relative;width:100%}.orc-date-picker__control{position:relative;display:flex;align-items:center;width:100%}.orc-date-picker__input{width:100%;min-height:2.75rem;padding:0 var(--space-3, .75rem);box-sizing:border-box;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, .625rem);outline:0;background:var(--orc-control-surface, var(--orc-fill-input, #fff));color:var(--orc-text, var(--text-primary, #141414));font:inherit;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-date-picker__control--with-trigger .orc-date-picker__input{padding-inline-end:2.75rem}.orc-date-picker__input:hover:not(:disabled){border-color:var(--orc-border-strong, var(--border-strong, #a3a3a3))}.orc-date-picker__input:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-date-picker__trigger{position:absolute;inset-block:0;inset-inline-end:0;display:grid;place-items:center;width:2.75rem;padding:0;border:0;border-radius:0 var(--radius-md, .625rem) var(--radius-md, .625rem) 0;background:transparent;color:var(--orc-text-secondary, var(--text-secondary, #666));cursor:pointer}.orc-date-picker__trigger:hover:not(:disabled){color:var(--orc-text, var(--text-primary, #141414));background:var(--orc-surface-subtle, var(--bg-subtle, #f7f7f7))}.orc-date-picker__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-3px}.orc-date-picker__trigger svg{width:1.25rem;height:1.25rem}.orc-date-picker__panel{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + var(--space-1, .25rem));inset-inline-start:0;display:grid;width:max-content;max-width:min(var(--orc-popup-available-width, calc(100vw - 1rem) ),80rem);max-height:var(--orc-popup-available-height, calc(100vh - 1rem) );overflow:auto;padding:0;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, .625rem);background:var(--orc-surface-raised, var(--orc-fill-modal, #fff));color:var(--orc-text, var(--text-primary, #141414));box-shadow:var(--orc-shadow-overlay, var(--shadow-lg, 0 12px 28px rgba(0, 0, 0, .16)))}.orc-date-picker__panel--inline{position:static;width:fit-content;max-width:100%;max-height:none;margin-top:var(--space-1, .25rem);box-shadow:none}.orc-date-picker__calendars{display:flex;max-width:100%;overflow-x:auto}.orc-date-picker__time{display:flex;align-items:center;justify-content:center;gap:var(--space-2, .5rem);padding:var(--space-3, .75rem);border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-date-picker__time-field{display:grid;min-width:2rem;justify-items:center;gap:var(--space-1, .25rem)}.orc-date-picker__time-field>span{font-variant-numeric:tabular-nums}.orc-date-picker__time button{display:grid;place-items:center;min-width:2rem;min-height:2rem;padding:0;border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:inherit;cursor:pointer}.orc-date-picker__time button:hover{background:var(--orc-surface-subtle, var(--bg-subtle, #f7f7f7))}.orc-date-picker__buttonbar{display:flex;justify-content:space-between;gap:var(--space-3, .75rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-date-picker__panel-action{min-height:2rem;padding:0 var(--space-2, .5rem);border:0;border-radius:var(--radius-sm, .375rem);background:transparent;color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font:inherit;font-size:.8125rem;font-weight:600;cursor:pointer}.orc-date-picker__panel-action:only-child{margin-inline-start:auto}.orc-date-picker__panel-action:hover:not(:disabled){background:var(--orc-interactive-soft, color-mix(in srgb, currentColor 10%, transparent))}.orc-date-picker__panel-action:disabled{opacity:.45;cursor:not-allowed}.orc-date-picker__help,.orc-date-picker__error{font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-date-picker__error{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-date-picker--disabled{opacity:.6}.orc-date-picker--fluid{width:100%}\n"] }]
        }], ctorParameters: () => [], propDecorators: { calendars: [{ type: i0.ViewChildren, args: [i0.forwardRef(() => DatePickerCalendarComponent), { isSignal: true }] }], maxDateCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxDateCount", required: false }] }], hideOnDateTimeSelect: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideOnDateTimeSelect", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], dateFormat: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateFormat", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], showIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIcon", required: false }] }], showButtonBar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtonBar", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }], showTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTime", required: false }] }], timeOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "timeOnly", required: false }] }], showSeconds: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSeconds", required: false }] }], touchUI: [{ type: i0.Input, args: [{ isSignal: true, alias: "touchUI", required: false }] }], showWeek: [{ type: i0.Input, args: [{ isSignal: true, alias: "showWeek", required: false }] }], showOtherMonths: [{ type: i0.Input, args: [{ isSignal: true, alias: "showOtherMonths", required: false }] }], selectOtherMonths: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOtherMonths", required: false }] }], readonlyInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonlyInput", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], hourFormat: [{ type: i0.Input, args: [{ isSignal: true, alias: "hourFormat", required: false }] }], firstDayOfWeek: [{ type: i0.Input, args: [{ isSignal: true, alias: "firstDayOfWeek", required: false }] }], numberOfMonths: [{ type: i0.Input, args: [{ isSignal: true, alias: "numberOfMonths", required: false }] }], minDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "minDate", required: false }] }], maxDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxDate", required: false }] }], disabledDates: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledDates", required: false }] }], disabledDays: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledDays", required: false }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], inputStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyle", required: false }] }], inputStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyleClass", required: false }] }], dataType: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataType", required: false }] }], defaultDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultDate", required: false }] }], viewDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewDate", required: false }] }, { type: i0.Output, args: ["viewDateChange"] }], showOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "showOnFocus", required: false }] }], keepInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "keepInvalid", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], focusOnShow: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnShow", required: false }] }], focusTrap: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusTrap", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], mask: [{ type: i0.Input, args: [{ isSignal: true, alias: "mask", required: false }] }], multipleSeparator: [{ type: i0.Input, args: [{ isSignal: true, alias: "multipleSeparator", required: false }] }], rangeSeparator: [{ type: i0.Input, args: [{ isSignal: true, alias: "rangeSeparator", required: false }] }], yearNavigator: [{ type: i0.Input, args: [{ isSignal: true, alias: "yearNavigator", required: false }] }], monthNavigator: [{ type: i0.Input, args: [{ isSignal: true, alias: "monthNavigator", required: false }] }], yearRange: [{ type: i0.Input, args: [{ isSignal: true, alias: "yearRange", required: false }] }], stepHour: [{ type: i0.Input, args: [{ isSignal: true, alias: "stepHour", required: false }] }], stepMinute: [{ type: i0.Input, args: [{ isSignal: true, alias: "stepMinute", required: false }] }], stepSecond: [{ type: i0.Input, args: [{ isSignal: true, alias: "stepSecond", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], clearButtonStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearButtonStyleClass", required: false }] }], todayButtonStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "todayButtonStyleClass", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconAriaLabel", required: false }] }], iconDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconDisplay", required: false }] }], defaultViewDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultViewDate", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], panelAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelAriaLabel", required: false }] }], previousMonthLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousMonthLabel", required: false }] }], nextMonthLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextMonthLabel", required: false }] }], timePickerAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "timePickerAriaLabel", required: false }] }], previousHourLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousHourLabel", required: false }] }], nextHourLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextHourLabel", required: false }] }], previousMinuteLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousMinuteLabel", required: false }] }], nextMinuteLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextMinuteLabel", required: false }] }], previousSecondLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousSecondLabel", required: false }] }], nextSecondLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextSecondLabel", required: false }] }], toggleMeridiemLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleMeridiemLabel", required: false }] }], todayLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "todayLabel", required: false }] }], clearLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearLabel", required: false }] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onClose: [{ type: i0.Output, args: ["onClose"] }], onSelect: [{ type: i0.Output, args: ["onSelect"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onInput: [{ type: i0.Output, args: ["onInput"] }], onTodayClick: [{ type: i0.Output, args: ["onTodayClick"] }], onClearClick: [{ type: i0.Output, args: ["onClearClick"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onViewDateChange: [{ type: i0.Output, args: ["onViewDateChange"] }], onMonthChange: [{ type: i0.Output, args: ["onMonthChange"] }], onYearChange: [{ type: i0.Output, args: ["onYearChange"] }], onClickOutside: [{ type: i0.Output, args: ["onClickOutside"] }], overlayVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayVisible", required: false }] }, { type: i0.Output, args: ["overlayVisibleChange"] }], panel: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], anchor: [{ type: i0.ViewChild, args: ['anchor', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DatePickerCalendarComponent, DatePickerComponent };
//# sourceMappingURL=ciag-orchestra-date-picker.mjs.map
