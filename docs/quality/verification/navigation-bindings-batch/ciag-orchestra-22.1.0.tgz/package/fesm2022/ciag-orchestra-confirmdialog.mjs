export * from '@ciag/orchestra/confirm-dialog';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-confirmdialog.mjs.map
