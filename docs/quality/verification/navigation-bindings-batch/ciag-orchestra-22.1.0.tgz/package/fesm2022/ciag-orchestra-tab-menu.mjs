import * as i0 from '@angular/core';
import { input, model, booleanAttribute, output, computed, viewChildren, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/router';
import { RouterModule } from '@angular/router';

class TabMenuComponent {
    model = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    activeItem = model(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItem" }] : /* istanbul ignore next */ []));
    scrollable = input(false, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    itemSelect = output();
    effectiveAriaLabel = computed(() => {
        if (this.ariaLabelledBy()?.trim())
            return undefined;
        return this.ariaLabel()?.trim() || 'Tab menu';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveAriaLabel" }] : /* istanbul ignore next */ []));
    visibleItems = computed(() => this.model().filter((item) => item.visible !== false), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    enabledItems = computed(() => this.visibleItems().filter((item) => !item.disabled), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "enabledItems" }] : /* istanbul ignore next */ []));
    // Kept as a button ElementRef for source compatibility; routed entries are
    // anchors, which expose the same focus/click methods used below.
    tabItems = viewChildren('tabItem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabItems" }] : /* istanbul ignore next */ []));
    selectedItem = computed(() => {
        const active = this.activeItem();
        const enabled = this.enabledItems();
        return active && enabled.includes(active) ? active : enabled[0];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedItem" }] : /* istanbul ignore next */ []));
    isActive(item) {
        return this.selectedItem() === item;
    }
    /**
     * @deprecated Popup mode has no trigger or open-state API and therefore has no effect.
     * Use MenuComponent for popup navigation.
     */
    popup = input(false, { ...(ngDevMode ? { debugName: "popup" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    hasRouterLink(item) {
        return item.routerLink !== undefined && item.routerLink !== null;
    }
    trackItem(item, index) {
        const id = item['id'];
        return id === undefined || id === null
            ? `${item.label ?? ''}:${index}`
            : id;
    }
    activate(item, event) {
        if (item.disabled ||
            item.visible === false ||
            !this.visibleItems().includes(item))
            return;
        this.activeItem.set(item);
        item.command?.(event);
        this.itemSelect.emit(item);
    }
    onKeydown(event, index) {
        const key = event.key;
        if (key !== 'ArrowRight' &&
            key !== 'ArrowLeft' &&
            key !== 'Home' &&
            key !== 'End')
            return;
        const visible = this.visibleItems();
        const enabled = this.enabledItems();
        const currentItem = visible[index];
        const current = enabled.indexOf(currentItem);
        if (!currentItem || current < 0 || !enabled.length)
            return;
        if (event.cancelable)
            event.preventDefault();
        const rtl = this.isRtl(event.currentTarget);
        const direction = key === 'ArrowRight' ? (rtl ? -1 : 1) : rtl ? 1 : -1;
        const next = key === 'Home'
            ? 0
            : key === 'End'
                ? enabled.length - 1
                : (current + direction + enabled.length) % enabled.length;
        const nextItem = enabled[next];
        const targetIndex = visible.indexOf(nextItem);
        const target = this.tabItems()[targetIndex]?.nativeElement;
        target?.focus();
        if (this.hasRouterLink(nextItem)) {
            target?.click();
        }
        else {
            this.activate(nextItem, event);
        }
    }
    isRtl(target) {
        if (!(target instanceof HTMLElement))
            return false;
        const explicitDirection = target.closest('[dir]')?.getAttribute('dir');
        if (explicitDirection)
            return explicitDirection.toLowerCase() === 'rtl';
        const view = target.ownerDocument.defaultView;
        return view?.getComputedStyle(target).direction === 'rtl';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TabMenuComponent, isStandalone: true, selector: "orc-tab-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, activeItem: { classPropertyName: "activeItem", publicName: "activeItem", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, popup: { classPropertyName: "popup", publicName: "popup", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeItem: "activeItemChange", itemSelect: "itemSelect" }, viewQueries: [{ propertyName: "tabItems", predicate: ["tabItem"], descendants: true, isSignal: true }], ngImport: i0, template: `<nav
    class="orc-tab-menu"
    [class.scrollable]="scrollable()"
    [class]="styleClass()"
    [style]="style()"
    [attr.aria-label]="effectiveAriaLabel()"
    [attr.aria-labelledby]="ariaLabelledBy()"
  >
    <ul role="tablist" aria-orientation="horizontal">
      @for (
        item of visibleItems();
        track trackItem(item, $index);
        let i = $index
      ) {
        <li role="presentation">
          @if (hasRouterLink(item) && !item.disabled) {
            <a
              #tabItem
              role="tab"
              [attr.aria-selected]="isActive(item)"
              [attr.tabindex]="isActive(item) ? 0 : -1"
              [routerLink]="item.routerLink"
              (click)="activate(item, $event)"
              (keydown)="onKeydown($event, i)"
            >
              @if (item.icon) {
                <span aria-hidden="true">{{ item.icon }}</span>
              }
              {{ item.label }}</a
            >
          } @else {
            <button
              #tabItem
              type="button"
              role="tab"
              [disabled]="!!item.disabled"
              [attr.aria-selected]="isActive(item)"
              [attr.tabindex]="isActive(item) ? 0 : -1"
              (click)="activate(item, $event)"
              (keydown)="onKeydown($event, i)"
            >
              @if (item.icon) {
                <span aria-hidden="true">{{ item.icon }}</span>
              }
              {{ item.label }}
            </button>
          }
        </li>
      }
    </ul>
  </nav>`, isInline: true, styles: [".orc-tab-menu{display:block;overflow:auto}.orc-tab-menu ul{display:flex;gap:.25rem;margin:0;padding:0;border-bottom:1px solid var(--orc-border-default, #e2e8f0);list-style:none}.orc-tab-menu button,.orc-tab-menu a{border:0;border-bottom:2px solid transparent;background:transparent;padding:.65rem .85rem;color:var(--orc-text-secondary, #475569);text-decoration:none}.orc-tab-menu button[aria-selected=true],.orc-tab-menu a[aria-selected=true]{border-bottom-color:var(--orc-interactive, #2563eb);color:var(--orc-interactive-hover, var(--orc-interactive, #1d4ed8));font-weight:600}.orc-tab-menu button:focus-visible,.orc-tab-menu a:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-tab-menu button:disabled{opacity:.5}.orc-tab-menu.scrollable ul{min-width:max-content}\n"], dependencies: [{ kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tab-menu', standalone: true, imports: [RouterModule], template: `<nav
    class="orc-tab-menu"
    [class.scrollable]="scrollable()"
    [class]="styleClass()"
    [style]="style()"
    [attr.aria-label]="effectiveAriaLabel()"
    [attr.aria-labelledby]="ariaLabelledBy()"
  >
    <ul role="tablist" aria-orientation="horizontal">
      @for (
        item of visibleItems();
        track trackItem(item, $index);
        let i = $index
      ) {
        <li role="presentation">
          @if (hasRouterLink(item) && !item.disabled) {
            <a
              #tabItem
              role="tab"
              [attr.aria-selected]="isActive(item)"
              [attr.tabindex]="isActive(item) ? 0 : -1"
              [routerLink]="item.routerLink"
              (click)="activate(item, $event)"
              (keydown)="onKeydown($event, i)"
            >
              @if (item.icon) {
                <span aria-hidden="true">{{ item.icon }}</span>
              }
              {{ item.label }}</a
            >
          } @else {
            <button
              #tabItem
              type="button"
              role="tab"
              [disabled]="!!item.disabled"
              [attr.aria-selected]="isActive(item)"
              [attr.tabindex]="isActive(item) ? 0 : -1"
              (click)="activate(item, $event)"
              (keydown)="onKeydown($event, i)"
            >
              @if (item.icon) {
                <span aria-hidden="true">{{ item.icon }}</span>
              }
              {{ item.label }}
            </button>
          }
        </li>
      }
    </ul>
  </nav>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".orc-tab-menu{display:block;overflow:auto}.orc-tab-menu ul{display:flex;gap:.25rem;margin:0;padding:0;border-bottom:1px solid var(--orc-border-default, #e2e8f0);list-style:none}.orc-tab-menu button,.orc-tab-menu a{border:0;border-bottom:2px solid transparent;background:transparent;padding:.65rem .85rem;color:var(--orc-text-secondary, #475569);text-decoration:none}.orc-tab-menu button[aria-selected=true],.orc-tab-menu a[aria-selected=true]{border-bottom-color:var(--orc-interactive, #2563eb);color:var(--orc-interactive-hover, var(--orc-interactive, #1d4ed8));font-weight:600}.orc-tab-menu button:focus-visible,.orc-tab-menu a:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-tab-menu button:disabled{opacity:.5}.orc-tab-menu.scrollable ul{min-width:max-content}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], activeItem: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItem", required: false }] }, { type: i0.Output, args: ["activeItemChange"] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], itemSelect: [{ type: i0.Output, args: ["itemSelect"] }], tabItems: [{ type: i0.ViewChildren, args: ['tabItem', { isSignal: true }] }], popup: [{ type: i0.Input, args: [{ isSignal: true, alias: "popup", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { TabMenuComponent };
//# sourceMappingURL=ciag-orchestra-tab-menu.mjs.map
