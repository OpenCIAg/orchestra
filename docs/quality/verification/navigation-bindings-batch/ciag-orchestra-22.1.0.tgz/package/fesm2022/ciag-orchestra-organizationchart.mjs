export * from '@ciag/orchestra/organization-chart';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-organizationchart.mjs.map
