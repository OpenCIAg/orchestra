import * as i0 from '@angular/core';
import { inject, ElementRef, input, numberAttribute, booleanAttribute, model, signal, output, computed, forwardRef, HostListener, ContentChild, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { TooltipDirective } from '@ciag/orchestra/tooltip';

let nextUniqueId = 0;
class RatingComponent {
    elementRef = inject((ElementRef));
    uniqueId = `orc-rating-${++nextUniqueId}`;
    // -- Inputs ---------------------------------------------------------
    id = input(this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    max = input(5, { ...(ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    stars = input(undefined, { ...(ngDevMode ? { debugName: "stars" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    allowHalf = input(false, { ...(ngDevMode ? { debugName: "allowHalf" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    numeric = input(false, { ...(ngDevMode ? { debugName: "numeric" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    clearable = input(false, { ...(ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    iconOnClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconOnClass" }] : /* istanbul ignore next */ []));
    iconOffClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconOffClass" }] : /* istanbul ignore next */ []));
    cancelAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelAriaLabel" }] : /* istanbul ignore next */ []));
    iconOnStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconOnStyle" }] : /* istanbul ignore next */ []));
    iconOffStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconOffStyle" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    cancel = input(true, { ...(ngDevMode ? { debugName: "cancel" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    cancelIcon = input('×', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelIcon" }] : /* istanbul ignore next */ []));
    // Array de rótulos ex: ['Péssimo', 'Ruim', 'Regular', 'Bom', 'Excelente']
    tooltips = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltips" }] : /* istanbul ignore next */ []));
    // Custom SVG via TemplateRef
    customIconTemplate;
    // -- Value (Model / CVA) ------------------------------------------
    value = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // -- Internal State -----------------------------------------------
    hoverValue = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hoverValue" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    isFocused = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFocused" }] : /* istanbul ignore next */ []));
    onRate = output();
    onCancel = output();
    onFocus = output();
    onBlur = output();
    // -- Computeds ----------------------------------------------------
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    effectiveStars = computed(() => this.stars() ?? this.max(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveStars" }] : /* istanbul ignore next */ []));
    starsArray = computed(() => Array.from({ length: this.effectiveStars() }, (_, i) => i + 1), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "starsArray" }] : /* istanbul ignore next */ []));
    displayValue = computed(() => {
        const hover = this.hoverValue();
        return hover !== null ? hover : this.value();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []));
    // -- ControlValueAccessor -----------------------------------------
    onChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        const num = typeof val === 'number' ? val : parseFloat(val);
        this.value.set(Number.isFinite(num) ? Math.max(0, Math.min(num, this.effectiveStars())) : 0);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    ngAfterViewInit() {
        if (this.autofocus() && !this.effectiveDisabled()) {
            this.elementRef.nativeElement.focus();
        }
    }
    // -- Interactions -------------------------------------------------
    onItemClick(event, index, isHalf = false) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        // In numeric mode, we ignore half clicks.
        let selectedValue = this.numeric() ? index : (isHalf && this.allowHalf() ? index - 0.5 : index);
        if (this.clearable() && this.value() === selectedValue) {
            selectedValue = 0;
            this.onCancel.emit(event);
            this.updateValue(selectedValue);
            this.onTouched();
            return;
        }
        this.updateValue(selectedValue);
        this.onTouched();
        this.onRate.emit({ originalEvent: event, value: selectedValue });
    }
    cancelRating(event) { if (this.effectiveDisabled() || this.readonly())
        return; this.updateValue(0); this.onTouched(); this.onCancel.emit(event); }
    onItemHover(index, isHalf = false) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const hValue = this.numeric() ? index : (isHalf && this.allowHalf() ? index - 0.5 : index);
        this.hoverValue.set(hValue);
    }
    onMouseLeave() {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.hoverValue.set(null);
    }
    handleFocus(event) {
        if (this.effectiveDisabled())
            return;
        this.isFocused.set(true);
        this.onFocus.emit(event);
    }
    handleBlur(event) {
        if (this.effectiveDisabled())
            return;
        this.isFocused.set(false);
        this.onTouched();
        this.onBlur.emit(event);
    }
    updateValue(val) {
        const safeVal = Math.max(0, Math.min(val, this.effectiveStars()));
        this.value.set(safeVal);
        this.onChange(safeVal);
    }
    // -- Keyboard Navigation (WCAG) -----------------------------------
    onKeydown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const step = this.allowHalf() && !this.numeric() ? 0.5 : 1;
        let current = this.value();
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowUp':
                event.preventDefault();
                this.updateValue(current + step);
                this.onTouched();
                this.onRate.emit({ originalEvent: event, value: this.value() });
                break;
            case 'ArrowLeft':
            case 'ArrowDown':
                event.preventDefault();
                this.updateValue(current - step);
                this.onTouched();
                this.onRate.emit({ originalEvent: event, value: this.value() });
                break;
            case 'Home':
                event.preventDefault();
                this.updateValue(0);
                this.onTouched();
                this.onRate.emit({ originalEvent: event, value: this.value() });
                break;
            case 'End':
                event.preventDefault();
                this.updateValue(this.effectiveStars());
                this.onTouched();
                this.onRate.emit({ originalEvent: event, value: this.value() });
                break;
            case 'Escape':
            case '0':
                if (this.clearable()) {
                    event.preventDefault();
                    this.updateValue(0);
                    this.onTouched();
                    this.onCancel.emit(event);
                }
                break;
        }
    }
    // -- Accessibility Helpers ----------------------------------------
    getTooltip(index) {
        // index is 1-based
        const tt = this.tooltips();
        if (!tt || tt.length === 0)
            return undefined;
        return tt[index - 1] || undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: RatingComponent, isStandalone: true, selector: "orc-rating", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, stars: { classPropertyName: "stars", publicName: "stars", isSignal: true, isRequired: false, transformFunction: null }, allowHalf: { classPropertyName: "allowHalf", publicName: "allowHalf", isSignal: true, isRequired: false, transformFunction: null }, numeric: { classPropertyName: "numeric", publicName: "numeric", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, iconOnClass: { classPropertyName: "iconOnClass", publicName: "iconOnClass", isSignal: true, isRequired: false, transformFunction: null }, iconOffClass: { classPropertyName: "iconOffClass", publicName: "iconOffClass", isSignal: true, isRequired: false, transformFunction: null }, cancelAriaLabel: { classPropertyName: "cancelAriaLabel", publicName: "cancelAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, iconOnStyle: { classPropertyName: "iconOnStyle", publicName: "iconOnStyle", isSignal: true, isRequired: false, transformFunction: null }, iconOffStyle: { classPropertyName: "iconOffStyle", publicName: "iconOffStyle", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, cancel: { classPropertyName: "cancel", publicName: "cancel", isSignal: true, isRequired: false, transformFunction: null }, cancelIcon: { classPropertyName: "cancelIcon", publicName: "cancelIcon", isSignal: true, isRequired: false, transformFunction: null }, tooltips: { classPropertyName: "tooltips", publicName: "tooltips", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", onRate: "onRate", onCancel: "onCancel", onFocus: "onFocus", onBlur: "onBlur" }, host: { listeners: { "keydown": "onKeydown($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => RatingComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "customIconTemplate", first: true, predicate: ["customIcon"], descendants: true }], ngImport: i0, template: "\n<div\n  class=\"p-rating p-component orc-rating\"\n  [class.orc-rating--disabled]=\"effectiveDisabled()\"\n  [class.orc-rating--readonly]=\"readonly()\"\n  [class]=\"'p-rating p-component orc-rating ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.id]=\"id()\"\n  [attr.data-pc-name]=\"'rating'\"\n  [attr.aria-label]=\"ariaLabel()\"\n  role=\"slider\"\n  [attr.aria-valuenow]=\"value()\"\n  [attr.aria-valuemin]=\"0\"\n  [attr.aria-valuemax]=\"effectiveStars()\"\n  [attr.aria-valuetext]=\"value() + ' de ' + effectiveStars()\"\n  [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n  [attr.tabindex]=\"effectiveDisabled() ? -1 : 0\"\n  [attr.autofocus]=\"autofocus() ? '' : null\"\n  (focus)=\"handleFocus($event)\"\n  (blur)=\"handleBlur($event)\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  @if (cancel() && value() > 0) { <button type=\"button\" class=\"orc-rating__cancel\" [disabled]=\"effectiveDisabled() || readonly()\" (click)=\"cancelRating($event)\" [attr.aria-label]=\"cancelAriaLabel() || null\">{{ cancelIcon() }}</button> }\n  <div class=\"orc-rating__items\">\n    @for (i of starsArray(); track i) {\n      <!-- \n        i \u00E9 1-based (1, 2, 3...)\n        Para calcular o preenchimento, comparamos i com displayValue()\n      -->\n      <div\n        class=\"p-rating-item orc-rating__item\"\n        [class.orc-rating__item--disabled]=\"effectiveDisabled()\"\n        [class.orc-rating__item--readonly]=\"readonly()\"\n        [class.orc-rating__item--numeric]=\"numeric()\"\n        [class.is-filled]=\"numeric() && displayValue() >= i\"\n        [orcTooltip]=\"getTooltip(i)\"\n      >\n        @if (numeric()) {\n          <span class=\"orc-rating__text\" (click)=\"onItemClick($event, i)\" (mouseenter)=\"onItemHover(i)\">\n            {{ i }}\n          </span>\n        } @else {\n          <!-- \u00C1reas clic\u00E1veis invis\u00EDveis para capturar meia estrela ou estrela inteira -->\n          @if (allowHalf()) {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              (click)=\"onItemClick($event, i, true)\"\n              (mouseenter)=\"onItemHover(i, true)\"\n            ></div>\n            <div \n              class=\"orc-rating__half orc-rating__half--right\" \n              (click)=\"onItemClick($event, i, false)\"\n              (mouseenter)=\"onItemHover(i, false)\"\n            ></div>\n          } @else {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              style=\"width: 100%;\"\n              (click)=\"onItemClick($event, i)\"\n              (mouseenter)=\"onItemHover(i)\"\n            ></div>\n          }\n\n          <!-- \u00CDcone Base (Vazio) -->\n          <div class=\"orc-rating__icon\" [class]=\"iconOffClass()\" [style]=\"iconOffStyle()\">\n            <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n          </div>\n\n          <!-- \u00CDcone Preenchido (Mascarado por largura) -->\n          <div class=\"orc-rating__icon orc-rating__icon--filled\" [class]=\"iconOnClass()\" [style]=\"iconOnStyle()\"\n               [style.width.%]=\"displayValue() >= i ? 100 : (displayValue() > i - 1 ? (displayValue() - (i - 1)) * 100 : 0)\">\n            <div class=\"orc-rating__icon-content\">\n              <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n            </div>\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n\n<!-- Estrela SVG Padr\u00E3o -->\n<ng-template #defaultStar>\n  <svg viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n    <path d=\"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z\"/>\n  </svg>\n</ng-template>\n", styles: [".orc-rating{display:inline-flex;align-items:center;gap:var(--space-2);outline:none}.orc-rating:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:4px;border-radius:var(--radius-sm)}.orc-rating--disabled{opacity:.5;cursor:not-allowed}.orc-rating--readonly{cursor:default}.orc-rating__items{display:flex;align-items:center;gap:var(--space-1)}.orc-rating__item{position:relative;display:inline-flex;align-items:center;justify-content:center;color:var(--border-default);transition:transform var(--transition-fast);cursor:pointer}.orc-rating__item:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:scale(1.15)}.orc-rating__item--disabled{cursor:not-allowed}.orc-rating__item--readonly{cursor:default}.orc-rating__item .orc-rating__half{position:absolute;top:0;bottom:0;width:50%;z-index:2}.orc-rating__item .orc-rating__half--left{left:0}.orc-rating__item .orc-rating__half--right{right:0}.orc-rating__item--numeric{width:40px;height:40px;border-radius:var(--radius-md);background-color:var(--orc-bg);border:1px solid var(--border-default);color:var(--text-secondary);font-size:1rem;font-weight:500;transition:all var(--transition-fast)}.orc-rating__item--numeric:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:none;border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-rating__item--numeric.is-filled{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-opposite-bw, #ffffff)}.orc-rating__icon{width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-rating__icon svg{width:100%;height:100%;fill:currentColor;transition:fill var(--transition-fast),color var(--transition-fast)}.orc-rating__icon--filled{position:absolute;top:0;left:0;color:var(--orc-color-laranja, #ff6a1c);overflow:hidden;width:0%;justify-content:flex-start;pointer-events:none}.orc-rating__icon-content{width:24px;height:24px;flex:0 0 24px;display:flex;align-items:center;justify-content:center}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: TooltipDirective, selector: "[orcTooltip]", inputs: ["appTooltip", "uiTooltip", "orcTooltip", "tooltipPosition", "tooltipTheme", "tooltipShowDelay", "tooltipHideDelay", "showDelay", "hideDelay", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "life", "fitContent", "content", "tooltipOptions", "position", "autoHide", "hideOnEscape", "tooltipDisabled", "styleClass", "appendTo"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-rating', standalone: true, imports: [CommonModule, TooltipDirective], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => RatingComponent),
                            multi: true,
                        },
                    ], template: "\n<div\n  class=\"p-rating p-component orc-rating\"\n  [class.orc-rating--disabled]=\"effectiveDisabled()\"\n  [class.orc-rating--readonly]=\"readonly()\"\n  [class]=\"'p-rating p-component orc-rating ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.id]=\"id()\"\n  [attr.data-pc-name]=\"'rating'\"\n  [attr.aria-label]=\"ariaLabel()\"\n  role=\"slider\"\n  [attr.aria-valuenow]=\"value()\"\n  [attr.aria-valuemin]=\"0\"\n  [attr.aria-valuemax]=\"effectiveStars()\"\n  [attr.aria-valuetext]=\"value() + ' de ' + effectiveStars()\"\n  [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n  [attr.tabindex]=\"effectiveDisabled() ? -1 : 0\"\n  [attr.autofocus]=\"autofocus() ? '' : null\"\n  (focus)=\"handleFocus($event)\"\n  (blur)=\"handleBlur($event)\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  @if (cancel() && value() > 0) { <button type=\"button\" class=\"orc-rating__cancel\" [disabled]=\"effectiveDisabled() || readonly()\" (click)=\"cancelRating($event)\" [attr.aria-label]=\"cancelAriaLabel() || null\">{{ cancelIcon() }}</button> }\n  <div class=\"orc-rating__items\">\n    @for (i of starsArray(); track i) {\n      <!-- \n        i \u00E9 1-based (1, 2, 3...)\n        Para calcular o preenchimento, comparamos i com displayValue()\n      -->\n      <div\n        class=\"p-rating-item orc-rating__item\"\n        [class.orc-rating__item--disabled]=\"effectiveDisabled()\"\n        [class.orc-rating__item--readonly]=\"readonly()\"\n        [class.orc-rating__item--numeric]=\"numeric()\"\n        [class.is-filled]=\"numeric() && displayValue() >= i\"\n        [orcTooltip]=\"getTooltip(i)\"\n      >\n        @if (numeric()) {\n          <span class=\"orc-rating__text\" (click)=\"onItemClick($event, i)\" (mouseenter)=\"onItemHover(i)\">\n            {{ i }}\n          </span>\n        } @else {\n          <!-- \u00C1reas clic\u00E1veis invis\u00EDveis para capturar meia estrela ou estrela inteira -->\n          @if (allowHalf()) {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              (click)=\"onItemClick($event, i, true)\"\n              (mouseenter)=\"onItemHover(i, true)\"\n            ></div>\n            <div \n              class=\"orc-rating__half orc-rating__half--right\" \n              (click)=\"onItemClick($event, i, false)\"\n              (mouseenter)=\"onItemHover(i, false)\"\n            ></div>\n          } @else {\n            <div \n              class=\"orc-rating__half orc-rating__half--left\" \n              style=\"width: 100%;\"\n              (click)=\"onItemClick($event, i)\"\n              (mouseenter)=\"onItemHover(i)\"\n            ></div>\n          }\n\n          <!-- \u00CDcone Base (Vazio) -->\n          <div class=\"orc-rating__icon\" [class]=\"iconOffClass()\" [style]=\"iconOffStyle()\">\n            <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n          </div>\n\n          <!-- \u00CDcone Preenchido (Mascarado por largura) -->\n          <div class=\"orc-rating__icon orc-rating__icon--filled\" [class]=\"iconOnClass()\" [style]=\"iconOnStyle()\"\n               [style.width.%]=\"displayValue() >= i ? 100 : (displayValue() > i - 1 ? (displayValue() - (i - 1)) * 100 : 0)\">\n            <div class=\"orc-rating__icon-content\">\n              <ng-container *ngTemplateOutlet=\"customIconTemplate || defaultStar\"></ng-container>\n            </div>\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n\n<!-- Estrela SVG Padr\u00E3o -->\n<ng-template #defaultStar>\n  <svg viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n    <path d=\"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z\"/>\n  </svg>\n</ng-template>\n", styles: [".orc-rating{display:inline-flex;align-items:center;gap:var(--space-2);outline:none}.orc-rating:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:4px;border-radius:var(--radius-sm)}.orc-rating--disabled{opacity:.5;cursor:not-allowed}.orc-rating--readonly{cursor:default}.orc-rating__items{display:flex;align-items:center;gap:var(--space-1)}.orc-rating__item{position:relative;display:inline-flex;align-items:center;justify-content:center;color:var(--border-default);transition:transform var(--transition-fast);cursor:pointer}.orc-rating__item:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:scale(1.15)}.orc-rating__item--disabled{cursor:not-allowed}.orc-rating__item--readonly{cursor:default}.orc-rating__item .orc-rating__half{position:absolute;top:0;bottom:0;width:50%;z-index:2}.orc-rating__item .orc-rating__half--left{left:0}.orc-rating__item .orc-rating__half--right{right:0}.orc-rating__item--numeric{width:40px;height:40px;border-radius:var(--radius-md);background-color:var(--orc-bg);border:1px solid var(--border-default);color:var(--text-secondary);font-size:1rem;font-weight:500;transition:all var(--transition-fast)}.orc-rating__item--numeric:hover:not(.orc-rating__item--disabled):not(.orc-rating__item--readonly){transform:none;border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-color-azul-eletrico, #1c6aed)}.orc-rating__item--numeric.is-filled{background-color:var(--orc-color-azul-eletrico, #1c6aed);border-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-opposite-bw, #ffffff)}.orc-rating__icon{width:24px;height:24px;display:flex;align-items:center;justify-content:center}.orc-rating__icon svg{width:100%;height:100%;fill:currentColor;transition:fill var(--transition-fast),color var(--transition-fast)}.orc-rating__icon--filled{position:absolute;top:0;left:0;color:var(--orc-color-laranja, #ff6a1c);overflow:hidden;width:0%;justify-content:flex-start;pointer-events:none}.orc-rating__icon-content{width:24px;height:24px;flex:0 0 24px;display:flex;align-items:center;justify-content:center}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], stars: [{ type: i0.Input, args: [{ isSignal: true, alias: "stars", required: false }] }], allowHalf: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowHalf", required: false }] }], numeric: [{ type: i0.Input, args: [{ isSignal: true, alias: "numeric", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], iconOnClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnClass", required: false }] }], iconOffClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOffClass", required: false }] }], cancelAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelAriaLabel", required: false }] }], iconOnStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnStyle", required: false }] }], iconOffStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOffStyle", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], cancel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancel", required: false }] }], cancelIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelIcon", required: false }] }], tooltips: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltips", required: false }] }], customIconTemplate: [{
                type: ContentChild,
                args: ['customIcon']
            }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], onRate: [{ type: i0.Output, args: ["onRate"] }], onCancel: [{ type: i0.Output, args: ["onCancel"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { RatingComponent };
//# sourceMappingURL=ciag-orchestra-rating.mjs.map
