export { PopoverComponent } from '@ciag/orchestra/overlay-panel';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-popover.mjs.map
