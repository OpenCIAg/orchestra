export { VirtualScrollerComponent as ScrollerComponent } from '@ciag/orchestra/virtual-scroller';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-scroller.mjs.map
