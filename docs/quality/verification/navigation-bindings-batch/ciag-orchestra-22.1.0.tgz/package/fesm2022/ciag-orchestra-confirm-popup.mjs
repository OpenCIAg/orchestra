export { ConfirmPopupComponent, ConfirmPopupService } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-confirm-popup.mjs.map
