import * as i0 from '@angular/core';
import { inject, ElementRef, input, model, booleanAttribute, output, computed, effect, signal, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgressBarComponent } from '@ciag/orchestra/progress';

class StepperComponent {
    host = inject((ElementRef));
    // ── Inputs & Models ───────────────────────────────────────
    /** Lista de etapas a serem exibidas */
    steps = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    /** Índice da etapa ativa atual (0-indexed) */
    currentStep = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentStep" }] : /* istanbul ignore next */ []));
    activeIndex = model(0, { ...(ngDevMode ? { debugName: "activeIndex" } : /* istanbul ignore next */ {}), alias: 'activeIndex' });
    model = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    exact = input(false, { ...(ngDevMode ? { debugName: "exact" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    style = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /** Orientação do layout: 'horizontal' ou 'vertical' */
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** Estilo dos marcadores de etapa: 'numeric' (1, 2, 3...) ou 'icon' */
    type = input('numeric', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Permite que o usuário clique nos passos para navegar */
    clickable = input(true, { ...(ngDevMode ? { debugName: "clickable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Automatically activate a step when it receives keyboard focus. */
    selectOnFocus = input(false, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Accessible label for the stepper navigation. */
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Modo linear: impede pular etapas à frente */
    linear = input(false, { ...(ngDevMode ? { debugName: "linear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Evento emitido quando o usuário clica em uma etapa */
    stepChange = output();
    onChange = output();
    completed = output();
    effectiveSteps = computed(() => this.model() ?? this.steps(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveSteps" }] : /* istanbul ignore next */ []));
    boundStep(index) {
        const count = this.effectiveSteps().length;
        if (!count || !Number.isFinite(index))
            return 0;
        return Math.min(count - 1, Math.max(0, Math.trunc(index)));
    }
    firstReachable(preferred) {
        const steps = this.effectiveSteps();
        if (!steps.length)
            return 0;
        if (steps[preferred] && this.isStepClickable(preferred, steps[preferred])) {
            return preferred;
        }
        const first = steps.findIndex((step, index) => this.isStepClickable(index, step));
        return first >= 0 ? first : 0;
    }
    constructor() {
        effect(() => {
            const current = this.boundStep(this.currentStep());
            const active = this.boundStep(this.activeIndex());
            if (this.currentStep() !== current)
                this.currentStep.set(current);
            if (this.activeIndex() !== active)
                this.activeIndex.set(active);
            if (!this.initialized) {
                this.initialized = true;
                this.lastCurrentStep = current;
                this.lastActiveIndex = active;
                if (current !== active) {
                    if (current !== 0 || active === 0)
                        this.activeIndex.set(current);
                    else
                        this.currentStep.set(active);
                }
                this.focusedIndex.set(this.firstReachable(current));
                return;
            }
            const currentChanged = current !== this.lastCurrentStep;
            const activeChanged = active !== this.lastActiveIndex;
            if (currentChanged && !activeChanged)
                this.activeIndex.set(current);
            else if (activeChanged)
                this.currentStep.set(active);
            if (currentChanged || activeChanged) {
                this.focusedIndex.set(this.firstReachable(this.currentStep()));
            }
            const reachable = this.reachableIndices();
            if (!reachable.includes(this.focusedIndex() ?? -1)) {
                this.focusedIndex.set(reachable[0] ?? 0);
            }
            this.lastCurrentStep = current;
            this.lastActiveIndex = active;
        });
    }
    initialized = false;
    lastCurrentStep = 0;
    lastActiveIndex = 0;
    focusedIndex = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedIndex" }] : /* istanbul ignore next */ []));
    // ── Helpers & Métodos ─────────────────────────────────────
    getStepStatus(index, step) {
        if (step.status && step.status !== 'active')
            return step.status;
        const current = this.currentStep();
        if (index === current && step.status === 'active')
            return 'active';
        if (index < current)
            return 'completed';
        if (index === current)
            return 'active';
        return 'pending';
    }
    isStepClickable(index, step) {
        if (step.disabled || this.readonly() || !this.clickable())
            return false;
        if (this.linear() && index > this.currentStep() + 1)
            return false;
        return true;
    }
    reachableIndices() {
        return this.effectiveSteps()
            .map((step, index) => (this.isStepClickable(index, step) ? index : -1))
            .filter((index) => index >= 0);
    }
    selectStep(index, step) {
        if (!step)
            return;
        if (!this.isStepClickable(index, step))
            return;
        if (this.currentStep() === index)
            return;
        this.currentStep.set(index);
        this.activeIndex.set(index);
        this.focusedIndex.set(index);
        this.stepChange.emit({ step, index });
        this.onChange.emit({ index, step });
        if (index === this.effectiveSteps().length - 1)
            this.completed.emit();
    }
    onFocus(index) {
        const step = this.effectiveSteps()[index];
        if (!step || !this.isStepClickable(index, step))
            return;
        this.focusedIndex.set(index);
        if (this.selectOnFocus() && index !== this.currentStep()) {
            this.selectStep(index, step);
        }
    }
    onKeydown(event, index) {
        const steps = this.effectiveSteps();
        const reachable = this.reachableIndices();
        if (!steps.length || !reachable.length)
            return;
        let target = -1;
        const rtl = this.orientation() === 'horizontal' &&
            this.host.nativeElement.ownerDocument.defaultView?.getComputedStyle(this.host.nativeElement).direction === 'rtl';
        const forward = rtl
            ? event.key === 'ArrowLeft'
            : event.key === 'ArrowRight';
        const backward = rtl
            ? event.key === 'ArrowRight'
            : event.key === 'ArrowLeft';
        if (forward || event.key === 'ArrowDown') {
            target = reachable.find((candidate) => candidate > index) ?? -1;
        }
        else if (backward || event.key === 'ArrowUp') {
            target =
                [...reachable].reverse().find((candidate) => candidate < index) ?? -1;
        }
        else if (event.key === 'Home') {
            target = reachable[0];
        }
        else if (event.key === 'End') {
            target = reachable.at(-1) ?? -1;
        }
        else if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.selectStep(index, steps[index]);
            return;
        }
        else {
            return;
        }
        event.preventDefault();
        if (target < 0 || target === index)
            return;
        const buttons = this.host.nativeElement.querySelectorAll('.orc-stepper__step-btn');
        buttons[target]?.focus();
    }
    next() {
        this.selectStep(this.currentStep() + 1, this.effectiveSteps()[this.currentStep() + 1]);
    }
    previous() {
        this.selectStep(this.currentStep() - 1, this.effectiveSteps()[this.currentStep() - 1]);
    }
    reset() {
        this.currentStep.set(0);
        this.activeIndex.set(0);
        this.focusedIndex.set(0);
    }
    isConnectorCompleted(index) {
        return index < this.currentStep();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: StepperComponent, isStandalone: true, selector: "orc-stepper, orc-steps", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, currentStep: { classPropertyName: "currentStep", publicName: "currentStep", isSignal: true, isRequired: false, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, exact: { classPropertyName: "exact", publicName: "exact", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, clickable: { classPropertyName: "clickable", publicName: "clickable", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, linear: { classPropertyName: "linear", publicName: "linear", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { currentStep: "currentStepChange", activeIndex: "activeIndexChange", stepChange: "stepChange", onChange: "onChange", completed: "completed" }, ngImport: i0, template: "<nav\n  [attr.id]=\"id() || null\"\n  class=\"p-steps p-component orc-stepper\"\n  [class]=\"'p-steps p-component orc-stepper ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'steps'\"\n  [class.orc-stepper--horizontal]=\"orientation() === 'horizontal'\"\n  [class.orc-stepper--vertical]=\"orientation() === 'vertical'\"\n  [class.orc-stepper--numeric]=\"type() === 'numeric'\"\n  [class.orc-stepper--icon]=\"type() === 'icon'\"\n  [attr.aria-label]=\"ariaLabel() || 'Steps'\"\n>\n  <ol class=\"orc-stepper__list\">\n    @for (\n      step of effectiveSteps();\n      track step.id || $index;\n      let idx = $index;\n      let isLast = $last\n    ) {\n      @let status = getStepStatus(idx, step);\n      @let clickableState = isStepClickable(idx, step);\n\n      <li\n        class=\"orc-stepper__item\"\n        [class.orc-stepper__item--completed]=\"status === 'completed'\"\n        [class.orc-stepper__item--active]=\"status === 'active'\"\n        [class.orc-stepper__item--loading]=\"status === 'loading'\"\n        [class.orc-stepper__item--pending]=\"status === 'pending'\"\n        [class.orc-stepper__item--error]=\"status === 'error'\"\n        [class.orc-stepper__item--disabled]=\"step.disabled\"\n        [class.orc-stepper__item--clickable]=\"clickableState\"\n      >\n        <!-- Horizontal Connector Line (Before Step, if not first) -->\n        @if (orientation() === \"horizontal\" && idx > 0) {\n          <div\n            class=\"orc-stepper__connector-line orc-stepper__connector-line--horizontal\"\n            [class.orc-stepper__connector-line--completed]=\"\n              isConnectorCompleted(idx)\n            \"\n          ></div>\n        }\n\n        <!-- Step Trigger Button / Container -->\n        <button\n          type=\"button\"\n          class=\"p-steps-item-link orc-stepper__step-btn\"\n          [disabled]=\"!clickableState\"\n          [attr.tabindex]=\"\n            idx === (focusedIndex() ?? currentStep()) && clickableState ? 0 : -1\n          \"\n          [attr.aria-posinset]=\"idx + 1\"\n          [attr.aria-setsize]=\"effectiveSteps().length\"\n          (click)=\"selectStep(idx, step)\"\n          (focus)=\"onFocus(idx)\"\n          (keydown)=\"onKeydown($event, idx)\"\n          [attr.aria-current]=\"idx === currentStep() ? 'step' : null\"\n        >\n          <!-- Marker Circle (Number or Icon) -->\n          <div class=\"orc-stepper__marker\">\n            @if (status === \"completed\") {\n              <!-- Checkmark SVG -->\n              <svg\n                class=\"orc-stepper__icon orc-stepper__icon--check\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <polyline points=\"20 6 9 17 4 12\"></polyline>\n              </svg>\n            } @else if (\n              status === \"loading\" ||\n              (status === \"active\" && orientation() === \"vertical\")\n            ) {\n              <!-- Spinner / Loader SVG -->\n              <svg\n                class=\"orc-stepper__icon orc-stepper__icon--spin\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path d=\"M21 12a9 9 0 1 1-6.219-8.56\"></path>\n              </svg>\n            } @else if (type() === \"numeric\") {\n              <!-- Step Number -->\n              <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n            } @else if (step.icon) {\n              <!-- Custom Icon or Text -->\n              <span class=\"orc-stepper__custom-icon\">{{ step.icon }}</span>\n            } @else {\n              <!-- Fallback to Number -->\n              <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n            }\n          </div>\n\n          <!-- Step Label & Description -->\n          <div class=\"orc-stepper__content\">\n            <span class=\"orc-stepper__title\">{{ step.title }}</span>\n            @if (step.subtitle || step.description) {\n              <span class=\"orc-stepper__subtitle\">{{\n                step.subtitle || step.description\n              }}</span>\n            }\n\n            <!-- Embedded Progress Bar in Step (Figma Vertical Stepper Spec) -->\n            @if (\n              step.progress !== undefined &&\n              (status === \"active\" || orientation() === \"vertical\")\n            ) {\n              <div class=\"orc-stepper__step-progress\">\n                <orc-progress-bar\n                  [value]=\"step.progress\"\n                  variant=\"primary\"\n                  [showValue]=\"true\"\n                />\n              </div>\n            }\n          </div>\n        </button>\n\n        <!-- Vertical Connector Line (Below step, if not last) -->\n        @if (orientation() === \"vertical\" && !isLast) {\n          <div\n            class=\"orc-stepper__connector-line orc-stepper__connector-line--vertical\"\n            [class.orc-stepper__connector-line--completed]=\"\n              isConnectorCompleted(idx + 1)\n            \"\n          ></div>\n        }\n      </li>\n    }\n  </ol>\n</nav>\n", styles: [":host{display:block;width:100%}.orc-stepper{width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-stepper__list{display:flex;margin:0;padding:0;list-style:none}.orc-stepper--horizontal .orc-stepper__list{flex-direction:row;align-items:flex-start;justify-content:space-between;width:100%}.orc-stepper--horizontal .orc-stepper__item{display:flex;flex:1;align-items:flex-start;position:relative}.orc-stepper--horizontal .orc-stepper__item:last-child{flex:0 0 auto}.orc-stepper--horizontal .orc-stepper__step-btn{display:flex;flex-direction:column;align-items:center;text-align:center;background:none;border:none;padding:0;margin:0;cursor:default;min-width:100px;outline:none;transition:transform var(--transition-fast)}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn:hover .orc-stepper__marker{transform:scale(1.05)}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal{flex:1;height:3px;background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));margin:19px 8px 0;align-self:flex-start;transition:background-color .3s ease}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal.orc-stepper__connector-line--completed{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal .orc-stepper__marker{width:40px;height:40px;border-radius:20px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;font-size:16px;font-weight:500;transition:all .3s ease;box-sizing:border-box}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-text, var(--orc-font-main, #141414));font-weight:500}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff);border:2px solid var(--orc-surface-raised, #ffffff);box-shadow:0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__title{color:var(--orc-text-muted, #929292);font-weight:400}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-interactive-soft);color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));color:var(--orc-text-muted, #929292);border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9))}.orc-stepper--vertical .orc-stepper__list{flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__item{position:relative;display:flex;flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__step-btn{display:flex;align-items:flex-start;gap:16px;width:100%;text-align:left;background:none;border:none;padding:0;margin:0;cursor:default;outline:none}.orc-stepper--vertical .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--vertical .orc-stepper__marker{width:32px;height:32px;border-radius:200px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box;transition:all .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical{width:2px;min-height:36px;background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));margin-left:15px;margin-top:4px;margin-bottom:4px;transition:background-color .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical.orc-stepper__connector-line--completed{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--vertical .orc-stepper__content{display:flex;flex-direction:column;gap:4px;flex:1;padding-top:2px;padding-bottom:16px}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:500}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-surface-raised, #ffffff);border:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-surface-raised, #ffffff);border:2px solid var(--orc-border-default, var(--orc-border, #d9d9d9));color:var(--orc-text-secondary, var(--orc-font-secondary, #58595b))}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__title{color:var(--orc-text-secondary, var(--orc-font-secondary, #58595b));font-weight:500}.orc-stepper__content{display:flex;flex-direction:column;align-items:inherit}.orc-stepper__title{font-size:14px;line-height:20px;font-weight:500;transition:color var(--transition-fast)}.orc-stepper__subtitle{font-size:12px;line-height:16px;color:var(--orc-text-muted, #929292);margin-top:2px}.orc-stepper__step-progress{margin-top:8px;width:100%}.orc-stepper__icon{width:18px;height:18px}.orc-stepper__icon--spin{animation:orc-step-spin 1.5s linear infinite}.orc-stepper__custom-icon{font-size:18px;line-height:1}@keyframes orc-step-spin{to{transform:rotate(360deg)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ProgressBarComponent, selector: "orc-progress-bar", inputs: ["value", "mode", "variant", "size", "label", "showValue", "unit", "color", "styleClass", "valueStyleClass", "style", "valuePrefix", "valueSuffix", "rounded", "segments", "currentSegment", "customHeight", "customColor", "customTrackColor", "markers", "ariaLabel", "ariaValueText"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-stepper, orc-steps', standalone: true, imports: [CommonModule, ProgressBarComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav\n  [attr.id]=\"id() || null\"\n  class=\"p-steps p-component orc-stepper\"\n  [class]=\"'p-steps p-component orc-stepper ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'steps'\"\n  [class.orc-stepper--horizontal]=\"orientation() === 'horizontal'\"\n  [class.orc-stepper--vertical]=\"orientation() === 'vertical'\"\n  [class.orc-stepper--numeric]=\"type() === 'numeric'\"\n  [class.orc-stepper--icon]=\"type() === 'icon'\"\n  [attr.aria-label]=\"ariaLabel() || 'Steps'\"\n>\n  <ol class=\"orc-stepper__list\">\n    @for (\n      step of effectiveSteps();\n      track step.id || $index;\n      let idx = $index;\n      let isLast = $last\n    ) {\n      @let status = getStepStatus(idx, step);\n      @let clickableState = isStepClickable(idx, step);\n\n      <li\n        class=\"orc-stepper__item\"\n        [class.orc-stepper__item--completed]=\"status === 'completed'\"\n        [class.orc-stepper__item--active]=\"status === 'active'\"\n        [class.orc-stepper__item--loading]=\"status === 'loading'\"\n        [class.orc-stepper__item--pending]=\"status === 'pending'\"\n        [class.orc-stepper__item--error]=\"status === 'error'\"\n        [class.orc-stepper__item--disabled]=\"step.disabled\"\n        [class.orc-stepper__item--clickable]=\"clickableState\"\n      >\n        <!-- Horizontal Connector Line (Before Step, if not first) -->\n        @if (orientation() === \"horizontal\" && idx > 0) {\n          <div\n            class=\"orc-stepper__connector-line orc-stepper__connector-line--horizontal\"\n            [class.orc-stepper__connector-line--completed]=\"\n              isConnectorCompleted(idx)\n            \"\n          ></div>\n        }\n\n        <!-- Step Trigger Button / Container -->\n        <button\n          type=\"button\"\n          class=\"p-steps-item-link orc-stepper__step-btn\"\n          [disabled]=\"!clickableState\"\n          [attr.tabindex]=\"\n            idx === (focusedIndex() ?? currentStep()) && clickableState ? 0 : -1\n          \"\n          [attr.aria-posinset]=\"idx + 1\"\n          [attr.aria-setsize]=\"effectiveSteps().length\"\n          (click)=\"selectStep(idx, step)\"\n          (focus)=\"onFocus(idx)\"\n          (keydown)=\"onKeydown($event, idx)\"\n          [attr.aria-current]=\"idx === currentStep() ? 'step' : null\"\n        >\n          <!-- Marker Circle (Number or Icon) -->\n          <div class=\"orc-stepper__marker\">\n            @if (status === \"completed\") {\n              <!-- Checkmark SVG -->\n              <svg\n                class=\"orc-stepper__icon orc-stepper__icon--check\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <polyline points=\"20 6 9 17 4 12\"></polyline>\n              </svg>\n            } @else if (\n              status === \"loading\" ||\n              (status === \"active\" && orientation() === \"vertical\")\n            ) {\n              <!-- Spinner / Loader SVG -->\n              <svg\n                class=\"orc-stepper__icon orc-stepper__icon--spin\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2.5\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path d=\"M21 12a9 9 0 1 1-6.219-8.56\"></path>\n              </svg>\n            } @else if (type() === \"numeric\") {\n              <!-- Step Number -->\n              <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n            } @else if (step.icon) {\n              <!-- Custom Icon or Text -->\n              <span class=\"orc-stepper__custom-icon\">{{ step.icon }}</span>\n            } @else {\n              <!-- Fallback to Number -->\n              <span class=\"orc-stepper__number\">{{ idx + 1 }}</span>\n            }\n          </div>\n\n          <!-- Step Label & Description -->\n          <div class=\"orc-stepper__content\">\n            <span class=\"orc-stepper__title\">{{ step.title }}</span>\n            @if (step.subtitle || step.description) {\n              <span class=\"orc-stepper__subtitle\">{{\n                step.subtitle || step.description\n              }}</span>\n            }\n\n            <!-- Embedded Progress Bar in Step (Figma Vertical Stepper Spec) -->\n            @if (\n              step.progress !== undefined &&\n              (status === \"active\" || orientation() === \"vertical\")\n            ) {\n              <div class=\"orc-stepper__step-progress\">\n                <orc-progress-bar\n                  [value]=\"step.progress\"\n                  variant=\"primary\"\n                  [showValue]=\"true\"\n                />\n              </div>\n            }\n          </div>\n        </button>\n\n        <!-- Vertical Connector Line (Below step, if not last) -->\n        @if (orientation() === \"vertical\" && !isLast) {\n          <div\n            class=\"orc-stepper__connector-line orc-stepper__connector-line--vertical\"\n            [class.orc-stepper__connector-line--completed]=\"\n              isConnectorCompleted(idx + 1)\n            \"\n          ></div>\n        }\n      </li>\n    }\n  </ol>\n</nav>\n", styles: [":host{display:block;width:100%}.orc-stepper{width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-stepper__list{display:flex;margin:0;padding:0;list-style:none}.orc-stepper--horizontal .orc-stepper__list{flex-direction:row;align-items:flex-start;justify-content:space-between;width:100%}.orc-stepper--horizontal .orc-stepper__item{display:flex;flex:1;align-items:flex-start;position:relative}.orc-stepper--horizontal .orc-stepper__item:last-child{flex:0 0 auto}.orc-stepper--horizontal .orc-stepper__step-btn{display:flex;flex-direction:column;align-items:center;text-align:center;background:none;border:none;padding:0;margin:0;cursor:default;min-width:100px;outline:none;transition:transform var(--transition-fast)}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--horizontal .orc-stepper__item--clickable .orc-stepper__step-btn:hover .orc-stepper__marker{transform:scale(1.05)}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal{flex:1;height:3px;background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));margin:19px 8px 0;align-self:flex-start;transition:background-color .3s ease}.orc-stepper--horizontal .orc-stepper__connector-line--horizontal.orc-stepper__connector-line--completed{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal .orc-stepper__marker{width:40px;height:40px;border-radius:20px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;font-size:16px;font-weight:500;transition:all .3s ease;box-sizing:border-box}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--horizontal .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-text, var(--orc-font-main, #141414));font-weight:500}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff);border:2px solid var(--orc-surface-raised, #ffffff);box-shadow:0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal .orc-stepper__item--active .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--horizontal .orc-stepper__item--pending .orc-stepper__title{color:var(--orc-text-muted, #929292);font-weight:400}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-interactive-soft);color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--horizontal.orc-stepper--icon .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));color:var(--orc-text-muted, #929292);border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9))}.orc-stepper--vertical .orc-stepper__list{flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__item{position:relative;display:flex;flex-direction:column;width:100%}.orc-stepper--vertical .orc-stepper__step-btn{display:flex;align-items:flex-start;gap:16px;width:100%;text-align:left;background:none;border:none;padding:0;margin:0;cursor:default;outline:none}.orc-stepper--vertical .orc-stepper__item--clickable .orc-stepper__step-btn{cursor:pointer}.orc-stepper--vertical .orc-stepper__marker{width:32px;height:32px;border-radius:200px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-sizing:border-box;transition:all .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical{width:2px;min-height:36px;background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));margin-left:15px;margin-top:4px;margin-bottom:4px;transition:background-color .3s ease}.orc-stepper--vertical .orc-stepper__connector-line--vertical.orc-stepper__connector-line--completed{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--vertical .orc-stepper__content{display:flex;flex-direction:column;gap:4px;flex:1;padding-top:2px;padding-bottom:16px}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__marker{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #ffffff)}.orc-stepper--vertical .orc-stepper__item--completed .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:500}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__marker{background-color:var(--orc-surface-raised, #ffffff);border:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-stepper--vertical .orc-stepper__item--active .orc-stepper__title{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__marker{background-color:var(--orc-surface-raised, #ffffff);border:2px solid var(--orc-border-default, var(--orc-border, #d9d9d9));color:var(--orc-text-secondary, var(--orc-font-secondary, #58595b))}.orc-stepper--vertical .orc-stepper__item--pending .orc-stepper__title{color:var(--orc-text-secondary, var(--orc-font-secondary, #58595b));font-weight:500}.orc-stepper__content{display:flex;flex-direction:column;align-items:inherit}.orc-stepper__title{font-size:14px;line-height:20px;font-weight:500;transition:color var(--transition-fast)}.orc-stepper__subtitle{font-size:12px;line-height:16px;color:var(--orc-text-muted, #929292);margin-top:2px}.orc-stepper__step-progress{margin-top:8px;width:100%}.orc-stepper__icon{width:18px;height:18px}.orc-stepper__icon--spin{animation:orc-step-spin 1.5s linear infinite}.orc-stepper__custom-icon{font-size:18px;line-height:1}@keyframes orc-step-spin{to{transform:rotate(360deg)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], currentStep: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentStep", required: false }] }, { type: i0.Output, args: ["currentStepChange"] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }, { type: i0.Output, args: ["activeIndexChange"] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], exact: [{ type: i0.Input, args: [{ isSignal: true, alias: "exact", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], clickable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickable", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], linear: [{ type: i0.Input, args: [{ isSignal: true, alias: "linear", required: false }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], completed: [{ type: i0.Output, args: ["completed"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { StepperComponent };
//# sourceMappingURL=ciag-orchestra-stepper.mjs.map
