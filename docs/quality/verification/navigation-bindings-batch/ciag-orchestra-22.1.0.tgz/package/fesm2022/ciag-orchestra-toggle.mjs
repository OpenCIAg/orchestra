export { SwitchComponent as ToggleComponent } from '@ciag/orchestra/switch';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-toggle.mjs.map
