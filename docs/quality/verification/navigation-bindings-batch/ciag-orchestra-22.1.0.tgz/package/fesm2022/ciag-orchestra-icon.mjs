import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component } from '@angular/core';

const ORC_MATERIAL_SYMBOL_FAMILIES = ['outlined', 'rounded', 'sharp'];
const SIZE_MAP = {
    xs: '12px',
    sm: '16px',
    md: '24px',
    lg: '32px',
    xl: '40px',
};
const clamp = (value, min, max) => {
    const numericValue = Number.isFinite(value) ? value : min;
    return Math.min(Math.max(numericValue, min), max);
};
const familyName = (family) => `Material Symbols ${family.charAt(0).toUpperCase()}${family.slice(1)}`;
class IconComponent {
    name = input('circle', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    family = input('rounded', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "family" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    fill = input('outline', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fill" }] : /* istanbul ignore next */ []));
    weight = input(400, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weight" }] : /* istanbul ignore next */ []));
    grade = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "grade" }] : /* istanbul ignore next */ []));
    opticalSize = input('auto', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opticalSize" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    title = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    fontFamily = computed(() => familyName(this.family()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fontFamily" }] : /* istanbul ignore next */ []));
    sizeValue = computed(() => {
        const size = this.size();
        return typeof size === 'number' ? `${Math.max(size, 0)}px` : (SIZE_MAP[size] ?? SIZE_MAP['md']);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sizeValue" }] : /* istanbul ignore next */ []));
    opticalSizeValue = computed(() => {
        const opticalSize = this.opticalSize();
        if (typeof opticalSize === 'number')
            return clamp(opticalSize, 20, 48);
        const size = this.size();
        const sizeInPixels = typeof size === 'number' ? size : Number.parseFloat(SIZE_MAP[size] ?? SIZE_MAP['md']);
        return clamp(sizeInPixels, 20, 48);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opticalSizeValue" }] : /* istanbul ignore next */ []));
    opticalSizing = computed(() => 'none', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "opticalSizing" }] : /* istanbul ignore next */ []));
    fontVariationSettings = computed(() => {
        const axes = [
            `'FILL' ${this.fill() === 'filled' ? 1 : 0}`,
            `'wght' ${clamp(this.weight(), 100, 700)}`,
            `'GRAD' ${clamp(this.grade(), -50, 200)}`,
            `'opsz' ${this.opticalSizeValue()}`,
        ];
        return axes.join(', ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fontVariationSettings" }] : /* istanbul ignore next */ []));
    accessibleName = computed(() => this.ariaLabel().trim() || this.title().trim(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accessibleName" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: IconComponent, isStandalone: true, selector: "orc-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, family: { classPropertyName: "family", publicName: "family", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null }, weight: { classPropertyName: "weight", publicName: "weight", isSignal: true, isRequired: false, transformFunction: null }, grade: { classPropertyName: "grade", publicName: "grade", isSignal: true, isRequired: false, transformFunction: null }, opticalSize: { classPropertyName: "opticalSize", publicName: "opticalSize", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<span\n  class=\"orc-icon\"\n  [style.font-family]=\"fontFamily()\"\n  [style.font-size]=\"sizeValue()\"\n  [style.font-variation-settings]=\"fontVariationSettings()\"\n  [style.font-optical-sizing]=\"opticalSizing()\"\n  [attr.role]=\"accessibleName() ? 'img' : null\"\n  [attr.aria-label]=\"accessibleName() || null\"\n  [attr.aria-hidden]=\"accessibleName() ? null : 'true'\"\n  [attr.title]=\"title() || null\"\n>{{ name() }}</span>\n", styles: ["@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";:host{display:inline-flex;vertical-align:middle}.orc-icon{display:inline-block;flex:0 0 auto;font-weight:400;font-style:normal;line-height:1;letter-spacing:normal;text-transform:none;white-space:nowrap;word-wrap:normal;direction:ltr;font-feature-settings:\"liga\";-webkit-font-feature-settings:\"liga\";-webkit-font-smoothing:antialiased}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n  class=\"orc-icon\"\n  [style.font-family]=\"fontFamily()\"\n  [style.font-size]=\"sizeValue()\"\n  [style.font-variation-settings]=\"fontVariationSettings()\"\n  [style.font-optical-sizing]=\"opticalSizing()\"\n  [attr.role]=\"accessibleName() ? 'img' : null\"\n  [attr.aria-label]=\"accessibleName() || null\"\n  [attr.aria-hidden]=\"accessibleName() ? null : 'true'\"\n  [attr.title]=\"title() || null\"\n>{{ name() }}</span>\n", styles: ["@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block\";:host{display:inline-flex;vertical-align:middle}.orc-icon{display:inline-block;flex:0 0 auto;font-weight:400;font-style:normal;line-height:1;letter-spacing:normal;text-transform:none;white-space:nowrap;word-wrap:normal;direction:ltr;font-feature-settings:\"liga\";-webkit-font-feature-settings:\"liga\";-webkit-font-smoothing:antialiased}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], family: [{ type: i0.Input, args: [{ isSignal: true, alias: "family", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], fill: [{ type: i0.Input, args: [{ isSignal: true, alias: "fill", required: false }] }], weight: [{ type: i0.Input, args: [{ isSignal: true, alias: "weight", required: false }] }], grade: [{ type: i0.Input, args: [{ isSignal: true, alias: "grade", required: false }] }], opticalSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "opticalSize", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IconComponent, ORC_MATERIAL_SYMBOL_FAMILIES };
//# sourceMappingURL=ciag-orchestra-icon.mjs.map
