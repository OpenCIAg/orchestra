export * from '@ciag/orchestra/tab-menu';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-tabmenu.mjs.map
