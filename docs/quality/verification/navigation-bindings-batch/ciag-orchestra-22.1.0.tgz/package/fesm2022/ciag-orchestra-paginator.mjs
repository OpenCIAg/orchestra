import * as i0 from '@angular/core';
import { input, model, booleanAttribute, signal, output, computed, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

class PaginatorComponent {
    // ── Inputs & Models (Signals API) ─────────────────────────
    /** Total de itens na coleção de dados */
    totalItems = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalItems" }] : /* istanbul ignore next */ []));
    /** PrimeNG naming alias for totalItems. */
    totalRecords = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    /** Quantidade de itens por página (Two-Way Data Binding) */
    pageSize = model(10, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    /** PrimeNG naming alias for pageSize. */
    rowsInput = input(undefined, { ...(ngDevMode ? { debugName: "rowsInput" } : /* istanbul ignore next */ {}), alias: 'rows' });
    rows = this.pageSize;
    /** PrimeNG zero-based first-row model. */
    first = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "first" }] : /* istanbul ignore next */ []));
    /** Página atual selecionada (1-indexed, Two-Way Data Binding) */
    currentPage = model(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []));
    /** Optional controlled 1-indexed page alias. */
    pageInput = input(undefined, { ...(ngDevMode ? { debugName: "pageInput" } : /* istanbul ignore next */ {}), alias: 'page' });
    page = this.pageInput;
    /** Optional controlled zero-indexed page alias. */
    pageIndexInput = input(undefined, { ...(ngDevMode ? { debugName: "pageIndexInput" } : /* istanbul ignore next */ {}), alias: 'pageIndex' });
    pageIndex = this.pageIndexInput;
    /** Opções de quantidade de itens por página */
    pageSizeOptions = input([10, 20, 50], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : /* istanbul ignore next */ []));
    rowsPerPageOptions = input(undefined, { ...(ngDevMode ? { debugName: "rowsPerPageOptions" } : /* istanbul ignore next */ {}), alias: 'rowsPerPageOptions' });
    /** Se deve exibir o seletor de quantidade de itens por página */
    showPageSizeSelector = input(true, { ...(ngDevMode ? { debugName: "showPageSizeSelector" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Se deve exibir os botões de Primeira e Última página */
    showFirstLastButtons = input(false, { ...(ngDevMode ? { debugName: "showFirstLastButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showFirstLastIcon = input(false, { ...(ngDevMode ? { debugName: "showFirstLastIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Se deve exibir os botões Anterior e Próximo */
    showPrevNextButtons = input(true, { ...(ngDevMode ? { debugName: "showPrevNextButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Se deve exibir o texto informativo de total (ex: 1-20 de 100 itens) */
    showTotalInfo = input(false, { ...(ngDevMode ? { debugName: "showTotalInfo" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCurrentPageReport = input(false, { ...(ngDevMode ? { debugName: "showCurrentPageReport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    currentPageReportTemplate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPageReportTemplate" }] : /* istanbul ignore next */ []));
    alwaysShow = input(false, { ...(ngDevMode ? { debugName: "alwaysShow" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showPageLinks = input(true, { ...(ngDevMode ? { debugName: "showPageLinks" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showJumpToPageDropdown = input(false, { ...(ngDevMode ? { debugName: "showJumpToPageDropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showJumpToPageInput = input(false, { ...(ngDevMode ? { debugName: "showJumpToPageInput" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    locale = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    dropdownAppendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownAppendTo" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    dropdownScrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownScrollHeight" }] : /* istanbul ignore next */ []));
    templateLeft = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templateLeft" }] : /* istanbul ignore next */ []));
    templateRight = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templateRight" }] : /* istanbul ignore next */ []));
    style = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /** Se o componente está desabilitado */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Tamanho visual do componente ('sm' | 'md' | 'lg') */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Quantidade máxima de botões numéricos visíveis antes de colapsar */
    maxVisiblePages = input(7, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxVisiblePages" }] : /* istanbul ignore next */ []));
    pageLinkSizeInput = input(undefined, { ...(ngDevMode ? { debugName: "pageLinkSizeInput" } : /* istanbul ignore next */ {}), alias: 'pageLinkSize' });
    /** Rótulo do botão Anterior */
    previousLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousLabel" }] : /* istanbul ignore next */ []));
    /** Rótulo do botão Próximo */
    nextLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextLabel" }] : /* istanbul ignore next */ []));
    /** Rótulo do botão Primeira Página */
    firstLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstLabel" }] : /* istanbul ignore next */ []));
    /** Rótulo do botão Última Página */
    lastLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "lastLabel" }] : /* istanbul ignore next */ []));
    /** Sufixo exibido no seletor de itens (ex: "20 / Página") */
    itemsPerPageLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemsPerPageLabel" }] : /* istanbul ignore next */ []));
    /** Atributo de acessibilidade aria-label da tag nav */
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    jumpAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "jumpAriaLabel" }] : /* istanbul ignore next */ []));
    pageAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageAriaLabel" }] : /* istanbul ignore next */ []));
    pageNumberAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageNumberAriaLabel" }] : /* istanbul ignore next */ []));
    pageSizeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSizeAriaLabel" }] : /* istanbul ignore next */ []));
    jumpPageInput = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "jumpPageInput" }] : /* istanbul ignore next */ []));
    pageSizeOverride = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSizeOverride" }] : /* istanbul ignore next */ []));
    localPageSizeWrite = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "localPageSizeWrite" }] : /* istanbul ignore next */ []));
    previousRowsInput;
    previousPageInput;
    previousPageIndexInput;
    previousPageSizeInput = 10;
    previousFirst = 0;
    previousPage = 1;
    previousPageSize = 10;
    // ── Outputs (Event Emitting) ──────────────────────────────
    /** Disparado sempre que a página ou o pageSize é alterado */
    pageChange = output();
    onPageChange = output();
    effectiveTotalRecords = computed(() => this.normalizeTotal(this.totalRecords() ?? this.totalItems()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveTotalRecords" }] : /* istanbul ignore next */ []));
    effectivePageSize = computed(() => this.normalizePageSize(this.pageSizeOverride() ?? this.pageSize()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePageSize" }] : /* istanbul ignore next */ []));
    effectivePageSizeOptions = computed(() => {
        const options = this.rowsPerPageOptions() ?? this.pageSizeOptions();
        const values = (Array.isArray(options) ? options : [])
            .map((value) => this.normalizePageSize(value))
            .filter((value, index, all) => all.indexOf(value) === index);
        if (values.length === 0)
            return values;
        const current = this.effectivePageSize();
        return values.includes(current) ? values : [current, ...values];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePageSizeOptions" }] : /* istanbul ignore next */ []));
    effectivePageLinkSize = computed(() => this.normalizePageSize(this.pageLinkSizeInput() ?? this.maxVisiblePages()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePageLinkSize" }] : /* istanbul ignore next */ []));
    effectiveShowFirstLast = computed(() => this.showFirstLastButtons() || this.showFirstLastIcon(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveShowFirstLast" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const rowsInput = this.rowsInput();
            const pageInput = this.pageInput();
            const pageIndexInput = this.pageIndexInput();
            const first = this.normalizeFirst(this.first());
            const page = this.normalizePage(this.currentPage());
            const rawPageSize = this.normalizePageSize(this.pageSize());
            const rows = this.effectivePageSize();
            const totalPages = this.totalPages();
            const rowsChanged = rowsInput !== this.previousRowsInput;
            const pageAliasChanged = pageInput !== this.previousPageInput;
            const pageIndexAliasChanged = pageIndexInput !== this.previousPageIndexInput;
            const pageSizeInputChanged = rawPageSize !== this.previousPageSizeInput;
            const firstChanged = first !== this.previousFirst;
            const pageChanged = page !== this.previousPage;
            const sizeChanged = rows !== this.previousPageSize;
            // A controlled rows input supersedes a value selected inside the component.
            if (rowsChanged) {
                this.previousRowsInput = rowsInput;
                if (this.pageSizeOverride() !== undefined)
                    this.pageSizeOverride.set(undefined);
                if (!pageSizeInputChanged &&
                    rowsInput !== undefined &&
                    this.normalizePageSize(this.pageSize()) !==
                        this.normalizePageSize(rowsInput)) {
                    this.pageSize.set(this.normalizePageSize(rowsInput));
                }
            }
            if (pageSizeInputChanged) {
                if (this.localPageSizeWrite() === rawPageSize) {
                    this.localPageSizeWrite.set(undefined);
                }
                else if (this.pageSizeOverride() !== undefined) {
                    // A parent pageSize update is authoritative over a previous local
                    // selector choice, just like a parent rows update.
                    this.pageSizeOverride.set(undefined);
                }
                this.previousPageSizeInput = rawPageSize;
            }
            this.previousPageInput = pageInput;
            this.previousPageIndexInput = pageIndexInput;
            // first and currentPage are both public controlled models. Reconcile the
            // model that changed instead of always deriving page from first.
            let targetPage = page;
            if ((pageIndexAliasChanged && pageIndexInput !== undefined) ||
                (pageAliasChanged && pageInput !== undefined)) {
                targetPage =
                    pageIndexAliasChanged && pageIndexInput !== undefined
                        ? this.normalizePage(Number(pageIndexInput) + 1)
                        : this.normalizePage(pageInput);
            }
            else if (firstChanged && !pageChanged) {
                targetPage = Math.floor(first / rows) + 1;
            }
            else if (pageChanged && !firstChanged) {
                targetPage = page;
            }
            else if (firstChanged && pageChanged) {
                // When both are supplied in one update, the explicit page model wins.
                targetPage = page;
            }
            else if (sizeChanged) {
                targetPage = page;
            }
            targetPage = Math.max(1, Math.min(targetPage, totalPages));
            const targetFirst = (targetPage - 1) * rows;
            if (this.currentPage() !== targetPage)
                this.currentPage.set(targetPage);
            if (this.first() !== targetFirst)
                this.first.set(targetFirst);
            this.previousFirst = targetFirst;
            this.previousPage = targetPage;
            this.previousPageSize = rows;
        });
    }
    normalizePageSize(value) {
        const normalized = Number(value);
        return Number.isFinite(normalized) && normalized > 0
            ? Math.max(1, Math.floor(normalized))
            : 1;
    }
    normalizeTotal(value) {
        const normalized = Number(value);
        return Number.isFinite(normalized) && normalized > 0
            ? Math.floor(normalized)
            : 0;
    }
    normalizeFirst(value) {
        const normalized = Number(value);
        return Number.isFinite(normalized)
            ? Math.max(0, Math.floor(normalized))
            : 0;
    }
    normalizePage(value) {
        const normalized = Number(value);
        return Number.isFinite(normalized)
            ? Math.max(1, Math.floor(normalized))
            : 1;
    }
    // ── Computeds (Reatividade Inteligente) ────────────────────
    /** Total de páginas calculado dinamicamente */
    totalPages = computed(() => {
        const total = this.effectiveTotalRecords();
        const size = this.effectivePageSize();
        return Math.max(1, Math.ceil(total / size));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []));
    effectiveCurrentPage = computed(() => Math.max(1, Math.min(this.normalizePage(this.currentPage()), this.totalPages())), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveCurrentPage" }] : /* istanbul ignore next */ []));
    shouldRender = computed(() => this.alwaysShow() || this.totalPages() > 1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shouldRender" }] : /* istanbul ignore next */ []));
    /** Índice inicial do intervalo visível (1-indexed) */
    startIndex = computed(() => {
        if (this.effectiveTotalRecords() === 0)
            return 0;
        return (this.effectiveCurrentPage() - 1) * this.effectivePageSize() + 1;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "startIndex" }] : /* istanbul ignore next */ []));
    /** Índice final do intervalo visível (1-indexed) */
    endIndex = computed(() => {
        return Math.min(this.effectiveCurrentPage() * this.effectivePageSize(), this.effectiveTotalRecords());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "endIndex" }] : /* istanbul ignore next */ []));
    pageReport = computed(() => {
        const template = this.currentPageReportTemplate();
        const first = this.startIndex();
        const last = this.endIndex();
        const total = this.effectiveTotalRecords();
        if (!template)
            return `${first}-${last} of ${total}`;
        return template
            .replaceAll('{first}', String(first))
            .replaceAll('{last}', String(last))
            .replaceAll('{totalRecords}', String(total))
            .replaceAll('{currentPage}', String(this.effectiveCurrentPage()))
            .replaceAll('{totalPages}', String(this.totalPages()));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageReport" }] : /* istanbul ignore next */ []));
    /** Se está na primeira página */
    isFirstPage = computed(() => this.effectiveCurrentPage() <= 1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFirstPage" }] : /* istanbul ignore next */ []));
    /** Se está na última página */
    isLastPage = computed(() => this.effectiveCurrentPage() >= this.totalPages(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isLastPage" }] : /* istanbul ignore next */ []));
    /** Lista inteligente de páginas e reticências a serem renderizadas */
    visiblePages = computed(() => {
        const total = this.totalPages();
        const current = this.effectiveCurrentPage();
        const max = this.effectivePageLinkSize();
        if (total <= max) {
            return Array.from({ length: total }, (_, i) => i + 1);
        }
        const pages = [];
        if (max === 1)
            return [current];
        if (max === 2) {
            if (current <= 1 || current >= total)
                return [1, total];
            return current <= Math.ceil(total / 2) ? [1, current] : [current, total];
        }
        // Reserve two numeric links for the first and last pages. The bounded
        // middle window always contains the active page and never duplicates them.
        const middleCount = max - 2;
        const lastMiddleStart = total - middleCount;
        const middleStart = Math.max(2, Math.min(current - Math.floor((middleCount - 1) / 2), lastMiddleStart));
        const middleEnd = Math.min(total - 1, middleStart + middleCount - 1);
        pages.push(1);
        if (middleStart > 2)
            pages.push('ellipsis');
        for (let page = middleStart; page <= middleEnd; page++)
            pages.push(page);
        if (middleEnd < total - 1)
            pages.push('ellipsis');
        pages.push(total);
        return pages;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visiblePages" }] : /* istanbul ignore next */ []));
    allPages = computed(() => Array.from({ length: this.totalPages() }, (_, index) => index + 1), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allPages" }] : /* istanbul ignore next */ []));
    // ── Ações de Navegação ────────────────────────────────────
    /** Navega para uma página específica */
    goToPage(page) {
        if (this.disabled())
            return;
        const requested = Number(page);
        if (!Number.isFinite(requested))
            return;
        const target = Math.max(1, Math.min(Math.floor(requested), this.totalPages()));
        if (target !== this.effectiveCurrentPage()) {
            this.currentPage.set(target);
            this.first.set((target - 1) * this.effectivePageSize());
            this.emitPageChangeEvent();
        }
    }
    jumpToPage() {
        const raw = this.jumpPageInput().trim();
        const target = Number(raw);
        if (raw && Number.isFinite(target))
            this.goToPage(target);
        this.jumpPageInput.set('');
    }
    onJumpInputKeydown(event) {
        if (event.key !== 'Enter')
            return;
        if (event.cancelable)
            event.preventDefault();
        this.jumpToPage();
    }
    /** Navega para a página anterior */
    prevPage() {
        if (!this.isFirstPage() && !this.disabled()) {
            this.goToPage(this.currentPage() - 1);
        }
    }
    /** Navega para a próxima página */
    nextPage() {
        if (!this.isLastPage() && !this.disabled()) {
            this.goToPage(this.currentPage() + 1);
        }
    }
    /** Navega para a primeira página */
    firstPage() {
        if (!this.isFirstPage() && !this.disabled()) {
            this.goToPage(1);
        }
    }
    /** Navega para a última página */
    lastPage() {
        if (!this.isLastPage() && !this.disabled()) {
            this.goToPage(this.totalPages());
        }
    }
    /** Manipula a mudança de itens por página via select */
    onPageSizeChange(event) {
        if (this.disabled())
            return;
        const select = event.target;
        const newSize = this.normalizePageSize(Number(select.value));
        if (newSize !== this.effectivePageSize()) {
            this.localPageSizeWrite.set(newSize);
            this.pageSize.set(newSize);
            this.pageSizeOverride.set(newSize);
            // Ajusta a página atual caso exceda o novo total de páginas
            const newTotalPages = Math.max(1, Math.ceil(this.effectiveTotalRecords() / newSize));
            const targetPage = Math.max(1, Math.min(this.normalizePage(this.currentPage()), newTotalPages));
            this.currentPage.set(targetPage);
            this.first.set((targetPage - 1) * newSize);
            this.emitPageChangeEvent();
        }
    }
    /** Emite o evento unificado de alteração */
    emitPageChangeEvent() {
        this.pageChange.emit({
            first: this.first(),
            rows: this.effectivePageSize(),
            page: this.currentPage(),
            pageSize: this.effectivePageSize(),
            totalPages: this.totalPages(),
            startIndex: this.startIndex(),
            endIndex: this.endIndex(),
            totalItems: this.effectiveTotalRecords(),
        });
        this.onPageChange.emit({
            first: this.first(),
            rows: this.effectivePageSize(),
            page: this.currentPage(),
            pageSize: this.effectivePageSize(),
            totalPages: this.totalPages(),
            startIndex: this.startIndex(),
            endIndex: this.endIndex(),
            totalItems: this.effectiveTotalRecords(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: PaginatorComponent, isStandalone: true, selector: "orc-paginator, orc-pagination", inputs: { totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, rowsInput: { classPropertyName: "rowsInput", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, pageInput: { classPropertyName: "pageInput", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, pageIndexInput: { classPropertyName: "pageIndexInput", publicName: "pageIndex", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, showPageSizeSelector: { classPropertyName: "showPageSizeSelector", publicName: "showPageSizeSelector", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastButtons: { classPropertyName: "showFirstLastButtons", publicName: "showFirstLastButtons", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastIcon: { classPropertyName: "showFirstLastIcon", publicName: "showFirstLastIcon", isSignal: true, isRequired: false, transformFunction: null }, showPrevNextButtons: { classPropertyName: "showPrevNextButtons", publicName: "showPrevNextButtons", isSignal: true, isRequired: false, transformFunction: null }, showTotalInfo: { classPropertyName: "showTotalInfo", publicName: "showTotalInfo", isSignal: true, isRequired: false, transformFunction: null }, showCurrentPageReport: { classPropertyName: "showCurrentPageReport", publicName: "showCurrentPageReport", isSignal: true, isRequired: false, transformFunction: null }, currentPageReportTemplate: { classPropertyName: "currentPageReportTemplate", publicName: "currentPageReportTemplate", isSignal: true, isRequired: false, transformFunction: null }, alwaysShow: { classPropertyName: "alwaysShow", publicName: "alwaysShow", isSignal: true, isRequired: false, transformFunction: null }, showPageLinks: { classPropertyName: "showPageLinks", publicName: "showPageLinks", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageDropdown: { classPropertyName: "showJumpToPageDropdown", publicName: "showJumpToPageDropdown", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageInput: { classPropertyName: "showJumpToPageInput", publicName: "showJumpToPageInput", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, dropdownAppendTo: { classPropertyName: "dropdownAppendTo", publicName: "dropdownAppendTo", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, dropdownScrollHeight: { classPropertyName: "dropdownScrollHeight", publicName: "dropdownScrollHeight", isSignal: true, isRequired: false, transformFunction: null }, templateLeft: { classPropertyName: "templateLeft", publicName: "templateLeft", isSignal: true, isRequired: false, transformFunction: null }, templateRight: { classPropertyName: "templateRight", publicName: "templateRight", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, maxVisiblePages: { classPropertyName: "maxVisiblePages", publicName: "maxVisiblePages", isSignal: true, isRequired: false, transformFunction: null }, pageLinkSizeInput: { classPropertyName: "pageLinkSizeInput", publicName: "pageLinkSize", isSignal: true, isRequired: false, transformFunction: null }, previousLabel: { classPropertyName: "previousLabel", publicName: "previousLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, firstLabel: { classPropertyName: "firstLabel", publicName: "firstLabel", isSignal: true, isRequired: false, transformFunction: null }, lastLabel: { classPropertyName: "lastLabel", publicName: "lastLabel", isSignal: true, isRequired: false, transformFunction: null }, itemsPerPageLabel: { classPropertyName: "itemsPerPageLabel", publicName: "itemsPerPageLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, jumpAriaLabel: { classPropertyName: "jumpAriaLabel", publicName: "jumpAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, pageAriaLabel: { classPropertyName: "pageAriaLabel", publicName: "pageAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, pageNumberAriaLabel: { classPropertyName: "pageNumberAriaLabel", publicName: "pageNumberAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, pageSizeAriaLabel: { classPropertyName: "pageSizeAriaLabel", publicName: "pageSizeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, jumpPageInput: { classPropertyName: "jumpPageInput", publicName: "jumpPageInput", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageSize: "pageSizeChange", first: "firstChange", currentPage: "currentPageChange", jumpPageInput: "jumpPageInputChange", pageChange: "pageChange", onPageChange: "onPageChange" }, ngImport: i0, template: "<nav\n  class=\"p-paginator p-component orc-paginator\"\n  [class.orc-paginator--always-visible]=\"alwaysShow()\"\n  [class.orc-paginator--no-links]=\"!showPageLinks()\"\n  [class]=\"'p-paginator p-component orc-paginator ' + (styleClass() || '')\"\n  [ngStyle]=\"style()\"\n  [hidden]=\"!shouldRender()\"\n  [attr.data-pc-name]=\"'paginator'\"\n  [attr.aria-label]=\"ariaLabel() || 'Pagination'\"\n  [class.orc-paginator--disabled]=\"disabled()\"\n  [class.orc-paginator--sm]=\"size() === 'sm'\"\n  [class.orc-paginator--lg]=\"size() === 'lg'\"\n>\n  <!-- Texto Informativo de Itens (Opcional) -->\n  <div\n    *ngIf=\"(showTotalInfo() || showCurrentPageReport()) && pageReport()\"\n    class=\"orc-paginator__info\"\n  >\n    {{ pageReport() }}\n  </div>\n\n  <!-- Lista de Navega\u00E7\u00E3o e P\u00E1ginas -->\n  <ul class=\"orc-paginator__list\" role=\"list\">\n    <!-- Bot\u00E3o: Primeira P\u00E1gina (Opcional) -->\n    <li *ngIf=\"effectiveShowFirstLast()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--first\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"firstPage()\"\n        [attr.aria-label]=\"firstLabel() || 'First page'\"\n        [attr.title]=\"firstLabel() || null\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M11 12L7 8L11 4M7 12L3 8L7 4\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: Anterior (Figma Node 18:1752) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--prev\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"prevPage()\"\n        [attr.aria-label]=\"previousLabel() || 'Previous page'\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M10 12L6 8L10 4\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        @if (previousLabel()) {\n          <span class=\"orc-paginator__btn-text\">{{ previousLabel() }}</span>\n        }\n      </button>\n    </li>\n\n    <!-- Bot\u00F5es Num\u00E9ricos e Retic\u00EAncias (Figma Nodes 18:1758 - 18:1773) -->\n    <ng-container *ngIf=\"showPageLinks()\">\n      <ng-container *ngFor=\"let p of visiblePages()\">\n        <!-- N\u00FAmero da P\u00E1gina -->\n        <li *ngIf=\"p !== 'ellipsis'\">\n          <button\n            type=\"button\"\n            class=\"orc-paginator__btn orc-paginator__btn--page\"\n            [class.orc-paginator__btn--active]=\"p === effectiveCurrentPage()\"\n            [attr.aria-current]=\"p === effectiveCurrentPage() ? 'page' : null\"\n            [disabled]=\"disabled()\"\n            (click)=\"goToPage(+p)\"\n            [attr.aria-label]=\"\n              pageAriaLabel() ? pageAriaLabel() + ' ' + p : 'Page ' + p\n            \"\n          >\n            {{ p }}\n          </button>\n        </li>\n\n        <!-- Retic\u00EAncias (...) -->\n        <li\n          *ngIf=\"p === 'ellipsis'\"\n          class=\"orc-paginator__ellipsis\"\n          aria-hidden=\"true\"\n        >\n          <svg class=\"orc-paginator__icon-dots\" viewBox=\"0 0 16 16\" fill=\"none\">\n            <circle cx=\"4\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n            <circle cx=\"8\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n            <circle cx=\"12\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n          </svg>\n        </li>\n      </ng-container>\n    </ng-container>\n\n    <!-- Bot\u00E3o: Pr\u00F3ximo (Figma Node 32:18542) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--next\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"nextPage()\"\n        [attr.aria-label]=\"nextLabel() || 'Next page'\"\n      >\n        @if (nextLabel()) {\n          <span class=\"orc-paginator__btn-text\">{{ nextLabel() }}</span>\n        }\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M6 4L10 8L6 12\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: \u00DAltima P\u00E1gina (Opcional) -->\n    <li *ngIf=\"effectiveShowFirstLast()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--last\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"lastPage()\"\n        [attr.aria-label]=\"lastLabel() || 'Last page'\"\n        [attr.title]=\"lastLabel() || null\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M5 4L9 8L5 12M9 4L13 8L9 12\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n  </ul>\n\n  @if (showJumpToPageDropdown() || showJumpToPageInput()) {\n    <div\n      class=\"orc-paginator__jump\"\n      role=\"group\"\n      [attr.aria-label]=\"jumpAriaLabel() || 'Jump to page'\"\n    >\n      @if (showJumpToPageDropdown()) {\n        <select\n          [value]=\"effectiveCurrentPage()\"\n          (change)=\"goToPage(+$any($event.target).value)\"\n          [disabled]=\"disabled()\"\n          [attr.aria-label]=\"pageAriaLabel() || 'Jump to page'\"\n        >\n          @for (page of allPages(); track page) {\n            <option [value]=\"page\">{{ page }}</option>\n          }\n        </select>\n      }\n      @if (showJumpToPageInput()) {\n        <input\n          type=\"number\"\n          min=\"1\"\n          [max]=\"totalPages()\"\n          [value]=\"jumpPageInput()\"\n          (input)=\"jumpPageInput.set($any($event.target).value)\"\n          (change)=\"jumpToPage()\"\n          (keydown)=\"onJumpInputKeydown($event)\"\n          [disabled]=\"disabled()\"\n          [attr.aria-label]=\"pageNumberAriaLabel() || 'Page number'\"\n        />\n      }\n    </div>\n  }\n\n  <!-- Seletor de Itens por P\u00E1gina (Figma Node 32:18566: \"20 / P\u00E1gina\") -->\n  <div\n    *ngIf=\"showPageSizeSelector() && effectivePageSizeOptions().length > 0\"\n    class=\"orc-paginator__page-size\"\n  >\n    <select\n      class=\"orc-paginator__select\"\n      [disabled]=\"disabled()\"\n      [value]=\"effectivePageSize()\"\n      (change)=\"onPageSizeChange($event)\"\n      [attr.aria-label]=\"pageSizeAriaLabel() || 'Items per page'\"\n    >\n      <option *ngFor=\"let opt of effectivePageSizeOptions()\" [value]=\"opt\">\n        @if (itemsPerPageLabel()) {\n          {{ opt }} / {{ itemsPerPageLabel() }}\n        } @else {\n          {{ opt }}\n        }\n      </option>\n    </select>\n    <div class=\"orc-paginator__select-icon\" aria-hidden=\"true\">\n      <svg viewBox=\"0 0 16 16\" fill=\"none\">\n        <path\n          d=\"M4 6L8 10L12 6\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </div>\n  </div>\n</nav>\n", styles: [":host{display:block;width:100%}.orc-paginator{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4, 16px);width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif);-webkit-user-select:none;user-select:none}.orc-paginator__info{font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap}.orc-paginator__info strong{color:var(--orc-text, var(--orc-font-main, #141414));font-weight:600}.orc-paginator__list{display:inline-flex;align-items:center;gap:4px;list-style:none;margin:0;padding:0;height:36px}.orc-paginator__btn{display:inline-flex;align-items:center;justify-content:center;height:36px;background:transparent;border:none;border-radius:8px;color:var(--orc-text, var(--orc-font-main, #141414));font-family:inherit;font-size:.875rem;font-weight:400;line-height:20px;cursor:pointer;transition:all var(--transition-fast, .12s ease);outline:none;text-decoration:none}.orc-paginator__btn:hover:not(:disabled){background:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-paginator__btn:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-paginator__btn:disabled,.orc-paginator__btn[aria-disabled=true]{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-paginator__btn--page{min-width:36px;width:36px;padding:0}.orc-paginator__btn--active{background:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));font-weight:600;color:var(--orc-text, var(--orc-font-main, #141414));cursor:default}.orc-paginator__btn--active:hover{background:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-paginator__btn--nav{padding:8px 12px;gap:4px;min-width:36px}.orc-paginator__btn--first,.orc-paginator__btn--last{padding:0;width:36px}.orc-paginator__btn-text{font-size:.875rem;line-height:20px;color:inherit}.orc-paginator__icon{width:16px;height:16px;display:block;flex-shrink:0}.orc-paginator__ellipsis{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-paginator__icon-dots{width:16px;height:16px}.orc-paginator__page-size{position:relative;display:inline-flex;align-items:center;height:36px}.orc-paginator__select{appearance:none;-webkit-appearance:none;-moz-appearance:none;height:36px;background:var(--orc-control-surface, var(--orc-fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:10px;padding:3px 36px 3px 12px;font-family:inherit;font-size:.875rem;line-height:22px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));cursor:pointer;outline:none;transition:all var(--transition-fast, .12s ease)}.orc-paginator__select:hover:not(:disabled){border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-paginator__select:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-paginator__select:disabled{opacity:.4;cursor:not-allowed;background:var(--orc-surface-muted, var(--bg-muted, #ededed))}.orc-paginator__select-icon{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:16px;height:16px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));pointer-events:none;display:flex;align-items:center;justify-content:center}.orc-paginator__select-icon svg{width:100%;height:100%}.orc-paginator--sm .orc-paginator__list,.orc-paginator--sm .orc-paginator__page-size{height:30px}.orc-paginator--sm .orc-paginator__btn{height:30px;font-size:.75rem}.orc-paginator--sm .orc-paginator__btn--page{width:30px;min-width:30px}.orc-paginator--sm .orc-paginator__btn--nav{padding:4px 8px}.orc-paginator--sm .orc-paginator__ellipsis{width:30px;height:30px}.orc-paginator--sm .orc-paginator__select{height:30px;font-size:.75rem;padding:2px 30px 2px 10px;border-radius:8px}.orc-paginator--lg .orc-paginator__list,.orc-paginator--lg .orc-paginator__page-size{height:42px}.orc-paginator--lg .orc-paginator__btn{height:42px;font-size:1rem}.orc-paginator--lg .orc-paginator__btn--page{width:42px;min-width:42px}.orc-paginator--lg .orc-paginator__btn--nav{padding:10px 16px}.orc-paginator--lg .orc-paginator__ellipsis{width:42px;height:42px}.orc-paginator--lg .orc-paginator__select{height:42px;font-size:1rem;padding:4px 40px 4px 14px;border-radius:12px}.orc-paginator--disabled{opacity:.5;pointer-events:none}@media(max-width:768px){.orc-paginator{flex-direction:column;align-items:center;gap:var(--space-3, 12px)}.orc-paginator__info{max-width:100%;white-space:normal;text-align:center}.orc-paginator__list{flex-wrap:wrap;justify-content:center;height:auto}.orc-paginator__page-size{width:100%;justify-content:center}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-paginator, orc-pagination', standalone: true, imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav\n  class=\"p-paginator p-component orc-paginator\"\n  [class.orc-paginator--always-visible]=\"alwaysShow()\"\n  [class.orc-paginator--no-links]=\"!showPageLinks()\"\n  [class]=\"'p-paginator p-component orc-paginator ' + (styleClass() || '')\"\n  [ngStyle]=\"style()\"\n  [hidden]=\"!shouldRender()\"\n  [attr.data-pc-name]=\"'paginator'\"\n  [attr.aria-label]=\"ariaLabel() || 'Pagination'\"\n  [class.orc-paginator--disabled]=\"disabled()\"\n  [class.orc-paginator--sm]=\"size() === 'sm'\"\n  [class.orc-paginator--lg]=\"size() === 'lg'\"\n>\n  <!-- Texto Informativo de Itens (Opcional) -->\n  <div\n    *ngIf=\"(showTotalInfo() || showCurrentPageReport()) && pageReport()\"\n    class=\"orc-paginator__info\"\n  >\n    {{ pageReport() }}\n  </div>\n\n  <!-- Lista de Navega\u00E7\u00E3o e P\u00E1ginas -->\n  <ul class=\"orc-paginator__list\" role=\"list\">\n    <!-- Bot\u00E3o: Primeira P\u00E1gina (Opcional) -->\n    <li *ngIf=\"effectiveShowFirstLast()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--first\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"firstPage()\"\n        [attr.aria-label]=\"firstLabel() || 'First page'\"\n        [attr.title]=\"firstLabel() || null\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M11 12L7 8L11 4M7 12L3 8L7 4\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: Anterior (Figma Node 18:1752) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--prev\"\n        [disabled]=\"isFirstPage() || disabled()\"\n        [attr.aria-disabled]=\"isFirstPage() || disabled()\"\n        (click)=\"prevPage()\"\n        [attr.aria-label]=\"previousLabel() || 'Previous page'\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M10 12L6 8L10 4\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n        @if (previousLabel()) {\n          <span class=\"orc-paginator__btn-text\">{{ previousLabel() }}</span>\n        }\n      </button>\n    </li>\n\n    <!-- Bot\u00F5es Num\u00E9ricos e Retic\u00EAncias (Figma Nodes 18:1758 - 18:1773) -->\n    <ng-container *ngIf=\"showPageLinks()\">\n      <ng-container *ngFor=\"let p of visiblePages()\">\n        <!-- N\u00FAmero da P\u00E1gina -->\n        <li *ngIf=\"p !== 'ellipsis'\">\n          <button\n            type=\"button\"\n            class=\"orc-paginator__btn orc-paginator__btn--page\"\n            [class.orc-paginator__btn--active]=\"p === effectiveCurrentPage()\"\n            [attr.aria-current]=\"p === effectiveCurrentPage() ? 'page' : null\"\n            [disabled]=\"disabled()\"\n            (click)=\"goToPage(+p)\"\n            [attr.aria-label]=\"\n              pageAriaLabel() ? pageAriaLabel() + ' ' + p : 'Page ' + p\n            \"\n          >\n            {{ p }}\n          </button>\n        </li>\n\n        <!-- Retic\u00EAncias (...) -->\n        <li\n          *ngIf=\"p === 'ellipsis'\"\n          class=\"orc-paginator__ellipsis\"\n          aria-hidden=\"true\"\n        >\n          <svg class=\"orc-paginator__icon-dots\" viewBox=\"0 0 16 16\" fill=\"none\">\n            <circle cx=\"4\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n            <circle cx=\"8\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n            <circle cx=\"12\" cy=\"8\" r=\"1.25\" fill=\"currentColor\" />\n          </svg>\n        </li>\n      </ng-container>\n    </ng-container>\n\n    <!-- Bot\u00E3o: Pr\u00F3ximo (Figma Node 32:18542) -->\n    <li *ngIf=\"showPrevNextButtons()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--next\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"nextPage()\"\n        [attr.aria-label]=\"nextLabel() || 'Next page'\"\n      >\n        @if (nextLabel()) {\n          <span class=\"orc-paginator__btn-text\">{{ nextLabel() }}</span>\n        }\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M6 4L10 8L6 12\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n\n    <!-- Bot\u00E3o: \u00DAltima P\u00E1gina (Opcional) -->\n    <li *ngIf=\"effectiveShowFirstLast()\">\n      <button\n        type=\"button\"\n        class=\"orc-paginator__btn orc-paginator__btn--nav orc-paginator__btn--last\"\n        [disabled]=\"isLastPage() || disabled()\"\n        [attr.aria-disabled]=\"isLastPage() || disabled()\"\n        (click)=\"lastPage()\"\n        [attr.aria-label]=\"lastLabel() || 'Last page'\"\n        [attr.title]=\"lastLabel() || null\"\n      >\n        <svg\n          class=\"orc-paginator__icon\"\n          viewBox=\"0 0 16 16\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M5 4L9 8L5 12M9 4L13 8L9 12\"\n            stroke=\"currentColor\"\n            stroke-width=\"1.5\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      </button>\n    </li>\n  </ul>\n\n  @if (showJumpToPageDropdown() || showJumpToPageInput()) {\n    <div\n      class=\"orc-paginator__jump\"\n      role=\"group\"\n      [attr.aria-label]=\"jumpAriaLabel() || 'Jump to page'\"\n    >\n      @if (showJumpToPageDropdown()) {\n        <select\n          [value]=\"effectiveCurrentPage()\"\n          (change)=\"goToPage(+$any($event.target).value)\"\n          [disabled]=\"disabled()\"\n          [attr.aria-label]=\"pageAriaLabel() || 'Jump to page'\"\n        >\n          @for (page of allPages(); track page) {\n            <option [value]=\"page\">{{ page }}</option>\n          }\n        </select>\n      }\n      @if (showJumpToPageInput()) {\n        <input\n          type=\"number\"\n          min=\"1\"\n          [max]=\"totalPages()\"\n          [value]=\"jumpPageInput()\"\n          (input)=\"jumpPageInput.set($any($event.target).value)\"\n          (change)=\"jumpToPage()\"\n          (keydown)=\"onJumpInputKeydown($event)\"\n          [disabled]=\"disabled()\"\n          [attr.aria-label]=\"pageNumberAriaLabel() || 'Page number'\"\n        />\n      }\n    </div>\n  }\n\n  <!-- Seletor de Itens por P\u00E1gina (Figma Node 32:18566: \"20 / P\u00E1gina\") -->\n  <div\n    *ngIf=\"showPageSizeSelector() && effectivePageSizeOptions().length > 0\"\n    class=\"orc-paginator__page-size\"\n  >\n    <select\n      class=\"orc-paginator__select\"\n      [disabled]=\"disabled()\"\n      [value]=\"effectivePageSize()\"\n      (change)=\"onPageSizeChange($event)\"\n      [attr.aria-label]=\"pageSizeAriaLabel() || 'Items per page'\"\n    >\n      <option *ngFor=\"let opt of effectivePageSizeOptions()\" [value]=\"opt\">\n        @if (itemsPerPageLabel()) {\n          {{ opt }} / {{ itemsPerPageLabel() }}\n        } @else {\n          {{ opt }}\n        }\n      </option>\n    </select>\n    <div class=\"orc-paginator__select-icon\" aria-hidden=\"true\">\n      <svg viewBox=\"0 0 16 16\" fill=\"none\">\n        <path\n          d=\"M4 6L8 10L12 6\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </div>\n  </div>\n</nav>\n", styles: [":host{display:block;width:100%}.orc-paginator{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4, 16px);width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif);-webkit-user-select:none;user-select:none}.orc-paginator__info{font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap}.orc-paginator__info strong{color:var(--orc-text, var(--orc-font-main, #141414));font-weight:600}.orc-paginator__list{display:inline-flex;align-items:center;gap:4px;list-style:none;margin:0;padding:0;height:36px}.orc-paginator__btn{display:inline-flex;align-items:center;justify-content:center;height:36px;background:transparent;border:none;border-radius:8px;color:var(--orc-text, var(--orc-font-main, #141414));font-family:inherit;font-size:.875rem;font-weight:400;line-height:20px;cursor:pointer;transition:all var(--transition-fast, .12s ease);outline:none;text-decoration:none}.orc-paginator__btn:hover:not(:disabled){background:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-paginator__btn:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-paginator__btn:disabled,.orc-paginator__btn[aria-disabled=true]{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-paginator__btn--page{min-width:36px;width:36px;padding:0}.orc-paginator__btn--active{background:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));font-weight:600;color:var(--orc-text, var(--orc-font-main, #141414));cursor:default}.orc-paginator__btn--active:hover{background:var(--orc-surface-subtle, var(--orc-th, #f9f9f9));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-paginator__btn--nav{padding:8px 12px;gap:4px;min-width:36px}.orc-paginator__btn--first,.orc-paginator__btn--last{padding:0;width:36px}.orc-paginator__btn-text{font-size:.875rem;line-height:20px;color:inherit}.orc-paginator__icon{width:16px;height:16px;display:block;flex-shrink:0}.orc-paginator__ellipsis{display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-paginator__icon-dots{width:16px;height:16px}.orc-paginator__page-size{position:relative;display:inline-flex;align-items:center;height:36px}.orc-paginator__select{appearance:none;-webkit-appearance:none;-moz-appearance:none;height:36px;background:var(--orc-control-surface, var(--orc-fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:10px;padding:3px 36px 3px 12px;font-family:inherit;font-size:.875rem;line-height:22px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));cursor:pointer;outline:none;transition:all var(--transition-fast, .12s ease)}.orc-paginator__select:hover:not(:disabled){border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-paginator__select:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-paginator__select:disabled{opacity:.4;cursor:not-allowed;background:var(--orc-surface-muted, var(--bg-muted, #ededed))}.orc-paginator__select-icon{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:16px;height:16px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));pointer-events:none;display:flex;align-items:center;justify-content:center}.orc-paginator__select-icon svg{width:100%;height:100%}.orc-paginator--sm .orc-paginator__list,.orc-paginator--sm .orc-paginator__page-size{height:30px}.orc-paginator--sm .orc-paginator__btn{height:30px;font-size:.75rem}.orc-paginator--sm .orc-paginator__btn--page{width:30px;min-width:30px}.orc-paginator--sm .orc-paginator__btn--nav{padding:4px 8px}.orc-paginator--sm .orc-paginator__ellipsis{width:30px;height:30px}.orc-paginator--sm .orc-paginator__select{height:30px;font-size:.75rem;padding:2px 30px 2px 10px;border-radius:8px}.orc-paginator--lg .orc-paginator__list,.orc-paginator--lg .orc-paginator__page-size{height:42px}.orc-paginator--lg .orc-paginator__btn{height:42px;font-size:1rem}.orc-paginator--lg .orc-paginator__btn--page{width:42px;min-width:42px}.orc-paginator--lg .orc-paginator__btn--nav{padding:10px 16px}.orc-paginator--lg .orc-paginator__ellipsis{width:42px;height:42px}.orc-paginator--lg .orc-paginator__select{height:42px;font-size:1rem;padding:4px 40px 4px 14px;border-radius:12px}.orc-paginator--disabled{opacity:.5;pointer-events:none}@media(max-width:768px){.orc-paginator{flex-direction:column;align-items:center;gap:var(--space-3, 12px)}.orc-paginator__info{max-width:100%;white-space:normal;text-align:center}.orc-paginator__list{flex-wrap:wrap;justify-content:center;height:auto}.orc-paginator__page-size{width:100%;justify-content:center}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }, { type: i0.Output, args: ["pageSizeChange"] }], rowsInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }, { type: i0.Output, args: ["firstChange"] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }, { type: i0.Output, args: ["currentPageChange"] }], pageInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], pageIndexInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageIndex", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], showPageSizeSelector: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageSizeSelector", required: false }] }], showFirstLastButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastButtons", required: false }] }], showFirstLastIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastIcon", required: false }] }], showPrevNextButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPrevNextButtons", required: false }] }], showTotalInfo: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTotalInfo", required: false }] }], showCurrentPageReport: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCurrentPageReport", required: false }] }], currentPageReportTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPageReportTemplate", required: false }] }], alwaysShow: [{ type: i0.Input, args: [{ isSignal: true, alias: "alwaysShow", required: false }] }], showPageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageLinks", required: false }] }], showJumpToPageDropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageDropdown", required: false }] }], showJumpToPageInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageInput", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], dropdownAppendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownAppendTo", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], dropdownScrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownScrollHeight", required: false }] }], templateLeft: [{ type: i0.Input, args: [{ isSignal: true, alias: "templateLeft", required: false }] }], templateRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "templateRight", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], maxVisiblePages: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxVisiblePages", required: false }] }], pageLinkSizeInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageLinkSize", required: false }] }], previousLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], firstLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "firstLabel", required: false }] }], lastLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "lastLabel", required: false }] }], itemsPerPageLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemsPerPageLabel", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], jumpAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "jumpAriaLabel", required: false }] }], pageAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageAriaLabel", required: false }] }], pageNumberAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageNumberAriaLabel", required: false }] }], pageSizeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeAriaLabel", required: false }] }], jumpPageInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "jumpPageInput", required: false }] }, { type: i0.Output, args: ["jumpPageInputChange"] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], onPageChange: [{ type: i0.Output, args: ["onPageChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { PaginatorComponent as Paginator, PaginatorComponent };
//# sourceMappingURL=ciag-orchestra-paginator.mjs.map
