export { InputComponent as InputText, InputComponent as InputTextComponent } from '@ciag/orchestra/input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-text.mjs.map
