import * as i0 from '@angular/core';
import { input, booleanAttribute, computed, HostBinding, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

class SkeletonComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    variant = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    animation = input('shimmer', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []));
    shape = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    width = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    height = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    borderRadius = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "borderRadius" }] : /* istanbul ignore next */ []));
    fitContent = input(false, { ...(ngDevMode ? { debugName: "fitContent" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    display = input('block', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    // ── Host Bindings ─────────────────────────────────────────
    get hostDisplay() {
        return this.fitContent() ? this.display() : (this.effectiveVariant() === 'circular' ? 'inline-block' : 'block');
    }
    get hostWidth() {
        const w = this.computedWidth();
        return this.fitContent() ? 'inherit' : (w || (this.effectiveVariant() === 'circular' ? '40px' : '100%'));
    }
    hostVerticalAlign = 'middle';
    // ── Computed Dimensions ───────────────────────────────────
    computedWidth = computed(() => {
        const size = this.size();
        if (size)
            return typeof size === 'number' ? `${size}px` : size;
        const w = this.width();
        if (w)
            return typeof w === 'number' ? `${w}px` : w;
        switch (this.effectiveVariant()) {
            case 'circular':
                return '40px';
            case 'text':
            case 'rectangular':
            default:
                return '100%';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedWidth" }] : /* istanbul ignore next */ []));
    computedHeight = computed(() => {
        const size = this.size();
        if (size)
            return typeof size === 'number' ? `${size}px` : size;
        const h = this.height();
        if (h)
            return typeof h === 'number' ? `${h}px` : h;
        switch (this.effectiveVariant()) {
            case 'circular':
                return '40px';
            case 'rectangular':
                return '96px';
            case 'text':
            default:
                return '14px';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedHeight" }] : /* istanbul ignore next */ []));
    computedBorderRadius = computed(() => {
        const r = this.borderRadius();
        if (r)
            return r;
        switch (this.effectiveVariant()) {
            case 'circular':
                return '50%';
            case 'text':
            case 'rectangular':
            default:
                return '8px';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedBorderRadius" }] : /* istanbul ignore next */ []));
    effectiveVariant = computed(() => {
        const shape = this.shape();
        if (shape === 'circle')
            return 'circular';
        if (shape === 'square')
            return 'rectangular';
        return this.variant();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveVariant" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: SkeletonComponent, isStandalone: true, selector: "orc-skeleton", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, animation: { classPropertyName: "animation", publicName: "animation", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, borderRadius: { classPropertyName: "borderRadius", publicName: "borderRadius", isSignal: true, isRequired: false, transformFunction: null }, fitContent: { classPropertyName: "fitContent", publicName: "fitContent", isSignal: true, isRequired: false, transformFunction: null }, display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style.display": "this.hostDisplay", "style.width": "this.hostWidth", "style.vertical-align": "this.hostVerticalAlign" } }, ngImport: i0, template: "<div\n  class=\"p-skeleton p-component orc-skeleton\"\n  [class.orc-skeleton--text]=\"effectiveVariant() === 'text'\"\n  [class.orc-skeleton--circular]=\"effectiveVariant() === 'circular'\"\n  [class.orc-skeleton--rectangular]=\"effectiveVariant() === 'rectangular'\"\n  [class.orc-skeleton--shimmer]=\"animation() === 'shimmer' || animation() === 'wave'\"\n  [class.orc-skeleton--pulse]=\"animation() === 'pulse'\"\n  [class.orc-skeleton--none]=\"animation() === 'none'\"\n  [style.width]=\"computedWidth()\"\n  [style.height]=\"computedHeight()\"\n  [style.border-radius]=\"computedBorderRadius()\"\n  [class]=\"'p-skeleton p-component orc-skeleton ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'skeleton'\"\n  role=\"status\"\n  aria-busy=\"true\"\n  [attr.aria-label]=\"ariaLabel()\"\n>\n  <span class=\"sr-only\">{{ ariaLabel() }}</span>\n</div>\n", styles: [":host{display:block;box-sizing:border-box}.orc-skeleton{display:block;box-sizing:border-box;width:100%;height:100%;background-color:var(--skeleton-base, #F1F5F9);position:relative;overflow:hidden}.orc-skeleton--text{border-radius:8px}.orc-skeleton--circular{border-radius:50%}.orc-skeleton--rectangular{border-radius:8px}.orc-skeleton--shimmer{background-color:var(--skeleton-base, #F1F5F9);background-image:linear-gradient(90deg,var(--skeleton-base, #F1F5F9) 0%,var(--skeleton-highlight, #E2E8F0) 50%,var(--skeleton-base, #F1F5F9) 100%);background-size:200% 100%;background-repeat:no-repeat;animation:orcShimmer 1.5s cubic-bezier(.4,0,.2,1) infinite}.orc-skeleton--pulse{background-color:var(--skeleton-base, #F1F5F9);animation:orcPulse 1.5s ease-in-out infinite}.orc-skeleton--none{animation:none;background-color:var(--skeleton-base, #F1F5F9)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes orcShimmer{0%{background-position:150% 0}to{background-position:-150% 0}}@keyframes orcPulse{0%,to{opacity:1}50%{opacity:.4}}@media(prefers-reduced-motion:reduce){.orc-skeleton--shimmer,.orc-skeleton--pulse{animation:none;background-color:var(--skeleton-base, #F1F5F9)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-skeleton', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"p-skeleton p-component orc-skeleton\"\n  [class.orc-skeleton--text]=\"effectiveVariant() === 'text'\"\n  [class.orc-skeleton--circular]=\"effectiveVariant() === 'circular'\"\n  [class.orc-skeleton--rectangular]=\"effectiveVariant() === 'rectangular'\"\n  [class.orc-skeleton--shimmer]=\"animation() === 'shimmer' || animation() === 'wave'\"\n  [class.orc-skeleton--pulse]=\"animation() === 'pulse'\"\n  [class.orc-skeleton--none]=\"animation() === 'none'\"\n  [style.width]=\"computedWidth()\"\n  [style.height]=\"computedHeight()\"\n  [style.border-radius]=\"computedBorderRadius()\"\n  [class]=\"'p-skeleton p-component orc-skeleton ' + styleClass()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'skeleton'\"\n  role=\"status\"\n  aria-busy=\"true\"\n  [attr.aria-label]=\"ariaLabel()\"\n>\n  <span class=\"sr-only\">{{ ariaLabel() }}</span>\n</div>\n", styles: [":host{display:block;box-sizing:border-box}.orc-skeleton{display:block;box-sizing:border-box;width:100%;height:100%;background-color:var(--skeleton-base, #F1F5F9);position:relative;overflow:hidden}.orc-skeleton--text{border-radius:8px}.orc-skeleton--circular{border-radius:50%}.orc-skeleton--rectangular{border-radius:8px}.orc-skeleton--shimmer{background-color:var(--skeleton-base, #F1F5F9);background-image:linear-gradient(90deg,var(--skeleton-base, #F1F5F9) 0%,var(--skeleton-highlight, #E2E8F0) 50%,var(--skeleton-base, #F1F5F9) 100%);background-size:200% 100%;background-repeat:no-repeat;animation:orcShimmer 1.5s cubic-bezier(.4,0,.2,1) infinite}.orc-skeleton--pulse{background-color:var(--skeleton-base, #F1F5F9);animation:orcPulse 1.5s ease-in-out infinite}.orc-skeleton--none{animation:none;background-color:var(--skeleton-base, #F1F5F9)}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes orcShimmer{0%{background-position:150% 0}to{background-position:-150% 0}}@keyframes orcPulse{0%,to{opacity:1}50%{opacity:.4}}@media(prefers-reduced-motion:reduce){.orc-skeleton--shimmer,.orc-skeleton--pulse{animation:none;background-color:var(--skeleton-base, #F1F5F9)}}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], animation: [{ type: i0.Input, args: [{ isSignal: true, alias: "animation", required: false }] }], shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], borderRadius: [{ type: i0.Input, args: [{ isSignal: true, alias: "borderRadius", required: false }] }], fitContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "fitContent", required: false }] }], display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], hostDisplay: [{
                type: HostBinding,
                args: ['style.display']
            }], hostWidth: [{
                type: HostBinding,
                args: ['style.width']
            }], hostVerticalAlign: [{
                type: HostBinding,
                args: ['style.vertical-align']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { SkeletonComponent };
//# sourceMappingURL=ciag-orchestra-skeleton.mjs.map
