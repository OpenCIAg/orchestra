export { ConfirmDialogComponent, ConfirmationService } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-confirm-dialog.mjs.map
