import * as i0 from '@angular/core';
import { input, booleanAttribute, numberAttribute, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { InputComponent } from '@ciag/orchestra/input';
import { BadgeComponent } from '@ciag/orchestra/badge';

class ChipInputComponent {
    // ── Inputs ──────────────────────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    // Chip specific config
    allowDuplicates = input(false, { ...(ngDevMode ? { debugName: "allowDuplicates" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    allowDuplicate = input(undefined, { ...(ngDevMode ? { debugName: "allowDuplicate" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maxChips = input(undefined, { ...(ngDevMode ? { debugName: "maxChips" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    max = input(undefined, { ...(ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    separator = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "separator" }] : /* istanbul ignore next */ []));
    addOnBlur = input(true, { ...(ngDevMode ? { debugName: "addOnBlur" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    separatorKeyCodes = input(['Enter', ',', ' '], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "separatorKeyCodes" }] : /* istanbul ignore next */ []));
    suggestions = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suggestions" }] : /* istanbul ignore next */ []));
    /** Optional localized announcements for assistive technology. */
    addAnnouncement = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "addAnnouncement" }] : /* istanbul ignore next */ []));
    removeAnnouncement = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeAnnouncement" }] : /* istanbul ignore next */ []));
    // ── Outputs ─────────────────────────────────────────────────
    chipsChange = output();
    maxReached = output();
    // ── Estado Interno ──────────────────────────────────────────
    value = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    inputValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputValue" }] : /* istanbul ignore next */ []));
    a11yMessage = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "a11yMessage" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    status = computed(() => this.errorMessage() ? 'error' : 'default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    effectiveSeparators = computed(() => this.separator() ? [...this.separator()] : this.separatorKeyCodes(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveSeparators" }] : /* istanbul ignore next */ []));
    filteredSuggestions = computed(() => {
        const term = this.inputValue().toLowerCase().trim();
        if (!term)
            return [];
        return this.suggestions()
            .filter(s => s.toLowerCase().includes(term))
            .filter(s => !this.value().includes(s)); // Evita sugerir chips já adicionados
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredSuggestions" }] : /* istanbul ignore next */ []));
    isSuggestionsVisible = computed(() => {
        return this.filteredSuggestions().length > 0 && !this.effectiveDisabled() && !this.readonly();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isSuggestionsVisible" }] : /* istanbul ignore next */ []));
    // ── ControlValueAccessor ───────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        if (Array.isArray(val)) {
            this.value.set([...val]);
        }
        else {
            this.value.set([]);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers ────────────────────────────────────────────────
    onInputChange(val) {
        this.inputValue.set(String(val));
    }
    onKeydown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const currentInput = this.inputValue().trim();
        // Adicionar Chip
        if (this.effectiveSeparators().includes(event.key)) {
            event.preventDefault();
            if (currentInput) {
                this.addChip(currentInput);
            }
        }
        // Remover último Chip no Backspace se input estiver vazio
        if (event.key === 'Backspace' && currentInput === '' && this.value().length > 0) {
            this.removeChip(this.value().length - 1);
        }
    }
    onPaste(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const clipboardData = event.clipboardData;
        const pastedText = clipboardData?.getData('text');
        if (pastedText) {
            event.preventDefault();
            const separator = this.separator();
            const items = (separator ? pastedText.split(separator) : pastedText.split(/[\n,]+/))
                .map(item => item.trim()).filter(item => item.length > 0);
            items.forEach(item => this.addChip(item, true));
            this.onTouched();
            this.updateFormAndEmit();
        }
    }
    onBlur() {
        this.onTouched();
        const currentInput = this.inputValue().trim();
        if (currentInput && this.addOnBlur()) {
            this.addChip(currentInput);
        }
    }
    // ── Lógica de Chips ─────────────────────────────────────────
    selectSuggestion(item) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.addChip(item);
    }
    addChip(item, skipEmit = false) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const max = this.max() ?? this.maxChips();
        const current = this.value();
        if (max !== undefined && current.length >= max) {
            this.maxReached.emit();
            return;
        }
        if (!(this.allowDuplicate() ?? this.allowDuplicates()) && current.includes(item)) {
            return; // Previne duplicatas
        }
        this.value.update(arr => [...arr, item]);
        this.inputValue.set('');
        this.a11yMessage.set(this.addAnnouncement()?.(item) ?? '');
        if (!skipEmit) {
            this.updateFormAndEmit();
        }
    }
    removeChip(index) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const current = this.value();
        const removedItem = current[index];
        this.value.update(arr => arr.filter((_, i) => i !== index));
        this.a11yMessage.set(this.removeAnnouncement()?.(removedItem) ?? '');
        this.onTouched();
        this.updateFormAndEmit();
    }
    updateFormAndEmit() {
        const currentVal = this.value();
        this.onChange(currentVal);
        this.chipsChange.emit(currentVal);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ChipInputComponent, isStandalone: true, selector: "orc-chip-input", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, allowDuplicates: { classPropertyName: "allowDuplicates", publicName: "allowDuplicates", isSignal: true, isRequired: false, transformFunction: null }, allowDuplicate: { classPropertyName: "allowDuplicate", publicName: "allowDuplicate", isSignal: true, isRequired: false, transformFunction: null }, maxChips: { classPropertyName: "maxChips", publicName: "maxChips", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null }, addOnBlur: { classPropertyName: "addOnBlur", publicName: "addOnBlur", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, separatorKeyCodes: { classPropertyName: "separatorKeyCodes", publicName: "separatorKeyCodes", isSignal: true, isRequired: false, transformFunction: null }, suggestions: { classPropertyName: "suggestions", publicName: "suggestions", isSignal: true, isRequired: false, transformFunction: null }, addAnnouncement: { classPropertyName: "addAnnouncement", publicName: "addAnnouncement", isSignal: true, isRequired: false, transformFunction: null }, removeAnnouncement: { classPropertyName: "removeAnnouncement", publicName: "removeAnnouncement", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { chipsChange: "chipsChange", maxReached: "maxReached" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ChipInputComponent),
                multi: true,
            },
        ], ngImport: i0, template: "<div class=\"p-chips p-component orc-chip-input\" [class]=\"'p-chips p-component orc-chip-input ' + styleClass()\" [style]=\"style()\" [attr.data-pc-name]=\"'chips'\">\n  <!-- Utilizamos o InputComponent estritamente como container -->\n  <orc-input\n    #orcInput\n    [id]=\"inputId() || id()\"\n    [label]=\"label()\"\n    [helperText]=\"helperText()\"\n    [errorMessage]=\"errorMessage()\"\n    [disabled]=\"effectiveDisabled()\"\n    [readonly]=\"readonly()\"\n    [size]=\"size()\"\n    [placeholder]=\"value().length > 0 ? '' : placeholder()\"\n    [status]=\"status()\"\n    [value]=\"inputValue()\"\n    [ariaLabel]=\"ariaLabel()\"\n    (inputChange)=\"onInputChange($event)\"\n    (keydown)=\"onKeydown($event)\"\n    (paste)=\"onPaste($event)\"\n    (blur)=\"onBlur()\"\n  >\n    <!-- Slot de Prefixo: Renderiza as Tags internamente -->\n    <div orcPrefix class=\"orc-chip-list\" (click)=\"orcInput.focusNative()\">\n      @for (chip of value(); track $index) {\n        <orc-badge\n          variant=\"soft\"\n          status=\"primary\"\n          [pill]=\"false\"\n          [size]=\"size() === 'lg' ? 'md' : 'sm'\"\n          [dismissible]=\"!effectiveDisabled() && !readonly()\"\n          (dismiss)=\"removeChip($index)\"\n          class=\"orc-chip-item\"\n        >\n          {{ chip }}\n        </orc-badge>\n      }\n    </div>\n  </orc-input>\n\n  <!-- Autocomplete Dropdown / Sugest\u00F5es -->\n  @if (isSuggestionsVisible()) {\n    <ul class=\"orc-chip-suggestions\" role=\"listbox\">\n      @for (suggestion of filteredSuggestions(); track suggestion) {\n        <li\n          class=\"orc-chip-suggestion-item\"\n          role=\"option\"\n          (mousedown)=\"$event.preventDefault()\" \n          (click)=\"selectSuggestion(suggestion)\"\n        >\n          {{ suggestion }}\n        </li>\n      }\n    </ul>\n  }\n\n  <!-- Regi\u00E3o para Leitores de Tela (Acessibilidade) -->\n  <div aria-live=\"polite\" class=\"sr-only\">\n    {{ a11yMessage() }}\n  </div>\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;width:100%}.orc-chip-input{width:100%;position:relative}.orc-chip-input ::ng-deep .orc-input-box{flex-wrap:wrap;height:auto!important;padding-top:4px;padding-bottom:4px;gap:4px 8px}.orc-chip-input ::ng-deep .orc-input__slot--prefix{flex-wrap:wrap;gap:6px;max-width:100%}.orc-chip-input ::ng-deep .orc-input__native{min-width:120px;flex:1 1 auto;padding:4px 0}.orc-chip-list{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.orc-chip-item{animation:fadeIn .2s ease}.orc-chip-suggestions{position:absolute;top:100%;left:0;width:100%;max-height:220px;overflow-y:auto;background:var(--orc-surface-raised, var(--fill-modal, #ffffff));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:8px;box-shadow:var(--orc-shadow-overlay, var(--shadow-md));margin-top:4px;padding:4px 0;list-style:none;z-index:1000}.orc-chip-suggestion-item{padding:8px 12px;font-size:14px;cursor:pointer;color:var(--orc-text, var(--orc-font-main, #141414));transition:background-color var(--transition-fast, .2s ease)}.orc-chip-suggestion-item:hover{background:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes fadeIn{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: InputComponent, selector: "orc-input, orc-input-text", inputs: ["id", "inputId", "name", "type", "size", "status", "placeholder", "label", "helperText", "errorMessage", "disabled", "readonly", "required", "clearable", "mask", "unmaskValue", "maxLength", "minLength", "min", "max", "step", "showCharCount", "prefixText", "suffixText", "autocomplete", "autofocus", "styleClass", "style", "variant", "fluid", "ariaLabel", "clearAriaLabel", "showPasswordAriaLabel", "hidePasswordAriaLabel", "ariaLabelledBy", "ariaDescribedby", "value"], outputs: ["valueChange", "inputChange", "blur", "focus", "clear"] }, { kind: "component", type: BadgeComponent, selector: "orc-badge", inputs: ["variant", "status", "severity", "size", "text", "value", "count", "maxCount", "dot", "showDefaultIcon", "dismissible", "pill", "id", "ariaLabel", "removeAriaLabel", "styleClass"], outputs: ["dismiss"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-chip-input', standalone: true, imports: [CommonModule, InputComponent, BadgeComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ChipInputComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"p-chips p-component orc-chip-input\" [class]=\"'p-chips p-component orc-chip-input ' + styleClass()\" [style]=\"style()\" [attr.data-pc-name]=\"'chips'\">\n  <!-- Utilizamos o InputComponent estritamente como container -->\n  <orc-input\n    #orcInput\n    [id]=\"inputId() || id()\"\n    [label]=\"label()\"\n    [helperText]=\"helperText()\"\n    [errorMessage]=\"errorMessage()\"\n    [disabled]=\"effectiveDisabled()\"\n    [readonly]=\"readonly()\"\n    [size]=\"size()\"\n    [placeholder]=\"value().length > 0 ? '' : placeholder()\"\n    [status]=\"status()\"\n    [value]=\"inputValue()\"\n    [ariaLabel]=\"ariaLabel()\"\n    (inputChange)=\"onInputChange($event)\"\n    (keydown)=\"onKeydown($event)\"\n    (paste)=\"onPaste($event)\"\n    (blur)=\"onBlur()\"\n  >\n    <!-- Slot de Prefixo: Renderiza as Tags internamente -->\n    <div orcPrefix class=\"orc-chip-list\" (click)=\"orcInput.focusNative()\">\n      @for (chip of value(); track $index) {\n        <orc-badge\n          variant=\"soft\"\n          status=\"primary\"\n          [pill]=\"false\"\n          [size]=\"size() === 'lg' ? 'md' : 'sm'\"\n          [dismissible]=\"!effectiveDisabled() && !readonly()\"\n          (dismiss)=\"removeChip($index)\"\n          class=\"orc-chip-item\"\n        >\n          {{ chip }}\n        </orc-badge>\n      }\n    </div>\n  </orc-input>\n\n  <!-- Autocomplete Dropdown / Sugest\u00F5es -->\n  @if (isSuggestionsVisible()) {\n    <ul class=\"orc-chip-suggestions\" role=\"listbox\">\n      @for (suggestion of filteredSuggestions(); track suggestion) {\n        <li\n          class=\"orc-chip-suggestion-item\"\n          role=\"option\"\n          (mousedown)=\"$event.preventDefault()\" \n          (click)=\"selectSuggestion(suggestion)\"\n        >\n          {{ suggestion }}\n        </li>\n      }\n    </ul>\n  }\n\n  <!-- Regi\u00E3o para Leitores de Tela (Acessibilidade) -->\n  <div aria-live=\"polite\" class=\"sr-only\">\n    {{ a11yMessage() }}\n  </div>\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;width:100%}.orc-chip-input{width:100%;position:relative}.orc-chip-input ::ng-deep .orc-input-box{flex-wrap:wrap;height:auto!important;padding-top:4px;padding-bottom:4px;gap:4px 8px}.orc-chip-input ::ng-deep .orc-input__slot--prefix{flex-wrap:wrap;gap:6px;max-width:100%}.orc-chip-input ::ng-deep .orc-input__native{min-width:120px;flex:1 1 auto;padding:4px 0}.orc-chip-list{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.orc-chip-item{animation:fadeIn .2s ease}.orc-chip-suggestions{position:absolute;top:100%;left:0;width:100%;max-height:220px;overflow-y:auto;background:var(--orc-surface-raised, var(--fill-modal, #ffffff));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:8px;box-shadow:var(--orc-shadow-overlay, var(--shadow-md));margin-top:4px;padding:4px 0;list-style:none;z-index:1000}.orc-chip-suggestion-item{padding:8px 12px;font-size:14px;cursor:pointer;color:var(--orc-text, var(--orc-font-main, #141414));transition:background-color var(--transition-fast, .2s ease)}.orc-chip-suggestion-item:hover{background:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}@keyframes fadeIn{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], allowDuplicates: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowDuplicates", required: false }] }], allowDuplicate: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowDuplicate", required: false }] }], maxChips: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxChips", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }], addOnBlur: [{ type: i0.Input, args: [{ isSignal: true, alias: "addOnBlur", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], separatorKeyCodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "separatorKeyCodes", required: false }] }], suggestions: [{ type: i0.Input, args: [{ isSignal: true, alias: "suggestions", required: false }] }], addAnnouncement: [{ type: i0.Input, args: [{ isSignal: true, alias: "addAnnouncement", required: false }] }], removeAnnouncement: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeAnnouncement", required: false }] }], chipsChange: [{ type: i0.Output, args: ["chipsChange"] }], maxReached: [{ type: i0.Output, args: ["maxReached"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ChipInputComponent };
//# sourceMappingURL=ciag-orchestra-chip-input.mjs.map
