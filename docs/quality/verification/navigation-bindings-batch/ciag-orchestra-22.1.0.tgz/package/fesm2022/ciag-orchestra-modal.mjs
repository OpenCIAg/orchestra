import * as i0 from '@angular/core';
import { inject, signal, model, input, booleanAttribute, computed, output, PLATFORM_ID, afterEveryRender, effect, ViewChild, ChangeDetectionStrategy, Component, InjectionToken, Injector, createComponent, Injectable } from '@angular/core';
import { DOCUMENT, isPlatformBrowser, CommonModule } from '@angular/common';
import { ButtonComponent } from '@ciag/orchestra/button';
import { registerOverlay, isTopOverlay, lockDocumentScroll, focusInitialElement, trapTabKey } from '@ciag/orchestra/internal';
import { ReplaySubject } from 'rxjs';

let nextModalId = 0;
class ModalComponent {
    document = inject(DOCUMENT);
    titleId = `orc-modal-title-${++nextModalId}`;
    hasTitle = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasTitle" }] : /* istanbul ignore next */ []));
    headerContent;
    lastIsOpen = false;
    lastVisible = false;
    releaseLayer;
    releaseKeyboardListener;
    releaseScroll;
    // ── Referência ao elemento nativo <dialog> ─────────────────
    dialogRef;
    // ── Inputs e Models ─────────────────────────────────────────
    isOpen = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    /** PrimeNG Dialog-compatible visibility model; isOpen remains supported for Orchestra callers. */
    visible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    header = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    modal = input(true, { ...(ngDevMode ? { debugName: "modal" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismissableMask = input(true, { ...(ngDevMode ? { debugName: "dismissableMask" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closable = input(true, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    draggable = input(false, { ...(ngDevMode ? { debugName: "draggable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    resizable = input(false, { ...(ngDevMode ? { debugName: "resizable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maximizable = input(false, { ...(ngDevMode ? { debugName: "maximizable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    focusOnShow = input(true, { ...(ngDevMode ? { debugName: "focusOnShow" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    focusTrap = input(true, { ...(ngDevMode ? { debugName: "focusTrap" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    blockScroll = input(true, { ...(ngDevMode ? { debugName: "blockScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(1000, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "baseZIndex" }] : /* istanbul ignore next */ []));
    position = input('center', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    maskStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maskStyle" }] : /* istanbul ignore next */ []));
    maskStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maskStyleClass" }] : /* istanbul ignore next */ []));
    contentStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentStyle" }] : /* istanbul ignore next */ []));
    contentStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentStyleClass" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    role = input('dialog', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "role" }] : /* istanbul ignore next */ []));
    showHeader = input(true, { ...(ngDevMode ? { debugName: "showHeader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeIcon = input('×', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeIcon" }] : /* istanbul ignore next */ []));
    closeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeAriaLabel" }] : /* istanbul ignore next */ []));
    minimizeIcon = input('−', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minimizeIcon" }] : /* istanbul ignore next */ []));
    maximizeIcon = input('+', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maximizeIcon" }] : /* istanbul ignore next */ []));
    restoreAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "restoreAriaLabel" }] : /* istanbul ignore next */ []));
    maximizeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maximizeAriaLabel" }] : /* istanbul ignore next */ []));
    closeTabindex = input('0', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeTabindex" }] : /* istanbul ignore next */ []));
    breakpoints = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoints" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    status = input('neutral', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnBackdropClick = input(true, { ...(ngDevMode ? { debugName: "closeOnBackdropClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCloseButton = input(true, { ...(ngDevMode ? { debugName: "showCloseButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabelledBy = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaDescribedBy = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedBy" }] : /* istanbul ignore next */ []));
    zIndex = input(1000, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "zIndex" }] : /* istanbul ignore next */ []));
    effectiveZIndex = computed(() => this.autoZIndex()
        ? Math.max(this.zIndex(), this.baseZIndex())
        : this.zIndex(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveZIndex" }] : /* istanbul ignore next */ []));
    keepInViewport = input(true, { ...(ngDevMode ? { debugName: "keepInViewport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    minX = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minX" }] : /* istanbul ignore next */ []));
    minY = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minY" }] : /* istanbul ignore next */ []));
    transitionOptions = input('150ms cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    rtl = input(false, { ...(ngDevMode ? { debugName: "rtl" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // ── Outputs ─────────────────────────────────────────────────
    closed = output();
    onShow = output();
    onHide = output();
    onMaximize = output();
    maximized = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maximized" }] : /* istanbul ignore next */ []));
    platformId = inject(PLATFORM_ID);
    isBrowser = isPlatformBrowser(this.platformId);
    previousActiveElement = null;
    constructor() {
        afterEveryRender(() => this.hasTitle.set(Boolean(this.headerContent?.nativeElement.textContent?.trim())));
        effect(() => {
            this.syncDialogState();
        });
    }
    ngAfterViewInit() {
        // A signal may already be true before ViewChild is assigned. The
        // constructor effect cannot observe that non-signal assignment, so sync
        // once after the native dialog enters the view.
        this.syncDialogState();
    }
    syncDialogState() {
        if (!this.isBrowser)
            return;
        const isOpen = this.isOpen();
        const visible = this.visible();
        const open = isOpen !== this.lastIsOpen
            ? isOpen
            : visible !== this.lastVisible
                ? visible
                : isOpen;
        this.lastIsOpen = open;
        this.lastVisible = open;
        this.isOpen.set(open);
        this.visible.set(open);
        if (this.inline()) {
            this.releaseScrollLock();
            this.releaseLayer?.();
            this.releaseLayer = undefined;
            this.releaseKeyboardListener?.();
            this.releaseKeyboardListener = undefined;
            return;
        }
        const dialog = this.dialogRef?.nativeElement;
        if (!dialog)
            return;
        if (open && !dialog.open) {
            this.previousActiveElement = this.document.activeElement;
            if (this.modal())
                dialog.showModal();
            else
                dialog.show();
            this.releaseLayer = registerOverlay(dialog, {
                onParentClose: () => this.close(),
            });
            const keydown = (event) => this.trapFocus(event);
            this.document.addEventListener('keydown', keydown);
            this.releaseKeyboardListener = () => this.document.removeEventListener('keydown', keydown);
            this.acquireScrollLock();
            this.onShow.emit();
            if (this.focusOnShow())
                queueMicrotask(() => this.focusInitialElement());
        }
        else if (!open && dialog.open) {
            dialog.close();
            this.finishClose();
            this.onHide.emit();
        }
    }
    // ── Computed Classes ────────────────────────────────────────
    modalClasses = computed(() => {
        return {
            'orc-modal': true,
            'orc-modal--inline': this.inline(),
            [`orc-modal--size-${this.size()}`]: true,
            'orc-modal--status-danger': this.status() === 'danger',
            'orc-modal--fullscreen': this.size() === 'fullScreen',
            'orc-modal--maximized': this.maximized(),
            [`orc-modal--position-${this.position()}`]: true,
        };
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "modalClasses" }] : /* istanbul ignore next */ []));
    /**
     * Angular string interpolation coerces a class map to "[object Object]".
     * Convert the map explicitly so every modal selector receives its base,
     * size, status, inline, and maximized classes.
     */
    modalClassNames = computed(() => {
        const classes = this.modalClasses();
        return Object.keys(classes)
            .filter((className) => classes[className])
            .join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "modalClassNames" }] : /* istanbul ignore next */ []));
    // ── Handlers ────────────────────────────────────────────────
    onClose() {
        if (this.isOpen() || this.visible()) {
            this.isOpen.set(false);
            this.visible.set(false);
            this.closed.emit();
        }
    }
    onCancel(event) {
        // Disparado nativamente ao apertar 'Escape'
        event.preventDefault();
        if (this.closeOnEscape() && isTopOverlay(this.dialogRef.nativeElement))
            this.onClose();
    }
    onBackdropClick(event) {
        if (!this.closeOnBackdropClick() ||
            !this.dismissableMask() ||
            !this.modal())
            return;
        const dialog = this.dialogRef.nativeElement;
        // O <dialog> cobre a tela inteira com seu backdrop.
        // O click nele tem rect bounds específicos. Se clicar fora do conteúdo interno, é o backdrop.
        // Como o conteúdo real está no <div class="orc-modal__container">,
        // clicar no dialog propriamente (se o padding não cobrir a tela) é backdrop.
        // Mas a forma mais segura é checar o target.
        if (event.target === dialog) {
            this.onClose();
        }
    }
    show() {
        this.visible.set(true);
        this.isOpen.set(true);
    }
    close() {
        this.onClose();
    }
    toggleMaximize() {
        if (!this.maximizable())
            return;
        this.maximized.update((value) => !value);
        this.onMaximize.emit({ maximized: this.maximized() });
    }
    acquireScrollLock() {
        if (this.isBrowser &&
            this.modal() &&
            this.blockScroll() &&
            !this.releaseScroll)
            this.releaseScroll = lockDocumentScroll(this.document);
    }
    releaseScrollLock() {
        this.releaseScroll?.();
        this.releaseScroll = undefined;
    }
    finishClose() {
        this.releaseKeyboardListener?.();
        this.releaseKeyboardListener = undefined;
        this.releaseScrollLock();
        this.releaseLayer?.();
        this.releaseLayer = undefined;
        if (this.previousActiveElement?.isConnected)
            this.previousActiveElement.focus({ preventScroll: true });
        this.previousActiveElement = null;
    }
    onNativeClose() {
        if (this.dialogRef?.nativeElement.open || this.inline())
            return;
        if (this.isOpen() || this.visible()) {
            this.onClose();
            this.finishClose();
            this.onHide.emit();
        }
    }
    focusInitialElement() {
        const dialog = this.dialogRef?.nativeElement;
        if (dialog && (this.isOpen() || this.visible()))
            focusInitialElement(dialog);
    }
    trapFocus(event) {
        if (!this.focusTrap() ||
            !this.modal() ||
            !(this.isOpen() || this.visible()))
            return;
        const dialog = this.dialogRef?.nativeElement;
        if (dialog)
            trapTabKey(event, dialog);
    }
    ngOnDestroy() {
        this.finishClose();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ModalComponent, isStandalone: true, selector: "orc-modal, orc-dialog, orc-dynamic-dialog", inputs: { isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, modal: { classPropertyName: "modal", publicName: "modal", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, dismissableMask: { classPropertyName: "dismissableMask", publicName: "dismissableMask", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, draggable: { classPropertyName: "draggable", publicName: "draggable", isSignal: true, isRequired: false, transformFunction: null }, resizable: { classPropertyName: "resizable", publicName: "resizable", isSignal: true, isRequired: false, transformFunction: null }, maximizable: { classPropertyName: "maximizable", publicName: "maximizable", isSignal: true, isRequired: false, transformFunction: null }, focusOnShow: { classPropertyName: "focusOnShow", publicName: "focusOnShow", isSignal: true, isRequired: false, transformFunction: null }, focusTrap: { classPropertyName: "focusTrap", publicName: "focusTrap", isSignal: true, isRequired: false, transformFunction: null }, blockScroll: { classPropertyName: "blockScroll", publicName: "blockScroll", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, maskStyle: { classPropertyName: "maskStyle", publicName: "maskStyle", isSignal: true, isRequired: false, transformFunction: null }, maskStyleClass: { classPropertyName: "maskStyleClass", publicName: "maskStyleClass", isSignal: true, isRequired: false, transformFunction: null }, contentStyle: { classPropertyName: "contentStyle", publicName: "contentStyle", isSignal: true, isRequired: false, transformFunction: null }, contentStyleClass: { classPropertyName: "contentStyleClass", publicName: "contentStyleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, role: { classPropertyName: "role", publicName: "role", isSignal: true, isRequired: false, transformFunction: null }, showHeader: { classPropertyName: "showHeader", publicName: "showHeader", isSignal: true, isRequired: false, transformFunction: null }, closeIcon: { classPropertyName: "closeIcon", publicName: "closeIcon", isSignal: true, isRequired: false, transformFunction: null }, closeAriaLabel: { classPropertyName: "closeAriaLabel", publicName: "closeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, minimizeIcon: { classPropertyName: "minimizeIcon", publicName: "minimizeIcon", isSignal: true, isRequired: false, transformFunction: null }, maximizeIcon: { classPropertyName: "maximizeIcon", publicName: "maximizeIcon", isSignal: true, isRequired: false, transformFunction: null }, restoreAriaLabel: { classPropertyName: "restoreAriaLabel", publicName: "restoreAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, maximizeAriaLabel: { classPropertyName: "maximizeAriaLabel", publicName: "maximizeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, closeTabindex: { classPropertyName: "closeTabindex", publicName: "closeTabindex", isSignal: true, isRequired: false, transformFunction: null }, breakpoints: { classPropertyName: "breakpoints", publicName: "breakpoints", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdropClick: { classPropertyName: "closeOnBackdropClick", publicName: "closeOnBackdropClick", isSignal: true, isRequired: false, transformFunction: null }, showCloseButton: { classPropertyName: "showCloseButton", publicName: "showCloseButton", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedBy: { classPropertyName: "ariaDescribedBy", publicName: "ariaDescribedBy", isSignal: true, isRequired: false, transformFunction: null }, zIndex: { classPropertyName: "zIndex", publicName: "zIndex", isSignal: true, isRequired: false, transformFunction: null }, keepInViewport: { classPropertyName: "keepInViewport", publicName: "keepInViewport", isSignal: true, isRequired: false, transformFunction: null }, minX: { classPropertyName: "minX", publicName: "minX", isSignal: true, isRequired: false, transformFunction: null }, minY: { classPropertyName: "minY", publicName: "minY", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, rtl: { classPropertyName: "rtl", publicName: "rtl", isSignal: true, isRequired: false, transformFunction: null }, maximized: { classPropertyName: "maximized", publicName: "maximized", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", visible: "visibleChange", closed: "closed", onShow: "onShow", onHide: "onHide", onMaximize: "onMaximize", maximized: "maximizedChange" }, viewQueries: [{ propertyName: "headerContent", first: true, predicate: ["headerContent"], descendants: true }, { propertyName: "dialogRef", first: true, predicate: ["dialogRef"], descendants: true }], ngImport: i0, template: "<dialog\n  #dialogRef\n  [attr.id]=\"id() || null\"\n  [class]=\"'p-dialog p-component ' + modalClassNames() + ' ' + styleClass()\"\n  [style]=\"style()\"\n  [style.z-index]=\"inline() ? 'auto' : effectiveZIndex()\"\n  (cancel)=\"onCancel($event)\"\n  (close)=\"onNativeClose()\"\n  tabindex=\"-1\"\n  (click)=\"onBackdropClick($event)\"\n  [attr.role]=\"role()\"\n  [attr.aria-modal]=\"inline() || !modal() ? null : 'true'\"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() || (!ariaLabel() && hasTitle() ? titleId : null)\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() || (!hasTitle() && !ariaLabelledBy() ? 'Dialog' : null)\n  \"\n  [attr.aria-describedby]=\"ariaDescribedBy() || null\"\n  [attr.open]=\"inline() ? '' : null\"\n>\n  <div class=\"orc-modal__container\">\n    <!-- HEADER -->\n    <header\n      class=\"orc-modal__header\"\n      [class.orc-modal__header--hidden]=\"!showHeader()\"\n    >\n      <div #headerContent [id]=\"titleId\" class=\"orc-modal__header-content\">\n        @if (header()) {\n          <span>{{ header() }}</span>\n        }\n        <ng-content select=\"[modal-header]\"></ng-content>\n      </div>\n\n      @if (showCloseButton() && closable()) {\n        <orc-button\n          variant=\"ghost\"\n          size=\"sm\"\n          [iconOnly]=\"true\"\n          (click)=\"onClose()\"\n          [ariaLabel]=\"closeAriaLabel() || 'Close dialog'\"\n          class=\"orc-modal__close-btn\"\n        >\n          <svg\n            iconLeft\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          >\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      }\n      @if (maximizable()) {\n        <button\n          type=\"button\"\n          class=\"orc-modal__maximize\"\n          (click)=\"toggleMaximize()\"\n          [attr.aria-label]=\"\n            maximized()\n              ? restoreAriaLabel() || 'Restore dialog'\n              : maximizeAriaLabel() || 'Maximize dialog'\n          \"\n        >\n          {{ maximized() ? minimizeIcon() : maximizeIcon() }}\n        </button>\n      }\n    </header>\n\n    <!-- BODY -->\n    <div\n      class=\"orc-modal__body\"\n      [class]=\"contentStyleClass()\"\n      [style]=\"contentStyle()\"\n    >\n      <ng-content select=\"[modal-body]\"></ng-content>\n      <ng-content></ng-content>\n    </div>\n\n    <!-- FOOTER -->\n    <footer class=\"orc-modal__footer\">\n      <ng-content select=\"[modal-footer]\"></ng-content>\n    </footer>\n  </div>\n</dialog>\n", styles: [".orc-modal{padding:0;border:none;background:transparent;color:var(--text-primary);margin:auto;overflow:visible}.orc-modal::backdrop{background-color:var(--orc-scrim, rgba(0, 0, 0, .5));-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);animation:fadeIn .2s ease}.orc-modal[open]:not(.orc-modal--inline){animation:scaleUp .25s cubic-bezier(.16,1,.3,1)}.orc-modal--inline{position:relative;width:auto;height:auto;margin:0;display:flex}.orc-modal--inline::backdrop{display:none}.orc-modal--inline .orc-modal__container{margin:0;box-shadow:none}.orc-modal--status-danger .orc-modal__container{border-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-modal--size-sm .orc-modal__container{max-width:400px;width:100%}.orc-modal--size-custom .orc-modal__container{width:100%}.orc-modal--size-md .orc-modal__container{max-width:560px;width:100%}.orc-modal--size-lg .orc-modal__container{max-width:800px;width:100%}.orc-modal--size-xl .orc-modal__container{max-width:1140px;width:100%}.orc-modal--fullscreen .orc-modal__container{max-width:100vw;width:100vw;height:100vh;border-radius:0;max-height:100vh}.orc-modal--maximized .orc-modal__container{max-width:100vw;width:100vw;height:100vh;max-height:100vh;border-radius:0}.orc-modal__container{display:flex;flex-direction:column;background-color:var(--orc-fill-modal);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);max-height:calc(100vh - var(--space-16));width:calc(100vw - var(--space-6));margin:0 auto;padding:var(--space-5);gap:var(--space-4, 1rem)}.orc-modal__header{display:flex;align-items:center;justify-content:space-between;flex-shrink:0}.orc-modal__header-content{flex:1;font-size:1.125rem;font-weight:600;color:var(--text-primary);margin-right:var(--space-4)}.orc-modal__header-content ::ng-deep h1,.orc-modal__header-content ::ng-deep h2,.orc-modal__header-content ::ng-deep h3,.orc-modal__header-content ::ng-deep h4,.orc-modal__header-content ::ng-deep h5,.orc-modal__header-content ::ng-deep h6{margin:0;font-size:inherit;font-weight:inherit;line-height:inherit}.orc-modal__close-btn{margin:-.25rem -.25rem -.25rem 0}.orc-modal__close-btn svg{width:18px;height:18px}.orc-modal__body{overflow-y:auto;flex:1 1 auto}.orc-modal__footer{display:flex;align-items:center;justify-content:flex-end;gap:var(--space-4, 1rem);flex-shrink:0}.orc-modal__footer ::ng-deep [modal-footer]{display:flex;align-items:center;justify-content:flex-end;gap:var(--space-4, 1rem);width:100%}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes scaleUp{0%{opacity:0;transform:scale(.96) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}:host{display:contents}.orc-modal{box-sizing:border-box;width:min(100vw - 2rem,var(--orc-dialog-width, 560px));max-width:calc(100vw - 2rem);max-height:calc(100dvh - 2rem)}.orc-modal--size-sm{--orc-dialog-width: 400px}.orc-modal--size-lg{--orc-dialog-width: 800px}.orc-modal--size-xl{--orc-dialog-width: 1140px}.orc-modal__container{box-sizing:border-box;max-height:calc(100dvh - 2rem);gap:var(--space-4, 1rem)}.orc-modal__body{min-height:0}.orc-modal__header--hidden,.orc-modal__footer:empty{display:none}.orc-modal--position-top{margin-block:1rem auto}.orc-modal--position-bottom{margin-block:auto 1rem}.orc-modal--position-left{margin-inline:1rem auto}.orc-modal--position-right{margin-inline:auto 1rem}.orc-modal--position-topleft{margin:1rem auto auto 1rem}.orc-modal--position-topright{margin:1rem 1rem auto auto}.orc-modal--position-bottomleft{margin:auto auto 1rem 1rem}.orc-modal--position-bottomright{margin:auto 1rem 1rem auto}.orc-modal--fullscreen,.orc-modal--maximized{width:100vw;max-width:100vw;height:100dvh;max-height:100dvh;margin:0}@media(prefers-reduced-motion:reduce){.orc-modal[open],.orc-modal::backdrop{animation:none}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ButtonComponent, selector: "orc-button", inputs: ["variant", "severity", "size", "disabled", "loading", "fullWidth", "text", "outlined", "raised", "rounded", "plain", "fluid", "link", "icon", "iconPos", "loadingIcon", "id", "tabindex", "ariaLabelledBy", "ariaExpanded", "ariaControls", "form", "styleClass", "style", "badge", "badgeClass", "iconLeft", "iconRight", "iconOnly", "type", "ariaLabel"], outputs: ["clicked", "onFocus", "onBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-modal, orc-dialog, orc-dynamic-dialog', standalone: true, imports: [CommonModule, ButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<dialog\n  #dialogRef\n  [attr.id]=\"id() || null\"\n  [class]=\"'p-dialog p-component ' + modalClassNames() + ' ' + styleClass()\"\n  [style]=\"style()\"\n  [style.z-index]=\"inline() ? 'auto' : effectiveZIndex()\"\n  (cancel)=\"onCancel($event)\"\n  (close)=\"onNativeClose()\"\n  tabindex=\"-1\"\n  (click)=\"onBackdropClick($event)\"\n  [attr.role]=\"role()\"\n  [attr.aria-modal]=\"inline() || !modal() ? null : 'true'\"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() || (!ariaLabel() && hasTitle() ? titleId : null)\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() || (!hasTitle() && !ariaLabelledBy() ? 'Dialog' : null)\n  \"\n  [attr.aria-describedby]=\"ariaDescribedBy() || null\"\n  [attr.open]=\"inline() ? '' : null\"\n>\n  <div class=\"orc-modal__container\">\n    <!-- HEADER -->\n    <header\n      class=\"orc-modal__header\"\n      [class.orc-modal__header--hidden]=\"!showHeader()\"\n    >\n      <div #headerContent [id]=\"titleId\" class=\"orc-modal__header-content\">\n        @if (header()) {\n          <span>{{ header() }}</span>\n        }\n        <ng-content select=\"[modal-header]\"></ng-content>\n      </div>\n\n      @if (showCloseButton() && closable()) {\n        <orc-button\n          variant=\"ghost\"\n          size=\"sm\"\n          [iconOnly]=\"true\"\n          (click)=\"onClose()\"\n          [ariaLabel]=\"closeAriaLabel() || 'Close dialog'\"\n          class=\"orc-modal__close-btn\"\n        >\n          <svg\n            iconLeft\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          >\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      }\n      @if (maximizable()) {\n        <button\n          type=\"button\"\n          class=\"orc-modal__maximize\"\n          (click)=\"toggleMaximize()\"\n          [attr.aria-label]=\"\n            maximized()\n              ? restoreAriaLabel() || 'Restore dialog'\n              : maximizeAriaLabel() || 'Maximize dialog'\n          \"\n        >\n          {{ maximized() ? minimizeIcon() : maximizeIcon() }}\n        </button>\n      }\n    </header>\n\n    <!-- BODY -->\n    <div\n      class=\"orc-modal__body\"\n      [class]=\"contentStyleClass()\"\n      [style]=\"contentStyle()\"\n    >\n      <ng-content select=\"[modal-body]\"></ng-content>\n      <ng-content></ng-content>\n    </div>\n\n    <!-- FOOTER -->\n    <footer class=\"orc-modal__footer\">\n      <ng-content select=\"[modal-footer]\"></ng-content>\n    </footer>\n  </div>\n</dialog>\n", styles: [".orc-modal{padding:0;border:none;background:transparent;color:var(--text-primary);margin:auto;overflow:visible}.orc-modal::backdrop{background-color:var(--orc-scrim, rgba(0, 0, 0, .5));-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px);animation:fadeIn .2s ease}.orc-modal[open]:not(.orc-modal--inline){animation:scaleUp .25s cubic-bezier(.16,1,.3,1)}.orc-modal--inline{position:relative;width:auto;height:auto;margin:0;display:flex}.orc-modal--inline::backdrop{display:none}.orc-modal--inline .orc-modal__container{margin:0;box-shadow:none}.orc-modal--status-danger .orc-modal__container{border-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-modal--size-sm .orc-modal__container{max-width:400px;width:100%}.orc-modal--size-custom .orc-modal__container{width:100%}.orc-modal--size-md .orc-modal__container{max-width:560px;width:100%}.orc-modal--size-lg .orc-modal__container{max-width:800px;width:100%}.orc-modal--size-xl .orc-modal__container{max-width:1140px;width:100%}.orc-modal--fullscreen .orc-modal__container{max-width:100vw;width:100vw;height:100vh;border-radius:0;max-height:100vh}.orc-modal--maximized .orc-modal__container{max-width:100vw;width:100vw;height:100vh;max-height:100vh;border-radius:0}.orc-modal__container{display:flex;flex-direction:column;background-color:var(--orc-fill-modal);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);max-height:calc(100vh - var(--space-16));width:calc(100vw - var(--space-6));margin:0 auto;padding:var(--space-5);gap:var(--space-4, 1rem)}.orc-modal__header{display:flex;align-items:center;justify-content:space-between;flex-shrink:0}.orc-modal__header-content{flex:1;font-size:1.125rem;font-weight:600;color:var(--text-primary);margin-right:var(--space-4)}.orc-modal__header-content ::ng-deep h1,.orc-modal__header-content ::ng-deep h2,.orc-modal__header-content ::ng-deep h3,.orc-modal__header-content ::ng-deep h4,.orc-modal__header-content ::ng-deep h5,.orc-modal__header-content ::ng-deep h6{margin:0;font-size:inherit;font-weight:inherit;line-height:inherit}.orc-modal__close-btn{margin:-.25rem -.25rem -.25rem 0}.orc-modal__close-btn svg{width:18px;height:18px}.orc-modal__body{overflow-y:auto;flex:1 1 auto}.orc-modal__footer{display:flex;align-items:center;justify-content:flex-end;gap:var(--space-4, 1rem);flex-shrink:0}.orc-modal__footer ::ng-deep [modal-footer]{display:flex;align-items:center;justify-content:flex-end;gap:var(--space-4, 1rem);width:100%}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes scaleUp{0%{opacity:0;transform:scale(.96) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}:host{display:contents}.orc-modal{box-sizing:border-box;width:min(100vw - 2rem,var(--orc-dialog-width, 560px));max-width:calc(100vw - 2rem);max-height:calc(100dvh - 2rem)}.orc-modal--size-sm{--orc-dialog-width: 400px}.orc-modal--size-lg{--orc-dialog-width: 800px}.orc-modal--size-xl{--orc-dialog-width: 1140px}.orc-modal__container{box-sizing:border-box;max-height:calc(100dvh - 2rem);gap:var(--space-4, 1rem)}.orc-modal__body{min-height:0}.orc-modal__header--hidden,.orc-modal__footer:empty{display:none}.orc-modal--position-top{margin-block:1rem auto}.orc-modal--position-bottom{margin-block:auto 1rem}.orc-modal--position-left{margin-inline:1rem auto}.orc-modal--position-right{margin-inline:auto 1rem}.orc-modal--position-topleft{margin:1rem auto auto 1rem}.orc-modal--position-topright{margin:1rem 1rem auto auto}.orc-modal--position-bottomleft{margin:auto auto 1rem 1rem}.orc-modal--position-bottomright{margin:auto 1rem 1rem auto}.orc-modal--fullscreen,.orc-modal--maximized{width:100vw;max-width:100vw;height:100dvh;max-height:100dvh;margin:0}@media(prefers-reduced-motion:reduce){.orc-modal[open],.orc-modal::backdrop{animation:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { headerContent: [{
                type: ViewChild,
                args: ['headerContent']
            }], dialogRef: [{
                type: ViewChild,
                args: ['dialogRef']
            }], isOpen: [{ type: i0.Input, args: [{ isSignal: true, alias: "isOpen", required: false }] }, { type: i0.Output, args: ["isOpenChange"] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], modal: [{ type: i0.Input, args: [{ isSignal: true, alias: "modal", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], dismissableMask: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissableMask", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], draggable: [{ type: i0.Input, args: [{ isSignal: true, alias: "draggable", required: false }] }], resizable: [{ type: i0.Input, args: [{ isSignal: true, alias: "resizable", required: false }] }], maximizable: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximizable", required: false }] }], focusOnShow: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnShow", required: false }] }], focusTrap: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusTrap", required: false }] }], blockScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "blockScroll", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], maskStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "maskStyle", required: false }] }], maskStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "maskStyleClass", required: false }] }], contentStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentStyle", required: false }] }], contentStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentStyleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], role: [{ type: i0.Input, args: [{ isSignal: true, alias: "role", required: false }] }], showHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showHeader", required: false }] }], closeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeIcon", required: false }] }], closeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeAriaLabel", required: false }] }], minimizeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "minimizeIcon", required: false }] }], maximizeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximizeIcon", required: false }] }], restoreAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "restoreAriaLabel", required: false }] }], maximizeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximizeAriaLabel", required: false }] }], closeTabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeTabindex", required: false }] }], breakpoints: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoints", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }], closeOnBackdropClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdropClick", required: false }] }], showCloseButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCloseButton", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaDescribedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedBy", required: false }] }], zIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "zIndex", required: false }] }], keepInViewport: [{ type: i0.Input, args: [{ isSignal: true, alias: "keepInViewport", required: false }] }], minX: [{ type: i0.Input, args: [{ isSignal: true, alias: "minX", required: false }] }], minY: [{ type: i0.Input, args: [{ isSignal: true, alias: "minY", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], rtl: [{ type: i0.Input, args: [{ isSignal: true, alias: "rtl", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onMaximize: [{ type: i0.Output, args: ["onMaximize"] }], maximized: [{ type: i0.Input, args: [{ isSignal: true, alias: "maximized", required: false }] }, { type: i0.Output, args: ["maximizedChange"] }] } });

class ModalRef {
    componentRef;
    destroyCallback;
    closed = new ReplaySubject(1);
    hasClosed = false;
    result;
    afterClosed$ = this.closed.asObservable();
    constructor(componentRef, destroyCallback) {
        this.componentRef = componentRef;
        this.destroyCallback = destroyCallback;
    }
    get instance() {
        return this.componentRef.instance;
    }
    close(result) {
        if (this.hasClosed)
            return;
        this.hasClosed = true;
        this.result = result;
        this.closed.next(result);
        this.closed.complete();
        this.destroyCallback();
    }
    /** Backwards-compatible synchronous access to the close result. */
    afterClosed() {
        return this.result;
    }
    /** Promise-friendly alternative to `afterClosed$`. */
    afterClosedPromise() {
        return new Promise((resolve) => this.afterClosed$.subscribe(resolve));
    }
}

const ORC_MODAL_DATA = new InjectionToken('ORC_MODAL_DATA');
class ModalService {
    appRef;
    injector;
    constructor(appRef, injector) {
        this.appRef = appRef;
        this.injector = injector;
    }
    /**
     * Abre um componente dinamicamente.
     * O componente injetado DEVE conter a tag <orc-modal> com [isOpen]="true" internamente,
     * para que o modal nativo assuma a camada de visualização (Top Layer do HTML5).
     */
    open(component, config = {}) {
        const componentInjector = Injector.create({
            parent: this.injector,
            providers: [{ provide: ORC_MODAL_DATA, useValue: config.data }],
        });
        // 1. Instanciar o componente dinamicamente
        const componentRef = createComponent(component, {
            environmentInjector: this.injector,
            elementInjector: componentInjector,
        });
        // 2. Setar inputs se fornecidos
        if (config.inputs) {
            const componentInputs = config.inputs;
            Object.entries(componentInputs).forEach(([key, value]) => {
                componentRef.setInput(key, value);
            });
        }
        // 3. Atachar à árvore de views do Angular para detecção de mudanças
        this.appRef.attachView(componentRef.hostView);
        // 4. Inserir no DOM
        const domElem = componentRef.hostView.rootNodes[0];
        document.body.appendChild(domElem);
        // 5. Configurar lógica de destruição
        const destroyFn = () => {
            this.appRef.detachView(componentRef.hostView);
            componentRef.destroy();
        };
        return new ModalRef(componentRef, destroyFn);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ModalService, deps: [{ token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ModalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ModalService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ModalComponent, ModalRef, ModalService, ORC_MODAL_DATA };
//# sourceMappingURL=ciag-orchestra-modal.mjs.map
