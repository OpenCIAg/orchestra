import * as i0 from '@angular/core';
import { input, booleanAttribute, model, effect, output, signal, ChangeDetectionStrategy, Component, inject, viewChild, computed } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class AccordionComponent {
    // Inputs (Signals API)
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    value = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    expandIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandIcon" }] : /* istanbul ignore next */ []));
    collapseIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapseIcon" }] : /* istanbul ignore next */ []));
    selectOnFocus = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectOnFocus" }] : /* istanbul ignore next */ []));
    transitionOptions = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    headerAriaLevel = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerAriaLevel" }] : /* istanbul ignore next */ []));
    activeIndex = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    previousValue = 0;
    previousActiveIndex = 0;
    selectionSource = 'value';
    constructor() {
        effect(() => {
            const items = this.items();
            const value = this.value();
            const active = this.activeIndex();
            // Both public models remain controllable after user interaction. A changed
            // value wins if a consumer updates both aliases in the same render.
            if (value !== this.previousValue)
                this.selectionSource = 'value';
            else if (active !== this.previousActiveIndex)
                this.selectionSource = 'index';
            this.previousValue = value;
            this.previousActiveIndex = active;
            let selectedOne = false;
            items.forEach((item, index) => {
                const keys = Array.isArray(value) ? value : [value];
                const indices = Array.isArray(active) ? active : [active];
                const selected = this.selectionSource === 'index'
                    ? indices.includes(index)
                    : keys.some((key) => key === (item.value() ?? index) || key === item.itemId());
                const expanded = selected && !item.disabled() && (this.multiple() || !selectedOne);
                if (expanded)
                    selectedOne = true;
                item.expanded.set(expanded);
            });
        });
    }
    // Outputs (Signals API)
    expandedChange = output();
    onOpen = output();
    onClose = output();
    // Lista de itens registrados no accordion
    items = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    // ── Registro e Gerenciamento de Itens ──────────────────────
    registerItem(item) {
        this.items.update((list) => [...list, item]);
    }
    unregisterItem(item) {
        this.items.update((list) => list.filter((i) => i !== item));
    }
    onItemToggle(targetItem, isExpanded, originalEvent = new Event('toggle')) {
        if (!this.multiple() && isExpanded) {
            // Fecha todos os outros itens quando multiple for false
            for (const item of this.items()) {
                if (item !== targetItem && item.expanded()) {
                    item.expanded.set(false);
                    item.closed.emit();
                    item.toggle.emit(false);
                }
            }
        }
        const visibleItems = this.items();
        const activeIndexes = visibleItems
            .filter((item) => item.expanded())
            .map((item) => visibleItems.indexOf(item));
        const activeValue = this.multiple()
            ? activeIndexes
            : (activeIndexes[0] ?? null);
        this.activeIndex.set(activeValue);
        this.expandedChange.emit({
            id: targetItem.itemId(),
            expanded: isExpanded,
            originalEvent,
            index: visibleItems.indexOf(targetItem),
        });
        const activeIds = visibleItems
            .filter((item) => item.expanded())
            .map((item) => item.value() ?? item.itemId());
        this.value.set(this.multiple() ? activeIds : (activeIds[0] ?? ''));
        const event = {
            id: targetItem.itemId(),
            expanded: isExpanded,
            originalEvent,
            index: visibleItems.indexOf(targetItem),
        };
        (isExpanded ? this.onOpen : this.onClose).emit(event);
    }
    // ── Navegação por Teclado (WAI-ARIA Accordion Pattern) ─────
    handleKeyNavigation(event, currentItem) {
        const enabledItems = this.items().filter((item) => !item.disabled());
        const currentIndex = enabledItems.indexOf(currentItem);
        if (currentIndex === -1)
            return;
        let targetItem;
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                targetItem = enabledItems[(currentIndex + 1) % enabledItems.length];
                break;
            case 'ArrowUp':
                event.preventDefault();
                targetItem =
                    enabledItems[(currentIndex - 1 + enabledItems.length) % enabledItems.length];
                break;
            case 'Home':
                event.preventDefault();
                targetItem = enabledItems[0];
                break;
            case 'End':
                event.preventDefault();
                targetItem = enabledItems[enabledItems.length - 1];
                break;
        }
        if (targetItem) {
            targetItem.focusHeader();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: AccordionComponent, isStandalone: true, selector: "orc-accordion", inputs: { multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, expandIcon: { classPropertyName: "expandIcon", publicName: "expandIcon", isSignal: true, isRequired: false, transformFunction: null }, collapseIcon: { classPropertyName: "collapseIcon", publicName: "collapseIcon", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, headerAriaLevel: { classPropertyName: "headerAriaLevel", publicName: "headerAriaLevel", isSignal: true, isRequired: false, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", activeIndex: "activeIndexChange", expandedChange: "expandedChange", onOpen: "onOpen", onClose: "onClose" }, ngImport: i0, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-accordion p-component orc-accordion\"\n  [class]=\"'p-accordion p-component orc-accordion ' + styleClass()\"\n  [class.orc-accordion--separated]=\"variant() === 'separated'\"\n  [class.orc-accordion--bordered]=\"variant() === 'bordered'\"\n  role=\"region\"\n  [attr.data-pc-name]=\"'accordion'\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion{display:flex;flex-direction:column;width:100%;box-sizing:border-box}.orc-accordion--separated{gap:var(--space-3, .75rem)}.orc-accordion--bordered{border:1px solid var(--border-default, #e5e5e5);border-radius:var(--radius-lg, 12px);overflow:hidden}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-accordion', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-accordion p-component orc-accordion\"\n  [class]=\"'p-accordion p-component orc-accordion ' + styleClass()\"\n  [class.orc-accordion--separated]=\"variant() === 'separated'\"\n  [class.orc-accordion--bordered]=\"variant() === 'bordered'\"\n  role=\"region\"\n  [attr.data-pc-name]=\"'accordion'\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion{display:flex;flex-direction:column;width:100%;box-sizing:border-box}.orc-accordion--separated{gap:var(--space-3, .75rem)}.orc-accordion--bordered{border:1px solid var(--border-default, #e5e5e5);border-radius:var(--radius-lg, 12px);overflow:hidden}\n"] }]
        }], ctorParameters: () => [], propDecorators: { multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], expandIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandIcon", required: false }] }], collapseIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapseIcon", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], headerAriaLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerAriaLevel", required: false }] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }, { type: i0.Output, args: ["activeIndexChange"] }], expandedChange: [{ type: i0.Output, args: ["expandedChange"] }], onOpen: [{ type: i0.Output, args: ["onOpen"] }], onClose: [{ type: i0.Output, args: ["onClose"] }] } });

let uniqueIdCounter = 0;
class AccordionItemComponent {
    accordion = inject(AccordionComponent, { optional: true });
    // Inputs (Signals API)
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    title = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    header = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    headerStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerStyleClass" }] : /* istanbul ignore next */ []));
    contentStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentStyleClass" }] : /* istanbul ignore next */ []));
    closable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closable" }] : /* istanbul ignore next */ []));
    cache = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cache" }] : /* istanbul ignore next */ []));
    subtitle = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    icon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    hideToggle = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideToggle" }] : /* istanbul ignore next */ []));
    iconPos = input('end', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []));
    headerAriaLevel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerAriaLevel" }] : /* istanbul ignore next */ []));
    // Model (Two-way binding Signals API)
    expanded = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []));
    // Outputs (Signals API)
    opened = output();
    closed = output();
    toggle = output();
    // Referência do botão de cabeçalho para foco programático
    headerButton = viewChild('headerBtn', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerButton" }] : /* istanbul ignore next */ []));
    // ID interno garantido
    fallbackId = `orc-accordion-item-${++uniqueIdCounter}`;
    itemId = computed(() => this.id() || this.fallbackId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemId" }] : /* istanbul ignore next */ []));
    effectiveTitle = computed(() => this.header() ?? this.title(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveTitle" }] : /* istanbul ignore next */ []));
    headerId = computed(() => `orc-accordion-header-${this.itemId()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerId" }] : /* istanbul ignore next */ []));
    panelId = computed(() => `orc-accordion-panel-${this.itemId()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelId" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        if (this.accordion) {
            this.accordion.registerItem(this);
        }
    }
    ngOnDestroy() {
        if (this.accordion) {
            this.accordion.unregisterItem(this);
        }
    }
    // ── Métodos de Controle ───────────────────────────────────
    toggleExpanded(originalEvent = new Event('toggle')) {
        if (this.disabled())
            return;
        const nextState = !this.expanded();
        this.expanded.set(nextState);
        if (nextState) {
            this.opened.emit();
        }
        else {
            this.closed.emit();
        }
        this.toggle.emit(nextState);
        if (this.accordion) {
            this.accordion.onItemToggle(this, nextState, originalEvent);
        }
    }
    focusHeader() {
        this.headerButton()?.nativeElement.focus();
    }
    onKeyDown(event) {
        if (this.accordion) {
            this.accordion.handleKeyNavigation(event, this);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccordionItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: AccordionItemComponent, isStandalone: true, selector: "orc-accordion-item", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, headerStyleClass: { classPropertyName: "headerStyleClass", publicName: "headerStyleClass", isSignal: true, isRequired: false, transformFunction: null }, contentStyleClass: { classPropertyName: "contentStyleClass", publicName: "contentStyleClass", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, cache: { classPropertyName: "cache", publicName: "cache", isSignal: true, isRequired: false, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, hideToggle: { classPropertyName: "hideToggle", publicName: "hideToggle", isSignal: true, isRequired: false, transformFunction: null }, iconPos: { classPropertyName: "iconPos", publicName: "iconPos", isSignal: true, isRequired: false, transformFunction: null }, headerAriaLevel: { classPropertyName: "headerAriaLevel", publicName: "headerAriaLevel", isSignal: true, isRequired: false, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expanded: "expandedChange", opened: "opened", closed: "closed", toggle: "toggle" }, viewQueries: [{ propertyName: "headerButton", first: true, predicate: ["headerBtn"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-accordionpanel orc-accordion-item\"\n  [class.orc-accordion-item--expanded]=\"expanded()\"\n  [class.orc-accordion-item--disabled]=\"disabled()\"\n>\n  <!-- Cabe\u00E7alho (WAI-ARIA Button) -->\n  <button\n    #headerBtn\n    type=\"button\"\n    class=\"p-accordionheader orc-accordion-item__header\"\n    [attr.data-pc-section]=\"'header'\"\n    [attr.id]=\"headerId()\"\n    [attr.aria-expanded]=\"expanded()\"\n    [attr.aria-controls]=\"panelId()\"\n    [attr.aria-level]=\"headerAriaLevel()\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleExpanded($event)\"\n    (keydown)=\"onKeyDown($event)\"\n  >\n    <!-- Custom Header Projection or Default Title -->\n    <div class=\"orc-accordion-item__header-content\">\n      <ng-content select=\"[accordion-header], [accordionHeader]\"></ng-content>\n\n      <div class=\"orc-accordion-item__title-group\" *ngIf=\"effectiveTitle()\">\n        <span class=\"orc-accordion-item__title\">{{ effectiveTitle() }}</span>\n        <span *ngIf=\"subtitle()\" class=\"orc-accordion-item__subtitle\">{{ subtitle() }}</span>\n      </div>\n    </div>\n\n    <!-- Chevron Indicator (Figma Node 26:16952 & 26:17019) -->\n    <span *ngIf=\"!hideToggle()\" class=\"orc-accordion-item__chevron\" aria-hidden=\"true\">\n      <svg\n        viewBox=\"0 0 24 24\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      >\n        <polyline points=\"6 9 12 15 18 9\"></polyline>\n      </svg>\n    </span>\n  </button>\n\n  <!-- Painel de Conte\u00FAdo com Anima\u00E7\u00E3o Fluida (WAI-ARIA Region) -->\n  <div\n    class=\"p-accordioncontent orc-accordion-item__collapse\"\n    [class.orc-accordion-item__collapse--expanded]=\"expanded()\"\n    [attr.id]=\"panelId()\"\n    role=\"region\"\n    [attr.aria-labelledby]=\"headerId()\"\n    [hidden]=\"!expanded()\"\n    [attr.aria-hidden]=\"expanded() ? null : 'true'\"\n  >\n    <div class=\"orc-accordion-item__content\">\n      <div class=\"orc-accordion-item__body\">\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion-item{width:100%;border-bottom:1px solid var(--border-default, #e5e5e5);font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease)}.orc-accordion-item:last-child{border-bottom:none}.orc-accordion-item__header{display:flex;align-items:center;justify-content:space-between;width:100%;padding:15px 10px;background:transparent;border:none;cursor:pointer;text-align:left;gap:var(--space-4, 1rem);-webkit-user-select:none;user-select:none;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 6px)}.orc-accordion-item__header:hover:not(:disabled){background-color:var(--bg-subtle, rgba(0, 0, 0, .02))}.orc-accordion-item__header:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-accordion-item__header-content{flex:1;min-width:0}.orc-accordion-item__title-group{display:flex;flex-direction:column;gap:2px}.orc-accordion-item__title{font-size:.875rem;font-weight:500;line-height:1.428;color:var(--orc-font-main, var(--text-primary, #141414))}.orc-accordion-item__subtitle{font-size:.75rem;font-weight:400;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item__chevron{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;flex-shrink:0;color:var(--orc-font-main, var(--text-primary, #141414));transition:transform var(--transition-normal, .2s cubic-bezier(.4, 0, .2, 1))}.orc-accordion-item__chevron svg{width:16px;height:16px;stroke-width:2.2}.orc-accordion-item--expanded .orc-accordion-item__chevron{transform:rotate(180deg)}.orc-accordion-item__collapse{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.orc-accordion-item__collapse--expanded{grid-template-rows:1fr}.orc-accordion-item__content{overflow:hidden}.orc-accordion-item__body{padding:0 10px 15px;font-size:.875rem;font-weight:400;line-height:1.5;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item--disabled{opacity:.45;pointer-events:none}.orc-accordion-item--disabled .orc-accordion-item__header{cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccordionItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-accordion-item', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"p-accordionpanel orc-accordion-item\"\n  [class.orc-accordion-item--expanded]=\"expanded()\"\n  [class.orc-accordion-item--disabled]=\"disabled()\"\n>\n  <!-- Cabe\u00E7alho (WAI-ARIA Button) -->\n  <button\n    #headerBtn\n    type=\"button\"\n    class=\"p-accordionheader orc-accordion-item__header\"\n    [attr.data-pc-section]=\"'header'\"\n    [attr.id]=\"headerId()\"\n    [attr.aria-expanded]=\"expanded()\"\n    [attr.aria-controls]=\"panelId()\"\n    [attr.aria-level]=\"headerAriaLevel()\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleExpanded($event)\"\n    (keydown)=\"onKeyDown($event)\"\n  >\n    <!-- Custom Header Projection or Default Title -->\n    <div class=\"orc-accordion-item__header-content\">\n      <ng-content select=\"[accordion-header], [accordionHeader]\"></ng-content>\n\n      <div class=\"orc-accordion-item__title-group\" *ngIf=\"effectiveTitle()\">\n        <span class=\"orc-accordion-item__title\">{{ effectiveTitle() }}</span>\n        <span *ngIf=\"subtitle()\" class=\"orc-accordion-item__subtitle\">{{ subtitle() }}</span>\n      </div>\n    </div>\n\n    <!-- Chevron Indicator (Figma Node 26:16952 & 26:17019) -->\n    <span *ngIf=\"!hideToggle()\" class=\"orc-accordion-item__chevron\" aria-hidden=\"true\">\n      <svg\n        viewBox=\"0 0 24 24\"\n        fill=\"none\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      >\n        <polyline points=\"6 9 12 15 18 9\"></polyline>\n      </svg>\n    </span>\n  </button>\n\n  <!-- Painel de Conte\u00FAdo com Anima\u00E7\u00E3o Fluida (WAI-ARIA Region) -->\n  <div\n    class=\"p-accordioncontent orc-accordion-item__collapse\"\n    [class.orc-accordion-item__collapse--expanded]=\"expanded()\"\n    [attr.id]=\"panelId()\"\n    role=\"region\"\n    [attr.aria-labelledby]=\"headerId()\"\n    [hidden]=\"!expanded()\"\n    [attr.aria-hidden]=\"expanded() ? null : 'true'\"\n  >\n    <div class=\"orc-accordion-item__content\">\n      <div class=\"orc-accordion-item__body\">\n        <ng-content></ng-content>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-accordion-item{width:100%;border-bottom:1px solid var(--border-default, #e5e5e5);font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease)}.orc-accordion-item:last-child{border-bottom:none}.orc-accordion-item__header{display:flex;align-items:center;justify-content:space-between;width:100%;padding:15px 10px;background:transparent;border:none;cursor:pointer;text-align:left;gap:var(--space-4, 1rem);-webkit-user-select:none;user-select:none;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease);outline:none;border-radius:var(--radius-sm, 6px)}.orc-accordion-item__header:hover:not(:disabled){background-color:var(--bg-subtle, rgba(0, 0, 0, .02))}.orc-accordion-item__header:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-accordion-item__header-content{flex:1;min-width:0}.orc-accordion-item__title-group{display:flex;flex-direction:column;gap:2px}.orc-accordion-item__title{font-size:.875rem;font-weight:500;line-height:1.428;color:var(--orc-font-main, var(--text-primary, #141414))}.orc-accordion-item__subtitle{font-size:.75rem;font-weight:400;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item__chevron{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;flex-shrink:0;color:var(--orc-font-main, var(--text-primary, #141414));transition:transform var(--transition-normal, .2s cubic-bezier(.4, 0, .2, 1))}.orc-accordion-item__chevron svg{width:16px;height:16px;stroke-width:2.2}.orc-accordion-item--expanded .orc-accordion-item__chevron{transform:rotate(180deg)}.orc-accordion-item__collapse{display:grid;grid-template-rows:0fr;transition:grid-template-rows .22s cubic-bezier(.4,0,.2,1)}.orc-accordion-item__collapse--expanded{grid-template-rows:1fr}.orc-accordion-item__content{overflow:hidden}.orc-accordion-item__body{padding:0 10px 15px;font-size:.875rem;font-weight:400;line-height:1.5;color:var(--orc-font-secondary, var(--text-secondary, #666666))}.orc-accordion-item--disabled{opacity:.45;pointer-events:none}.orc-accordion-item--disabled .orc-accordion-item__header{cursor:not-allowed}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], headerStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerStyleClass", required: false }] }], contentStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentStyleClass", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], cache: [{ type: i0.Input, args: [{ isSignal: true, alias: "cache", required: false }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], hideToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideToggle", required: false }] }], iconPos: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconPos", required: false }] }], headerAriaLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerAriaLevel", required: false }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }, { type: i0.Output, args: ["expandedChange"] }], opened: [{ type: i0.Output, args: ["opened"] }], closed: [{ type: i0.Output, args: ["closed"] }], toggle: [{ type: i0.Output, args: ["toggle"] }], headerButton: [{ type: i0.ViewChild, args: ['headerBtn', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionComponent, AccordionItemComponent };
//# sourceMappingURL=ciag-orchestra-accordion.mjs.map
