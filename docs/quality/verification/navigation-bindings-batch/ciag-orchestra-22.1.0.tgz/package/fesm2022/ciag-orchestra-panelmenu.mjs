export * from '@ciag/orchestra/panel-menu';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-panelmenu.mjs.map
