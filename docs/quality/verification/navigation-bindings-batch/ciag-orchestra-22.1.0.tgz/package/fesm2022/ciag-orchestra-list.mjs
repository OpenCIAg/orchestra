import * as i0 from '@angular/core';
import { input, model, output, signal, viewChildren, ChangeDetectionStrategy, Component } from '@angular/core';

class ListComponent {
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    selection = input('none', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    selectedIds = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedIds" }] : /* istanbul ignore next */ []));
    itemSelect = output();
    activeIndex = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    listItems = viewChildren('listItem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listItems" }] : /* istanbul ignore next */ []));
    isSelected(item) { return this.selectedIds().length ? this.selectedIds().includes(item.id) : !!item.selected; }
    select(item) { if (item.disabled)
        return; if (this.selection() !== 'none') {
        const ids = this.selection() === 'single' ? [item.id] : this.selectedIds().includes(item.id) ? this.selectedIds().filter(id => id !== item.id) : [...this.selectedIds(), item.id];
        this.selectedIds.set(ids);
    } this.itemSelect.emit(item); }
    onKeydown(event, index) { const enabled = this.items().map((item, i) => item.disabled ? -1 : i).filter(i => i >= 0); if (!enabled.length)
        return; const current = enabled.indexOf(index); let target = -1; if (event.key === 'ArrowDown')
        target = enabled[(current + 1) % enabled.length];
    else if (event.key === 'ArrowUp')
        target = enabled[(current - 1 + enabled.length) % enabled.length];
    else if (event.key === 'Home')
        target = enabled[0];
    else if (event.key === 'End')
        target = enabled[enabled.length - 1];
    else
        return; event.preventDefault(); this.activeIndex.set(target); queueMicrotask(() => this.listItems()[target]?.nativeElement.focus()); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ListComponent, isStandalone: true, selector: "orc-list", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, selectedIds: { classPropertyName: "selectedIds", publicName: "selectedIds", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedIds: "selectedIdsChange", itemSelect: "itemSelect" }, host: { properties: { "class": "styleClass()", "attr.id": "id() || null", "attr.data-pc-name": "'listbox'" }, classAttribute: "p-listbox p-component" }, viewQueries: [{ propertyName: "listItems", predicate: ["listItem"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"orc-list\" role=\"listbox\" [attr.aria-label]=\"label() || null\" [attr.aria-multiselectable]=\"selection()==='multiple' ? 'true' : null\">@for(item of items();track item.id; let i = $index){<button #listItem type=\"button\" class=\"orc-list__item\" role=\"option\" [disabled]=\"item.disabled\" [tabindex]=\"!item.disabled && activeIndex() === i ? 0 : -1\" [attr.aria-selected]=\"selection()!=='none' ? isSelected(item) : null\" (click)=\"select(item)\" (focus)=\"activeIndex.set(i)\" (keydown)=\"onKeydown($event, i)\"><span class=\"orc-list__label\">{{item.label}}</span>@if(item.description){<span class=\"orc-list__description\">{{item.description}}</span>}</button>}@empty{@if(emptyMessage()){<div class=\"orc-list__empty\" role=\"status\">{{emptyMessage()}}</div>}}</div>\n", styles: [".orc-list{display:grid;background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);overflow:hidden}.orc-list__item{display:grid;gap:var(--space-1);padding:var(--space-3) var(--space-4);text-align:left;background:transparent;color:inherit;border:0;border-bottom:1px solid var(--border-default);cursor:pointer}.orc-list__item:last-child{border-bottom:0}.orc-list__item:hover:not(:disabled),.orc-list__item[aria-selected=true]{background:var(--bg-muted)}.orc-list__item:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-list__item:disabled{opacity:.5;cursor:not-allowed}.orc-list__label{font-weight:600}.orc-list__description,.orc-list__empty{font-size:.8125rem;color:var(--text-secondary)}.orc-list__empty{padding:var(--space-4)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-list', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: { 'class': 'p-listbox p-component', '[class]': 'styleClass()', '[attr.id]': 'id() || null', '[attr.data-pc-name]': "'listbox'" }, template: "<div class=\"orc-list\" role=\"listbox\" [attr.aria-label]=\"label() || null\" [attr.aria-multiselectable]=\"selection()==='multiple' ? 'true' : null\">@for(item of items();track item.id; let i = $index){<button #listItem type=\"button\" class=\"orc-list__item\" role=\"option\" [disabled]=\"item.disabled\" [tabindex]=\"!item.disabled && activeIndex() === i ? 0 : -1\" [attr.aria-selected]=\"selection()!=='none' ? isSelected(item) : null\" (click)=\"select(item)\" (focus)=\"activeIndex.set(i)\" (keydown)=\"onKeydown($event, i)\"><span class=\"orc-list__label\">{{item.label}}</span>@if(item.description){<span class=\"orc-list__description\">{{item.description}}</span>}</button>}@empty{@if(emptyMessage()){<div class=\"orc-list__empty\" role=\"status\">{{emptyMessage()}}</div>}}</div>\n", styles: [".orc-list{display:grid;background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md);overflow:hidden}.orc-list__item{display:grid;gap:var(--space-1);padding:var(--space-3) var(--space-4);text-align:left;background:transparent;color:inherit;border:0;border-bottom:1px solid var(--border-default);cursor:pointer}.orc-list__item:last-child{border-bottom:0}.orc-list__item:hover:not(:disabled),.orc-list__item[aria-selected=true]{background:var(--bg-muted)}.orc-list__item:focus-visible{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-list__item:disabled{opacity:.5;cursor:not-allowed}.orc-list__label{font-weight:600}.orc-list__description,.orc-list__empty{font-size:.8125rem;color:var(--text-secondary)}.orc-list__empty{padding:var(--space-4)}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], selectedIds: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedIds", required: false }] }, { type: i0.Output, args: ["selectedIdsChange"] }], itemSelect: [{ type: i0.Output, args: ["itemSelect"] }], listItems: [{ type: i0.ViewChildren, args: ['listItem', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ListComponent };
//# sourceMappingURL=ciag-orchestra-list.mjs.map
