export * from '@ciag/orchestra/focus-trap';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-focustrap.mjs.map
