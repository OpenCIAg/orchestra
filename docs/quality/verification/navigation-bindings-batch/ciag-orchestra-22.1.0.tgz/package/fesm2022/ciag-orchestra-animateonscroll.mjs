export * from '@ciag/orchestra/animate-on-scroll';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-animateonscroll.mjs.map
