import * as i0 from '@angular/core';
import { input, model, numberAttribute, booleanAttribute, output, signal, computed, effect, HostListener, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

let nextCarouselId = 0;
class CarouselComponent {
    carouselId = `orc-carousel-${++nextCarouselId}`;
    autoplayTimer = null;
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    value = input(undefined, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), alias: 'value' });
    activeIndex = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    page = model(0, { ...(ngDevMode ? { debugName: "page" } : /* istanbul ignore next */ {}), alias: 'page' });
    numVisible = input(1, { ...(ngDevMode ? { debugName: "numVisible" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    numScroll = input(1, { ...(ngDevMode ? { debugName: "numScroll" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    responsiveOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "responsiveOptions" }] : /* istanbul ignore next */ []));
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    loop = input(true, { ...(ngDevMode ? { debugName: "loop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    circular = input(undefined, { ...(ngDevMode ? { debugName: "circular" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoplay = input(false, { ...(ngDevMode ? { debugName: "autoplay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoplayInterval = input(undefined, { ...(ngDevMode ? { debugName: "autoplayInterval" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    pauseOnHover = input(true, { ...(ngDevMode ? { debugName: "pauseOnHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    interval = input(5000, { ...(ngDevMode ? { debugName: "interval" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    showArrows = input(true, { ...(ngDevMode ? { debugName: "showArrows" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showNavigators = input(undefined, { ...(ngDevMode ? { debugName: "showNavigators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showIndicators = input(true, { ...(ngDevMode ? { debugName: "showIndicators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    previousLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousLabel" }] : /* istanbul ignore next */ []));
    nextLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextLabel" }] : /* istanbul ignore next */ []));
    indicatorsLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indicatorsLabel" }] : /* istanbul ignore next */ []));
    slideChange = output();
    onPage = output();
    onPlay = output();
    onPause = output();
    hovered = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hovered" }] : /* istanbul ignore next */ []));
    effectiveItems = computed(() => this.value() ?? this.items(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveItems" }] : /* istanbul ignore next */ []));
    effectiveCircular = computed(() => this.circular() ?? this.loop(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveCircular" }] : /* istanbul ignore next */ []));
    effectiveInterval = computed(() => this.autoplayInterval() ?? this.interval(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveInterval" }] : /* istanbul ignore next */ []));
    effectiveShowNavigators = computed(() => this.showNavigators() ?? this.showArrows(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveShowNavigators" }] : /* istanbul ignore next */ []));
    activeItem = computed(() => this.effectiveItems()[this.safeIndex()] ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItem" }] : /* istanbul ignore next */ []));
    safeIndex = computed(() => {
        const count = this.effectiveItems().length;
        if (!count)
            return 0;
        return Math.min(Math.max(this.activeIndex(), 0), count - 1);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "safeIndex" }] : /* istanbul ignore next */ []));
    canGoPrevious = computed(() => this.effectiveCircular() || this.findIndex(-1) !== null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canGoPrevious" }] : /* istanbul ignore next */ []));
    canGoNext = computed(() => this.effectiveCircular() || this.findIndex(1) !== null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canGoNext" }] : /* istanbul ignore next */ []));
    itemId = (index) => `${this.carouselId}-item-${index}`;
    constructor() {
        effect(() => {
            this.effectiveItems();
            this.autoplay();
            this.interval();
            this.autoplayInterval();
            this.pauseOnHover();
            this.stopAutoplay();
            if (this.autoplay() && this.effectiveItems().length > 1) {
                this.autoplayTimer = setInterval(() => { if (!(this.pauseOnHover() && this.hovered()))
                    this.next(); }, Math.max(1000, this.effectiveInterval()));
            }
        });
    }
    ngOnDestroy() {
        this.stopAutoplay();
    }
    previous() {
        const index = this.findIndex(-1);
        if (index !== null)
            this.goTo(index);
    }
    next() {
        const index = this.findIndex(1);
        if (index !== null)
            this.goTo(index);
    }
    goTo(index) {
        const item = this.effectiveItems()[index];
        if (!item || item.disabled)
            return;
        this.activeIndex.set(index);
        this.page.set(index);
        this.slideChange.emit({ index, item });
        const pageCount = Math.max(1, Math.ceil(this.effectiveItems().length / Math.max(1, this.numVisible())));
        this.onPage.emit({ first: index, last: Math.min(this.effectiveItems().length - 1, index + this.numVisible() - 1), page: Math.floor(index / Math.max(1, this.numScroll())), pageCount });
    }
    onMouseEnter() { this.hovered.set(true); this.onPause.emit(); }
    onMouseLeave() { this.hovered.set(false); if (this.autoplay())
        this.onPlay.emit(); }
    trackItem(index, item) {
        return item.id ?? index;
    }
    onKeydown(event) {
        if (this.orientation() === 'vertical') {
            if (event.key === 'ArrowUp') {
                event.preventDefault();
                this.previous();
            }
            else if (event.key === 'ArrowDown') {
                event.preventDefault();
                this.next();
            }
            return;
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            this.previous();
        }
        else if (event.key === 'ArrowRight') {
            event.preventDefault();
            this.next();
        }
    }
    findIndex(direction) {
        const items = this.effectiveItems();
        if (!items.length)
            return null;
        const start = this.safeIndex();
        for (let offset = 1; offset <= items.length; offset += 1) {
            let candidate = start + direction * offset;
            if (this.effectiveCircular()) {
                candidate = (candidate + items.length) % items.length;
            }
            else if (candidate < 0 || candidate >= items.length) {
                continue;
            }
            if (!items[candidate]?.disabled)
                return candidate;
        }
        return null;
    }
    stopAutoplay() {
        if (this.autoplayTimer !== null) {
            clearInterval(this.autoplayTimer);
            this.autoplayTimer = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CarouselComponent, isStandalone: true, selector: "orc-carousel", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null }, page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, numVisible: { classPropertyName: "numVisible", publicName: "numVisible", isSignal: true, isRequired: false, transformFunction: null }, numScroll: { classPropertyName: "numScroll", publicName: "numScroll", isSignal: true, isRequired: false, transformFunction: null }, responsiveOptions: { classPropertyName: "responsiveOptions", publicName: "responsiveOptions", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, loop: { classPropertyName: "loop", publicName: "loop", isSignal: true, isRequired: false, transformFunction: null }, circular: { classPropertyName: "circular", publicName: "circular", isSignal: true, isRequired: false, transformFunction: null }, autoplay: { classPropertyName: "autoplay", publicName: "autoplay", isSignal: true, isRequired: false, transformFunction: null }, autoplayInterval: { classPropertyName: "autoplayInterval", publicName: "autoplayInterval", isSignal: true, isRequired: false, transformFunction: null }, pauseOnHover: { classPropertyName: "pauseOnHover", publicName: "pauseOnHover", isSignal: true, isRequired: false, transformFunction: null }, interval: { classPropertyName: "interval", publicName: "interval", isSignal: true, isRequired: false, transformFunction: null }, showArrows: { classPropertyName: "showArrows", publicName: "showArrows", isSignal: true, isRequired: false, transformFunction: null }, showNavigators: { classPropertyName: "showNavigators", publicName: "showNavigators", isSignal: true, isRequired: false, transformFunction: null }, showIndicators: { classPropertyName: "showIndicators", publicName: "showIndicators", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, previousLabel: { classPropertyName: "previousLabel", publicName: "previousLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, indicatorsLabel: { classPropertyName: "indicatorsLabel", publicName: "indicatorsLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeIndex: "activeIndexChange", page: "pageChange", slideChange: "slideChange", onPage: "onPage", onPlay: "onPlay", onPause: "onPause" }, host: { listeners: { "keydown": "onKeydown($event)" } }, ngImport: i0, template: "<section\n  class=\"orc-carousel\"\n  [class.orc-carousel--vertical]=\"orientation() === 'vertical'\"\n  [attr.aria-label]=\"ariaLabel()\"\n  aria-roledescription=\"carousel\"\n  tabindex=\"0\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <div class=\"orc-carousel__viewport\" aria-live=\"polite\">\n    @if (activeItem(); as item) {\n      <article\n        class=\"orc-carousel__slide\"\n        [id]=\"itemId(safeIndex())\"\n        role=\"group\"\n        aria-roledescription=\"slide\"\n        [attr.aria-label]=\"item.label || null\"\n      >\n        @if (item.image) {\n          <img class=\"orc-carousel__image\" [src]=\"item.image\" [alt]=\"item.alt || item.label\" />\n        } @else {\n          <div class=\"orc-carousel__placeholder\" aria-hidden=\"true\">{{ safeIndex() + 1 }}</div>\n        }\n        <div class=\"orc-carousel__content\">\n          <h3>{{ item.label }}</h3>\n          @if (item.description) { <p>{{ item.description }}</p> }\n        </div>\n      </article>\n    } @else {\n      @if (emptyMessage()) { <div class=\"orc-carousel__empty\">{{ emptyMessage() }}</div> }\n    }\n  </div>\n\n  @if (effectiveShowNavigators() && effectiveItems().length > 1) {\n    <div class=\"orc-carousel__arrows\">\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"previous()\" [disabled]=\"!canGoPrevious()\" [attr.aria-label]=\"previousLabel() || 'Previous slide'\">\u2039</button>\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"next()\" [disabled]=\"!canGoNext()\" [attr.aria-label]=\"nextLabel() || 'Next slide'\">\u203A</button>\n    </div>\n  }\n\n  @if (showIndicators() && effectiveItems().length > 1) {\n    <div class=\"orc-carousel__indicators\" role=\"tablist\" [attr.aria-label]=\"indicatorsLabel() || null\">\n      @for (item of effectiveItems(); track trackItem($index, item)) {\n        <button\n          type=\"button\"\n          class=\"orc-carousel__indicator\"\n          [class.orc-carousel__indicator--active]=\"safeIndex() === $index\"\n          [disabled]=\"item.disabled\"\n          role=\"tab\"\n          [attr.aria-controls]=\"itemId($index)\"\n          [attr.aria-selected]=\"safeIndex() === $index\"\n          [attr.aria-label]=\"item.label || 'Slide ' + ($index + 1)\"\n          (click)=\"goTo($index)\"\n        ></button>\n      }\n    </div>\n  }\n</section>\n", styles: [":host{display:block;width:100%}.orc-carousel{position:relative;display:grid;gap:12px;width:100%;padding:12px;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-lg, 14px);background:var(--orc-surface-raised, var(--fill-modal, #fff));outline:none}.orc-carousel:focus-visible{box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-carousel--vertical .orc-carousel__slide{min-height:220px}.orc-carousel__viewport{min-width:0;overflow:hidden}.orc-carousel__slide{display:flex;align-items:center;gap:16px;min-height:180px;padding:12px;border-radius:var(--radius-md, 10px);background:var(--orc-surface-subtle, var(--orc-th, #f7f8fa))}.orc-carousel__image,.orc-carousel__placeholder{width:42%;max-height:220px;aspect-ratio:16/10;object-fit:cover;border-radius:var(--radius-md, 10px)}.orc-carousel__placeholder{display:grid;place-items:center;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #fff);font-size:2rem;font-weight:700}.orc-carousel__content{min-width:0}.orc-carousel__content h3{margin:0 0 6px;color:var(--orc-text, var(--orc-font-main, #141414));font-size:1rem}.orc-carousel__content p{margin:0;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));line-height:1.5}.orc-carousel__arrows{display:flex;justify-content:space-between;position:absolute;inset:50% 16px auto;transform:translateY(-50%);pointer-events:none}.orc-carousel__arrow{pointer-events:auto;display:grid;place-items:center;width:34px;height:34px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:50%;background:var(--orc-surface-raised, var(--fill-modal, #fff));color:var(--orc-text, var(--orc-font-main, #141414));font-size:1.5rem;line-height:1;cursor:pointer}.orc-carousel__arrow:disabled{opacity:.4;cursor:not-allowed}.orc-carousel__arrow:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-carousel__indicators{display:flex;justify-content:center;gap:6px}.orc-carousel__indicator{width:8px;height:8px;padding:0;border:0;border-radius:50%;background:var(--orc-border-default, var(--orc-border, #d9d9d9));cursor:pointer}.orc-carousel__indicator--active{width:22px;border-radius:999px;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-carousel__indicator:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-carousel__empty{padding:32px;text-align:center;color:var(--orc-text-secondary, var(--orc-font-secondary, #666))}@media(max-width:560px){.orc-carousel__slide{align-items:stretch;flex-direction:column}.orc-carousel__image,.orc-carousel__placeholder{width:100%}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-carousel', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<section\n  class=\"orc-carousel\"\n  [class.orc-carousel--vertical]=\"orientation() === 'vertical'\"\n  [attr.aria-label]=\"ariaLabel()\"\n  aria-roledescription=\"carousel\"\n  tabindex=\"0\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <div class=\"orc-carousel__viewport\" aria-live=\"polite\">\n    @if (activeItem(); as item) {\n      <article\n        class=\"orc-carousel__slide\"\n        [id]=\"itemId(safeIndex())\"\n        role=\"group\"\n        aria-roledescription=\"slide\"\n        [attr.aria-label]=\"item.label || null\"\n      >\n        @if (item.image) {\n          <img class=\"orc-carousel__image\" [src]=\"item.image\" [alt]=\"item.alt || item.label\" />\n        } @else {\n          <div class=\"orc-carousel__placeholder\" aria-hidden=\"true\">{{ safeIndex() + 1 }}</div>\n        }\n        <div class=\"orc-carousel__content\">\n          <h3>{{ item.label }}</h3>\n          @if (item.description) { <p>{{ item.description }}</p> }\n        </div>\n      </article>\n    } @else {\n      @if (emptyMessage()) { <div class=\"orc-carousel__empty\">{{ emptyMessage() }}</div> }\n    }\n  </div>\n\n  @if (effectiveShowNavigators() && effectiveItems().length > 1) {\n    <div class=\"orc-carousel__arrows\">\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"previous()\" [disabled]=\"!canGoPrevious()\" [attr.aria-label]=\"previousLabel() || 'Previous slide'\">\u2039</button>\n      <button type=\"button\" class=\"orc-carousel__arrow\" (click)=\"next()\" [disabled]=\"!canGoNext()\" [attr.aria-label]=\"nextLabel() || 'Next slide'\">\u203A</button>\n    </div>\n  }\n\n  @if (showIndicators() && effectiveItems().length > 1) {\n    <div class=\"orc-carousel__indicators\" role=\"tablist\" [attr.aria-label]=\"indicatorsLabel() || null\">\n      @for (item of effectiveItems(); track trackItem($index, item)) {\n        <button\n          type=\"button\"\n          class=\"orc-carousel__indicator\"\n          [class.orc-carousel__indicator--active]=\"safeIndex() === $index\"\n          [disabled]=\"item.disabled\"\n          role=\"tab\"\n          [attr.aria-controls]=\"itemId($index)\"\n          [attr.aria-selected]=\"safeIndex() === $index\"\n          [attr.aria-label]=\"item.label || 'Slide ' + ($index + 1)\"\n          (click)=\"goTo($index)\"\n        ></button>\n      }\n    </div>\n  }\n</section>\n", styles: [":host{display:block;width:100%}.orc-carousel{position:relative;display:grid;gap:12px;width:100%;padding:12px;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-lg, 14px);background:var(--orc-surface-raised, var(--fill-modal, #fff));outline:none}.orc-carousel:focus-visible{box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-carousel--vertical .orc-carousel__slide{min-height:220px}.orc-carousel__viewport{min-width:0;overflow:hidden}.orc-carousel__slide{display:flex;align-items:center;gap:16px;min-height:180px;padding:12px;border-radius:var(--radius-md, 10px);background:var(--orc-surface-subtle, var(--orc-th, #f7f8fa))}.orc-carousel__image,.orc-carousel__placeholder{width:42%;max-height:220px;aspect-ratio:16/10;object-fit:cover;border-radius:var(--radius-md, 10px)}.orc-carousel__placeholder{display:grid;place-items:center;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));color:var(--orc-on-interactive, #fff);font-size:2rem;font-weight:700}.orc-carousel__content{min-width:0}.orc-carousel__content h3{margin:0 0 6px;color:var(--orc-text, var(--orc-font-main, #141414));font-size:1rem}.orc-carousel__content p{margin:0;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));line-height:1.5}.orc-carousel__arrows{display:flex;justify-content:space-between;position:absolute;inset:50% 16px auto;transform:translateY(-50%);pointer-events:none}.orc-carousel__arrow{pointer-events:auto;display:grid;place-items:center;width:34px;height:34px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:50%;background:var(--orc-surface-raised, var(--fill-modal, #fff));color:var(--orc-text, var(--orc-font-main, #141414));font-size:1.5rem;line-height:1;cursor:pointer}.orc-carousel__arrow:disabled{opacity:.4;cursor:not-allowed}.orc-carousel__arrow:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-carousel__indicators{display:flex;justify-content:center;gap:6px}.orc-carousel__indicator{width:8px;height:8px;padding:0;border:0;border-radius:50%;background:var(--orc-border-default, var(--orc-border, #d9d9d9));cursor:pointer}.orc-carousel__indicator--active{width:22px;border-radius:999px;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-carousel__indicator:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-carousel__empty{padding:32px;text-align:center;color:var(--orc-text-secondary, var(--orc-font-secondary, #666))}@media(max-width:560px){.orc-carousel__slide{align-items:stretch;flex-direction:column}.orc-carousel__image,.orc-carousel__placeholder{width:100%}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }, { type: i0.Output, args: ["activeIndexChange"] }], page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }, { type: i0.Output, args: ["pageChange"] }], numVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "numVisible", required: false }] }], numScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "numScroll", required: false }] }], responsiveOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsiveOptions", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], loop: [{ type: i0.Input, args: [{ isSignal: true, alias: "loop", required: false }] }], circular: [{ type: i0.Input, args: [{ isSignal: true, alias: "circular", required: false }] }], autoplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoplay", required: false }] }], autoplayInterval: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoplayInterval", required: false }] }], pauseOnHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "pauseOnHover", required: false }] }], interval: [{ type: i0.Input, args: [{ isSignal: true, alias: "interval", required: false }] }], showArrows: [{ type: i0.Input, args: [{ isSignal: true, alias: "showArrows", required: false }] }], showNavigators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showNavigators", required: false }] }], showIndicators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIndicators", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], previousLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], indicatorsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "indicatorsLabel", required: false }] }], slideChange: [{ type: i0.Output, args: ["slideChange"] }], onPage: [{ type: i0.Output, args: ["onPage"] }], onPlay: [{ type: i0.Output, args: ["onPlay"] }], onPause: [{ type: i0.Output, args: ["onPause"] }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CarouselComponent };
//# sourceMappingURL=ciag-orchestra-carousel.mjs.map
