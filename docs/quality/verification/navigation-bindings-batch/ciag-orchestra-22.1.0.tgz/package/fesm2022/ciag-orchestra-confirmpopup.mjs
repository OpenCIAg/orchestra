export * from '@ciag/orchestra/confirm-popup';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-confirmpopup.mjs.map
