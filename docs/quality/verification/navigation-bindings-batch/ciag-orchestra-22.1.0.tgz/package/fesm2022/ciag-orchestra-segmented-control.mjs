import * as i0 from '@angular/core';
import { input, model, booleanAttribute, output, signal, viewChildren, inject, ElementRef, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class SegmentedControlComponent {
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    change = output();
    onChange = output();
    /** Compatibility output retained for the P2 import path. */
    valueChangeEvent = output();
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    activeIndex = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    focusedIndex = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedIndex" }] : /* istanbul ignore next */ []));
    segments = viewChildren('segment', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    onModelChange = () => { };
    onTouched = () => { };
    tabStopIndex = computed(() => {
        const options = this.options();
        const focused = this.focusedIndex();
        if (this.readonly() &&
            focused !== null &&
            options[focused] &&
            !options[focused].disabled)
            return focused;
        const selected = options.findIndex((option) => !option.disabled && this.isSelected(option));
        return selected >= 0
            ? selected
            : options.findIndex((option) => !option.disabled);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabStopIndex" }] : /* istanbul ignore next */ []));
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(value) {
        this.cvaDisabled.set(value);
    }
    isSelected(option) {
        return this.value() === option.value;
    }
    isTabStop(option) {
        return this.options()[this.tabStopIndex()] === option;
    }
    onKeydown(event, index) {
        if (this.disabled() || this.cvaDisabled())
            return;
        const enabled = this.options()
            .map((option, i) => (option.disabled ? -1 : i))
            .filter((i) => i >= 0);
        if (!enabled.length)
            return;
        const current = enabled.indexOf(index ?? this.activeIndex());
        let target;
        // Arrow direction follows visual reading order in right-to-left layouts.
        const rtl = this.host.nativeElement.ownerDocument.defaultView?.getComputedStyle(this.host.nativeElement).direction === 'rtl';
        const next = event.key === 'ArrowDown' ||
            event.key === (rtl ? 'ArrowLeft' : 'ArrowRight');
        const previous = event.key === 'ArrowUp' ||
            event.key === (rtl ? 'ArrowRight' : 'ArrowLeft');
        if (next)
            target = enabled[(current + 1) % enabled.length];
        else if (previous)
            target =
                enabled[(current < 0 ? enabled.length - 1 : current + enabled.length - 1) %
                    enabled.length];
        else if (event.key === 'Home')
            target = enabled[0];
        else if (event.key === 'End')
            target = enabled[enabled.length - 1];
        else if (event.key === 'Enter' || event.key === ' ')
            target = index ?? this.activeIndex();
        else
            return;
        event.preventDefault();
        this.activeIndex.set(target);
        this.segments()[target]?.nativeElement.focus();
        const option = this.options()[target];
        if (option)
            this.select(option);
    }
    select(option) {
        if (option.disabled ||
            this.disabled() ||
            this.cvaDisabled() ||
            this.readonly())
            return;
        this.activeIndex.set(this.options().indexOf(option));
        this.onTouched();
        if (this.isSelected(option))
            return;
        this.value.set(option.value);
        this.onModelChange(option.value);
        this.change.emit(option.value);
        this.onChange.emit({ value: option.value });
        this.valueChangeEvent.emit(option.value);
    }
    onFocus(index) {
        this.activeIndex.set(index);
        this.focusedIndex.set(index);
    }
    onFocusOut(event) {
        if (!event.relatedTarget ||
            !this.host.nativeElement.contains(event.relatedTarget)) {
            this.focusedIndex.set(null);
            this.onTouched();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SegmentedControlComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: SegmentedControlComponent, isStandalone: true, selector: "orc-segmented-control", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", change: "change", onChange: "onChange", valueChangeEvent: "valueChangeEvent" }, host: { listeners: { "focusout": "onFocusOut($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SegmentedControlComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "segments", predicate: ["segment"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  [class]=\"\n    'orc-segmented-control p-selectbutton p-buttonset p-component orc-p2-segmented ' +\n    styleClass()\n  \"\n  [style]=\"style()\"\n  [attr.id]=\"inputId() || null\"\n  role=\"radiogroup\"\n  [attr.aria-label]=\"label() || null\"\n  [attr.aria-readonly]=\"readonly() || null\"\n  [attr.aria-disabled]=\"disabled() || cvaDisabled() || null\"\n  data-pc-name=\"selectbutton\"\n>\n  @for (option of options(); track option.value; let i = $index) {\n    <button\n      #segment\n      type=\"button\"\n      class=\"p-button p-component\"\n      role=\"radio\"\n      [disabled]=\"disabled() || cvaDisabled() || option.disabled\"\n      [class.orc-segmented-control__option--selected]=\"isSelected(option)\"\n      [class.selected]=\"isSelected(option)\"\n      [attr.aria-checked]=\"isSelected(option)\"\n      [attr.tabindex]=\"isTabStop(option) ? tabindex() : -1\"\n      (focus)=\"onFocus(i)\"\n      (click)=\"select(option)\"\n      (keydown)=\"onKeydown($event, i)\"\n    >\n      @if (option.icon) {\n        <span aria-hidden=\"true\">{{ option.icon }}</span>\n      }\n      {{ option.label }}\n    </button>\n  }\n</div>\n", styles: [":host{display:inline-block;max-width:100%}.orc-segmented-control{box-sizing:border-box;display:inline-flex;flex-wrap:wrap;gap:var(--space-1, .25rem);padding:var(--space-1, .25rem);border:1px solid var(--orc-border-default, #e2e8f0);border-radius:var(--radius-md, .5rem);background:var(--orc-surface, #fff);max-width:100%}button{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2, .5rem);border:0;border-radius:var(--radius-sm, .25rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);min-height:2.25rem;background:transparent;color:var(--orc-text, #0f172a);font:inherit;cursor:pointer}.orc-segmented-control__option--selected{background:var(--orc-interactive, #2563eb);color:var(--orc-on-interactive, #fff)}button:disabled{cursor:not-allowed;opacity:.55}button:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}[aria-readonly=true] button{cursor:default}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SegmentedControlComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-segmented-control', standalone: true, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SegmentedControlComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: { '(focusout)': 'onFocusOut($event)' }, template: "<div\n  [class]=\"\n    'orc-segmented-control p-selectbutton p-buttonset p-component orc-p2-segmented ' +\n    styleClass()\n  \"\n  [style]=\"style()\"\n  [attr.id]=\"inputId() || null\"\n  role=\"radiogroup\"\n  [attr.aria-label]=\"label() || null\"\n  [attr.aria-readonly]=\"readonly() || null\"\n  [attr.aria-disabled]=\"disabled() || cvaDisabled() || null\"\n  data-pc-name=\"selectbutton\"\n>\n  @for (option of options(); track option.value; let i = $index) {\n    <button\n      #segment\n      type=\"button\"\n      class=\"p-button p-component\"\n      role=\"radio\"\n      [disabled]=\"disabled() || cvaDisabled() || option.disabled\"\n      [class.orc-segmented-control__option--selected]=\"isSelected(option)\"\n      [class.selected]=\"isSelected(option)\"\n      [attr.aria-checked]=\"isSelected(option)\"\n      [attr.tabindex]=\"isTabStop(option) ? tabindex() : -1\"\n      (focus)=\"onFocus(i)\"\n      (click)=\"select(option)\"\n      (keydown)=\"onKeydown($event, i)\"\n    >\n      @if (option.icon) {\n        <span aria-hidden=\"true\">{{ option.icon }}</span>\n      }\n      {{ option.label }}\n    </button>\n  }\n</div>\n", styles: [":host{display:inline-block;max-width:100%}.orc-segmented-control{box-sizing:border-box;display:inline-flex;flex-wrap:wrap;gap:var(--space-1, .25rem);padding:var(--space-1, .25rem);border:1px solid var(--orc-border-default, #e2e8f0);border-radius:var(--radius-md, .5rem);background:var(--orc-surface, #fff);max-width:100%}button{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2, .5rem);border:0;border-radius:var(--radius-sm, .25rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);min-height:2.25rem;background:transparent;color:var(--orc-text, #0f172a);font:inherit;cursor:pointer}.orc-segmented-control__option--selected{background:var(--orc-interactive, #2563eb);color:var(--orc-on-interactive, #fff)}button:disabled{cursor:not-allowed;opacity:.55}button:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}[aria-readonly=true] button{cursor:default}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], change: [{ type: i0.Output, args: ["change"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], valueChangeEvent: [{ type: i0.Output, args: ["valueChangeEvent"] }], segments: [{ type: i0.ViewChildren, args: ['segment', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { SegmentedControlComponent };
//# sourceMappingURL=ciag-orchestra-segmented-control.mjs.map
