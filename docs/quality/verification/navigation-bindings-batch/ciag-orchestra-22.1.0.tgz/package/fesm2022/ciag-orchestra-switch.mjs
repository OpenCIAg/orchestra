import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, viewChild, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

let nextSwitchUniqueId = 0;
class SwitchComponent {
    // Inputs (Signals API)
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    trueValue = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trueValue" }] : /* istanbul ignore next */ []));
    falseValue = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "falseValue" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    description = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    labelPosition = input('end', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelPosition" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    error = input(false, { ...(ngDevMode ? { debugName: "error" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledby" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaDescribedby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedby" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    variant = input('outlined', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    // Two-way Model (Signals API)
    checked = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    // Output (Signals API)
    change = output();
    onChange = output();
    onFocus = output();
    onBlur = output();
    // Element reference do botão interativo
    buttonElement = viewChild('switchButton', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "buttonElement" }] : /* istanbul ignore next */ []));
    // Identificador único interno
    uniqueId = `orc-switch-${++nextSwitchUniqueId}`;
    // Estado interno para ControlValueAccessor
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    labelId = computed(() => `${this.effectiveId()}-label`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelId" }] : /* istanbul ignore next */ []));
    descriptionId = computed(() => `${this.effectiveId()}-desc`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "descriptionId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isError = computed(() => this.error() || !!this.errorMessage(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isError" }] : /* istanbul ignore next */ []));
    computedAriaLabelledBy = computed(() => {
        if (this.ariaLabelledby())
            return this.ariaLabelledby();
        if (this.label())
            return this.labelId();
        return null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaLabelledBy" }] : /* istanbul ignore next */ []));
    computedAriaDescribedBy = computed(() => {
        if (this.ariaDescribedby())
            return this.ariaDescribedby();
        if (this.errorMessage())
            return this.errorId();
        if (this.description())
            return this.descriptionId();
        return null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaDescribedBy" }] : /* istanbul ignore next */ []));
    hasContent = computed(() => {
        return !!this.label() || !!this.description() || !!this.errorMessage();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasContent" }] : /* istanbul ignore next */ []));
    // Callbacks do ControlValueAccessor
    onModelChange = () => { };
    onTouched = () => { };
    // ── ControlValueAccessor Implementation ───────────────────
    writeValue(val) {
        this.checked.set(val === this.trueValue());
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Event Handlers ────────────────────────────────────────
    onToggle(event) {
        event.preventDefault();
        if (this.isDisabled() || this.readonly()) {
            return;
        }
        const newChecked = !this.checked();
        this.checked.set(newChecked);
        this.onModelChange(newChecked ? this.trueValue() : this.falseValue());
        this.onTouched();
        this.change.emit({
            originalEvent: event,
            checked: newChecked,
            value: newChecked ? this.trueValue() : this.falseValue(),
        });
        this.onChange.emit({ originalEvent: event, checked: newChecked, value: newChecked ? this.trueValue() : this.falseValue() });
    }
    handleBlur(event) {
        this.onTouched();
        if (event)
            this.onBlur.emit(event);
    }
    // ── Public API Methods ────────────────────────────────────
    toggle() {
        if (this.isDisabled() || this.readonly())
            return;
        const newChecked = !this.checked();
        this.checked.set(newChecked);
        this.onModelChange(newChecked ? this.trueValue() : this.falseValue());
        this.onTouched();
        this.change.emit({
            checked: newChecked,
            value: newChecked ? this.trueValue() : this.falseValue(),
        });
        this.onChange.emit({ checked: newChecked, value: newChecked ? this.trueValue() : this.falseValue() });
    }
    focus() {
        this.buttonElement()?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SwitchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: SwitchComponent, isStandalone: true, selector: "orc-switch, orc-toggle-switch, orc-toggle", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, trueValue: { classPropertyName: "trueValue", publicName: "trueValue", isSignal: true, isRequired: false, transformFunction: null }, falseValue: { classPropertyName: "falseValue", publicName: "falseValue", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, labelPosition: { classPropertyName: "labelPosition", publicName: "labelPosition", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledby: { classPropertyName: "ariaLabelledby", publicName: "ariaLabelledby", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "ariaDescribedby", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange", change: "change", onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SwitchComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "buttonElement", first: true, predicate: ["switchButton"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-toggleswitch p-component orc-switch\"\n  [class]=\"'p-toggleswitch p-component orc-switch ' + styleClass()\"\n  [class.orc-switch--checked]=\"checked()\"\n  [class.orc-switch--disabled]=\"isDisabled()\"\n  [class.orc-switch--error]=\"isError()\"\n  [class.orc-switch--size-sm]=\"size() === 'sm'\"\n  [class.orc-switch--size-md]=\"size() === 'md'\"\n  [class.orc-switch--size-lg]=\"size() === 'lg'\"\n  [class.orc-switch--label-start]=\"labelPosition() === 'start'\"\n  [class.orc-switch--label-end]=\"labelPosition() === 'end'\"\n  [class.p-toggleswitch-checked]=\"checked()\"\n  [class.p-toggleswitch-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'toggleswitch'\"\n>\n  <!-- Content before switch (when labelPosition === 'start') -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'start' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <!-- Interactive Switch Control (W3C WAI-ARIA Switch Pattern) -->\n  <button\n    #switchButton\n    type=\"button\"\n    role=\"switch\"\n    class=\"p-toggleswitch-input orc-switch__control\"\n    [id]=\"inputId() || effectiveId()\"\n    [attr.aria-checked]=\"checked()\"\n    [disabled]=\"isDisabled() || readonly()\"\n    [attr.tabindex]=\"tabindex()\"\n    [autofocus]=\"autofocus()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || computedAriaLabelledBy()\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-invalid]=\"isError()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n    (click)=\"onToggle($event)\"\n    (focus)=\"onFocus.emit($event)\"\n    (blur)=\"handleBlur($event)\"\n  >\n    <span class=\"p-toggleswitch-slider orc-switch__track\" aria-hidden=\"true\">\n      <span class=\"p-toggleswitch-handle orc-switch__thumb\"></span>\n    </span>\n  </button>\n\n  <!-- Content after switch (when labelPosition === 'end', default) -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'end' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <div class=\"orc-switch__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{display:inline-flex}.orc-switch{display:inline-flex;align-items:flex-start;gap:var(--space-3, .75rem);-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428;--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-sm{--switch-track-w: 26px;--switch-track-h: 15px;--switch-thumb-size: 11px;--switch-thumb-offset: 2px;--switch-thumb-travel: 11px;--switch-font-size: .8125rem}.orc-switch--size-md{--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-lg{--switch-track-w: 42px;--switch-track-h: 24px;--switch-thumb-size: 18px;--switch-thumb-offset: 3px;--switch-thumb-travel: 18px;--switch-font-size: 1rem}.orc-switch--label-start,.orc-switch--label-end{flex-direction:row}.orc-switch__control{background:transparent;border:none;padding:0;margin:2px 0 0;cursor:pointer;display:inline-flex;outline:none;border-radius:200px;flex-shrink:0}.orc-switch__control:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-switch__track{width:var(--switch-track-w);height:var(--switch-track-h);background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:200px;position:relative;display:flex;align-items:center;box-sizing:border-box;transition:background-color var(--transition-base, .2s ease),border-color var(--transition-base, .2s ease),box-shadow var(--transition-base, .2s ease)}.orc-switch__thumb{width:var(--switch-thumb-size);height:var(--switch-thumb-size);background-color:var(--orc-surface-raised, var(--orc-bg, #ffffff));border-radius:200px;position:absolute;left:var(--switch-thumb-offset);box-shadow:var(--shadow-sm);transform:translate(0);transition:transform var(--transition-base, .2s ease),background-color var(--transition-base, .2s ease)}.orc-switch__content{display:flex;flex-direction:column;cursor:pointer}.orc-switch__label{font-size:var(--switch-font-size);font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-switch__description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));line-height:1.4;margin-top:2px}.orc-switch__error{font-size:.75rem;color:var(--orc-danger, var(--color-error, #fb2c36));line-height:1.4;margin-top:2px;font-weight:500}.orc-switch:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:var(--orc-border-strong, var(--orc-secondary-bg, #bfbfbf))}.orc-switch--checked .orc-switch__track{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-switch--checked .orc-switch__thumb{transform:translate(var(--switch-thumb-travel))}.orc-switch--checked .orc-switch__label{font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-switch--checked:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:var(--orc-interactive-hover, #175cd3)}.orc-switch--error .orc-switch__track{background-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--error .orc-switch__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--error .orc-switch__control:focus-visible{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--disabled{cursor:not-allowed;opacity:.5}.orc-switch--disabled .orc-switch__control,.orc-switch--disabled .orc-switch__content{cursor:not-allowed;pointer-events:none}.orc-switch--disabled .orc-switch__track{background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.orc-switch--disabled.orc-switch--checked .orc-switch__track{background-color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-switch--disabled .orc-switch__label,.orc-switch--disabled .orc-switch__description{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}@media(prefers-reduced-motion:reduce){.orc-switch__track,.orc-switch__thumb{transition:none!important}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SwitchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-switch, orc-toggle-switch, orc-toggle', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SwitchComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-toggleswitch p-component orc-switch\"\n  [class]=\"'p-toggleswitch p-component orc-switch ' + styleClass()\"\n  [class.orc-switch--checked]=\"checked()\"\n  [class.orc-switch--disabled]=\"isDisabled()\"\n  [class.orc-switch--error]=\"isError()\"\n  [class.orc-switch--size-sm]=\"size() === 'sm'\"\n  [class.orc-switch--size-md]=\"size() === 'md'\"\n  [class.orc-switch--size-lg]=\"size() === 'lg'\"\n  [class.orc-switch--label-start]=\"labelPosition() === 'start'\"\n  [class.orc-switch--label-end]=\"labelPosition() === 'end'\"\n  [class.p-toggleswitch-checked]=\"checked()\"\n  [class.p-toggleswitch-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'toggleswitch'\"\n>\n  <!-- Content before switch (when labelPosition === 'start') -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'start' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <!-- Interactive Switch Control (W3C WAI-ARIA Switch Pattern) -->\n  <button\n    #switchButton\n    type=\"button\"\n    role=\"switch\"\n    class=\"p-toggleswitch-input orc-switch__control\"\n    [id]=\"inputId() || effectiveId()\"\n    [attr.aria-checked]=\"checked()\"\n    [disabled]=\"isDisabled() || readonly()\"\n    [attr.tabindex]=\"tabindex()\"\n    [autofocus]=\"autofocus()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || computedAriaLabelledBy()\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-invalid]=\"isError()\"\n    [attr.aria-required]=\"required() ? 'true' : null\"\n    [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n    (click)=\"onToggle($event)\"\n    (focus)=\"onFocus.emit($event)\"\n    (blur)=\"handleBlur($event)\"\n  >\n    <span class=\"p-toggleswitch-slider orc-switch__track\" aria-hidden=\"true\">\n      <span class=\"p-toggleswitch-handle orc-switch__thumb\"></span>\n    </span>\n  </button>\n\n  <!-- Content after switch (when labelPosition === 'end', default) -->\n  <div\n    class=\"orc-switch__content\"\n    *ngIf=\"labelPosition() === 'end' && hasContent()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"orc-switch__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-switch__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-switch__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </div>\n\n  <div class=\"orc-switch__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{display:inline-flex}.orc-switch{display:inline-flex;align-items:flex-start;gap:var(--space-3, .75rem);-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428;--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-sm{--switch-track-w: 26px;--switch-track-h: 15px;--switch-thumb-size: 11px;--switch-thumb-offset: 2px;--switch-thumb-travel: 11px;--switch-font-size: .8125rem}.orc-switch--size-md{--switch-track-w: 32px;--switch-track-h: 18.4px;--switch-thumb-size: 14.4px;--switch-thumb-offset: 2px;--switch-thumb-travel: 13.6px;--switch-font-size: .875rem}.orc-switch--size-lg{--switch-track-w: 42px;--switch-track-h: 24px;--switch-thumb-size: 18px;--switch-thumb-offset: 3px;--switch-thumb-travel: 18px;--switch-font-size: 1rem}.orc-switch--label-start,.orc-switch--label-end{flex-direction:row}.orc-switch__control{background:transparent;border:none;padding:0;margin:2px 0 0;cursor:pointer;display:inline-flex;outline:none;border-radius:200px;flex-shrink:0}.orc-switch__control:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-switch__track{width:var(--switch-track-w);height:var(--switch-track-h);background-color:var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:200px;position:relative;display:flex;align-items:center;box-sizing:border-box;transition:background-color var(--transition-base, .2s ease),border-color var(--transition-base, .2s ease),box-shadow var(--transition-base, .2s ease)}.orc-switch__thumb{width:var(--switch-thumb-size);height:var(--switch-thumb-size);background-color:var(--orc-surface-raised, var(--orc-bg, #ffffff));border-radius:200px;position:absolute;left:var(--switch-thumb-offset);box-shadow:var(--shadow-sm);transform:translate(0);transition:transform var(--transition-base, .2s ease),background-color var(--transition-base, .2s ease)}.orc-switch__content{display:flex;flex-direction:column;cursor:pointer}.orc-switch__label{font-size:var(--switch-font-size);font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-switch__description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));line-height:1.4;margin-top:2px}.orc-switch__error{font-size:.75rem;color:var(--orc-danger, var(--color-error, #fb2c36));line-height:1.4;margin-top:2px;font-weight:500}.orc-switch:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:var(--orc-border-strong, var(--orc-secondary-bg, #bfbfbf))}.orc-switch--checked .orc-switch__track{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-switch--checked .orc-switch__thumb{transform:translate(var(--switch-thumb-travel))}.orc-switch--checked .orc-switch__label{font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-switch--checked:hover:not(.orc-switch--disabled) .orc-switch__track{background-color:var(--orc-interactive-hover, #175cd3)}.orc-switch--error .orc-switch__track{background-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--error .orc-switch__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--error .orc-switch__control:focus-visible{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-switch--disabled{cursor:not-allowed;opacity:.5}.orc-switch--disabled .orc-switch__control,.orc-switch--disabled .orc-switch__content{cursor:not-allowed;pointer-events:none}.orc-switch--disabled .orc-switch__track{background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.orc-switch--disabled.orc-switch--checked .orc-switch__track{background-color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-switch--disabled .orc-switch__label,.orc-switch--disabled .orc-switch__description{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}@media(prefers-reduced-motion:reduce){.orc-switch__track,.orc-switch__thumb{transition:none!important}}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], trueValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "trueValue", required: false }] }], falseValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "falseValue", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], labelPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelPosition", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledby", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], ariaDescribedby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedby", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], change: [{ type: i0.Output, args: ["change"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], buttonElement: [{ type: i0.ViewChild, args: ['switchButton', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { SwitchComponent };
//# sourceMappingURL=ciag-orchestra-switch.mjs.map
