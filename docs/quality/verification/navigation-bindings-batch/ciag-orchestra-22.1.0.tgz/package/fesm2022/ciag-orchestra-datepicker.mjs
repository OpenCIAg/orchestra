export { DatePickerComponent as DatePicker, DatePickerComponent as DatepickerComponent } from '@ciag/orchestra/date-picker';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-datepicker.mjs.map
