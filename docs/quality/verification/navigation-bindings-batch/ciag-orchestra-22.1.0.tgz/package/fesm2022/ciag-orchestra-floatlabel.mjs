export * from '@ciag/orchestra/float-label';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-floatlabel.mjs.map
