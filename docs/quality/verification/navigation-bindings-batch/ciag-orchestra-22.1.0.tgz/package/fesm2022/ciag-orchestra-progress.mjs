import * as i0 from '@angular/core';
import { input, booleanAttribute, computed, TemplateRef, ContentChild, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class ProgressBarComponent {
    /** PrimeNG-compatible projected content template (`#content`, implicit value). */
    contentTemplate;
    // ── Inputs (Signals API) ──────────────────────────────────
    /** Valor percentual atual do progresso (0 a 100) */
    value = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Modo de operação: 'determinate' (valor numérico) ou 'indeterminate' (animação contínua) */
    mode = input('determinate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    variant = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Espessura / tamanho da barra: 'sm' (4px) | 'md' (8px - padrão Figma) | 'lg' (12px) */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Rótulo textual opcional exibido no topo à esquerda (ex: 'Progresso', 'Upload') */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Exibe a porcentagem numérica no topo à direita */
    showValue = input(false, { ...(ngDevMode ? { debugName: "showValue" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    unit = input('%', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "unit" }] : /* istanbul ignore next */ []));
    color = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    valueStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valueStyleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    /** Prefixo opcional para exibição de valor (ex: '$') */
    valuePrefix = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valuePrefix" }] : /* istanbul ignore next */ []));
    /** Sufixo para exibição de valor (padrão: '%') */
    valueSuffix = input('%', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Cantos arredondados tipo pílula (padrão Figma: true) */
    rounded = input(true, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Suporte a etapas segmentadas (ex: 3 barras discretas) */
    segments = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []));
    /** Etapa ativa atual no modo segmentado (1-indexed ou 0-indexed) */
    currentSegment = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentSegment" }] : /* istanbul ignore next */ []));
    /** Altura customizada (ex: '6px' ou número 6) */
    customHeight = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customHeight" }] : /* istanbul ignore next */ []));
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    customColor = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customColor" }] : /* istanbul ignore next */ []));
    /** Cor customizada da trilha / fundo da barra */
    customTrackColor = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customTrackColor" }] : /* istanbul ignore next */ []));
    markers = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "markers" }] : /* istanbul ignore next */ []));
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Sobrescreve a descrição audível aria-valuetext */
    ariaValueText = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaValueText" }] : /* istanbul ignore next */ []));
    // ── Computeds Reativos ────────────────────────────────────
    isIndeterminate = computed(() => this.mode() === 'indeterminate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isIndeterminate" }] : /* istanbul ignore next */ []));
    normalizedValue = computed(() => {
        const val = Number(this.value());
        if (isNaN(val))
            return 0;
        return Math.min(100, Math.max(0, val));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedValue" }] : /* istanbul ignore next */ []));
    formattedValue = computed(() => {
        const suffix = this.valueSuffix() === '%' && this.unit() !== '%' ? this.unit() : this.valueSuffix();
        return `${this.valuePrefix()}${Math.round(this.normalizedValue())}${suffix}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formattedValue" }] : /* istanbul ignore next */ []));
    effectiveColor = computed(() => this.customColor() || this.color() || '', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveColor" }] : /* istanbul ignore next */ []));
    hasHeader = computed(() => {
        return Boolean(this.label());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasHeader" }] : /* istanbul ignore next */ []));
    segmentArray = computed(() => {
        const total = this.segments();
        if (total <= 0)
            return [];
        return Array.from({ length: total }, (_, i) => i + 1);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "segmentArray" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ProgressBarComponent, isStandalone: true, selector: "orc-progress-bar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null }, unit: { classPropertyName: "unit", publicName: "unit", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, valueStyleClass: { classPropertyName: "valueStyleClass", publicName: "valueStyleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, valuePrefix: { classPropertyName: "valuePrefix", publicName: "valuePrefix", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, segments: { classPropertyName: "segments", publicName: "segments", isSignal: true, isRequired: false, transformFunction: null }, currentSegment: { classPropertyName: "currentSegment", publicName: "currentSegment", isSignal: true, isRequired: false, transformFunction: null }, customHeight: { classPropertyName: "customHeight", publicName: "customHeight", isSignal: true, isRequired: false, transformFunction: null }, customColor: { classPropertyName: "customColor", publicName: "customColor", isSignal: true, isRequired: false, transformFunction: null }, customTrackColor: { classPropertyName: "customTrackColor", publicName: "customTrackColor", isSignal: true, isRequired: false, transformFunction: null }, markers: { classPropertyName: "markers", publicName: "markers", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaValueText: { classPropertyName: "ariaValueText", publicName: "ariaValueText", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "contentTemplate", first: true, predicate: ["content"], descendants: true, read: TemplateRef }], ngImport: i0, template: "<div\n  class=\"p-progressbar p-component orc-progress-bar-host\"\n  [class]=\"'orc-progress-bar-host ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-progress-bar--rounded]=\"rounded()\"\n  [class.orc-progress-bar--sm]=\"size() === 'sm'\"\n  [class.orc-progress-bar--md]=\"size() === 'md'\"\n  [class.orc-progress-bar--lg]=\"size() === 'lg'\"\n  [class.orc-progress-bar--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-bar--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-bar--success]=\"variant() === 'success'\"\n  [class.orc-progress-bar--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-bar--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-bar--indeterminate]=\"isIndeterminate()\"\n  [class.p-progressbar-determinate]=\"!isIndeterminate()\"\n  [class.p-progressbar-indeterminate]=\"isIndeterminate()\"\n  [attr.data-pc-name]=\"'progressbar'\"\n  [attr.data-pc-section]=\"'root'\"\n>\n  <!-- Header (Label & Valor num\u00E9rico) -->\n  @if (hasHeader()) {\n    <div class=\"orc-progress-bar__header\">\n      @if (label()) {\n        <span class=\"orc-progress-bar__label\">{{ label() }}</span>\n      }\n      @if (showValue() && !isIndeterminate()) {\n        <span class=\"orc-progress-bar__value\" [class]=\"'orc-progress-bar__value ' + valueStyleClass()\">{{ formattedValue() }}</span>\n      }\n    </div>\n  }\n\n  <!-- Segmented Bars Mode -->\n  @if (segmentArray().length > 0) {\n    <div\n      class=\"orc-progress-bar__segments\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"currentSegment()\"\n      [attr.aria-valuemin]=\"1\"\n      [attr.aria-valuemax]=\"segmentArray().length\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-valuetext]=\"ariaValueText() || null\"\n    >\n      @for (seg of segmentArray(); track seg) {\n        <div\n          class=\"orc-progress-bar__segment-item\"\n          [class.orc-progress-bar__segment-item--active]=\"seg <= currentSegment()\"\n          [style.background-color]=\"seg <= currentSegment() ? (effectiveColor() || null) : (customTrackColor() || null)\"\n          [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n        ></div>\n      }\n    </div>\n  } @else {\n    <!-- Continuous Progress Bar Track -->\n    <div\n      class=\"orc-progress-bar__track\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n      [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n      [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? null : formattedValue())\"\n      [style.background-color]=\"customTrackColor() || null\"\n      [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n    >\n      <div\n        class=\"p-progressbar-value p-progressbar-value-animate orc-progress-bar__fill\"\n        [style.width]=\"isIndeterminate() ? null : (normalizedValue() + '%')\"\n        [style.background-color]=\"effectiveColor() || null\"\n        [attr.data-pc-section]=\"'value'\"\n      >\n        <div class=\"p-progressbar-label orc-progress-bar__value\" [class]=\"'p-progressbar-label orc-progress-bar__value ' + valueStyleClass()\" [attr.data-pc-section]=\"'label'\">\n          @if (contentTemplate) {\n            <ng-container *ngTemplateOutlet=\"contentTemplate; context: { $implicit: value() }\"></ng-container>\n          } @else if (showValue() && normalizedValue() !== 0) {\n            {{ normalizedValue() }}{{ unit() }}\n          }\n        </div>\n      </div>\n      @for (marker of markers(); track marker.value) {\n        <span class=\"orc-progress-bar__marker\" [style.left.%]=\"marker.value\" [attr.data-tone]=\"marker.tone || null\" [attr.aria-label]=\"marker.label || null\"><span class=\"orc-progress-bar__marker-line\"></span>@if (marker.label) { <span class=\"orc-progress-bar__marker-label\">{{ marker.label }}</span> }</span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-progress-bar-host{display:flex;flex-direction:column;gap:4px;width:100%;box-sizing:border-box}.orc-progress-bar-host.orc-progress-bar--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-bar-host.orc-progress-bar--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-bar-host.orc-progress-bar--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-bar-host.orc-progress-bar--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-bar-host.orc-progress-bar--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-bar-host.orc-progress-bar--sm{--progress-height: 4px}.orc-progress-bar-host.orc-progress-bar--md{--progress-height: 8px}.orc-progress-bar-host.orc-progress-bar--lg{--progress-height: 12px}.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__track,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__fill,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__segment-item{border-radius:9999px}.orc-progress-bar__header{display:flex;align-items:center;justify-content:space-between;min-height:16px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:12px;line-height:16px;color:var(--orc-font-secondary, #58595b)}.orc-progress-bar__label{font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-progress-bar__value{font-weight:400;font-variant-numeric:tabular-nums;margin-left:auto;white-space:nowrap}.orc-progress-bar__track{position:relative;width:100%;height:var(--progress-height, 8px);background-color:var(--orc-border, #d9d9d9);overflow:hidden;box-sizing:border-box}.orc-progress-bar__fill{height:100%;background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));transition:width .35s cubic-bezier(.4,0,.2,1);box-sizing:border-box}.orc-progress-bar__marker{position:absolute;top:0;height:100%;z-index:1;color:var(--orc-text-secondary, #58595b);pointer-events:none}.orc-progress-bar__marker-line{display:block;width:2px;height:100%;background:currentColor;transform:translate(-1px)}.orc-progress-bar__marker-label{position:absolute;top:calc(100% + 4px);left:0;transform:translate(-50%);white-space:nowrap;font-size:11px;line-height:1}.orc-progress-bar--indeterminate .orc-progress-bar__fill{position:absolute;top:0;bottom:0;width:auto;will-change:left,right;animation:orc-indeterminate-bar 1.8s cubic-bezier(.65,.815,.735,.395) infinite}@keyframes orc-indeterminate-bar{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}.orc-progress-bar__segments{display:flex;align-items:center;gap:6px;width:100%}.orc-progress-bar__segment-item{flex:1;height:var(--progress-height, 6px);background-color:var(--orc-border, #d9d9d9);transition:background-color .3s ease}.orc-progress-bar__segment-item--active{background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed))}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-progress-bar', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"p-progressbar p-component orc-progress-bar-host\"\n  [class]=\"'orc-progress-bar-host ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-progress-bar--rounded]=\"rounded()\"\n  [class.orc-progress-bar--sm]=\"size() === 'sm'\"\n  [class.orc-progress-bar--md]=\"size() === 'md'\"\n  [class.orc-progress-bar--lg]=\"size() === 'lg'\"\n  [class.orc-progress-bar--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-bar--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-bar--success]=\"variant() === 'success'\"\n  [class.orc-progress-bar--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-bar--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-bar--indeterminate]=\"isIndeterminate()\"\n  [class.p-progressbar-determinate]=\"!isIndeterminate()\"\n  [class.p-progressbar-indeterminate]=\"isIndeterminate()\"\n  [attr.data-pc-name]=\"'progressbar'\"\n  [attr.data-pc-section]=\"'root'\"\n>\n  <!-- Header (Label & Valor num\u00E9rico) -->\n  @if (hasHeader()) {\n    <div class=\"orc-progress-bar__header\">\n      @if (label()) {\n        <span class=\"orc-progress-bar__label\">{{ label() }}</span>\n      }\n      @if (showValue() && !isIndeterminate()) {\n        <span class=\"orc-progress-bar__value\" [class]=\"'orc-progress-bar__value ' + valueStyleClass()\">{{ formattedValue() }}</span>\n      }\n    </div>\n  }\n\n  <!-- Segmented Bars Mode -->\n  @if (segmentArray().length > 0) {\n    <div\n      class=\"orc-progress-bar__segments\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"currentSegment()\"\n      [attr.aria-valuemin]=\"1\"\n      [attr.aria-valuemax]=\"segmentArray().length\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-valuetext]=\"ariaValueText() || null\"\n    >\n      @for (seg of segmentArray(); track seg) {\n        <div\n          class=\"orc-progress-bar__segment-item\"\n          [class.orc-progress-bar__segment-item--active]=\"seg <= currentSegment()\"\n          [style.background-color]=\"seg <= currentSegment() ? (effectiveColor() || null) : (customTrackColor() || null)\"\n          [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n        ></div>\n      }\n    </div>\n  } @else {\n    <!-- Continuous Progress Bar Track -->\n    <div\n      class=\"orc-progress-bar__track\"\n      role=\"progressbar\"\n      [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n      [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n      [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? null : formattedValue())\"\n      [style.background-color]=\"customTrackColor() || null\"\n      [style.height]=\"customHeight() ? (customHeight() + (customHeight().toString().endsWith('px') ? '' : 'px')) : null\"\n    >\n      <div\n        class=\"p-progressbar-value p-progressbar-value-animate orc-progress-bar__fill\"\n        [style.width]=\"isIndeterminate() ? null : (normalizedValue() + '%')\"\n        [style.background-color]=\"effectiveColor() || null\"\n        [attr.data-pc-section]=\"'value'\"\n      >\n        <div class=\"p-progressbar-label orc-progress-bar__value\" [class]=\"'p-progressbar-label orc-progress-bar__value ' + valueStyleClass()\" [attr.data-pc-section]=\"'label'\">\n          @if (contentTemplate) {\n            <ng-container *ngTemplateOutlet=\"contentTemplate; context: { $implicit: value() }\"></ng-container>\n          } @else if (showValue() && normalizedValue() !== 0) {\n            {{ normalizedValue() }}{{ unit() }}\n          }\n        </div>\n      </div>\n      @for (marker of markers(); track marker.value) {\n        <span class=\"orc-progress-bar__marker\" [style.left.%]=\"marker.value\" [attr.data-tone]=\"marker.tone || null\" [attr.aria-label]=\"marker.label || null\"><span class=\"orc-progress-bar__marker-line\"></span>@if (marker.label) { <span class=\"orc-progress-bar__marker-label\">{{ marker.label }}</span> }</span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-progress-bar-host{display:flex;flex-direction:column;gap:4px;width:100%;box-sizing:border-box}.orc-progress-bar-host.orc-progress-bar--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-bar-host.orc-progress-bar--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-bar-host.orc-progress-bar--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-bar-host.orc-progress-bar--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-bar-host.orc-progress-bar--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-bar-host.orc-progress-bar--sm{--progress-height: 4px}.orc-progress-bar-host.orc-progress-bar--md{--progress-height: 8px}.orc-progress-bar-host.orc-progress-bar--lg{--progress-height: 12px}.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__track,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__fill,.orc-progress-bar-host.orc-progress-bar--rounded .orc-progress-bar__segment-item{border-radius:9999px}.orc-progress-bar__header{display:flex;align-items:center;justify-content:space-between;min-height:16px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:12px;line-height:16px;color:var(--orc-font-secondary, #58595b)}.orc-progress-bar__label{font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-progress-bar__value{font-weight:400;font-variant-numeric:tabular-nums;margin-left:auto;white-space:nowrap}.orc-progress-bar__track{position:relative;width:100%;height:var(--progress-height, 8px);background-color:var(--orc-border, #d9d9d9);overflow:hidden;box-sizing:border-box}.orc-progress-bar__fill{height:100%;background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));transition:width .35s cubic-bezier(.4,0,.2,1);box-sizing:border-box}.orc-progress-bar__marker{position:absolute;top:0;height:100%;z-index:1;color:var(--orc-text-secondary, #58595b);pointer-events:none}.orc-progress-bar__marker-line{display:block;width:2px;height:100%;background:currentColor;transform:translate(-1px)}.orc-progress-bar__marker-label{position:absolute;top:calc(100% + 4px);left:0;transform:translate(-50%);white-space:nowrap;font-size:11px;line-height:1}.orc-progress-bar--indeterminate .orc-progress-bar__fill{position:absolute;top:0;bottom:0;width:auto;will-change:left,right;animation:orc-indeterminate-bar 1.8s cubic-bezier(.65,.815,.735,.395) infinite}@keyframes orc-indeterminate-bar{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}.orc-progress-bar__segments{display:flex;align-items:center;gap:6px;width:100%}.orc-progress-bar__segment-item{flex:1;height:var(--progress-height, 6px);background-color:var(--orc-border, #d9d9d9);transition:background-color .3s ease}.orc-progress-bar__segment-item--active{background-color:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed))}\n"] }]
        }], propDecorators: { contentTemplate: [{
                type: ContentChild,
                args: ['content', { read: TemplateRef }]
            }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], unit: [{ type: i0.Input, args: [{ isSignal: true, alias: "unit", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], valueStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueStyleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], valuePrefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valuePrefix", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], segments: [{ type: i0.Input, args: [{ isSignal: true, alias: "segments", required: false }] }], currentSegment: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentSegment", required: false }] }], customHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "customHeight", required: false }] }], customColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "customColor", required: false }] }], customTrackColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "customTrackColor", required: false }] }], markers: [{ type: i0.Input, args: [{ isSignal: true, alias: "markers", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaValueText: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaValueText", required: false }] }] } });

class ProgressCircleComponent {
    // ── Inputs (Signals API) ──────────────────────────────────
    /** Valor percentual atual do progresso circular (0 a 100) */
    value = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Modo de operação: 'determinate' (valor exato) ou 'indeterminate' (spinner contínuo) */
    mode = input('determinate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    /** Status semântico / cor: 'primary' | 'neutral' | 'success' | 'warning' | 'error' | 'danger' */
    variant = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Dimensão do círculo: 'sm' (32px) | 'md' (48px) | 'lg' (64px) | 'xl' (96px) ou número em px */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Espessura do traço (em px). Se omitido, é calculado proporcionalmente ao tamanho */
    strokeWidth = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "strokeWidth" }] : /* istanbul ignore next */ []));
    animation = input('spin', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []));
    /** Exibe o valor numérico centralizado dentro do círculo */
    showValue = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showValue" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    animationDuration = input('2s', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animationDuration" }] : /* istanbul ignore next */ []));
    fill = input('none', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fill" }] : /* istanbul ignore next */ []));
    /** Cantos arredondados na ponta do arco (stroke-linecap: round) */
    rounded = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rounded" }] : /* istanbul ignore next */ []));
    /** Prefixo opcional para exibição de valor (ex: '$') */
    valuePrefix = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valuePrefix" }] : /* istanbul ignore next */ []));
    /** Sufixo para exibição de valor (padrão: '%') */
    valueSuffix = input('%', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Rótulo textual opcional */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Cor customizada de preenchimento (sobrescreve o variant) */
    customColor = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customColor" }] : /* istanbul ignore next */ []));
    /** Cor customizada da trilha de fundo */
    customTrackColor = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customTrackColor" }] : /* istanbul ignore next */ []));
    /** Sobrescreve o rótulo de acessibilidade aria-label */
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Sobrescreve a descrição audível aria-valuetext */
    ariaValueText = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaValueText" }] : /* istanbul ignore next */ []));
    // ── Computeds Reativos ────────────────────────────────────
    isIndeterminate = computed(() => this.mode() === 'indeterminate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isIndeterminate" }] : /* istanbul ignore next */ []));
    normalizedValue = computed(() => {
        const val = Number(this.value());
        if (isNaN(val))
            return 0;
        return Math.min(100, Math.max(0, val));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedValue" }] : /* istanbul ignore next */ []));
    pixelSize = computed(() => {
        const s = this.size();
        if (typeof s === 'number')
            return s > 0 ? s : 48;
        switch (s) {
            case 'sm': return 32;
            case 'md': return 48;
            case 'lg': return 64;
            case 'xl': return 96;
            default: return 48;
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pixelSize" }] : /* istanbul ignore next */ []));
    computedStrokeWidth = computed(() => {
        const custom = this.strokeWidth();
        const numeric = typeof custom === 'string' ? Number.parseFloat(custom) : custom;
        if (numeric !== undefined && numeric > 0)
            return numeric;
        const s = this.pixelSize();
        if (s <= 32)
            return 3;
        if (s <= 48)
            return 4;
        if (s <= 64)
            return 5;
        return 6;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedStrokeWidth" }] : /* istanbul ignore next */ []));
    center = computed(() => this.pixelSize() / 2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "center" }] : /* istanbul ignore next */ []));
    radius = computed(() => {
        return Math.max(1, (this.pixelSize() - this.computedStrokeWidth()) / 2);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "radius" }] : /* istanbul ignore next */ []));
    circumference = computed(() => {
        return 2 * Math.PI * this.radius();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "circumference" }] : /* istanbul ignore next */ []));
    strokeDashOffset = computed(() => {
        if (this.isIndeterminate())
            return 0;
        const progress = this.normalizedValue() / 100;
        return this.circumference() * (1 - progress);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "strokeDashOffset" }] : /* istanbul ignore next */ []));
    formattedValue = computed(() => {
        return `${this.valuePrefix()}${Math.round(this.normalizedValue())}${this.valueSuffix()}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formattedValue" }] : /* istanbul ignore next */ []));
    effectiveColor = computed(() => this.customColor() || '', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveColor" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressCircleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ProgressCircleComponent, isStandalone: true, selector: "orc-progress-circle", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, strokeWidth: { classPropertyName: "strokeWidth", publicName: "strokeWidth", isSignal: true, isRequired: false, transformFunction: null }, animation: { classPropertyName: "animation", publicName: "animation", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, animationDuration: { classPropertyName: "animationDuration", publicName: "animationDuration", isSignal: true, isRequired: false, transformFunction: null }, fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, valuePrefix: { classPropertyName: "valuePrefix", publicName: "valuePrefix", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, customColor: { classPropertyName: "customColor", publicName: "customColor", isSignal: true, isRequired: false, transformFunction: null }, customTrackColor: { classPropertyName: "customTrackColor", publicName: "customTrackColor", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaValueText: { classPropertyName: "ariaValueText", publicName: "ariaValueText", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\n  class=\"orc-progress-circle-host\"\n  [class]=\"'orc-progress-circle-host ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-progress-circle--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-circle--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-circle--success]=\"variant() === 'success'\"\n  [class.orc-progress-circle--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-circle--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-circle--indeterminate]=\"isIndeterminate() && animation() !== 'none'\"\n  [style.width.px]=\"pixelSize()\"\n  [style.height.px]=\"pixelSize()\"\n>\n  <svg\n    class=\"orc-progress-circle__svg\"\n    [attr.viewBox]=\"'0 0 ' + pixelSize() + ' ' + pixelSize()\"\n    [style.width.px]=\"pixelSize()\"\n    [style.height.px]=\"pixelSize()\"\n    role=\"progressbar\"\n    [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n    [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n    [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n    [attr.aria-label]=\"ariaLabel() || label() || null\"\n    [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? null : formattedValue())\"\n  >\n    <!-- Trilha de fundo (Track) -->\n    <circle\n      class=\"orc-progress-circle__track\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [style.stroke]=\"customTrackColor() || null\"\n    />\n\n    <!-- Arco de preenchimento (Fill) -->\n    <circle\n      class=\"orc-progress-circle__fill\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [attr.stroke-dasharray]=\"circumference()\"\n      [attr.stroke-dashoffset]=\"strokeDashOffset()\"\n      [attr.stroke-linecap]=\"rounded() ? 'round' : 'butt'\"\n      [style.stroke]=\"effectiveColor() || null\"\n      [style.animation-duration]=\"animationDuration()\"\n      [attr.fill]=\"fill()\"\n    />\n  </svg>\n\n  <!-- Conte\u00FAdo centralizado (Porcentagem ou custom template) -->\n  <div class=\"orc-progress-circle__content\" [style.font-size.px]=\"pixelSize() <= 32 ? 9 : pixelSize() <= 48 ? 11 : pixelSize() <= 64 ? 14 : 18\">\n    @if (showValue() && !isIndeterminate()) {\n      <span class=\"orc-progress-circle__value\">{{ formattedValue() }}</span>\n    } @else {\n      <ng-content></ng-content>\n    }\n  </div>\n</div>\n", styles: [":host{display:inline-block;vertical-align:middle}.orc-progress-circle-host{position:relative;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box}.orc-progress-circle-host.orc-progress-circle--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-circle-host.orc-progress-circle--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-circle-host.orc-progress-circle--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-circle-host.orc-progress-circle--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-circle-host.orc-progress-circle--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-circle__svg{display:block;transform:rotate(-90deg);transform-origin:50% 50%}.orc-progress-circle__track{stroke:var(--orc-border, #d9d9d9);fill:none}.orc-progress-circle__fill{stroke:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));fill:none;transition:stroke-dashoffset .35s cubic-bezier(.4,0,.2,1)}.orc-progress-circle--indeterminate .orc-progress-circle__svg{animation:orc-circle-rotate 1.6s linear infinite}.orc-progress-circle--indeterminate .orc-progress-circle__fill{animation:orc-circle-dash 1.6s ease-in-out infinite;transition:none}@keyframes orc-circle-rotate{to{transform:rotate(270deg)}}@keyframes orc-circle-dash{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35px}to{stroke-dasharray:89,200;stroke-dashoffset:-124px}}.orc-progress-circle__content{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;font-variant-numeric:tabular-nums;color:var(--orc-font-main, #141414)}.orc-progress-circle__value{line-height:1}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressCircleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-progress-circle', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-progress-circle-host\"\n  [class]=\"'orc-progress-circle-host ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-progress-circle--primary]=\"variant() === 'primary'\"\n  [class.orc-progress-circle--neutral]=\"variant() === 'neutral'\"\n  [class.orc-progress-circle--success]=\"variant() === 'success'\"\n  [class.orc-progress-circle--warning]=\"variant() === 'warning'\"\n  [class.orc-progress-circle--error]=\"variant() === 'error' || variant() === 'danger'\"\n  [class.orc-progress-circle--indeterminate]=\"isIndeterminate() && animation() !== 'none'\"\n  [style.width.px]=\"pixelSize()\"\n  [style.height.px]=\"pixelSize()\"\n>\n  <svg\n    class=\"orc-progress-circle__svg\"\n    [attr.viewBox]=\"'0 0 ' + pixelSize() + ' ' + pixelSize()\"\n    [style.width.px]=\"pixelSize()\"\n    [style.height.px]=\"pixelSize()\"\n    role=\"progressbar\"\n    [attr.aria-valuenow]=\"isIndeterminate() ? null : normalizedValue()\"\n    [attr.aria-valuemin]=\"isIndeterminate() ? null : 0\"\n    [attr.aria-valuemax]=\"isIndeterminate() ? null : 100\"\n    [attr.aria-label]=\"ariaLabel() || label() || null\"\n    [attr.aria-valuetext]=\"ariaValueText() || (isIndeterminate() ? null : formattedValue())\"\n  >\n    <!-- Trilha de fundo (Track) -->\n    <circle\n      class=\"orc-progress-circle__track\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [style.stroke]=\"customTrackColor() || null\"\n    />\n\n    <!-- Arco de preenchimento (Fill) -->\n    <circle\n      class=\"orc-progress-circle__fill\"\n      [attr.cx]=\"center()\"\n      [attr.cy]=\"center()\"\n      [attr.r]=\"radius()\"\n      [attr.stroke-width]=\"computedStrokeWidth()\"\n      [attr.stroke-dasharray]=\"circumference()\"\n      [attr.stroke-dashoffset]=\"strokeDashOffset()\"\n      [attr.stroke-linecap]=\"rounded() ? 'round' : 'butt'\"\n      [style.stroke]=\"effectiveColor() || null\"\n      [style.animation-duration]=\"animationDuration()\"\n      [attr.fill]=\"fill()\"\n    />\n  </svg>\n\n  <!-- Conte\u00FAdo centralizado (Porcentagem ou custom template) -->\n  <div class=\"orc-progress-circle__content\" [style.font-size.px]=\"pixelSize() <= 32 ? 9 : pixelSize() <= 48 ? 11 : pixelSize() <= 64 ? 14 : 18\">\n    @if (showValue() && !isIndeterminate()) {\n      <span class=\"orc-progress-circle__value\">{{ formattedValue() }}</span>\n    } @else {\n      <ng-content></ng-content>\n    }\n  </div>\n</div>\n", styles: [":host{display:inline-block;vertical-align:middle}.orc-progress-circle-host{position:relative;display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box}.orc-progress-circle-host.orc-progress-circle--primary{--progress-fill-color: var(--orc-color-azul-eletrico, #1c6aed)}.orc-progress-circle-host.orc-progress-circle--neutral{--progress-fill-color: var(--orc-font-main, #141414)}.orc-progress-circle-host.orc-progress-circle--success{--progress-fill-color: var(--color-success, #006f4a)}.orc-progress-circle-host.orc-progress-circle--warning{--progress-fill-color: var(--color-warning, #fe9a00)}.orc-progress-circle-host.orc-progress-circle--error{--progress-fill-color: var(--color-error, #fb2c36)}.orc-progress-circle__svg{display:block;transform:rotate(-90deg);transform-origin:50% 50%}.orc-progress-circle__track{stroke:var(--orc-border, #d9d9d9);fill:none}.orc-progress-circle__fill{stroke:var(--progress-fill-color, var(--orc-color-azul-eletrico, #1c6aed));fill:none;transition:stroke-dashoffset .35s cubic-bezier(.4,0,.2,1)}.orc-progress-circle--indeterminate .orc-progress-circle__svg{animation:orc-circle-rotate 1.6s linear infinite}.orc-progress-circle--indeterminate .orc-progress-circle__fill{animation:orc-circle-dash 1.6s ease-in-out infinite;transition:none}@keyframes orc-circle-rotate{to{transform:rotate(270deg)}}@keyframes orc-circle-dash{0%{stroke-dasharray:1,200;stroke-dashoffset:0}50%{stroke-dasharray:89,200;stroke-dashoffset:-35px}to{stroke-dasharray:89,200;stroke-dashoffset:-124px}}.orc-progress-circle__content{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;font-variant-numeric:tabular-nums;color:var(--orc-font-main, #141414)}.orc-progress-circle__value{line-height:1}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], strokeWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "strokeWidth", required: false }] }], animation: [{ type: i0.Input, args: [{ isSignal: true, alias: "animation", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], animationDuration: [{ type: i0.Input, args: [{ isSignal: true, alias: "animationDuration", required: false }] }], fill: [{ type: i0.Input, args: [{ isSignal: true, alias: "fill", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], valuePrefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valuePrefix", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], customColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "customColor", required: false }] }], customTrackColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "customTrackColor", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaValueText: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaValueText", required: false }] }] } });

class ProgressSpinnerComponent {
    strokeWidth = input(6, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "strokeWidth" }] : /* istanbul ignore next */ []));
    fill = input('currentColor', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fill" }] : /* istanbul ignore next */ []));
    color = input('currentColor', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    animationDuration = input('1.6s', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animationDuration" }] : /* istanbul ignore next */ []));
    size = input(48, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    animation = input('spin', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: ProgressSpinnerComponent, isStandalone: true, selector: "orc-progress-spinner", inputs: { strokeWidth: { classPropertyName: "strokeWidth", publicName: "strokeWidth", isSignal: true, isRequired: false, transformFunction: null }, fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, animationDuration: { classPropertyName: "animationDuration", publicName: "animationDuration", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, animation: { classPropertyName: "animation", publicName: "animation", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<svg
    viewBox="0 0 100 100"
    focusable="false"
    class="p-progressspinner p-component orc-progress-spinner"
    [class]="
      'p-progressspinner p-component orc-progress-spinner ' + styleClass()
    "
    [style]="style()"
    [class.orc-progress-spinner--static]="animation() === 'none'"
    [style.width.px]="size()"
    [style.height.px]="size()"
    [style.animation-duration]="animationDuration()"
    role="progressbar"
    [attr.aria-label]="ariaLabel() || 'Loading'"
    [attr.data-pc-name]="'progressspinner'"
  >
    <circle
      class="track"
      cx="50"
      cy="50"
      r="40"
      [attr.stroke-width]="strokeWidth()"
      [attr.stroke]="fill()"
    />
    <circle
      class="spinner"
      cx="50"
      cy="50"
      r="40"
      [attr.stroke-width]="strokeWidth()"
      [attr.stroke]="color()"
    />
  </svg>`, isInline: true, styles: [".orc-progress-spinner{display:inline-block;overflow:visible;animation:orc-spin 1.6s linear infinite}.orc-progress-spinner--static{animation:none}.orc-progress-spinner .track{fill:none;opacity:.2}.orc-progress-spinner .spinner{fill:none;stroke-linecap:round;stroke-dasharray:70 180;transform:rotate(-90deg);transform-origin:50% 50%}@keyframes orc-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-progress-spinner{animation:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProgressSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-progress-spinner', standalone: true, template: `<svg
    viewBox="0 0 100 100"
    focusable="false"
    class="p-progressspinner p-component orc-progress-spinner"
    [class]="
      'p-progressspinner p-component orc-progress-spinner ' + styleClass()
    "
    [style]="style()"
    [class.orc-progress-spinner--static]="animation() === 'none'"
    [style.width.px]="size()"
    [style.height.px]="size()"
    [style.animation-duration]="animationDuration()"
    role="progressbar"
    [attr.aria-label]="ariaLabel() || 'Loading'"
    [attr.data-pc-name]="'progressspinner'"
  >
    <circle
      class="track"
      cx="50"
      cy="50"
      r="40"
      [attr.stroke-width]="strokeWidth()"
      [attr.stroke]="fill()"
    />
    <circle
      class="spinner"
      cx="50"
      cy="50"
      r="40"
      [attr.stroke-width]="strokeWidth()"
      [attr.stroke]="color()"
    />
  </svg>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".orc-progress-spinner{display:inline-block;overflow:visible;animation:orc-spin 1.6s linear infinite}.orc-progress-spinner--static{animation:none}.orc-progress-spinner .track{fill:none;opacity:.2}.orc-progress-spinner .spinner{fill:none;stroke-linecap:round;stroke-dasharray:70 180;transform:rotate(-90deg);transform-origin:50% 50%}@keyframes orc-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-progress-spinner{animation:none}}\n"] }]
        }], propDecorators: { strokeWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "strokeWidth", required: false }] }], fill: [{ type: i0.Input, args: [{ isSignal: true, alias: "fill", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], animationDuration: [{ type: i0.Input, args: [{ isSignal: true, alias: "animationDuration", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], animation: [{ type: i0.Input, args: [{ isSignal: true, alias: "animation", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ProgressBarComponent, ProgressCircleComponent, ProgressSpinnerComponent };
//# sourceMappingURL=ciag-orchestra-progress.mjs.map
