import * as i0 from '@angular/core';
import { input, booleanAttribute, ChangeDetectionStrategy, Component } from '@angular/core';

class FormFieldComponent {
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FormFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: FormFieldComponent, isStandalone: true, selector: "orc-form-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"orc-form-field\" [class.orc-form-field--invalid]=\"error()\"><span class=\"orc-form-field__label\">{{label()}} @if(required()){<span aria-hidden=\"true\">*</span>}</span><span class=\"orc-form-field__control\"><ng-content /></span>@if(error()){<span class=\"orc-form-field__error\" role=\"alert\">{{error()}}</span>}@else if(helperText()){<span class=\"orc-form-field__help\">{{helperText()}}</span>}</div>\n", styles: [".orc-form-field{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-form-field__label{font-size:.875rem;font-weight:600}.orc-form-field__help,.orc-form-field__error{font-size:.75rem;color:var(--text-secondary)}.orc-form-field__error{color:var(--color-error)}.orc-form-field--invalid .orc-form-field__control{--border-default:var(--color-error)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-form-field', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-form-field\" [class.orc-form-field--invalid]=\"error()\"><span class=\"orc-form-field__label\">{{label()}} @if(required()){<span aria-hidden=\"true\">*</span>}</span><span class=\"orc-form-field__control\"><ng-content /></span>@if(error()){<span class=\"orc-form-field__error\" role=\"alert\">{{error()}}</span>}@else if(helperText()){<span class=\"orc-form-field__help\">{{helperText()}}</span>}</div>\n", styles: [".orc-form-field{display:grid;gap:var(--space-2);color:var(--text-primary);font-family:var(--font-sans)}.orc-form-field__label{font-size:.875rem;font-weight:600}.orc-form-field__help,.orc-form-field__error{font-size:.75rem;color:var(--text-secondary)}.orc-form-field__error{color:var(--color-error)}.orc-form-field--invalid .orc-form-field__control{--border-default:var(--color-error)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FormFieldComponent };
//# sourceMappingURL=ciag-orchestra-form-field.mjs.map
