export * from '@ciag/orchestra/tabs';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-tabview.mjs.map
