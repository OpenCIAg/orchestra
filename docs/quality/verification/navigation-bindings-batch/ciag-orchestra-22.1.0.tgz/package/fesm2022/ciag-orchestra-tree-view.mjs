import * as i0 from '@angular/core';
import { input, output, signal, inject, Injector, viewChild, computed, ElementRef, effect, afterNextRender, ChangeDetectionStrategy, Component } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';

let nextTreeViewId = 0;
class TreeViewComponent {
    nodes = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    collapseLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapseLabel" }] : /* istanbul ignore next */ []));
    expandLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandLabel" }] : /* istanbul ignore next */ []));
    nodeSelect = output();
    expanded = signal(new Set(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []));
    activeIndex = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    injector = inject(Injector);
    treeElement = viewChild('tree', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "treeElement" }] : /* istanbul ignore next */ []));
    treeId = `orc-tree-view-${++nextTreeViewId}`;
    visibleNodes = computed(() => {
        const result = [];
        const visit = (nodes, level, parentId) => nodes.forEach((node, position) => {
            const expandable = !!node.children?.length;
            result.push({
                node,
                index: result.length,
                level,
                expandable,
                position,
                setSize: nodes.length,
                parentId,
            });
            if (expandable && this.expanded().has(node.id))
                visit(node.children, level + 1, node.id);
        });
        visit(this.nodes(), 1, null);
        return result;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleNodes" }] : /* istanbul ignore next */ []));
    normalizedActiveIndex = computed(() => {
        const count = this.visibleNodes().length;
        return count ? Math.max(0, Math.min(this.activeIndex(), count - 1)) : 0;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedActiveIndex" }] : /* istanbul ignore next */ []));
    visibleNodeById = computed(() => new Map(this.visibleNodes().map((item) => [item.node.id, item])), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleNodeById" }] : /* istanbul ignore next */ []));
    /** All rendered treeitems, including descendants rendered by the recursive template. */
    treeItems = () => this.itemElements().map((element) => new ElementRef(element));
    previousVisibleIds = [];
    previousActiveIndex = 0;
    typeahead = '';
    typeaheadAt = 0;
    focusRequest = 0;
    focusTimer = null;
    constructor() {
        effect(() => {
            const ids = new Set();
            const collect = (nodes) => nodes.forEach((node) => {
                ids.add(node.id);
                if (node.children?.length)
                    collect(node.children);
            });
            collect(this.nodes());
            const current = this.expanded();
            const next = new Set([...current].filter((id) => ids.has(id)));
            if (next.size !== current.size)
                this.expanded.set(next);
            const count = this.visibleNodes().length;
            const visibleIds = this.visibleNodes().map((item) => item.node.id);
            const activeIndexChanged = this.activeIndex() !== this.previousActiveIndex;
            const previousActiveId = activeIndexChanged
                ? undefined
                : this.previousVisibleIds[this.activeIndex()];
            const preservedIndex = previousActiveId
                ? visibleIds.indexOf(previousActiveId)
                : -1;
            const index = count
                ? preservedIndex >= 0
                    ? preservedIndex
                    : Math.max(0, Math.min(this.activeIndex(), count - 1))
                : 0;
            const shouldRestoreFocus = this.previousVisibleIds.length > 0 &&
                index !== this.activeIndex() &&
                !!this.treeElement()?.nativeElement.contains(typeof document === 'undefined' ? null : document.activeElement);
            this.previousVisibleIds = visibleIds;
            if (index !== this.activeIndex())
                this.activeIndex.set(index);
            this.previousActiveIndex = index;
            if (shouldRestoreFocus && visibleIds[index]) {
                afterNextRender(() => this.focusNode(visibleIds[index]), {
                    injector: this.injector,
                });
            }
        });
    }
    visibleItem(node) {
        return this.visibleNodeById().get(node.id);
    }
    itemId(node) {
        return this.itemDomId(node.id);
    }
    groupId(node) {
        return `${this.itemId(node)}-group`;
    }
    labelId(node) {
        return `${this.itemId(node)}-label`;
    }
    toggle(node) {
        if (node.disabled || !node.children?.length)
            return;
        const wasExpanded = this.expanded().has(node.id);
        const nodeIndex = this.visibleNodeById().get(node.id)?.index ?? -1;
        const element = nodeIndex >= 0 ? this.itemElements()[nodeIndex] : undefined;
        const activeElement = typeof document === 'undefined' ? null : document.activeElement;
        const activeItem = this.visibleNodes()[this.activeIndex()];
        const focusWithinNode = !!element && !!activeElement && element.contains(activeElement);
        const activeDescendant = !!activeItem && this.isDescendant(node, activeItem.node.id);
        this.expanded.update((current) => {
            const next = new Set(current);
            wasExpanded ? next.delete(node.id) : next.add(node.id);
            return next;
        });
        if (nodeIndex >= 0) {
            this.activeIndex.set(nodeIndex);
            this.rememberCurrentVisibleState(nodeIndex);
            if (focusWithinNode || (wasExpanded && activeDescendant))
                this.focusNode(node.id);
        }
    }
    activate(node, index, event) {
        if (event) {
            const target = event.target;
            const current = event.currentTarget;
            if (target?.closest('[role="treeitem"]') !== current)
                return;
        }
        if (index !== undefined)
            this.setActiveIndex(index);
        if (!node.disabled)
            this.nodeSelect.emit(node);
    }
    keydown(event, item, index) {
        const targetTreeItem = event.target?.closest('[role="treeitem"]');
        if (event.currentTarget && targetTreeItem !== event.currentTarget)
            return;
        if (event.isComposing ||
            event.key === 'Process' ||
            event.key === 'Unidentified')
            return;
        const current = this.visibleNodeById().get(item.node.id);
        const resolvedIndex = index ?? item.index ?? current?.index ?? 0;
        const expandable = current?.expandable ?? item.expandable ?? false;
        const parentId = current?.parentId ?? item.parentId ?? null;
        const target = event.target;
        if ((event.key === 'Enter' || event.key === ' ') &&
            target?.closest('.orc-tree__toggle')) {
            event.preventDefault();
            this.toggle(item.node);
            return;
        }
        if (item.node.disabled && (event.key === 'Enter' || event.key === ' ')) {
            event.preventDefault();
            return;
        }
        if (event.key === 'ArrowRight' && expandable) {
            event.preventDefault();
            if (!this.expanded().has(item.node.id))
                this.toggle(item.node);
            else
                this.moveTo(resolvedIndex + 1);
            return;
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            if (expandable && this.expanded().has(item.node.id))
                this.toggle(item.node);
            else if (parentId) {
                const parentIndex = this.visibleNodeById().get(parentId)?.index ?? -1;
                if (parentIndex >= 0)
                    this.moveTo(parentIndex);
            }
            return;
        }
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.moveTo(resolvedIndex + 1);
            return;
        }
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.moveTo(resolvedIndex - 1);
            return;
        }
        if (event.key === 'Home') {
            event.preventDefault();
            this.moveTo(0);
            return;
        }
        if (event.key === 'End') {
            event.preventDefault();
            this.moveTo(this.visibleNodes().length - 1);
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.activate(item.node, index);
            return;
        }
        if (event.key.length === 1 &&
            !event.altKey &&
            !event.ctrlKey &&
            !event.metaKey) {
            const now = Date.now();
            const character = event.key.toLocaleLowerCase();
            this.typeahead =
                now - this.typeaheadAt > 500 ? character : this.typeahead + character;
            this.typeaheadAt = now;
            const visible = this.visibleNodes();
            const matches = (prefix) => visible.filter((candidate) => candidate.node.label.toLocaleLowerCase().startsWith(prefix));
            let match = matches(this.typeahead);
            // Typing the same character repeatedly cycles through matching labels.
            if (!match.length && this.typeahead.length > 1) {
                this.typeahead = character;
                match = matches(this.typeahead);
            }
            if (match.length) {
                const matchIndexes = match.map((candidate) => candidate.index);
                const next = matchIndexes.find((candidateIndex) => candidateIndex > resolvedIndex) ?? matchIndexes[0];
                event.preventDefault();
                this.moveTo(next);
            }
        }
    }
    setActiveIndex(index, focus = true) {
        const count = this.visibleNodes().length;
        const next = count ? Math.max(0, Math.min(index, count - 1)) : 0;
        this.activeIndex.set(next);
        this.rememberCurrentVisibleState(next);
        if (focus)
            this.focusNode(this.visibleNodes()[next]?.node.id);
    }
    focusItem(event, index) {
        if (event.target !== event.currentTarget)
            return;
        this.setActiveIndex(index, false);
    }
    moveTo(index) {
        this.setActiveIndex(index);
    }
    rememberCurrentVisibleState(activeIndex) {
        this.previousVisibleIds = this.visibleNodes().map((item) => item.node.id);
        this.previousActiveIndex = activeIndex;
    }
    isDescendant(parent, nodeId) {
        return !!parent.children?.some((child) => child.id === nodeId || this.isDescendant(child, nodeId));
    }
    focusNode(nodeId) {
        if (!nodeId)
            return;
        const request = ++this.focusRequest;
        if (this.focusTimer !== null) {
            clearTimeout(this.focusTimer);
            this.focusTimer = null;
        }
        const focus = () => {
            const tree = this.treeElement()?.nativeElement;
            const element = tree?.ownerDocument.getElementById(this.itemDomId(nodeId));
            return tree && element && tree.contains(element) ? element : undefined;
        };
        // Existing items can be focused synchronously, which keeps keyboard and
        // toggle interactions stable even before Angular renders a new subtree.
        const element = focus();
        if (element) {
            element.focus();
            return;
        }
        // A target can be newly revealed by an input update. Retry after Angular
        // renders the new subtree in that case.
        afterNextRender(() => {
            if (request !== this.focusRequest)
                return;
            const element = focus();
            if (element)
                element.focus();
            else {
                this.focusTimer = setTimeout(() => {
                    this.focusTimer = null;
                    if (request === this.focusRequest)
                        focus()?.focus();
                }, 0);
            }
        }, { injector: this.injector });
    }
    itemDomId(nodeId) {
        return `${this.treeId}-node-${encodeURIComponent(nodeId)}`;
    }
    ngOnDestroy() {
        this.focusRequest++;
        if (this.focusTimer !== null)
            clearTimeout(this.focusTimer);
        this.focusTimer = null;
    }
    itemElements() {
        return this.treeElement()
            ? Array.from(this.treeElement().nativeElement.querySelectorAll('[role="treeitem"]'))
            : [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TreeViewComponent, isStandalone: true, selector: "orc-tree-view", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, collapseLabel: { classPropertyName: "collapseLabel", publicName: "collapseLabel", isSignal: true, isRequired: false, transformFunction: null }, expandLabel: { classPropertyName: "expandLabel", publicName: "expandLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { nodeSelect: "nodeSelect" }, viewQueries: [{ propertyName: "treeElement", first: true, predicate: ["tree"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"orc-tree\"\n  #tree\n  role=\"tree\"\n  [attr.id]=\"treeId\"\n  [attr.aria-label]=\"label() || 'Tree'\"\n>\n  <ng-template #renderNodes let-list let-level=\"level\">\n    @for (node of list; track node.id) {\n      @if (visibleItem(node); as item) {\n        <div\n          #treeItem\n          class=\"orc-tree__item\"\n          role=\"treeitem\"\n          [attr.id]=\"itemId(item.node)\"\n          [tabindex]=\"normalizedActiveIndex() === item.index ? 0 : -1\"\n          [style.--orc-tree-level]=\"level\"\n          [attr.aria-level]=\"level\"\n          [attr.aria-setsize]=\"item.setSize\"\n          [attr.aria-posinset]=\"item.position + 1\"\n          [attr.aria-expanded]=\"\n            item.expandable ? expanded().has(item.node.id) : null\n          \"\n          [attr.aria-disabled]=\"item.node.disabled ? 'true' : null\"\n          [attr.aria-labelledby]=\"labelId(item.node)\"\n          (focus)=\"focusItem($event, item.index)\"\n          (keydown)=\"keydown($event, item, item.index)\"\n          (click)=\"activate(item.node, item.index, $event)\"\n        >\n          <div class=\"orc-tree__row\">\n            @if (item.expandable) {\n              <button\n                type=\"button\"\n                class=\"orc-tree__toggle\"\n                tabindex=\"-1\"\n                [disabled]=\"item.node.disabled\"\n                [attr.aria-controls]=\"\n                  expanded().has(item.node.id) ? groupId(item.node) : null\n                \"\n                [attr.aria-label]=\"\n                  (expanded().has(item.node.id)\n                    ? collapseLabel()\n                    : expandLabel()) ||\n                  (expanded().has(item.node.id) ? 'Collapse ' : 'Expand ') +\n                    item.node.label\n                \"\n                (click)=\"toggle(item.node); $event.stopPropagation()\"\n              >\n                {{ expanded().has(item.node.id) ? \"\u2212\" : \"+\" }}\n              </button>\n            } @else {\n              <span class=\"orc-tree__spacer\" aria-hidden=\"true\"></span>\n            }\n            <span class=\"orc-tree__label\" [attr.id]=\"labelId(item.node)\">{{\n              item.node.label\n            }}</span>\n          </div>\n          @if (item.expandable && expanded().has(item.node.id)) {\n            <div\n              class=\"orc-tree__group\"\n              role=\"group\"\n              [attr.id]=\"groupId(item.node)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  renderNodes;\n                  context: { $implicit: item.node.children, level: level + 1 }\n                \"\n              ></ng-container>\n            </div>\n          }\n        </div>\n      }\n    }\n  </ng-template>\n  <ng-container\n    *ngTemplateOutlet=\"renderNodes; context: { $implicit: nodes(), level: 1 }\"\n  ></ng-container>\n</div>\n", styles: [".orc-tree{display:grid;padding:var(--space-2);background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-tree__item{display:block;border-radius:var(--radius-sm);cursor:pointer}.orc-tree__row{display:flex;align-items:center;gap:var(--space-2);min-height:2.25rem;padding-inline-start:calc((var(--orc-tree-level) - 1) * var(--space-5));padding-inline-end:var(--space-2);border-radius:var(--radius-sm)}.orc-tree__row:hover{background:var(--bg-muted)}.orc-tree__item:focus-visible>.orc-tree__row{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-tree__item[aria-disabled=true]{opacity:.5;cursor:not-allowed}.orc-tree__toggle{width:1.5rem;height:1.5rem;border:0;border-radius:var(--radius-sm);background:var(--bg-muted);color:var(--text-primary);cursor:pointer}.orc-tree__spacer{width:1.5rem}.orc-tree__group{display:block}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tree-view', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-tree\"\n  #tree\n  role=\"tree\"\n  [attr.id]=\"treeId\"\n  [attr.aria-label]=\"label() || 'Tree'\"\n>\n  <ng-template #renderNodes let-list let-level=\"level\">\n    @for (node of list; track node.id) {\n      @if (visibleItem(node); as item) {\n        <div\n          #treeItem\n          class=\"orc-tree__item\"\n          role=\"treeitem\"\n          [attr.id]=\"itemId(item.node)\"\n          [tabindex]=\"normalizedActiveIndex() === item.index ? 0 : -1\"\n          [style.--orc-tree-level]=\"level\"\n          [attr.aria-level]=\"level\"\n          [attr.aria-setsize]=\"item.setSize\"\n          [attr.aria-posinset]=\"item.position + 1\"\n          [attr.aria-expanded]=\"\n            item.expandable ? expanded().has(item.node.id) : null\n          \"\n          [attr.aria-disabled]=\"item.node.disabled ? 'true' : null\"\n          [attr.aria-labelledby]=\"labelId(item.node)\"\n          (focus)=\"focusItem($event, item.index)\"\n          (keydown)=\"keydown($event, item, item.index)\"\n          (click)=\"activate(item.node, item.index, $event)\"\n        >\n          <div class=\"orc-tree__row\">\n            @if (item.expandable) {\n              <button\n                type=\"button\"\n                class=\"orc-tree__toggle\"\n                tabindex=\"-1\"\n                [disabled]=\"item.node.disabled\"\n                [attr.aria-controls]=\"\n                  expanded().has(item.node.id) ? groupId(item.node) : null\n                \"\n                [attr.aria-label]=\"\n                  (expanded().has(item.node.id)\n                    ? collapseLabel()\n                    : expandLabel()) ||\n                  (expanded().has(item.node.id) ? 'Collapse ' : 'Expand ') +\n                    item.node.label\n                \"\n                (click)=\"toggle(item.node); $event.stopPropagation()\"\n              >\n                {{ expanded().has(item.node.id) ? \"\u2212\" : \"+\" }}\n              </button>\n            } @else {\n              <span class=\"orc-tree__spacer\" aria-hidden=\"true\"></span>\n            }\n            <span class=\"orc-tree__label\" [attr.id]=\"labelId(item.node)\">{{\n              item.node.label\n            }}</span>\n          </div>\n          @if (item.expandable && expanded().has(item.node.id)) {\n            <div\n              class=\"orc-tree__group\"\n              role=\"group\"\n              [attr.id]=\"groupId(item.node)\"\n            >\n              <ng-container\n                *ngTemplateOutlet=\"\n                  renderNodes;\n                  context: { $implicit: item.node.children, level: level + 1 }\n                \"\n              ></ng-container>\n            </div>\n          }\n        </div>\n      }\n    }\n  </ng-template>\n  <ng-container\n    *ngTemplateOutlet=\"renderNodes; context: { $implicit: nodes(), level: 1 }\"\n  ></ng-container>\n</div>\n", styles: [".orc-tree{display:grid;padding:var(--space-2);background:var(--bg-app);color:var(--text-primary);border:1px solid var(--border-default);border-radius:var(--radius-md)}.orc-tree__item{display:block;border-radius:var(--radius-sm);cursor:pointer}.orc-tree__row{display:flex;align-items:center;gap:var(--space-2);min-height:2.25rem;padding-inline-start:calc((var(--orc-tree-level) - 1) * var(--space-5));padding-inline-end:var(--space-2);border-radius:var(--radius-sm)}.orc-tree__row:hover{background:var(--bg-muted)}.orc-tree__item:focus-visible>.orc-tree__row{outline:2px solid var(--orc-color-azul-eletrico);outline-offset:-2px}.orc-tree__item[aria-disabled=true]{opacity:.5;cursor:not-allowed}.orc-tree__toggle{width:1.5rem;height:1.5rem;border:0;border-radius:var(--radius-sm);background:var(--bg-muted);color:var(--text-primary);cursor:pointer}.orc-tree__spacer{width:1.5rem}.orc-tree__group{display:block}\n"] }]
        }], ctorParameters: () => [], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], collapseLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapseLabel", required: false }] }], expandLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandLabel", required: false }] }], nodeSelect: [{ type: i0.Output, args: ["nodeSelect"] }], treeElement: [{ type: i0.ViewChild, args: ['tree', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { TreeViewComponent };
//# sourceMappingURL=ciag-orchestra-tree-view.mjs.map
