export * from '@ciag/orchestra/split-button';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-splitbutton.mjs.map
