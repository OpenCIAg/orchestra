export * from '@ciag/orchestra/overlay-badge';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-overlaybadge.mjs.map
