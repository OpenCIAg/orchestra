import * as i0 from '@angular/core';
import { inject, viewChild, input, booleanAttribute, numberAttribute, model, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT, CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

let nextSliderUniqueId = 0;
class SliderComponent {
    document = inject(DOCUMENT);
    activeWindow = null;
    uniqueId = `orc-slider-${++nextSliderUniqueId}`;
    // ── Element References ────────────────────────────────────
    trackRef = viewChild('trackElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trackRef" }] : /* istanbul ignore next */ []));
    startThumbRef = viewChild('startThumb', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "startThumbRef" }] : /* istanbul ignore next */ []));
    endThumbRef = viewChild('endThumb', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "endThumbRef" }] : /* istanbul ignore next */ []));
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    range = input(false, { ...(ngDevMode ? { debugName: "range" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    animate = input(false, { ...(ngDevMode ? { debugName: "animate" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    min = input(0, { ...(ngDevMode ? { debugName: "min" } : /* istanbul ignore next */ {}), transform: (v) => numberAttribute(v, 0) });
    max = input(100, { ...(ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {}), transform: (v) => numberAttribute(v, 100) });
    step = input(1, { ...(ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {}), transform: (v) => numberAttribute(v, 1) });
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showTicks = input(false, { ...(ngDevMode ? { debugName: "showTicks" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showLabels = input(false, { ...(ngDevMode ? { debugName: "showLabels" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    marks = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "marks" }] : /* istanbul ignore next */ []));
    showTooltip = input('auto', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTooltip" }] : /* istanbul ignore next */ []));
    tooltip = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    tooltipPosition = input('top', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : /* istanbul ignore next */ []));
    valueFormatter = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valueFormatter" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelMin = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelMin" }] : /* istanbul ignore next */ []));
    ariaLabelMax = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelMax" }] : /* istanbul ignore next */ []));
    // ── Two-Way Model ─────────────────────────────────────────
    value = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // ── Outputs (Signals API) ─────────────────────────────────
    sliderChange = output();
    sliderInput = output();
    onChange = output();
    onSlideEnd = output();
    // ── Estado Interno ────────────────────────────────────────
    activeThumb = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeThumb" }] : /* istanbul ignore next */ []));
    isDragging = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDragging" }] : /* istanbul ignore next */ []));
    hoveredThumb = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hoveredThumb" }] : /* istanbul ignore next */ []));
    focusedThumb = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedThumb" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    activePointerId = null;
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    helperId = computed(() => `${this.effectiveId()}-helper`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    minVal = computed(() => this.min(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minVal" }] : /* istanbul ignore next */ []));
    maxVal = computed(() => {
        const min = this.minVal();
        const max = this.max();
        return max > min ? max : min + 1;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxVal" }] : /* istanbul ignore next */ []));
    stepVal = computed(() => {
        const s = this.step();
        return s > 0 ? s : 1;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stepVal" }] : /* istanbul ignore next */ []));
    normalizedValues = computed(() => {
        const raw = this.value();
        const min = this.minVal();
        const max = this.maxVal();
        const isRange = this.range();
        if (isRange) {
            let start;
            let end;
            if (Array.isArray(raw)) {
                const rawStart = Number(raw[0]);
                const rawEnd = Number(raw[1]);
                start = Number.isFinite(rawStart) ? rawStart : min;
                end = Number.isFinite(rawEnd) ? rawEnd : max;
            }
            else {
                start = min;
                end = Number(raw) || max;
            }
            start = this.clamp(start, min, max);
            end = this.clamp(end, min, max);
            if (start > end) {
                start = end;
            }
            return [start, end];
        }
        else {
            let val = typeof raw === 'number' ? raw : Array.isArray(raw) ? raw[0] : min;
            const numeric = Number(val);
            val = this.clamp(Number.isFinite(numeric) ? numeric : min, min, max);
            return [min, val];
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedValues" }] : /* istanbul ignore next */ []));
    currentStartValue = computed(() => this.normalizedValues()[0], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentStartValue" }] : /* istanbul ignore next */ []));
    currentEndValue = computed(() => this.normalizedValues()[1], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentEndValue" }] : /* istanbul ignore next */ []));
    startPercent = computed(() => {
        const min = this.minVal();
        const max = this.maxVal();
        const val = this.currentStartValue();
        return this.calculatePercent(val, min, max);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "startPercent" }] : /* istanbul ignore next */ []));
    endPercent = computed(() => {
        const min = this.minVal();
        const max = this.maxVal();
        const val = this.currentEndValue();
        return this.calculatePercent(val, min, max);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "endPercent" }] : /* istanbul ignore next */ []));
    fillLeftPercent = computed(() => {
        return this.range() ? this.startPercent() : 0;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fillLeftPercent" }] : /* istanbul ignore next */ []));
    fillWidthPercent = computed(() => {
        if (this.range()) {
            return Math.max(0, this.endPercent() - this.startPercent());
        }
        return this.endPercent();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fillWidthPercent" }] : /* istanbul ignore next */ []));
    formattedStartValue = computed(() => {
        const val = this.currentStartValue();
        const fmt = this.valueFormatter();
        return fmt ? fmt(val) : String(val);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formattedStartValue" }] : /* istanbul ignore next */ []));
    formattedEndValue = computed(() => {
        const val = this.currentEndValue();
        const fmt = this.valueFormatter();
        return fmt ? fmt(val) : String(val);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formattedEndValue" }] : /* istanbul ignore next */ []));
    parsedMarks = computed(() => {
        const marksData = this.marks();
        const min = this.minVal();
        const max = this.maxVal();
        if (!marksData) {
            if (this.showLabels()) {
                return [
                    { value: min, percent: 0, label: String(min) },
                    { value: max, percent: 100, label: String(max) },
                ];
            }
            return [];
        }
        if (Array.isArray(marksData)) {
            return marksData.map((item) => {
                const val = typeof item === 'number' ? item : item.value;
                const lbl = typeof item === 'number' ? String(item) : (item.label ?? String(val));
                return {
                    value: val,
                    percent: this.calculatePercent(val, min, max),
                    label: lbl,
                };
            });
        }
        if (typeof marksData === 'object') {
            return Object.entries(marksData).map(([valStr, label]) => {
                const val = Number(valStr);
                return {
                    value: val,
                    percent: this.calculatePercent(val, min, max),
                    label: String(label),
                };
            });
        }
        return [];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "parsedMarks" }] : /* istanbul ignore next */ []));
    ticks = computed(() => {
        if (!this.showTicks())
            return [];
        const min = this.minVal();
        const max = this.maxVal();
        const step = this.stepVal();
        const count = Math.floor((max - min) / step);
        if (count > 100)
            return []; // Evita renderizar milhares de ticks se step for muito pequeno
        const items = [];
        for (let i = 0; i <= count; i++) {
            const val = min + i * step;
            items.push(this.calculatePercent(val, min, max));
        }
        return items;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ticks" }] : /* istanbul ignore next */ []));
    // ── ControlValueAccessor ──────────────────────────────────
    onModelChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        if (value === null || value === undefined) {
            this.value.set(this.range() ? [this.minVal(), this.maxVal()] : this.minVal());
        }
        else {
            this.value.set(value);
        }
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers de Ponteiro / Arraste ────────────────────────
    onTrackPointerDown(event) {
        if (this.effectiveDisabled())
            return;
        const track = this.trackRef()?.nativeElement;
        if (!track)
            return;
        const view = this.document.defaultView;
        if (!view)
            return;
        const rect = track.getBoundingClientRect();
        const clickPercent = this.pointerPercent(event, rect);
        const clickedVal = this.percentToValue(clickPercent);
        let targetThumb = 'end';
        if (this.range()) {
            const startDist = Math.abs(clickedVal - this.currentStartValue());
            const endDist = Math.abs(clickedVal - this.currentEndValue());
            if (startDist < endDist) {
                targetThumb = 'start';
            }
            else if (startDist === endDist) {
                targetThumb = clickedVal < this.currentStartValue() ? 'start' : 'end';
            }
            else {
                targetThumb = 'end';
            }
        }
        this.activeThumb.set(targetThumb);
        this.isDragging.set(true);
        this.activePointerId = event.pointerId;
        this.updateValueByTarget(targetThumb, clickedVal, event);
        // Adiciona ouvintes globais para continuidade fluida do arraste
        this.activeWindow = view;
        view.addEventListener('pointermove', this.onGlobalPointerMove);
        view.addEventListener('pointerup', this.onGlobalPointerUp);
        view.addEventListener('pointercancel', this.onGlobalPointerUp);
        // Foca o thumb correspondente para acessibilidade
        if (targetThumb === 'start') {
            this.startThumbRef()?.nativeElement.focus();
        }
        else {
            this.endThumbRef()?.nativeElement.focus();
        }
        event.preventDefault();
    }
    onGlobalPointerMove = (event) => {
        if (!this.isDragging() ||
            this.effectiveDisabled() ||
            event.pointerId !== this.activePointerId)
            return;
        const track = this.trackRef()?.nativeElement;
        if (!track)
            return;
        const rect = track.getBoundingClientRect();
        const percent = this.pointerPercent(event, rect);
        const currentVal = this.percentToValue(percent);
        const thumb = this.activeThumb();
        if (thumb) {
            this.updateValueByTarget(thumb, currentVal, event);
        }
    };
    onGlobalPointerUp = (event) => {
        if (!this.isDragging() || event.pointerId !== this.activePointerId)
            return;
        this.isDragging.set(false);
        this.activeThumb.set(null);
        this.activePointerId = null;
        this.removeGlobalListeners();
        this.onTouched();
        this.sliderChange.emit(this.value());
        this.onSlideEnd.emit({ value: this.value() });
    };
    // ── Navegação por Teclado WCAG ────────────────────────────
    onKeyDown(event, thumb) {
        if (this.effectiveDisabled())
            return;
        const step = this.stepVal();
        const pageJump = Math.max(step * 10, (this.maxVal() - this.minVal()) / 10);
        const currentVal = thumb === 'start' ? this.currentStartValue() : this.currentEndValue();
        let nextVal = currentVal;
        let handled = false;
        switch (event.key) {
            case 'ArrowRight':
            case 'ArrowUp':
                nextVal = currentVal + step;
                handled = true;
                break;
            case 'ArrowLeft':
            case 'ArrowDown':
                nextVal = currentVal - step;
                handled = true;
                break;
            case 'PageUp':
                nextVal = currentVal + pageJump;
                handled = true;
                break;
            case 'PageDown':
                nextVal = currentVal - pageJump;
                handled = true;
                break;
            case 'Home':
                nextVal = this.minVal();
                handled = true;
                break;
            case 'End':
                nextVal = this.maxVal();
                handled = true;
                break;
        }
        if (handled) {
            event.preventDefault();
            this.updateValueByTarget(thumb, nextVal, event);
            this.sliderChange.emit(this.value());
        }
    }
    onThumbFocus(thumb) {
        this.focusedThumb.set(thumb);
    }
    onThumbBlur() {
        this.focusedThumb.set(null);
        this.onTouched();
    }
    onThumbMouseEnter(thumb) {
        this.hoveredThumb.set(thumb);
    }
    onThumbMouseLeave() {
        this.hoveredThumb.set(null);
    }
    // ── Utilitários de Cálculo e Atualização ───────────────────
    updateValueByTarget(thumb, rawVal, originalEvent) {
        const min = this.minVal();
        const max = this.maxVal();
        const steppedVal = this.snapToStep(this.clamp(rawVal, min, max));
        if (this.range()) {
            let [start, end] = this.normalizedValues();
            if (thumb === 'start') {
                start = Math.min(steppedVal, end);
            }
            else {
                end = Math.max(steppedVal, start);
            }
            const nextRange = [start, end];
            this.value.set(nextRange);
            this.onModelChange(nextRange);
            this.sliderInput.emit(nextRange);
            this.onChange.emit({ originalEvent, value: nextRange });
        }
        else {
            this.value.set(steppedVal);
            this.onModelChange(steppedVal);
            this.sliderInput.emit(steppedVal);
            this.onChange.emit({ originalEvent, value: steppedVal });
        }
    }
    snapToStep(val) {
        const min = this.minVal();
        const step = this.stepVal();
        const count = Math.round((val - min) / step);
        const result = min + count * step;
        // Arredonda para evitar problemas de ponto flutuante (ex: 0.1 + 0.2 = 0.30000000000000004)
        const stepDecimals = (step.toString().split('.')[1] || '').length;
        return Number(result.toFixed(stepDecimals));
    }
    calculatePercent(val, min, max) {
        if (max <= min)
            return 0;
        return this.clamp(((val - min) / (max - min)) * 100, 0, 100);
    }
    percentToValue(percent) {
        const min = this.minVal();
        const max = this.maxVal();
        return min + percent * (max - min);
    }
    pointerPercent(event, rect) {
        if (this.orientation() === 'vertical')
            return this.clamp(1 - (event.clientY - rect.top) / rect.height, 0, 1);
        return this.clamp((event.clientX - rect.left) / rect.width, 0, 1);
    }
    clamp(val, min, max) {
        return Math.max(min, Math.min(max, val));
    }
    shouldShowTooltip(thumb) {
        const mode = this.showTooltip();
        if (mode === 'never')
            return false;
        if (mode === 'always')
            return true;
        // auto: exibe durante arraste, hover ou foco
        const isThisThumbActive = this.activeThumb() === thumb && this.isDragging();
        const isThisThumbHovered = this.hoveredThumb() === thumb;
        const isThisThumbFocused = this.focusedThumb() === thumb;
        return isThisThumbActive || isThisThumbHovered || isThisThumbFocused;
    }
    ngOnDestroy() {
        this.removeGlobalListeners();
    }
    removeGlobalListeners() {
        const view = this.activeWindow ?? this.document.defaultView;
        if (!view)
            return;
        view.removeEventListener('pointermove', this.onGlobalPointerMove);
        view.removeEventListener('pointerup', this.onGlobalPointerUp);
        view.removeEventListener('pointercancel', this.onGlobalPointerUp);
        this.activeWindow = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: SliderComponent, isStandalone: true, selector: "orc-slider", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, range: { classPropertyName: "range", publicName: "range", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, animate: { classPropertyName: "animate", publicName: "animate", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, showTicks: { classPropertyName: "showTicks", publicName: "showTicks", isSignal: true, isRequired: false, transformFunction: null }, showLabels: { classPropertyName: "showLabels", publicName: "showLabels", isSignal: true, isRequired: false, transformFunction: null }, marks: { classPropertyName: "marks", publicName: "marks", isSignal: true, isRequired: false, transformFunction: null }, showTooltip: { classPropertyName: "showTooltip", publicName: "showTooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, valueFormatter: { classPropertyName: "valueFormatter", publicName: "valueFormatter", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelMin: { classPropertyName: "ariaLabelMin", publicName: "ariaLabelMin", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelMax: { classPropertyName: "ariaLabelMax", publicName: "ariaLabelMax", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", sliderChange: "sliderChange", sliderInput: "sliderInput", onChange: "onChange", onSlideEnd: "onSlideEnd" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SliderComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "trackRef", first: true, predicate: ["trackElement"], descendants: true, isSignal: true }, { propertyName: "startThumbRef", first: true, predicate: ["startThumb"], descendants: true, isSignal: true }, { propertyName: "endThumbRef", first: true, predicate: ["endThumb"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-slider p-component orc-slider-wrapper\"\n  [class]=\"'p-slider p-component orc-slider-wrapper ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-slider-wrapper--vertical]=\"orientation() === 'vertical'\"\n  [class.orc-slider-wrapper--disabled]=\"effectiveDisabled()\"\n  [class.orc-slider-wrapper--sm]=\"size() === 'sm'\"\n  [class.orc-slider-wrapper--md]=\"size() === 'md'\"\n    [class.orc-slider-wrapper--lg]=\"size() === 'lg'\"\n  [attr.data-pc-name]=\"'slider'\"\n>\n  <!-- R\u00F3tulo Superior (Label) -->\n  @if (label()) {\n    <div class=\"orc-slider-header\">\n      <label [attr.for]=\"effectiveId()\" class=\"orc-slider-label\">\n        {{ label() }}\n      </label>\n      <span class=\"orc-slider-value-display\">\n        @if (range()) {\n          {{ formattedStartValue() }} \u2013 {{ formattedEndValue() }}\n        } @else {\n          {{ formattedEndValue() }}\n        }\n      </span>\n    </div>\n  }\n\n  <!-- \u00C1rea Interativa do Slider (Track + Thumbs) -->\n  <div\n    #trackElement\n    class=\"p-slider-track orc-slider-track-container\"\n    [class.p-slider-vertical]=\"orientation() === 'vertical'\"\n    (pointerdown)=\"onTrackPointerDown($event)\"\n  >\n    <!-- Barra de Fundo (Track Inativo) -->\n    <div class=\"orc-slider-track\">\n      <!-- Barra Preenchida Ativa (Progress Fill) -->\n      <div\n        class=\"p-slider-range orc-slider-fill\"\n        [style.left.%]=\"orientation() === 'horizontal' ? fillLeftPercent() : null\"\n        [style.width.%]=\"orientation() === 'horizontal' ? fillWidthPercent() : null\"\n        [style.bottom.%]=\"orientation() === 'vertical' ? fillLeftPercent() : null\"\n        [style.height.%]=\"orientation() === 'vertical' ? fillWidthPercent() : null\"\n      ></div>\n\n      <!-- Marca\u00E7\u00F5es de Escala (Ticks) -->\n      @if (showTicks()) {\n        <div class=\"orc-slider-ticks-container\">\n          @for (tickPercent of ticks(); track $index) {\n            <span\n              class=\"orc-slider-tick\"\n              [style.left.%]=\"tickPercent\"\n            ></span>\n          }\n        </div>\n      }\n    </div>\n\n    <!-- Thumb Inicial (Apenas no Modo Range) -->\n    @if (range()) {\n      <div\n        #startThumb\n        class=\"p-slider-handle orc-slider-thumb orc-slider-thumb--start\"\n        [class.orc-slider-thumb--active]=\"activeThumb() === 'start' && isDragging()\"\n        [class.orc-slider-thumb--focused]=\"focusedThumb() === 'start'\"\n        [style.left.%]=\"orientation() === 'horizontal' ? startPercent() : null\"\n        [style.bottom.%]=\"orientation() === 'vertical' ? startPercent() : null\"\n        role=\"slider\"\n        [attr.tabindex]=\"effectiveDisabled() ? -1 : tabindex()\"\n        [attr.autofocus]=\"autofocus() ? '' : null\"\n        [attr.aria-valuenow]=\"currentStartValue()\"\n        [attr.aria-valuemin]=\"minVal()\"\n        [attr.aria-valuemax]=\"currentEndValue()\"\n        [attr.aria-valuetext]=\"formattedStartValue()\"\n        [attr.aria-label]=\"ariaLabelMin()\"\n        [attr.aria-orientation]=\"orientation()\"\n        [attr.aria-labelledby]=\"ariaLabelledBy()\"\n        [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n        (keydown)=\"onKeyDown($event, 'start')\"\n        (focus)=\"onThumbFocus('start')\"\n        (blur)=\"onThumbBlur()\"\n        (mouseenter)=\"onThumbMouseEnter('start')\"\n        (mouseleave)=\"onThumbMouseLeave()\"\n      >\n        <!-- Tooltip Flutuante -->\n        @if (shouldShowTooltip('start')) {\n          <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n            {{ formattedStartValue() }}\n          </div>\n        }\n      </div>\n    }\n\n    <!-- Thumb Principal / Final -->\n    <div\n      #endThumb\n      [id]=\"effectiveId()\"\n      class=\"p-slider-handle orc-slider-thumb orc-slider-thumb--end\"\n      [class.orc-slider-thumb--active]=\"activeThumb() === 'end' && isDragging()\"\n      [class.orc-slider-thumb--focused]=\"focusedThumb() === 'end'\"\n      [style.left.%]=\"orientation() === 'horizontal' ? endPercent() : null\"\n      [style.bottom.%]=\"orientation() === 'vertical' ? endPercent() : null\"\n      role=\"slider\"\n      [attr.tabindex]=\"effectiveDisabled() ? -1 : tabindex()\"\n      [attr.autofocus]=\"autofocus() ? '' : null\"\n      [attr.aria-valuenow]=\"currentEndValue()\"\n      [attr.aria-valuemin]=\"range() ? currentStartValue() : minVal()\"\n      [attr.aria-valuemax]=\"maxVal()\"\n      [attr.aria-valuetext]=\"formattedEndValue()\"\n      [attr.aria-label]=\"range() ? ariaLabelMax() : (ariaLabel() || label() || null)\"\n      [attr.aria-orientation]=\"orientation()\"\n      [attr.aria-labelledby]=\"ariaLabelledBy()\"\n      [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n      [attr.aria-describedby]=\"helperText() ? helperId() : null\"\n      (keydown)=\"onKeyDown($event, 'end')\"\n      (focus)=\"onThumbFocus('end')\"\n      (blur)=\"onThumbBlur()\"\n      (mouseenter)=\"onThumbMouseEnter('end')\"\n      (mouseleave)=\"onThumbMouseLeave()\"\n    >\n      <!-- Tooltip Flutuante -->\n      @if (shouldShowTooltip('end')) {\n        <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n          {{ formattedEndValue() }}\n        </div>\n      }\n    </div>\n  </div>\n\n  <!-- R\u00F3tulos e Marca\u00E7\u00F5es Inferiores (Marks & Labels) -->\n  @if (parsedMarks().length > 0) {\n    <div class=\"orc-slider-marks\">\n      @for (mark of parsedMarks(); track mark.value) {\n        <span\n          class=\"orc-slider-mark-label\"\n          [style.left.%]=\"mark.percent\"\n        >\n          {{ mark.label }}\n        </span>\n      }\n    </div>\n  }\n\n  <!-- Texto de Ajuda (Helper Text) -->\n  @if (helperText()) {\n    <div [id]=\"helperId()\" class=\"orc-slider-helper\">\n      {{ helperText() }}\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-slider-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-slider-wrapper--sm{--slider-track-height: 10px;--slider-thumb-size: 14px;--slider-tick-size: 3px}.orc-slider-wrapper--md{--slider-track-height: 16px;--slider-thumb-size: 16px;--slider-tick-size: 4px}.orc-slider-wrapper--lg{--slider-track-height: 20px;--slider-thumb-size: 20px;--slider-tick-size: 5px}.orc-slider-wrapper--disabled{opacity:.5;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-track-container{pointer-events:none;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-thumb{cursor:not-allowed;border-color:var(--orc-border-default, var(--orc-border, #d9d9d9));box-shadow:none}.orc-slider-wrapper--disabled .orc-slider-fill{background:var(--orc-text-muted, var(--text-tertiary, #999999))}.orc-slider-header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem)}.orc-slider-label{font-size:.875rem;font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414));cursor:pointer}.orc-slider-value-display{font-size:.8125rem;font-weight:600;color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-variant-numeric:tabular-nums}.orc-slider-track-container{position:relative;width:100%;height:var(--slider-track-height);display:flex;align-items:center;cursor:pointer;touch-action:none;-webkit-user-select:none;user-select:none;padding:8px 0;box-sizing:content-box}.orc-slider-wrapper--vertical .orc-slider-track-container{align-self:flex-start;width:var(--slider-track-height);height:180px;padding:0 8px}.orc-slider-wrapper--vertical .orc-slider-track{width:var(--slider-track-height);height:100%}.orc-slider-wrapper--vertical .orc-slider-fill{top:auto;left:0;width:100%}.orc-slider-wrapper--vertical .orc-slider-thumb,.orc-slider-wrapper--vertical .orc-slider-tick{top:auto;left:50%}.orc-slider-track{position:relative;width:100%;height:var(--slider-track-height);background:var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-full, 200px);overflow:visible;transition:background .15s ease}.orc-slider-fill{position:absolute;top:0;height:100%;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-full, 200px);transition:background .15s ease}.orc-slider-ticks-container{position:absolute;inset:0;pointer-events:none}.orc-slider-tick{position:absolute;top:50%;width:var(--slider-tick-size);height:var(--slider-tick-size);background:var(--orc-on-interactive, rgba(255, 255, 255, .7));border-radius:50%;transform:translate(-50%,-50%)}.orc-slider-thumb{position:absolute;top:50%;width:var(--slider-thumb-size);height:var(--slider-thumb-size);background:var(--orc-surface-raised, var(--fill-modal, #ffffff));border:1px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-full, 200px);box-shadow:var(--shadow-sm);transform:translate(-50%,-50%);cursor:grab;outline:none;box-sizing:border-box;z-index:2;transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease}.orc-slider-thumb:hover{box-shadow:0 0 0 4px var(--orc-interactive-shadow),var(--shadow-sm);transform:translate(-50%,-50%) scale(1.1)}.orc-slider-thumb--focused,.orc-slider-thumb:focus-visible{box-shadow:0 0 0 4px var(--orc-interactive-shadow),var(--shadow-sm);border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));transform:translate(-50%,-50%) scale(1.15);z-index:4}.orc-slider-thumb--active{cursor:grabbing;box-shadow:0 0 0 6px var(--orc-interactive-shadow),var(--shadow-md);transform:translate(-50%,-50%) scale(1.2);z-index:5}.orc-slider-tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--bg-inverse, var(--orc-font-main, #141414));color:var(--text-inverse, #ffffff);font-size:.6875rem;font-weight:600;line-height:1;padding:4px 7px;border-radius:var(--radius-sm, 4px);white-space:nowrap;pointer-events:none;box-shadow:var(--orc-shadow-overlay, var(--shadow-md));animation:orc-tooltip-fade .15s cubic-bezier(.16,1,.3,1);font-variant-numeric:tabular-nums}.orc-slider-tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border-width:4px 4px 0 4px;border-style:solid;border-color:var(--bg-inverse, var(--orc-font-main, #141414)) transparent transparent transparent}@keyframes orc-tooltip-fade{0%{opacity:0;transform:translate(-50%) translateY(4px)}to{opacity:1;transform:translate(-50%) translateY(0)}}.orc-slider-marks{position:relative;width:100%;height:16px;margin-top:2px}.orc-slider-mark-label{position:absolute;transform:translate(-50%);font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;pointer-events:none;font-variant-numeric:tabular-nums}.orc-slider-helper{font-size:.75rem;color:var(--text-secondary, #666666);margin-top:2px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-slider', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SliderComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-slider p-component orc-slider-wrapper\"\n  [class]=\"'p-slider p-component orc-slider-wrapper ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-slider-wrapper--vertical]=\"orientation() === 'vertical'\"\n  [class.orc-slider-wrapper--disabled]=\"effectiveDisabled()\"\n  [class.orc-slider-wrapper--sm]=\"size() === 'sm'\"\n  [class.orc-slider-wrapper--md]=\"size() === 'md'\"\n    [class.orc-slider-wrapper--lg]=\"size() === 'lg'\"\n  [attr.data-pc-name]=\"'slider'\"\n>\n  <!-- R\u00F3tulo Superior (Label) -->\n  @if (label()) {\n    <div class=\"orc-slider-header\">\n      <label [attr.for]=\"effectiveId()\" class=\"orc-slider-label\">\n        {{ label() }}\n      </label>\n      <span class=\"orc-slider-value-display\">\n        @if (range()) {\n          {{ formattedStartValue() }} \u2013 {{ formattedEndValue() }}\n        } @else {\n          {{ formattedEndValue() }}\n        }\n      </span>\n    </div>\n  }\n\n  <!-- \u00C1rea Interativa do Slider (Track + Thumbs) -->\n  <div\n    #trackElement\n    class=\"p-slider-track orc-slider-track-container\"\n    [class.p-slider-vertical]=\"orientation() === 'vertical'\"\n    (pointerdown)=\"onTrackPointerDown($event)\"\n  >\n    <!-- Barra de Fundo (Track Inativo) -->\n    <div class=\"orc-slider-track\">\n      <!-- Barra Preenchida Ativa (Progress Fill) -->\n      <div\n        class=\"p-slider-range orc-slider-fill\"\n        [style.left.%]=\"orientation() === 'horizontal' ? fillLeftPercent() : null\"\n        [style.width.%]=\"orientation() === 'horizontal' ? fillWidthPercent() : null\"\n        [style.bottom.%]=\"orientation() === 'vertical' ? fillLeftPercent() : null\"\n        [style.height.%]=\"orientation() === 'vertical' ? fillWidthPercent() : null\"\n      ></div>\n\n      <!-- Marca\u00E7\u00F5es de Escala (Ticks) -->\n      @if (showTicks()) {\n        <div class=\"orc-slider-ticks-container\">\n          @for (tickPercent of ticks(); track $index) {\n            <span\n              class=\"orc-slider-tick\"\n              [style.left.%]=\"tickPercent\"\n            ></span>\n          }\n        </div>\n      }\n    </div>\n\n    <!-- Thumb Inicial (Apenas no Modo Range) -->\n    @if (range()) {\n      <div\n        #startThumb\n        class=\"p-slider-handle orc-slider-thumb orc-slider-thumb--start\"\n        [class.orc-slider-thumb--active]=\"activeThumb() === 'start' && isDragging()\"\n        [class.orc-slider-thumb--focused]=\"focusedThumb() === 'start'\"\n        [style.left.%]=\"orientation() === 'horizontal' ? startPercent() : null\"\n        [style.bottom.%]=\"orientation() === 'vertical' ? startPercent() : null\"\n        role=\"slider\"\n        [attr.tabindex]=\"effectiveDisabled() ? -1 : tabindex()\"\n        [attr.autofocus]=\"autofocus() ? '' : null\"\n        [attr.aria-valuenow]=\"currentStartValue()\"\n        [attr.aria-valuemin]=\"minVal()\"\n        [attr.aria-valuemax]=\"currentEndValue()\"\n        [attr.aria-valuetext]=\"formattedStartValue()\"\n        [attr.aria-label]=\"ariaLabelMin()\"\n        [attr.aria-orientation]=\"orientation()\"\n        [attr.aria-labelledby]=\"ariaLabelledBy()\"\n        [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n        (keydown)=\"onKeyDown($event, 'start')\"\n        (focus)=\"onThumbFocus('start')\"\n        (blur)=\"onThumbBlur()\"\n        (mouseenter)=\"onThumbMouseEnter('start')\"\n        (mouseleave)=\"onThumbMouseLeave()\"\n      >\n        <!-- Tooltip Flutuante -->\n        @if (shouldShowTooltip('start')) {\n          <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n            {{ formattedStartValue() }}\n          </div>\n        }\n      </div>\n    }\n\n    <!-- Thumb Principal / Final -->\n    <div\n      #endThumb\n      [id]=\"effectiveId()\"\n      class=\"p-slider-handle orc-slider-thumb orc-slider-thumb--end\"\n      [class.orc-slider-thumb--active]=\"activeThumb() === 'end' && isDragging()\"\n      [class.orc-slider-thumb--focused]=\"focusedThumb() === 'end'\"\n      [style.left.%]=\"orientation() === 'horizontal' ? endPercent() : null\"\n      [style.bottom.%]=\"orientation() === 'vertical' ? endPercent() : null\"\n      role=\"slider\"\n      [attr.tabindex]=\"effectiveDisabled() ? -1 : tabindex()\"\n      [attr.autofocus]=\"autofocus() ? '' : null\"\n      [attr.aria-valuenow]=\"currentEndValue()\"\n      [attr.aria-valuemin]=\"range() ? currentStartValue() : minVal()\"\n      [attr.aria-valuemax]=\"maxVal()\"\n      [attr.aria-valuetext]=\"formattedEndValue()\"\n      [attr.aria-label]=\"range() ? ariaLabelMax() : (ariaLabel() || label() || null)\"\n      [attr.aria-orientation]=\"orientation()\"\n      [attr.aria-labelledby]=\"ariaLabelledBy()\"\n      [attr.aria-disabled]=\"effectiveDisabled() ? 'true' : null\"\n      [attr.aria-describedby]=\"helperText() ? helperId() : null\"\n      (keydown)=\"onKeyDown($event, 'end')\"\n      (focus)=\"onThumbFocus('end')\"\n      (blur)=\"onThumbBlur()\"\n      (mouseenter)=\"onThumbMouseEnter('end')\"\n      (mouseleave)=\"onThumbMouseLeave()\"\n    >\n      <!-- Tooltip Flutuante -->\n      @if (shouldShowTooltip('end')) {\n        <div class=\"orc-slider-tooltip\" role=\"tooltip\">\n          {{ formattedEndValue() }}\n        </div>\n      }\n    </div>\n  </div>\n\n  <!-- R\u00F3tulos e Marca\u00E7\u00F5es Inferiores (Marks & Labels) -->\n  @if (parsedMarks().length > 0) {\n    <div class=\"orc-slider-marks\">\n      @for (mark of parsedMarks(); track mark.value) {\n        <span\n          class=\"orc-slider-mark-label\"\n          [style.left.%]=\"mark.percent\"\n        >\n          {{ mark.label }}\n        </span>\n      }\n    </div>\n  }\n\n  <!-- Texto de Ajuda (Helper Text) -->\n  @if (helperText()) {\n    <div [id]=\"helperId()\" class=\"orc-slider-helper\">\n      {{ helperText() }}\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-slider-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-slider-wrapper--sm{--slider-track-height: 10px;--slider-thumb-size: 14px;--slider-tick-size: 3px}.orc-slider-wrapper--md{--slider-track-height: 16px;--slider-thumb-size: 16px;--slider-tick-size: 4px}.orc-slider-wrapper--lg{--slider-track-height: 20px;--slider-thumb-size: 20px;--slider-tick-size: 5px}.orc-slider-wrapper--disabled{opacity:.5;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-track-container{pointer-events:none;cursor:not-allowed}.orc-slider-wrapper--disabled .orc-slider-thumb{cursor:not-allowed;border-color:var(--orc-border-default, var(--orc-border, #d9d9d9));box-shadow:none}.orc-slider-wrapper--disabled .orc-slider-fill{background:var(--orc-text-muted, var(--text-tertiary, #999999))}.orc-slider-header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem)}.orc-slider-label{font-size:.875rem;font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414));cursor:pointer}.orc-slider-value-display{font-size:.8125rem;font-weight:600;color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-variant-numeric:tabular-nums}.orc-slider-track-container{position:relative;width:100%;height:var(--slider-track-height);display:flex;align-items:center;cursor:pointer;touch-action:none;-webkit-user-select:none;user-select:none;padding:8px 0;box-sizing:content-box}.orc-slider-wrapper--vertical .orc-slider-track-container{align-self:flex-start;width:var(--slider-track-height);height:180px;padding:0 8px}.orc-slider-wrapper--vertical .orc-slider-track{width:var(--slider-track-height);height:100%}.orc-slider-wrapper--vertical .orc-slider-fill{top:auto;left:0;width:100%}.orc-slider-wrapper--vertical .orc-slider-thumb,.orc-slider-wrapper--vertical .orc-slider-tick{top:auto;left:50%}.orc-slider-track{position:relative;width:100%;height:var(--slider-track-height);background:var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-full, 200px);overflow:visible;transition:background .15s ease}.orc-slider-fill{position:absolute;top:0;height:100%;background:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-full, 200px);transition:background .15s ease}.orc-slider-ticks-container{position:absolute;inset:0;pointer-events:none}.orc-slider-tick{position:absolute;top:50%;width:var(--slider-tick-size);height:var(--slider-tick-size);background:var(--orc-on-interactive, rgba(255, 255, 255, .7));border-radius:50%;transform:translate(-50%,-50%)}.orc-slider-thumb{position:absolute;top:50%;width:var(--slider-thumb-size);height:var(--slider-thumb-size);background:var(--orc-surface-raised, var(--fill-modal, #ffffff));border:1px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-full, 200px);box-shadow:var(--shadow-sm);transform:translate(-50%,-50%);cursor:grab;outline:none;box-sizing:border-box;z-index:2;transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease}.orc-slider-thumb:hover{box-shadow:0 0 0 4px var(--orc-interactive-shadow),var(--shadow-sm);transform:translate(-50%,-50%) scale(1.1)}.orc-slider-thumb--focused,.orc-slider-thumb:focus-visible{box-shadow:0 0 0 4px var(--orc-interactive-shadow),var(--shadow-sm);border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));transform:translate(-50%,-50%) scale(1.15);z-index:4}.orc-slider-thumb--active{cursor:grabbing;box-shadow:0 0 0 6px var(--orc-interactive-shadow),var(--shadow-md);transform:translate(-50%,-50%) scale(1.2);z-index:5}.orc-slider-tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--bg-inverse, var(--orc-font-main, #141414));color:var(--text-inverse, #ffffff);font-size:.6875rem;font-weight:600;line-height:1;padding:4px 7px;border-radius:var(--radius-sm, 4px);white-space:nowrap;pointer-events:none;box-shadow:var(--orc-shadow-overlay, var(--shadow-md));animation:orc-tooltip-fade .15s cubic-bezier(.16,1,.3,1);font-variant-numeric:tabular-nums}.orc-slider-tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border-width:4px 4px 0 4px;border-style:solid;border-color:var(--bg-inverse, var(--orc-font-main, #141414)) transparent transparent transparent}@keyframes orc-tooltip-fade{0%{opacity:0;transform:translate(-50%) translateY(4px)}to{opacity:1;transform:translate(-50%) translateY(0)}}.orc-slider-marks{position:relative;width:100%;height:16px;margin-top:2px}.orc-slider-mark-label{position:absolute;transform:translate(-50%);font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;pointer-events:none;font-variant-numeric:tabular-nums}.orc-slider-helper{font-size:.75rem;color:var(--text-secondary, #666666);margin-top:2px}\n"] }]
        }], propDecorators: { trackRef: [{ type: i0.ViewChild, args: ['trackElement', { isSignal: true }] }], startThumbRef: [{ type: i0.ViewChild, args: ['startThumb', { isSignal: true }] }], endThumbRef: [{ type: i0.ViewChild, args: ['endThumb', { isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], range: [{ type: i0.Input, args: [{ isSignal: true, alias: "range", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], animate: [{ type: i0.Input, args: [{ isSignal: true, alias: "animate", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], showTicks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTicks", required: false }] }], showLabels: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLabels", required: false }] }], marks: [{ type: i0.Input, args: [{ isSignal: true, alias: "marks", required: false }] }], showTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTooltip", required: false }] }], tooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], valueFormatter: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueFormatter", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelMin: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelMin", required: false }] }], ariaLabelMax: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelMax", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], sliderChange: [{ type: i0.Output, args: ["sliderChange"] }], sliderInput: [{ type: i0.Output, args: ["sliderInput"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onSlideEnd: [{ type: i0.Output, args: ["onSlideEnd"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { SliderComponent };
//# sourceMappingURL=ciag-orchestra-slider.mjs.map
