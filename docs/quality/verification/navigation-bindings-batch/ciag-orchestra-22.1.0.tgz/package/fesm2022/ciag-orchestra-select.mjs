import * as i0 from '@angular/core';
import { InjectionToken, inject, ElementRef, input, booleanAttribute, signal, computed, HostListener, ChangeDetectionStrategy, Component, ViewContainerRef, viewChild, contentChildren, forwardRef, model, output, effect } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { registerOverlay, listenForOutsideInteraction, isTopOverlay, overlayAttachmentTarget } from '@ciag/orchestra/internal';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';

const SELECT_HOST = new InjectionToken('ORC_SELECT_HOST');

// src/app/shared/select/option.component.ts
let nextOptionId = 0;
class OptionComponent {
    select = inject(SELECT_HOST, { optional: true });
    elementRef = inject(ElementRef);
    defaultId = `orc-option-${++nextOptionId}`;
    // ── Signal Inputs ──────────────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    // Options can be projected before Angular has applied their inputs. Keep a
    // safe undefined default so select effects do not throw NG0950 during the
    // first change-detection pass; a missing value remains a valid empty option.
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    description = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    icon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    avatarUrl = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "avatarUrl" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // ── Internal State Signals ─────────────────────────────────
    isSelected = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isSelected" }] : /* istanbul ignore next */ []));
    isActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []));
    isHidden = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isHidden" }] : /* istanbul ignore next */ []));
    // ── Computeds ──────────────────────────────────────────────
    displayText = computed(() => {
        if (this.label())
            return this.label();
        const nativeText = this.elementRef?.nativeElement?.textContent?.trim();
        return nativeText || String(this.value() ?? '');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.disabled())
            return;
        if (this.select) {
            this.select.onOptionSelected(this, event);
        }
    }
    onMouseEnter() {
        if (this.disabled() || !this.select)
            return;
        this.select.setActiveOption(this);
    }
    getOptionText() {
        return this.displayText();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OptionComponent, isStandalone: true, selector: "orc-option", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, avatarUrl: { classPropertyName: "avatarUrl", publicName: "avatarUrl", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "onClick($event)", "mouseenter": "onMouseEnter()" }, properties: { "id": "id() || defaultId", "attr.aria-selected": "isSelected()", "attr.aria-disabled": "disabled()", "class.is-selected": "isSelected()", "class.is-active": "isActive()", "class.is-hidden": "isHidden()", "class.is-disabled": "disabled()" } }, ngImport: i0, template: "<div class=\"orc-option-container\">\n  @if (avatarUrl()) {\n    <img [src]=\"avatarUrl()\" alt=\"\" class=\"orc-option-avatar\" />\n  } @else if (icon()) {\n    <i [class]=\"icon()\" class=\"orc-option-icon\" aria-hidden=\"true\"></i>\n  }\n\n  <div class=\"orc-option-content\">\n    <span class=\"orc-option-label\">\n      @if (label()) {\n        {{ label() }}\n      } @else {\n        <ng-content></ng-content>\n      }\n    </span>\n    @if (description()) {\n      <span class=\"orc-option-description\">{{ description() }}</span>\n    }\n  </div>\n\n  @if (isSelected()) {\n    <svg\n      class=\"orc-option-checkmark\"\n      viewBox=\"0 0 20 20\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\"\n        clip-rule=\"evenodd\"\n      />\n    </svg>\n  }\n</div>\n", styles: [":host{display:block;width:100%;box-sizing:border-box}:host.is-hidden{display:none!important}.orc-option-container{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-text, var(--text-primary, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-option-container:hover{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed))}:host(.is-active) .orc-option-container{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed))}:host(.is-selected) .orc-option-container{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed));font-weight:500}:host(.is-disabled) .orc-option-container{opacity:.5;cursor:not-allowed;pointer-events:none}:host(.is-disabled) .orc-option-container:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;line-height:1rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-text, var(--text-primary, #141414))}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OptionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-option', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        role: 'option',
                        '[id]': 'id() || defaultId',
                        '[attr.aria-selected]': 'isSelected()',
                        '[attr.aria-disabled]': 'disabled()',
                        '[class.is-selected]': 'isSelected()',
                        '[class.is-active]': 'isActive()',
                        '[class.is-hidden]': 'isHidden()',
                        '[class.is-disabled]': 'disabled()',
                    }, template: "<div class=\"orc-option-container\">\n  @if (avatarUrl()) {\n    <img [src]=\"avatarUrl()\" alt=\"\" class=\"orc-option-avatar\" />\n  } @else if (icon()) {\n    <i [class]=\"icon()\" class=\"orc-option-icon\" aria-hidden=\"true\"></i>\n  }\n\n  <div class=\"orc-option-content\">\n    <span class=\"orc-option-label\">\n      @if (label()) {\n        {{ label() }}\n      } @else {\n        <ng-content></ng-content>\n      }\n    </span>\n    @if (description()) {\n      <span class=\"orc-option-description\">{{ description() }}</span>\n    }\n  </div>\n\n  @if (isSelected()) {\n    <svg\n      class=\"orc-option-checkmark\"\n      viewBox=\"0 0 20 20\"\n      fill=\"currentColor\"\n      aria-hidden=\"true\"\n    >\n      <path\n        fill-rule=\"evenodd\"\n        d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\"\n        clip-rule=\"evenodd\"\n      />\n    </svg>\n  }\n</div>\n", styles: [":host{display:block;width:100%;box-sizing:border-box}:host.is-hidden{display:none!important}.orc-option-container{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-text, var(--text-primary, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-option-container:hover{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed))}:host(.is-active) .orc-option-container{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed))}:host(.is-selected) .orc-option-container{background-color:var(--orc-interactive-soft, var(--bg-subtle, #ededed));font-weight:500}:host(.is-disabled) .orc-option-container{opacity:.5;cursor:not-allowed;pointer-events:none}:host(.is-disabled) .orc-option-container:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;line-height:1rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-text, var(--text-primary, #141414))}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], avatarUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "avatarUrl", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }] } });

// src/app/shared/select/select.component.ts
let nextSelectUniqueId = 0;
class SelectComponent {
    uniqueId = `orc-select-${++nextSelectUniqueId}`;
    hostEl = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    overlay = inject(Overlay);
    document = inject(DOCUMENT);
    // ── Overlay References ─────────────────────────────────────
    overlayRef = null;
    portal;
    layerCleanup;
    outsideCleanup;
    focusTimer;
    // ── Element Signals ────────────────────────────────────────
    triggerEl = viewChild('triggerEl', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "triggerEl" }] : /* istanbul ignore next */ []));
    searchInputRef = viewChild('searchInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchInputRef" }] : /* istanbul ignore next */ []));
    dropdownPanel = viewChild.required('dropdownPanel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownPanel" }] : /* istanbul ignore next */ []));
    // ── Content Children Options ───────────────────────────────
    projectedOptions = contentChildren(forwardRef(() => OptionComponent), { ...(ngDevMode ? { debugName: "projectedOptions" } : /* istanbul ignore next */ {}), descendants: true });
    // ── Signal Inputs ──────────────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    status = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    searchable = input(false, { ...(ngDevMode ? { debugName: "searchable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    searchPlaceholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []));
    searchEmptyText = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchEmptyText" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    clearable = input(false, { ...(ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    options = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    // PrimeNG Select public inputs (the Orchestra names remain supported).
    optionLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    optionDisabled = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    filter = input(undefined, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: (value) => value === undefined || value === null
            ? undefined
            : booleanAttribute(value) });
    filterPlaceholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    filterLocale = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    filterBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterBy" }] : /* istanbul ignore next */ []));
    filterFields = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterFields" }] : /* istanbul ignore next */ []));
    filterMatchMode = input('contains', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterMatchMode" }] : /* istanbul ignore next */ []));
    emptyFilterMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyFilterMessage" }] : /* istanbul ignore next */ []));
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    panelStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    panelStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    overlayOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayOptions" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    variant = input('outlined', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loadingIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    loadingMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingMessage" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autofocusFilter = input(false, { ...(ngDevMode ? { debugName: "autofocusFilter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    editable = input(false, { ...(ngDevMode ? { debugName: "editable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    checkmark = input(false, { ...(ngDevMode ? { debugName: "checkmark" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dropdownIcon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownIcon" }] : /* istanbul ignore next */ []));
    optionGroupLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    optionGroupChildren = input('items', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    autoDisplayFirst = input(false, { ...(ngDevMode ? { debugName: "autoDisplayFirst" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    group = input(false, { ...(ngDevMode ? { debugName: "group" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    virtualScroll = input(false, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    virtualScrollItemSize = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualScrollItemSize" }] : /* istanbul ignore next */ []));
    virtualScrollOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    itemSize = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemSize" }] : /* istanbul ignore next */ []));
    dataKey = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dataKey" }] : /* istanbul ignore next */ []));
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "baseZIndex" }] : /* istanbul ignore next */ []));
    focusOnHover = input(true, { ...(ngDevMode ? { debugName: "focusOnHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectOnFocus = input(false, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoOptionFocus = input(false, { ...(ngDevMode ? { debugName: "autoOptionFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maxlength = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxlength" }] : /* istanbul ignore next */ []));
    showTransitionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    resetFilterOnHide = input(true, { ...(ngDevMode ? { debugName: "resetFilterOnHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tooltip = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    tooltipPosition = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : /* istanbul ignore next */ []));
    tooltipPositionStyle = input('absolute', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPositionStyle" }] : /* istanbul ignore next */ []));
    tooltipStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipStyleClass" }] : /* istanbul ignore next */ []));
    scrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    // Acessibilidade WCAG
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaFilterLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaFilterLabel" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    removeOptionAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeOptionAriaLabel" }] : /* istanbul ignore next */ []));
    ariaDescribedby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedby" }] : /* istanbul ignore next */ []));
    // ── Two-Way Model Signal ───────────────────────────────────
    value = model(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // ── Signal Outputs ─────────────────────────────────────────
    selectionChange = output();
    searchChange = output();
    opened = output();
    closed = output();
    blur = output();
    focus = output();
    onChange = output();
    onFilter = output();
    onShow = output();
    onHide = output();
    onClear = output();
    onOptionSelect = output();
    onOptionUnselect = output();
    onClick = output();
    onFocus = output();
    onBlur = output();
    onLazyLoad = output();
    // ── Internal State Signals ─────────────────────────────────
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    isFocused = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFocused" }] : /* istanbul ignore next */ []));
    searchTerm = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    activeOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeOptionIndex" }] : /* istanbul ignore next */ []));
    // ── Computeds ──────────────────────────────────────────────
    effectiveId = computed(() => this.id() || this.inputId() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    filterEnabled = computed(() => this.filter() ?? this.searchable(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterEnabled" }] : /* istanbul ignore next */ []));
    listboxId = computed(() => `${this.effectiveId()}-listbox`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listboxId" }] : /* istanbul ignore next */ []));
    activeOptionId = computed(() => {
        const index = this.activeOptionIndex();
        if (index < 0)
            return null;
        if (this.isDataMode())
            return `${this.listboxId()}-option-${index}`;
        const option = this.getVisibleOptions()[index];
        return option ? option.id() || option.defaultId : null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeOptionId" }] : /* istanbul ignore next */ []));
    labelId = computed(() => `${this.effectiveId()}-label`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelId" }] : /* istanbul ignore next */ []));
    helperId = computed(() => `${this.effectiveId()}-helper`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    isInvalid = computed(() => this.status() === 'error' || !!this.errorMessage(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isInvalid" }] : /* istanbul ignore next */ []));
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby())
            ids.push(this.ariaDescribedby());
        if (this.isInvalid() && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaDescribedBy" }] : /* istanbul ignore next */ []));
    /** Close an open panel when a parent changes the control into a state that
     * cannot interact with the list anymore. */
    closeWhenUnavailable = effect(() => {
        if ((this.effectiveDisabled() || this.readonly()) && this.isOpen()) {
            this.closePanel();
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeWhenUnavailable" }] : /* istanbul ignore next */ []));
    // Effective list of options either from inputs or projected components
    dataOptions = computed(() => {
        if (this.options() !== undefined) {
            return this.options() || [];
        }
        return [];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dataOptions" }] : /* istanbul ignore next */ []));
    isDataMode = computed(() => this.options() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDataMode" }] : /* istanbul ignore next */ []));
    // Filtered data options when searching
    filteredDataOptions = computed(() => {
        const list = this.dataOptions();
        const term = this.searchTerm().trim().toLowerCase();
        if (!term)
            return list;
        return list.filter((opt) => {
            const fields = this.filterFields() ??
                (this.filterBy()
                    ? this.filterBy()
                        .split(',')
                        .map((f) => f.trim())
                        .filter(Boolean)
                    : undefined);
            const values = fields?.length
                ? fields
                    .map((field) => String(opt?.[field] ?? ''))
                    .filter(Boolean)
                : [
                    this.getOptionLabel(opt),
                    String(opt?.description ?? ''),
                ].filter(Boolean);
            return values.some((value) => this.matchesFilter(value, term));
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredDataOptions" }] : /* istanbul ignore next */ []));
    matchesFilter(value, term) {
        const normalized = value.toLocaleLowerCase(this.filterLocale() || undefined);
        const query = term.toLocaleLowerCase(this.filterLocale() || undefined);
        switch (this.filterMatchMode()) {
            case 'startsWith':
                return normalized.startsWith(query);
            case 'endsWith':
                return normalized.endsWith(query);
            case 'equals':
                return normalized === query;
            case 'notEquals':
                return normalized !== query;
            case 'in':
                return query
                    .split(',')
                    .map((item) => item.trim())
                    .filter(Boolean)
                    .includes(normalized);
            case 'lt':
                return this.compareNumericFilter(value, term, (left, right) => left < right);
            case 'lte':
                return this.compareNumericFilter(value, term, (left, right) => left <= right);
            case 'gt':
                return this.compareNumericFilter(value, term, (left, right) => left > right);
            case 'gte':
                return this.compareNumericFilter(value, term, (left, right) => left >= right);
            default:
                return normalized.includes(query);
        }
    }
    compareNumericFilter(value, term, compare) {
        const numericValue = Number(value);
        const numericQuery = Number(term);
        return (Number.isFinite(numericValue) &&
            Number.isFinite(numericQuery) &&
            compare(numericValue, numericQuery));
    }
    getOptionValue(option) {
        const key = this.optionValue();
        return key ? option?.[key] : (option?.value ?? option);
    }
    sameOptionValue(left, right) {
        const key = this.dataKey();
        if (!key || left == null || right == null)
            return left === right;
        const valueForKey = (value) => typeof value === 'object' && value !== null && key in value
            ? value[key]
            : value;
        return valueForKey(left) === valueForKey(right);
    }
    isDataOptionSelected(option) {
        const candidate = this.getOptionValue(option);
        const current = this.value();
        return this.multiple()
            ? Array.isArray(current) &&
                current.some((item) => this.sameOptionValue(item, candidate))
            : this.sameOptionValue(current, candidate);
    }
    getOptionLabel(option) {
        const key = this.optionLabel();
        return String(key ? (option?.[key] ?? '') : (option?.label ?? option ?? ''));
    }
    isOptionDisabled(option) {
        const key = this.optionDisabled();
        return Boolean(key ? option?.[key] : option?.disabled);
    }
    // Selected Option Items for display
    selectedItems = computed(() => {
        const currentVal = this.value();
        if (currentVal === undefined || currentVal === null || currentVal === '') {
            return [];
        }
        const valArray = this.multiple()
            ? Array.isArray(currentVal)
                ? currentVal
                : [currentVal]
            : [currentVal];
        if (this.isDataMode()) {
            const allData = this.dataOptions();
            return valArray.map((v) => {
                const found = allData.find((opt) => this.sameOptionValue(this.getOptionValue(opt), v));
                return {
                    label: found ? this.getOptionLabel(found) : String(v),
                    value: v,
                    icon: found?.icon,
                    avatarUrl: found?.avatarUrl,
                };
            });
        }
        // Projected mode
        const proj = this.projectedOptions();
        return valArray.map((v) => {
            const found = proj.find((opt) => this.sameOptionValue(opt.value(), v));
            return {
                label: found ? found.getOptionText() : String(v),
                value: v,
                icon: found?.icon(),
                avatarUrl: found?.avatarUrl(),
            };
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedItems" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.selectedItems().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    // ── ControlValueAccessor Implementation ───────────────────
    onModelChange = () => { };
    onTouched = () => { };
    constructor() {
        // Synchronize selection state to projected components whenever value or projected options change
        effect(() => {
            const val = this.value();
            const isMulti = this.multiple();
            const projOptions = this.projectedOptions();
            projOptions.forEach((opt) => {
                if (isMulti) {
                    const arr = Array.isArray(val) ? val : [];
                    opt.isSelected.set(arr.some((item) => this.sameOptionValue(item, opt.value())));
                }
                else {
                    opt.isSelected.set(this.sameOptionValue(val, opt.value()));
                }
            });
        });
        // Update visibility of projected options when searching
        effect(() => {
            if (this.isDataMode())
                return;
            const term = this.searchTerm().trim().toLowerCase();
            const projOptions = this.projectedOptions();
            projOptions.forEach((opt) => {
                if (!term) {
                    opt.isHidden.set(false);
                }
                else {
                    const desc = opt.description();
                    const matches = [opt.getOptionText(), desc ?? ''].some((value) => this.matchesFilter(value, term));
                    opt.isHidden.set(!matches);
                }
            });
        });
    }
    ngAfterViewInit() {
        this.portal = new TemplatePortal(this.dropdownPanel(), this.viewContainerRef);
        if (this.autofocus()) {
            this.triggerEl()?.nativeElement.focus({ preventScroll: true });
        }
    }
    ngOnDestroy() {
        this.closePanel();
    }
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Overlay & Panel Methods ───────────────────────────────
    togglePanel() {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.isOpen() ? this.closePanel() : this.openPanel();
    }
    openPanel() {
        if (this.isOpen() || this.effectiveDisabled() || this.readonly())
            return;
        if (!this.portal)
            return;
        const triggerNative = this.triggerEl()?.nativeElement || this.hostEl.nativeElement;
        const triggerWidth = triggerNative.getBoundingClientRect().width;
        const positionStrategy = this.createPositionStrategy(triggerNative);
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
            minWidth: triggerWidth,
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        if (this.autoZIndex()) {
            this.overlayRef.hostElement.style.zIndex = String(Math.max(0, this.baseZIndex()) + 1000);
        }
        this.overlayRef.backdropClick().subscribe(() => this.closePanel());
        this.overlayRef.keydownEvents().subscribe((event) => {
            if (event.key === 'Escape') {
                event.preventDefault();
                this.closePanel(true);
                event.stopPropagation();
            }
        });
        this.overlayRef.attach(this.portal);
        this.layerCleanup = registerOverlay(this.overlayRef.overlayElement, {
            anchor: triggerNative,
            onParentClose: () => this.closePanel(),
        });
        this.outsideCleanup = listenForOutsideInteraction(this.document, () => [this.hostEl.nativeElement, this.overlayRef?.overlayElement], () => {
            if (this.overlayRef && isTopOverlay(this.overlayRef.overlayElement))
                this.closePanel();
        });
        this.isOpen.set(true);
        if (this.autoOptionFocus())
            this.navigateOption(1);
        this.opened.emit();
        this.onShow.emit();
        if (this.lazy() || this.virtualScroll())
            this.onLazyLoad.emit({
                first: 0,
                last: Math.max(0, this.dataOptions().length - 1),
            });
        if (this.filterEnabled()) {
            this.focusTimer = setTimeout(() => {
                this.focusTimer = undefined;
                this.searchInputRef()?.nativeElement?.focus();
            });
        }
    }
    closePanel(restoreFocus = false) {
        if (!this.isOpen())
            return;
        if (this.focusTimer !== undefined)
            clearTimeout(this.focusTimer);
        this.focusTimer = undefined;
        this.outsideCleanup?.();
        this.outsideCleanup = undefined;
        this.layerCleanup?.();
        this.layerCleanup = undefined;
        this.overlayRef?.dispose();
        this.overlayRef = null;
        this.isOpen.set(false);
        if (this.resetFilterOnHide())
            this.searchTerm.set('');
        this.activeOptionIndex.set(-1);
        this.onTouched();
        this.closed.emit();
        this.onHide.emit();
        if (restoreFocus)
            this.triggerEl()?.nativeElement.focus({ preventScroll: true });
    }
    createPositionStrategy(origin) {
        const parent = overlayAttachmentTarget(origin, this.appendTo() ?? 'body');
        const positions = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
                offsetY: 4,
            },
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom',
                offsetY: -4,
            },
        ];
        return this.overlay
            .position()
            .flexibleConnectedTo(origin)
            .withPopoverLocation(parent === this.document.body
            ? 'global'
            : { type: 'parent', element: parent })
            .withPositions(positions)
            .withPush(true);
    }
    // ── Selection Logic ───────────────────────────────────────
    onOptionSelected(optionComponent, event) {
        this.selectValue(optionComponent.value(), event);
    }
    onDataOptionClick(option, event) {
        if (this.isOptionDisabled(option))
            return;
        this.selectValue(this.getOptionValue(option), event);
    }
    selectValue(val, originalEvent) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        if (this.multiple()) {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            const index = current.findIndex((item) => this.sameOptionValue(item, val));
            if (index > -1) {
                current.splice(index, 1);
            }
            else {
                current.push(val);
            }
            this.value.set(current);
            this.onModelChange(current);
            this.selectionChange.emit(current);
            const event = originalEvent ?? new Event('change');
            this.onChange.emit({ originalEvent: event, value: current });
            (index > -1 ? this.onOptionUnselect : this.onOptionSelect).emit({
                originalEvent: event,
                value: val,
            });
            this.onTouched();
        }
        else {
            this.value.set(val);
            this.onModelChange(val);
            this.selectionChange.emit(val);
            const event = originalEvent ?? new Event('change');
            this.onChange.emit({ originalEvent: event, value: val });
            this.onOptionSelect.emit({ originalEvent: event, value: val });
            this.closePanel(true);
        }
    }
    removeSelectedItem(itemValue, event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        if (this.multiple()) {
            const current = Array.isArray(this.value()) ? [...this.value()] : [];
            const updated = current.filter((v) => !this.sameOptionValue(v, itemValue));
            this.value.set(updated);
            this.onModelChange(updated);
            this.selectionChange.emit(updated);
            this.onChange.emit({ originalEvent: event, value: updated });
            this.onOptionUnselect.emit({ originalEvent: event, value: itemValue });
            this.onTouched();
        }
        else {
            this.clearValue(event);
        }
    }
    clearValue(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        const clearedVal = this.multiple() ? [] : undefined;
        this.value.set(clearedVal);
        this.onModelChange(clearedVal);
        this.selectionChange.emit(clearedVal);
        this.onChange.emit({ originalEvent: event, value: clearedVal });
        this.onClear.emit(event);
        this.onTouched();
    }
    setActiveOption(optionComponent) {
        if (!this.focusOnHover())
            return;
        const list = this.getVisibleOptions();
        const idx = list.indexOf(optionComponent);
        if (idx !== -1) {
            this.activeOptionIndex.set(idx);
            this.updateActiveHighlight(list, idx);
        }
    }
    getVisibleOptions() {
        return this.projectedOptions().filter((opt) => !opt.isHidden() && !opt.disabled());
    }
    updateActiveHighlight(list, activeIdx) {
        list.forEach((opt, index) => {
            opt.isActive.set(index === activeIdx);
        });
    }
    // ── Search Event Handler ──────────────────────────────────
    onSearchInput(event) {
        const target = event.target;
        const val = target.value;
        this.searchTerm.set(val);
        this.searchChange.emit(val);
        this.onFilter.emit({ originalEvent: event, filter: val });
    }
    // ── Keyboard Navigation (WAI-ARIA Select) ────────────────
    onKeyDown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else {
                    this.navigateOption(1);
                }
                break;
            case 'ArrowUp':
                event.preventDefault();
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else {
                    this.navigateOption(-1);
                }
                break;
            case 'Enter':
            case ' ':
                if (!this.searchable() || !this.isOpen()) {
                    event.preventDefault();
                }
                if (!this.isOpen()) {
                    this.openPanel();
                }
                else if (this.activeOptionIndex() >= 0) {
                    event.preventDefault();
                    this.confirmActiveOption();
                }
                break;
            case 'Tab':
                if (this.isOpen()) {
                    this.closePanel();
                }
                break;
            case 'Escape':
                if (this.isOpen()) {
                    event.preventDefault();
                    event.stopPropagation();
                    this.closePanel(true);
                }
                break;
        }
    }
    navigateOption(direction) {
        if (this.isDataMode()) {
            const optionsList = this.filteredDataOptions();
            if (!optionsList.some((option) => !this.isOptionDisabled(option)))
                return;
            let nextIndex = this.activeOptionIndex();
            do {
                nextIndex =
                    (nextIndex + direction + optionsList.length) % optionsList.length;
            } while (this.isOptionDisabled(optionsList[nextIndex]));
            this.activeOptionIndex.set(nextIndex);
        }
        else {
            const visibleOpts = this.getVisibleOptions();
            if (visibleOpts.length === 0)
                return;
            let nextIndex = this.activeOptionIndex() + direction;
            if (nextIndex < 0)
                nextIndex = visibleOpts.length - 1;
            if (nextIndex >= visibleOpts.length)
                nextIndex = 0;
            this.activeOptionIndex.set(nextIndex);
            this.updateActiveHighlight(visibleOpts, nextIndex);
        }
    }
    dataOptionIndex(option) {
        return this.filteredDataOptions().indexOf(option);
    }
    confirmActiveOption() {
        const idx = this.activeOptionIndex();
        if (idx < 0)
            return;
        if (this.isDataMode()) {
            const optionsList = this.filteredDataOptions();
            if (optionsList[idx] && !this.isOptionDisabled(optionsList[idx])) {
                this.selectValue(this.getOptionValue(optionsList[idx]));
            }
        }
        else {
            const visibleOpts = this.getVisibleOptions();
            if (visibleOpts[idx]) {
                this.selectValue(visibleOpts[idx].value());
            }
        }
    }
    onTriggerFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
        this.onFocus.emit(event);
    }
    onTriggerBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
        this.onBlur.emit(event);
    }
    onDocumentClick(target) {
        if (!this.isOpen())
            return;
        const insideHost = target instanceof Node && this.hostEl.nativeElement.contains(target);
        const insideOverlay = this.overlayRef?.overlayElement.contains(target);
        if (!insideHost && !insideOverlay) {
            this.closePanel();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: SelectComponent, isStandalone: true, selector: "orc-select", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, searchable: { classPropertyName: "searchable", publicName: "searchable", isSignal: true, isRequired: false, transformFunction: null }, searchPlaceholder: { classPropertyName: "searchPlaceholder", publicName: "searchPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, searchEmptyText: { classPropertyName: "searchEmptyText", publicName: "searchEmptyText", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, filterBy: { classPropertyName: "filterBy", publicName: "filterBy", isSignal: true, isRequired: false, transformFunction: null }, filterFields: { classPropertyName: "filterFields", publicName: "filterFields", isSignal: true, isRequired: false, transformFunction: null }, filterMatchMode: { classPropertyName: "filterMatchMode", publicName: "filterMatchMode", isSignal: true, isRequired: false, transformFunction: null }, emptyFilterMessage: { classPropertyName: "emptyFilterMessage", publicName: "emptyFilterMessage", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, overlayOptions: { classPropertyName: "overlayOptions", publicName: "overlayOptions", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, loadingMessage: { classPropertyName: "loadingMessage", publicName: "loadingMessage", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, autofocusFilter: { classPropertyName: "autofocusFilter", publicName: "autofocusFilter", isSignal: true, isRequired: false, transformFunction: null }, editable: { classPropertyName: "editable", publicName: "editable", isSignal: true, isRequired: false, transformFunction: null }, checkmark: { classPropertyName: "checkmark", publicName: "checkmark", isSignal: true, isRequired: false, transformFunction: null }, dropdownIcon: { classPropertyName: "dropdownIcon", publicName: "dropdownIcon", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, autoDisplayFirst: { classPropertyName: "autoDisplayFirst", publicName: "autoDisplayFirst", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, itemSize: { classPropertyName: "itemSize", publicName: "itemSize", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, focusOnHover: { classPropertyName: "focusOnHover", publicName: "focusOnHover", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, autoOptionFocus: { classPropertyName: "autoOptionFocus", publicName: "autoOptionFocus", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, resetFilterOnHide: { classPropertyName: "resetFilterOnHide", publicName: "resetFilterOnHide", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, tooltipPositionStyle: { classPropertyName: "tooltipPositionStyle", publicName: "tooltipPositionStyle", isSignal: true, isRequired: false, transformFunction: null }, tooltipStyleClass: { classPropertyName: "tooltipStyleClass", publicName: "tooltipStyleClass", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaFilterLabel: { classPropertyName: "ariaFilterLabel", publicName: "ariaFilterLabel", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, removeOptionAriaLabel: { classPropertyName: "removeOptionAriaLabel", publicName: "removeOptionAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "ariaDescribedby", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", selectionChange: "selectionChange", searchChange: "searchChange", opened: "opened", closed: "closed", blur: "blur", focus: "focus", onChange: "onChange", onFilter: "onFilter", onShow: "onShow", onHide: "onHide", onClear: "onClear", onOptionSelect: "onOptionSelect", onOptionUnselect: "onOptionUnselect", onClick: "onClick", onFocus: "onFocus", onBlur: "onBlur", onLazyLoad: "onLazyLoad" }, providers: [
            { provide: SELECT_HOST, useExisting: forwardRef(() => SelectComponent) },
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SelectComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "projectedOptions", predicate: i0.forwardRef(() => OptionComponent), descendants: true, isSignal: true }], viewQueries: [{ propertyName: "triggerEl", first: true, predicate: ["triggerEl"], descendants: true, isSignal: true }, { propertyName: "searchInputRef", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }, { propertyName: "dropdownPanel", first: true, predicate: ["dropdownPanel"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"orc-select-wrapper\"\n  [class.is-disabled]=\"effectiveDisabled()\"\n  [class.is-invalid]=\"isInvalid()\"\n  [class.is-filled]=\"variant() === 'filled'\"\n  [class.is-fluid]=\"fluid()\"\n  [class]=\"styleClass()\"\n  [style]=\"style()\"\n>\n  <!-- Label -->\n  @if (label()) {\n    <label [id]=\"labelId()\" class=\"orc-select-label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-select-required-asterisk\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- Main Combobox Trigger -->\n  <div\n    #triggerEl\n    [id]=\"effectiveId()\"\n    [attr.name]=\"name() || null\"\n    class=\"orc-select-trigger\"\n    [class.is-open]=\"isOpen()\"\n    [class.is-focused]=\"isFocused()\"\n    [class.is-disabled]=\"effectiveDisabled()\"\n    [class.is-readonly]=\"readonly()\"\n    [class.is-invalid]=\"isInvalid()\"\n    [class.is-filled]=\"variant() === 'filled'\"\n    [class.is-small]=\"size() === 'small'\"\n    [class.is-large]=\"size() === 'large'\"\n    role=\"combobox\"\n    [attr.aria-expanded]=\"isOpen()\"\n    [attr.aria-controls]=\"listboxId()\"\n    [attr.aria-activedescendant]=\"activeOptionId()\"\n    [attr.aria-haspopup]=\"'listbox'\"\n    [attr.aria-disabled]=\"effectiveDisabled()\"\n    [attr.aria-readonly]=\"readonly()\"\n    [attr.aria-required]=\"required()\"\n    [attr.aria-invalid]=\"isInvalid()\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || (label() ? labelId() : null)\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.tabindex]=\"effectiveDisabled() ? -1 : (tabindex() ?? 0)\"\n    (click)=\"onClick.emit($event); togglePanel()\"\n    (keydown)=\"onKeyDown($event)\"\n    (focus)=\"onTriggerFocus($event)\"\n    (blur)=\"onTriggerBlur($event)\"\n  >\n    <div class=\"orc-select-trigger-content\">\n      <ng-content select=\"[orcSelectTrigger], [selectTrigger]\">\n        @if (multiple()) {\n          @if (selectedItems().length > 0) {\n            <div class=\"orc-select-chips\">\n              @for (item of selectedItems(); track item.value) {\n                <span class=\"orc-select-chip\">\n                  @if (item.avatarUrl) {\n                    <img\n                      [src]=\"item.avatarUrl\"\n                      alt=\"\"\n                      class=\"orc-chip-avatar\"\n                    />\n                  } @else if (item.icon) {\n                    <i\n                      [class]=\"item.icon\"\n                      class=\"orc-chip-icon\"\n                      aria-hidden=\"true\"\n                    ></i>\n                  }\n                  <span class=\"orc-chip-label\">{{ item.label }}</span>\n                  @if (!effectiveDisabled() && !readonly()) {\n                    <button\n                      type=\"button\"\n                      class=\"orc-chip-remove\"\n                      [attr.aria-label]=\"removeOptionAriaLabel() || null\"\n                      (click)=\"removeSelectedItem(item.value, $event)\"\n                    >\n                      &times;\n                    </button>\n                  }\n                </span>\n              }\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        } @else {\n          @if (hasValue()) {\n            <div class=\"orc-select-single-value\">\n              @if (selectedItems()[0].avatarUrl) {\n                <img\n                  [src]=\"selectedItems()[0].avatarUrl\"\n                  alt=\"\"\n                  class=\"orc-value-avatar\"\n                />\n              } @else if (selectedItems()[0].icon) {\n                <i\n                  [class]=\"selectedItems()[0].icon\"\n                  class=\"orc-value-icon\"\n                  aria-hidden=\"true\"\n                ></i>\n              }\n              <span class=\"orc-value-text\">{{ selectedItems()[0].label }}</span>\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        }\n      </ng-content>\n    </div>\n\n    <!-- Actions (Clear & Chevron Arrow) -->\n    <div class=\"orc-select-actions\">\n      @if (\n        (clearable() || showClear()) &&\n        hasValue() &&\n        !effectiveDisabled() &&\n        !readonly()\n      ) {\n        <button\n          type=\"button\"\n          class=\"orc-select-clear-btn\"\n          [attr.aria-label]=\"clearAriaLabel() || null\"\n          (click)=\"clearValue($event)\"\n        >\n          &times;\n        </button>\n      }\n\n      <div class=\"orc-select-arrow\" [class.is-expanded]=\"isOpen()\">\n        @if (dropdownIcon()) {\n          <span>{{ dropdownIcon() }}</span>\n        } @else {\n          <svg\n            width=\"20\"\n            height=\"20\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M5 7.5L10 12.5L15 7.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.67\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n      </div>\n    </div>\n  </div>\n\n  <!-- Helper Text or Error Message -->\n  @if (isInvalid() && errorMessage()) {\n    <p [id]=\"errorId()\" class=\"orc-select-message is-error\">\n      {{ errorMessage() }}\n    </p>\n  } @else if (helperText()) {\n    <p [id]=\"helperId()\" class=\"orc-select-message is-helper\">\n      {{ helperText() }}\n    </p>\n  }\n</div>\n\n<!-- Floating Dropdown Panel Template -->\n<ng-template #dropdownPanel>\n  <div\n    [id]=\"listboxId()\"\n    class=\"orc-select-dropdown\"\n    role=\"listbox\"\n    [class]=\"panelStyleClass()\"\n    [style]=\"panelStyle()\"\n    [style.max-height]=\"scrollHeight()\"\n    [attr.aria-multiselectable]=\"multiple()\"\n  >\n    <!-- Header projection -->\n    <ng-content select=\"[orcSelectHeader]\"></ng-content>\n\n    <!-- Search Input -->\n    @if (filterEnabled()) {\n      <div class=\"orc-select-search-container\">\n        <input\n          #searchInput\n          type=\"text\"\n          class=\"orc-select-search-input\"\n          [attr.placeholder]=\"\n            filterPlaceholder() || searchPlaceholder() || null\n          \"\n          [attr.aria-label]=\"ariaFilterLabel() || null\"\n          [attr.maxlength]=\"maxlength()\"\n          [value]=\"searchTerm()\"\n          (input)=\"onSearchInput($event)\"\n          (keydown)=\"onKeyDown($event)\"\n        />\n      </div>\n    }\n\n    <!-- Options Container -->\n    <div class=\"orc-select-options-list\">\n      @if (loading()) {\n        @if (loadingIcon() || loadingMessage()) {\n          <div class=\"orc-select-empty-state\" aria-live=\"polite\">\n            {{ loadingIcon() || loadingMessage() }}\n          </div>\n        }\n      } @else {\n        @if (isDataMode()) {\n          @for (opt of filteredDataOptions(); track $index; let idx = $index) {\n            <div\n              class=\"orc-data-option\"\n              [id]=\"listboxId() + '-option-' + dataOptionIndex(opt)\"\n              [class.is-selected]=\"isDataOptionSelected(opt)\"\n              [class.is-active]=\"activeOptionIndex() === dataOptionIndex(opt)\"\n              [class.is-disabled]=\"isOptionDisabled(opt)\"\n              role=\"option\"\n              [attr.aria-selected]=\"isDataOptionSelected(opt)\"\n              [attr.aria-disabled]=\"isOptionDisabled(opt)\"\n              (click)=\"onDataOptionClick(opt, $event)\"\n            >\n              @if (opt.avatarUrl) {\n                <img [src]=\"opt.avatarUrl\" alt=\"\" class=\"orc-option-avatar\" />\n              } @else if (opt.icon) {\n                <i\n                  [class]=\"opt.icon\"\n                  class=\"orc-option-icon\"\n                  aria-hidden=\"true\"\n                ></i>\n              }\n              <div class=\"orc-option-content\">\n                <span class=\"orc-option-label\">{{ getOptionLabel(opt) }}</span>\n                @if (opt.description) {\n                  <span class=\"orc-option-description\">{{\n                    opt.description\n                  }}</span>\n                }\n              </div>\n              @if (isDataOptionSelected(opt)) {\n                <svg\n                  class=\"orc-option-checkmark\"\n                  viewBox=\"0 0 20 20\"\n                  fill=\"currentColor\"\n                >\n                  <path\n                    fill-rule=\"evenodd\"\n                    d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\"\n                    clip-rule=\"evenodd\"\n                  />\n                </svg>\n              }\n            </div>\n          } @empty {\n            <div class=\"orc-select-empty-state\">\n              {{\n                searchTerm()\n                  ? emptyFilterMessage() || searchEmptyText()\n                  : emptyMessage()\n              }}\n            </div>\n          }\n        } @else {\n          <!-- Projected <orc-option> elements -->\n          <ng-content></ng-content>\n        }\n      }\n    </div>\n\n    <!-- Footer projection -->\n    <ng-content select=\"[orcSelectFooter]\"></ng-content>\n  </div>\n</ng-template>\n", styles: [":host{display:block;width:100%}.orc-select-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box}.orc-select-wrapper.is-fluid{width:100%}.orc-select-wrapper.is-disabled{opacity:.6;pointer-events:none}.orc-select-label{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414));display:inline-flex;align-items:center;gap:var(--space-1, .25rem)}.orc-select-required-asterisk{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-select-trigger{display:flex;align-items:center;justify-content:space-between;min-height:41px;width:100%;padding:.625rem;background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, .625rem);box-sizing:border-box;cursor:pointer;outline:none;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-select-trigger.is-filled{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-select-trigger.is-small{min-height:34px;padding-block:.375rem}.orc-select-trigger.is-large{min-height:48px;padding-block:.75rem}.orc-select-trigger:hover:not(.is-disabled):not(.is-readonly){border-color:var(--orc-border-strong, var(--border-strong, #d9d9d9))}.orc-select-trigger.is-focused,.orc-select-trigger.is-open{border-color:var(--orc-interactive, var(--color-accent, #141414));box-shadow:0 0 0 1px var(--orc-interactive, var(--color-accent, #141414))}.orc-select-trigger.is-invalid{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-select-trigger.is-invalid.is-focused,.orc-select-trigger.is-invalid.is-open{box-shadow:0 0 0 1px var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-select-trigger.is-disabled{cursor:not-allowed;background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-select-trigger-content{display:flex;align-items:center;flex:1 1 auto;min-width:0;overflow:hidden}.orc-select-placeholder{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-single-value{display:flex;align-items:center;gap:var(--space-2, .5rem);color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-value-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-value-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-value-text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-chips{display:flex;flex-wrap:wrap;gap:.375rem;width:100%}.orc-select-chip{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem .5rem;background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed));border-radius:var(--radius-sm, .375rem);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.75rem;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-chip-avatar{width:1rem;height:1rem;border-radius:var(--radius-full, 9999px)}.orc-chip-icon{font-size:.875rem}.orc-chip-label{white-space:nowrap}.orc-chip-remove{background:transparent;border:none;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));font-size:.875rem;line-height:1;cursor:pointer;padding:0 .125rem;display:inline-flex;align-items:center;justify-content:center;border-radius:50%}.orc-chip-remove:hover{color:var(--orc-danger, var(--color-error, #fb2c36));background-color:color-mix(in srgb,var(--orc-text) 5%,transparent)}.orc-select-actions{display:flex;align-items:center;gap:.25rem;margin-left:.5rem;flex-shrink:0}.orc-select-clear-btn{background:transparent;border:none;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));font-size:1.125rem;cursor:pointer;padding:0 .25rem;line-height:1}.orc-select-clear-btn:hover{color:var(--orc-text, var(--orc-font-main, #141414))}.orc-select-arrow{display:flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;color:var(--orc-text, var(--orc-font-main, #141414));transition:transform var(--transition-fast, .12s ease)}.orc-select-arrow.is-expanded{transform:rotate(180deg)}.orc-select-dropdown{background-color:var(--orc-surface-raised, var(--orc-bg, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, .625rem);box-shadow:var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, .08));padding:.625rem;display:flex;flex-direction:column;gap:.25rem;box-sizing:border-box;max-height:260px;overflow:hidden;z-index:1000}.orc-select-search-container{padding-bottom:.5rem;border-bottom:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));margin-bottom:.25rem}.orc-select-search-input{width:100%;padding:.5rem .625rem;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-sm, .375rem);outline:none;box-sizing:border-box}.orc-select-search-input:focus{border-color:var(--orc-interactive, var(--color-accent, #141414))}.orc-select-options-list{display:flex;flex-direction:column;gap:.125rem;overflow-y:auto;max-height:200px}.orc-select-options-list::-webkit-scrollbar{width:6px}.orc-select-options-list::-webkit-scrollbar-thumb{background:var(--orc-border-strong, var(--border-strong, #d9d9d9));border-radius:var(--radius-full, 9999px)}.orc-data-option{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease)}.orc-data-option:hover,.orc-data-option.is-active,.orc-data-option.is-selected{background-color:var(--orc-interactive-soft, var(--orc-highlight-cinza-claro, #ededed))}.orc-data-option.is-disabled{opacity:.5;cursor:not-allowed}.orc-data-option.is-disabled:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-select-empty-state{padding:.75rem;text-align:center;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-select-message{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem}.orc-select-message.is-error{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-select-message.is-helper{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-select', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        { provide: SELECT_HOST, useExisting: forwardRef(() => SelectComponent) },
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SelectComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"orc-select-wrapper\"\n  [class.is-disabled]=\"effectiveDisabled()\"\n  [class.is-invalid]=\"isInvalid()\"\n  [class.is-filled]=\"variant() === 'filled'\"\n  [class.is-fluid]=\"fluid()\"\n  [class]=\"styleClass()\"\n  [style]=\"style()\"\n>\n  <!-- Label -->\n  @if (label()) {\n    <label [id]=\"labelId()\" class=\"orc-select-label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-select-required-asterisk\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- Main Combobox Trigger -->\n  <div\n    #triggerEl\n    [id]=\"effectiveId()\"\n    [attr.name]=\"name() || null\"\n    class=\"orc-select-trigger\"\n    [class.is-open]=\"isOpen()\"\n    [class.is-focused]=\"isFocused()\"\n    [class.is-disabled]=\"effectiveDisabled()\"\n    [class.is-readonly]=\"readonly()\"\n    [class.is-invalid]=\"isInvalid()\"\n    [class.is-filled]=\"variant() === 'filled'\"\n    [class.is-small]=\"size() === 'small'\"\n    [class.is-large]=\"size() === 'large'\"\n    role=\"combobox\"\n    [attr.aria-expanded]=\"isOpen()\"\n    [attr.aria-controls]=\"listboxId()\"\n    [attr.aria-activedescendant]=\"activeOptionId()\"\n    [attr.aria-haspopup]=\"'listbox'\"\n    [attr.aria-disabled]=\"effectiveDisabled()\"\n    [attr.aria-readonly]=\"readonly()\"\n    [attr.aria-required]=\"required()\"\n    [attr.aria-invalid]=\"isInvalid()\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || (label() ? labelId() : null)\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.tabindex]=\"effectiveDisabled() ? -1 : (tabindex() ?? 0)\"\n    (click)=\"onClick.emit($event); togglePanel()\"\n    (keydown)=\"onKeyDown($event)\"\n    (focus)=\"onTriggerFocus($event)\"\n    (blur)=\"onTriggerBlur($event)\"\n  >\n    <div class=\"orc-select-trigger-content\">\n      <ng-content select=\"[orcSelectTrigger], [selectTrigger]\">\n        @if (multiple()) {\n          @if (selectedItems().length > 0) {\n            <div class=\"orc-select-chips\">\n              @for (item of selectedItems(); track item.value) {\n                <span class=\"orc-select-chip\">\n                  @if (item.avatarUrl) {\n                    <img\n                      [src]=\"item.avatarUrl\"\n                      alt=\"\"\n                      class=\"orc-chip-avatar\"\n                    />\n                  } @else if (item.icon) {\n                    <i\n                      [class]=\"item.icon\"\n                      class=\"orc-chip-icon\"\n                      aria-hidden=\"true\"\n                    ></i>\n                  }\n                  <span class=\"orc-chip-label\">{{ item.label }}</span>\n                  @if (!effectiveDisabled() && !readonly()) {\n                    <button\n                      type=\"button\"\n                      class=\"orc-chip-remove\"\n                      [attr.aria-label]=\"removeOptionAriaLabel() || null\"\n                      (click)=\"removeSelectedItem(item.value, $event)\"\n                    >\n                      &times;\n                    </button>\n                  }\n                </span>\n              }\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        } @else {\n          @if (hasValue()) {\n            <div class=\"orc-select-single-value\">\n              @if (selectedItems()[0].avatarUrl) {\n                <img\n                  [src]=\"selectedItems()[0].avatarUrl\"\n                  alt=\"\"\n                  class=\"orc-value-avatar\"\n                />\n              } @else if (selectedItems()[0].icon) {\n                <i\n                  [class]=\"selectedItems()[0].icon\"\n                  class=\"orc-value-icon\"\n                  aria-hidden=\"true\"\n                ></i>\n              }\n              <span class=\"orc-value-text\">{{ selectedItems()[0].label }}</span>\n            </div>\n          } @else {\n            <span class=\"orc-select-placeholder\">{{ placeholder() }}</span>\n          }\n        }\n      </ng-content>\n    </div>\n\n    <!-- Actions (Clear & Chevron Arrow) -->\n    <div class=\"orc-select-actions\">\n      @if (\n        (clearable() || showClear()) &&\n        hasValue() &&\n        !effectiveDisabled() &&\n        !readonly()\n      ) {\n        <button\n          type=\"button\"\n          class=\"orc-select-clear-btn\"\n          [attr.aria-label]=\"clearAriaLabel() || null\"\n          (click)=\"clearValue($event)\"\n        >\n          &times;\n        </button>\n      }\n\n      <div class=\"orc-select-arrow\" [class.is-expanded]=\"isOpen()\">\n        @if (dropdownIcon()) {\n          <span>{{ dropdownIcon() }}</span>\n        } @else {\n          <svg\n            width=\"20\"\n            height=\"20\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n            xmlns=\"http://www.w3.org/2000/svg\"\n          >\n            <path\n              d=\"M5 7.5L10 12.5L15 7.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.67\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n      </div>\n    </div>\n  </div>\n\n  <!-- Helper Text or Error Message -->\n  @if (isInvalid() && errorMessage()) {\n    <p [id]=\"errorId()\" class=\"orc-select-message is-error\">\n      {{ errorMessage() }}\n    </p>\n  } @else if (helperText()) {\n    <p [id]=\"helperId()\" class=\"orc-select-message is-helper\">\n      {{ helperText() }}\n    </p>\n  }\n</div>\n\n<!-- Floating Dropdown Panel Template -->\n<ng-template #dropdownPanel>\n  <div\n    [id]=\"listboxId()\"\n    class=\"orc-select-dropdown\"\n    role=\"listbox\"\n    [class]=\"panelStyleClass()\"\n    [style]=\"panelStyle()\"\n    [style.max-height]=\"scrollHeight()\"\n    [attr.aria-multiselectable]=\"multiple()\"\n  >\n    <!-- Header projection -->\n    <ng-content select=\"[orcSelectHeader]\"></ng-content>\n\n    <!-- Search Input -->\n    @if (filterEnabled()) {\n      <div class=\"orc-select-search-container\">\n        <input\n          #searchInput\n          type=\"text\"\n          class=\"orc-select-search-input\"\n          [attr.placeholder]=\"\n            filterPlaceholder() || searchPlaceholder() || null\n          \"\n          [attr.aria-label]=\"ariaFilterLabel() || null\"\n          [attr.maxlength]=\"maxlength()\"\n          [value]=\"searchTerm()\"\n          (input)=\"onSearchInput($event)\"\n          (keydown)=\"onKeyDown($event)\"\n        />\n      </div>\n    }\n\n    <!-- Options Container -->\n    <div class=\"orc-select-options-list\">\n      @if (loading()) {\n        @if (loadingIcon() || loadingMessage()) {\n          <div class=\"orc-select-empty-state\" aria-live=\"polite\">\n            {{ loadingIcon() || loadingMessage() }}\n          </div>\n        }\n      } @else {\n        @if (isDataMode()) {\n          @for (opt of filteredDataOptions(); track $index; let idx = $index) {\n            <div\n              class=\"orc-data-option\"\n              [id]=\"listboxId() + '-option-' + dataOptionIndex(opt)\"\n              [class.is-selected]=\"isDataOptionSelected(opt)\"\n              [class.is-active]=\"activeOptionIndex() === dataOptionIndex(opt)\"\n              [class.is-disabled]=\"isOptionDisabled(opt)\"\n              role=\"option\"\n              [attr.aria-selected]=\"isDataOptionSelected(opt)\"\n              [attr.aria-disabled]=\"isOptionDisabled(opt)\"\n              (click)=\"onDataOptionClick(opt, $event)\"\n            >\n              @if (opt.avatarUrl) {\n                <img [src]=\"opt.avatarUrl\" alt=\"\" class=\"orc-option-avatar\" />\n              } @else if (opt.icon) {\n                <i\n                  [class]=\"opt.icon\"\n                  class=\"orc-option-icon\"\n                  aria-hidden=\"true\"\n                ></i>\n              }\n              <div class=\"orc-option-content\">\n                <span class=\"orc-option-label\">{{ getOptionLabel(opt) }}</span>\n                @if (opt.description) {\n                  <span class=\"orc-option-description\">{{\n                    opt.description\n                  }}</span>\n                }\n              </div>\n              @if (isDataOptionSelected(opt)) {\n                <svg\n                  class=\"orc-option-checkmark\"\n                  viewBox=\"0 0 20 20\"\n                  fill=\"currentColor\"\n                >\n                  <path\n                    fill-rule=\"evenodd\"\n                    d=\"M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z\"\n                    clip-rule=\"evenodd\"\n                  />\n                </svg>\n              }\n            </div>\n          } @empty {\n            <div class=\"orc-select-empty-state\">\n              {{\n                searchTerm()\n                  ? emptyFilterMessage() || searchEmptyText()\n                  : emptyMessage()\n              }}\n            </div>\n          }\n        } @else {\n          <!-- Projected <orc-option> elements -->\n          <ng-content></ng-content>\n        }\n      }\n    </div>\n\n    <!-- Footer projection -->\n    <ng-content select=\"[orcSelectFooter]\"></ng-content>\n  </div>\n</ng-template>\n", styles: [":host{display:block;width:100%}.orc-select-wrapper{display:flex;flex-direction:column;gap:var(--space-2, .5rem);width:100%;box-sizing:border-box}.orc-select-wrapper.is-fluid{width:100%}.orc-select-wrapper.is-disabled{opacity:.6;pointer-events:none}.orc-select-label{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414));display:inline-flex;align-items:center;gap:var(--space-1, .25rem)}.orc-select-required-asterisk{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-select-trigger{display:flex;align-items:center;justify-content:space-between;min-height:41px;width:100%;padding:.625rem;background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, .625rem);box-sizing:border-box;cursor:pointer;outline:none;transition:border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-select-trigger.is-filled{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-select-trigger.is-small{min-height:34px;padding-block:.375rem}.orc-select-trigger.is-large{min-height:48px;padding-block:.75rem}.orc-select-trigger:hover:not(.is-disabled):not(.is-readonly){border-color:var(--orc-border-strong, var(--border-strong, #d9d9d9))}.orc-select-trigger.is-focused,.orc-select-trigger.is-open{border-color:var(--orc-interactive, var(--color-accent, #141414));box-shadow:0 0 0 1px var(--orc-interactive, var(--color-accent, #141414))}.orc-select-trigger.is-invalid{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-select-trigger.is-invalid.is-focused,.orc-select-trigger.is-invalid.is-open{box-shadow:0 0 0 1px var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-select-trigger.is-disabled{cursor:not-allowed;background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-select-trigger-content{display:flex;align-items:center;flex:1 1 auto;min-width:0;overflow:hidden}.orc-select-placeholder{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-single-value{display:flex;align-items:center;gap:var(--space-2, .5rem);color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-value-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-value-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-value-text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-select-chips{display:flex;flex-wrap:wrap;gap:.375rem;width:100%}.orc-select-chip{display:inline-flex;align-items:center;gap:.25rem;padding:.125rem .5rem;background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed));border-radius:var(--radius-sm, .375rem);font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.75rem;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-chip-avatar{width:1rem;height:1rem;border-radius:var(--radius-full, 9999px)}.orc-chip-icon{font-size:.875rem}.orc-chip-label{white-space:nowrap}.orc-chip-remove{background:transparent;border:none;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));font-size:.875rem;line-height:1;cursor:pointer;padding:0 .125rem;display:inline-flex;align-items:center;justify-content:center;border-radius:50%}.orc-chip-remove:hover{color:var(--orc-danger, var(--color-error, #fb2c36));background-color:color-mix(in srgb,var(--orc-text) 5%,transparent)}.orc-select-actions{display:flex;align-items:center;gap:.25rem;margin-left:.5rem;flex-shrink:0}.orc-select-clear-btn{background:transparent;border:none;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));font-size:1.125rem;cursor:pointer;padding:0 .25rem;line-height:1}.orc-select-clear-btn:hover{color:var(--orc-text, var(--orc-font-main, #141414))}.orc-select-arrow{display:flex;align-items:center;justify-content:center;width:1.25rem;height:1.25rem;color:var(--orc-text, var(--orc-font-main, #141414));transition:transform var(--transition-fast, .12s ease)}.orc-select-arrow.is-expanded{transform:rotate(180deg)}.orc-select-dropdown{background-color:var(--orc-surface-raised, var(--orc-bg, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, .625rem);box-shadow:var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, .08));padding:.625rem;display:flex;flex-direction:column;gap:.25rem;box-sizing:border-box;max-height:260px;overflow:hidden;z-index:1000}.orc-select-search-container{padding-bottom:.5rem;border-bottom:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));margin-bottom:.25rem}.orc-select-search-input{width:100%;padding:.5rem .625rem;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-sm, .375rem);outline:none;box-sizing:border-box}.orc-select-search-input:focus{border-color:var(--orc-interactive, var(--color-accent, #141414))}.orc-select-options-list{display:flex;flex-direction:column;gap:.125rem;overflow-y:auto;max-height:200px}.orc-select-options-list::-webkit-scrollbar{width:6px}.orc-select-options-list::-webkit-scrollbar-thumb{background:var(--orc-border-strong, var(--border-strong, #d9d9d9));border-radius:var(--radius-full, 9999px)}.orc-data-option{display:flex;align-items:center;gap:var(--space-2, .5rem);padding:.625rem .75rem;border-radius:var(--radius-md, .625rem);color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem;cursor:pointer;-webkit-user-select:none;user-select:none;transition:background-color var(--transition-fast, .12s ease)}.orc-data-option:hover,.orc-data-option.is-active,.orc-data-option.is-selected{background-color:var(--orc-interactive-soft, var(--orc-highlight-cinza-claro, #ededed))}.orc-data-option.is-disabled{opacity:.5;cursor:not-allowed}.orc-data-option.is-disabled:hover{background-color:transparent}.orc-option-avatar{width:1.25rem;height:1.25rem;border-radius:var(--radius-full, 9999px);object-fit:cover;flex-shrink:0}.orc-option-icon{font-size:1rem;width:1rem;height:1rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-option-content{display:flex;flex-direction:column;flex:1 1 auto;min-width:0}.orc-option-label{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-option-checkmark{width:1.125rem;height:1.125rem;flex-shrink:0;margin-left:auto;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-select-empty-state{padding:.75rem;text-align:center;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-select-message{font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:.875rem;line-height:1.25rem}.orc-select-message.is-error{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-select-message.is-helper{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}\n"] }]
        }], ctorParameters: () => [], propDecorators: { triggerEl: [{ type: i0.ViewChild, args: ['triggerEl', { isSignal: true }] }], searchInputRef: [{ type: i0.ViewChild, args: ['searchInput', { isSignal: true }] }], dropdownPanel: [{ type: i0.ViewChild, args: ['dropdownPanel', { isSignal: true }] }], projectedOptions: [{ type: i0.ContentChildren, args: [forwardRef(() => OptionComponent), { ...{ descendants: true }, isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], searchable: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchable", required: false }] }], searchPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchPlaceholder", required: false }] }], searchEmptyText: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchEmptyText", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], filterBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterBy", required: false }] }], filterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterFields", required: false }] }], filterMatchMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterMatchMode", required: false }] }], emptyFilterMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyFilterMessage", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], overlayOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayOptions", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], loadingMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingMessage", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], autofocusFilter: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocusFilter", required: false }] }], editable: [{ type: i0.Input, args: [{ isSignal: true, alias: "editable", required: false }] }], checkmark: [{ type: i0.Input, args: [{ isSignal: true, alias: "checkmark", required: false }] }], dropdownIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownIcon", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], autoDisplayFirst: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoDisplayFirst", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], itemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemSize", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], focusOnHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnHover", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], autoOptionFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoOptionFocus", required: false }] }], maxlength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxlength", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], resetFilterOnHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetFilterOnHide", required: false }] }], tooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], tooltipPositionStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPositionStyle", required: false }] }], tooltipStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipStyleClass", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaFilterLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaFilterLabel", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], removeOptionAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeOptionAriaLabel", required: false }] }], ariaDescribedby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedby", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], searchChange: [{ type: i0.Output, args: ["searchChange"] }], opened: [{ type: i0.Output, args: ["opened"] }], closed: [{ type: i0.Output, args: ["closed"] }], blur: [{ type: i0.Output, args: ["blur"] }], focus: [{ type: i0.Output, args: ["focus"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onOptionSelect: [{ type: i0.Output, args: ["onOptionSelect"] }], onOptionUnselect: [{ type: i0.Output, args: ["onOptionUnselect"] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }] } });

// src/app/shared/select/select.types.ts

/**
 * Generated bundle index. Do not edit.
 */

export { OptionComponent, SELECT_HOST, SelectComponent };
//# sourceMappingURL=ciag-orchestra-select.mjs.map
