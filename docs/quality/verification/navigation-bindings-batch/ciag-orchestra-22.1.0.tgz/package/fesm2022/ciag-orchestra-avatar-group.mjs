export { AvatarGroupComponent } from '@ciag/orchestra/avatar';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-avatar-group.mjs.map
