export * from '@ciag/orchestra/mega-menu';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-megamenu.mjs.map
