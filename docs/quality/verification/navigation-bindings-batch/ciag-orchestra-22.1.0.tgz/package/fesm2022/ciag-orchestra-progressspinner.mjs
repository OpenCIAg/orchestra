export * from '@ciag/orchestra/progress-spinner';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-progressspinner.mjs.map
