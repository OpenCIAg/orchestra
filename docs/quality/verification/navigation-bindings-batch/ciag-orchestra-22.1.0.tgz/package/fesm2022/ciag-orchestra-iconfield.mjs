export * from '@ciag/orchestra/icon-field';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-iconfield.mjs.map
