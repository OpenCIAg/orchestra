import * as i0 from '@angular/core';
import { inject, ApplicationRef, EnvironmentInjector, signal, computed, DestroyRef, createComponent, Injectable, ElementRef, input, output, effect, untracked, ChangeDetectionStrategy, Component, booleanAttribute } from '@angular/core';
import { DOCUMENT, CommonModule } from '@angular/common';

class ToastService {
    appRef = inject(ApplicationRef);
    injector = inject(EnvironmentInjector);
    document = inject(DOCUMENT);
    // ── Sinais Reativos Globais ───────────────────────────────
    toasts = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toasts" }] : /* istanbul ignore next */ []));
    activeCount = computed(() => this.toasts().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeCount" }] : /* istanbul ignore next */ []));
    // ── Configurações Padrão ──────────────────────────────────
    defaultPosition = 'top-right';
    defaultDuration = 5000;
    preventDuplicates = false;
    preventOpenDuplicates = false;
    containerRef = null;
    isCreatingContainer = false;
    idCounter = 0;
    destroyed = false;
    containers = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "containers" }] : /* istanbul ignore next */ []));
    /** A service stream is rendered once; explicit toast arrays remain independent. */
    registerContainer(owner) {
        this.containers.update((owners) => [...owners, owner]);
        this.disposeContainer();
        return () => {
            this.containers.update((owners) => owners.filter((candidate) => candidate !== owner));
            if (!this.destroyed && !this.containers().length && this.toasts().length)
                void this.ensureContainer();
        };
    }
    isContainerOwner(owner) {
        return this.containers()[0] === owner;
    }
    disposeContainer() {
        if (!this.containerRef)
            return;
        const ref = this.containerRef;
        this.containerRef = null;
        if (!this.appRef.destroyed && !ref.hostView.destroyed)
            this.appRef.detachView(ref.hostView);
        ref.destroy();
    }
    constructor() {
        inject(DestroyRef).onDestroy(() => {
            this.destroyed = true;
            this.disposeContainer();
        });
    }
    // ── Inicialização Dinâmica do Container Overlay (Sem Circular Dependency) ──
    async ensureContainer() {
        if (this.containerRef ||
            this.isCreatingContainer ||
            this.containers().length ||
            !this.document.defaultView ||
            this.destroyed)
            return;
        try {
            this.isCreatingContainer = true;
            const { ToastContainerComponent } = await Promise.resolve().then(function () { return toastContainer_component; });
            if (!this.containerRef && !this.destroyed && !this.containers().length) {
                const containerComponentRef = createComponent(ToastContainerComponent, {
                    environmentInjector: this.injector,
                });
                containerComponentRef.setInput('automatic', true);
                this.appRef.attachView(containerComponentRef.hostView);
                const domElem = containerComponentRef.location
                    .nativeElement;
                this.document.body.appendChild(domElem);
                this.containerRef = containerComponentRef;
            }
        }
        catch {
            // Ignora caso já esteja instanciado
        }
        finally {
            this.isCreatingContainer = false;
        }
    }
    // ── Métodos de Configuração Global ────────────────────────
    setDefaultPosition(position) {
        this.defaultPosition = position;
    }
    setDefaultDuration(duration) {
        this.defaultDuration = duration;
    }
    setPreventDuplicates(value) {
        this.preventDuplicates = value;
    }
    setPreventOpenDuplicates(value) {
        this.preventOpenDuplicates = value;
    }
    // ── Disparo Principal de Toasts ───────────────────────────
    show(optionsOrMessage) {
        this.ensureContainer();
        const options = typeof optionsOrMessage === 'string'
            ? { message: optionsOrMessage }
            : optionsOrMessage;
        const id = options.id || `orc-toast-${++this.idCounter}-${Date.now()}`;
        const type = options.type ||
            (options.severity === 'warn'
                ? 'warning'
                : options.severity === 'error'
                    ? 'error'
                    : options.severity === 'success'
                        ? 'success'
                        : 'info');
        const title = options.title || options.summary || '';
        const toastItem = {
            ...options,
            id,
            type,
            title,
            message: options.message || options.detail || '',
            duration: options.sticky
                ? 0
                : options.duration !== undefined
                    ? options.duration
                    : options.life !== undefined
                        ? options.life
                        : this.defaultDuration,
            showProgressBar: Boolean(options.showProgressBar),
            dismissible: options.dismissible !== undefined ? options.dismissible : true,
            showIcon: options.showIcon !== undefined ? options.showIcon : true,
            position: options.position || this.defaultPosition,
            pauseOnHover: options.pauseOnHover !== undefined ? options.pauseOnHover : true,
            createdAt: Date.now(),
        };
        const existing = this.toasts();
        const duplicate = existing.find((item) => item.id === id ||
            (this.preventDuplicates &&
                item.message === toastItem.message &&
                item.type === toastItem.type) ||
            (this.preventOpenDuplicates &&
                item.key === toastItem.key &&
                item.message === toastItem.message));
        if (duplicate)
            return duplicate.id;
        this.toasts.update((current) => [...current, toastItem]);
        return id;
    }
    add(message) {
        return this.show(message);
    }
    addAll(messages) {
        return messages.map((message) => this.show(message));
    }
    remove(id) {
        this.dismiss(id);
    }
    // ── Atalhos Semânticos ────────────────────────────────────
    success(message, options) {
        return this.show({
            ...options,
            type: 'success',
            title: options?.title,
            message,
        });
    }
    info(message, options) {
        return this.show({
            ...options,
            type: 'info',
            title: options?.title,
            message,
        });
    }
    warning(message, options) {
        return this.show({
            ...options,
            type: 'warning',
            title: options?.title,
            message,
        });
    }
    error(message, options) {
        return this.show({
            ...options,
            type: 'error',
            title: options?.title,
            message,
        });
    }
    loading(message, options) {
        return this.show({
            ...options,
            type: 'loading',
            title: options?.title,
            message,
            duration: options?.duration !== undefined ? options.duration : 0,
        });
    }
    notification(message, options) {
        return this.show({
            ...options,
            type: 'notification',
            title: options?.title,
            message,
        });
    }
    // ── Fechamento e Limpeza ──────────────────────────────────
    dismiss(id) {
        this.toasts.update((current) => current.filter((t) => t.id !== id));
    }
    clear(key) {
        if (key)
            this.toasts.update((current) => current.filter((toast) => toast.key !== key));
        else
            this.toasts.set([]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class ToastComponent {
    destroyRef = inject(DestroyRef);
    element = inject(ElementRef);
    // ── Inputs (Signals API) ──────────────────────────────────
    toast = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toast" }] : /* istanbul ignore next */ []));
    // ── Outputs (Signals API) ─────────────────────────────────
    dismiss = output();
    actionClick = output();
    onClose = output();
    onClick = output();
    // ── Estados Internos Reativos ─────────────────────────────
    isHovered = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isHovered" }] : /* istanbul ignore next */ []));
    isFocused = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFocused" }] : /* istanbul ignore next */ []));
    isPaused = computed(() => this.isFocused() || (this.isHovered() && this.toast().pauseOnHover), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isPaused" }] : /* istanbul ignore next */ []));
    isExiting = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isExiting" }] : /* istanbul ignore next */ []));
    progress = signal(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "progress" }] : /* istanbul ignore next */ []));
    timerInterval = null;
    dismissTimeout = null;
    remainingTime = 0;
    totalDuration = 0;
    deadline = 0;
    expiryTimeout = null;
    // ── Sinais Computados ─────────────────────────────────────
    computedRole = computed(() => {
        if (this.toast().role)
            return this.toast().role;
        const type = this.toast().type;
        return type === 'error' || type === 'warning' ? 'alert' : 'status';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedRole" }] : /* istanbul ignore next */ []));
    computedAriaLive = computed(() => {
        if (this.toast().ariaLive)
            return this.toast().ariaLive;
        const type = this.toast().type;
        return type === 'error' ? 'assertive' : 'polite';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaLive" }] : /* istanbul ignore next */ []));
    hasProgressBar = computed(() => {
        const t = this.toast();
        const d = t.duration;
        return Boolean(t.showProgressBar) && d > 0 && isFinite(d);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasProgressBar" }] : /* istanbul ignore next */ []));
    constructor() {
        // Inicialização do timer reativo de auto-dismiss com suporte a hover pause
        effect(() => {
            const item = this.toast();
            untracked(() => this.initTimer(item));
        });
        this.destroyRef.onDestroy(() => {
            this.clearTimer();
            this.clearDismissTimeout();
        });
    }
    initTimer(item) {
        this.clearTimer();
        this.clearDismissTimeout();
        this.isExiting.set(false);
        this.totalDuration = item.duration;
        this.remainingTime = item.duration;
        this.progress.set(100);
        this.resumeTimer();
    }
    resumeTimer() {
        if (this.isPaused() ||
            this.isExiting() ||
            this.totalDuration <= 0 ||
            !Number.isFinite(this.totalDuration))
            return;
        this.clearTimer();
        this.deadline = Date.now() + this.remainingTime;
        this.expiryTimeout = setTimeout(() => {
            this.progress.set(0);
            this.handleClose();
        }, Math.max(0, this.remainingTime));
        // Plain notifications need only one deadline timer, with no polling or
        // reactive updates. Visual progress runs only while it can be seen.
        if (this.hasProgressBar())
            this.timerInterval = setInterval(() => {
                this.progress.set(Math.max(0, ((this.deadline - Date.now()) / this.totalDuration) * 100));
            }, 50);
    }
    pauseTimer() {
        if (this.expiryTimeout !== null)
            this.remainingTime = Math.max(0, this.deadline - Date.now());
        this.clearTimer();
    }
    clearTimer() {
        if (this.timerInterval !== null)
            clearInterval(this.timerInterval);
        this.timerInterval = null;
        if (this.expiryTimeout !== null)
            clearTimeout(this.expiryTimeout);
        this.expiryTimeout = null;
    }
    clearDismissTimeout() {
        if (this.dismissTimeout) {
            clearTimeout(this.dismissTimeout);
            this.dismissTimeout = null;
        }
    }
    onMouseEnter() {
        this.isHovered.set(true);
        if (this.isPaused())
            this.pauseTimer();
    }
    onMouseLeave() {
        const wasPaused = this.isPaused();
        this.isHovered.set(false);
        if (wasPaused && !this.isPaused())
            this.resumeTimer();
    }
    onFocusIn() {
        this.isFocused.set(true);
        this.pauseTimer();
    }
    onFocusOut(event) {
        if (event.relatedTarget &&
            this.element.nativeElement.contains(event.relatedTarget))
            return;
        this.isFocused.set(false);
        if (!this.isPaused())
            this.resumeTimer();
    }
    handleClose(originalEvent = new Event('close')) {
        if (this.isExiting())
            return;
        this.isExiting.set(true);
        this.clearTimer();
        this.clearDismissTimeout();
        this.onClose.emit({ originalEvent, message: this.toast() });
        // Permite animação de saída antes da remoção final
        this.dismissTimeout = setTimeout(() => {
            this.dismissTimeout = null;
            this.dismiss.emit(this.toast().id);
        }, 200);
    }
    handleToastClick(event) {
        this.onClick.emit({ originalEvent: event, message: this.toast() });
    }
    handleAction() {
        if (this.toast().action) {
            this.toast().action.onClick(this.toast());
            this.actionClick.emit(this.toast());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ToastComponent, isStandalone: true, selector: "orc-toast", inputs: { toast: { classPropertyName: "toast", publicName: "toast", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { dismiss: "dismiss", actionClick: "actionClick", onClose: "onClose", onClick: "onClick" }, host: { listeners: { "mouseenter": "onMouseEnter()", "mouseleave": "onMouseLeave()", "focusin": "onFocusIn()", "focusout": "onFocusOut($event)" }, classAttribute: "orc-toast-host" }, ngImport: i0, template: "<div\n  class=\"p-toast-message p-component orc-toast\"\n  [class]=\"\n    'p-toast-message p-component orc-toast ' +\n    (toast().type === 'warning'\n      ? 'p-toast-message-warn'\n      : 'p-toast-message-' + toast().type)\n  \"\n  [attr.data-pc-name]=\"'toast'\"\n  [class.orc-toast--exiting]=\"isExiting()\"\n  [class.orc-toast--type-success]=\"toast().type === 'success'\"\n  [class.orc-toast--type-info]=\"toast().type === 'info'\"\n  [class.orc-toast--type-warning]=\"toast().type === 'warning'\"\n  [class.orc-toast--type-error]=\"toast().type === 'error'\"\n  [class.orc-toast--type-loading]=\"toast().type === 'loading'\"\n  [class.orc-toast--type-notification]=\"toast().type === 'notification'\"\n  [attr.role]=\"computedRole()\"\n  [attr.aria-live]=\"computedAriaLive()\"\n  [attr.aria-atomic]=\"true\"\n  [attr.aria-label]=\"toast().ariaLabel || undefined\"\n  tabindex=\"0\"\n  (click)=\"handleToastClick($event)\"\n  (keydown.escape)=\"handleClose($event)\"\n>\n  <!-- \u00CDcone Sem\u00E2ntico (Figma Node 382:5265) -->\n  @if (toast().showIcon) {\n    <div class=\"orc-toast__icon-wrap\" aria-hidden=\"true\">\n      @switch (toast().type) {\n        @case (\"success\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--success\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M6.5 10.2L8.8 12.5L13.5 7.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n        @case (\"info\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--info\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M10 13.5V10\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <circle cx=\"10\" cy=\"6.8\" r=\"0.9\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case (\"warning\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--warning\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <path\n              d=\"M10 2.5L1.8 16.5H18.2L10 2.5Z\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M10 8V11.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <circle cx=\"10\" cy=\"14\" r=\"0.8\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case (\"error\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--error\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M12.5 7.5L7.5 12.5M7.5 7.5L12.5 12.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n        @case (\"loading\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--loading\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"7.5\"\n              stroke=\"var(--border-default)\"\n              stroke-width=\"2\"\n            />\n            <path\n              d=\"M10 2.5A7.5 7.5 0 0 1 17.5 10\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        }\n        @case (\"notification\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--notification\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <path\n              d=\"M15 14H5L6.5 12.5V8.5C6.5 6.3 8.1 4.5 10 4.5C11.9 4.5 13.5 6.3 13.5 8.5V12.5L15 14Z\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M8.5 14C8.5 14.8 9.2 15.5 10 15.5C10.8 15.5 11.5 14.8 11.5 14\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        }\n      }\n    </div>\n  }\n\n  <!-- Corpo do Texto -->\n  <div class=\"orc-toast__content\">\n    @if (toast().title) {\n      <p class=\"orc-toast__title\">{{ toast().title }}</p>\n    }\n    @if (toast().message) {\n      <p class=\"orc-toast__message\">{{ toast().message }}</p>\n    }\n  </div>\n\n  <!-- A\u00E7\u00E3o Customizada (Bot\u00E3o Desfazer / Saiba mais) -->\n  @if (toast().action; as action) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__action\"\n      (click)=\"handleAction(); $event.stopPropagation()\"\n    >\n      @if (\n        action.icon === \"undo\" || action.label.toLowerCase() === \"desfazer\"\n      ) {\n        <svg\n          class=\"orc-toast__action-icon\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M9 14L4 9M4 9L9 4M4 9H15C17.7614 9 20 11.2386 20 14C20 16.7614 17.7614 19 15 19H8\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      }\n      <span>{{ action.label }}</span>\n    </button>\n  }\n\n  <!-- Bot\u00E3o Manual de Fechar -->\n  @if (toast().dismissible) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__close\"\n      [attr.aria-label]=\"toast().closeAriaLabel || 'Dismiss notification'\"\n      (click)=\"handleClose($event); $event.stopPropagation()\"\n    >\n      <svg\n        viewBox=\"0 0 16 16\"\n        fill=\"none\"\n        class=\"orc-toast__close-icon\"\n        aria-hidden=\"true\"\n      >\n        <path\n          d=\"M12 4L4 12M4 4L12 12\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </button>\n  }\n\n  <!-- Barra de Progresso de Auto-Dismiss -->\n  @if (hasProgressBar()) {\n    <div\n      class=\"orc-toast__progress\"\n      [style.width.%]=\"progress()\"\n      [class.orc-toast__progress--paused]=\"isPaused()\"\n    ></div>\n  }\n</div>\n", styles: [":host{display:block;width:100%;max-width:448px;pointer-events:auto}.orc-toast{position:relative;display:flex;align-items:center;gap:12px;width:100%;min-height:58px;padding:17px;background-color:var(--orc-surface-raised, var(--orc-bg, #FFFFFF));border:1px solid var(--orc-border-default, var(--border-default, #D9D9D9));border-radius:var(--radius-md, 10px);box-shadow:var(--orc-shadow-overlay, var(--shadow-lg));font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;overflow:hidden;outline:none;animation:orc-toast-enter var(--transition-base, .25s) cubic-bezier(.16,1,.3,1) forwards;transition:transform var(--transition-fast, .15s ease),box-shadow var(--transition-fast, .15s ease),opacity var(--transition-fast, .15s ease)}.orc-toast:hover{box-shadow:var(--orc-shadow-overlay, var(--shadow-lg))}.orc-toast:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-toast--exiting{animation:orc-toast-exit var(--transition-base, .2s) cubic-bezier(.4,0,1,1) forwards!important}.orc-toast__icon-wrap{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px}.orc-toast__icon{width:20px;height:20px;display:block}.orc-toast__icon--success{color:var(--orc-status-success-fg, var(--color-success, #006F4A))}.orc-toast__icon--info{color:var(--orc-status-info-fg, var(--color-info, #2B7FFF))}.orc-toast__icon--warning{color:var(--orc-status-warning-fg, var(--color-warning, #FE9A00))}.orc-toast__icon--error{color:var(--orc-danger, var(--color-error, #FB2C36))}.orc-toast__icon--loading{color:var(--orc-text, var(--orc-font-main, #141414));animation:orc-toast-spin .9s linear infinite}.orc-toast__icon--notification{color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__content{flex:1 1 auto;display:flex;flex-direction:column;gap:4px;min-width:0;word-break:break-word}.orc-toast__title{margin:0;padding:0;font-size:16px;font-weight:500;line-height:24px;letter-spacing:-.3px;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__message{margin:0;padding:0;font-size:14px;font-weight:400;line-height:20px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-toast__action{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:32px;padding:0 13px;border:1px solid var(--orc-border-default, var(--border-default, #D9D9D9));border-radius:var(--radius-sm, 8px);background-color:var(--orc-surface-raised, var(--orc-bg, #FFFFFF));color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:500;line-height:20px;cursor:pointer;flex-shrink:0;white-space:nowrap;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),transform var(--transition-fast, .12s ease)}.orc-toast__action:hover{background-color:var(--orc-surface-muted, var(--bg-muted, #EDEDED));border-color:var(--orc-border-strong, var(--border-strong, #BDBDBD))}.orc-toast__action:active{transform:scale(.97)}.orc-toast__action:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));outline-offset:2px}.orc-toast__action-icon{width:18px;height:18px;flex-shrink:0}.orc-toast__close{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));cursor:pointer;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-toast__close:hover{background-color:var(--orc-surface-muted, var(--bg-muted, rgba(0, 0, 0, .06)));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));outline-offset:2px}.orc-toast__close-icon{width:14px;height:14px}.orc-toast__progress{position:absolute;bottom:0;left:0;height:3px;background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));opacity:.6;border-radius:0 0 0 10px;transition:width 25ms linear}.orc-toast__progress--paused{background-color:var(--orc-status-warning-fg, var(--orc-color-laranja, #FF6A1C))}.orc-toast--type-success .orc-toast__progress{background-color:var(--orc-status-success-fg, var(--color-success, #006F4A))}.orc-toast--type-error .orc-toast__progress{background-color:var(--orc-danger, var(--color-error, #FB2C36))}.orc-toast--type-warning .orc-toast__progress{background-color:var(--orc-status-warning-fg, var(--color-warning, #FE9A00))}.orc-toast--type-info .orc-toast__progress{background-color:var(--orc-status-info-fg, var(--color-info, #2B7FFF))}@keyframes orc-toast-enter{0%{opacity:0;transform:translateY(16px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes orc-toast-exit{0%{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-8px) scale(.95)}}@keyframes orc-toast-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-toast{animation:none!important;transition:opacity .15s ease!important}.orc-toast--exiting{animation:none!important;opacity:0!important}.orc-toast__icon--loading{animation:none!important}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-toast', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'orc-toast-host',
                        '(mouseenter)': 'onMouseEnter()',
                        '(mouseleave)': 'onMouseLeave()',
                        '(focusin)': 'onFocusIn()',
                        '(focusout)': 'onFocusOut($event)',
                    }, template: "<div\n  class=\"p-toast-message p-component orc-toast\"\n  [class]=\"\n    'p-toast-message p-component orc-toast ' +\n    (toast().type === 'warning'\n      ? 'p-toast-message-warn'\n      : 'p-toast-message-' + toast().type)\n  \"\n  [attr.data-pc-name]=\"'toast'\"\n  [class.orc-toast--exiting]=\"isExiting()\"\n  [class.orc-toast--type-success]=\"toast().type === 'success'\"\n  [class.orc-toast--type-info]=\"toast().type === 'info'\"\n  [class.orc-toast--type-warning]=\"toast().type === 'warning'\"\n  [class.orc-toast--type-error]=\"toast().type === 'error'\"\n  [class.orc-toast--type-loading]=\"toast().type === 'loading'\"\n  [class.orc-toast--type-notification]=\"toast().type === 'notification'\"\n  [attr.role]=\"computedRole()\"\n  [attr.aria-live]=\"computedAriaLive()\"\n  [attr.aria-atomic]=\"true\"\n  [attr.aria-label]=\"toast().ariaLabel || undefined\"\n  tabindex=\"0\"\n  (click)=\"handleToastClick($event)\"\n  (keydown.escape)=\"handleClose($event)\"\n>\n  <!-- \u00CDcone Sem\u00E2ntico (Figma Node 382:5265) -->\n  @if (toast().showIcon) {\n    <div class=\"orc-toast__icon-wrap\" aria-hidden=\"true\">\n      @switch (toast().type) {\n        @case (\"success\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--success\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M6.5 10.2L8.8 12.5L13.5 7.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n        @case (\"info\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--info\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M10 13.5V10\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <circle cx=\"10\" cy=\"6.8\" r=\"0.9\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case (\"warning\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--warning\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <path\n              d=\"M10 2.5L1.8 16.5H18.2L10 2.5Z\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M10 8V11.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <circle cx=\"10\" cy=\"14\" r=\"0.8\" fill=\"currentColor\" />\n          </svg>\n        }\n        @case (\"error\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--error\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"8\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n            />\n            <path\n              d=\"M12.5 7.5L7.5 12.5M7.5 7.5L12.5 12.5\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n          </svg>\n        }\n        @case (\"loading\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--loading\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <circle\n              cx=\"10\"\n              cy=\"10\"\n              r=\"7.5\"\n              stroke=\"var(--border-default)\"\n              stroke-width=\"2\"\n            />\n            <path\n              d=\"M10 2.5A7.5 7.5 0 0 1 17.5 10\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        }\n        @case (\"notification\") {\n          <svg\n            class=\"orc-toast__icon orc-toast__icon--notification\"\n            viewBox=\"0 0 20 20\"\n            fill=\"none\"\n          >\n            <path\n              d=\"M15 14H5L6.5 12.5V8.5C6.5 6.3 8.1 4.5 10 4.5C11.9 4.5 13.5 6.3 13.5 8.5V12.5L15 14Z\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n            />\n            <path\n              d=\"M8.5 14C8.5 14.8 9.2 15.5 10 15.5C10.8 15.5 11.5 14.8 11.5 14\"\n              stroke=\"currentColor\"\n              stroke-width=\"1.6\"\n              stroke-linecap=\"round\"\n            />\n          </svg>\n        }\n      }\n    </div>\n  }\n\n  <!-- Corpo do Texto -->\n  <div class=\"orc-toast__content\">\n    @if (toast().title) {\n      <p class=\"orc-toast__title\">{{ toast().title }}</p>\n    }\n    @if (toast().message) {\n      <p class=\"orc-toast__message\">{{ toast().message }}</p>\n    }\n  </div>\n\n  <!-- A\u00E7\u00E3o Customizada (Bot\u00E3o Desfazer / Saiba mais) -->\n  @if (toast().action; as action) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__action\"\n      (click)=\"handleAction(); $event.stopPropagation()\"\n    >\n      @if (\n        action.icon === \"undo\" || action.label.toLowerCase() === \"desfazer\"\n      ) {\n        <svg\n          class=\"orc-toast__action-icon\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          aria-hidden=\"true\"\n        >\n          <path\n            d=\"M9 14L4 9M4 9L9 4M4 9H15C17.7614 9 20 11.2386 20 14C20 16.7614 17.7614 19 15 19H8\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          />\n        </svg>\n      }\n      <span>{{ action.label }}</span>\n    </button>\n  }\n\n  <!-- Bot\u00E3o Manual de Fechar -->\n  @if (toast().dismissible) {\n    <button\n      type=\"button\"\n      class=\"orc-toast__close\"\n      [attr.aria-label]=\"toast().closeAriaLabel || 'Dismiss notification'\"\n      (click)=\"handleClose($event); $event.stopPropagation()\"\n    >\n      <svg\n        viewBox=\"0 0 16 16\"\n        fill=\"none\"\n        class=\"orc-toast__close-icon\"\n        aria-hidden=\"true\"\n      >\n        <path\n          d=\"M12 4L4 12M4 4L12 12\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.5\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        />\n      </svg>\n    </button>\n  }\n\n  <!-- Barra de Progresso de Auto-Dismiss -->\n  @if (hasProgressBar()) {\n    <div\n      class=\"orc-toast__progress\"\n      [style.width.%]=\"progress()\"\n      [class.orc-toast__progress--paused]=\"isPaused()\"\n    ></div>\n  }\n</div>\n", styles: [":host{display:block;width:100%;max-width:448px;pointer-events:auto}.orc-toast{position:relative;display:flex;align-items:center;gap:12px;width:100%;min-height:58px;padding:17px;background-color:var(--orc-surface-raised, var(--orc-bg, #FFFFFF));border:1px solid var(--orc-border-default, var(--border-default, #D9D9D9));border-radius:var(--radius-md, 10px);box-shadow:var(--orc-shadow-overlay, var(--shadow-lg));font-family:var(--font-sans, \"Poppins\", sans-serif);box-sizing:border-box;overflow:hidden;outline:none;animation:orc-toast-enter var(--transition-base, .25s) cubic-bezier(.16,1,.3,1) forwards;transition:transform var(--transition-fast, .15s ease),box-shadow var(--transition-fast, .15s ease),opacity var(--transition-fast, .15s ease)}.orc-toast:hover{box-shadow:var(--orc-shadow-overlay, var(--shadow-lg))}.orc-toast:focus-visible{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-toast--exiting{animation:orc-toast-exit var(--transition-base, .2s) cubic-bezier(.4,0,1,1) forwards!important}.orc-toast__icon-wrap{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px}.orc-toast__icon{width:20px;height:20px;display:block}.orc-toast__icon--success{color:var(--orc-status-success-fg, var(--color-success, #006F4A))}.orc-toast__icon--info{color:var(--orc-status-info-fg, var(--color-info, #2B7FFF))}.orc-toast__icon--warning{color:var(--orc-status-warning-fg, var(--color-warning, #FE9A00))}.orc-toast__icon--error{color:var(--orc-danger, var(--color-error, #FB2C36))}.orc-toast__icon--loading{color:var(--orc-text, var(--orc-font-main, #141414));animation:orc-toast-spin .9s linear infinite}.orc-toast__icon--notification{color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__content{flex:1 1 auto;display:flex;flex-direction:column;gap:4px;min-width:0;word-break:break-word}.orc-toast__title{margin:0;padding:0;font-size:16px;font-weight:500;line-height:24px;letter-spacing:-.3px;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__message{margin:0;padding:0;font-size:14px;font-weight:400;line-height:20px;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-toast__action{display:inline-flex;align-items:center;justify-content:center;gap:6px;height:32px;padding:0 13px;border:1px solid var(--orc-border-default, var(--border-default, #D9D9D9));border-radius:var(--radius-sm, 8px);background-color:var(--orc-surface-raised, var(--orc-bg, #FFFFFF));color:var(--orc-text, var(--orc-font-main, #141414));font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:500;line-height:20px;cursor:pointer;flex-shrink:0;white-space:nowrap;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),transform var(--transition-fast, .12s ease)}.orc-toast__action:hover{background-color:var(--orc-surface-muted, var(--bg-muted, #EDEDED));border-color:var(--orc-border-strong, var(--border-strong, #BDBDBD))}.orc-toast__action:active{transform:scale(.97)}.orc-toast__action:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));outline-offset:2px}.orc-toast__action-icon{width:18px;height:18px;flex-shrink:0}.orc-toast__close{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:24px;height:24px;padding:0;border:none;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));cursor:pointer;transition:background-color var(--transition-fast, .12s ease),color var(--transition-fast, .12s ease)}.orc-toast__close:hover{background-color:var(--orc-surface-muted, var(--bg-muted, rgba(0, 0, 0, .06)));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-toast__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));outline-offset:2px}.orc-toast__close-icon{width:14px;height:14px}.orc-toast__progress{position:absolute;bottom:0;left:0;height:3px;background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1C6AED));opacity:.6;border-radius:0 0 0 10px;transition:width 25ms linear}.orc-toast__progress--paused{background-color:var(--orc-status-warning-fg, var(--orc-color-laranja, #FF6A1C))}.orc-toast--type-success .orc-toast__progress{background-color:var(--orc-status-success-fg, var(--color-success, #006F4A))}.orc-toast--type-error .orc-toast__progress{background-color:var(--orc-danger, var(--color-error, #FB2C36))}.orc-toast--type-warning .orc-toast__progress{background-color:var(--orc-status-warning-fg, var(--color-warning, #FE9A00))}.orc-toast--type-info .orc-toast__progress{background-color:var(--orc-status-info-fg, var(--color-info, #2B7FFF))}@keyframes orc-toast-enter{0%{opacity:0;transform:translateY(16px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes orc-toast-exit{0%{opacity:1;transform:translateY(0) scale(1)}to{opacity:0;transform:translateY(-8px) scale(.95)}}@keyframes orc-toast-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orc-toast{animation:none!important;transition:opacity .15s ease!important}.orc-toast--exiting{animation:none!important;opacity:0!important}.orc-toast__icon--loading{animation:none!important}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { toast: [{ type: i0.Input, args: [{ isSignal: true, alias: "toast", required: true }] }], dismiss: [{ type: i0.Output, args: ["dismiss"] }], actionClick: [{ type: i0.Output, args: ["actionClick"] }], onClose: [{ type: i0.Output, args: ["onClose"] }], onClick: [{ type: i0.Output, args: ["onClick"] }] } });

class ToastContainerComponent {
    toastService = inject(ToastService);
    // ── Inputs e Outputs para suporte declarativo e via serviço ──
    toasts = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "toasts" }] : /* istanbul ignore next */ []));
    dismiss = output();
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    preventOpenDuplicates = input(undefined, { ...(ngDevMode ? { debugName: "preventOpenDuplicates" } : /* istanbul ignore next */ {}), transform: (value) => value == null ? undefined : booleanAttribute(value) });
    preventDuplicates = input(undefined, { ...(ngDevMode ? { debugName: "preventDuplicates" } : /* istanbul ignore next */ {}), transform: (value) => (value == null ? undefined : booleanAttribute(value)) });
    /** @internal Used by the service's automatically mounted outlet. */
    automatic = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "automatic" }] : /* istanbul ignore next */ []));
    owner = Symbol('toast-outlet');
    showTransformOptions = input('300ms ease-out', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransformOptions" }] : /* istanbul ignore next */ []));
    hideTransformOptions = input('250ms ease-in', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransformOptions" }] : /* istanbul ignore next */ []));
    showTransitionOptions = input('300ms ease-out', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input('250ms ease-in', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const duplicates = this.preventDuplicates();
            const openDuplicates = this.preventOpenDuplicates();
            if (duplicates !== undefined)
                this.toastService.setPreventDuplicates(duplicates);
            if (openDuplicates !== undefined)
                this.toastService.setPreventOpenDuplicates(openDuplicates);
        });
        effect((onCleanup) => {
            if (this.toasts() === undefined && !this.automatic()) {
                onCleanup(untracked(() => this.toastService.registerContainer(this.owner)));
            }
        });
    }
    positions = [
        'top-right',
        'top-left',
        'top-center',
        'bottom-right',
        'bottom-left',
        'bottom-center',
    ];
    /** Lista consolidada de toasts (input declarativo com fallback para o ToastService) */
    activeToasts = computed(() => this.toasts() ??
        (this.automatic() || this.toastService.isContainerOwner(this.owner)
            ? this.toastService.toasts()
            : []), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeToasts" }] : /* istanbul ignore next */ []));
    /** Agrupa os toasts de forma reativa e memorizada por posição */
    toastsByPosition = computed(() => {
        const all = this.activeToasts();
        const map = {
            'top-right': [],
            'top-left': [],
            'top-center': [],
            'bottom-right': [],
            'bottom-left': [],
            'bottom-center': [],
        };
        for (const toast of all) {
            if (map[toast.position]) {
                map[toast.position].push(toast);
            }
        }
        return map;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toastsByPosition" }] : /* istanbul ignore next */ []));
    handleDismiss(id) {
        this.dismiss.emit(id);
        if (this.toasts() === undefined)
            this.toastService.dismiss(id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ToastContainerComponent, isStandalone: true, selector: "orc-toast-container", inputs: { toasts: { classPropertyName: "toasts", publicName: "toasts", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, preventOpenDuplicates: { classPropertyName: "preventOpenDuplicates", publicName: "preventOpenDuplicates", isSignal: true, isRequired: false, transformFunction: null }, preventDuplicates: { classPropertyName: "preventDuplicates", publicName: "preventDuplicates", isSignal: true, isRequired: false, transformFunction: null }, automatic: { classPropertyName: "automatic", publicName: "automatic", isSignal: true, isRequired: false, transformFunction: null }, showTransformOptions: { classPropertyName: "showTransformOptions", publicName: "showTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransformOptions: { classPropertyName: "hideTransformOptions", publicName: "hideTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismiss: "dismiss" }, host: { classAttribute: "orc-toast-container-host" }, ngImport: i0, template: "@for (pos of positions; track pos) {\n  @if (toastsByPosition()[pos].length > 0) {\n    <div\n      class=\"p-toast p-component orc-toast-stack\"\n      [class]=\"'orc-toast-stack--' + pos\"\n      role=\"region\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      aria-live=\"polite\"\n    >\n      @for (item of toastsByPosition()[pos]; track item.id) {\n        <orc-toast\n          [toast]=\"item\"\n          (dismiss)=\"handleDismiss($event)\"\n        />\n      }\n    </div>\n  }\n}\n", styles: [":host{display:contents;pointer-events:none}.orc-toast-stack{position:fixed;z-index:9999;display:flex;flex-direction:column;gap:12px;max-width:calc(100vw - 32px);width:448px;pointer-events:none;box-sizing:border-box}.orc-toast-stack--top-right{top:24px;right:24px;align-items:flex-end}.orc-toast-stack--top-left{top:24px;left:24px;align-items:flex-start}.orc-toast-stack--top-center{top:24px;left:50%;transform:translate(-50%);align-items:center}.orc-toast-stack--bottom-right{bottom:24px;right:24px;align-items:flex-end;flex-direction:column-reverse}.orc-toast-stack--bottom-left{bottom:24px;left:24px;align-items:flex-start;flex-direction:column-reverse}.orc-toast-stack--bottom-center{bottom:24px;left:50%;transform:translate(-50%);align-items:center;flex-direction:column-reverse}@media(max-width:640px){.orc-toast-stack{left:16px!important;right:16px!important;width:auto!important;max-width:none!important;transform:none!important;align-items:stretch!important}.orc-toast-stack--top-right,.orc-toast-stack--top-left,.orc-toast-stack--top-center{top:16px}.orc-toast-stack--bottom-right,.orc-toast-stack--bottom-left,.orc-toast-stack--bottom-center{bottom:16px}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ToastComponent, selector: "orc-toast", inputs: ["toast"], outputs: ["dismiss", "actionClick", "onClose", "onClick"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-toast-container', standalone: true, imports: [CommonModule, ToastComponent], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'orc-toast-container-host',
                    }, template: "@for (pos of positions; track pos) {\n  @if (toastsByPosition()[pos].length > 0) {\n    <div\n      class=\"p-toast p-component orc-toast-stack\"\n      [class]=\"'orc-toast-stack--' + pos\"\n      role=\"region\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      aria-live=\"polite\"\n    >\n      @for (item of toastsByPosition()[pos]; track item.id) {\n        <orc-toast\n          [toast]=\"item\"\n          (dismiss)=\"handleDismiss($event)\"\n        />\n      }\n    </div>\n  }\n}\n", styles: [":host{display:contents;pointer-events:none}.orc-toast-stack{position:fixed;z-index:9999;display:flex;flex-direction:column;gap:12px;max-width:calc(100vw - 32px);width:448px;pointer-events:none;box-sizing:border-box}.orc-toast-stack--top-right{top:24px;right:24px;align-items:flex-end}.orc-toast-stack--top-left{top:24px;left:24px;align-items:flex-start}.orc-toast-stack--top-center{top:24px;left:50%;transform:translate(-50%);align-items:center}.orc-toast-stack--bottom-right{bottom:24px;right:24px;align-items:flex-end;flex-direction:column-reverse}.orc-toast-stack--bottom-left{bottom:24px;left:24px;align-items:flex-start;flex-direction:column-reverse}.orc-toast-stack--bottom-center{bottom:24px;left:50%;transform:translate(-50%);align-items:center;flex-direction:column-reverse}@media(max-width:640px){.orc-toast-stack{left:16px!important;right:16px!important;width:auto!important;max-width:none!important;transform:none!important;align-items:stretch!important}.orc-toast-stack--top-right,.orc-toast-stack--top-left,.orc-toast-stack--top-center{top:16px}.orc-toast-stack--bottom-right,.orc-toast-stack--bottom-left,.orc-toast-stack--bottom-center{bottom:16px}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { toasts: [{ type: i0.Input, args: [{ isSignal: true, alias: "toasts", required: false }] }], dismiss: [{ type: i0.Output, args: ["dismiss"] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], preventOpenDuplicates: [{ type: i0.Input, args: [{ isSignal: true, alias: "preventOpenDuplicates", required: false }] }], preventDuplicates: [{ type: i0.Input, args: [{ isSignal: true, alias: "preventDuplicates", required: false }] }], automatic: [{ type: i0.Input, args: [{ isSignal: true, alias: "automatic", required: false }] }], showTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransformOptions", required: false }] }], hideTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransformOptions", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }] } });

var toastContainer_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ToastContainerComponent: ToastContainerComponent
});

/**
 * Generated bundle index. Do not edit.
 */

export { ToastComponent, ToastContainerComponent, ToastService };
//# sourceMappingURL=ciag-orchestra-toast.mjs.map
