import * as i0 from '@angular/core';
import { inject, ElementRef, signal, ChangeDetectionStrategy, Component, ViewContainerRef, Renderer2, input, numberAttribute, booleanAttribute, computed, effect, untracked, HostListener, Directive } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { overlayAttachmentTarget, registerOverlay } from '@ciag/orchestra/internal';

class TooltipComponent {
    elementRef = inject((ElementRef));
    text = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    theme = signal('dark', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    position = signal('top', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    actualPosition = signal('top', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "actualPosition" }] : /* istanbul ignore next */ []));
    visible = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    id = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    styleClass = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: TooltipComponent, isStandalone: true, selector: "orc-tooltip-overlay", ngImport: i0, template: "<div\n  class=\"orc-tooltip\"\n  [class.orc-tooltip--visible]=\"visible()\"\n  [class.orc-tooltip--dark]=\"theme() === 'dark'\"\n  [class.orc-tooltip--light]=\"theme() === 'light'\"\n  [class.orc-tooltip--top]=\"actualPosition() === 'top'\"\n  [class.orc-tooltip--bottom]=\"actualPosition() === 'bottom'\"\n  [class.orc-tooltip--left]=\"actualPosition() === 'left'\"\n  [class.orc-tooltip--right]=\"actualPosition() === 'right'\"\n  [attr.id]=\"id()\"\n  [class]=\"styleClass()\"\n  role=\"tooltip\"\n  [attr.aria-hidden]=\"!visible()\"\n>\n  <span class=\"orc-tooltip__text\">{{ text() }}</span>\n\n  <!-- Arrow SVG Polygon -->\n  <svg class=\"orc-tooltip__arrow\" viewBox=\"0 0 14 7\" aria-hidden=\"true\">\n    <path d=\"M0 0 L7 7 L14 0 Z\" />\n  </svg>\n</div>\n", styles: [":host{position:fixed;z-index:9999;pointer-events:none;display:block}.orc-tooltip{position:relative;display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:10px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:400;line-height:20px;white-space:nowrap;box-shadow:var(--orc-shadow-overlay, var(--shadow-lg));transition:opacity .15s cubic-bezier(.16,1,.3,1),transform .15s cubic-bezier(.16,1,.3,1);opacity:0}.orc-tooltip--visible{opacity:1}.orc-tooltip--dark{background-color:var(--bg-inverse, var(--orc-font-main, #141414));color:var(--text-inverse, #FFFFFF)}.orc-tooltip--dark .orc-tooltip__arrow{color:var(--bg-inverse, var(--orc-font-main, #141414))}.orc-tooltip--light{background-color:var(--orc-surface-muted, var(--orc-secondary-bg, #D9D9D9));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-tooltip--light .orc-tooltip__arrow{color:var(--orc-surface-muted, var(--orc-secondary-bg, #D9D9D9))}.orc-tooltip__arrow{position:absolute;width:14px;height:7px;fill:currentColor;display:block;pointer-events:none}.orc-tooltip--top{transform:translateY(4px)}.orc-tooltip--top.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--top .orc-tooltip__arrow{bottom:-6px;left:50%;transform:translate(-50%)}.orc-tooltip--bottom{transform:translateY(-4px)}.orc-tooltip--bottom.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--bottom .orc-tooltip__arrow{top:-6px;left:50%;transform:translate(-50%) rotate(180deg)}.orc-tooltip--left{transform:translate(4px)}.orc-tooltip--left.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--left .orc-tooltip__arrow{right:-10px;top:50%;transform:translateY(-50%) rotate(-90deg);width:14px;height:7px}.orc-tooltip--right{transform:translate(-4px)}.orc-tooltip--right.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--right .orc-tooltip__arrow{left:-10px;top:50%;transform:translateY(-50%) rotate(90deg);width:14px;height:7px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tooltip-overlay', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-tooltip\"\n  [class.orc-tooltip--visible]=\"visible()\"\n  [class.orc-tooltip--dark]=\"theme() === 'dark'\"\n  [class.orc-tooltip--light]=\"theme() === 'light'\"\n  [class.orc-tooltip--top]=\"actualPosition() === 'top'\"\n  [class.orc-tooltip--bottom]=\"actualPosition() === 'bottom'\"\n  [class.orc-tooltip--left]=\"actualPosition() === 'left'\"\n  [class.orc-tooltip--right]=\"actualPosition() === 'right'\"\n  [attr.id]=\"id()\"\n  [class]=\"styleClass()\"\n  role=\"tooltip\"\n  [attr.aria-hidden]=\"!visible()\"\n>\n  <span class=\"orc-tooltip__text\">{{ text() }}</span>\n\n  <!-- Arrow SVG Polygon -->\n  <svg class=\"orc-tooltip__arrow\" viewBox=\"0 0 14 7\" aria-hidden=\"true\">\n    <path d=\"M0 0 L7 7 L14 0 Z\" />\n  </svg>\n</div>\n", styles: [":host{position:fixed;z-index:9999;pointer-events:none;display:block}.orc-tooltip{position:relative;display:inline-flex;align-items:center;justify-content:center;padding:10px 14px;border-radius:10px;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px;font-weight:400;line-height:20px;white-space:nowrap;box-shadow:var(--orc-shadow-overlay, var(--shadow-lg));transition:opacity .15s cubic-bezier(.16,1,.3,1),transform .15s cubic-bezier(.16,1,.3,1);opacity:0}.orc-tooltip--visible{opacity:1}.orc-tooltip--dark{background-color:var(--bg-inverse, var(--orc-font-main, #141414));color:var(--text-inverse, #FFFFFF)}.orc-tooltip--dark .orc-tooltip__arrow{color:var(--bg-inverse, var(--orc-font-main, #141414))}.orc-tooltip--light{background-color:var(--orc-surface-muted, var(--orc-secondary-bg, #D9D9D9));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-tooltip--light .orc-tooltip__arrow{color:var(--orc-surface-muted, var(--orc-secondary-bg, #D9D9D9))}.orc-tooltip__arrow{position:absolute;width:14px;height:7px;fill:currentColor;display:block;pointer-events:none}.orc-tooltip--top{transform:translateY(4px)}.orc-tooltip--top.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--top .orc-tooltip__arrow{bottom:-6px;left:50%;transform:translate(-50%)}.orc-tooltip--bottom{transform:translateY(-4px)}.orc-tooltip--bottom.orc-tooltip--visible{transform:translateY(0)}.orc-tooltip--bottom .orc-tooltip__arrow{top:-6px;left:50%;transform:translate(-50%) rotate(180deg)}.orc-tooltip--left{transform:translate(4px)}.orc-tooltip--left.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--left .orc-tooltip__arrow{right:-10px;top:50%;transform:translateY(-50%) rotate(-90deg);width:14px;height:7px}.orc-tooltip--right{transform:translate(-4px)}.orc-tooltip--right.orc-tooltip--visible{transform:translate(0)}.orc-tooltip--right .orc-tooltip__arrow{left:-10px;top:50%;transform:translateY(-50%) rotate(90deg);width:14px;height:7px}\n"] }]
        }] });

let nextUniqueId = 0;
class TooltipDirective {
    elementRef = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    renderer = inject(Renderer2);
    // ── Inputs (Signals API) ──────────────────────────────────
    appTooltip = input('', { ...(ngDevMode ? { debugName: "appTooltip" } : /* istanbul ignore next */ {}), alias: 'appTooltip' });
    uiTooltip = input('', { ...(ngDevMode ? { debugName: "uiTooltip" } : /* istanbul ignore next */ {}), alias: 'uiTooltip' });
    orcTooltip = input('', { ...(ngDevMode ? { debugName: "orcTooltip" } : /* istanbul ignore next */ {}), alias: 'orcTooltip' });
    tooltipPosition = input('top', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : /* istanbul ignore next */ []));
    tooltipTheme = input('dark', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipTheme" }] : /* istanbul ignore next */ []));
    tooltipShowDelay = input(150, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipShowDelay" }] : /* istanbul ignore next */ []));
    tooltipHideDelay = input(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipHideDelay" }] : /* istanbul ignore next */ []));
    showDelay = input(undefined, { ...(ngDevMode ? { debugName: "showDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    hideDelay = input(undefined, { ...(ngDevMode ? { debugName: "hideDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    tooltipEvent = input('both', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipEvent" }] : /* istanbul ignore next */ []));
    positionStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "positionStyle" }] : /* istanbul ignore next */ []));
    tooltipStyleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipStyleClass" }] : /* istanbul ignore next */ []));
    tooltipZIndex = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipZIndex" }] : /* istanbul ignore next */ []));
    escape = input(true, { ...(ngDevMode ? { debugName: "escape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    life = input(undefined, { ...(ngDevMode ? { debugName: "life" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    fitContent = input(true, { ...(ngDevMode ? { debugName: "fitContent" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    content = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    tooltipOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipOptions" }] : /* istanbul ignore next */ []));
    position = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    autoHide = input(true, { ...(ngDevMode ? { debugName: "autoHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    hideOnEscape = input(true, { ...(ngDevMode ? { debugName: "hideOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tooltipDisabled = input(false, { ...(ngDevMode ? { debugName: "tooltipDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    appendTo = input('body', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    // Texto efetivo do tooltip
    tooltipText = computed(() => {
        return (this.content() ||
            this.appTooltip() ||
            this.uiTooltip() ||
            this.orcTooltip() ||
            '');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipText" }] : /* istanbul ignore next */ []));
    effectiveShowDelay = computed(() => this.showDelay() ?? this.tooltipShowDelay(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveShowDelay" }] : /* istanbul ignore next */ []));
    effectiveHideDelay = computed(() => this.hideDelay() ?? this.tooltipHideDelay(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveHideDelay" }] : /* istanbul ignore next */ []));
    effectivePosition = computed(() => this.position() ?? this.tooltipPosition(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePosition" }] : /* istanbul ignore next */ []));
    componentRef = null;
    showTimeoutId = null;
    hideTimeoutId = null;
    tooltipId = `orc-tooltip-${++nextUniqueId}`;
    document = inject(DOCUMENT);
    hovered = false;
    focused = false;
    frame = null;
    lifetimeTimer = null;
    fading = new Map();
    stopPositioning;
    releaseLayer;
    constructor() {
        effect(() => {
            const disabled = this.tooltipDisabled();
            const text = this.tooltipText();
            const theme = this.tooltipTheme();
            const position = this.effectivePosition();
            untracked(() => {
                if (disabled || !text)
                    this.hideImmediately();
                else if (this.componentRef) {
                    this.componentRef.instance.text.set(text);
                    this.componentRef.instance.theme.set(theme);
                    this.componentRef.instance.position.set(position);
                    this.componentRef.changeDetectorRef.detectChanges();
                    this.updatePosition();
                }
            });
        });
    }
    onMouseEnter() {
        if (this.tooltipEvent() === 'focus')
            return;
        this.hovered = true;
        this.scheduleShow();
    }
    onMouseLeave() {
        this.hovered = false;
        if (this.tooltipEvent() === 'focus' || !this.autoHide() || this.focused)
            return;
        this.scheduleHide();
    }
    onFocusIn() {
        if (this.tooltipEvent() === 'hover')
            return;
        this.focused = true;
        this.scheduleShow();
    }
    onFocusOut(event) {
        if (event?.relatedTarget &&
            this.elementRef.nativeElement.contains(event.relatedTarget))
            return;
        this.focused = false;
        if (this.tooltipEvent() === 'hover' || this.hovered)
            return;
        this.scheduleHide();
    }
    onEscape() {
        if (!this.escape() || !this.hideOnEscape())
            return;
        this.hideImmediately();
    }
    scheduleShow() {
        if (this.tooltipDisabled() || !this.tooltipText())
            return;
        this.clearHideTimeout();
        this.clearShowTimeout();
        if (this.componentRef)
            return;
        const delay = this.effectiveShowDelay();
        if (delay <= 0) {
            this.show();
        }
        else {
            this.showTimeoutId = setTimeout(() => this.show(), delay);
        }
    }
    scheduleHide() {
        this.clearShowTimeout();
        this.clearHideTimeout();
        if (!this.componentRef)
            return;
        const delay = this.effectiveHideDelay();
        if (delay <= 0) {
            this.hide();
        }
        else {
            this.hideTimeoutId = setTimeout(() => this.hide(), delay);
        }
    }
    show() {
        if (this.componentRef || this.tooltipDisabled() || !this.tooltipText())
            return;
        // Instancia o componente do tooltip
        this.componentRef = this.viewContainerRef.createComponent(TooltipComponent);
        const instance = this.componentRef.instance;
        instance.text.set(this.tooltipText());
        instance.theme.set(this.tooltipTheme());
        instance.position.set(this.effectivePosition());
        instance.id.set(this.tooltipId);
        instance.styleClass.set([this.styleClass(), this.tooltipStyleClass() || '']
            .filter(Boolean)
            .join(' '));
        const domElement = this.componentRef.location.nativeElement;
        this.renderer.appendChild(overlayAttachmentTarget(this.elementRef.nativeElement, this.appendTo()), domElement);
        this.releaseLayer = registerOverlay(domElement, {
            interactive: false,
            anchor: this.elementRef.nativeElement,
            onParentClose: () => this.hideImmediately(),
        });
        // The tooltip starts with empty signal values. Render the new inputs before
        // measuring it, otherwise positioning uses the empty shell's dimensions
        // and becomes offset when the text is rendered on the next change-detection
        // pass.
        this.componentRef.changeDetectorRef.detectChanges();
        // WCAG A11y
        const describedBy = this.elementRef.nativeElement.getAttribute('aria-describedby');
        this.renderer.setAttribute(this.elementRef.nativeElement, 'aria-describedby', [describedBy, this.tooltipId].filter(Boolean).join(' '));
        // Posicionamento inteligente com verificação de colisão
        this.updatePosition();
        if (this.tooltipZIndex())
            this.renderer.setStyle(domElement, 'z-index', this.tooltipZIndex());
        if (this.positionStyle())
            this.renderer.setStyle(domElement, 'position', this.positionStyle());
        // Fade-in animado no próximo frame
        const window = this.document.defaultView;
        if (!window)
            return;
        this.startPositioning();
        this.frame = window.requestAnimationFrame(() => {
            this.frame = null;
            if (this.componentRef) {
                this.componentRef.instance.visible.set(true);
                const lifetime = this.life();
                if (lifetime && lifetime > 0)
                    this.lifetimeTimer = setTimeout(() => this.hideImmediately(), lifetime);
            }
        });
    }
    hide() {
        if (!this.componentRef)
            return;
        this.stopLiveResources();
        this.componentRef.instance.visible.set(false);
        const ref = this.componentRef;
        this.componentRef = null;
        // Remove aria-describedby
        this.restoreDescribedBy();
        // Remove do DOM após a transição de fade-out
        const timer = setTimeout(() => {
            this.fading.delete(ref);
            ref.destroy();
        }, 150);
        this.fading.set(ref, timer);
    }
    hideImmediately() {
        this.clearShowTimeout();
        this.clearHideTimeout();
        this.stopLiveResources();
        for (const [ref, timer] of this.fading) {
            clearTimeout(timer);
            ref.destroy();
        }
        this.fading.clear();
        if (this.componentRef) {
            this.restoreDescribedBy();
            this.componentRef.destroy();
            this.componentRef = null;
        }
    }
    restoreDescribedBy() {
        const host = this.elementRef.nativeElement;
        const tokens = (host.getAttribute('aria-describedby') ?? '')
            .split(/\s+/)
            .filter((token) => token && token !== this.tooltipId);
        if (tokens.length)
            this.renderer.setAttribute(host, 'aria-describedby', tokens.join(' '));
        else
            this.renderer.removeAttribute(host, 'aria-describedby');
    }
    startPositioning() {
        const window = this.document.defaultView;
        if (!window)
            return;
        const update = () => this.updatePosition();
        this.document.addEventListener('scroll', update, true);
        window.addEventListener('resize', update);
        this.stopPositioning = () => {
            this.document.removeEventListener('scroll', update, true);
            window.removeEventListener('resize', update);
        };
    }
    stopLiveResources() {
        this.releaseLayer?.();
        this.releaseLayer = undefined;
        if (this.frame !== null)
            this.document.defaultView?.cancelAnimationFrame(this.frame);
        this.frame = null;
        if (this.lifetimeTimer !== null)
            clearTimeout(this.lifetimeTimer);
        this.lifetimeTimer = null;
        this.stopPositioning?.();
        this.stopPositioning = undefined;
    }
    updatePosition() {
        if (!this.componentRef)
            return;
        const triggerEl = this.elementRef.nativeElement;
        const tooltipHost = this.componentRef.location.nativeElement;
        const tooltipEl = tooltipHost.firstElementChild;
        if (!tooltipEl)
            return;
        const triggerRect = triggerEl.getBoundingClientRect();
        const tooltipRect = tooltipEl.getBoundingClientRect();
        const margin = 8;
        let pos = this.effectivePosition();
        const window = this.document.defaultView;
        if (!window)
            return;
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        // Verificação de espaço e inversão automática (Auto-Flip)
        if (pos === 'top' && triggerRect.top - tooltipRect.height - margin < 0) {
            pos = 'bottom';
        }
        else if (pos === 'bottom' &&
            triggerRect.bottom + tooltipRect.height + margin > viewportHeight) {
            pos = 'top';
        }
        else if (pos === 'left' &&
            triggerRect.left - tooltipRect.width - margin < 0) {
            pos = 'right';
        }
        else if (pos === 'right' &&
            triggerRect.right + tooltipRect.width + margin > viewportWidth) {
            pos = 'left';
        }
        this.componentRef.instance.actualPosition.set(pos);
        let top = 0;
        let left = 0;
        switch (pos) {
            case 'top':
                top = triggerRect.top - tooltipRect.height - margin;
                left = triggerRect.left + (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'bottom':
                top = triggerRect.bottom + margin;
                left = triggerRect.left + (triggerRect.width - tooltipRect.width) / 2;
                break;
            case 'left':
                top = triggerRect.top + (triggerRect.height - tooltipRect.height) / 2;
                left = triggerRect.left - tooltipRect.width - margin;
                break;
            case 'right':
                top = triggerRect.top + (triggerRect.height - tooltipRect.height) / 2;
                left = triggerRect.right + margin;
                break;
        }
        // Garante que não ultrapassa as bordas laterais da viewport
        left = Math.max(8, Math.min(left, viewportWidth - tooltipRect.width - 8));
        top = Math.max(8, Math.min(top, viewportHeight - tooltipRect.height - 8));
        this.renderer.setStyle(tooltipHost, 'top', `${top}px`);
        this.renderer.setStyle(tooltipHost, 'left', `${left}px`);
    }
    clearShowTimeout() {
        if (this.showTimeoutId) {
            clearTimeout(this.showTimeoutId);
            this.showTimeoutId = null;
        }
    }
    clearHideTimeout() {
        if (this.hideTimeoutId) {
            clearTimeout(this.hideTimeoutId);
            this.hideTimeoutId = null;
        }
    }
    ngOnDestroy() {
        this.hideImmediately();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TooltipDirective, isStandalone: true, selector: "[orcTooltip]", inputs: { appTooltip: { classPropertyName: "appTooltip", publicName: "appTooltip", isSignal: true, isRequired: false, transformFunction: null }, uiTooltip: { classPropertyName: "uiTooltip", publicName: "uiTooltip", isSignal: true, isRequired: false, transformFunction: null }, orcTooltip: { classPropertyName: "orcTooltip", publicName: "orcTooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, tooltipTheme: { classPropertyName: "tooltipTheme", publicName: "tooltipTheme", isSignal: true, isRequired: false, transformFunction: null }, tooltipShowDelay: { classPropertyName: "tooltipShowDelay", publicName: "tooltipShowDelay", isSignal: true, isRequired: false, transformFunction: null }, tooltipHideDelay: { classPropertyName: "tooltipHideDelay", publicName: "tooltipHideDelay", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null }, tooltipEvent: { classPropertyName: "tooltipEvent", publicName: "tooltipEvent", isSignal: true, isRequired: false, transformFunction: null }, positionStyle: { classPropertyName: "positionStyle", publicName: "positionStyle", isSignal: true, isRequired: false, transformFunction: null }, tooltipStyleClass: { classPropertyName: "tooltipStyleClass", publicName: "tooltipStyleClass", isSignal: true, isRequired: false, transformFunction: null }, tooltipZIndex: { classPropertyName: "tooltipZIndex", publicName: "tooltipZIndex", isSignal: true, isRequired: false, transformFunction: null }, escape: { classPropertyName: "escape", publicName: "escape", isSignal: true, isRequired: false, transformFunction: null }, life: { classPropertyName: "life", publicName: "life", isSignal: true, isRequired: false, transformFunction: null }, fitContent: { classPropertyName: "fitContent", publicName: "fitContent", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, tooltipOptions: { classPropertyName: "tooltipOptions", publicName: "tooltipOptions", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, autoHide: { classPropertyName: "autoHide", publicName: "autoHide", isSignal: true, isRequired: false, transformFunction: null }, hideOnEscape: { classPropertyName: "hideOnEscape", publicName: "hideOnEscape", isSignal: true, isRequired: false, transformFunction: null }, tooltipDisabled: { classPropertyName: "tooltipDisabled", publicName: "tooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "mouseenter": "onMouseEnter()", "mouseleave": "onMouseLeave()", "focusin": "onFocusIn()", "focusout": "onFocusOut($event)", "keydown.escape": "onEscape()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[orcTooltip]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { appTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "appTooltip", required: false }] }], uiTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "uiTooltip", required: false }] }], orcTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "orcTooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], tooltipTheme: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipTheme", required: false }] }], tooltipShowDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipShowDelay", required: false }] }], tooltipHideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipHideDelay", required: false }] }], showDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelay", required: false }] }], hideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideDelay", required: false }] }], tooltipEvent: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipEvent", required: false }] }], positionStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "positionStyle", required: false }] }], tooltipStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipStyleClass", required: false }] }], tooltipZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipZIndex", required: false }] }], escape: [{ type: i0.Input, args: [{ isSignal: true, alias: "escape", required: false }] }], life: [{ type: i0.Input, args: [{ isSignal: true, alias: "life", required: false }] }], fitContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "fitContent", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], tooltipOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipOptions", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], autoHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHide", required: false }] }], hideOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideOnEscape", required: false }] }], tooltipDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipDisabled", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }], onFocusIn: [{
                type: HostListener,
                args: ['focusin']
            }], onFocusOut: [{
                type: HostListener,
                args: ['focusout', ['$event']]
            }], onEscape: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { TooltipComponent, TooltipDirective };
//# sourceMappingURL=ciag-orchestra-tooltip.mjs.map
