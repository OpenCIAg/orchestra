export { InputComponent as TextInputComponent } from '@ciag/orchestra/input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-text-input.mjs.map
