export * from '@ciag/orchestra/ifta-label';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-iftalabel.mjs.map
