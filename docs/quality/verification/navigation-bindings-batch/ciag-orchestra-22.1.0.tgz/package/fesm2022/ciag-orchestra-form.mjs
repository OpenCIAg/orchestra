import * as i0 from '@angular/core';
import { viewChild, input, booleanAttribute, output, HostListener, ChangeDetectionStrategy, Component } from '@angular/core';

class FormComponent {
    nativeForm = viewChild('nativeForm', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeForm" }] : /* istanbul ignore next */ []));
    layout = input('stacked', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    novalidate = input(true, { ...(ngDevMode ? { debugName: "novalidate" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    formSubmit = output();
    formReset = output();
    onSubmit(event) {
        event.preventDefault();
        const form = this.nativeForm()?.nativeElement;
        if (!form || this.disabled())
            return;
        const valid = form.checkValidity();
        if (!valid) {
            form.reportValidity();
        }
        this.formSubmit.emit({ event, valid });
    }
    onReset() { this.formReset.emit(); }
    reset() { this.nativeForm()?.nativeElement.reset(); }
    submit() { this.nativeForm()?.nativeElement.requestSubmit(); }
    onKeydown(event) { if (this.disabled() && event.key === 'Enter')
        event.preventDefault(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: FormComponent, isStandalone: true, selector: "orc-form", inputs: { layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, novalidate: { classPropertyName: "novalidate", publicName: "novalidate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { formSubmit: "formSubmit", formReset: "formReset" }, host: { listeners: { "keydown": "onKeydown($event)" } }, viewQueries: [{ propertyName: "nativeForm", first: true, predicate: ["nativeForm"], descendants: true, isSignal: true }], ngImport: i0, template: "<form #nativeForm class=\"orc-form\" [class.orc-form--inline]=\"layout() === 'inline'\" [attr.name]=\"name() || null\" [attr.aria-label]=\"ariaLabel()\" [attr.novalidate]=\"novalidate() ? '' : null\" [class.orc-form--disabled]=\"disabled()\" (submit)=\"onSubmit($event)\" (reset)=\"onReset()\">\n  <fieldset [disabled]=\"disabled()\"><ng-content /></fieldset>\n</form>\n", styles: [":host{display:block;width:100%}.orc-form{width:100%}.orc-form fieldset{display:grid;gap:16px;min-width:0;margin:0;padding:0;border:0}.orc-form--inline fieldset{grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end}.orc-form--disabled{opacity:.6}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-form', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<form #nativeForm class=\"orc-form\" [class.orc-form--inline]=\"layout() === 'inline'\" [attr.name]=\"name() || null\" [attr.aria-label]=\"ariaLabel()\" [attr.novalidate]=\"novalidate() ? '' : null\" [class.orc-form--disabled]=\"disabled()\" (submit)=\"onSubmit($event)\" (reset)=\"onReset()\">\n  <fieldset [disabled]=\"disabled()\"><ng-content /></fieldset>\n</form>\n", styles: [":host{display:block;width:100%}.orc-form{width:100%}.orc-form fieldset{display:grid;gap:16px;min-width:0;margin:0;padding:0;border:0}.orc-form--inline fieldset{grid-template-columns:repeat(auto-fit,minmax(180px,1fr));align-items:end}.orc-form--disabled{opacity:.6}\n"] }]
        }], propDecorators: { nativeForm: [{ type: i0.ViewChild, args: ['nativeForm', { isSignal: true }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], novalidate: [{ type: i0.Input, args: [{ isSignal: true, alias: "novalidate", required: false }] }], formSubmit: [{ type: i0.Output, args: ["formSubmit"] }], formReset: [{ type: i0.Output, args: ["formReset"] }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FormComponent };
//# sourceMappingURL=ciag-orchestra-form.mjs.map
