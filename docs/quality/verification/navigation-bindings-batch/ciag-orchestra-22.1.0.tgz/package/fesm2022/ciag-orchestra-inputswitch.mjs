export * from '@ciag/orchestra/switch';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-inputswitch.mjs.map
