import * as i0 from '@angular/core';
import { output, Directive } from '@angular/core';

class DeferDirective {
    template;
    container;
    host;
    onLoad = output();
    observer;
    view;
    loaded = false;
    constructor(template, container, host) {
        this.template = template;
        this.container = container;
        this.host = host;
    }
    ngAfterViewInit() {
        if (typeof IntersectionObserver === 'undefined') {
            this.load();
            return;
        }
        const anchor = this.host.nativeElement;
        // Structural directives are attached to an ng-template comment. Observe a
        // real containing element when available; IntersectionObserver rejects
        // comment nodes in browsers.
        const target = anchor instanceof Element ? anchor : anchor.parentElement;
        if (!target) {
            this.load();
            return;
        }
        this.observer = new IntersectionObserver(entries => {
            if (entries.some(entry => entry.isIntersecting))
                this.load();
        });
        this.observer.observe(target);
    }
    shouldLoad() { return !this.loaded; }
    isLoaded() { return this.loaded; }
    load(event) {
        if (this.loaded)
            return;
        this.loaded = true;
        this.view = this.container.createEmbeddedView(this.template);
        this.onLoad.emit(event ?? new Event('load'));
        this.observer?.disconnect();
    }
    ngOnDestroy() { this.observer?.disconnect(); this.view?.destroy(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DeferDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: DeferDirective, isStandalone: true, selector: "[orcDefer], [pDefer]", outputs: { onLoad: "onLoad" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DeferDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[orcDefer], [pDefer]', standalone: true }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }, { type: i0.ElementRef }], propDecorators: { onLoad: [{ type: i0.Output, args: ["onLoad"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DeferDirective };
//# sourceMappingURL=ciag-orchestra-defer.mjs.map
