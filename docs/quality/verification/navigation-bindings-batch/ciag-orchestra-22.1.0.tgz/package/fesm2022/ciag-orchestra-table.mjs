import * as i0 from '@angular/core';
import { inject, TemplateRef, Directive, input, booleanAttribute, contentChild, model, output, linkedSignal, contentChildren, computed, ChangeDetectionStrategy, Component, forwardRef } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { CheckboxComponent } from '@ciag/orchestra/checkbox';
import { PaginatorComponent } from '@ciag/orchestra/paginator';
import { SkeletonComponent } from '@ciag/orchestra/skeleton';

class CellDefDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: CellDefDirective, isStandalone: true, selector: "[orcCellDef], [appCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[orcCellDef], [appCellDef]',
                    standalone: true,
                }]
        }] });
class HeaderCellDefDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: HeaderCellDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: HeaderCellDefDirective, isStandalone: true, selector: "[orcHeaderCellDef], [appHeaderCellDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: HeaderCellDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[orcHeaderCellDef], [appHeaderCellDef]',
                    standalone: true,
                }]
        }] });

class ColumnDirective {
    /** Chave do objeto que identifica a propriedade da coluna */
    key = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "key" }] : /* istanbul ignore next */ []));
    /** Título do cabeçalho da coluna */
    header = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    /** Habilita ordenação para esta coluna */
    sortable = input(false, { ...(ngDevMode ? { debugName: "sortable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Largura customizada da coluna (ex: '120px', '20%') */
    width = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    /** Alinhamento do conteúdo: 'left' | 'center' | 'right' */
    align = input('left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    /** Template customizado de corpo da célula */
    cellTemplate = contentChild(CellDefDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cellTemplate" }] : /* istanbul ignore next */ []));
    /** Template customizado de cabeçalho da coluna */
    headerTemplate = contentChild(HeaderCellDefDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.1.2", type: ColumnDirective, isStandalone: true, selector: "orc-column, app-column", inputs: { key: { classPropertyName: "key", publicName: "key", isSignal: true, isRequired: true, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, sortable: { classPropertyName: "sortable", publicName: "sortable", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "cellTemplate", first: true, predicate: CellDefDirective, descendants: true, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: HeaderCellDefDirective, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'orc-column, app-column',
                    standalone: true,
                }]
        }], propDecorators: { key: [{ type: i0.Input, args: [{ isSignal: true, alias: "key", required: true }] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], sortable: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortable", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], cellTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CellDefDirective), { isSignal: true }] }], headerTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => HeaderCellDefDirective), { isSignal: true }] }] } });

class TableFooterDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableFooterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: TableFooterDirective, isStandalone: true, selector: "[orcTableFooter]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableFooterDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[orcTableFooter]', standalone: true }]
        }] });
class TableRowExpansionDirective {
    templateRef = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableRowExpansionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: TableRowExpansionDirective, isStandalone: true, selector: "[orcRowExpansion]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableRowExpansionDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[orcRowExpansion]', standalone: true }]
        }] });

/** Resolve a configured field consistently for cells, sorting, filtering and IDs. */
function tableField(row, field) {
    if (row === null || typeof row !== 'object')
        return undefined;
    const record = row;
    if (Object.prototype.hasOwnProperty.call(record, field))
        return record[field];
    return field
        .split('.')
        .reduce((value, key) => value !== null && typeof value === 'object'
        ? value[key]
        : undefined, row);
}
function positiveTableInteger(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) && number >= 1 ? Math.floor(number) : fallback;
}
function tableOffset(value) {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
}
/** Nested interactive controls keep their own click and keyboard activation. */
const tableInteractiveRoles = new Set([
    'button',
    'checkbox',
    'combobox',
    'gridcell',
    'link',
    'listbox',
    'menuitem',
    'option',
    'radio',
    'searchbox',
    'slider',
    'spinbutton',
    'switch',
    'tab',
    'textbox',
]);
function isTableControlEvent(event) {
    const currentTarget = event.currentTarget;
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    const candidates = path.length
        ? path
        : event.target instanceof Element
            ? [event.target]
            : [];
    for (const candidate of candidates) {
        if (candidate === currentTarget)
            break;
        if (!(candidate instanceof Element))
            continue;
        const role = candidate.getAttribute('role')?.toLowerCase();
        const tabIndex = candidate.getAttribute('tabindex');
        const focusable = tabIndex !== null &&
            Number.isInteger(Number(tabIndex)) &&
            Number(tabIndex) >= 0;
        if (candidate.matches('button, a[href], input, select, textarea, summary, [contenteditable]:not([contenteditable="false"])') ||
            tableInteractiveRoles.has(role ?? '') ||
            focusable) {
            return true;
        }
    }
    return false;
}

/** Escape one CSV field using the delimiter selected by the table consumer. */
function escapeTableCsvField(value, separator) {
    const text = String(value ?? '');
    const needsQuotes = text.includes('"') ||
        text.includes('\n') ||
        text.includes('\r') ||
        (separator.length > 0 && text.includes(separator));
    return needsQuotes ? `"${text.replace(/"/g, '""')}"` : text;
}
/**
 * Build the CSV payload. `customHeader` is intentionally a complete, raw
 * header line for compatibility with the existing exportHeader input.
 */
function buildTableCsv(rows, columns, separator, customHeader, getValue = (row, key) => row[key]) {
    const header = customHeader ??
        columns
            .map((column) => escapeTableCsvField(column.header, separator))
            .join(separator);
    // There are no meaningful body fields when no columns were configured.
    if (columns.length === 0)
        return header;
    const body = rows
        .map((row) => columns
        .map((column) => escapeTableCsvField(getValue(row, column.key), separator))
        .join(separator))
        .join('\n');
    return header + (rows.length > 0 ? `\n${body}` : '');
}

const token = (kind, value) => `${kind}${value.length}:${value}`;
function isPlainObject(value) {
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
}
function serializeSelectionValue(value, ancestors, path) {
    if (value === undefined)
        return token('undefined', '');
    if (value === null)
        return token('null', '');
    switch (typeof value) {
        case 'string':
            return token('string', value);
        case 'boolean':
            return token('boolean', value ? 'true' : 'false');
        case 'number':
            if (Number.isNaN(value))
                return token('number', 'NaN');
            if (Object.is(value, -0))
                return token('number', '-0');
            if (value === Infinity)
                return token('number', 'Infinity');
            if (value === -Infinity)
                return token('number', '-Infinity');
            return token('number', String(value));
        case 'bigint':
            return token('bigint', String(value));
        case 'symbol':
        case 'function':
            return undefined;
    }
    if (value instanceof Date) {
        const timestamp = value.getTime();
        return token('date', Number.isNaN(timestamp) ? 'invalid' : String(timestamp));
    }
    if (!Array.isArray(value) && !isPlainObject(value))
        return undefined;
    // Symbol-keyed records are outside the structural contract. Retain their
    // identity rather than silently treating them as an empty plain object.
    if (Object.getOwnPropertySymbols(value).length > 0)
        return undefined;
    const reference = ancestors.get(value);
    if (reference !== undefined)
        return token('reference', reference);
    ancestors.set(value, path);
    try {
        if (Array.isArray(value)) {
            let result = token('array-length', String(value.length)) + '[';
            for (let index = 0; index < value.length; index += 1) {
                if (!Object.prototype.hasOwnProperty.call(value, index)) {
                    result += token('hole', '');
                    continue;
                }
                const child = serializeSelectionValue(value[index], ancestors, `${path}${token('array-index', String(index))}`);
                if (child === undefined)
                    return undefined;
                result += child;
            }
            return result + ']';
        }
        const keys = Object.keys(value).sort();
        let result = '{';
        for (const key of keys) {
            const child = serializeSelectionValue(value[key], ancestors, `${path}${token('object-key', key)}`);
            if (child === undefined)
                return undefined;
            result += token('key', key) + child;
        }
        return result + '}';
    }
    finally {
        // Only ancestors become references. Shared acyclic values are serialized
        // independently, so sharing does not change deep value equality.
        ancestors.delete(value);
    }
}
/**
 * Produce a deterministic structural key for supported deep selection values.
 * Unsupported objects retain identity, matching equals-mode's documented
 * object fallback while keeping cyclic arrays and plain objects safe.
 */
function tableDeepSelectionKey(value) {
    try {
        const serialized = serializeSelectionValue(value, new Map(), 'root');
        return serialized === undefined ? value : `deep:${serialized}`;
    }
    catch {
        return value;
    }
}

class TableComponent {
    // ── Inputs de Dados e Configuração ────────────────────────
    /** Dados a serem exibidos na tabela */
    data = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    frozenColumns = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "frozenColumns" }] : /* istanbul ignore next */ []));
    frozenValue = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "frozenValue" }] : /* istanbul ignore next */ []));
    /** Configuração direta de colunas (alternativa ao uso de <orc-column>) */
    columnsConfig = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnsConfig" }] : /* istanbul ignore next */ []));
    /** Propriedade identificadora única de cada linha (padrão: 'id') */
    rowKey = input('id', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowKey" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    selectAllAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectAllAriaLabel" }] : /* istanbul ignore next */ []));
    rowAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowAriaLabel" }] : /* istanbul ignore next */ []));
    // ── Seleção de Linhas ─────────────────────────────────────
    /** Habilita seleção de linhas com checkbox na primeira coluna */
    selectable = input(false, { ...(ngDevMode ? { debugName: "selectable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectionMode = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    /** Linhas selecionadas (Two-Way Binding) */
    selectedRows = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedRows" }] : /* istanbul ignore next */ []));
    /** Evento emitido quando a seleção muda */
    selectionChange = output();
    rowSelect = output();
    rowUnselect = output();
    onRowSelect = output();
    onRowUnselect = output();
    selectAllChange = output();
    // ── Ordenação ─────────────────────────────────────────────
    /** Chave da coluna ordenada atualmente */
    sortColumn = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortColumn" }] : /* istanbul ignore next */ []));
    /** Direção da ordenação atual: 'asc' | 'desc' | 'none' */
    sortDirection = model('none', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortDirection" }] : /* istanbul ignore next */ []));
    sortField = model('', { ...(ngDevMode ? { debugName: "sortField" } : /* istanbul ignore next */ {}), alias: 'sortField' });
    sortOrder = model(0, { ...(ngDevMode ? { debugName: "sortOrder" } : /* istanbul ignore next */ {}), alias: 'sortOrder' });
    sorting = linkedSignal({ ...(ngDevMode ? { debugName: "sorting" } : /* istanbul ignore next */ {}), source: () => ({
            column: this.sortColumn(),
            direction: this.sortDirection(),
            field: this.sortField(),
            order: this.sortOrder(),
        }),
        computation: (source, previous) => {
            const useAlias = previous
                ? source.field !== previous.source.field ||
                    source.order !== previous.source.order
                : !!source.field || source.order !== 0;
            return useAlias
                ? {
                    column: source.field,
                    direction: source.order > 0 ? 'asc' : source.order < 0 ? 'desc' : 'none',
                }
                : { column: source.column, direction: source.direction };
        } });
    /** Evento emitido quando o usuário clica para ordenar uma coluna */
    sortChange = output();
    onSort = output();
    // ── Estilos e Variantes Visuais (Figma Spec) ───────────────
    /** Linhas zebradas alternadas */
    striped = input(false, { ...(ngDevMode ? { debugName: "striped" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Bordas ao redor da tabela e células */
    bordered = input(true, { ...(ngDevMode ? { debugName: "bordered" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Realce visual no hover sobre as linhas */
    hoverable = input(true, { ...(ngDevMode ? { debugName: "hoverable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    tableStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableStyleClass" }] : /* istanbul ignore next */ []));
    tableStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableStyle" }] : /* istanbul ignore next */ []));
    rowHover = input(false, { ...(ngDevMode ? { debugName: "rowHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showGridlines = input(false, { ...(ngDevMode ? { debugName: "showGridlines" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    stripedRows = input(false, { ...(ngDevMode ? { debugName: "stripedRows" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    responsiveLayout = input('scroll', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "responsiveLayout" }] : /* istanbul ignore next */ []));
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    autoLayout = input(false, { ...(ngDevMode ? { debugName: "autoLayout" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollable = input(false, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollDirection = input('vertical', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollDirection" }] : /* istanbul ignore next */ []));
    scrollHeight = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    virtualScroll = input(false, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    virtualScrollItemSize = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualScrollItemSize" }] : /* istanbul ignore next */ []));
    virtualScrollOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    resizableColumns = input(false, { ...(ngDevMode ? { debugName: "resizableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    reorderableColumns = input(false, { ...(ngDevMode ? { debugName: "reorderableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    customSort = input(false, { ...(ngDevMode ? { debugName: "customSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showInitialSortBadge = input(true, { ...(ngDevMode ? { debugName: "showInitialSortBadge" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    exportFilename = input('download', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "exportFilename" }] : /* istanbul ignore next */ []));
    csvSeparator = input(',', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "csvSeparator" }] : /* istanbul ignore next */ []));
    exportHeader = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "exportHeader" }] : /* istanbul ignore next */ []));
    stateKey = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stateKey" }] : /* istanbul ignore next */ []));
    stateStorage = input('session', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stateStorage" }] : /* istanbul ignore next */ []));
    editMode = input('row', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editMode" }] : /* istanbul ignore next */ []));
    rowExpandMode = input('multiple', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowExpandMode" }] : /* istanbul ignore next */ []));
    groupRowsBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "groupRowsBy" }] : /* istanbul ignore next */ []));
    rowGroupMode = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowGroupMode" }] : /* istanbul ignore next */ []));
    rowTrackBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowTrackBy" }] : /* istanbul ignore next */ []));
    contextMenuSelection = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextMenuSelection" }] : /* istanbul ignore next */ []));
    contextMenuSelectionMode = input('separate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextMenuSelectionMode" }] : /* istanbul ignore next */ []));
    filters = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []));
    /** Consumer owns fetching, filtering and paging; the table only emits queries. */
    serverDriven = input(false, { ...(ngDevMode ? { debugName: "serverDriven" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    queryChange = output();
    filterDelay = input(300, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterDelay" }] : /* istanbul ignore next */ []));
    filterLocale = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    filterable = input(false, { ...(ngDevMode ? { debugName: "filterable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filterPlaceholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    filterAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterAriaLabel" }] : /* istanbul ignore next */ []));
    filter = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []));
    globalFilterFields = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "globalFilterFields" }] : /* istanbul ignore next */ []));
    onFilter = output();
    // ── Estados de Carregamento e Vazio ───────────────────────
    /** Exibe estado de carregamento com Skeletons */
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Quantidade de linhas skeleton a renderizar durante loading */
    loadingRowsCount = input(5, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingRowsCount" }] : /* istanbul ignore next */ []));
    /** Título principal do estado vazio */
    emptyTitle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyTitle" }] : /* istanbul ignore next */ []));
    /** Mensagem descritiva do estado vazio */
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    // ── Paginação Integrada ────────────────────────────────────
    /** Habilita rodapé com PaginatorComponent integrado */
    paginated = input(false, { ...(ngDevMode ? { debugName: "paginated" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    paginator = input(false, { ...(ngDevMode ? { debugName: "paginator" } : /* istanbul ignore next */ {}), alias: 'paginator',
        transform: booleanAttribute });
    /** Quantidade de itens por página (Two-Way Binding) */
    pageSize = model(5, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    rowsInput = input(undefined, { ...(ngDevMode ? { debugName: "rowsInput" } : /* istanbul ignore next */ {}), alias: 'rows' });
    first = model(0, { ...(ngDevMode ? { debugName: "first" } : /* istanbul ignore next */ {}), alias: 'first' });
    /** Página atual (1-indexed, Two-Way Binding) */
    currentPage = model(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []));
    /** Total de itens para paginação do lado do servidor (se omitido, usa data().length) */
    totalItems = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalItems" }] : /* istanbul ignore next */ []));
    totalRecords = input(undefined, { ...(ngDevMode ? { debugName: "totalRecords" } : /* istanbul ignore next */ {}), alias: 'totalRecords' });
    /** Opções de tamanho de página */
    pageSizeOptions = input([5, 10, 20, 50], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : /* istanbul ignore next */ []));
    rowsPerPageOptions = input(undefined, { ...(ngDevMode ? { debugName: "rowsPerPageOptions" } : /* istanbul ignore next */ {}), alias: 'rowsPerPageOptions' });
    pageLinks = input(5, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageLinks" }] : /* istanbul ignore next */ []));
    alwaysShowPaginator = input(true, { ...(ngDevMode ? { debugName: "alwaysShowPaginator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    paginatorPosition = input('bottom', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorPosition" }] : /* istanbul ignore next */ []));
    paginatorStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorStyleClass" }] : /* istanbul ignore next */ []));
    currentPageReportTemplate = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPageReportTemplate" }] : /* istanbul ignore next */ []));
    showCurrentPageReport = input(false, { ...(ngDevMode ? { debugName: "showCurrentPageReport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showJumpToPageDropdown = input(false, { ...(ngDevMode ? { debugName: "showJumpToPageDropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showJumpToPageInput = input(false, { ...(ngDevMode ? { debugName: "showJumpToPageInput" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showFirstLastIcon = input(false, { ...(ngDevMode ? { debugName: "showFirstLastIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showPageLinks = input(true, { ...(ngDevMode ? { debugName: "showPageLinks" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lazyLoadOnInit = input(true, { ...(ngDevMode ? { debugName: "lazyLoadOnInit" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    metaKeySelection = input(true, { ...(ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectionPageOnly = input(false, { ...(ngDevMode ? { debugName: "selectionPageOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dataKey = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dataKey" }] : /* istanbul ignore next */ []));
    rowSelectable = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowSelectable" }] : /* istanbul ignore next */ []));
    paginatorDropdownAppendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorDropdownAppendTo" }] : /* istanbul ignore next */ []));
    paginatorDropdownScrollHeight = input('400px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorDropdownScrollHeight" }] : /* istanbul ignore next */ []));
    virtualScrollDelay = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualScrollDelay" }] : /* istanbul ignore next */ []));
    contextMenu = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextMenu" }] : /* istanbul ignore next */ []));
    defaultSortOrder = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultSortOrder" }] : /* istanbul ignore next */ []));
    sortMode = input('single', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortMode" }] : /* istanbul ignore next */ []));
    resetPageOnSort = input(true, { ...(ngDevMode ? { debugName: "resetPageOnSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    compareSelectionBy = input('equals', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "compareSelectionBy" }] : /* istanbul ignore next */ []));
    loadingIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    showLoader = input(true, { ...(ngDevMode ? { debugName: "showLoader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onPage = output();
    onLazyLoad = output();
    onRowExpand = output();
    onRowCollapse = output();
    onContextMenuSelect = output();
    onColResize = output();
    onColReorder = output();
    onRowReorder = output();
    onEditInit = output();
    onEditComplete = output();
    onEditCancel = output();
    onHeaderCheckboxToggle = output();
    onStateSave = output();
    onStateRestore = output();
    sortFunction = output();
    // ── Evento de Clique na Linha ─────────────────────────────
    rowClick = output();
    // ── Diretivas Filhas (<orc-column>) ───────────────────────
    declaredColumns = contentChildren(ColumnDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "declaredColumns" }] : /* istanbul ignore next */ []));
    footerTemplate = contentChild(TableFooterDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerTemplate" }] : /* istanbul ignore next */ []));
    rowExpansionTemplate = contentChild(TableRowExpansionDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowExpansionTemplate" }] : /* istanbul ignore next */ []));
    expandedRows = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandedRows" }] : /* istanbul ignore next */ []));
    effectiveData = computed(() => this.value() ?? this.data(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveData" }] : /* istanbul ignore next */ []));
    effectivePageSize = linkedSignal({ ...(ngDevMode ? { debugName: "effectivePageSize" } : /* istanbul ignore next */ {}), source: () => ({ rows: this.rowsInput(), size: this.pageSize() }),
        computation: (source, previous) => positiveTableInteger(previous &&
            source.rows === previous.source.rows &&
            source.size !== previous.source.size
            ? source.size
            : (source.rows ?? source.size), 5) });
    requestedFirst = linkedSignal({ ...(ngDevMode ? { debugName: "requestedFirst" } : /* istanbul ignore next */ {}), source: () => ({
            first: this.first(),
            page: this.currentPage(),
            size: this.effectivePageSize(),
        }),
        computation: (source, previous) => {
            if (previous && source.first !== previous.source.first)
                return tableOffset(source.first);
            if (!previous && source.first)
                return tableOffset(source.first);
            return (positiveTableInteger(source.page, 1) - 1) * source.size;
        } });
    remoteData = computed(() => this.serverDriven() || this.lazy(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "remoteData" }] : /* istanbul ignore next */ []));
    effectiveRowsPerPageOptions = computed(() => this.rowsPerPageOptions() ?? this.pageSizeOptions(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveRowsPerPageOptions" }] : /* istanbul ignore next */ []));
    effectivePaginated = computed(() => this.paginated() || this.paginator(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePaginated" }] : /* istanbul ignore next */ []));
    selectionEnabled = computed(() => this.selectable() || !!this.selectionMode(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectionEnabled" }] : /* istanbul ignore next */ []));
    /** Uses projected columns when present, otherwise adapts the direct config API. */
    effectiveColumns = computed(() => {
        const declared = this.declaredColumns();
        if (declared.length || !this.columnsConfig())
            return declared;
        return (this.columnsConfig() ?? []).map((config) => ({
            key: () => config.key,
            header: () => config.header,
            sortable: () => !!config.sortable,
            width: () => config.width ?? '',
            align: () => config.align ?? 'left',
            cellTemplate: () => undefined,
            headerTemplate: () => undefined,
        }));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveColumns" }] : /* istanbul ignore next */ []));
    // ── Computeds ─────────────────────────────────────────────
    effectiveTotalItems = computed(() => {
        const custom = this.totalRecords() ?? this.totalItems();
        return this.remoteData() && custom !== undefined
            ? tableOffset(custom)
            : this.filteredData().length;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveTotalItems" }] : /* istanbul ignore next */ []));
    /** Dados ordenados localmente */
    filteredData = computed(() => {
        if (this.remoteData())
            return this.effectiveData();
        const query = this.filter().trim().toLocaleLowerCase(this.filterLocale());
        if (!query)
            return this.effectiveData();
        const configured = this.globalFilterFields();
        const fields = configured.length
            ? configured
            : this.effectiveColumns().map((column) => column.key());
        return this.effectiveData().filter((row) => (fields.length ? fields : Object.keys(row ?? {})).some((key) => String(tableField(row, key) ?? '')
            .toLocaleLowerCase(this.filterLocale())
            .includes(query)));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredData" }] : /* istanbul ignore next */ []));
    collator = computed(() => new Intl.Collator(this.filterLocale(), {
        numeric: true,
        sensitivity: 'base',
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collator" }] : /* istanbul ignore next */ []));
    sortedData = computed(() => {
        if (this.remoteData() || this.customSort())
            return this.filteredData();
        const raw = this.filteredData();
        const { column: col, direction: dir } = this.sorting();
        if (!col || dir === 'none') {
            return raw;
        }
        const collator = this.collator();
        return [...raw].sort((a, b) => {
            const valA = tableField(a, col);
            const valB = tableField(b, col);
            if (valA === valB)
                return 0;
            if (valA === null || valA === undefined)
                return 1;
            if (valB === null || valB === undefined)
                return -1;
            let comparison = 0;
            if (typeof valA === 'string' && typeof valB === 'string') {
                comparison = collator.compare(valA, valB);
            }
            else if (typeof valA === 'number' && typeof valB === 'number') {
                comparison = valA - valB;
            }
            else if (valA instanceof Date && valB instanceof Date) {
                comparison = valA.getTime() - valB.getTime();
            }
            else {
                comparison = collator.compare(String(valA), String(valB));
            }
            return dir === 'asc' ? comparison : -comparison;
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortedData" }] : /* istanbul ignore next */ []));
    displayFirst = computed(() => this.remoteData()
        ? this.requestedFirst()
        : Math.min(this.requestedFirst(), Math.floor(Math.max(0, this.sortedData().length - 1) /
            this.effectivePageSize()) * this.effectivePageSize()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayFirst" }] : /* istanbul ignore next */ []));
    displayedPage = computed(() => Math.floor(this.displayFirst() / this.effectivePageSize()) + 1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayedPage" }] : /* istanbul ignore next */ []));
    /** Dados exibidos na página atual */
    displayData = computed(() => {
        const sorted = this.sortedData();
        if (this.remoteData() || !this.effectivePaginated()) {
            return sorted;
        }
        const size = this.effectivePageSize();
        const start = this.displayFirst();
        return sorted.slice(start, start + size);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayData" }] : /* istanbul ignore next */ []));
    selectableRows = computed(() => (this.selectionPageOnly() ? this.displayData() : this.sortedData()).filter((row, index) => this.isRowSelectable(row, this.selectionPageOnly() || this.remoteData()
        ? this.displayRowIndex(index)
        : index)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectableRows" }] : /* istanbul ignore next */ []));
    selectedKeys = computed(() => new Set(this.selectedRows().map((row) => this.selectionKey(row))), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedKeys" }] : /* istanbul ignore next */ []));
    /** Verifica se todas as linhas da página atual estão selecionadas */
    isAllSelected = computed(() => {
        const current = this.selectableRows();
        if (current.length === 0)
            return false;
        return current.every((row) => this.isRowSelected(row));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isAllSelected" }] : /* istanbul ignore next */ []));
    /** Verifica se parte das linhas está selecionada (estado indeterminado) */
    isSomeSelected = computed(() => {
        const current = this.selectableRows();
        if (current.length === 0)
            return false;
        const selectedCount = current.filter((row) => this.isRowSelected(row)).length;
        return selectedCount > 0 && selectedCount < current.length;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isSomeSelected" }] : /* istanbul ignore next */ []));
    // ── Métodos de Ação ───────────────────────────────────────
    getRowId(row) {
        return tableField(row, this.dataKey() || this.rowKey()) ?? row;
    }
    trackRow(index, row) {
        return this.rowTrackBy()?.(index, row) ?? this.getRowId(row);
    }
    isRowSelected(row, selected) {
        return selected
            ? selected.some((item) => this.sameRow(item, row))
            : this.selectedKeys().has(this.selectionKey(row));
    }
    selectionKey(row) {
        if (this.compareSelectionBy() === 'deepEquals') {
            return tableDeepSelectionKey(row);
        }
        return this.getRowId(row);
    }
    sameRow(left, right) {
        return this.selectionKey(left) === this.selectionKey(right);
    }
    isRowSelectable(row, index) {
        return this.rowSelectable()?.({ data: row, index }) ?? true;
    }
    displayRowIndex(index) {
        return ((this.effectivePaginated() || this.remoteData()
            ? this.displayFirst()
            : 0) + index);
    }
    toggleRowSelect(row, event) {
        const checked = typeof event === 'boolean' ? event : event.checked;
        const rowIndex = this.displayRowIndex(this.displayData().indexOf(row));
        if (this.rowSelectable() &&
            !this.rowSelectable()({ data: row, index: rowIndex }))
            return;
        const current = [...this.selectedRows()];
        const index = current.findIndex((item) => this.sameRow(item, row));
        if (checked === (index !== -1))
            return;
        if (checked && index === -1) {
            if (this.selectionMode() === 'single')
                current.splice(0, current.length);
            current.push(row);
        }
        else if (!checked && index !== -1) {
            current.splice(index, 1);
        }
        this.selectedRows.set(current);
        this.selectionChange.emit(current);
        (checked ? this.rowSelect : this.rowUnselect).emit({ data: row });
        (checked ? this.onRowSelect : this.onRowUnselect).emit({ data: row });
    }
    toggleSelectAll(event) {
        if (this.selectionMode() === 'single')
            return;
        const checked = typeof event === 'boolean' ? event : event.checked;
        const currentDisplay = this.selectableRows();
        let currentSelected = [...this.selectedRows()];
        if (checked) {
            const keys = new Set(currentSelected.map((row) => this.selectionKey(row)));
            currentDisplay.forEach((row) => {
                const key = this.selectionKey(row);
                if (!keys.has(key)) {
                    currentSelected.push(row);
                    keys.add(key);
                }
            });
        }
        else {
            const keys = new Set(currentDisplay.map((row) => this.selectionKey(row)));
            currentSelected = currentSelected.filter((item) => !keys.has(this.selectionKey(item)));
        }
        this.selectedRows.set(currentSelected);
        this.selectionChange.emit(currentSelected);
        this.selectAllChange.emit({ checked, data: currentSelected });
        this.onHeaderCheckboxToggle.emit({ checked, data: currentSelected });
    }
    handleSort(columnKey, isSortable, originalEvent) {
        if (!isSortable || (originalEvent && isTableControlEvent(originalEvent)))
            return;
        let newDirection = this.defaultSortOrder() < 0 ? 'desc' : 'asc';
        if (this.sorting().column === columnKey) {
            const currentDir = this.sorting().direction;
            if (currentDir === 'asc')
                newDirection = 'desc';
            else if (currentDir === 'desc')
                newDirection = 'none';
            else
                newDirection = 'asc';
        }
        this.sortColumn.set(newDirection === 'none' ? '' : columnKey);
        this.sortDirection.set(newDirection);
        this.sortField.set(newDirection === 'none' ? '' : columnKey);
        this.sortOrder.set(newDirection === 'asc' ? 1 : newDirection === 'desc' ? -1 : 0);
        const event = { column: columnKey, direction: newDirection };
        this.sorting.set(event);
        this.sortChange.emit(event);
        this.onSort.emit(event);
        if (this.customSort())
            this.sortFunction.emit(event);
        if (this.resetPageOnSort()) {
            this.currentPage.set(1);
            this.first.set(0);
            this.requestedFirst.set(0);
        }
        this.emitQuery();
    }
    ngOnInit() {
        if (this.lazyLoadOnInit())
            this.emitQuery();
    }
    applyFilter(value) {
        this.filter.set(value);
        this.currentPage.set(1);
        this.first.set(0);
        this.requestedFirst.set(0);
        this.onFilter.emit({ value });
        this.emitQuery();
    }
    handlePageChange(event) {
        const first = tableOffset(event.startIndex - 1);
        const rows = positiveTableInteger(event.pageSize, this.effectivePageSize());
        this.currentPage.set(positiveTableInteger(event.page, 1));
        this.pageSize.set(rows);
        this.effectivePageSize.set(rows);
        this.first.set(first);
        this.requestedFirst.set(first);
        this.onPage.emit({ first, rows });
        this.emitQuery();
    }
    toggleRowExpansion(row) {
        const expanded = this.expandedRows();
        const exists = expanded.some((item) => this.sameRow(item, row));
        this.expandedRows.set(exists
            ? expanded.filter((item) => !this.sameRow(item, row))
            : this.rowExpandMode() === 'single'
                ? [row]
                : [...expanded, row]);
        (exists ? this.onRowCollapse : this.onRowExpand).emit({ data: row });
    }
    isExpanded(row) {
        return this.expandedRows().some((item) => this.sameRow(item, row));
    }
    emitQuery() {
        if (!this.remoteData())
            return;
        const page = {
            first: this.requestedFirst(),
            rows: this.effectivePageSize(),
        };
        this.onLazyLoad.emit(page);
        this.queryChange.emit({
            ...page,
            sort: this.sorting().column && this.sorting().direction !== 'none'
                ? this.sorting()
                : undefined,
            filter: this.filter() || undefined,
            filters: this.filters(),
        });
    }
    handleRowClick(row, event) {
        if (event && isTableControlEvent(event))
            return;
        this.rowClick.emit(row);
    }
    onRowKeydown(row, event) {
        if ((event.key !== 'Enter' && event.key !== ' ') ||
            isTableControlEvent(event))
            return;
        event.preventDefault();
        this.handleRowClick(row);
    }
    onHeaderKeydown(column, event) {
        if (!column.sortable() ||
            (event.key !== 'Enter' && event.key !== ' ') ||
            isTableControlEvent(event))
            return;
        event.preventDefault();
        this.handleSort(column.key(), true);
    }
    getAriaSort(columnKey, isSortable) {
        if (!isSortable)
            return null;
        if (this.sorting().column !== columnKey)
            return 'none';
        const dir = this.sorting().direction;
        if (dir === 'asc')
            return 'ascending';
        if (dir === 'desc')
            return 'descending';
        return 'none';
    }
    getCellValue(row, key) {
        return tableField(row, key) ?? '';
    }
    getSkeletonArray() {
        return Array.from({ length: Math.max(0, this.loadingRowsCount()) }, (_, i) => i);
    }
    reset() {
        this.filter.set('');
        this.sortColumn.set('');
        this.sortField.set('');
        this.sortDirection.set('none');
        this.sortOrder.set(0);
        this.sorting.set({ column: '', direction: 'none' });
        this.currentPage.set(1);
        this.first.set(0);
        this.selectedRows.set([]);
        this.selectionChange.emit([]);
        this.requestedFirst.set(0);
    }
    exportCSV(options) {
        if (typeof document === 'undefined')
            return;
        const rows = options?.selectionOnly
            ? this.selectedRows()
            : this.effectiveData();
        const columns = this.effectiveColumns().map((column) => ({
            key: column.key(),
            header: column.header(),
        }));
        const csv = buildTableCsv(rows, columns, this.csvSeparator(), this.exportHeader(), (row, key) => this.getCellValue(row, key));
        const blob = new Blob([csv], {
            type: 'text/csv;charset=utf-8',
        });
        const link = document.createElement('a');
        const objectUrl = URL.createObjectURL(blob);
        link.href = objectUrl;
        link.download = `${this.exportFilename()}.csv`;
        try {
            link.click();
        }
        finally {
            URL.revokeObjectURL(objectUrl);
            link.remove();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TableComponent, isStandalone: true, selector: "orc-table", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, frozenColumns: { classPropertyName: "frozenColumns", publicName: "frozenColumns", isSignal: true, isRequired: false, transformFunction: null }, frozenValue: { classPropertyName: "frozenValue", publicName: "frozenValue", isSignal: true, isRequired: false, transformFunction: null }, columnsConfig: { classPropertyName: "columnsConfig", publicName: "columnsConfig", isSignal: true, isRequired: false, transformFunction: null }, rowKey: { classPropertyName: "rowKey", publicName: "rowKey", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, selectAllAriaLabel: { classPropertyName: "selectAllAriaLabel", publicName: "selectAllAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, rowAriaLabel: { classPropertyName: "rowAriaLabel", publicName: "rowAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, selectedRows: { classPropertyName: "selectedRows", publicName: "selectedRows", isSignal: true, isRequired: false, transformFunction: null }, sortColumn: { classPropertyName: "sortColumn", publicName: "sortColumn", isSignal: true, isRequired: false, transformFunction: null }, sortDirection: { classPropertyName: "sortDirection", publicName: "sortDirection", isSignal: true, isRequired: false, transformFunction: null }, sortField: { classPropertyName: "sortField", publicName: "sortField", isSignal: true, isRequired: false, transformFunction: null }, sortOrder: { classPropertyName: "sortOrder", publicName: "sortOrder", isSignal: true, isRequired: false, transformFunction: null }, striped: { classPropertyName: "striped", publicName: "striped", isSignal: true, isRequired: false, transformFunction: null }, bordered: { classPropertyName: "bordered", publicName: "bordered", isSignal: true, isRequired: false, transformFunction: null }, hoverable: { classPropertyName: "hoverable", publicName: "hoverable", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, tableStyleClass: { classPropertyName: "tableStyleClass", publicName: "tableStyleClass", isSignal: true, isRequired: false, transformFunction: null }, tableStyle: { classPropertyName: "tableStyle", publicName: "tableStyle", isSignal: true, isRequired: false, transformFunction: null }, rowHover: { classPropertyName: "rowHover", publicName: "rowHover", isSignal: true, isRequired: false, transformFunction: null }, showGridlines: { classPropertyName: "showGridlines", publicName: "showGridlines", isSignal: true, isRequired: false, transformFunction: null }, stripedRows: { classPropertyName: "stripedRows", publicName: "stripedRows", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, responsiveLayout: { classPropertyName: "responsiveLayout", publicName: "responsiveLayout", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, autoLayout: { classPropertyName: "autoLayout", publicName: "autoLayout", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, scrollDirection: { classPropertyName: "scrollDirection", publicName: "scrollDirection", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, resizableColumns: { classPropertyName: "resizableColumns", publicName: "resizableColumns", isSignal: true, isRequired: false, transformFunction: null }, reorderableColumns: { classPropertyName: "reorderableColumns", publicName: "reorderableColumns", isSignal: true, isRequired: false, transformFunction: null }, customSort: { classPropertyName: "customSort", publicName: "customSort", isSignal: true, isRequired: false, transformFunction: null }, showInitialSortBadge: { classPropertyName: "showInitialSortBadge", publicName: "showInitialSortBadge", isSignal: true, isRequired: false, transformFunction: null }, exportFilename: { classPropertyName: "exportFilename", publicName: "exportFilename", isSignal: true, isRequired: false, transformFunction: null }, csvSeparator: { classPropertyName: "csvSeparator", publicName: "csvSeparator", isSignal: true, isRequired: false, transformFunction: null }, exportHeader: { classPropertyName: "exportHeader", publicName: "exportHeader", isSignal: true, isRequired: false, transformFunction: null }, stateKey: { classPropertyName: "stateKey", publicName: "stateKey", isSignal: true, isRequired: false, transformFunction: null }, stateStorage: { classPropertyName: "stateStorage", publicName: "stateStorage", isSignal: true, isRequired: false, transformFunction: null }, editMode: { classPropertyName: "editMode", publicName: "editMode", isSignal: true, isRequired: false, transformFunction: null }, rowExpandMode: { classPropertyName: "rowExpandMode", publicName: "rowExpandMode", isSignal: true, isRequired: false, transformFunction: null }, groupRowsBy: { classPropertyName: "groupRowsBy", publicName: "groupRowsBy", isSignal: true, isRequired: false, transformFunction: null }, rowGroupMode: { classPropertyName: "rowGroupMode", publicName: "rowGroupMode", isSignal: true, isRequired: false, transformFunction: null }, rowTrackBy: { classPropertyName: "rowTrackBy", publicName: "rowTrackBy", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelection: { classPropertyName: "contextMenuSelection", publicName: "contextMenuSelection", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelectionMode: { classPropertyName: "contextMenuSelectionMode", publicName: "contextMenuSelectionMode", isSignal: true, isRequired: false, transformFunction: null }, filters: { classPropertyName: "filters", publicName: "filters", isSignal: true, isRequired: false, transformFunction: null }, serverDriven: { classPropertyName: "serverDriven", publicName: "serverDriven", isSignal: true, isRequired: false, transformFunction: null }, filterDelay: { classPropertyName: "filterDelay", publicName: "filterDelay", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, filterAriaLabel: { classPropertyName: "filterAriaLabel", publicName: "filterAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, globalFilterFields: { classPropertyName: "globalFilterFields", publicName: "globalFilterFields", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingRowsCount: { classPropertyName: "loadingRowsCount", publicName: "loadingRowsCount", isSignal: true, isRequired: false, transformFunction: null }, emptyTitle: { classPropertyName: "emptyTitle", publicName: "emptyTitle", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, paginated: { classPropertyName: "paginated", publicName: "paginated", isSignal: true, isRequired: false, transformFunction: null }, paginator: { classPropertyName: "paginator", publicName: "paginator", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, rowsInput: { classPropertyName: "rowsInput", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, pageLinks: { classPropertyName: "pageLinks", publicName: "pageLinks", isSignal: true, isRequired: false, transformFunction: null }, alwaysShowPaginator: { classPropertyName: "alwaysShowPaginator", publicName: "alwaysShowPaginator", isSignal: true, isRequired: false, transformFunction: null }, paginatorPosition: { classPropertyName: "paginatorPosition", publicName: "paginatorPosition", isSignal: true, isRequired: false, transformFunction: null }, paginatorStyleClass: { classPropertyName: "paginatorStyleClass", publicName: "paginatorStyleClass", isSignal: true, isRequired: false, transformFunction: null }, currentPageReportTemplate: { classPropertyName: "currentPageReportTemplate", publicName: "currentPageReportTemplate", isSignal: true, isRequired: false, transformFunction: null }, showCurrentPageReport: { classPropertyName: "showCurrentPageReport", publicName: "showCurrentPageReport", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageDropdown: { classPropertyName: "showJumpToPageDropdown", publicName: "showJumpToPageDropdown", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageInput: { classPropertyName: "showJumpToPageInput", publicName: "showJumpToPageInput", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastIcon: { classPropertyName: "showFirstLastIcon", publicName: "showFirstLastIcon", isSignal: true, isRequired: false, transformFunction: null }, showPageLinks: { classPropertyName: "showPageLinks", publicName: "showPageLinks", isSignal: true, isRequired: false, transformFunction: null }, lazyLoadOnInit: { classPropertyName: "lazyLoadOnInit", publicName: "lazyLoadOnInit", isSignal: true, isRequired: false, transformFunction: null }, metaKeySelection: { classPropertyName: "metaKeySelection", publicName: "metaKeySelection", isSignal: true, isRequired: false, transformFunction: null }, selectionPageOnly: { classPropertyName: "selectionPageOnly", publicName: "selectionPageOnly", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, rowSelectable: { classPropertyName: "rowSelectable", publicName: "rowSelectable", isSignal: true, isRequired: false, transformFunction: null }, paginatorDropdownAppendTo: { classPropertyName: "paginatorDropdownAppendTo", publicName: "paginatorDropdownAppendTo", isSignal: true, isRequired: false, transformFunction: null }, paginatorDropdownScrollHeight: { classPropertyName: "paginatorDropdownScrollHeight", publicName: "paginatorDropdownScrollHeight", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollDelay: { classPropertyName: "virtualScrollDelay", publicName: "virtualScrollDelay", isSignal: true, isRequired: false, transformFunction: null }, contextMenu: { classPropertyName: "contextMenu", publicName: "contextMenu", isSignal: true, isRequired: false, transformFunction: null }, defaultSortOrder: { classPropertyName: "defaultSortOrder", publicName: "defaultSortOrder", isSignal: true, isRequired: false, transformFunction: null }, sortMode: { classPropertyName: "sortMode", publicName: "sortMode", isSignal: true, isRequired: false, transformFunction: null }, resetPageOnSort: { classPropertyName: "resetPageOnSort", publicName: "resetPageOnSort", isSignal: true, isRequired: false, transformFunction: null }, compareSelectionBy: { classPropertyName: "compareSelectionBy", publicName: "compareSelectionBy", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, showLoader: { classPropertyName: "showLoader", publicName: "showLoader", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, expandedRows: { classPropertyName: "expandedRows", publicName: "expandedRows", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedRows: "selectedRowsChange", selectionChange: "selectionChange", rowSelect: "rowSelect", rowUnselect: "rowUnselect", onRowSelect: "onRowSelect", onRowUnselect: "onRowUnselect", selectAllChange: "selectAllChange", sortColumn: "sortColumnChange", sortDirection: "sortDirectionChange", sortField: "sortFieldChange", sortOrder: "sortOrderChange", sortChange: "sortChange", onSort: "onSort", contextMenuSelection: "contextMenuSelectionChange", queryChange: "queryChange", filter: "filterChange", onFilter: "onFilter", pageSize: "pageSizeChange", first: "firstChange", currentPage: "currentPageChange", onPage: "onPage", onLazyLoad: "onLazyLoad", onRowExpand: "onRowExpand", onRowCollapse: "onRowCollapse", onContextMenuSelect: "onContextMenuSelect", onColResize: "onColResize", onColReorder: "onColReorder", onRowReorder: "onRowReorder", onEditInit: "onEditInit", onEditComplete: "onEditComplete", onEditCancel: "onEditCancel", onHeaderCheckboxToggle: "onHeaderCheckboxToggle", onStateSave: "onStateSave", onStateRestore: "onStateRestore", sortFunction: "sortFunction", rowClick: "rowClick", expandedRows: "expandedRowsChange" }, queries: [{ propertyName: "declaredColumns", predicate: ColumnDirective, isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: TableFooterDirective, descendants: true, isSignal: true }, { propertyName: "rowExpansionTemplate", first: true, predicate: TableRowExpansionDirective, descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-datatable p-component orc-table-container\"\n  [class.orc-table-container--bordered]=\"bordered()\"\n  [class.orc-table-container--striped]=\"striped() || stripedRows()\"\n  [class.orc-table-container--hoverable]=\"hoverable() || rowHover()\"\n  [class.orc-table-container--gridlines]=\"showGridlines()\"\n  [class.orc-table-container--small]=\"size() === 'small'\"\n  [class.orc-table-container--large]=\"size() === 'large'\"\n  [class]=\"'p-datatable p-component orc-table-container ' + styleClass()\"\n  [attr.data-pc-name]=\"'datatable'\"\n  [style]=\"style()\"\n>\n  @if (paginatorPosition() === \"top\" || paginatorPosition() === \"both\") {\n    <ng-container *ngTemplateOutlet=\"pagination\" />\n  }\n  <div\n    class=\"orc-table-wrapper\"\n    role=\"region\"\n    [attr.aria-label]=\"ariaLabel() || 'Data table'\"\n    [attr.aria-busy]=\"loading()\"\n    tabindex=\"0\"\n    [style.max-height]=\"scrollable() ? scrollHeight() : null\"\n  >\n    @if (filterable()) {\n      <input\n        class=\"orc-table__filter\"\n        type=\"search\"\n        [value]=\"filter()\"\n        [attr.placeholder]=\"filterPlaceholder() || null\"\n        (input)=\"applyFilter($any($event.target).value)\"\n        [attr.aria-label]=\"filterAriaLabel() || 'Filter rows'\"\n      />\n    }\n    <table class=\"orc-table {{ tableStyleClass() }}\" [style]=\"tableStyle()\">\n      <!-- \u2500\u2500 Cabe\u00E7alho da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <thead class=\"orc-table__head\">\n        <tr class=\"orc-table__head-row\">\n          <!-- Coluna de Sele\u00E7\u00E3o em Massa -->\n          @if (selectionEnabled()) {\n            <th scope=\"col\" class=\"orc-table__th orc-table__th--checkbox\">\n              @if (selectionMode() !== \"single\") {\n                <orc-checkbox\n                  [checked]=\"isAllSelected()\"\n                  [indeterminate]=\"isSomeSelected()\"\n                  (change)=\"toggleSelectAll($event)\"\n                  [ariaLabel]=\"selectAllAriaLabel() || 'Select all rows'\"\n                  [disabled]=\"selectableRows().length === 0\"\n                />\n              } @else {\n                <span class=\"orc-table__selection-heading\">Selection</span>\n              }\n            </th>\n          }\n\n          <!-- Colunas Declaradas via <orc-column> -->\n          @for (col of effectiveColumns(); track col.key()) {\n            <th\n              scope=\"col\"\n              class=\"orc-table__th\"\n              [class.orc-table__th--sortable]=\"col.sortable()\"\n              [class.orc-table__th--sorted]=\"\n                sorting().column === col.key() && sorting().direction !== 'none'\n              \"\n              [style.width]=\"col.width() || null\"\n              [style.text-align]=\"col.align()\"\n              [attr.aria-sort]=\"getAriaSort(col.key(), col.sortable())\"\n              (click)=\"handleSort(col.key(), col.sortable(), $event)\"\n              (keydown)=\"onHeaderKeydown(col, $event)\"\n              [tabindex]=\"col.sortable() ? 0 : -1\"\n            >\n              @if (col.headerTemplate(); as headerTpl) {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    headerTpl.templateRef;\n                    context: { column: col }\n                  \"\n                ></ng-container>\n              } @else {\n                <div\n                  class=\"orc-table__th-content\"\n                  [style.justify-content]=\"\n                    col.align() === 'center'\n                      ? 'center'\n                      : col.align() === 'right'\n                        ? 'flex-end'\n                        : 'flex-start'\n                  \"\n                >\n                  <span class=\"orc-table__th-text\">{{ col.header() }}</span>\n                  @if (col.sortable()) {\n                    <span class=\"orc-table__sort-icon\" aria-hidden=\"true\">\n                      @if (\n                        sorting().column === col.key() &&\n                        sorting().direction !== \"none\"\n                      ) {\n                        @if (sorting().direction === \"asc\") {\n                          <!-- Seta Ascendente (SVG Figma) -->\n                          <svg\n                            viewBox=\"0 0 16 16\"\n                            fill=\"none\"\n                            stroke=\"currentColor\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                          >\n                            <path d=\"M8 12V4M4 8l4-4 4 4\" />\n                          </svg>\n                        } @else if (sorting().direction === \"desc\") {\n                          <!-- Seta Descendente (SVG Figma) -->\n                          <svg\n                            viewBox=\"0 0 16 16\"\n                            fill=\"none\"\n                            stroke=\"currentColor\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                          >\n                            <path d=\"M8 4v8M4 8l4 4 4-4\" />\n                          </svg>\n                        }\n                      } @else {\n                        <!-- \u00CDcone Neutro de Ordena\u00E7\u00E3o -->\n                        <svg\n                          viewBox=\"0 0 16 16\"\n                          fill=\"none\"\n                          stroke=\"currentColor\"\n                          stroke-width=\"1.75\"\n                          stroke-linecap=\"round\"\n                          stroke-linejoin=\"round\"\n                        >\n                          <path d=\"M5 6l3-3 3 3M5 10l3 3 3-3\" opacity=\"0.4\" />\n                        </svg>\n                      }\n                    </span>\n                  }\n                </div>\n              }\n            </th>\n          }\n        </tr>\n      </thead>\n\n      <!-- \u2500\u2500 Corpo da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <tbody class=\"orc-table__body\">\n        <!-- Estado de Carregamento (Loading com Skeletons) -->\n        @if (loading()) {\n          @for (placeholder of getSkeletonArray(); track placeholder) {\n            <tr class=\"orc-table__row orc-table__row--loading\">\n              @if (selectionEnabled()) {\n                <td class=\"orc-table__td orc-table__td--checkbox\">\n                  <orc-skeleton\n                    variant=\"rectangular\"\n                    width=\"18px\"\n                    height=\"18px\"\n                    borderRadius=\"4px\"\n                  />\n                </td>\n              }\n              @for (col of effectiveColumns(); track col.key()) {\n                <td class=\"orc-table__td\">\n                  <orc-skeleton\n                    variant=\"text\"\n                    height=\"16px\"\n                    [width]=\"col.key() === 'id' ? '40px' : '75%'\"\n                  />\n                </td>\n              }\n            </tr>\n          }\n        }\n        <!-- Estado Vazio (Empty State) -->\n        @else if (displayData().length === 0) {\n          <tr class=\"orc-table__empty-row\">\n            <td\n              class=\"orc-table__empty-cell\"\n              [attr.colspan]=\"\n                effectiveColumns().length + (selectionEnabled() ? 1 : 0)\n              \"\n            >\n              <div class=\"orc-table__empty-content\">\n                <div class=\"orc-table__empty-icon\" aria-hidden=\"true\">\n                  <svg\n                    viewBox=\"0 0 24 24\"\n                    fill=\"none\"\n                    stroke=\"currentColor\"\n                    stroke-width=\"1.5\"\n                    stroke-linecap=\"round\"\n                    stroke-linejoin=\"round\"\n                  >\n                    <rect\n                      x=\"3\"\n                      y=\"3\"\n                      width=\"18\"\n                      height=\"18\"\n                      rx=\"2\"\n                      ry=\"2\"\n                    ></rect>\n                    <line x1=\"3\" y1=\"9\" x2=\"21\" y2=\"9\"></line>\n                    <line x1=\"9\" y1=\"21\" x2=\"9\" y2=\"9\"></line>\n                  </svg>\n                </div>\n                @if (emptyTitle()) {\n                  <h4 class=\"orc-table__empty-title\">{{ emptyTitle() }}</h4>\n                }\n                @if (emptyMessage()) {\n                  <p class=\"orc-table__empty-desc\">{{ emptyMessage() }}</p>\n                }\n              </div>\n            </td>\n          </tr>\n        }\n        <!-- Linhas de Dados -->\n        @else {\n          @for (\n            row of displayData();\n            track trackRow($index, row);\n            let rowIndex = $index\n          ) {\n            @let selected = isRowSelected(row);\n            <tr\n              class=\"orc-table__row\"\n              [class.orc-table__row--selected]=\"selected\"\n              [attr.aria-selected]=\"selectionEnabled() ? selected : null\"\n              tabindex=\"0\"\n              [attr.aria-label]=\"\n                rowAriaLabel() ? rowAriaLabel() + ' ' + (rowIndex + 1) : null\n              \"\n              (click)=\"handleRowClick(row, $event)\"\n              (keydown)=\"onRowKeydown(row, $event)\"\n            >\n              <!-- Checkbox de Sele\u00E7\u00E3o por Linha -->\n              @if (selectionEnabled()) {\n                <td\n                  class=\"orc-table__td orc-table__td--checkbox\"\n                  (click)=\"$event.stopPropagation()\"\n                >\n                  <orc-checkbox\n                    [checked]=\"selected\"\n                    (change)=\"toggleRowSelect(row, $event)\"\n                    [ariaLabel]=\"\n                      (rowAriaLabel() || 'Select row') +\n                      ' ' +\n                      (displayRowIndex(rowIndex) + 1)\n                    \"\n                    [disabled]=\"\n                      !isRowSelectable(row, displayRowIndex(rowIndex))\n                    \"\n                  />\n                </td>\n              }\n\n              <!-- C\u00E9lulas de Dados -->\n              @for (col of effectiveColumns(); track col.key()) {\n                <td class=\"orc-table__td\" [style.text-align]=\"col.align()\">\n                  @if (col.cellTemplate(); as cellTpl) {\n                    <ng-container\n                      *ngTemplateOutlet=\"\n                        cellTpl.templateRef;\n                        context: {\n                          $implicit: row,\n                          row: row,\n                          index: rowIndex,\n                          column: col,\n                          value: getCellValue(row, col.key()),\n                        }\n                      \"\n                    ></ng-container>\n                  } @else {\n                    <span class=\"orc-table__cell-value\">{{\n                      getCellValue(row, col.key())\n                    }}</span>\n                  }\n                </td>\n              }\n            </tr>\n            @if (rowExpansionTemplate() && isExpanded(row)) {\n              <tr class=\"orc-table__expansion-row\">\n                <td\n                  [attr.colspan]=\"\n                    effectiveColumns().length + (selectionEnabled() ? 1 : 0)\n                  \"\n                >\n                  <ng-container\n                    *ngTemplateOutlet=\"\n                      rowExpansionTemplate()!.templateRef;\n                      context: { $implicit: row, row: row, index: rowIndex }\n                    \"\n                  ></ng-container>\n                </td>\n              </tr>\n            }\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n\n  <!-- \u2500\u2500 Rodap\u00E9 com Pagina\u00E7\u00E3o Integrada \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (paginatorPosition() === \"bottom\" || paginatorPosition() === \"both\") {\n    <ng-container *ngTemplateOutlet=\"pagination\" />\n  }\n  <ng-template #pagination>\n    @if (\n      effectivePaginated() &&\n      (alwaysShowPaginator() || effectiveTotalItems() > effectivePageSize())\n    ) {\n      <div class=\"orc-table__footer\">\n        <orc-paginator\n          [totalItems]=\"effectiveTotalItems()\"\n          [pageSize]=\"effectivePageSize()\"\n          [currentPage]=\"displayedPage()\"\n          [pageSizeOptions]=\"effectiveRowsPerPageOptions()\"\n          [showPageSizeSelector]=\"true\"\n          [alwaysShow]=\"alwaysShowPaginator()\"\n          [pageLinkSize]=\"pageLinks()\"\n          [styleClass]=\"paginatorStyleClass()\"\n          [showCurrentPageReport]=\"showCurrentPageReport()\"\n          [currentPageReportTemplate]=\"currentPageReportTemplate()\"\n          [showJumpToPageDropdown]=\"showJumpToPageDropdown()\"\n          [showJumpToPageInput]=\"showJumpToPageInput()\"\n          [showFirstLastIcon]=\"showFirstLastIcon()\"\n          [showPageLinks]=\"showPageLinks()\"\n          (pageChange)=\"handlePageChange($event)\"\n        />\n      </div>\n    }\n  </ng-template>\n  @if (footerTemplate()) {\n    <div class=\"orc-table__aggregate-footer\">\n      <ng-container\n        *ngTemplateOutlet=\"footerTemplate()!.templateRef\"\n      ></ng-container>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-table-container{display:flex;flex-direction:column;width:100%;background:var(--orc-surface, var(--bg-app, #ffffff));border-radius:20px;overflow:hidden;box-sizing:border-box}.orc-table-container--bordered{border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-table-container--striped .orc-table__body .orc-table__row:nth-child(2n):not(.orc-table__row--selected){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-table-container--hoverable .orc-table__body .orc-table__row:hover:not(.orc-table__row--loading){background-color:color-mix(in srgb,var(--orc-interactive, #1c6aed) 4%,transparent)}.orc-table-container--gridlines .orc-table__th,.orc-table-container--gridlines .orc-table__td{border-inline-end:1px solid var(--orc-border-default, #d9d9d9)}.orc-table-container--small .orc-table__th,.orc-table-container--small .orc-table__td{padding-block:var(--space-2, .5rem)}.orc-table-container--large .orc-table__th,.orc-table-container--large .orc-table__td{padding-block:var(--space-6, 1.5rem)}.orc-table__selection-heading{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}.orc-table-wrapper{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;outline:none}.orc-table-wrapper:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table{width:100%;border-collapse:collapse;text-align:left;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px}.orc-table__head{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-table__head-row{border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-table__th{height:48px;padding:12px 16px;font-size:15px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));box-sizing:border-box;white-space:nowrap;outline:none;transition:background-color var(--transition-fast, .2s ease)}.orc-table__th--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__th--sortable{cursor:pointer;-webkit-user-select:none;user-select:none}.orc-table__th--sortable:hover{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed))}.orc-table__th--sortable:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table__th--sorted{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table__th-content{display:flex;align-items:center;gap:8px}.orc-table__th-text{font-weight:500}.orc-table__sort-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;color:currentColor}.orc-table__sort-icon svg{width:14px;height:14px}.orc-table__body{background-color:var(--orc-surface, var(--bg-app, #ffffff))}.orc-table__row{border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));transition:background-color var(--transition-fast, .2s ease)}.orc-table__row:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:-2px}.orc-table__row:last-child{border-bottom:none}.orc-table__row--selected{background-color:var(--orc-interactive-soft)!important}.orc-table__td{padding:16px;min-height:56px;vertical-align:middle;font-size:14px;line-height:20px;color:var(--orc-text, var(--text-primary, #141414));box-sizing:border-box}.orc-table__td--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__cell-value{display:block}.orc-table__empty-row:hover{background-color:transparent!important}.orc-table__empty-cell{padding:48px 24px;text-align:center}.orc-table__empty-content{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;max-width:320px;margin:0 auto}.orc-table__empty-icon{width:44px;height:44px;color:var(--orc-text-muted, #929292);margin-bottom:4px}.orc-table__empty-icon svg{width:100%;height:100%}.orc-table__empty-title{font-size:16px;font-weight:600;color:var(--orc-text, var(--text-primary, #141414));margin:0}.orc-table__empty-desc{font-size:13px;color:var(--orc-text-secondary, var(--text-secondary, #58595b));margin:0}.orc-table__footer{padding:12px 16px;background-color:var(--orc-surface, var(--bg-app, #ffffff));border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));display:flex;align-items:center;justify-content:flex-end}\n"], dependencies: [{ kind: "ngmodule", type: i0.forwardRef(() => CommonModule) }, { kind: "directive", type: i0.forwardRef(() => i1.NgTemplateOutlet), selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i0.forwardRef(() => CheckboxComponent), selector: "orc-checkbox", inputs: ["id", "name", "value", "label", "description", "disabled", "required", "error", "errorMessage", "ariaLabel", "ariaLabelledby", "ariaDescribedby", "ariaLabelledBy", "inputId", "readonly", "binary", "trueValue", "falseValue", "variant", "size", "autofocus", "styleClass", "checked", "indeterminate"], outputs: ["checkedChange", "indeterminateChange", "change", "onChange", "onFocus", "onBlur"] }, { kind: "component", type: i0.forwardRef(() => PaginatorComponent), selector: "orc-paginator, orc-pagination", inputs: ["totalItems", "totalRecords", "pageSize", "rows", "first", "currentPage", "page", "pageIndex", "pageSizeOptions", "rowsPerPageOptions", "showPageSizeSelector", "showFirstLastButtons", "showFirstLastIcon", "showPrevNextButtons", "showTotalInfo", "showCurrentPageReport", "currentPageReportTemplate", "alwaysShow", "showPageLinks", "showJumpToPageDropdown", "showJumpToPageInput", "locale", "dropdownAppendTo", "appendTo", "dropdownScrollHeight", "templateLeft", "templateRight", "style", "styleClass", "disabled", "size", "maxVisiblePages", "pageLinkSize", "previousLabel", "nextLabel", "firstLabel", "lastLabel", "itemsPerPageLabel", "ariaLabel", "jumpAriaLabel", "pageAriaLabel", "pageNumberAriaLabel", "pageSizeAriaLabel", "jumpPageInput"], outputs: ["pageSizeChange", "firstChange", "currentPageChange", "jumpPageInputChange", "pageChange", "onPageChange"] }, { kind: "component", type: i0.forwardRef(() => SkeletonComponent), selector: "orc-skeleton", inputs: ["variant", "animation", "shape", "size", "width", "height", "borderRadius", "fitContent", "display", "styleClass", "style", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-table', standalone: true, imports: [
                        CommonModule,
                        forwardRef(() => CheckboxComponent),
                        forwardRef(() => PaginatorComponent),
                        forwardRef(() => SkeletonComponent),
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-datatable p-component orc-table-container\"\n  [class.orc-table-container--bordered]=\"bordered()\"\n  [class.orc-table-container--striped]=\"striped() || stripedRows()\"\n  [class.orc-table-container--hoverable]=\"hoverable() || rowHover()\"\n  [class.orc-table-container--gridlines]=\"showGridlines()\"\n  [class.orc-table-container--small]=\"size() === 'small'\"\n  [class.orc-table-container--large]=\"size() === 'large'\"\n  [class]=\"'p-datatable p-component orc-table-container ' + styleClass()\"\n  [attr.data-pc-name]=\"'datatable'\"\n  [style]=\"style()\"\n>\n  @if (paginatorPosition() === \"top\" || paginatorPosition() === \"both\") {\n    <ng-container *ngTemplateOutlet=\"pagination\" />\n  }\n  <div\n    class=\"orc-table-wrapper\"\n    role=\"region\"\n    [attr.aria-label]=\"ariaLabel() || 'Data table'\"\n    [attr.aria-busy]=\"loading()\"\n    tabindex=\"0\"\n    [style.max-height]=\"scrollable() ? scrollHeight() : null\"\n  >\n    @if (filterable()) {\n      <input\n        class=\"orc-table__filter\"\n        type=\"search\"\n        [value]=\"filter()\"\n        [attr.placeholder]=\"filterPlaceholder() || null\"\n        (input)=\"applyFilter($any($event.target).value)\"\n        [attr.aria-label]=\"filterAriaLabel() || 'Filter rows'\"\n      />\n    }\n    <table class=\"orc-table {{ tableStyleClass() }}\" [style]=\"tableStyle()\">\n      <!-- \u2500\u2500 Cabe\u00E7alho da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <thead class=\"orc-table__head\">\n        <tr class=\"orc-table__head-row\">\n          <!-- Coluna de Sele\u00E7\u00E3o em Massa -->\n          @if (selectionEnabled()) {\n            <th scope=\"col\" class=\"orc-table__th orc-table__th--checkbox\">\n              @if (selectionMode() !== \"single\") {\n                <orc-checkbox\n                  [checked]=\"isAllSelected()\"\n                  [indeterminate]=\"isSomeSelected()\"\n                  (change)=\"toggleSelectAll($event)\"\n                  [ariaLabel]=\"selectAllAriaLabel() || 'Select all rows'\"\n                  [disabled]=\"selectableRows().length === 0\"\n                />\n              } @else {\n                <span class=\"orc-table__selection-heading\">Selection</span>\n              }\n            </th>\n          }\n\n          <!-- Colunas Declaradas via <orc-column> -->\n          @for (col of effectiveColumns(); track col.key()) {\n            <th\n              scope=\"col\"\n              class=\"orc-table__th\"\n              [class.orc-table__th--sortable]=\"col.sortable()\"\n              [class.orc-table__th--sorted]=\"\n                sorting().column === col.key() && sorting().direction !== 'none'\n              \"\n              [style.width]=\"col.width() || null\"\n              [style.text-align]=\"col.align()\"\n              [attr.aria-sort]=\"getAriaSort(col.key(), col.sortable())\"\n              (click)=\"handleSort(col.key(), col.sortable(), $event)\"\n              (keydown)=\"onHeaderKeydown(col, $event)\"\n              [tabindex]=\"col.sortable() ? 0 : -1\"\n            >\n              @if (col.headerTemplate(); as headerTpl) {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    headerTpl.templateRef;\n                    context: { column: col }\n                  \"\n                ></ng-container>\n              } @else {\n                <div\n                  class=\"orc-table__th-content\"\n                  [style.justify-content]=\"\n                    col.align() === 'center'\n                      ? 'center'\n                      : col.align() === 'right'\n                        ? 'flex-end'\n                        : 'flex-start'\n                  \"\n                >\n                  <span class=\"orc-table__th-text\">{{ col.header() }}</span>\n                  @if (col.sortable()) {\n                    <span class=\"orc-table__sort-icon\" aria-hidden=\"true\">\n                      @if (\n                        sorting().column === col.key() &&\n                        sorting().direction !== \"none\"\n                      ) {\n                        @if (sorting().direction === \"asc\") {\n                          <!-- Seta Ascendente (SVG Figma) -->\n                          <svg\n                            viewBox=\"0 0 16 16\"\n                            fill=\"none\"\n                            stroke=\"currentColor\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                          >\n                            <path d=\"M8 12V4M4 8l4-4 4 4\" />\n                          </svg>\n                        } @else if (sorting().direction === \"desc\") {\n                          <!-- Seta Descendente (SVG Figma) -->\n                          <svg\n                            viewBox=\"0 0 16 16\"\n                            fill=\"none\"\n                            stroke=\"currentColor\"\n                            stroke-width=\"2\"\n                            stroke-linecap=\"round\"\n                            stroke-linejoin=\"round\"\n                          >\n                            <path d=\"M8 4v8M4 8l4 4 4-4\" />\n                          </svg>\n                        }\n                      } @else {\n                        <!-- \u00CDcone Neutro de Ordena\u00E7\u00E3o -->\n                        <svg\n                          viewBox=\"0 0 16 16\"\n                          fill=\"none\"\n                          stroke=\"currentColor\"\n                          stroke-width=\"1.75\"\n                          stroke-linecap=\"round\"\n                          stroke-linejoin=\"round\"\n                        >\n                          <path d=\"M5 6l3-3 3 3M5 10l3 3 3-3\" opacity=\"0.4\" />\n                        </svg>\n                      }\n                    </span>\n                  }\n                </div>\n              }\n            </th>\n          }\n        </tr>\n      </thead>\n\n      <!-- \u2500\u2500 Corpo da Tabela \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n      <tbody class=\"orc-table__body\">\n        <!-- Estado de Carregamento (Loading com Skeletons) -->\n        @if (loading()) {\n          @for (placeholder of getSkeletonArray(); track placeholder) {\n            <tr class=\"orc-table__row orc-table__row--loading\">\n              @if (selectionEnabled()) {\n                <td class=\"orc-table__td orc-table__td--checkbox\">\n                  <orc-skeleton\n                    variant=\"rectangular\"\n                    width=\"18px\"\n                    height=\"18px\"\n                    borderRadius=\"4px\"\n                  />\n                </td>\n              }\n              @for (col of effectiveColumns(); track col.key()) {\n                <td class=\"orc-table__td\">\n                  <orc-skeleton\n                    variant=\"text\"\n                    height=\"16px\"\n                    [width]=\"col.key() === 'id' ? '40px' : '75%'\"\n                  />\n                </td>\n              }\n            </tr>\n          }\n        }\n        <!-- Estado Vazio (Empty State) -->\n        @else if (displayData().length === 0) {\n          <tr class=\"orc-table__empty-row\">\n            <td\n              class=\"orc-table__empty-cell\"\n              [attr.colspan]=\"\n                effectiveColumns().length + (selectionEnabled() ? 1 : 0)\n              \"\n            >\n              <div class=\"orc-table__empty-content\">\n                <div class=\"orc-table__empty-icon\" aria-hidden=\"true\">\n                  <svg\n                    viewBox=\"0 0 24 24\"\n                    fill=\"none\"\n                    stroke=\"currentColor\"\n                    stroke-width=\"1.5\"\n                    stroke-linecap=\"round\"\n                    stroke-linejoin=\"round\"\n                  >\n                    <rect\n                      x=\"3\"\n                      y=\"3\"\n                      width=\"18\"\n                      height=\"18\"\n                      rx=\"2\"\n                      ry=\"2\"\n                    ></rect>\n                    <line x1=\"3\" y1=\"9\" x2=\"21\" y2=\"9\"></line>\n                    <line x1=\"9\" y1=\"21\" x2=\"9\" y2=\"9\"></line>\n                  </svg>\n                </div>\n                @if (emptyTitle()) {\n                  <h4 class=\"orc-table__empty-title\">{{ emptyTitle() }}</h4>\n                }\n                @if (emptyMessage()) {\n                  <p class=\"orc-table__empty-desc\">{{ emptyMessage() }}</p>\n                }\n              </div>\n            </td>\n          </tr>\n        }\n        <!-- Linhas de Dados -->\n        @else {\n          @for (\n            row of displayData();\n            track trackRow($index, row);\n            let rowIndex = $index\n          ) {\n            @let selected = isRowSelected(row);\n            <tr\n              class=\"orc-table__row\"\n              [class.orc-table__row--selected]=\"selected\"\n              [attr.aria-selected]=\"selectionEnabled() ? selected : null\"\n              tabindex=\"0\"\n              [attr.aria-label]=\"\n                rowAriaLabel() ? rowAriaLabel() + ' ' + (rowIndex + 1) : null\n              \"\n              (click)=\"handleRowClick(row, $event)\"\n              (keydown)=\"onRowKeydown(row, $event)\"\n            >\n              <!-- Checkbox de Sele\u00E7\u00E3o por Linha -->\n              @if (selectionEnabled()) {\n                <td\n                  class=\"orc-table__td orc-table__td--checkbox\"\n                  (click)=\"$event.stopPropagation()\"\n                >\n                  <orc-checkbox\n                    [checked]=\"selected\"\n                    (change)=\"toggleRowSelect(row, $event)\"\n                    [ariaLabel]=\"\n                      (rowAriaLabel() || 'Select row') +\n                      ' ' +\n                      (displayRowIndex(rowIndex) + 1)\n                    \"\n                    [disabled]=\"\n                      !isRowSelectable(row, displayRowIndex(rowIndex))\n                    \"\n                  />\n                </td>\n              }\n\n              <!-- C\u00E9lulas de Dados -->\n              @for (col of effectiveColumns(); track col.key()) {\n                <td class=\"orc-table__td\" [style.text-align]=\"col.align()\">\n                  @if (col.cellTemplate(); as cellTpl) {\n                    <ng-container\n                      *ngTemplateOutlet=\"\n                        cellTpl.templateRef;\n                        context: {\n                          $implicit: row,\n                          row: row,\n                          index: rowIndex,\n                          column: col,\n                          value: getCellValue(row, col.key()),\n                        }\n                      \"\n                    ></ng-container>\n                  } @else {\n                    <span class=\"orc-table__cell-value\">{{\n                      getCellValue(row, col.key())\n                    }}</span>\n                  }\n                </td>\n              }\n            </tr>\n            @if (rowExpansionTemplate() && isExpanded(row)) {\n              <tr class=\"orc-table__expansion-row\">\n                <td\n                  [attr.colspan]=\"\n                    effectiveColumns().length + (selectionEnabled() ? 1 : 0)\n                  \"\n                >\n                  <ng-container\n                    *ngTemplateOutlet=\"\n                      rowExpansionTemplate()!.templateRef;\n                      context: { $implicit: row, row: row, index: rowIndex }\n                    \"\n                  ></ng-container>\n                </td>\n              </tr>\n            }\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n\n  <!-- \u2500\u2500 Rodap\u00E9 com Pagina\u00E7\u00E3o Integrada \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (paginatorPosition() === \"bottom\" || paginatorPosition() === \"both\") {\n    <ng-container *ngTemplateOutlet=\"pagination\" />\n  }\n  <ng-template #pagination>\n    @if (\n      effectivePaginated() &&\n      (alwaysShowPaginator() || effectiveTotalItems() > effectivePageSize())\n    ) {\n      <div class=\"orc-table__footer\">\n        <orc-paginator\n          [totalItems]=\"effectiveTotalItems()\"\n          [pageSize]=\"effectivePageSize()\"\n          [currentPage]=\"displayedPage()\"\n          [pageSizeOptions]=\"effectiveRowsPerPageOptions()\"\n          [showPageSizeSelector]=\"true\"\n          [alwaysShow]=\"alwaysShowPaginator()\"\n          [pageLinkSize]=\"pageLinks()\"\n          [styleClass]=\"paginatorStyleClass()\"\n          [showCurrentPageReport]=\"showCurrentPageReport()\"\n          [currentPageReportTemplate]=\"currentPageReportTemplate()\"\n          [showJumpToPageDropdown]=\"showJumpToPageDropdown()\"\n          [showJumpToPageInput]=\"showJumpToPageInput()\"\n          [showFirstLastIcon]=\"showFirstLastIcon()\"\n          [showPageLinks]=\"showPageLinks()\"\n          (pageChange)=\"handlePageChange($event)\"\n        />\n      </div>\n    }\n  </ng-template>\n  @if (footerTemplate()) {\n    <div class=\"orc-table__aggregate-footer\">\n      <ng-container\n        *ngTemplateOutlet=\"footerTemplate()!.templateRef\"\n      ></ng-container>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-table-container{display:flex;flex-direction:column;width:100%;background:var(--orc-surface, var(--bg-app, #ffffff));border-radius:20px;overflow:hidden;box-sizing:border-box}.orc-table-container--bordered{border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-table-container--striped .orc-table__body .orc-table__row:nth-child(2n):not(.orc-table__row--selected){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-table-container--hoverable .orc-table__body .orc-table__row:hover:not(.orc-table__row--loading){background-color:color-mix(in srgb,var(--orc-interactive, #1c6aed) 4%,transparent)}.orc-table-container--gridlines .orc-table__th,.orc-table-container--gridlines .orc-table__td{border-inline-end:1px solid var(--orc-border-default, #d9d9d9)}.orc-table-container--small .orc-table__th,.orc-table-container--small .orc-table__td{padding-block:var(--space-2, .5rem)}.orc-table-container--large .orc-table__th,.orc-table-container--large .orc-table__td{padding-block:var(--space-6, 1.5rem)}.orc-table__selection-heading{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}.orc-table-wrapper{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;outline:none}.orc-table-wrapper:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table{width:100%;border-collapse:collapse;text-align:left;font-family:var(--font-sans, \"Poppins\", sans-serif);font-size:14px}.orc-table__head{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9))}.orc-table__head-row{border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-table__th{height:48px;padding:12px 16px;font-size:15px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));box-sizing:border-box;white-space:nowrap;outline:none;transition:background-color var(--transition-fast, .2s ease)}.orc-table__th--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__th--sortable{cursor:pointer;-webkit-user-select:none;user-select:none}.orc-table__th--sortable:hover{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed))}.orc-table__th--sortable:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table__th--sorted{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-table__th-content{display:flex;align-items:center;gap:8px}.orc-table__th-text{font-weight:500}.orc-table__sort-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;color:currentColor}.orc-table__sort-icon svg{width:14px;height:14px}.orc-table__body{background-color:var(--orc-surface, var(--bg-app, #ffffff))}.orc-table__row{border-bottom:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));transition:background-color var(--transition-fast, .2s ease)}.orc-table__row:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:-2px}.orc-table__row:last-child{border-bottom:none}.orc-table__row--selected{background-color:var(--orc-interactive-soft)!important}.orc-table__td{padding:16px;min-height:56px;vertical-align:middle;font-size:14px;line-height:20px;color:var(--orc-text, var(--text-primary, #141414));box-sizing:border-box}.orc-table__td--checkbox{width:48px;padding-left:20px;padding-right:8px;text-align:center}.orc-table__cell-value{display:block}.orc-table__empty-row:hover{background-color:transparent!important}.orc-table__empty-cell{padding:48px 24px;text-align:center}.orc-table__empty-content{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;max-width:320px;margin:0 auto}.orc-table__empty-icon{width:44px;height:44px;color:var(--orc-text-muted, #929292);margin-bottom:4px}.orc-table__empty-icon svg{width:100%;height:100%}.orc-table__empty-title{font-size:16px;font-weight:600;color:var(--orc-text, var(--text-primary, #141414));margin:0}.orc-table__empty-desc{font-size:13px;color:var(--orc-text-secondary, var(--text-secondary, #58595b));margin:0}.orc-table__footer{padding:12px 16px;background-color:var(--orc-surface, var(--bg-app, #ffffff));border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));display:flex;align-items:center;justify-content:flex-end}\n"] }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], frozenColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenColumns", required: false }] }], frozenValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenValue", required: false }] }], columnsConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnsConfig", required: false }] }], rowKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowKey", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], selectAllAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAllAriaLabel", required: false }] }], rowAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowAriaLabel", required: false }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], selectedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedRows", required: false }] }, { type: i0.Output, args: ["selectedRowsChange"] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], rowSelect: [{ type: i0.Output, args: ["rowSelect"] }], rowUnselect: [{ type: i0.Output, args: ["rowUnselect"] }], onRowSelect: [{ type: i0.Output, args: ["onRowSelect"] }], onRowUnselect: [{ type: i0.Output, args: ["onRowUnselect"] }], selectAllChange: [{ type: i0.Output, args: ["selectAllChange"] }], sortColumn: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortColumn", required: false }] }, { type: i0.Output, args: ["sortColumnChange"] }], sortDirection: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortDirection", required: false }] }, { type: i0.Output, args: ["sortDirectionChange"] }], sortField: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortField", required: false }] }, { type: i0.Output, args: ["sortFieldChange"] }], sortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortOrder", required: false }] }, { type: i0.Output, args: ["sortOrderChange"] }], sortChange: [{ type: i0.Output, args: ["sortChange"] }], onSort: [{ type: i0.Output, args: ["onSort"] }], striped: [{ type: i0.Input, args: [{ isSignal: true, alias: "striped", required: false }] }], bordered: [{ type: i0.Input, args: [{ isSignal: true, alias: "bordered", required: false }] }], hoverable: [{ type: i0.Input, args: [{ isSignal: true, alias: "hoverable", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], tableStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyleClass", required: false }] }], tableStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyle", required: false }] }], rowHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHover", required: false }] }], showGridlines: [{ type: i0.Input, args: [{ isSignal: true, alias: "showGridlines", required: false }] }], stripedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "stripedRows", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], responsiveLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsiveLayout", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], autoLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoLayout", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], scrollDirection: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollDirection", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], resizableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "resizableColumns", required: false }] }], reorderableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "reorderableColumns", required: false }] }], customSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "customSort", required: false }] }], showInitialSortBadge: [{ type: i0.Input, args: [{ isSignal: true, alias: "showInitialSortBadge", required: false }] }], exportFilename: [{ type: i0.Input, args: [{ isSignal: true, alias: "exportFilename", required: false }] }], csvSeparator: [{ type: i0.Input, args: [{ isSignal: true, alias: "csvSeparator", required: false }] }], exportHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "exportHeader", required: false }] }], stateKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateKey", required: false }] }], stateStorage: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateStorage", required: false }] }], editMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "editMode", required: false }] }], rowExpandMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowExpandMode", required: false }] }], groupRowsBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupRowsBy", required: false }] }], rowGroupMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowGroupMode", required: false }] }], rowTrackBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowTrackBy", required: false }] }], contextMenuSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelection", required: false }] }, { type: i0.Output, args: ["contextMenuSelectionChange"] }], contextMenuSelectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelectionMode", required: false }] }], filters: [{ type: i0.Input, args: [{ isSignal: true, alias: "filters", required: false }] }], serverDriven: [{ type: i0.Input, args: [{ isSignal: true, alias: "serverDriven", required: false }] }], queryChange: [{ type: i0.Output, args: ["queryChange"] }], filterDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterDelay", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], filterAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterAriaLabel", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }, { type: i0.Output, args: ["filterChange"] }], globalFilterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "globalFilterFields", required: false }] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingRowsCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingRowsCount", required: false }] }], emptyTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyTitle", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], paginated: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginated", required: false }] }], paginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginator", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }, { type: i0.Output, args: ["pageSizeChange"] }], rowsInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }, { type: i0.Output, args: ["firstChange"] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }, { type: i0.Output, args: ["currentPageChange"] }], totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], pageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageLinks", required: false }] }], alwaysShowPaginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "alwaysShowPaginator", required: false }] }], paginatorPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorPosition", required: false }] }], paginatorStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorStyleClass", required: false }] }], currentPageReportTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPageReportTemplate", required: false }] }], showCurrentPageReport: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCurrentPageReport", required: false }] }], showJumpToPageDropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageDropdown", required: false }] }], showJumpToPageInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageInput", required: false }] }], showFirstLastIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastIcon", required: false }] }], showPageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageLinks", required: false }] }], lazyLoadOnInit: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyLoadOnInit", required: false }] }], metaKeySelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "metaKeySelection", required: false }] }], selectionPageOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionPageOnly", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], rowSelectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowSelectable", required: false }] }], paginatorDropdownAppendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorDropdownAppendTo", required: false }] }], paginatorDropdownScrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorDropdownScrollHeight", required: false }] }], virtualScrollDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollDelay", required: false }] }], contextMenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenu", required: false }] }], defaultSortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultSortOrder", required: false }] }], sortMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortMode", required: false }] }], resetPageOnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetPageOnSort", required: false }] }], compareSelectionBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareSelectionBy", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], showLoader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLoader", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], onPage: [{ type: i0.Output, args: ["onPage"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }], onRowExpand: [{ type: i0.Output, args: ["onRowExpand"] }], onRowCollapse: [{ type: i0.Output, args: ["onRowCollapse"] }], onContextMenuSelect: [{ type: i0.Output, args: ["onContextMenuSelect"] }], onColResize: [{ type: i0.Output, args: ["onColResize"] }], onColReorder: [{ type: i0.Output, args: ["onColReorder"] }], onRowReorder: [{ type: i0.Output, args: ["onRowReorder"] }], onEditInit: [{ type: i0.Output, args: ["onEditInit"] }], onEditComplete: [{ type: i0.Output, args: ["onEditComplete"] }], onEditCancel: [{ type: i0.Output, args: ["onEditCancel"] }], onHeaderCheckboxToggle: [{ type: i0.Output, args: ["onHeaderCheckboxToggle"] }], onStateSave: [{ type: i0.Output, args: ["onStateSave"] }], onStateRestore: [{ type: i0.Output, args: ["onStateRestore"] }], sortFunction: [{ type: i0.Output, args: ["sortFunction"] }], rowClick: [{ type: i0.Output, args: ["rowClick"] }], declaredColumns: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ColumnDirective), { isSignal: true }] }], footerTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => TableFooterDirective), { isSignal: true }] }], rowExpansionTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => TableRowExpansionDirective), { isSignal: true }] }], expandedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandedRows", required: false }] }, { type: i0.Output, args: ["expandedRowsChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CellDefDirective, ColumnDirective, HeaderCellDefDirective, TableComponent, TableFooterDirective, TableRowExpansionDirective };
//# sourceMappingURL=ciag-orchestra-table.mjs.map
