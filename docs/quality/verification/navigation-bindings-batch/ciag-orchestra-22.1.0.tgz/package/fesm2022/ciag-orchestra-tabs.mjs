import * as i0 from '@angular/core';
import { input, booleanAttribute, viewChild, computed, model, ChangeDetectionStrategy, Component, inject, ElementRef, output, contentChildren, signal, viewChildren, effect } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

let uniqueTabIdCounter = 0;
class TabComponent {
    // Inputs (Signals API)
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    iconPosition = input('start', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconPosition" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closable = input(false, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeAriaLabel" }] : /* istanbul ignore next */ []));
    cache = input(true, { ...(ngDevMode ? { debugName: "cache" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tooltip = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    tooltipPosition = input('top', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : /* istanbul ignore next */ []));
    headerStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerStyle" }] : /* istanbul ignore next */ []));
    headerStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerStyleClass" }] : /* istanbul ignore next */ []));
    selected = input(false, { ...(ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    badge = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "badge" }] : /* istanbul ignore next */ []));
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    // Templates internos para projeção sob demanda
    contentTemplate = viewChild('contentTemplate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentTemplate" }] : /* istanbul ignore next */ []));
    customLabelTemplate = viewChild('customLabelTemplate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "customLabelTemplate" }] : /* istanbul ignore next */ []));
    // Identificador único garantido
    fallbackId = `orc-tab-${++uniqueTabIdCounter}`;
    tabId = computed(() => this.id() || this.fallbackId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabId" }] : /* istanbul ignore next */ []));
    panelId = computed(() => `${this.tabId()}-panel`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelId" }] : /* istanbul ignore next */ []));
    closed = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closed" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: TabComponent, isStandalone: true, selector: "orc-tab", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconPosition: { classPropertyName: "iconPosition", publicName: "iconPosition", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, closeAriaLabel: { classPropertyName: "closeAriaLabel", publicName: "closeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, cache: { classPropertyName: "cache", publicName: "cache", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, headerStyle: { classPropertyName: "headerStyle", publicName: "headerStyle", isSignal: true, isRequired: false, transformFunction: null }, headerStyleClass: { classPropertyName: "headerStyleClass", publicName: "headerStyleClass", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, closed: { classPropertyName: "closed", publicName: "closed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closedChange" }, viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: ["contentTemplate"], descendants: true, isSignal: true }, { propertyName: "customLabelTemplate", first: true, predicate: ["customLabelTemplate"], descendants: true, isSignal: true }], ngImport: i0, template: "<ng-template #contentTemplate>\n  <ng-content></ng-content>\n</ng-template>\n\n<ng-template #customLabelTemplate>\n  <ng-content select=\"[tab-label], [tabLabel]\"></ng-content>\n</ng-template>\n", styles: [":host{display:none}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tab', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #contentTemplate>\n  <ng-content></ng-content>\n</ng-template>\n\n<ng-template #customLabelTemplate>\n  <ng-content select=\"[tab-label], [tabLabel]\"></ng-content>\n</ng-template>\n", styles: [":host{display:none}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconPosition", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], closeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeAriaLabel", required: false }] }], cache: [{ type: i0.Input, args: [{ isSignal: true, alias: "cache", required: false }] }], tooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], headerStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerStyle", required: false }] }], headerStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerStyleClass", required: false }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }], badge: [{ type: i0.Input, args: [{ isSignal: true, alias: "badge", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], contentTemplate: [{ type: i0.ViewChild, args: ['contentTemplate', { isSignal: true }] }], customLabelTemplate: [{ type: i0.ViewChild, args: ['customLabelTemplate', { isSignal: true }] }], closed: [{ type: i0.Input, args: [{ isSignal: true, alias: "closed", required: false }] }, { type: i0.Output, args: ["closedChange"] }] } });

class TabGroupComponent {
    host = inject((ElementRef));
    // Inputs & Model (Signals API)
    selectedIndex = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedIndex" }] : /* istanbul ignore next */ []));
    value = model(undefined, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), alias: 'value' });
    variant = input('line', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    fullWidth = input(false, { ...(ngDevMode ? { debugName: "fullWidth" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollable = input(false, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectOnFocus = input(false, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    controlClose = input(false, { ...(ngDevMode ? { debugName: "controlClose" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showNavigators = input(true, { ...(ngDevMode ? { debugName: "showNavigators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    nextButtonAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextButtonAriaLabel" }] : /* istanbul ignore next */ []));
    prevButtonAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prevButtonAriaLabel" }] : /* istanbul ignore next */ []));
    autoHideButtons = input(true, { ...(ngDevMode ? { debugName: "autoHideButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    // Outputs (Signals API)
    tabChange = output();
    onChange = output();
    tabFocus = output();
    onClose = output();
    // Abas filhas registradas via contentChildren
    tabs = contentChildren(TabComponent, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    visibleTabs = computed(() => this.tabs().filter((tab) => !tab.closed()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleTabs" }] : /* istanbul ignore next */ []));
    loadedTabs = new Set();
    selectionIntent = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectionIntent" }] : /* istanbul ignore next */ []));
    lastSelectedIndex = this.selectedIndex();
    lastValue = this.value();
    initialized = false;
    focusedIndex = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedIndex" }] : /* istanbul ignore next */ []));
    // Referências dos botões de abas para navegação por teclado e foco programático
    tabButtons = viewChildren('tabBtn', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabButtons" }] : /* istanbul ignore next */ []));
    tabHeader = viewChild('tabHeader', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabHeader" }] : /* istanbul ignore next */ []));
    navigation = signal({ previous: false, next: false }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []));
    resizeObserver;
    mutationObserver;
    observedTabItems = new Set();
    rtlScrollMode;
    focusRequest = 0;
    destroyed = false;
    activeIndex = computed(() => {
        const intent = this.selectionIntent();
        if (typeof intent === 'number')
            return this.boundIndex(intent);
        if (typeof intent === 'string') {
            const index = this.visibleTabs().findIndex((tab) => tab.tabId() === intent);
            if (index >= 0)
                return index;
        }
        const selectedTab = this.visibleTabs().findIndex((tab) => tab.selected());
        return selectedTab >= 0
            ? selectedTab
            : this.boundIndex(this.selectedIndex());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const selectedIndex = this.selectedIndex();
            const value = this.value();
            const selectedChanged = selectedIndex !== this.lastSelectedIndex;
            const valueChanged = value !== this.lastValue;
            if (!this.initialized) {
                this.initialized = true;
                this.lastSelectedIndex = selectedIndex;
                this.lastValue = value;
                if (value !== undefined)
                    this.selectionIntent.set(value);
            }
            else if (selectedChanged || valueChanged) {
                // If both aliases change in one update, `value` is the deterministic
                // winner. A single-alias update keeps that alias as the intent.
                this.selectionIntent.set(valueChanged ? value : selectedIndex);
                this.lastSelectedIndex = selectedIndex;
                this.lastValue = value;
                this.focusedIndex.set(this.activeIndex());
            }
            const visible = this.visibleTabs();
            const activeIndex = this.activeIndex();
            const active = visible[activeIndex];
            if (active)
                this.loadedTabs.add(active);
            const focused = this.focusedIndex();
            if (focused === undefined ||
                !visible[focused] ||
                visible[focused].disabled()) {
                this.focusedIndex.set(visible.length ? this.nearestEnabledIndex(activeIndex) : 0);
            }
            for (const tab of this.loadedTabs) {
                if (!visible.includes(tab) || tab.closed())
                    this.loadedTabs.delete(tab);
            }
        });
    }
    boundIndex(index) {
        const count = this.visibleTabs().length;
        if (!count || !Number.isFinite(index))
            return 0;
        return Math.min(count - 1, Math.max(0, Math.trunc(index)));
    }
    ngAfterViewInit() {
        this.updateNavigation();
        const header = this.tabHeader()?.nativeElement;
        const view = this.host.nativeElement.ownerDocument?.defaultView;
        if (header && view?.ResizeObserver) {
            const observer = new view.ResizeObserver(() => this.updateNavigation());
            observer.observe(header);
            this.observeTabItems(observer, header);
            this.resizeObserver = observer;
        }
        if (header && view?.MutationObserver) {
            const observer = new view.MutationObserver(() => {
                if (this.resizeObserver)
                    this.observeTabItems(this.resizeObserver, header);
                this.updateNavigation();
            });
            observer.observe(header, {
                attributes: true,
                childList: true,
                characterData: true,
                subtree: true,
            });
            this.mutationObserver = observer;
        }
    }
    ngOnDestroy() {
        this.destroyed = true;
        this.focusRequest++;
        this.resizeObserver?.disconnect();
        this.observedTabItems.clear();
        this.mutationObserver?.disconnect();
    }
    updateNavigation() {
        const header = this.tabHeader()?.nativeElement;
        if (!header)
            return;
        const max = this.maxScroll(header);
        const logicalLeft = this.logicalScrollLeft(header, max);
        const state = {
            previous: logicalLeft > 0,
            next: logicalLeft < max,
        };
        const current = this.navigation();
        if (current.previous !== state.previous || current.next !== state.next) {
            this.navigation.set(state);
        }
    }
    scrollTabs(direction) {
        const header = this.tabHeader()?.nativeElement;
        if (!header)
            return;
        const max = this.maxScroll(header);
        const amount = Math.max(1, Math.floor(header.clientWidth * 0.8));
        const current = this.logicalScrollLeft(header, max);
        const nextLeft = direction === 'next'
            ? Math.min(max, current + amount)
            : Math.max(0, current - amount);
        if (this.isRtl()) {
            header.scrollLeft = -nextLeft;
            if (nextLeft > 0 && header.scrollLeft === 0) {
                header.scrollLeft = nextLeft;
                if (header.scrollLeft > 0)
                    this.rtlScrollMode = 'positive';
            }
            else if (nextLeft > 0 && header.scrollLeft < 0) {
                this.rtlScrollMode = 'negative';
            }
        }
        else {
            header.scrollLeft = nextLeft;
        }
        this.updateNavigation();
    }
    isRtl() {
        const element = this.tabHeader()?.nativeElement ?? this.host.nativeElement;
        return (this.host.nativeElement.ownerDocument.defaultView?.getComputedStyle(element).direction === 'rtl');
    }
    maxScroll(header) {
        return Math.max(0, header.scrollWidth - header.clientWidth);
    }
    logicalScrollLeft(header, max) {
        if (!this.isRtl()) {
            return Math.min(max, Math.max(0, header.scrollLeft));
        }
        if (header.scrollLeft < 0) {
            this.rtlScrollMode = 'negative';
            return Math.min(max, -header.scrollLeft);
        }
        if (this.rtlScrollMode === 'positive') {
            return Math.min(max, Math.max(0, header.scrollLeft));
        }
        return 0;
    }
    observeTabItems(observer, header) {
        const current = new Set(Array.from(header.querySelectorAll('.orc-tab-group__tab-item')));
        for (const item of this.observedTabItems) {
            if (!current.has(item)) {
                observer.unobserve(item);
                this.observedTabItems.delete(item);
            }
        }
        for (const item of current) {
            if (!this.observedTabItems.has(item)) {
                observer.observe(item);
                this.observedTabItems.add(item);
            }
        }
    }
    nearestEnabledIndex(index) {
        const tabs = this.visibleTabs();
        const start = Math.min(tabs.length - 1, Math.max(0, index));
        for (let candidate = start; candidate < tabs.length; candidate++) {
            const tab = tabs[candidate];
            if (tab && !tab.disabled())
                return candidate;
        }
        for (let candidate = start - 1; candidate >= 0; candidate--) {
            const tab = tabs[candidate];
            if (tab && !tab.disabled())
                return candidate;
        }
        return this.boundIndex(start);
    }
    // ── Seleção de Aba ────────────────────────────────────────
    selectTab(index) {
        const tabList = this.visibleTabs();
        if (index < 0 || index >= tabList.length)
            return;
        const targetTab = tabList[index];
        if (targetTab.disabled())
            return;
        if (this.activeIndex() === index)
            return;
        this.selectedIndex.set(index);
        this.value.set(index);
        this.lastSelectedIndex = index;
        this.lastValue = index;
        this.selectionIntent.set(index);
        this.focusedIndex.set(index);
        this.loadedTabs.add(targetTab);
        const event = { index, tab: targetTab };
        this.tabChange.emit(event);
        this.onChange.emit(event);
    }
    // ── Navegação Acessível por Teclado (WAI-ARIA Tabs) ───────
    onKeydown(event, currentIndex) {
        const tabList = this.visibleTabs();
        if (!tabList || tabList.length === 0)
            return;
        const enabledIndices = tabList
            .map((tab, idx) => (!tab.disabled() ? idx : -1))
            .filter((idx) => idx !== -1);
        if (enabledIndices.length === 0)
            return;
        const currentPos = enabledIndices.indexOf(currentIndex);
        let targetIndex = -1;
        const rtl = this.host.nativeElement.ownerDocument.defaultView?.getComputedStyle(this.host.nativeElement).direction === 'rtl';
        const forward = rtl
            ? event.key === 'ArrowLeft'
            : event.key === 'ArrowRight';
        const backward = rtl
            ? event.key === 'ArrowRight'
            : event.key === 'ArrowLeft';
        if (forward || event.key === 'ArrowDown') {
            event.preventDefault();
            targetIndex = enabledIndices[(currentPos + 1) % enabledIndices.length];
        }
        else if (backward || event.key === 'ArrowUp') {
            event.preventDefault();
            targetIndex =
                enabledIndices[(currentPos - 1 + enabledIndices.length) % enabledIndices.length];
        }
        else if (event.key === 'Home') {
            event.preventDefault();
            targetIndex = enabledIndices[0];
        }
        else if (event.key === 'End') {
            event.preventDefault();
            targetIndex = enabledIndices[enabledIndices.length - 1];
        }
        else if (event.key === ' ' || event.key === 'Enter') {
            event.preventDefault();
            this.selectTab(currentIndex);
            return;
        }
        if (targetIndex !== -1) {
            this.focusTab(targetIndex);
        }
    }
    onFocus(index) {
        const tab = this.visibleTabs()[index];
        if (!tab || tab.disabled())
            return;
        this.focusedIndex.set(index);
        this.tabFocus.emit({ index, tab });
        if (this.selectOnFocus() && this.activeIndex() !== index)
            this.selectTab(index);
    }
    focusTab(index) {
        const buttons = this.tabButtons();
        if (buttons && buttons[index]) {
            buttons[index].nativeElement.focus();
            return true;
        }
        return false;
    }
    closeTab(index, event) {
        const tab = this.visibleTabs()[index];
        if (!tab || !tab.closable() || tab.disabled())
            return;
        // Invalidate any pending recovery before a new close is processed. A
        // consumer-controlled close may leave the old tab in place, but it still
        // must not allow an earlier microtask to steal focus later.
        const request = ++this.focusRequest;
        this.onClose.emit({ originalEvent: event, index, tab });
        if (this.controlClose())
            return;
        const documentRef = this.host.nativeElement.ownerDocument;
        const activeElement = documentRef.activeElement;
        const target = event.target;
        const item = target instanceof Element
            ? target.closest('.orc-tab-group__tab-item')
            : null;
        const hadFocus = !!item && !!activeElement && item.contains(activeElement);
        const previousActive = this.activeIndex();
        tab.closed.set(true);
        this.loadedTabs.delete(tab);
        const nextIndex = this.nearestEnabledIndex(index < previousActive ? previousActive - 1 : previousActive);
        this.selectedIndex.set(nextIndex);
        this.value.set(nextIndex);
        this.lastSelectedIndex = nextIndex;
        this.lastValue = nextIndex;
        this.selectionIntent.set(nextIndex);
        this.focusedIndex.set(nextIndex);
        if (hadFocus) {
            queueMicrotask(() => {
                if (this.destroyed || request !== this.focusRequest)
                    return;
                if (documentRef.activeElement !== activeElement &&
                    documentRef.activeElement !== documentRef.body) {
                    return;
                }
                this.focusTab(nextIndex);
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: TabGroupComponent, isStandalone: true, selector: "orc-tab-group", inputs: { selectedIndex: { classPropertyName: "selectedIndex", publicName: "selectedIndex", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, fullWidth: { classPropertyName: "fullWidth", publicName: "fullWidth", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, controlClose: { classPropertyName: "controlClose", publicName: "controlClose", isSignal: true, isRequired: false, transformFunction: null }, showNavigators: { classPropertyName: "showNavigators", publicName: "showNavigators", isSignal: true, isRequired: false, transformFunction: null }, nextButtonAriaLabel: { classPropertyName: "nextButtonAriaLabel", publicName: "nextButtonAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, prevButtonAriaLabel: { classPropertyName: "prevButtonAriaLabel", publicName: "prevButtonAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, autoHideButtons: { classPropertyName: "autoHideButtons", publicName: "autoHideButtons", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedIndex: "selectedIndexChange", value: "valueChange", tabChange: "tabChange", onChange: "onChange", tabFocus: "tabFocus", onClose: "onClose" }, queries: [{ propertyName: "tabs", predicate: TabComponent, isSignal: true }], viewQueries: [{ propertyName: "tabButtons", predicate: ["tabBtn"], descendants: true, isSignal: true }, { propertyName: "tabHeader", first: true, predicate: ["tabHeader"], descendants: true, isSignal: true }], ngImport: i0, template: "<!-- Coletor de abas filhas para ContentChildren -->\n<div class=\"orc-tab-group__slot\" aria-hidden=\"true\">\n  <ng-content></ng-content>\n</div>\n\n<div\n  class=\"p-tabview p-component orc-tab-group\"\n  [class]=\"'p-tabview p-component orc-tab-group ' + styleClass()\"\n  [attr.data-pc-name]=\"'tabview'\"\n  [style]=\"style()\"\n  [class.orc-tab-group--variant-line]=\"variant() === 'line'\"\n  [class.orc-tab-group--variant-filled]=\"variant() === 'filled'\"\n  [class.orc-tab-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-tab-group--size-md]=\"size() === 'md'\"\n  [class.orc-tab-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-tab-group--full-width]=\"fullWidth()\"\n  [class.orc-tab-group--scrollable]=\"scrollable()\"\n  [attr.id]=\"id()\"\n>\n  <!-- Barra de Abas (WAI-ARIA Tablist) -->\n  <div class=\"orc-tab-group__navigation\">\n    <button\n      *ngIf=\"\n        scrollable() &&\n        showNavigators() &&\n        (!autoHideButtons() || navigation().previous)\n      \"\n      type=\"button\"\n      class=\"orc-tab-group__navigator orc-tab-group__navigator--previous\"\n      [attr.aria-label]=\"prevButtonAriaLabel() || 'Previous tabs'\"\n      [disabled]=\"!navigation().previous\"\n      (click)=\"scrollTabs('previous')\"\n    >\n      {{ isRtl() ? \"\u203A\" : \"\u2039\" }}\n    </button>\n    <div\n      #tabHeader\n      class=\"p-tabview-nav-container orc-tab-group__header\"\n      role=\"tablist\"\n      [attr.aria-label]=\"ariaLabel()\"\n      (scroll)=\"updateNavigation()\"\n    >\n      <ng-container *ngFor=\"let tab of visibleTabs(); let i = index\">\n        <!-- Divisor sutil entre abas inativas na variante Filled (Figma Node 69:2171) -->\n        <span\n          *ngIf=\"\n            variant() === 'filled' &&\n            i > 0 &&\n            activeIndex() !== i &&\n            activeIndex() !== i - 1\n          \"\n          class=\"orc-tab-group__divider\"\n          aria-hidden=\"true\"\n        ></span>\n\n        <!-- Bot\u00E3o da Aba Individual (WAI-ARIA Tab) -->\n        <div class=\"orc-tab-group__tab-item\">\n          <button\n            #tabBtn\n            type=\"button\"\n            role=\"tab\"\n            class=\"p-tabview-nav-link orc-tab-group__tab\"\n            [class.orc-tab-group__tab--active]=\"activeIndex() === i\"\n            [class.orc-tab-group__tab--disabled]=\"tab.disabled()\"\n            [id]=\"tab.tabId()\"\n            [attr.aria-selected]=\"activeIndex() === i\"\n            [attr.aria-controls]=\"tab.panelId()\"\n            [tabindex]=\"\n              !tab.disabled() && (focusedIndex() ?? activeIndex()) === i\n                ? tabindex()\n                : -1\n            \"\n            [disabled]=\"tab.disabled()\"\n            [title]=\"tab.tooltip() || null\"\n            [class]=\"tab.headerStyleClass()\"\n            [style]=\"tab.headerStyle()\"\n            (click)=\"selectTab(i)\"\n            (focus)=\"onFocus(i)\"\n            (keydown)=\"onKeydown($event, i)\"\n          >\n            <!-- \u00CDcone \u00E0 Esquerda (start) -->\n            <span\n              *ngIf=\"tab.icon() && tab.iconPosition() === 'start'\"\n              class=\"orc-tab-group__icon orc-tab-group__icon--start\"\n              aria-hidden=\"true\"\n            >\n              <!-- Home Icon padr\u00E3o se icon='home' -->\n              <svg\n                *ngIf=\"tab.icon() === 'home'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n              <!-- Settings Icon padr\u00E3o se icon='settings' -->\n              <svg\n                *ngIf=\"tab.icon() === 'settings'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>\n                <path\n                  d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"\n                ></path>\n              </svg>\n              <!-- Warning Icon padr\u00E3o se icon='warning' -->\n              <svg\n                *ngIf=\"tab.icon() === 'warning'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path\n                  d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z\"\n                ></path>\n                <line x1=\"12\" y1=\"9\" x2=\"12\" y2=\"13\"></line>\n                <line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\"></line>\n              </svg>\n            </span>\n\n            <!-- Label / R\u00F3tulo da Aba -->\n            <span class=\"orc-tab-group__label\" *ngIf=\"tab.label()\">\n              {{ tab.label() }}\n            </span>\n\n            <!-- Proje\u00E7\u00E3o Customizada de Label (se houver) -->\n            <ng-container\n              *ngTemplateOutlet=\"tab.customLabelTemplate() || null\"\n            ></ng-container>\n\n            <!-- Badge Opcional -->\n            <span\n              *ngIf=\"tab.badge() !== undefined\"\n              class=\"orc-tab-group__badge\"\n            >\n              {{ tab.badge() }}\n            </span>\n\n            <!-- \u00CDcone \u00E0 Direita (end) -->\n            <span\n              *ngIf=\"tab.icon() && tab.iconPosition() === 'end'\"\n              class=\"orc-tab-group__icon orc-tab-group__icon--end\"\n              aria-hidden=\"true\"\n            >\n              <svg\n                *ngIf=\"tab.icon() === 'home'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n              >\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n              </svg>\n            </span>\n          </button>\n\n          <button\n            *ngIf=\"tab.closable()\"\n            type=\"button\"\n            class=\"orc-tab-group__close\"\n            [disabled]=\"tab.disabled()\"\n            [attr.aria-label]=\"\n              tab.closeAriaLabel() || 'Close ' + (tab.label() || 'tab')\n            \"\n            (click)=\"closeTab(i, $event)\"\n          >\n            \u00D7\n          </button>\n        </div>\n      </ng-container>\n    </div>\n    <button\n      *ngIf=\"\n        scrollable() &&\n        showNavigators() &&\n        (!autoHideButtons() || navigation().next)\n      \"\n      type=\"button\"\n      class=\"orc-tab-group__navigator orc-tab-group__navigator--next\"\n      [attr.aria-label]=\"nextButtonAriaLabel() || 'Next tabs'\"\n      [disabled]=\"!navigation().next\"\n      (click)=\"scrollTabs('next')\"\n    >\n      {{ isRtl() ? \"\u2039\" : \"\u203A\" }}\n    </button>\n  </div>\n\n  <!-- Pain\u00E9is de Conte\u00FAdo das Abas (WAI-ARIA Tabpanels) -->\n  <div class=\"orc-tab-group__panels\">\n    <div\n      *ngFor=\"let tab of visibleTabs(); let i = index\"\n      role=\"tabpanel\"\n      class=\"p-tabview-panel orc-tab-group__panel\"\n      [class.orc-tab-group__panel--active]=\"activeIndex() === i\"\n      [id]=\"tab.panelId()\"\n      [attr.aria-labelledby]=\"tab.tabId()\"\n      [hidden]=\"activeIndex() !== i\"\n      tabindex=\"0\"\n    >\n      <ng-container\n        *ngIf=\"\n          activeIndex() === i ||\n          ((!lazy() || tab.cache()) && loadedTabs.has(tab))\n        \"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.contentTemplate() || null\"\n        ></ng-container>\n      </ng-container>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-tab-group{display:flex;flex-direction:column;width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-tab-group__slot{display:none}.orc-tab-group__header{display:flex;align-items:center;position:relative;-webkit-user-select:none;user-select:none;box-sizing:border-box;overflow-x:auto;scrollbar-width:none}.orc-tab-group__header::-webkit-scrollbar{display:none}.orc-tab-group__navigation{display:flex;align-items:center;min-width:0}.orc-tab-group__navigator{display:inline-flex;align-items:center;justify-content:center;flex:0 0 32px;width:32px;height:32px;padding:0;border:0;border-radius:50%;background:transparent;color:var(--orc-text, var(--orc-font-main, #141414));cursor:pointer;font-size:1.5rem}.orc-tab-group__navigator:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-1px}.orc-tab-group__tab-item{display:inline-flex;align-items:center;flex-shrink:0}.orc-tab-group__tab{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;cursor:pointer;font-family:inherit;white-space:nowrap;text-decoration:none;flex-shrink:0;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease);outline:none;box-sizing:border-box}.orc-tab-group__tab:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-tab-group__close{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:-8px;padding:0;border:0;border-radius:50%;background:transparent;color:currentColor;cursor:pointer;font:inherit}.orc-tab-group__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-1px}.orc-tab-group__close:disabled{cursor:not-allowed;opacity:.45}.orc-tab-group__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-tab-group__icon svg{width:100%;height:100%}.orc-tab-group__icon--start{margin-right:8px}.orc-tab-group__icon--end{margin-left:8px}.orc-tab-group__badge{display:inline-flex;align-items:center;justify-content:center;font-size:.6875rem;font-weight:600;padding:1px 6px;border-radius:9999px;background:var(--orc-interactive-soft);color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));margin-left:8px}.orc-tab-group--full-width .orc-tab-group__header{width:100%}.orc-tab-group--full-width .orc-tab-group__tab-item{flex:1 1 0;min-width:0}.orc-tab-group--full-width .orc-tab-group__tab{flex:1 1 auto;min-width:0;width:100%}.orc-tab-group--variant-line .orc-tab-group__header{box-shadow:inset 0 -2px 0 var(--orc-surface-muted, var(--highlight-cinzaclaro, #ededed));gap:0}.orc-tab-group--variant-line .orc-tab-group__tab{height:44px;padding:0 20px;font-size:1rem;font-weight:400;color:var(--orc-text-muted, #929292);box-shadow:inset 0 -2px 0 transparent}.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:20px;height:20px;color:var(--orc-text-muted, #929292)}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled){color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled) .orc-tab-group__icon{color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-line .orc-tab-group__tab--active{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600;box-shadow:inset 0 -2px 0 var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-tab-group--variant-line .orc-tab-group__tab--active .orc-tab-group__icon{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-tab-group--variant-line .orc-tab-group__tab--disabled{opacity:.25;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__header{background:var(--orc-surface-muted, var(--highlight-cinzaclaro, #ededed));padding:5px;border-radius:10px;display:inline-flex;align-items:center;gap:2px;width:fit-content}.orc-tab-group--variant-filled .orc-tab-group__tab{height:34px;padding:0 16px;font-size:.9375rem;font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));border-radius:10px;transition:all var(--transition-fast, .12s ease)}.orc-tab-group--variant-filled .orc-tab-group__tab .orc-tab-group__icon{width:18px;height:18px}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active){color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab));background-color:color-mix(in srgb,var(--orc-surface-raised) 60%,transparent)}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active) .orc-tab-group__icon{color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-filled .orc-tab-group__tab--active{background-color:var(--orc-surface-raised, var(--bg, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));font-weight:500;box-shadow:var(--shadow-sm)}.orc-tab-group--variant-filled .orc-tab-group__tab--disabled{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__divider{display:inline-block;width:1px;height:16px;background-color:var(--orc-border-default, #d4d4d8);margin:0 2px}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab{height:36px;padding:0 14px;font-size:.875rem}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:16px;height:16px}.orc-tab-group--size-sm.orc-tab-group--variant-filled .orc-tab-group__tab{height:28px;padding:0 12px;font-size:.8125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab{height:52px;padding:0 26px;font-size:1.125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:24px;height:24px}.orc-tab-group--size-lg.orc-tab-group--variant-filled .orc-tab-group__tab{height:42px;padding:0 22px;font-size:1.0625rem}.orc-tab-group__panels{width:100%;margin-top:var(--space-4, 1rem)}.orc-tab-group__panel{outline:none}.orc-tab-group__panel:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-sm, 6px)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TabGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tab-group', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<!-- Coletor de abas filhas para ContentChildren -->\n<div class=\"orc-tab-group__slot\" aria-hidden=\"true\">\n  <ng-content></ng-content>\n</div>\n\n<div\n  class=\"p-tabview p-component orc-tab-group\"\n  [class]=\"'p-tabview p-component orc-tab-group ' + styleClass()\"\n  [attr.data-pc-name]=\"'tabview'\"\n  [style]=\"style()\"\n  [class.orc-tab-group--variant-line]=\"variant() === 'line'\"\n  [class.orc-tab-group--variant-filled]=\"variant() === 'filled'\"\n  [class.orc-tab-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-tab-group--size-md]=\"size() === 'md'\"\n  [class.orc-tab-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-tab-group--full-width]=\"fullWidth()\"\n  [class.orc-tab-group--scrollable]=\"scrollable()\"\n  [attr.id]=\"id()\"\n>\n  <!-- Barra de Abas (WAI-ARIA Tablist) -->\n  <div class=\"orc-tab-group__navigation\">\n    <button\n      *ngIf=\"\n        scrollable() &&\n        showNavigators() &&\n        (!autoHideButtons() || navigation().previous)\n      \"\n      type=\"button\"\n      class=\"orc-tab-group__navigator orc-tab-group__navigator--previous\"\n      [attr.aria-label]=\"prevButtonAriaLabel() || 'Previous tabs'\"\n      [disabled]=\"!navigation().previous\"\n      (click)=\"scrollTabs('previous')\"\n    >\n      {{ isRtl() ? \"\u203A\" : \"\u2039\" }}\n    </button>\n    <div\n      #tabHeader\n      class=\"p-tabview-nav-container orc-tab-group__header\"\n      role=\"tablist\"\n      [attr.aria-label]=\"ariaLabel()\"\n      (scroll)=\"updateNavigation()\"\n    >\n      <ng-container *ngFor=\"let tab of visibleTabs(); let i = index\">\n        <!-- Divisor sutil entre abas inativas na variante Filled (Figma Node 69:2171) -->\n        <span\n          *ngIf=\"\n            variant() === 'filled' &&\n            i > 0 &&\n            activeIndex() !== i &&\n            activeIndex() !== i - 1\n          \"\n          class=\"orc-tab-group__divider\"\n          aria-hidden=\"true\"\n        ></span>\n\n        <!-- Bot\u00E3o da Aba Individual (WAI-ARIA Tab) -->\n        <div class=\"orc-tab-group__tab-item\">\n          <button\n            #tabBtn\n            type=\"button\"\n            role=\"tab\"\n            class=\"p-tabview-nav-link orc-tab-group__tab\"\n            [class.orc-tab-group__tab--active]=\"activeIndex() === i\"\n            [class.orc-tab-group__tab--disabled]=\"tab.disabled()\"\n            [id]=\"tab.tabId()\"\n            [attr.aria-selected]=\"activeIndex() === i\"\n            [attr.aria-controls]=\"tab.panelId()\"\n            [tabindex]=\"\n              !tab.disabled() && (focusedIndex() ?? activeIndex()) === i\n                ? tabindex()\n                : -1\n            \"\n            [disabled]=\"tab.disabled()\"\n            [title]=\"tab.tooltip() || null\"\n            [class]=\"tab.headerStyleClass()\"\n            [style]=\"tab.headerStyle()\"\n            (click)=\"selectTab(i)\"\n            (focus)=\"onFocus(i)\"\n            (keydown)=\"onKeydown($event, i)\"\n          >\n            <!-- \u00CDcone \u00E0 Esquerda (start) -->\n            <span\n              *ngIf=\"tab.icon() && tab.iconPosition() === 'start'\"\n              class=\"orc-tab-group__icon orc-tab-group__icon--start\"\n              aria-hidden=\"true\"\n            >\n              <!-- Home Icon padr\u00E3o se icon='home' -->\n              <svg\n                *ngIf=\"tab.icon() === 'home'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n                <polyline points=\"9 22 9 12 15 12 15 22\"></polyline>\n              </svg>\n              <!-- Settings Icon padr\u00E3o se icon='settings' -->\n              <svg\n                *ngIf=\"tab.icon() === 'settings'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>\n                <path\n                  d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\"\n                ></path>\n              </svg>\n              <!-- Warning Icon padr\u00E3o se icon='warning' -->\n              <svg\n                *ngIf=\"tab.icon() === 'warning'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n                stroke-linecap=\"round\"\n                stroke-linejoin=\"round\"\n              >\n                <path\n                  d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z\"\n                ></path>\n                <line x1=\"12\" y1=\"9\" x2=\"12\" y2=\"13\"></line>\n                <line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\"></line>\n              </svg>\n            </span>\n\n            <!-- Label / R\u00F3tulo da Aba -->\n            <span class=\"orc-tab-group__label\" *ngIf=\"tab.label()\">\n              {{ tab.label() }}\n            </span>\n\n            <!-- Proje\u00E7\u00E3o Customizada de Label (se houver) -->\n            <ng-container\n              *ngTemplateOutlet=\"tab.customLabelTemplate() || null\"\n            ></ng-container>\n\n            <!-- Badge Opcional -->\n            <span\n              *ngIf=\"tab.badge() !== undefined\"\n              class=\"orc-tab-group__badge\"\n            >\n              {{ tab.badge() }}\n            </span>\n\n            <!-- \u00CDcone \u00E0 Direita (end) -->\n            <span\n              *ngIf=\"tab.icon() && tab.iconPosition() === 'end'\"\n              class=\"orc-tab-group__icon orc-tab-group__icon--end\"\n              aria-hidden=\"true\"\n            >\n              <svg\n                *ngIf=\"tab.icon() === 'home'\"\n                viewBox=\"0 0 24 24\"\n                fill=\"none\"\n                stroke=\"currentColor\"\n                stroke-width=\"2\"\n              >\n                <path d=\"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"></path>\n              </svg>\n            </span>\n          </button>\n\n          <button\n            *ngIf=\"tab.closable()\"\n            type=\"button\"\n            class=\"orc-tab-group__close\"\n            [disabled]=\"tab.disabled()\"\n            [attr.aria-label]=\"\n              tab.closeAriaLabel() || 'Close ' + (tab.label() || 'tab')\n            \"\n            (click)=\"closeTab(i, $event)\"\n          >\n            \u00D7\n          </button>\n        </div>\n      </ng-container>\n    </div>\n    <button\n      *ngIf=\"\n        scrollable() &&\n        showNavigators() &&\n        (!autoHideButtons() || navigation().next)\n      \"\n      type=\"button\"\n      class=\"orc-tab-group__navigator orc-tab-group__navigator--next\"\n      [attr.aria-label]=\"nextButtonAriaLabel() || 'Next tabs'\"\n      [disabled]=\"!navigation().next\"\n      (click)=\"scrollTabs('next')\"\n    >\n      {{ isRtl() ? \"\u2039\" : \"\u203A\" }}\n    </button>\n  </div>\n\n  <!-- Pain\u00E9is de Conte\u00FAdo das Abas (WAI-ARIA Tabpanels) -->\n  <div class=\"orc-tab-group__panels\">\n    <div\n      *ngFor=\"let tab of visibleTabs(); let i = index\"\n      role=\"tabpanel\"\n      class=\"p-tabview-panel orc-tab-group__panel\"\n      [class.orc-tab-group__panel--active]=\"activeIndex() === i\"\n      [id]=\"tab.panelId()\"\n      [attr.aria-labelledby]=\"tab.tabId()\"\n      [hidden]=\"activeIndex() !== i\"\n      tabindex=\"0\"\n    >\n      <ng-container\n        *ngIf=\"\n          activeIndex() === i ||\n          ((!lazy() || tab.cache()) && loadedTabs.has(tab))\n        \"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.contentTemplate() || null\"\n        ></ng-container>\n      </ng-container>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-tab-group{display:flex;flex-direction:column;width:100%;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-tab-group__slot{display:none}.orc-tab-group__header{display:flex;align-items:center;position:relative;-webkit-user-select:none;user-select:none;box-sizing:border-box;overflow-x:auto;scrollbar-width:none}.orc-tab-group__header::-webkit-scrollbar{display:none}.orc-tab-group__navigation{display:flex;align-items:center;min-width:0}.orc-tab-group__navigator{display:inline-flex;align-items:center;justify-content:center;flex:0 0 32px;width:32px;height:32px;padding:0;border:0;border-radius:50%;background:transparent;color:var(--orc-text, var(--orc-font-main, #141414));cursor:pointer;font-size:1.5rem}.orc-tab-group__navigator:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-1px}.orc-tab-group__tab-item{display:inline-flex;align-items:center;flex-shrink:0}.orc-tab-group__tab{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:none;cursor:pointer;font-family:inherit;white-space:nowrap;text-decoration:none;flex-shrink:0;transition:color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease);outline:none;box-sizing:border-box}.orc-tab-group__tab:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-tab-group__close{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:-8px;padding:0;border:0;border-radius:50%;background:transparent;color:currentColor;cursor:pointer;font:inherit}.orc-tab-group__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-1px}.orc-tab-group__close:disabled{cursor:not-allowed;opacity:.45}.orc-tab-group__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.orc-tab-group__icon svg{width:100%;height:100%}.orc-tab-group__icon--start{margin-right:8px}.orc-tab-group__icon--end{margin-left:8px}.orc-tab-group__badge{display:inline-flex;align-items:center;justify-content:center;font-size:.6875rem;font-weight:600;padding:1px 6px;border-radius:9999px;background:var(--orc-interactive-soft);color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));margin-left:8px}.orc-tab-group--full-width .orc-tab-group__header{width:100%}.orc-tab-group--full-width .orc-tab-group__tab-item{flex:1 1 0;min-width:0}.orc-tab-group--full-width .orc-tab-group__tab{flex:1 1 auto;min-width:0;width:100%}.orc-tab-group--variant-line .orc-tab-group__header{box-shadow:inset 0 -2px 0 var(--orc-surface-muted, var(--highlight-cinzaclaro, #ededed));gap:0}.orc-tab-group--variant-line .orc-tab-group__tab{height:44px;padding:0 20px;font-size:1rem;font-weight:400;color:var(--orc-text-muted, #929292);box-shadow:inset 0 -2px 0 transparent}.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:20px;height:20px;color:var(--orc-text-muted, #929292)}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled){color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-line .orc-tab-group__tab:hover:not(:disabled) .orc-tab-group__icon{color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-line .orc-tab-group__tab--active{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));font-weight:600;box-shadow:inset 0 -2px 0 var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-tab-group--variant-line .orc-tab-group__tab--active .orc-tab-group__icon{color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-tab-group--variant-line .orc-tab-group__tab--disabled{opacity:.25;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__header{background:var(--orc-surface-muted, var(--highlight-cinzaclaro, #ededed));padding:5px;border-radius:10px;display:inline-flex;align-items:center;gap:2px;width:fit-content}.orc-tab-group--variant-filled .orc-tab-group__tab{height:34px;padding:0 16px;font-size:.9375rem;font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));border-radius:10px;transition:all var(--transition-fast, .12s ease)}.orc-tab-group--variant-filled .orc-tab-group__tab .orc-tab-group__icon{width:18px;height:18px}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active){color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab));background-color:color-mix(in srgb,var(--orc-surface-raised) 60%,transparent)}.orc-tab-group--variant-filled .orc-tab-group__tab:hover:not(:disabled):not(.orc-tab-group__tab--active) .orc-tab-group__icon{color:var(--orc-interactive-hover, var(--orc-color-azul-royal, #0406ab))}.orc-tab-group--variant-filled .orc-tab-group__tab--active{background-color:var(--orc-surface-raised, var(--bg, #ffffff));color:var(--orc-text, var(--orc-font-main, #141414));font-weight:500;box-shadow:var(--shadow-sm)}.orc-tab-group--variant-filled .orc-tab-group__tab--disabled{opacity:.35;cursor:not-allowed;pointer-events:none}.orc-tab-group--variant-filled .orc-tab-group__divider{display:inline-block;width:1px;height:16px;background-color:var(--orc-border-default, #d4d4d8);margin:0 2px}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab{height:36px;padding:0 14px;font-size:.875rem}.orc-tab-group--size-sm.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:16px;height:16px}.orc-tab-group--size-sm.orc-tab-group--variant-filled .orc-tab-group__tab{height:28px;padding:0 12px;font-size:.8125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab{height:52px;padding:0 26px;font-size:1.125rem}.orc-tab-group--size-lg.orc-tab-group--variant-line .orc-tab-group__tab .orc-tab-group__icon{width:24px;height:24px}.orc-tab-group--size-lg.orc-tab-group--variant-filled .orc-tab-group__tab{height:42px;padding:0 22px;font-size:1.0625rem}.orc-tab-group__panels{width:100%;margin-top:var(--space-4, 1rem)}.orc-tab-group__panel{outline:none}.orc-tab-group__panel:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-radius:var(--radius-sm, 6px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { selectedIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedIndex", required: false }] }, { type: i0.Output, args: ["selectedIndexChange"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], fullWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "fullWidth", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], controlClose: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlClose", required: false }] }], showNavigators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showNavigators", required: false }] }], nextButtonAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextButtonAriaLabel", required: false }] }], prevButtonAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "prevButtonAriaLabel", required: false }] }], autoHideButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHideButtons", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], tabChange: [{ type: i0.Output, args: ["tabChange"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], tabFocus: [{ type: i0.Output, args: ["tabFocus"] }], onClose: [{ type: i0.Output, args: ["onClose"] }], tabs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => TabComponent), { isSignal: true }] }], tabButtons: [{ type: i0.ViewChildren, args: ['tabBtn', { isSignal: true }] }], tabHeader: [{ type: i0.ViewChild, args: ['tabHeader', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { TabComponent, TabGroupComponent };
//# sourceMappingURL=ciag-orchestra-tabs.mjs.map
