export { GridComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-grid.mjs.map
