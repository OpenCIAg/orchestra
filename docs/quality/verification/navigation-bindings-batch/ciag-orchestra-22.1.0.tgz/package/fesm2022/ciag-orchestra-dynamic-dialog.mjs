export { ModalComponent as DynamicDialogComponent, ModalRef as DynamicDialogRef, ModalService as DynamicDialogService } from '@ciag/orchestra/modal';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-dynamic-dialog.mjs.map
