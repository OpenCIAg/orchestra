export * from '@ciag/orchestra/multi-select';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-multiselect.mjs.map
