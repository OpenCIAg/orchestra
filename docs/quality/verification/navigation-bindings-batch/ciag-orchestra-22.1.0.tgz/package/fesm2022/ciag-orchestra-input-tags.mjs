export { TagsInputComponent as InputTagsComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-tags.mjs.map
