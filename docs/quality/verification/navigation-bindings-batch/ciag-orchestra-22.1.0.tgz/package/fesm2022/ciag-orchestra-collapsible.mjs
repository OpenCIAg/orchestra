import * as i0 from '@angular/core';
import { input, model, booleanAttribute, output, computed, ChangeDetectionStrategy, Component } from '@angular/core';

let nextCollapsibleId = 0;
class CollapsibleComponent {
    uniqueId = `orc-collapsible-${++nextCollapsibleId}`;
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    title = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    summary = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "summary" }] : /* istanbul ignore next */ []));
    open = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    toggleChange = output();
    effectiveId = computed(() => this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    triggerId = computed(() => `${this.effectiveId()}-trigger`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "triggerId" }] : /* istanbul ignore next */ []));
    contentId = computed(() => `${this.effectiveId()}-content`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentId" }] : /* istanbul ignore next */ []));
    toggle() {
        if (this.disabled())
            return;
        this.open.update(value => !value);
        this.toggleChange.emit(this.open());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CollapsibleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CollapsibleComponent, isStandalone: true, selector: "orc-collapsible", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, summary: { classPropertyName: "summary", publicName: "summary", isSignal: true, isRequired: false, transformFunction: null }, open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", toggleChange: "toggleChange" }, ngImport: i0, template: "<section class=\"orc-collapsible\" [class.orc-collapsible--open]=\"open()\" [class.orc-collapsible--disabled]=\"disabled()\">\n  <button type=\"button\" class=\"orc-collapsible__trigger\" [id]=\"triggerId()\" [attr.aria-controls]=\"contentId()\" [attr.aria-expanded]=\"open()\" [disabled]=\"disabled()\" (click)=\"toggle()\">\n    <span class=\"orc-collapsible__heading\"><strong>{{ title() }}</strong>@if (summary()) { <small>{{ summary() }}</small> }</span>\n    <span class=\"orc-collapsible__chevron\" aria-hidden=\"true\">\u2304</span>\n  </button>\n  @if (open() || !lazy()) { <div class=\"orc-collapsible__content\" [id]=\"contentId()\" role=\"region\" [attr.aria-labelledby]=\"triggerId()\" [hidden]=\"!open()\"><ng-content /></div> }\n</section>\n", styles: [":host{display:block;width:100%}.orc-collapsible{overflow:hidden;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-collapsible__trigger{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;padding:14px 16px;border:0;background:transparent;color:var(--orc-text, var(--text-primary, #141414));text-align:left;cursor:pointer}.orc-collapsible__trigger:hover:not(:disabled){background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-collapsible__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-collapsible__trigger:disabled{cursor:not-allowed}.orc-collapsible__heading{display:grid;gap:3px;min-width:0}.orc-collapsible__heading strong{font-size:14px}.orc-collapsible__heading small{color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px;font-weight:400}.orc-collapsible__chevron{transition:transform .2s;font-size:18px}.orc-collapsible--open .orc-collapsible__chevron{transform:rotate(180deg)}.orc-collapsible__content{padding:0 16px 16px;color:var(--orc-text-secondary, var(--text-secondary, #666));line-height:1.5}.orc-collapsible--disabled{opacity:.55}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CollapsibleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-collapsible', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"orc-collapsible\" [class.orc-collapsible--open]=\"open()\" [class.orc-collapsible--disabled]=\"disabled()\">\n  <button type=\"button\" class=\"orc-collapsible__trigger\" [id]=\"triggerId()\" [attr.aria-controls]=\"contentId()\" [attr.aria-expanded]=\"open()\" [disabled]=\"disabled()\" (click)=\"toggle()\">\n    <span class=\"orc-collapsible__heading\"><strong>{{ title() }}</strong>@if (summary()) { <small>{{ summary() }}</small> }</span>\n    <span class=\"orc-collapsible__chevron\" aria-hidden=\"true\">\u2304</span>\n  </button>\n  @if (open() || !lazy()) { <div class=\"orc-collapsible__content\" [id]=\"contentId()\" role=\"region\" [attr.aria-labelledby]=\"triggerId()\" [hidden]=\"!open()\"><ng-content /></div> }\n</section>\n", styles: [":host{display:block;width:100%}.orc-collapsible{overflow:hidden;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-collapsible__trigger{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;padding:14px 16px;border:0;background:transparent;color:var(--orc-text, var(--text-primary, #141414));text-align:left;cursor:pointer}.orc-collapsible__trigger:hover:not(:disabled){background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-collapsible__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-collapsible__trigger:disabled{cursor:not-allowed}.orc-collapsible__heading{display:grid;gap:3px;min-width:0}.orc-collapsible__heading strong{font-size:14px}.orc-collapsible__heading small{color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px;font-weight:400}.orc-collapsible__chevron{transition:transform .2s;font-size:18px}.orc-collapsible--open .orc-collapsible__chevron{transform:rotate(180deg)}.orc-collapsible__content{padding:0 16px 16px;color:var(--orc-text-secondary, var(--text-secondary, #666));line-height:1.5}.orc-collapsible--disabled{opacity:.55}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], summary: [{ type: i0.Input, args: [{ isSignal: true, alias: "summary", required: false }] }], open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], toggleChange: [{ type: i0.Output, args: ["toggleChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CollapsibleComponent };
//# sourceMappingURL=ciag-orchestra-collapsible.mjs.map
