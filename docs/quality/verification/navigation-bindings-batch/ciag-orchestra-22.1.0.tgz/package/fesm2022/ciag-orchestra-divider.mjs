import * as i0 from '@angular/core';
import { input, booleanAttribute, computed, ChangeDetectionStrategy, Component } from '@angular/core';

class DividerComponent {
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    variant = input('solid', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    inset = input(false, { ...(ngDevMode ? { debugName: "inset" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    decorative = input(true, { ...(ngDevMode ? { debugName: "decorative" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    classes = computed(() => ({
        'orc-divider': true,
        'orc-divider--vertical': this.orientation() === 'vertical',
        'orc-divider--inset': this.inset(),
        [`orc-divider--${this.variant()}`]: true,
        'orc-divider--labeled': !!this.label(),
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: DividerComponent, isStandalone: true, selector: "orc-divider", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, inset: { classPropertyName: "inset", publicName: "inset", isSignal: true, isRequired: false, transformFunction: null }, decorative: { classPropertyName: "decorative", publicName: "decorative", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\n  [class]=\"classes()\"\n  [attr.role]=\"decorative() ? null : 'separator'\"\n  [attr.aria-orientation]=\"decorative() ? null : orientation()\"\n  [attr.aria-label]=\"decorative() ? null : ariaLabel() || label() || null\"\n  [attr.aria-hidden]=\"decorative() ? 'true' : null\"\n>\n  <span class=\"orc-divider__line\"></span>\n  <span class=\"orc-divider__label\">{{ label() }}<ng-content></ng-content></span>\n  <span class=\"orc-divider__line\"></span>\n</div>\n", styles: [":host{display:block;width:100%}.orc-divider{display:flex;align-items:center;gap:12px;width:100%;color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-divider--inset{padding-inline:16px;box-sizing:border-box}.orc-divider__line{flex:1;min-width:0;border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-divider--dashed .orc-divider__line{border-top-style:dashed}.orc-divider--dotted .orc-divider__line{border-top-style:dotted}.orc-divider__label{font-size:12px;white-space:nowrap}.orc-divider__label:empty,.orc-divider__label:empty+.orc-divider__line{display:none}.orc-divider--vertical{width:auto;min-height:24px;height:100%;flex-direction:column}.orc-divider--vertical .orc-divider__line{width:1px;height:auto;min-height:12px;border-top:0;border-left:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-divider--vertical.orc-divider--dashed .orc-divider__line{border-left-style:dashed}.orc-divider--vertical.orc-divider--dotted .orc-divider__line{border-left-style:dotted}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-divider', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [class]=\"classes()\"\n  [attr.role]=\"decorative() ? null : 'separator'\"\n  [attr.aria-orientation]=\"decorative() ? null : orientation()\"\n  [attr.aria-label]=\"decorative() ? null : ariaLabel() || label() || null\"\n  [attr.aria-hidden]=\"decorative() ? 'true' : null\"\n>\n  <span class=\"orc-divider__line\"></span>\n  <span class=\"orc-divider__label\">{{ label() }}<ng-content></ng-content></span>\n  <span class=\"orc-divider__line\"></span>\n</div>\n", styles: [":host{display:block;width:100%}.orc-divider{display:flex;align-items:center;gap:12px;width:100%;color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-divider--inset{padding-inline:16px;box-sizing:border-box}.orc-divider__line{flex:1;min-width:0;border-top:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-divider--dashed .orc-divider__line{border-top-style:dashed}.orc-divider--dotted .orc-divider__line{border-top-style:dotted}.orc-divider__label{font-size:12px;white-space:nowrap}.orc-divider__label:empty,.orc-divider__label:empty+.orc-divider__line{display:none}.orc-divider--vertical{width:auto;min-height:24px;height:100%;flex-direction:column}.orc-divider--vertical .orc-divider__line{width:1px;height:auto;min-height:12px;border-top:0;border-left:1px solid var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-divider--vertical.orc-divider--dashed .orc-divider__line{border-left-style:dashed}.orc-divider--vertical.orc-divider--dotted .orc-divider__line{border-left-style:dotted}\n"] }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], inset: [{ type: i0.Input, args: [{ isSignal: true, alias: "inset", required: false }] }], decorative: [{ type: i0.Input, args: [{ isSignal: true, alias: "decorative", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DividerComponent };
//# sourceMappingURL=ciag-orchestra-divider.mjs.map
