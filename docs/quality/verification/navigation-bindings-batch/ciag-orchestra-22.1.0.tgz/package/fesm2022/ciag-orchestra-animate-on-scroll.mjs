export { AnimateOnScrollDirective } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-animate-on-scroll.mjs.map
