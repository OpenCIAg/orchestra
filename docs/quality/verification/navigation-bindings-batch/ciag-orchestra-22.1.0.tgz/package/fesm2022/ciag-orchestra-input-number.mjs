export { NumberInputComponent as InputNumber, NumberInputComponent as InputNumberComponent } from '@ciag/orchestra/number-input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-number.mjs.map
