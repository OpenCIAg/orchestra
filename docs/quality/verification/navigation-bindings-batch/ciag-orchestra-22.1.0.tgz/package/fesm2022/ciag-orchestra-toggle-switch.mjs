export { SwitchComponent as ToggleSwitch, SwitchComponent as ToggleSwitchComponent } from '@ciag/orchestra/switch';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-toggle-switch.mjs.map
