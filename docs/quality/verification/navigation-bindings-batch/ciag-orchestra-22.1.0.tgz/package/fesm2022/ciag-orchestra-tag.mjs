import * as i0 from '@angular/core';
import { input, booleanAttribute, output, ChangeDetectionStrategy, Component } from '@angular/core';

class TagComponent {
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    variant = input('neutral', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    severity = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    icon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    rounded = input(false, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    removable = input(false, { ...(ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    removeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeAriaLabel" }] : /* istanbul ignore next */ []));
    removed = output();
    onRemove = output();
    effectiveLabel() {
        return this.value() ?? this.label() ?? '';
    }
    effectiveVariant() {
        return this.severity() ?? this.variant();
    }
    remove(event) {
        event.stopPropagation();
        if (!this.disabled()) {
            const value = this.value() ?? this.label() ?? '';
            this.removed.emit(value);
            this.onRemove.emit({ value });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TagComponent, isStandalone: true, selector: "orc-tag", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, removeAriaLabel: { classPropertyName: "removeAriaLabel", publicName: "removeAriaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { removed: "removed", onRemove: "onRemove" }, ngImport: i0, template: `<span
    class="orc-tag"
    [class]="
      'orc-tag orc-p2-tag orc-tag--' +
      effectiveVariant() +
      ' orc-p2-tag--' +
      effectiveVariant() +
      ' ' +
      styleClass()
    "
    [class.orc-tag--rounded]="rounded()"
    [class.rounded]="rounded()"
    [class.disabled]="disabled()"
    [attr.aria-disabled]="disabled() || null"
  >
    @if (icon()) {
      <span aria-hidden="true">{{ icon() }}</span>
    }
    <span>{{ value() ?? label() }}</span>
    @if (removable()) {
      <button
        type="button"
        [disabled]="disabled()"
        [attr.aria-label]="removeAriaLabel() || 'Remove ' + effectiveLabel()"
        (click)="remove($event)"
      >
        ×
      </button>
    }
  </span>`, isInline: true, styles: [":host{display:inline-block}.orc-tag{display:inline-flex;align-items:center;gap:.3rem;min-height:1.6rem;padding:.2rem .55rem;border-radius:.35rem;font-size:.8rem;font-weight:600;background:var(--orc-surface-muted,#f1f5f9);color:var(--orc-text-secondary,#475569)}.orc-tag--rounded{border-radius:999px}.orc-tag--primary,.orc-tag--info{background:var(--orc-interactive-soft,#eff6ff);color:var(--orc-interactive-hover,#1d4ed8)}.orc-tag--success{background:var(--orc-status-success-bg,#dcfce7);color:var(--orc-status-success-fg,#166534)}.orc-tag--warning{background:var(--orc-status-warning-bg,#fef3c7);color:var(--orc-status-warning-fg,#92400e)}.orc-tag--danger{background:var(--orc-status-danger-bg,#fee2e2);color:var(--orc-status-danger-fg,#991b1b)}button{border:0;background:transparent;color:inherit;padding:0;font:inherit;cursor:pointer}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-tag', standalone: true, template: `<span
    class="orc-tag"
    [class]="
      'orc-tag orc-p2-tag orc-tag--' +
      effectiveVariant() +
      ' orc-p2-tag--' +
      effectiveVariant() +
      ' ' +
      styleClass()
    "
    [class.orc-tag--rounded]="rounded()"
    [class.rounded]="rounded()"
    [class.disabled]="disabled()"
    [attr.aria-disabled]="disabled() || null"
  >
    @if (icon()) {
      <span aria-hidden="true">{{ icon() }}</span>
    }
    <span>{{ value() ?? label() }}</span>
    @if (removable()) {
      <button
        type="button"
        [disabled]="disabled()"
        [attr.aria-label]="removeAriaLabel() || 'Remove ' + effectiveLabel()"
        (click)="remove($event)"
      >
        ×
      </button>
    }
  </span>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-block}.orc-tag{display:inline-flex;align-items:center;gap:.3rem;min-height:1.6rem;padding:.2rem .55rem;border-radius:.35rem;font-size:.8rem;font-weight:600;background:var(--orc-surface-muted,#f1f5f9);color:var(--orc-text-secondary,#475569)}.orc-tag--rounded{border-radius:999px}.orc-tag--primary,.orc-tag--info{background:var(--orc-interactive-soft,#eff6ff);color:var(--orc-interactive-hover,#1d4ed8)}.orc-tag--success{background:var(--orc-status-success-bg,#dcfce7);color:var(--orc-status-success-fg,#166534)}.orc-tag--warning{background:var(--orc-status-warning-bg,#fef3c7);color:var(--orc-status-warning-fg,#92400e)}.orc-tag--danger{background:var(--orc-status-danger-bg,#fee2e2);color:var(--orc-status-danger-fg,#991b1b)}button{border:0;background:transparent;color:inherit;padding:0;font:inherit;cursor:pointer}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], removable: [{ type: i0.Input, args: [{ isSignal: true, alias: "removable", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], removeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeAriaLabel", required: false }] }], removed: [{ type: i0.Output, args: ["removed"] }], onRemove: [{ type: i0.Output, args: ["onRemove"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { TagComponent };
//# sourceMappingURL=ciag-orchestra-tag.mjs.map
