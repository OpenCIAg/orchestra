export { PaginatorComponent as PaginationComponent } from '@ciag/orchestra/paginator';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-pagination.mjs.map
