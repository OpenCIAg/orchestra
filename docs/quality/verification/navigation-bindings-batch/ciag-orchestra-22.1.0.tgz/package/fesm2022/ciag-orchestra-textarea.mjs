export { TextareaComponent as Textarea } from '@ciag/orchestra/input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-textarea.mjs.map
