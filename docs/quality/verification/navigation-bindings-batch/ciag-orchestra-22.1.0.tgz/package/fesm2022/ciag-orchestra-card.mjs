import * as i0 from '@angular/core';
import { input, booleanAttribute, output, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

class CardComponent {
    clickable = input(false, { ...(ngDevMode ? { debugName: "clickable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected = input(false, { ...(ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input('simple', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    flush = input(false, { ...(ngDevMode ? { debugName: "flush" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    media = input(false, { ...(ngDevMode ? { debugName: "media" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    padding = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []));
    clip = input(false, { ...(ngDevMode ? { debugName: "clip" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    header = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    subheader = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subheader" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    cardClick = output();
    onClickEvent = output();
    onClick() {
        if (this.clickable()) {
            this.cardClick.emit();
        }
    }
    onCardClick(event) {
        if (!this.clickable() || this.isNestedInteractive(event))
            return;
        this.activate(event);
    }
    onPrimaryClick(event) {
        if (!this.clickable())
            return;
        this.activate(event);
    }
    activate(event) {
        this.onClick();
        this.onClickEvent.emit(event);
    }
    isNestedInteractive(event) {
        const target = event.target;
        const current = event.currentTarget;
        if (!(target instanceof Element) || !(current instanceof Element)) {
            return false;
        }
        const selector = 'a,button,input,select,textarea,[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="slider"],[role="combobox"],[role="switch"],[role="tab"],[role="menuitem"],[tabindex]';
        const path = event.composedPath();
        const boundary = path.slice(0, Math.max(path.indexOf(current), 0));
        return boundary.some((node) => node instanceof Element && node.matches(selector));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CardComponent, isStandalone: true, selector: "orc-card", inputs: { clickable: { classPropertyName: "clickable", publicName: "clickable", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, flush: { classPropertyName: "flush", publicName: "flush", isSignal: true, isRequired: false, transformFunction: null }, media: { classPropertyName: "media", publicName: "media", isSignal: true, isRequired: false, transformFunction: null }, padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, clip: { classPropertyName: "clip", publicName: "clip", isSignal: true, isRequired: false, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, subheader: { classPropertyName: "subheader", publicName: "subheader", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { cardClick: "cardClick", onClickEvent: "onClickEvent" }, ngImport: i0, template: "<article\n  class=\"card {{ styleClass() }}\"\n  [style]=\"style()\"\n  [class.card--clickable]=\"clickable()\"\n  [class.card--selected]=\"selected()\"\n  [class.card--dashboard]=\"variant() === 'dashboard'\"\n  [class.card--flush]=\"flush() || media()\"\n  [class.card--media]=\"media()\"\n  [class.card--clip]=\"clip() || media()\"\n  [style.padding]=\"padding() ?? null\"\n  [attr.aria-label]=\"ariaLabel() || header() || null\"\n  (click)=\"onCardClick($event)\"\n>\n  @if (clickable()) {\n    <button\n      #primaryButton\n      type=\"button\"\n      class=\"card__primary-action\"\n      [attr.aria-label]=\"ariaLabel() || header() || 'Card action'\"\n      [attr.aria-pressed]=\"clickable() ? (selected() ? 'true' : 'false') : null\"\n      (click)=\"onPrimaryClick($event)\"\n    ></button>\n  }\n  @if (header() || subheader()) {\n    <div class=\"card__header\">\n      @if (header()) {\n        <div class=\"card__title\">{{ header() }}</div>\n      }\n      @if (subheader()) {\n        <div class=\"card__subtitle\">{{ subheader() }}</div>\n      }\n    </div>\n  }\n  <ng-content></ng-content>\n</article>\n", styles: [".card{background:var(--orc-surface, var(--bg-app));border:1px solid var(--orc-border-default, var(--border-default));border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-5);display:flex;flex-direction:column;gap:var(--space-3);position:relative;transition:transform var(--transition-fast),box-shadow var(--transition-fast),border-color var(--transition-fast)}.card:focus-within{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico));outline-offset:2px}.card__primary-action{position:absolute;inset:0;z-index:0;width:100%;height:100%;padding:0;border:0;border-radius:inherit;background:transparent;opacity:0;cursor:inherit;pointer-events:none}.card>:not(.card__primary-action){position:relative;z-index:1}.card--clickable{cursor:pointer}.card--clickable:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);border-color:var(--orc-border-strong, var(--border-strong))}.card--selected{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));box-shadow:0 0 0 2px var(--orc-interactive-shadow)}.card--dashboard{flex-direction:row;align-items:center;gap:var(--space-4)}.card--flush{padding:0}.card--clip{overflow:hidden}.card--media{gap:0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-card', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<article\n  class=\"card {{ styleClass() }}\"\n  [style]=\"style()\"\n  [class.card--clickable]=\"clickable()\"\n  [class.card--selected]=\"selected()\"\n  [class.card--dashboard]=\"variant() === 'dashboard'\"\n  [class.card--flush]=\"flush() || media()\"\n  [class.card--media]=\"media()\"\n  [class.card--clip]=\"clip() || media()\"\n  [style.padding]=\"padding() ?? null\"\n  [attr.aria-label]=\"ariaLabel() || header() || null\"\n  (click)=\"onCardClick($event)\"\n>\n  @if (clickable()) {\n    <button\n      #primaryButton\n      type=\"button\"\n      class=\"card__primary-action\"\n      [attr.aria-label]=\"ariaLabel() || header() || 'Card action'\"\n      [attr.aria-pressed]=\"clickable() ? (selected() ? 'true' : 'false') : null\"\n      (click)=\"onPrimaryClick($event)\"\n    ></button>\n  }\n  @if (header() || subheader()) {\n    <div class=\"card__header\">\n      @if (header()) {\n        <div class=\"card__title\">{{ header() }}</div>\n      }\n      @if (subheader()) {\n        <div class=\"card__subtitle\">{{ subheader() }}</div>\n      }\n    </div>\n  }\n  <ng-content></ng-content>\n</article>\n", styles: [".card{background:var(--orc-surface, var(--bg-app));border:1px solid var(--orc-border-default, var(--border-default));border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-5);display:flex;flex-direction:column;gap:var(--space-3);position:relative;transition:transform var(--transition-fast),box-shadow var(--transition-fast),border-color var(--transition-fast)}.card:focus-within{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico));outline-offset:2px}.card__primary-action{position:absolute;inset:0;z-index:0;width:100%;height:100%;padding:0;border:0;border-radius:inherit;background:transparent;opacity:0;cursor:inherit;pointer-events:none}.card>:not(.card__primary-action){position:relative;z-index:1}.card--clickable{cursor:pointer}.card--clickable:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);border-color:var(--orc-border-strong, var(--border-strong))}.card--selected{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));box-shadow:0 0 0 2px var(--orc-interactive-shadow)}.card--dashboard{flex-direction:row;align-items:center;gap:var(--space-4)}.card--flush{padding:0}.card--clip{overflow:hidden}.card--media{gap:0}\n"] }]
        }], propDecorators: { clickable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickable", required: false }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], flush: [{ type: i0.Input, args: [{ isSignal: true, alias: "flush", required: false }] }], media: [{ type: i0.Input, args: [{ isSignal: true, alias: "media", required: false }] }], padding: [{ type: i0.Input, args: [{ isSignal: true, alias: "padding", required: false }] }], clip: [{ type: i0.Input, args: [{ isSignal: true, alias: "clip", required: false }] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], subheader: [{ type: i0.Input, args: [{ isSignal: true, alias: "subheader", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], cardClick: [{ type: i0.Output, args: ["cardClick"] }], onClickEvent: [{ type: i0.Output, args: ["onClickEvent"] }] } });

class CardHeaderComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: CardHeaderComponent, isStandalone: true, selector: "orc-card-header", ngImport: i0, template: "<div class=\"card-header\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-header{display:flex;align-items:center;gap:var(--space-2);width:100%;font-family:var(--font-sans);font-size:1rem;font-weight:500;color:var(--text-primary);letter-spacing:-.01em}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-card-header', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-header\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-header{display:flex;align-items:center;gap:var(--space-2);width:100%;font-family:var(--font-sans);font-size:1rem;font-weight:500;color:var(--text-primary);letter-spacing:-.01em}\n"] }]
        }] });

class CardBodyComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardBodyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: CardBodyComponent, isStandalone: true, selector: "orc-card-body", ngImport: i0, template: "<div class=\"card-body\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-body{width:100%;font-family:var(--font-sans);font-size:.875rem;line-height:1.5;color:var(--text-secondary);display:flex;flex-direction:column;gap:var(--space-2)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-card-body', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-body\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-body{width:100%;font-family:var(--font-sans);font-size:.875rem;line-height:1.5;color:var(--text-secondary);display:flex;flex-direction:column;gap:var(--space-2)}\n"] }]
        }] });

class CardFooterComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: CardFooterComponent, isStandalone: true, selector: "orc-card-footer", ngImport: i0, template: "<div class=\"card-footer\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-footer{display:flex;align-items:center;gap:var(--space-3);width:100%;margin-top:auto;padding-top:var(--space-2);border-top:1px solid var(--border-default)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-card-footer', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"card-footer\">\n  <ng-content></ng-content>\n</div>\n", styles: [".card-footer{display:flex;align-items:center;gap:var(--space-3);width:100%;margin-top:auto;padding-top:var(--space-2);border-top:1px solid var(--border-default)}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CardBodyComponent, CardComponent, CardFooterComponent, CardHeaderComponent };
//# sourceMappingURL=ciag-orchestra-card.mjs.map
