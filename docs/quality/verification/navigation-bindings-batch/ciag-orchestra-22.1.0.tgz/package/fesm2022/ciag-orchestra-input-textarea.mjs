export { TextareaComponent as InputTextareaComponent } from '@ciag/orchestra/input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-textarea.mjs.map
