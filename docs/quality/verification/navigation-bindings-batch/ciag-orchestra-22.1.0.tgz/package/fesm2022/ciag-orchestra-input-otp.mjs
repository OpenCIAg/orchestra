export { OtpInputComponent as InputOtp, OtpInputComponent as InputOtpComponent } from '@ciag/orchestra/otp-input';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-otp.mjs.map
