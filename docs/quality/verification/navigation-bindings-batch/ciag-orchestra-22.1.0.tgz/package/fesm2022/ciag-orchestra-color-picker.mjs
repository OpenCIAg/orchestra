import * as i0 from '@angular/core';
import { inject, ElementRef, input, model, booleanAttribute, output, signal, computed, forwardRef, HostListener, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

let nextColorPickerId = 0;
const DEFAULT_PRESETS = ['#1C6AED', '#0406AB', '#FF6A1C', '#1CEDB9', '#6A1CED', '#006F4A', '#FB2C36', '#FE9A00', '#141414', '#FFFFFF'];
class ColorPickerComponent {
    host = inject((ElementRef));
    uniqueId = `orc-color-picker-${++nextColorPickerId}`;
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    value = model('#1C6AED', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    presets = input(DEFAULT_PRESETS, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "presets" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    clearable = input(true, { ...(ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showInput = input(true, { ...(ngDevMode ? { debugName: "showInput" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    format = input('hex', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []));
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    panelStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    panelAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelAriaLabel" }] : /* istanbul ignore next */ []));
    nativeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeAriaLabel" }] : /* istanbul ignore next */ []));
    inputAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputAriaLabel" }] : /* istanbul ignore next */ []));
    presetsAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "presetsAriaLabel" }] : /* istanbul ignore next */ []));
    showTransitionOptions = input('150ms ease', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input('150ms ease', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    colorChange = output();
    onChange = output();
    onShow = output();
    onHide = output();
    onClear = output();
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    nativeValue = computed(() => this.toNativeHex(this.value()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeValue" }] : /* istanbul ignore next */ []));
    cvaChange = () => { };
    onTouched = () => { };
    writeValue(value) { if (typeof value === 'string' && this.isValidColor(value))
        this.value.set(value); }
    registerOnChange(fn) { this.cvaChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    toggle() { if (!this.effectiveDisabled() && !this.inline()) {
        const next = !this.isOpen();
        this.isOpen.set(next);
        (next ? this.onShow : this.onHide).emit();
    } }
    selectColor(color) { if (!this.effectiveDisabled() && this.isValidColor(color)) {
        this.update(color);
        this.isOpen.set(false);
    } }
    onNativeColor(event) { this.update(event.target.value.toUpperCase()); }
    onTextInput(event) { const color = event.target.value; if (this.isValidColor(color))
        this.update(color.toUpperCase()); }
    clear() { if (!this.effectiveDisabled()) {
        this.value.set('');
        this.cvaChange('');
        this.colorChange.emit('');
        this.onChange.emit({ value: '' });
        this.onTouched();
        this.isOpen.set(false);
        this.onClear.emit();
        this.onHide.emit();
    } }
    onDocumentClick(event) { if (!this.host.nativeElement.contains(event.target))
        this.isOpen.set(false); }
    update(color) { if (!this.isValidColor(color))
        return; const hex = this.toNativeHex(color); const next = this.format() === 'hex' && color.trim().startsWith('#') ? color.trim() : this.formatColor(hex); this.value.set(next); this.cvaChange(next); this.colorChange.emit(next); this.onChange.emit({ value: next }); this.onTouched(); }
    isValidColor(color) { return Boolean(this.parseColor(color)); }
    parseColor(color) { const value = color.trim(); const hex = value.match(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/); if (hex) {
        const raw = hex[1].length === 3 ? hex[1].split('').map(char => char + char).join('') : hex[1];
        return { r: parseInt(raw.slice(0, 2), 16), g: parseInt(raw.slice(2, 4), 16), b: parseInt(raw.slice(4, 6), 16) };
    } const rgb = value.match(/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/i); if (rgb) {
        const channels = rgb.slice(1, 4).map(Number);
        return channels.every(channel => channel >= 0 && channel <= 255) ? { r: channels[0], g: channels[1], b: channels[2] } : null;
    } const hsv = value.match(/^(?:hsv|hsb)\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)%?\s*,\s*(\d+(?:\.\d+)?)%?\s*\)$/i); if (hsv) {
        const hue = Number(hsv[1]);
        const saturation = Number(hsv[2]);
        const brightness = Number(hsv[3]);
        if (hue > 360 || saturation > 100 || brightness > 100)
            return null;
        const h = hue / 60;
        const s = saturation / 100;
        const v = brightness / 100;
        const c = v * s;
        const x = c * (1 - Math.abs((h % 2) - 1));
        const m = v - c;
        const [r, g, b] = h < 1 ? [c, x, 0] : h < 2 ? [x, c, 0] : h < 3 ? [0, c, x] : h < 4 ? [0, x, c] : h < 5 ? [x, 0, c] : [c, 0, x];
        return { r: Math.round((r + m) * 255), g: Math.round((g + m) * 255), b: Math.round((b + m) * 255) };
    } return null; }
    formatColor(hex) { const rgb = this.parseColor(hex); if (this.format() === 'rgb')
        return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`; if (this.format() === 'hsv' || this.format() === 'hsb') {
        const r = rgb.r / 255, g = rgb.g / 255, b = rgb.b / 255, max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
        let h = 0;
        if (d)
            h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
        h = Math.round(h * 60);
        if (h < 0)
            h += 360;
        const s = max ? Math.round((d / max) * 100) : 0;
        return `${this.format() === 'hsb' ? 'hsb' : 'hsv'}(${h}, ${s}%, ${Math.round(max * 100)}%)`;
    } return hex; }
    toNativeHex(color) { const rgb = this.parseColor(color); if (!rgb)
        return '#000000'; return `#${[rgb.r, rgb.g, rgb.b].map(channel => channel.toString(16).padStart(2, '0')).join('')}`; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColorPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ColorPickerComponent, isStandalone: true, selector: "orc-color-picker", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, presets: { classPropertyName: "presets", publicName: "presets", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, showInput: { classPropertyName: "showInput", publicName: "showInput", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null }, inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, panelAriaLabel: { classPropertyName: "panelAriaLabel", publicName: "panelAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, nativeAriaLabel: { classPropertyName: "nativeAriaLabel", publicName: "nativeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, inputAriaLabel: { classPropertyName: "inputAriaLabel", publicName: "inputAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, presetsAriaLabel: { classPropertyName: "presetsAriaLabel", publicName: "presetsAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", colorChange: "colorChange", onChange: "onChange", onShow: "onShow", onHide: "onHide", onClear: "onClear" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ColorPickerComponent), multi: true }], ngImport: i0, template: "<div class=\"p-colorpicker p-component orc-color-picker\" [class]=\"'p-colorpicker p-component orc-color-picker ' + styleClass()\" [style]=\"style()\" [class.orc-color-picker--disabled]=\"effectiveDisabled()\" [attr.data-pc-name]=\"'colorpicker'\">\n  @if (label()) { <label class=\"orc-color-picker__label\" [for]=\"effectiveId()\">{{ label() }}</label> }\n  <div class=\"orc-color-picker__control\">\n    <button type=\"button\" class=\"orc-color-picker__trigger\" [id]=\"effectiveId()\" [disabled]=\"effectiveDisabled()\" [attr.tabindex]=\"tabindex()\" [attr.aria-label]=\"ariaLabel()\" [attr.aria-expanded]=\"isOpen()\" (click)=\"toggle()\">\n      <span class=\"orc-color-picker__swatch\" [style.background-color]=\"value() || 'transparent'\" aria-hidden=\"true\"></span>\n      @if (showInput() && value()) { <span class=\"orc-color-picker__value\">{{ value() }}</span> }\n      <span class=\"orc-color-picker__chevron\" aria-hidden=\"true\">\u2304</span>\n    </button>\n    @if (clearable() && value()) { <button type=\"button\" class=\"orc-color-picker__clear\" (click)=\"clear()\" [disabled]=\"effectiveDisabled()\" [attr.aria-label]=\"clearAriaLabel() || null\">\u00D7</button> }\n  </div>\n  @if (isOpen() || inline()) {\n    <div class=\"p-colorpicker-panel p-component orc-color-picker__panel\" [class]=\"'p-colorpicker-panel p-component orc-color-picker__panel ' + panelStyleClass()\" role=\"dialog\" [attr.aria-label]=\"panelAriaLabel() || null\">\n      <input class=\"orc-color-picker__native\" type=\"color\" [value]=\"nativeValue()\" (input)=\"onNativeColor($event)\" [disabled]=\"effectiveDisabled()\" [attr.aria-label]=\"nativeAriaLabel() || null\" />\n      @if (showInput()) { <input class=\"orc-color-picker__text\" type=\"text\" [value]=\"value()\" (input)=\"onTextInput($event)\" [attr.aria-label]=\"inputAriaLabel() || null\" inputmode=\"text\" /> }\n      <div class=\"orc-color-picker__presets\" [attr.aria-label]=\"presetsAriaLabel() || null\">\n        @for (color of presets(); track color) { <button type=\"button\" class=\"orc-color-picker__preset\" [style.background-color]=\"color\" [class.orc-color-picker__preset--active]=\"value().toUpperCase() === color.toUpperCase()\" [attr.aria-label]=\"color\" (click)=\"selectColor(color)\"></button> }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-color-picker{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-color-picker__label{font-size:13px;font-weight:600;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-color-picker__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-color-picker__trigger{display:flex;align-items:center;gap:8px;flex:1;min-width:0;height:42px;padding:0 10px;border:0;border-radius:inherit;background:transparent;color:var(--orc-text, var(--orc-font-main, #141414));font:inherit;text-align:left;cursor:pointer}.orc-color-picker__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-color-picker__swatch{width:22px;height:22px;flex:0 0 auto;border:1px solid var(--orc-border-strong, rgba(0, 0, 0, .16));border-radius:50%;background-image:linear-gradient(45deg,var(--orc-surface-muted, #ddd) 25%,transparent 25%),linear-gradient(-45deg,var(--orc-surface-muted, #ddd) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,var(--orc-surface-muted, #ddd) 75%),linear-gradient(-45deg,transparent 75%,var(--orc-surface-muted, #ddd) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0}.orc-color-picker__value{min-width:0;overflow:hidden;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));font-size:13px;text-overflow:ellipsis;white-space:nowrap}.orc-color-picker__chevron{margin-left:auto}.orc-color-picker__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));font-size:20px;cursor:pointer}.orc-color-picker__panel{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + 4px);left:0;display:grid;gap:12px;width:min(260px,100%);padding:12px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff));box-shadow:var(--orc-shadow-overlay, var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12)))}.orc-color-picker__native{width:100%;height:42px;padding:0;border:0;background:transparent;cursor:pointer}.orc-color-picker__text{width:100%;min-height:36px;padding:0 8px;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-sm, 6px);background:var(--orc-surface-raised, var(--fill-modal, #fff));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-color-picker__presets{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.orc-color-picker__preset{width:30px;height:30px;padding:0;border:1px solid var(--orc-border-strong, rgba(0, 0, 0, .16));border-radius:50%;cursor:pointer}.orc-color-picker__preset:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-color-picker__preset--active{box-shadow:0 0 0 2px var(--orc-surface-raised, var(--fill-modal, #fff)),0 0 0 4px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-color-picker--disabled{opacity:.55}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColorPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-color-picker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ColorPickerComponent), multi: true }], template: "<div class=\"p-colorpicker p-component orc-color-picker\" [class]=\"'p-colorpicker p-component orc-color-picker ' + styleClass()\" [style]=\"style()\" [class.orc-color-picker--disabled]=\"effectiveDisabled()\" [attr.data-pc-name]=\"'colorpicker'\">\n  @if (label()) { <label class=\"orc-color-picker__label\" [for]=\"effectiveId()\">{{ label() }}</label> }\n  <div class=\"orc-color-picker__control\">\n    <button type=\"button\" class=\"orc-color-picker__trigger\" [id]=\"effectiveId()\" [disabled]=\"effectiveDisabled()\" [attr.tabindex]=\"tabindex()\" [attr.aria-label]=\"ariaLabel()\" [attr.aria-expanded]=\"isOpen()\" (click)=\"toggle()\">\n      <span class=\"orc-color-picker__swatch\" [style.background-color]=\"value() || 'transparent'\" aria-hidden=\"true\"></span>\n      @if (showInput() && value()) { <span class=\"orc-color-picker__value\">{{ value() }}</span> }\n      <span class=\"orc-color-picker__chevron\" aria-hidden=\"true\">\u2304</span>\n    </button>\n    @if (clearable() && value()) { <button type=\"button\" class=\"orc-color-picker__clear\" (click)=\"clear()\" [disabled]=\"effectiveDisabled()\" [attr.aria-label]=\"clearAriaLabel() || null\">\u00D7</button> }\n  </div>\n  @if (isOpen() || inline()) {\n    <div class=\"p-colorpicker-panel p-component orc-color-picker__panel\" [class]=\"'p-colorpicker-panel p-component orc-color-picker__panel ' + panelStyleClass()\" role=\"dialog\" [attr.aria-label]=\"panelAriaLabel() || null\">\n      <input class=\"orc-color-picker__native\" type=\"color\" [value]=\"nativeValue()\" (input)=\"onNativeColor($event)\" [disabled]=\"effectiveDisabled()\" [attr.aria-label]=\"nativeAriaLabel() || null\" />\n      @if (showInput()) { <input class=\"orc-color-picker__text\" type=\"text\" [value]=\"value()\" (input)=\"onTextInput($event)\" [attr.aria-label]=\"inputAriaLabel() || null\" inputmode=\"text\" /> }\n      <div class=\"orc-color-picker__presets\" [attr.aria-label]=\"presetsAriaLabel() || null\">\n        @for (color of presets(); track color) { <button type=\"button\" class=\"orc-color-picker__preset\" [style.background-color]=\"color\" [class.orc-color-picker__preset--active]=\"value().toUpperCase() === color.toUpperCase()\" [attr.aria-label]=\"color\" (click)=\"selectColor(color)\"></button> }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-color-picker{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-color-picker__label{font-size:13px;font-weight:600;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-color-picker__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-color-picker__trigger{display:flex;align-items:center;gap:8px;flex:1;min-width:0;height:42px;padding:0 10px;border:0;border-radius:inherit;background:transparent;color:var(--orc-text, var(--orc-font-main, #141414));font:inherit;text-align:left;cursor:pointer}.orc-color-picker__trigger:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:-2px}.orc-color-picker__swatch{width:22px;height:22px;flex:0 0 auto;border:1px solid var(--orc-border-strong, rgba(0, 0, 0, .16));border-radius:50%;background-image:linear-gradient(45deg,var(--orc-surface-muted, #ddd) 25%,transparent 25%),linear-gradient(-45deg,var(--orc-surface-muted, #ddd) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,var(--orc-surface-muted, #ddd) 75%),linear-gradient(-45deg,transparent 75%,var(--orc-surface-muted, #ddd) 75%);background-size:8px 8px;background-position:0 0,0 4px,4px -4px,-4px 0}.orc-color-picker__value{min-width:0;overflow:hidden;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));font-size:13px;text-overflow:ellipsis;white-space:nowrap}.orc-color-picker__chevron{margin-left:auto}.orc-color-picker__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-text-secondary, var(--orc-font-secondary, #666));font-size:20px;cursor:pointer}.orc-color-picker__panel{position:absolute;z-index:var(--z-dropdown, 1000);top:calc(100% + 4px);left:0;display:grid;gap:12px;width:min(260px,100%);padding:12px;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff));box-shadow:var(--orc-shadow-overlay, var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12)))}.orc-color-picker__native{width:100%;height:42px;padding:0;border:0;background:transparent;cursor:pointer}.orc-color-picker__text{width:100%;min-height:36px;padding:0 8px;box-sizing:border-box;border:1px solid var(--orc-border-default, var(--orc-border, #d9d9d9));border-radius:var(--radius-sm, 6px);background:var(--orc-surface-raised, var(--fill-modal, #fff));color:var(--orc-text, var(--orc-font-main, #141414))}.orc-color-picker__presets{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.orc-color-picker__preset{width:30px;height:30px;padding:0;border:1px solid var(--orc-border-strong, rgba(0, 0, 0, .16));border-radius:50%;cursor:pointer}.orc-color-picker__preset:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-color-picker__preset--active{box-shadow:0 0 0 2px var(--orc-surface-raised, var(--fill-modal, #fff)),0 0 0 4px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-color-picker--disabled{opacity:.55}\n"] }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], presets: [{ type: i0.Input, args: [{ isSignal: true, alias: "presets", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], showInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "showInput", required: false }] }], format: [{ type: i0.Input, args: [{ isSignal: true, alias: "format", required: false }] }], inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], panelAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelAriaLabel", required: false }] }], nativeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nativeAriaLabel", required: false }] }], inputAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputAriaLabel", required: false }] }], presetsAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "presetsAriaLabel", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], colorChange: [{ type: i0.Output, args: ["colorChange"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ColorPickerComponent as ColorPicker, ColorPickerComponent };
//# sourceMappingURL=ciag-orchestra-color-picker.mjs.map
