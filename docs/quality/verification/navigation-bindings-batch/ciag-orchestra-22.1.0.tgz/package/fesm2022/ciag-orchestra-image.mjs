import * as i0 from '@angular/core';
import { input, booleanAttribute, signal, computed, output, effect, untracked, ChangeDetectionStrategy, Component } from '@angular/core';
import { ModalComponent } from '@ciag/orchestra/modal';

class ImageComponent {
    src = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    srcSet = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "srcSet" }] : /* istanbul ignore next */ []));
    sizes = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sizes" }] : /* istanbul ignore next */ []));
    previewImageSrc = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previewImageSrc" }] : /* istanbul ignore next */ []));
    previewImageSrcSet = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previewImageSrcSet" }] : /* istanbul ignore next */ []));
    previewImageSizes = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previewImageSizes" }] : /* istanbul ignore next */ []));
    alt = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []));
    fallbackSrc = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fallbackSrc" }] : /* istanbul ignore next */ []));
    fit = input('cover', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fit" }] : /* istanbul ignore next */ []));
    width = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    height = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    loading = input('lazy', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    radius = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "radius" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    zoomOutAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "zoomOutAriaLabel" }] : /* istanbul ignore next */ []));
    zoomInAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "zoomInAriaLabel" }] : /* istanbul ignore next */ []));
    rotateLeftAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rotateLeftAriaLabel" }] : /* istanbul ignore next */ []));
    rotateRightAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rotateRightAriaLabel" }] : /* istanbul ignore next */ []));
    closePreviewAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closePreviewAriaLabel" }] : /* istanbul ignore next */ []));
    preview = input(false, { ...(ngDevMode ? { debugName: "preview" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    imageClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageClass" }] : /* istanbul ignore next */ []));
    imageStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageStyle" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    showTransitionOptions = input('150ms cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input('100ms linear', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    usingFallback = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "usingFallback" }] : /* istanbul ignore next */ []));
    failed = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "failed" }] : /* istanbul ignore next */ []));
    renderedSrc = computed(() => this.failed() ? '' : this.usingFallback() ? this.fallbackSrc() : this.src(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "renderedSrc" }] : /* istanbul ignore next */ []));
    renderedSrcSet = computed(() => this.usingFallback() || this.failed() ? undefined : this.srcSet(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "renderedSrcSet" }] : /* istanbul ignore next */ []));
    renderedSizes = computed(() => this.usingFallback() || this.failed() ? undefined : this.sizes(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "renderedSizes" }] : /* istanbul ignore next */ []));
    loaded = output();
    error = output();
    onImageError = output({ alias: 'onImageError' });
    onShow = output();
    onHide = output();
    previewVisible = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previewVisible" }] : /* istanbul ignore next */ []));
    scale = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []));
    rotation = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rotation" }] : /* istanbul ignore next */ []));
    lastSource = Symbol('uninitialized');
    lastFallbackSource = Symbol('uninitialized');
    lastSourceSet = Symbol('uninitialized');
    lastSizes = Symbol('uninitialized');
    constructor() {
        effect(() => {
            const source = this.src();
            const fallbackSource = this.fallbackSrc();
            const sourceSet = this.srcSet();
            const sizes = this.sizes();
            const previewEnabled = this.preview();
            const sameInputs = source === this.lastSource &&
                fallbackSource === this.lastFallbackSource &&
                sourceSet === this.lastSourceSet &&
                sizes === this.lastSizes;
            if (!sameInputs) {
                this.lastSource = source;
                this.lastFallbackSource = fallbackSource;
                this.lastSourceSet = sourceSet;
                this.lastSizes = sizes;
                this.usingFallback.set(false);
                this.failed.set(false);
            }
            if ((!previewEnabled || !this.renderedSrc()) &&
                untracked(() => this.previewVisible()))
                this.closePreview();
        });
    }
    cssDimension(value) {
        if (value === '')
            return null;
        return typeof value === 'number' ? `${value}px` : value;
    }
    onLoad() {
        this.loaded.emit();
    }
    onError(event) {
        if (this.fallbackSrc() && !this.usingFallback()) {
            this.usingFallback.set(true);
            return;
        }
        this.failed.set(true);
        this.error.emit(event);
        this.onImageError.emit(event);
    }
    onImageClick() {
        if (!this.preview() || !this.renderedSrc() || this.previewVisible())
            return;
        this.scale.set(1);
        this.rotation.set(0);
        this.previewVisible.set(true);
        this.onShow.emit();
    }
    onTriggerKeydown(event) {
        if (event.key !== 'Enter' && event.key !== ' ')
            return;
        event.preventDefault();
        this.onImageClick();
    }
    onPreviewModalClosed() {
        if (this.previewVisible())
            this.closePreview();
    }
    closePreview() {
        if (!this.previewVisible())
            return;
        this.previewVisible.set(false);
        this.onHide.emit();
    }
    zoomIn() {
        this.scale.update((value) => Math.min(3, value + 0.25));
    }
    zoomOut() {
        this.scale.update((value) => Math.max(0.5, value - 0.25));
    }
    rotateRight() {
        this.rotation.update((value) => (value + 90) % 360);
    }
    rotateLeft() {
        this.rotation.update((value) => (value + 270) % 360);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ImageComponent, isStandalone: true, selector: "orc-image", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, srcSet: { classPropertyName: "srcSet", publicName: "srcSet", isSignal: true, isRequired: false, transformFunction: null }, sizes: { classPropertyName: "sizes", publicName: "sizes", isSignal: true, isRequired: false, transformFunction: null }, previewImageSrc: { classPropertyName: "previewImageSrc", publicName: "previewImageSrc", isSignal: true, isRequired: false, transformFunction: null }, previewImageSrcSet: { classPropertyName: "previewImageSrcSet", publicName: "previewImageSrcSet", isSignal: true, isRequired: false, transformFunction: null }, previewImageSizes: { classPropertyName: "previewImageSizes", publicName: "previewImageSizes", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, fallbackSrc: { classPropertyName: "fallbackSrc", publicName: "fallbackSrc", isSignal: true, isRequired: false, transformFunction: null }, fit: { classPropertyName: "fit", publicName: "fit", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, radius: { classPropertyName: "radius", publicName: "radius", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, zoomOutAriaLabel: { classPropertyName: "zoomOutAriaLabel", publicName: "zoomOutAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, zoomInAriaLabel: { classPropertyName: "zoomInAriaLabel", publicName: "zoomInAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, rotateLeftAriaLabel: { classPropertyName: "rotateLeftAriaLabel", publicName: "rotateLeftAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, rotateRightAriaLabel: { classPropertyName: "rotateRightAriaLabel", publicName: "rotateRightAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, closePreviewAriaLabel: { classPropertyName: "closePreviewAriaLabel", publicName: "closePreviewAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, preview: { classPropertyName: "preview", publicName: "preview", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, imageClass: { classPropertyName: "imageClass", publicName: "imageClass", isSignal: true, isRequired: false, transformFunction: null }, imageStyle: { classPropertyName: "imageStyle", publicName: "imageStyle", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { loaded: "loaded", error: "error", onImageError: "onImageError", onShow: "onShow", onHide: "onHide" }, ngImport: i0, template: "<figure\n  [class]=\"\n    'orc-image orc-image--' +\n    radius() +\n    (height() === '' ? ' orc-image--auto-height' : '') +\n    ' ' +\n    styleClass()\n  \"\n  [style.width]=\"cssDimension(width())\"\n  [style.height]=\"cssDimension(height())\"\n>\n  @if (renderedSrc()) {\n    @if (preview()) {\n      <button\n        type=\"button\"\n        class=\"orc-image__trigger\"\n        [attr.aria-label]=\"\n          ariaLabel() ||\n          (alt() ? 'Open image preview: ' + alt() : 'Open image preview')\n        \"\n        (click)=\"onImageClick()\"\n      >\n        <img\n          [src]=\"renderedSrc()\"\n          [attr.alt]=\"alt()\"\n          [loading]=\"loading()\"\n          [attr.srcset]=\"renderedSrcSet() || null\"\n          [attr.sizes]=\"renderedSizes() || null\"\n          decoding=\"async\"\n          [class]=\"imageClass()\"\n          [style]=\"imageStyle()\"\n          [style.object-fit]=\"fit()\"\n          [attr.aria-label]=\"ariaLabel() || null\"\n          (load)=\"onLoad()\"\n          (error)=\"onError($event)\"\n        />\n      </button>\n    } @else {\n      <img\n        [src]=\"renderedSrc()\"\n        [attr.alt]=\"alt()\"\n        [loading]=\"loading()\"\n        [attr.srcset]=\"renderedSrcSet() || null\"\n        [attr.sizes]=\"renderedSizes() || null\"\n        decoding=\"async\"\n        [class]=\"imageClass()\"\n        [style]=\"imageStyle()\"\n        [style.object-fit]=\"fit()\"\n        [attr.aria-label]=\"ariaLabel() || null\"\n        (load)=\"onLoad()\"\n        (error)=\"onError($event)\"\n      />\n    }\n  } @else if (placeholder()) {\n    <div\n      class=\"orc-image__placeholder\"\n      role=\"img\"\n      [attr.aria-label]=\"ariaLabel() || alt() || null\"\n    >\n      {{ placeholder() }}\n    </div>\n  }\n  @if (previewVisible()) {\n    <orc-modal\n      [isOpen]=\"previewVisible()\"\n      [showHeader]=\"false\"\n      [showCloseButton]=\"false\"\n      [closable]=\"false\"\n      [ariaLabel]=\"ariaLabel() || 'Image preview'\"\n      [transitionOptions]=\"showTransitionOptions()\"\n      size=\"custom\"\n      [style]=\"{\n        width: 'min(100vw - 1rem, 1200px)',\n        maxWidth: 'calc(100vw - 1rem)',\n      }\"\n      [contentStyle]=\"{ overflow: 'hidden', padding: '0' }\"\n      (closed)=\"onPreviewModalClosed()\"\n    >\n      <div\n        modal-body\n        class=\"orc-image__preview-content\"\n        [style.width]=\"'min(100%, 1200px)'\"\n      >\n        <div\n          class=\"orc-image__preview-toolbar\"\n          role=\"group\"\n          aria-label=\"Image preview controls\"\n        >\n          <button\n            type=\"button\"\n            [disabled]=\"scale() <= 0.5\"\n            [attr.aria-label]=\"zoomOutAriaLabel() || 'Zoom out'\"\n            (click)=\"zoomOut()\"\n          >\n            \u2212\n          </button>\n          <button\n            type=\"button\"\n            [disabled]=\"scale() >= 3\"\n            [attr.aria-label]=\"zoomInAriaLabel() || 'Zoom in'\"\n            (click)=\"zoomIn()\"\n          >\n            +\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"rotateLeftAriaLabel() || 'Rotate left'\"\n            (click)=\"rotateLeft()\"\n          >\n            \u21B6\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"rotateRightAriaLabel() || 'Rotate right'\"\n            (click)=\"rotateRight()\"\n          >\n            \u21B7\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"closePreviewAriaLabel() || 'Close image preview'\"\n            (click)=\"closePreview()\"\n          >\n            \u00D7\n          </button>\n        </div>\n        <img\n          [src]=\"previewImageSrc() || renderedSrc()\"\n          [attr.srcset]=\"previewImageSrcSet() || null\"\n          [attr.sizes]=\"previewImageSizes() || null\"\n          [attr.alt]=\"alt()\"\n          [style.maxWidth]=\"'100%'\"\n          [style.transform]=\"\n            'scale(' + scale() + ') rotate(' + rotation() + 'deg)'\n          \"\n        />\n      </div>\n    </orc-modal>\n  }\n</figure>\n", styles: [":host{display:block}.orc-image{display:block;width:100%;height:auto;margin:0;overflow:visible;background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-image--none{border-radius:0}.orc-image--sm{border-radius:var(--radius-sm, 6px)}.orc-image--md{border-radius:var(--radius-md, 10px)}.orc-image--lg{border-radius:var(--radius-lg, 14px)}.orc-image--full{border-radius:999px}.orc-image>img,.orc-image__trigger>img,.orc-image__placeholder{display:block;width:100%;height:100%;min-height:0;border-radius:inherit}.orc-image>img,.orc-image__trigger>img{object-position:center}.orc-image__trigger{display:block;width:100%;height:100%;padding:0;border:0;border-radius:inherit;background:transparent;color:inherit;cursor:pointer}.orc-image__trigger:disabled{cursor:default}.orc-image__trigger:focus-visible{outline:2px solid var(--orc-component-interactive, #2563eb);outline-offset:2px}.orc-image__placeholder{display:grid;place-items:center;padding:0;box-sizing:border-box;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px;text-align:center}.orc-image--auto-height .orc-image__placeholder{min-height:64px;padding:16px}.orc-image__preview-content{position:relative;display:grid;place-items:center;width:min(100%,1200px);max-height:calc(100dvh - 8rem);overflow:hidden}.orc-image__preview-content>img{max-width:100%;max-height:calc(100dvh - 9rem);object-fit:contain;transition:transform .15s ease}.orc-image__preview-toolbar{position:absolute;z-index:1;top:.5rem;right:.5rem;display:flex;gap:.25rem}.orc-image__preview-toolbar button{width:2rem;height:2rem;border:0;border-radius:.25rem;background:color-mix(in srgb,var(--orc-scrim, #000) 88%,transparent);color:var(--orc-on-dark, #fff);font-size:1.25rem}@media(max-width:480px){.orc-image__preview-content{max-height:calc(100dvh - 3rem)}.orc-image__preview-content>img{max-height:calc(100dvh - 7rem)}.orc-image__preview-toolbar{position:static;order:2;justify-content:center;width:100%;margin-top:.5rem}}\n"], dependencies: [{ kind: "component", type: ModalComponent, selector: "orc-modal, orc-dialog, orc-dynamic-dialog", inputs: ["isOpen", "visible", "header", "modal", "closeOnEscape", "dismissableMask", "closable", "draggable", "resizable", "maximizable", "focusOnShow", "focusTrap", "blockScroll", "autoZIndex", "baseZIndex", "position", "style", "styleClass", "maskStyle", "maskStyleClass", "contentStyle", "contentStyleClass", "appendTo", "role", "showHeader", "closeIcon", "closeAriaLabel", "minimizeIcon", "maximizeIcon", "restoreAriaLabel", "maximizeAriaLabel", "closeTabindex", "breakpoints", "size", "id", "ariaLabel", "status", "inline", "closeOnBackdropClick", "showCloseButton", "ariaLabelledBy", "ariaDescribedBy", "zIndex", "keepInViewport", "minX", "minY", "transitionOptions", "rtl", "maximized"], outputs: ["isOpenChange", "visibleChange", "closed", "onShow", "onHide", "onMaximize", "maximizedChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-image', standalone: true, imports: [ModalComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<figure\n  [class]=\"\n    'orc-image orc-image--' +\n    radius() +\n    (height() === '' ? ' orc-image--auto-height' : '') +\n    ' ' +\n    styleClass()\n  \"\n  [style.width]=\"cssDimension(width())\"\n  [style.height]=\"cssDimension(height())\"\n>\n  @if (renderedSrc()) {\n    @if (preview()) {\n      <button\n        type=\"button\"\n        class=\"orc-image__trigger\"\n        [attr.aria-label]=\"\n          ariaLabel() ||\n          (alt() ? 'Open image preview: ' + alt() : 'Open image preview')\n        \"\n        (click)=\"onImageClick()\"\n      >\n        <img\n          [src]=\"renderedSrc()\"\n          [attr.alt]=\"alt()\"\n          [loading]=\"loading()\"\n          [attr.srcset]=\"renderedSrcSet() || null\"\n          [attr.sizes]=\"renderedSizes() || null\"\n          decoding=\"async\"\n          [class]=\"imageClass()\"\n          [style]=\"imageStyle()\"\n          [style.object-fit]=\"fit()\"\n          [attr.aria-label]=\"ariaLabel() || null\"\n          (load)=\"onLoad()\"\n          (error)=\"onError($event)\"\n        />\n      </button>\n    } @else {\n      <img\n        [src]=\"renderedSrc()\"\n        [attr.alt]=\"alt()\"\n        [loading]=\"loading()\"\n        [attr.srcset]=\"renderedSrcSet() || null\"\n        [attr.sizes]=\"renderedSizes() || null\"\n        decoding=\"async\"\n        [class]=\"imageClass()\"\n        [style]=\"imageStyle()\"\n        [style.object-fit]=\"fit()\"\n        [attr.aria-label]=\"ariaLabel() || null\"\n        (load)=\"onLoad()\"\n        (error)=\"onError($event)\"\n      />\n    }\n  } @else if (placeholder()) {\n    <div\n      class=\"orc-image__placeholder\"\n      role=\"img\"\n      [attr.aria-label]=\"ariaLabel() || alt() || null\"\n    >\n      {{ placeholder() }}\n    </div>\n  }\n  @if (previewVisible()) {\n    <orc-modal\n      [isOpen]=\"previewVisible()\"\n      [showHeader]=\"false\"\n      [showCloseButton]=\"false\"\n      [closable]=\"false\"\n      [ariaLabel]=\"ariaLabel() || 'Image preview'\"\n      [transitionOptions]=\"showTransitionOptions()\"\n      size=\"custom\"\n      [style]=\"{\n        width: 'min(100vw - 1rem, 1200px)',\n        maxWidth: 'calc(100vw - 1rem)',\n      }\"\n      [contentStyle]=\"{ overflow: 'hidden', padding: '0' }\"\n      (closed)=\"onPreviewModalClosed()\"\n    >\n      <div\n        modal-body\n        class=\"orc-image__preview-content\"\n        [style.width]=\"'min(100%, 1200px)'\"\n      >\n        <div\n          class=\"orc-image__preview-toolbar\"\n          role=\"group\"\n          aria-label=\"Image preview controls\"\n        >\n          <button\n            type=\"button\"\n            [disabled]=\"scale() <= 0.5\"\n            [attr.aria-label]=\"zoomOutAriaLabel() || 'Zoom out'\"\n            (click)=\"zoomOut()\"\n          >\n            \u2212\n          </button>\n          <button\n            type=\"button\"\n            [disabled]=\"scale() >= 3\"\n            [attr.aria-label]=\"zoomInAriaLabel() || 'Zoom in'\"\n            (click)=\"zoomIn()\"\n          >\n            +\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"rotateLeftAriaLabel() || 'Rotate left'\"\n            (click)=\"rotateLeft()\"\n          >\n            \u21B6\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"rotateRightAriaLabel() || 'Rotate right'\"\n            (click)=\"rotateRight()\"\n          >\n            \u21B7\n          </button>\n          <button\n            type=\"button\"\n            [attr.aria-label]=\"closePreviewAriaLabel() || 'Close image preview'\"\n            (click)=\"closePreview()\"\n          >\n            \u00D7\n          </button>\n        </div>\n        <img\n          [src]=\"previewImageSrc() || renderedSrc()\"\n          [attr.srcset]=\"previewImageSrcSet() || null\"\n          [attr.sizes]=\"previewImageSizes() || null\"\n          [attr.alt]=\"alt()\"\n          [style.maxWidth]=\"'100%'\"\n          [style.transform]=\"\n            'scale(' + scale() + ') rotate(' + rotation() + 'deg)'\n          \"\n        />\n      </div>\n    </orc-modal>\n  }\n</figure>\n", styles: [":host{display:block}.orc-image{display:block;width:100%;height:auto;margin:0;overflow:visible;background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-image--none{border-radius:0}.orc-image--sm{border-radius:var(--radius-sm, 6px)}.orc-image--md{border-radius:var(--radius-md, 10px)}.orc-image--lg{border-radius:var(--radius-lg, 14px)}.orc-image--full{border-radius:999px}.orc-image>img,.orc-image__trigger>img,.orc-image__placeholder{display:block;width:100%;height:100%;min-height:0;border-radius:inherit}.orc-image>img,.orc-image__trigger>img{object-position:center}.orc-image__trigger{display:block;width:100%;height:100%;padding:0;border:0;border-radius:inherit;background:transparent;color:inherit;cursor:pointer}.orc-image__trigger:disabled{cursor:default}.orc-image__trigger:focus-visible{outline:2px solid var(--orc-component-interactive, #2563eb);outline-offset:2px}.orc-image__placeholder{display:grid;place-items:center;padding:0;box-sizing:border-box;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px;text-align:center}.orc-image--auto-height .orc-image__placeholder{min-height:64px;padding:16px}.orc-image__preview-content{position:relative;display:grid;place-items:center;width:min(100%,1200px);max-height:calc(100dvh - 8rem);overflow:hidden}.orc-image__preview-content>img{max-width:100%;max-height:calc(100dvh - 9rem);object-fit:contain;transition:transform .15s ease}.orc-image__preview-toolbar{position:absolute;z-index:1;top:.5rem;right:.5rem;display:flex;gap:.25rem}.orc-image__preview-toolbar button{width:2rem;height:2rem;border:0;border-radius:.25rem;background:color-mix(in srgb,var(--orc-scrim, #000) 88%,transparent);color:var(--orc-on-dark, #fff);font-size:1.25rem}@media(max-width:480px){.orc-image__preview-content{max-height:calc(100dvh - 3rem)}.orc-image__preview-content>img{max-height:calc(100dvh - 7rem)}.orc-image__preview-toolbar{position:static;order:2;justify-content:center;width:100%;margin-top:.5rem}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], srcSet: [{ type: i0.Input, args: [{ isSignal: true, alias: "srcSet", required: false }] }], sizes: [{ type: i0.Input, args: [{ isSignal: true, alias: "sizes", required: false }] }], previewImageSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "previewImageSrc", required: false }] }], previewImageSrcSet: [{ type: i0.Input, args: [{ isSignal: true, alias: "previewImageSrcSet", required: false }] }], previewImageSizes: [{ type: i0.Input, args: [{ isSignal: true, alias: "previewImageSizes", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }], fallbackSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "fallbackSrc", required: false }] }], fit: [{ type: i0.Input, args: [{ isSignal: true, alias: "fit", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], radius: [{ type: i0.Input, args: [{ isSignal: true, alias: "radius", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], zoomOutAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "zoomOutAriaLabel", required: false }] }], zoomInAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "zoomInAriaLabel", required: false }] }], rotateLeftAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rotateLeftAriaLabel", required: false }] }], rotateRightAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rotateRightAriaLabel", required: false }] }], closePreviewAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closePreviewAriaLabel", required: false }] }], preview: [{ type: i0.Input, args: [{ isSignal: true, alias: "preview", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], imageClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageClass", required: false }] }], imageStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageStyle", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], loaded: [{ type: i0.Output, args: ["loaded"] }], error: [{ type: i0.Output, args: ["error"] }], onImageError: [{ type: i0.Output, args: ["onImageError"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ImageComponent };
//# sourceMappingURL=ciag-orchestra-image.mjs.map
