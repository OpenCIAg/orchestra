export { FluidComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-fluid.mjs.map
