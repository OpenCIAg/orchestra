import * as i0 from '@angular/core';
import { input, booleanAttribute, output, signal, effect, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class AvatarComponent {
    // Inputs (Signals API)
    src = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    initials = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []));
    alt = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []));
    statusLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "statusLabel" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    shape = input('circular', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    status = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    statusPosition = input('bottom-right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "statusPosition" }] : /* istanbul ignore next */ []));
    colorVariant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "colorVariant" }] : /* istanbul ignore next */ []));
    bordered = input(false, { ...(ngDevMode ? { debugName: "bordered" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    clickable = input(false, { ...(ngDevMode ? { debugName: "clickable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    // Outputs (Signals API)
    imageError = output();
    avatarClick = output();
    // Estado interno para controle de erro no carregamento da imagem
    imageFailed = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageFailed" }] : /* istanbul ignore next */ []));
    constructor() {
        // Reseta estado de erro caso a URL da imagem mude
        effect(() => {
            this.src();
            this.imageFailed.set(false);
        });
    }
    // ── Sinais Computados ──────────────────────────────────────
    showImage = computed(() => {
        return Boolean(this.src() && !this.imageFailed());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showImage" }] : /* istanbul ignore next */ []));
    computedInitials = computed(() => {
        if (this.initials()) {
            return this.initials().trim().toUpperCase().slice(0, 3);
        }
        const fullName = (this.name() || this.label() || '').trim();
        if (!fullName)
            return '';
        const parts = fullName.split(/\s+/).filter(Boolean);
        if (parts.length === 1) {
            return parts[0].slice(0, 2).toUpperCase();
        }
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedInitials" }] : /* istanbul ignore next */ []));
    hasInitials = computed(() => {
        return !this.showImage() && Boolean(this.computedInitials());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasInitials" }] : /* istanbul ignore next */ []));
    showIcon = computed(() => {
        return !this.showImage() && !this.hasInitials();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showIcon" }] : /* istanbul ignore next */ []));
    effectiveColorVariant = computed(() => {
        const variant = this.colorVariant();
        if (variant !== 'auto') {
            return variant;
        }
        const key = this.name() || this.initials() || '';
        if (!key)
            return 'default';
        const variants = ['primary', 'royal', 'orange', 'purple'];
        let hash = 0;
        for (let i = 0; i < key.length; i++) {
            hash = key.charCodeAt(i) + ((hash << 5) - hash);
        }
        const index = Math.abs(hash) % variants.length;
        return variants[index];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveColorVariant" }] : /* istanbul ignore next */ []));
    accessibleLabel = computed(() => this.alt() || this.name() || this.label() || this.initials() || undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accessibleLabel" }] : /* istanbul ignore next */ []));
    statusText = computed(() => {
        return this.statusLabel() || '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "statusText" }] : /* istanbul ignore next */ []));
    // ── Event Handlers ────────────────────────────────────────
    onImageError(event) {
        this.imageFailed.set(true);
        this.imageError.emit(event);
    }
    onClick(event) {
        if (this.clickable()) {
            this.avatarClick.emit(event);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: AvatarComponent, isStandalone: true, selector: "orc-avatar", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, initials: { classPropertyName: "initials", publicName: "initials", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, statusLabel: { classPropertyName: "statusLabel", publicName: "statusLabel", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, statusPosition: { classPropertyName: "statusPosition", publicName: "statusPosition", isSignal: true, isRequired: false, transformFunction: null }, colorVariant: { classPropertyName: "colorVariant", publicName: "colorVariant", isSignal: true, isRequired: false, transformFunction: null }, bordered: { classPropertyName: "bordered", publicName: "bordered", isSignal: true, isRequired: false, transformFunction: null }, clickable: { classPropertyName: "clickable", publicName: "clickable", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { imageError: "imageError", avatarClick: "avatarClick" }, ngImport: i0, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-avatar p-component orc-avatar\"\n  [class]=\"'p-avatar p-component orc-avatar ' + styleClass()\"\n  [attr.data-pc-name]=\"'avatar'\"\n  [class.orc-avatar--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar--size-md]=\"size() === 'md'\"\n  [class.orc-avatar--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar--size-xl]=\"size() === 'xl'\"\n  [class.orc-avatar--shape-circular]=\"shape() === 'circular'\"\n  [class.orc-avatar--shape-rounded]=\"shape() === 'rounded'\"\n  [class.orc-avatar--shape-square]=\"shape() === 'square'\"\n  [class.orc-avatar--bordered]=\"bordered()\"\n  [class.orc-avatar--clickable]=\"clickable()\"\n  [class.orc-avatar--variant-default]=\"effectiveColorVariant() === 'default'\"\n  [class.orc-avatar--variant-primary]=\"effectiveColorVariant() === 'primary'\"\n  [class.orc-avatar--variant-royal]=\"effectiveColorVariant() === 'royal'\"\n  [class.orc-avatar--variant-orange]=\"effectiveColorVariant() === 'orange'\"\n  [class.orc-avatar--variant-purple]=\"effectiveColorVariant() === 'purple'\"\n  [class.orc-avatar--variant-cyan]=\"effectiveColorVariant() === 'cyan'\"\n  role=\"img\"\n  [attr.aria-label]=\"accessibleLabel()\"\n  [attr.tabindex]=\"clickable() ? 0 : null\"\n  (click)=\"onClick($event)\"\n  (keydown.enter)=\"onClick($any($event))\"\n  (keydown.space)=\"onClick($any($event))\"\n>\n  <!-- Imagem do Avatar -->\n  <img\n    *ngIf=\"showImage()\"\n    [src]=\"src()\"\n    [attr.alt]=\"alt() || accessibleLabel() || null\"\n    (error)=\"onImageError($event)\"\n    class=\"orc-avatar__img\"\n    loading=\"lazy\"\n  />\n\n  <!-- Iniciais do Usu\u00E1rio -->\n  <span *ngIf=\"hasInitials()\" class=\"orc-avatar__initials\" aria-hidden=\"true\">\n    {{ computedInitials() }}\n  </span>\n\n  @if (icon()) { <span class=\"orc-avatar__icon\" aria-hidden=\"true\">{{ icon() }}</span> }\n  <!-- \u00CDcone Fallback Padr\u00E3o -->\n  <svg\n    *ngIf=\"showIcon() && !icon()\"\n    class=\"orc-avatar__icon\"\n    viewBox=\"0 0 24 24\"\n    fill=\"none\"\n    stroke=\"currentColor\"\n    stroke-width=\"2\"\n    stroke-linecap=\"round\"\n    stroke-linejoin=\"round\"\n    aria-hidden=\"true\"\n  >\n    <path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\" />\n    <circle cx=\"12\" cy=\"7\" r=\"4\" />\n  </svg>\n\n  <!-- Indicador de Status (Online/Offline/Busy/Away) -->\n  <span\n    *ngIf=\"status()\"\n    class=\"orc-avatar__status\"\n    [class.orc-avatar__status--online]=\"status() === 'online'\"\n    [class.orc-avatar__status--offline]=\"status() === 'offline'\"\n    [class.orc-avatar__status--busy]=\"status() === 'busy'\"\n    [class.orc-avatar__status--away]=\"status() === 'away'\"\n    [class.orc-avatar__status--top-right]=\"statusPosition() === 'top-right'\"\n    [class.orc-avatar__status--bottom-right]=\"statusPosition() === 'bottom-right'\"\n    [class.orc-avatar__status--top-left]=\"statusPosition() === 'top-left'\"\n    [class.orc-avatar__status--bottom-left]=\"statusPosition() === 'bottom-left'\"\n    [attr.aria-label]=\"statusText() || null\"\n    [attr.title]=\"statusText() || null\"\n  ></span>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;box-sizing:border-box;overflow:visible;transition:transform var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-avatar--size-xs{width:24px;height:24px;font-size:.6875rem;--status-size: 6px;--status-offset: -1px;--icon-size: 14px;--border-radius-rounded: 6px}.orc-avatar--size-sm{width:32px;height:32px;font-size:.75rem;--status-size: 8px;--status-offset: -1px;--icon-size: 16px;--border-radius-rounded: 8px}.orc-avatar--size-md{width:40px;height:40px;font-size:.9375rem;--status-size: 10px;--status-offset: 0px;--icon-size: 20px;--border-radius-rounded: 10px}.orc-avatar--size-lg{width:48px;height:48px;font-size:1.0625rem;--status-size: 12px;--status-offset: 1px;--icon-size: 24px;--border-radius-rounded: 12px}.orc-avatar--size-xl{width:64px;height:64px;font-size:1.375rem;--status-size: 14px;--status-offset: 2px;--icon-size: 32px;--border-radius-rounded: 16px}.orc-avatar--shape-circular,.orc-avatar--shape-circular .orc-avatar__img{border-radius:9999px}.orc-avatar--shape-rounded,.orc-avatar--shape-rounded .orc-avatar__img{border-radius:var(--border-radius-rounded, 10px)}.orc-avatar--shape-square,.orc-avatar--shape-square .orc-avatar__img{border-radius:0}.orc-avatar--bordered{box-shadow:0 0 0 2px var(--orc-surface, var(--orc-bg, #ffffff))}.orc-avatar--variant-default{background-color:var(--orc-status-neutral-bg, #ececf0);color:var(--orc-status-neutral-fg, var(--orc-text, #0a0a0a))}.orc-avatar--variant-primary{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-royal{background-color:var(--orc-color-azul-royal, #0406ab);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-orange{background-color:var(--orc-color-laranja, #ff6a1c);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-purple{background-color:var(--orc-color-roxo-lavender, #6a1ced);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-cyan{background-color:var(--orc-color-ciano, #1cedb9);color:var(--orc-text, #141414)}.orc-avatar__img{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}.orc-avatar__initials{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;line-height:1;letter-spacing:.02em;font-weight:500}.orc-avatar__icon{width:var(--icon-size, 20px);height:var(--icon-size, 20px);opacity:.75}.orc-avatar__status{position:absolute;width:var(--status-size, 10px);height:var(--status-size, 10px);border-radius:9999px;border:2px solid var(--orc-surface, var(--orc-bg, #ffffff));box-sizing:content-box;z-index:2}.orc-avatar__status--bottom-right{bottom:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--top-right{top:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--bottom-left{bottom:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--top-left{top:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--online{background-color:var(--orc-status-success-fg, #22c55e)}.orc-avatar__status--busy{background-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-avatar__status--away{background-color:var(--orc-status-warning-fg, var(--color-warning, #fe9a00))}.orc-avatar__status--offline{background-color:var(--orc-text-muted, #999999)}.orc-avatar--clickable{cursor:pointer}.orc-avatar--clickable:hover{opacity:.9;transform:translateY(-1px)}.orc-avatar--clickable:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-avatar', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [attr.id]=\"id() || null\"\n  class=\"p-avatar p-component orc-avatar\"\n  [class]=\"'p-avatar p-component orc-avatar ' + styleClass()\"\n  [attr.data-pc-name]=\"'avatar'\"\n  [class.orc-avatar--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar--size-md]=\"size() === 'md'\"\n  [class.orc-avatar--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar--size-xl]=\"size() === 'xl'\"\n  [class.orc-avatar--shape-circular]=\"shape() === 'circular'\"\n  [class.orc-avatar--shape-rounded]=\"shape() === 'rounded'\"\n  [class.orc-avatar--shape-square]=\"shape() === 'square'\"\n  [class.orc-avatar--bordered]=\"bordered()\"\n  [class.orc-avatar--clickable]=\"clickable()\"\n  [class.orc-avatar--variant-default]=\"effectiveColorVariant() === 'default'\"\n  [class.orc-avatar--variant-primary]=\"effectiveColorVariant() === 'primary'\"\n  [class.orc-avatar--variant-royal]=\"effectiveColorVariant() === 'royal'\"\n  [class.orc-avatar--variant-orange]=\"effectiveColorVariant() === 'orange'\"\n  [class.orc-avatar--variant-purple]=\"effectiveColorVariant() === 'purple'\"\n  [class.orc-avatar--variant-cyan]=\"effectiveColorVariant() === 'cyan'\"\n  role=\"img\"\n  [attr.aria-label]=\"accessibleLabel()\"\n  [attr.tabindex]=\"clickable() ? 0 : null\"\n  (click)=\"onClick($event)\"\n  (keydown.enter)=\"onClick($any($event))\"\n  (keydown.space)=\"onClick($any($event))\"\n>\n  <!-- Imagem do Avatar -->\n  <img\n    *ngIf=\"showImage()\"\n    [src]=\"src()\"\n    [attr.alt]=\"alt() || accessibleLabel() || null\"\n    (error)=\"onImageError($event)\"\n    class=\"orc-avatar__img\"\n    loading=\"lazy\"\n  />\n\n  <!-- Iniciais do Usu\u00E1rio -->\n  <span *ngIf=\"hasInitials()\" class=\"orc-avatar__initials\" aria-hidden=\"true\">\n    {{ computedInitials() }}\n  </span>\n\n  @if (icon()) { <span class=\"orc-avatar__icon\" aria-hidden=\"true\">{{ icon() }}</span> }\n  <!-- \u00CDcone Fallback Padr\u00E3o -->\n  <svg\n    *ngIf=\"showIcon() && !icon()\"\n    class=\"orc-avatar__icon\"\n    viewBox=\"0 0 24 24\"\n    fill=\"none\"\n    stroke=\"currentColor\"\n    stroke-width=\"2\"\n    stroke-linecap=\"round\"\n    stroke-linejoin=\"round\"\n    aria-hidden=\"true\"\n  >\n    <path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\" />\n    <circle cx=\"12\" cy=\"7\" r=\"4\" />\n  </svg>\n\n  <!-- Indicador de Status (Online/Offline/Busy/Away) -->\n  <span\n    *ngIf=\"status()\"\n    class=\"orc-avatar__status\"\n    [class.orc-avatar__status--online]=\"status() === 'online'\"\n    [class.orc-avatar__status--offline]=\"status() === 'offline'\"\n    [class.orc-avatar__status--busy]=\"status() === 'busy'\"\n    [class.orc-avatar__status--away]=\"status() === 'away'\"\n    [class.orc-avatar__status--top-right]=\"statusPosition() === 'top-right'\"\n    [class.orc-avatar__status--bottom-right]=\"statusPosition() === 'bottom-right'\"\n    [class.orc-avatar__status--top-left]=\"statusPosition() === 'top-left'\"\n    [class.orc-avatar__status--bottom-left]=\"statusPosition() === 'bottom-left'\"\n    [attr.aria-label]=\"statusText() || null\"\n    [attr.title]=\"statusText() || null\"\n  ></span>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);font-weight:500;box-sizing:border-box;overflow:visible;transition:transform var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-avatar--size-xs{width:24px;height:24px;font-size:.6875rem;--status-size: 6px;--status-offset: -1px;--icon-size: 14px;--border-radius-rounded: 6px}.orc-avatar--size-sm{width:32px;height:32px;font-size:.75rem;--status-size: 8px;--status-offset: -1px;--icon-size: 16px;--border-radius-rounded: 8px}.orc-avatar--size-md{width:40px;height:40px;font-size:.9375rem;--status-size: 10px;--status-offset: 0px;--icon-size: 20px;--border-radius-rounded: 10px}.orc-avatar--size-lg{width:48px;height:48px;font-size:1.0625rem;--status-size: 12px;--status-offset: 1px;--icon-size: 24px;--border-radius-rounded: 12px}.orc-avatar--size-xl{width:64px;height:64px;font-size:1.375rem;--status-size: 14px;--status-offset: 2px;--icon-size: 32px;--border-radius-rounded: 16px}.orc-avatar--shape-circular,.orc-avatar--shape-circular .orc-avatar__img{border-radius:9999px}.orc-avatar--shape-rounded,.orc-avatar--shape-rounded .orc-avatar__img{border-radius:var(--border-radius-rounded, 10px)}.orc-avatar--shape-square,.orc-avatar--shape-square .orc-avatar__img{border-radius:0}.orc-avatar--bordered{box-shadow:0 0 0 2px var(--orc-surface, var(--orc-bg, #ffffff))}.orc-avatar--variant-default{background-color:var(--orc-status-neutral-bg, #ececf0);color:var(--orc-status-neutral-fg, var(--orc-text, #0a0a0a))}.orc-avatar--variant-primary{background-color:var(--orc-color-azul-eletrico, #1c6aed);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-royal{background-color:var(--orc-color-azul-royal, #0406ab);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-orange{background-color:var(--orc-color-laranja, #ff6a1c);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-purple{background-color:var(--orc-color-roxo-lavender, #6a1ced);color:var(--orc-on-dark, #ffffff)}.orc-avatar--variant-cyan{background-color:var(--orc-color-ciano, #1cedb9);color:var(--orc-text, #141414)}.orc-avatar__img{width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}.orc-avatar__initials{display:inline-flex;align-items:center;justify-content:center;width:100%;height:100%;line-height:1;letter-spacing:.02em;font-weight:500}.orc-avatar__icon{width:var(--icon-size, 20px);height:var(--icon-size, 20px);opacity:.75}.orc-avatar__status{position:absolute;width:var(--status-size, 10px);height:var(--status-size, 10px);border-radius:9999px;border:2px solid var(--orc-surface, var(--orc-bg, #ffffff));box-sizing:content-box;z-index:2}.orc-avatar__status--bottom-right{bottom:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--top-right{top:var(--status-offset, 0px);right:var(--status-offset, 0px)}.orc-avatar__status--bottom-left{bottom:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--top-left{top:var(--status-offset, 0px);left:var(--status-offset, 0px)}.orc-avatar__status--online{background-color:var(--orc-status-success-fg, #22c55e)}.orc-avatar__status--busy{background-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-avatar__status--away{background-color:var(--orc-status-warning-fg, var(--color-warning, #fe9a00))}.orc-avatar__status--offline{background-color:var(--orc-text-muted, #999999)}.orc-avatar--clickable{cursor:pointer}.orc-avatar--clickable:hover{opacity:.9;transform:translateY(-1px)}.orc-avatar--clickable:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], initials: [{ type: i0.Input, args: [{ isSignal: true, alias: "initials", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }], statusLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "statusLabel", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], statusPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "statusPosition", required: false }] }], colorVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "colorVariant", required: false }] }], bordered: [{ type: i0.Input, args: [{ isSignal: true, alias: "bordered", required: false }] }], clickable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickable", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], imageError: [{ type: i0.Output, args: ["imageError"] }], avatarClick: [{ type: i0.Output, args: ["avatarClick"] }] } });

class AvatarGroupComponent {
    // Inputs (Signals API)
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    max = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    shape = input('circular', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    excessCount = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "excessCount" }] : /* istanbul ignore next */ []));
    excessColorVariant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "excessColorVariant" }] : /* istanbul ignore next */ []));
    bordered = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "bordered" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    // Sinais computados
    visibleItems = computed(() => {
        const list = this.items();
        const limit = this.max();
        if (limit > 0 && list.length > limit) {
            return list.slice(0, limit);
        }
        return list;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    calculatedExcess = computed(() => {
        if (this.excessCount() > 0) {
            return this.excessCount();
        }
        const limit = this.max();
        const total = this.items().length;
        if (limit > 0 && total > limit) {
            return total - limit;
        }
        return 0;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "calculatedExcess" }] : /* istanbul ignore next */ []));
    excessText = computed(() => {
        const excess = this.calculatedExcess();
        return excess > 0 ? `+${excess}` : '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "excessText" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AvatarGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: AvatarGroupComponent, isStandalone: true, selector: "orc-avatar-group", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, excessCount: { classPropertyName: "excessCount", publicName: "excessCount", isSignal: true, isRequired: false, transformFunction: null }, excessColorVariant: { classPropertyName: "excessColorVariant", publicName: "excessColorVariant", isSignal: true, isRequired: false, transformFunction: null }, bordered: { classPropertyName: "bordered", publicName: "bordered", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\n  class=\"orc-avatar-group\"\n  [class]=\"styleClass()\"\n  [class.orc-avatar-group--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar-group--size-md]=\"size() === 'md'\"\n  [class.orc-avatar-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar-group--size-xl]=\"size() === 'xl'\"\n  role=\"group\"\n  [attr.aria-label]=\"label() || null\"\n>\n  <!-- Modo com lista de items informada via input -->\n  <ng-container *ngIf=\"items().length > 0\">\n    <orc-avatar\n      *ngFor=\"let item of visibleItems()\"\n      [src]=\"item.src || ''\"\n      [name]=\"item.name || ''\"\n      [initials]=\"item.initials || ''\"\n      [alt]=\"item.alt || ''\"\n      [size]=\"size()\"\n      [shape]=\"shape()\"\n      [status]=\"item.status\"\n      [colorVariant]=\"item.colorVariant || 'default'\"\n      [bordered]=\"bordered()\"\n      class=\"orc-avatar-group__item\"\n    ></orc-avatar>\n  </ng-container>\n\n  <!-- Proje\u00E7\u00E3o de conte\u00FAdo quando items n\u00E3o for informado -->\n  <ng-content></ng-content>\n\n  <!-- Contador Excedente (+N) -->\n  <orc-avatar\n    *ngIf=\"calculatedExcess() > 0\"\n    [initials]=\"excessText()\"\n    [size]=\"size()\"\n    [shape]=\"shape()\"\n    [colorVariant]=\"excessColorVariant()\"\n    [bordered]=\"bordered()\"\n    [alt]=\"'Mais ' + calculatedExcess() + ' membros'\"\n    class=\"orc-avatar-group__item orc-avatar-group__excess\"\n  ></orc-avatar>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar-group{display:inline-flex;align-items:center;flex-direction:row;--group-overlap: -12px}.orc-avatar-group--size-xs{--group-overlap: -8px}.orc-avatar-group--size-sm{--group-overlap: -10px}.orc-avatar-group--size-md{--group-overlap: -12px}.orc-avatar-group--size-lg{--group-overlap: -14px}.orc-avatar-group--size-xl{--group-overlap: -18px}.orc-avatar-group ::ng-deep>app-avatar,.orc-avatar-group .orc-avatar-group__item{position:relative;transition:transform var(--transition-fast, .12s ease),z-index var(--transition-fast, .12s ease)}.orc-avatar-group ::ng-deep>app-avatar .orc-avatar,.orc-avatar-group .orc-avatar-group__item .orc-avatar{box-shadow:0 0 0 2px var(--orc-surface, var(--orc-bg, #ffffff))}.orc-avatar-group ::ng-deep>app-avatar:not(:first-child),.orc-avatar-group .orc-avatar-group__item:not(:first-child){margin-left:var(--group-overlap)}.orc-avatar-group ::ng-deep>app-avatar:hover,.orc-avatar-group .orc-avatar-group__item:hover{z-index:10!important;transform:translateY(-2px) scale(1.08)}.orc-avatar-group__excess .orc-avatar{background-color:var(--orc-status-neutral-bg, #ececf0);color:var(--orc-status-neutral-fg, var(--orc-text, #0a0a0a));font-weight:500}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: AvatarComponent, selector: "orc-avatar", inputs: ["src", "name", "label", "icon", "initials", "alt", "statusLabel", "size", "shape", "status", "statusPosition", "colorVariant", "bordered", "clickable", "id", "styleClass"], outputs: ["imageError", "avatarClick"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AvatarGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-avatar-group', standalone: true, imports: [CommonModule, AvatarComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"orc-avatar-group\"\n  [class]=\"styleClass()\"\n  [class.orc-avatar-group--size-xs]=\"size() === 'xs'\"\n  [class.orc-avatar-group--size-sm]=\"size() === 'sm'\"\n  [class.orc-avatar-group--size-md]=\"size() === 'md'\"\n  [class.orc-avatar-group--size-lg]=\"size() === 'lg'\"\n  [class.orc-avatar-group--size-xl]=\"size() === 'xl'\"\n  role=\"group\"\n  [attr.aria-label]=\"label() || null\"\n>\n  <!-- Modo com lista de items informada via input -->\n  <ng-container *ngIf=\"items().length > 0\">\n    <orc-avatar\n      *ngFor=\"let item of visibleItems()\"\n      [src]=\"item.src || ''\"\n      [name]=\"item.name || ''\"\n      [initials]=\"item.initials || ''\"\n      [alt]=\"item.alt || ''\"\n      [size]=\"size()\"\n      [shape]=\"shape()\"\n      [status]=\"item.status\"\n      [colorVariant]=\"item.colorVariant || 'default'\"\n      [bordered]=\"bordered()\"\n      class=\"orc-avatar-group__item\"\n    ></orc-avatar>\n  </ng-container>\n\n  <!-- Proje\u00E7\u00E3o de conte\u00FAdo quando items n\u00E3o for informado -->\n  <ng-content></ng-content>\n\n  <!-- Contador Excedente (+N) -->\n  <orc-avatar\n    *ngIf=\"calculatedExcess() > 0\"\n    [initials]=\"excessText()\"\n    [size]=\"size()\"\n    [shape]=\"shape()\"\n    [colorVariant]=\"excessColorVariant()\"\n    [bordered]=\"bordered()\"\n    [alt]=\"'Mais ' + calculatedExcess() + ' membros'\"\n    class=\"orc-avatar-group__item orc-avatar-group__excess\"\n  ></orc-avatar>\n</div>\n", styles: [":host{display:inline-flex}.orc-avatar-group{display:inline-flex;align-items:center;flex-direction:row;--group-overlap: -12px}.orc-avatar-group--size-xs{--group-overlap: -8px}.orc-avatar-group--size-sm{--group-overlap: -10px}.orc-avatar-group--size-md{--group-overlap: -12px}.orc-avatar-group--size-lg{--group-overlap: -14px}.orc-avatar-group--size-xl{--group-overlap: -18px}.orc-avatar-group ::ng-deep>app-avatar,.orc-avatar-group .orc-avatar-group__item{position:relative;transition:transform var(--transition-fast, .12s ease),z-index var(--transition-fast, .12s ease)}.orc-avatar-group ::ng-deep>app-avatar .orc-avatar,.orc-avatar-group .orc-avatar-group__item .orc-avatar{box-shadow:0 0 0 2px var(--orc-surface, var(--orc-bg, #ffffff))}.orc-avatar-group ::ng-deep>app-avatar:not(:first-child),.orc-avatar-group .orc-avatar-group__item:not(:first-child){margin-left:var(--group-overlap)}.orc-avatar-group ::ng-deep>app-avatar:hover,.orc-avatar-group .orc-avatar-group__item:hover{z-index:10!important;transform:translateY(-2px) scale(1.08)}.orc-avatar-group__excess .orc-avatar{background-color:var(--orc-status-neutral-bg, #ececf0);color:var(--orc-status-neutral-fg, var(--orc-text, #0a0a0a));font-weight:500}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], excessCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "excessCount", required: false }] }], excessColorVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "excessColorVariant", required: false }] }], bordered: [{ type: i0.Input, args: [{ isSignal: true, alias: "bordered", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AvatarComponent, AvatarGroupComponent };
//# sourceMappingURL=ciag-orchestra-avatar.mjs.map
