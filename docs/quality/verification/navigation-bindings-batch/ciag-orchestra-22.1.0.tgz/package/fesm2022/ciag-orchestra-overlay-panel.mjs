import * as i0 from '@angular/core';
import { model, input, booleanAttribute, output, computed, inject, ElementRef, viewChild, effect, afterEveryRender, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { isTopOverlay, trapTabKey, eventIsInside, registerOverlay, listenForOutsideInteraction, isolateModalBackground, lockDocumentScroll, focusInitialElement, overlayAttachmentTarget, positionOverlayPanel } from '@ciag/orchestra/internal';

let nextOverlayPanelId = 0;
class OverlayPanelComponent {
    componentKind = 'overlaypanel';
    visible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    modal = input(false, { ...(ngDevMode ? { debugName: "modal" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismissable = input(true, { ...(ngDevMode ? { debugName: "dismissable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closable = input(false, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCloseIcon = input(false, { ...(ngDevMode ? { debugName: "showCloseIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    id = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    closeLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeLabel" }] : /* istanbul ignore next */ []));
    ariaCloseLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaCloseLabel" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "baseZIndex" }] : /* istanbul ignore next */ []));
    focusOnShow = input(true, { ...(ngDevMode ? { debugName: "focusOnShow" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showTransitionOptions = input('150ms cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input('100ms linear', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    onShow = output();
    onHide = output();
    onClick = output();
    computedZIndex = computed(() => this.autoZIndex() ? this.baseZIndex() + 1 : this.baseZIndex(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedZIndex" }] : /* istanbul ignore next */ []));
    open = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    placement = input('bottom', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []));
    align = input('start', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    header = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    host = inject(ElementRef);
    document = inject(DOCUMENT);
    instanceId = ++nextOverlayPanelId;
    panelId = computed(() => this.id() || `orc-${this.componentKind}-${this.instanceId}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelId" }] : /* istanbul ignore next */ []));
    defaultLabel = computed(() => this.componentKind === 'popover' ? 'Popover' : 'Overlay panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultLabel" }] : /* istanbul ignore next */ []));
    defaultCloseLabel = computed(() => this.componentKind === 'popover' ? 'Close popover' : 'Close panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultCloseLabel" }] : /* istanbul ignore next */ []));
    panelClassNames = computed(() => `orc-popover orc-overlay-surface p-component p-${this.componentKind} orc-p2-${this.componentKind === 'popover' ? 'popover' : 'overlay-panel'} orc-popover--${this.placement()} orc-popover--align-${this.align()} ${this.styleClass()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelClassNames" }] : /* istanbul ignore next */ []));
    trigger = viewChild('trigger', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []));
    panel = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    hasTrigger = false;
    previousOpen = false;
    previousVisible = false;
    active = false;
    previousFocus = null;
    anchor = null;
    cleanup = [];
    releaseScroll;
    releaseIsolation;
    triggerControl = null;
    originalTriggerAttributes = new Map();
    focused = false;
    restoreOnHide = true;
    constructor() {
        effect(() => {
            const open = this.open();
            const visible = this.visible();
            const next = open !== this.previousOpen
                ? open
                : visible !== this.previousVisible
                    ? visible
                    : open;
            this.previousOpen = this.previousVisible = next;
            if (open !== next)
                this.open.set(next);
            if (visible !== next)
                this.visible.set(next);
        });
        afterEveryRender(() => this.syncView());
    }
    toggle(event, target) {
        this.open() ? this.close() : this.show(event, target);
    }
    show(event, target) {
        this.anchor =
            target ??
                (typeof HTMLElement !== 'undefined' &&
                    event?.currentTarget instanceof HTMLElement
                    ? event.currentTarget
                    : null) ??
                this.triggerControl;
        if (!this.open()) {
            this.open.set(true);
            this.visible.set(true);
        }
    }
    close(restoreFocus = true) {
        if (!this.open())
            return;
        this.restoreOnHide = restoreFocus;
        this.open.set(false);
        this.visible.set(false);
        if (restoreFocus && this.previousFocus?.isConnected)
            this.previousFocus.focus({ preventScroll: true });
    }
    hide() {
        this.close(true);
    }
    onTriggerClick(event) {
        if (event.target.closest(':disabled, [aria-disabled="true"]'))
            return;
        this.toggle(event, this.triggerControl ?? this.trigger()?.nativeElement);
    }
    onTriggerKeydown(event) {
        const target = event.target;
        if (target.closest(':disabled, [aria-disabled="true"]'))
            return;
        const nativeActivation = target.matches('button, input, a[href]');
        if (event.key === 'ArrowDown' ||
            (!nativeActivation && (event.key === 'Enter' || event.key === ' '))) {
            event.preventDefault();
            this.show(event, this.triggerControl ?? this.trigger()?.nativeElement);
        }
    }
    onDocumentKeydown(event) {
        const panel = this.panel()?.nativeElement;
        if (!this.open() ||
            !panel ||
            !isTopOverlay(panel) ||
            event.defaultPrevented)
            return;
        if (event.key === 'Escape' && this.closeOnEscape()) {
            event.preventDefault();
            this.close(true);
        }
        else if (this.modal())
            trapTabKey(event, panel);
    }
    onEscape() {
        if (this.closeOnEscape())
            this.close(true);
    }
    onDocumentClick(event) {
        const panel = this.panel()?.nativeElement;
        if (!panel || isTopOverlay(panel))
            this.onOutside(event);
    }
    onOutside(event) {
        if (this.open() &&
            this.dismissable() &&
            !eventIsInside(event, [
                this.host.nativeElement,
                this.panel()?.nativeElement,
                this.anchor,
            ]))
            this.close(this.modal());
    }
    syncView() {
        const panel = this.panel()?.nativeElement;
        const trigger = this.trigger()?.nativeElement;
        if (!panel || !trigger)
            return;
        this.hasTrigger =
            !!trigger.textContent?.trim() || !!trigger.firstElementChild;
        trigger.hidden = !this.hasTrigger;
        const control = trigger.querySelector('button, a[href], input, [role="button"], [tabindex]');
        if (control) {
            for (const name of [
                'role',
                'tabindex',
                'aria-expanded',
                'aria-controls',
                'aria-haspopup',
            ])
                trigger.removeAttribute(name);
        }
        else {
            trigger.setAttribute('role', 'button');
            trigger.setAttribute('tabindex', this.hasTrigger ? '0' : '-1');
            trigger.setAttribute('aria-expanded', String(this.open()));
            trigger.setAttribute('aria-haspopup', 'dialog');
            if (this.open())
                trigger.setAttribute('aria-controls', this.panelId());
            else
                trigger.removeAttribute('aria-controls');
        }
        if (control !== this.triggerControl) {
            this.restoreTriggerAttributes();
            this.triggerControl = control;
            if (control)
                for (const name of ['aria-expanded', 'aria-controls', 'aria-haspopup'])
                    this.originalTriggerAttributes.set(name, control.getAttribute(name));
        }
        if (control) {
            control.setAttribute('aria-expanded', String(this.open()));
            control.setAttribute('aria-haspopup', 'dialog');
            if (this.open())
                control.setAttribute('aria-controls', this.panelId());
            else if (this.originalTriggerAttributes.get('aria-controls'))
                control.setAttribute('aria-controls', this.originalTriggerAttributes.get('aria-controls'));
            else
                control.removeAttribute('aria-controls');
        }
        // A global render callback may run while a different root is rendering.
        // Wait until this view has applied the requested visibility before focusing.
        if (panel.hidden === this.open())
            return;
        if (this.open()) {
            if (!this.active) {
                this.active = true;
                this.restoreOnHide = true;
                this.previousFocus = this.document.activeElement;
                this.anchor ??=
                    control ?? (this.hasTrigger ? trigger : this.host.nativeElement);
                this.cleanup.push(registerOverlay(panel, {
                    anchor: this.anchor,
                    onParentClose: () => {
                        this.close(false);
                        this.releaseIsolation?.();
                        this.releaseIsolation = undefined;
                    },
                }));
                const keydown = (event) => this.onDocumentKeydown(event);
                this.document.addEventListener('keydown', keydown);
                this.cleanup.push(() => this.document.removeEventListener('keydown', keydown));
                this.cleanup.push(listenForOutsideInteraction(this.document, () => [this.host.nativeElement, panel, this.anchor], (event) => {
                    if (isTopOverlay(panel))
                        this.onOutside(event);
                }));
                const reposition = () => this.positionPanel();
                this.document.addEventListener('scroll', reposition, true);
                this.document.defaultView?.addEventListener('resize', reposition);
                this.cleanup.push(() => {
                    this.document.removeEventListener('scroll', reposition, true);
                    this.document.defaultView?.removeEventListener('resize', reposition);
                });
                if (typeof ResizeObserver !== 'undefined') {
                    const observer = new ResizeObserver(reposition);
                    observer.observe(panel);
                    if (this.anchor)
                        observer.observe(this.anchor);
                    this.cleanup.push(() => observer.disconnect());
                }
                this.onShow.emit();
            }
            this.attachPanel(panel);
            this.positionPanel();
            if (this.modal() && !this.releaseIsolation)
                this.releaseIsolation = isolateModalBackground(panel);
            if (!this.modal() && this.releaseIsolation) {
                this.releaseIsolation();
                this.releaseIsolation = undefined;
            }
            if (this.modal() && !this.releaseScroll)
                this.releaseScroll = lockDocumentScroll(this.document);
            if (!this.modal() && this.releaseScroll) {
                this.releaseScroll();
                this.releaseScroll = undefined;
            }
            if (!this.focused) {
                this.focused = true;
                if (this.focusOnShow()) {
                    focusInitialElement(panel);
                }
            }
        }
        else if (this.active) {
            this.releaseResources();
            if (this.restoreOnHide && this.previousFocus?.isConnected)
                this.previousFocus.focus({ preventScroll: true });
            this.host.nativeElement.appendChild(panel);
            this.onHide.emit();
        }
    }
    attachPanel(panel) {
        const parent = overlayAttachmentTarget(this.anchor ?? this.host.nativeElement, this.appendTo(), this.host.nativeElement);
        if (parent !== panel &&
            !panel.contains(parent) &&
            panel.parentElement !== parent)
            parent.appendChild(panel);
    }
    positionPanel() {
        const panel = this.panel()?.nativeElement;
        const anchor = this.anchor ?? this.host.nativeElement;
        const window = this.document.defaultView;
        if (!this.open() || !panel?.isConnected || !window)
            return;
        const origin = anchor.getBoundingClientRect();
        const rect = panel.getBoundingClientRect();
        let { left, top, placement } = positionOverlayPanel(origin, rect, { width: window.innerWidth, height: window.innerHeight }, this.placement(), this.align(), window.getComputedStyle(anchor).direction === 'rtl');
        panel.dataset['placement'] = placement;
        // Fixed positioning is relative to the viewport unless a transformed parent
        // establishes a containing block. Local placement uses the actual offset parent.
        panel.style.position =
            panel.parentElement === this.document.body ? 'fixed' : 'absolute';
        const offset = panel.style.position === 'absolute'
            ? panel.offsetParent
            : null;
        if (offset === this.document.body &&
            window.getComputedStyle(offset).position === 'static') {
            left += window.scrollX;
            top += window.scrollY;
        }
        else if (offset) {
            const bounds = offset.getBoundingClientRect();
            left -= bounds.left + offset.clientLeft - offset.scrollLeft;
            top -= bounds.top + offset.clientTop - offset.scrollTop;
        }
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
    }
    restoreTriggerAttributes() {
        if (this.triggerControl)
            for (const [name, value] of this.originalTriggerAttributes) {
                if (value === null)
                    this.triggerControl.removeAttribute(name);
                else
                    this.triggerControl.setAttribute(name, value);
            }
        this.originalTriggerAttributes.clear();
        this.triggerControl = null;
    }
    releaseResources() {
        this.releaseIsolation?.();
        this.releaseIsolation = undefined;
        this.cleanup.splice(0).forEach((cleanup) => cleanup());
        this.releaseScroll?.();
        this.releaseScroll = undefined;
        this.active = false;
        this.focused = false;
        this.anchor = null;
    }
    ngOnDestroy() {
        this.releaseResources();
        this.restoreTriggerAttributes();
        const panel = this.panel()?.nativeElement;
        panel?.remove();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OverlayPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OverlayPanelComponent, isStandalone: true, selector: "orc-overlay-panel", inputs: { visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, modal: { classPropertyName: "modal", publicName: "modal", isSignal: true, isRequired: false, transformFunction: null }, dismissable: { classPropertyName: "dismissable", publicName: "dismissable", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, showCloseIcon: { classPropertyName: "showCloseIcon", publicName: "showCloseIcon", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, closeLabel: { classPropertyName: "closeLabel", publicName: "closeLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaCloseLabel: { classPropertyName: "ariaCloseLabel", publicName: "ariaCloseLabel", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, focusOnShow: { classPropertyName: "focusOnShow", publicName: "focusOnShow", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { visible: "visibleChange", onShow: "onShow", onHide: "onHide", onClick: "onClick", open: "openChange" }, viewQueries: [{ propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true, isSignal: true }, { propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }], ngImport: i0, template: "<span\n  #trigger\n  class=\"orc-popover__trigger\"\n  (click)=\"onTriggerClick($event)\"\n  (keydown)=\"onTriggerKeydown($event)\"\n  ><ng-content select=\"[popover-trigger]\"\n/></span>\n<section\n  #panel\n  [id]=\"panelId()\"\n  [hidden]=\"!open()\"\n  [inert]=\"!open()\"\n  [attr.aria-hidden]=\"open() ? null : true\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  [class]=\"panelClassNames()\"\n  [style]=\"style()\"\n  [style.--orc-popover-transition]=\"\n    open() ? showTransitionOptions() : hideTransitionOptions()\n  \"\n  [style.z-index]=\"\n    autoZIndex() ? (baseZIndex() ? computedZIndex() : null) : baseZIndex()\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() ||\n    label() ||\n    (!header() && !ariaLabelledBy() ? defaultLabel() : null)\n  \"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() ||\n    (header() && !ariaLabel() && !label() ? panelId() + '-title' : null)\n  \"\n  [attr.aria-modal]=\"modal() || null\"\n  [attr.data-pc-name]=\"componentKind\"\n  (click)=\"onClick.emit($event)\"\n>\n  @if (header() || closable() || showCloseIcon()) {\n    <header class=\"orc-popover__header\">\n      @if (header()) {\n        <span [id]=\"panelId() + '-title'\">{{ header() }}</span>\n      }\n      @if (closable() || showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-popover__close close\"\n          [attr.aria-label]=\"\n            ariaCloseLabel() || closeLabel() || defaultCloseLabel()\n          \"\n          (click)=\"hide()\"\n        >\n          \u00D7\n        </button>\n      }\n    </header>\n  }\n  <ng-content />\n</section>\n", styles: [":host{position:relative;display:inline-block}.orc-popover__trigger{display:inline-flex;cursor:pointer}.orc-popover__trigger[hidden],.orc-popover[hidden]{display:none}.orc-popover{box-sizing:border-box;position:absolute;z-index:var(--z-popover, 1000);width:max-content;min-width:12rem;max-width:min(22rem,100vw - 16px);max-height:calc(100dvh - 16px);overflow:auto;padding:var(--space-4, 1rem);background:var(--orc-surface-raised, var(--orc-fill-modal, white));color:var(--orc-text, var(--text-primary, #141414));border:1px solid var(--orc-border-default, var(--border-default, #ddd));border-radius:var(--radius-md, .5rem);box-shadow:var(--shadow-lg, 0 12px 30px rgba(0, 0, 0, .1333333333))}.orc-popover__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3, .75rem);margin-bottom:var(--space-3, .75rem);font-weight:600}.orc-popover__close{margin-inline-start:auto;min-width:2rem;min-height:2rem;border:0;border-radius:var(--radius-sm, .25rem);background:transparent;color:inherit;font:inherit;font-size:1.25rem;cursor:pointer}.orc-popover__close:focus-visible,.orc-popover__trigger:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-popover{opacity:1;transition:opacity var(--orc-popover-transition, .15s ease),display var(--orc-popover-transition, .15s ease) allow-discrete}.orc-popover[hidden]{opacity:0}@starting-style{.orc-popover:not([hidden]){opacity:0}}@media(prefers-reduced-motion:reduce){.orc-popover{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OverlayPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-overlay-panel', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n  #trigger\n  class=\"orc-popover__trigger\"\n  (click)=\"onTriggerClick($event)\"\n  (keydown)=\"onTriggerKeydown($event)\"\n  ><ng-content select=\"[popover-trigger]\"\n/></span>\n<section\n  #panel\n  [id]=\"panelId()\"\n  [hidden]=\"!open()\"\n  [inert]=\"!open()\"\n  [attr.aria-hidden]=\"open() ? null : true\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  [class]=\"panelClassNames()\"\n  [style]=\"style()\"\n  [style.--orc-popover-transition]=\"\n    open() ? showTransitionOptions() : hideTransitionOptions()\n  \"\n  [style.z-index]=\"\n    autoZIndex() ? (baseZIndex() ? computedZIndex() : null) : baseZIndex()\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() ||\n    label() ||\n    (!header() && !ariaLabelledBy() ? defaultLabel() : null)\n  \"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() ||\n    (header() && !ariaLabel() && !label() ? panelId() + '-title' : null)\n  \"\n  [attr.aria-modal]=\"modal() || null\"\n  [attr.data-pc-name]=\"componentKind\"\n  (click)=\"onClick.emit($event)\"\n>\n  @if (header() || closable() || showCloseIcon()) {\n    <header class=\"orc-popover__header\">\n      @if (header()) {\n        <span [id]=\"panelId() + '-title'\">{{ header() }}</span>\n      }\n      @if (closable() || showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-popover__close close\"\n          [attr.aria-label]=\"\n            ariaCloseLabel() || closeLabel() || defaultCloseLabel()\n          \"\n          (click)=\"hide()\"\n        >\n          \u00D7\n        </button>\n      }\n    </header>\n  }\n  <ng-content />\n</section>\n", styles: [":host{position:relative;display:inline-block}.orc-popover__trigger{display:inline-flex;cursor:pointer}.orc-popover__trigger[hidden],.orc-popover[hidden]{display:none}.orc-popover{box-sizing:border-box;position:absolute;z-index:var(--z-popover, 1000);width:max-content;min-width:12rem;max-width:min(22rem,100vw - 16px);max-height:calc(100dvh - 16px);overflow:auto;padding:var(--space-4, 1rem);background:var(--orc-surface-raised, var(--orc-fill-modal, white));color:var(--orc-text, var(--text-primary, #141414));border:1px solid var(--orc-border-default, var(--border-default, #ddd));border-radius:var(--radius-md, .5rem);box-shadow:var(--shadow-lg, 0 12px 30px rgba(0, 0, 0, .1333333333))}.orc-popover__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3, .75rem);margin-bottom:var(--space-3, .75rem);font-weight:600}.orc-popover__close{margin-inline-start:auto;min-width:2rem;min-height:2rem;border:0;border-radius:var(--radius-sm, .25rem);background:transparent;color:inherit;font:inherit;font-size:1.25rem;cursor:pointer}.orc-popover__close:focus-visible,.orc-popover__trigger:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-popover{opacity:1;transition:opacity var(--orc-popover-transition, .15s ease),display var(--orc-popover-transition, .15s ease) allow-discrete}.orc-popover[hidden]{opacity:0}@starting-style{.orc-popover:not([hidden]){opacity:0}}@media(prefers-reduced-motion:reduce){.orc-popover{transition:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }], modal: [{ type: i0.Input, args: [{ isSignal: true, alias: "modal", required: false }] }], dismissable: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissable", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], showCloseIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCloseIcon", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], closeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeLabel", required: false }] }], ariaCloseLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaCloseLabel", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], focusOnShow: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnShow", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClick: [{ type: i0.Output, args: ["onClick"] }], open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], placement: [{ type: i0.Input, args: [{ isSignal: true, alias: "placement", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], trigger: [{ type: i0.ViewChild, args: ['trigger', { isSignal: true }] }], panel: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }] } });
/** Co-located with the base so JIT and split bundles initialize inheritance atomically. */
class PopoverComponent extends OverlayPanelComponent {
    componentKind = 'popover';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PopoverComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: PopoverComponent, isStandalone: true, selector: "orc-popover", usesInheritance: true, ngImport: i0, template: "<span\n  #trigger\n  class=\"orc-popover__trigger\"\n  (click)=\"onTriggerClick($event)\"\n  (keydown)=\"onTriggerKeydown($event)\"\n  ><ng-content select=\"[popover-trigger]\"\n/></span>\n<section\n  #panel\n  [id]=\"panelId()\"\n  [hidden]=\"!open()\"\n  [inert]=\"!open()\"\n  [attr.aria-hidden]=\"open() ? null : true\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  [class]=\"panelClassNames()\"\n  [style]=\"style()\"\n  [style.--orc-popover-transition]=\"\n    open() ? showTransitionOptions() : hideTransitionOptions()\n  \"\n  [style.z-index]=\"\n    autoZIndex() ? (baseZIndex() ? computedZIndex() : null) : baseZIndex()\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() ||\n    label() ||\n    (!header() && !ariaLabelledBy() ? defaultLabel() : null)\n  \"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() ||\n    (header() && !ariaLabel() && !label() ? panelId() + '-title' : null)\n  \"\n  [attr.aria-modal]=\"modal() || null\"\n  [attr.data-pc-name]=\"componentKind\"\n  (click)=\"onClick.emit($event)\"\n>\n  @if (header() || closable() || showCloseIcon()) {\n    <header class=\"orc-popover__header\">\n      @if (header()) {\n        <span [id]=\"panelId() + '-title'\">{{ header() }}</span>\n      }\n      @if (closable() || showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-popover__close close\"\n          [attr.aria-label]=\"\n            ariaCloseLabel() || closeLabel() || defaultCloseLabel()\n          \"\n          (click)=\"hide()\"\n        >\n          \u00D7\n        </button>\n      }\n    </header>\n  }\n  <ng-content />\n</section>\n", styles: [":host{position:relative;display:inline-block}.orc-popover__trigger{display:inline-flex;cursor:pointer}.orc-popover__trigger[hidden],.orc-popover[hidden]{display:none}.orc-popover{box-sizing:border-box;position:absolute;z-index:var(--z-popover, 1000);width:max-content;min-width:12rem;max-width:min(22rem,100vw - 16px);max-height:calc(100dvh - 16px);overflow:auto;padding:var(--space-4, 1rem);background:var(--orc-surface-raised, var(--orc-fill-modal, white));color:var(--orc-text, var(--text-primary, #141414));border:1px solid var(--orc-border-default, var(--border-default, #ddd));border-radius:var(--radius-md, .5rem);box-shadow:var(--shadow-lg, 0 12px 30px rgba(0, 0, 0, .1333333333))}.orc-popover__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3, .75rem);margin-bottom:var(--space-3, .75rem);font-weight:600}.orc-popover__close{margin-inline-start:auto;min-width:2rem;min-height:2rem;border:0;border-radius:var(--radius-sm, .25rem);background:transparent;color:inherit;font:inherit;font-size:1.25rem;cursor:pointer}.orc-popover__close:focus-visible,.orc-popover__trigger:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-popover{opacity:1;transition:opacity var(--orc-popover-transition, .15s ease),display var(--orc-popover-transition, .15s ease) allow-discrete}.orc-popover[hidden]{opacity:0}@starting-style{.orc-popover:not([hidden]){opacity:0}}@media(prefers-reduced-motion:reduce){.orc-popover{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PopoverComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-popover', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n  #trigger\n  class=\"orc-popover__trigger\"\n  (click)=\"onTriggerClick($event)\"\n  (keydown)=\"onTriggerKeydown($event)\"\n  ><ng-content select=\"[popover-trigger]\"\n/></span>\n<section\n  #panel\n  [id]=\"panelId()\"\n  [hidden]=\"!open()\"\n  [inert]=\"!open()\"\n  [attr.aria-hidden]=\"open() ? null : true\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  [class]=\"panelClassNames()\"\n  [style]=\"style()\"\n  [style.--orc-popover-transition]=\"\n    open() ? showTransitionOptions() : hideTransitionOptions()\n  \"\n  [style.z-index]=\"\n    autoZIndex() ? (baseZIndex() ? computedZIndex() : null) : baseZIndex()\n  \"\n  [attr.aria-label]=\"\n    ariaLabel() ||\n    label() ||\n    (!header() && !ariaLabelledBy() ? defaultLabel() : null)\n  \"\n  [attr.aria-labelledby]=\"\n    ariaLabelledBy() ||\n    (header() && !ariaLabel() && !label() ? panelId() + '-title' : null)\n  \"\n  [attr.aria-modal]=\"modal() || null\"\n  [attr.data-pc-name]=\"componentKind\"\n  (click)=\"onClick.emit($event)\"\n>\n  @if (header() || closable() || showCloseIcon()) {\n    <header class=\"orc-popover__header\">\n      @if (header()) {\n        <span [id]=\"panelId() + '-title'\">{{ header() }}</span>\n      }\n      @if (closable() || showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-popover__close close\"\n          [attr.aria-label]=\"\n            ariaCloseLabel() || closeLabel() || defaultCloseLabel()\n          \"\n          (click)=\"hide()\"\n        >\n          \u00D7\n        </button>\n      }\n    </header>\n  }\n  <ng-content />\n</section>\n", styles: [":host{position:relative;display:inline-block}.orc-popover__trigger{display:inline-flex;cursor:pointer}.orc-popover__trigger[hidden],.orc-popover[hidden]{display:none}.orc-popover{box-sizing:border-box;position:absolute;z-index:var(--z-popover, 1000);width:max-content;min-width:12rem;max-width:min(22rem,100vw - 16px);max-height:calc(100dvh - 16px);overflow:auto;padding:var(--space-4, 1rem);background:var(--orc-surface-raised, var(--orc-fill-modal, white));color:var(--orc-text, var(--text-primary, #141414));border:1px solid var(--orc-border-default, var(--border-default, #ddd));border-radius:var(--radius-md, .5rem);box-shadow:var(--shadow-lg, 0 12px 30px rgba(0, 0, 0, .1333333333))}.orc-popover__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3, .75rem);margin-bottom:var(--space-3, .75rem);font-weight:600}.orc-popover__close{margin-inline-start:auto;min-width:2rem;min-height:2rem;border:0;border-radius:var(--radius-sm, .25rem);background:transparent;color:inherit;font:inherit;font-size:1.25rem;cursor:pointer}.orc-popover__close:focus-visible,.orc-popover__trigger:focus-visible{outline:2px solid var(--orc-interactive, #2563eb);outline-offset:2px}.orc-popover{opacity:1;transition:opacity var(--orc-popover-transition, .15s ease),display var(--orc-popover-transition, .15s ease) allow-discrete}.orc-popover[hidden]{opacity:0}@starting-style{.orc-popover:not([hidden]){opacity:0}}@media(prefers-reduced-motion:reduce){.orc-popover{transition:none}}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { OverlayPanelComponent, PopoverComponent };
//# sourceMappingURL=ciag-orchestra-overlay-panel.mjs.map
