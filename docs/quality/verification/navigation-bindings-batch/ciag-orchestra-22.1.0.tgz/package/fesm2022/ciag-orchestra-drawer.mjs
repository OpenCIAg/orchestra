import * as i0 from '@angular/core';
import { model, input, booleanAttribute, output, viewChild, inject, DestroyRef, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { registerOverlay, focusInitialElement, isolateModalBackground, lockDocumentScroll, isTopOverlay, trapTabKey } from '@ciag/orchestra/internal';

class DrawerComponent {
    open = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    /** PrimeNG-compatible visibility alias. */
    visible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    placement = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    closeOnBackdrop = input(true, { ...(ngDevMode ? { debugName: "closeOnBackdrop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismissible = input(true, { ...(ngDevMode ? { debugName: "dismissible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    modal = input(true, { ...(ngDevMode ? { debugName: "modal" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    closable = input(true, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCloseIcon = input(true, { ...(ngDevMode ? { debugName: "showCloseIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeAriaLabel" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    baseZIndex = input(1000, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "baseZIndex" }] : /* istanbul ignore next */ []));
    closed = output();
    onShow = output();
    onHide = output();
    panel = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    backdrop = viewChild('backdrop', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "backdrop" }] : /* istanbul ignore next */ []));
    releaseIsolation;
    document = inject(DOCUMENT);
    destroyRef = inject(DestroyRef);
    previousOpen = false;
    previousVisible = false;
    constructor() {
        effect(() => {
            const open = this.open();
            const visible = this.visible();
            const next = open !== this.previousOpen
                ? open
                : visible !== this.previousVisible
                    ? visible
                    : open;
            this.previousOpen = next;
            this.previousVisible = next;
            if (open !== next)
                this.open.set(next);
            if (visible !== next)
                this.visible.set(next);
        });
        effect((onCleanup) => {
            const panel = this.panel()?.nativeElement;
            if (!this.open() || !panel)
                return;
            const previousFocus = this.document.activeElement;
            const releaseLayer = registerOverlay(panel, {
                onParentClose: () => {
                    this.close();
                    this.releaseIsolation?.();
                    this.releaseIsolation = undefined;
                },
            });
            const keydown = (event) => this.onKeydown(event);
            this.document.addEventListener('keydown', keydown);
            focusInitialElement(panel);
            this.onShow.emit();
            onCleanup(() => {
                this.document.removeEventListener('keydown', keydown);
                releaseLayer();
                this.releaseIsolation?.();
                this.releaseIsolation = undefined;
                if (previousFocus?.isConnected)
                    previousFocus.focus({ preventScroll: true });
                if (!this.destroyRef.destroyed)
                    this.onHide.emit();
            });
        });
        effect((onCleanup) => {
            const panel = this.panel()?.nativeElement;
            const backdrop = this.backdrop()?.nativeElement;
            if (this.open() && this.modal() && panel) {
                const release = isolateModalBackground(panel, backdrop ? [backdrop] : []);
                this.releaseIsolation = release;
                onCleanup(() => {
                    release();
                    if (this.releaseIsolation === release)
                        this.releaseIsolation = undefined;
                });
            }
        });
        effect((onCleanup) => {
            if (this.open() && this.modal())
                onCleanup(lockDocumentScroll(this.document));
        });
    }
    show() {
        this.open.set(true);
        this.visible.set(true);
    }
    close() {
        if (!this.open())
            return;
        this.open.set(false);
        this.visible.set(false);
        this.closed.emit();
    }
    onBackdrop() {
        const panel = this.panel()?.nativeElement;
        if (panel &&
            isTopOverlay(panel) &&
            this.dismissible() &&
            this.closeOnBackdrop())
            this.close();
    }
    onKeydown(event) {
        const panel = this.panel()?.nativeElement;
        if (!this.open() ||
            !panel ||
            !isTopOverlay(panel) ||
            event.defaultPrevented)
            return;
        if (event.key === 'Escape' && this.closeOnEscape()) {
            event.preventDefault();
            this.close();
        }
        else if (this.modal())
            trapTabKey(event, panel);
    }
    onEscape() {
        this.onKeydown(new KeyboardEvent('keydown', { key: 'Escape', cancelable: true }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DrawerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: DrawerComponent, isStandalone: true, selector: "orc-drawer, orc-sidebar", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdrop: { classPropertyName: "closeOnBackdrop", publicName: "closeOnBackdrop", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, modal: { classPropertyName: "modal", publicName: "modal", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, showCloseIcon: { classPropertyName: "showCloseIcon", publicName: "showCloseIcon", isSignal: true, isRequired: false, transformFunction: null }, closeAriaLabel: { classPropertyName: "closeAriaLabel", publicName: "closeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange", visible: "visibleChange", closed: "closed", onShow: "onShow", onHide: "onHide" }, viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }, { propertyName: "backdrop", first: true, predicate: ["backdrop"], descendants: true, isSignal: true }], ngImport: i0, template: "@if (open()) {\n  @if (modal()) {\n    <div\n      #backdrop\n      class=\"orc-drawer__backdrop p-drawer-mask\"\n      [style.z-index]=\"baseZIndex() - 1\"\n      (click)=\"onBackdrop()\"\n      aria-hidden=\"true\"\n    ></div>\n  }\n  <aside\n    #panel\n    tabindex=\"-1\"\n    [attr.id]=\"id() || null\"\n    class=\"orc-drawer p-drawer p-component\"\n    [class]=\"\n      'orc-drawer p-drawer p-component orc-drawer--' +\n      placement() +\n      ' ' +\n      styleClass()\n    \"\n    role=\"dialog\"\n    [attr.aria-modal]=\"modal()\"\n    [attr.aria-label]=\"\n      ariaLabel() || label() || (ariaLabelledBy() ? null : 'Drawer')\n    \"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n    [style]=\"style()\"\n    [style.z-index]=\"baseZIndex()\"\n  >\n    <div class=\"orc-drawer__header\">\n      <ng-content select=\"[drawer-title]\" />\n      @if (closable() && showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-drawer__close p-drawer-close-button\"\n          (click)=\"close()\"\n          [attr.aria-label]=\"closeAriaLabel() || 'Close drawer'\"\n        >\n          \u00D7\n        </button>\n      }\n    </div>\n    <div class=\"orc-drawer__body\"><ng-content /></div>\n    <div class=\"orc-drawer__footer\">\n      <ng-content select=\"[drawer-actions]\" />\n    </div>\n  </aside>\n}\n", styles: [":host{display:contents}.orc-drawer__backdrop{position:fixed;inset:0;z-index:var(--z-modal-backdrop);background:var(--orc-scrim, rgba(0, 0, 0, .52))}.orc-drawer{position:fixed;z-index:var(--z-modal);display:flex;flex-direction:column;max-width:100vw;max-height:100vh;background:var(--orc-surface-raised, var(--orc-fill-modal));color:var(--orc-text, var(--text-primary));border:1px solid var(--orc-border-default, var(--border-default));box-shadow:var(--orc-shadow-overlay, var(--shadow-lg))}.orc-drawer--left,.orc-drawer--right{top:0;bottom:0;width:min(26rem,92vw)}.orc-drawer--left{left:0}.orc-drawer--right{right:0}.orc-drawer--top,.orc-drawer--bottom{left:0;right:0;min-height:12rem;max-height:80vh}.orc-drawer--top{top:0}.orc-drawer--bottom{bottom:0}.orc-drawer__header,.orc-drawer__footer{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-4) var(--space-5);border-color:var(--orc-border-default, var(--border-default))}.orc-drawer__header{justify-content:space-between;border-bottom:1px solid var(--orc-border-default, var(--border-default))}.orc-drawer__footer{justify-content:flex-end;border-top:1px solid var(--orc-border-default, var(--border-default))}.orc-drawer__body{flex:1;overflow:auto;padding:var(--space-5)}.orc-drawer__close{border:0;background:transparent;color:var(--orc-text-secondary, var(--text-secondary));font:inherit;font-size:1.5rem;cursor:pointer;border-radius:var(--radius-sm)}.orc-drawer__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico));outline-offset:2px}@media(prefers-reduced-motion:no-preference){.orc-drawer{animation:orc-drawer-in var(--transition-base)}@keyframes orc-drawer-in{0%{opacity:0;transform:translate(1rem)}}}.orc-drawer{box-sizing:border-box;max-height:100dvh}.orc-drawer__body{min-height:0}.orc-drawer__footer:empty{display:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DrawerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-drawer, orc-sidebar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (open()) {\n  @if (modal()) {\n    <div\n      #backdrop\n      class=\"orc-drawer__backdrop p-drawer-mask\"\n      [style.z-index]=\"baseZIndex() - 1\"\n      (click)=\"onBackdrop()\"\n      aria-hidden=\"true\"\n    ></div>\n  }\n  <aside\n    #panel\n    tabindex=\"-1\"\n    [attr.id]=\"id() || null\"\n    class=\"orc-drawer p-drawer p-component\"\n    [class]=\"\n      'orc-drawer p-drawer p-component orc-drawer--' +\n      placement() +\n      ' ' +\n      styleClass()\n    \"\n    role=\"dialog\"\n    [attr.aria-modal]=\"modal()\"\n    [attr.aria-label]=\"\n      ariaLabel() || label() || (ariaLabelledBy() ? null : 'Drawer')\n    \"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n    [style]=\"style()\"\n    [style.z-index]=\"baseZIndex()\"\n  >\n    <div class=\"orc-drawer__header\">\n      <ng-content select=\"[drawer-title]\" />\n      @if (closable() && showCloseIcon()) {\n        <button\n          type=\"button\"\n          class=\"orc-drawer__close p-drawer-close-button\"\n          (click)=\"close()\"\n          [attr.aria-label]=\"closeAriaLabel() || 'Close drawer'\"\n        >\n          \u00D7\n        </button>\n      }\n    </div>\n    <div class=\"orc-drawer__body\"><ng-content /></div>\n    <div class=\"orc-drawer__footer\">\n      <ng-content select=\"[drawer-actions]\" />\n    </div>\n  </aside>\n}\n", styles: [":host{display:contents}.orc-drawer__backdrop{position:fixed;inset:0;z-index:var(--z-modal-backdrop);background:var(--orc-scrim, rgba(0, 0, 0, .52))}.orc-drawer{position:fixed;z-index:var(--z-modal);display:flex;flex-direction:column;max-width:100vw;max-height:100vh;background:var(--orc-surface-raised, var(--orc-fill-modal));color:var(--orc-text, var(--text-primary));border:1px solid var(--orc-border-default, var(--border-default));box-shadow:var(--orc-shadow-overlay, var(--shadow-lg))}.orc-drawer--left,.orc-drawer--right{top:0;bottom:0;width:min(26rem,92vw)}.orc-drawer--left{left:0}.orc-drawer--right{right:0}.orc-drawer--top,.orc-drawer--bottom{left:0;right:0;min-height:12rem;max-height:80vh}.orc-drawer--top{top:0}.orc-drawer--bottom{bottom:0}.orc-drawer__header,.orc-drawer__footer{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-4) var(--space-5);border-color:var(--orc-border-default, var(--border-default))}.orc-drawer__header{justify-content:space-between;border-bottom:1px solid var(--orc-border-default, var(--border-default))}.orc-drawer__footer{justify-content:flex-end;border-top:1px solid var(--orc-border-default, var(--border-default))}.orc-drawer__body{flex:1;overflow:auto;padding:var(--space-5)}.orc-drawer__close{border:0;background:transparent;color:var(--orc-text-secondary, var(--text-secondary));font:inherit;font-size:1.5rem;cursor:pointer;border-radius:var(--radius-sm)}.orc-drawer__close:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico));outline-offset:2px}@media(prefers-reduced-motion:no-preference){.orc-drawer{animation:orc-drawer-in var(--transition-base)}@keyframes orc-drawer-in{0%{opacity:0;transform:translate(1rem)}}}.orc-drawer{box-sizing:border-box;max-height:100dvh}.orc-drawer__body{min-height:0}.orc-drawer__footer:empty{display:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }], placement: [{ type: i0.Input, args: [{ isSignal: true, alias: "placement", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], closeOnBackdrop: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdrop", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], modal: [{ type: i0.Input, args: [{ isSignal: true, alias: "modal", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], showCloseIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCloseIcon", required: false }] }], closeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeAriaLabel", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], panel: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], backdrop: [{ type: i0.ViewChild, args: ['backdrop', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DrawerComponent };
//# sourceMappingURL=ciag-orchestra-drawer.mjs.map
