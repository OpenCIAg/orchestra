import * as i0 from '@angular/core';
import { inject, ElementRef, input, booleanAttribute, output, signal, computed, viewChild, HostListener, ChangeDetectionStrategy, Component } from '@angular/core';

class ScrollAreaComponent {
    host = inject((ElementRef));
    orientation = input('vertical', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    maxHeight = input('240px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxHeight" }] : /* istanbul ignore next */ []));
    maxWidth = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxWidth" }] : /* istanbul ignore next */ []));
    alwaysShowScrollbar = input(false, { ...(ngDevMode ? { debugName: "alwaysShowScrollbar" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    scrolled = output();
    canScrollBack = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canScrollBack" }] : /* istanbul ignore next */ []));
    canScrollForward = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canScrollForward" }] : /* istanbul ignore next */ []));
    viewportStyle = computed(() => ({ 'max-height': this.maxHeight() || null, 'max-width': this.maxWidth() || null }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewportStyle" }] : /* istanbul ignore next */ []));
    viewport = viewChild('viewport', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewport" }] : /* istanbul ignore next */ []));
    ngAfterViewInit() { this.measure(); }
    measure() { const target = this.viewport()?.nativeElement; if (!target)
        return; const verticalForward = target.scrollTop + target.clientHeight < target.scrollHeight - 1; const horizontalForward = target.scrollLeft + target.clientWidth < target.scrollWidth - 1; this.canScrollBack.set(this.orientation() === 'horizontal' ? target.scrollLeft > 0 : this.orientation() === 'both' ? target.scrollLeft > 0 || target.scrollTop > 0 : target.scrollTop > 0); this.canScrollForward.set(this.orientation() === 'horizontal' ? horizontalForward : this.orientation() === 'both' ? horizontalForward || verticalForward : verticalForward); }
    onScroll(event) {
        const target = event.target;
        const vertical = target.scrollTop > 0;
        const horizontal = target.scrollLeft > 0;
        const verticalForward = target.scrollTop + target.clientHeight < target.scrollHeight - 1;
        const horizontalForward = target.scrollLeft + target.clientWidth < target.scrollWidth - 1;
        this.canScrollBack.set(this.orientation() === 'horizontal' ? horizontal : this.orientation() === 'both' ? horizontal || vertical : vertical);
        this.canScrollForward.set(this.orientation() === 'horizontal' ? horizontalForward : this.orientation() === 'both' ? horizontalForward || verticalForward : verticalForward);
        this.scrolled.emit({ top: target.scrollTop, left: target.scrollLeft });
    }
    onKeydown(event) {
        const viewport = this.host.nativeElement.querySelector('.orc-scroll-area__viewport');
        if (!viewport)
            return;
        const horizontal = this.orientation() === 'horizontal';
        if (event.key === 'PageDown') {
            event.preventDefault();
            viewport.scrollBy(horizontal ? { left: viewport.clientWidth, behavior: 'smooth' } : { top: viewport.clientHeight, behavior: 'smooth' });
        }
        if (event.key === 'PageUp') {
            event.preventDefault();
            viewport.scrollBy(horizontal ? { left: -viewport.clientWidth, behavior: 'smooth' } : { top: -viewport.clientHeight, behavior: 'smooth' });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ScrollAreaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: ScrollAreaComponent, isStandalone: true, selector: "orc-scroll-area", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, maxHeight: { classPropertyName: "maxHeight", publicName: "maxHeight", isSignal: true, isRequired: false, transformFunction: null }, maxWidth: { classPropertyName: "maxWidth", publicName: "maxWidth", isSignal: true, isRequired: false, transformFunction: null }, alwaysShowScrollbar: { classPropertyName: "alwaysShowScrollbar", publicName: "alwaysShowScrollbar", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { scrolled: "scrolled" }, host: { listeners: { "keydown": "onKeydown($event)" } }, viewQueries: [{ propertyName: "viewport", first: true, predicate: ["viewport"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"orc-scroll-area\" [class.orc-scroll-area--horizontal]=\"orientation() === 'horizontal'\" [class.orc-scroll-area--both]=\"orientation() === 'both'\" [class.orc-scroll-area--always]=\"alwaysShowScrollbar()\" [attr.aria-label]=\"label() || null\">\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--top\" [class.orc-scroll-area__shadow--visible]=\"canScrollBack()\" aria-hidden=\"true\"></div>\n  <div #viewport class=\"orc-scroll-area__viewport\" [style]=\"viewportStyle()\" tabindex=\"0\" (scroll)=\"onScroll($event)\"><ng-content /></div>\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--bottom\" [class.orc-scroll-area__shadow--visible]=\"canScrollForward()\" aria-hidden=\"true\"></div>\n</div>\n", styles: [":host{display:block;min-width:0}.orc-scroll-area{position:relative;min-width:0}.orc-scroll-area__viewport{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:var(--orc-border-default, var(--border-default, #d9d9d9)) transparent;outline:none}.orc-scroll-area__viewport:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-scroll-area__viewport::-webkit-scrollbar{width:8px;height:8px}.orc-scroll-area__viewport::-webkit-scrollbar-thumb{border-radius:999px;background:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-scroll-area--horizontal .orc-scroll-area__viewport{overflow-x:auto;overflow-y:hidden;white-space:nowrap}.orc-scroll-area--both .orc-scroll-area__viewport{overflow:auto}.orc-scroll-area--always .orc-scroll-area__viewport{scrollbar-gutter:stable}.orc-scroll-area__shadow{position:absolute;z-index:1;right:8px;left:0;height:18px;pointer-events:none;opacity:0;transition:opacity .2s}.orc-scroll-area__shadow--top{top:0;background:linear-gradient(var(--orc-surface-raised, var(--fill-modal, #fff)),transparent)}.orc-scroll-area__shadow--bottom{bottom:0;background:linear-gradient(transparent,var(--orc-surface-raised, var(--fill-modal, #fff)))}.orc-scroll-area__shadow--visible{opacity:1}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ScrollAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-scroll-area', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-scroll-area\" [class.orc-scroll-area--horizontal]=\"orientation() === 'horizontal'\" [class.orc-scroll-area--both]=\"orientation() === 'both'\" [class.orc-scroll-area--always]=\"alwaysShowScrollbar()\" [attr.aria-label]=\"label() || null\">\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--top\" [class.orc-scroll-area__shadow--visible]=\"canScrollBack()\" aria-hidden=\"true\"></div>\n  <div #viewport class=\"orc-scroll-area__viewport\" [style]=\"viewportStyle()\" tabindex=\"0\" (scroll)=\"onScroll($event)\"><ng-content /></div>\n  <div class=\"orc-scroll-area__shadow orc-scroll-area__shadow--bottom\" [class.orc-scroll-area__shadow--visible]=\"canScrollForward()\" aria-hidden=\"true\"></div>\n</div>\n", styles: [":host{display:block;min-width:0}.orc-scroll-area{position:relative;min-width:0}.orc-scroll-area__viewport{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:var(--orc-border-default, var(--border-default, #d9d9d9)) transparent;outline:none}.orc-scroll-area__viewport:focus-visible{box-shadow:inset 0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-scroll-area__viewport::-webkit-scrollbar{width:8px;height:8px}.orc-scroll-area__viewport::-webkit-scrollbar-thumb{border-radius:999px;background:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-scroll-area--horizontal .orc-scroll-area__viewport{overflow-x:auto;overflow-y:hidden;white-space:nowrap}.orc-scroll-area--both .orc-scroll-area__viewport{overflow:auto}.orc-scroll-area--always .orc-scroll-area__viewport{scrollbar-gutter:stable}.orc-scroll-area__shadow{position:absolute;z-index:1;right:8px;left:0;height:18px;pointer-events:none;opacity:0;transition:opacity .2s}.orc-scroll-area__shadow--top{top:0;background:linear-gradient(var(--orc-surface-raised, var(--fill-modal, #fff)),transparent)}.orc-scroll-area__shadow--bottom{bottom:0;background:linear-gradient(transparent,var(--orc-surface-raised, var(--fill-modal, #fff)))}.orc-scroll-area__shadow--visible{opacity:1}\n"] }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], maxHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxHeight", required: false }] }], maxWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxWidth", required: false }] }], alwaysShowScrollbar: [{ type: i0.Input, args: [{ isSignal: true, alias: "alwaysShowScrollbar", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], scrolled: [{ type: i0.Output, args: ["scrolled"] }], viewport: [{ type: i0.ViewChild, args: ['viewport', { isSignal: true }] }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ScrollAreaComponent };
//# sourceMappingURL=ciag-orchestra-scroll-area.mjs.map
