import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, inject, ElementRef, ViewContainerRef, viewChild, signal, computed, effect, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { DOCUMENT } from '@angular/common';
import { registerOverlay, listenForOutsideInteraction, nativeModalFor } from '@ciag/orchestra/internal';

let nextDropdownId = 0;
class DropdownComponent {
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    placement = input('bottom-start', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placement" }] : /* istanbul ignore next */ []));
    /** PrimeNG Dropdown/Select-compatible form mode. Menu mode remains the default. */
    options = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    optionDisabled = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filter = input(false, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filterPlaceholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    filterAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterAriaLabel" }] : /* istanbul ignore next */ []));
    optionsAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionsAriaLabel" }] : /* istanbul ignore next */ []));
    loadingMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingMessage" }] : /* istanbul ignore next */ []));
    filterBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterBy" }] : /* istanbul ignore next */ []));
    scrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    resetFilterOnHide = input(true, { ...(ngDevMode ? { debugName: "resetFilterOnHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    itemSelect = output();
    onChange = output();
    onShow = output();
    onHide = output();
    onClear = output();
    onFocus = output();
    onBlur = output();
    filterChange = output();
    overlayRef = null;
    portal;
    hostEl = inject(ElementRef);
    document = inject(DOCUMENT);
    outsideCleanup;
    layerCleanup;
    focusTimer;
    returnFocus = null;
    viewContainerRef = inject(ViewContainerRef);
    overlay = inject(Overlay);
    dropdownPanel = viewChild('dropdownPanel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownPanel" }] : /* istanbul ignore next */ []));
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    visible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    filterValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    uniqueId = `orc-dropdown-${++nextDropdownId}`;
    effectiveId = computed(() => this.inputId() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    onModelChange = () => { };
    onTouched = () => { };
    formMode = computed(() => this.options() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formMode" }] : /* istanbul ignore next */ []));
    filteredOptions = computed(() => {
        const term = this.filterValue().trim().toLowerCase();
        const options = this.options() ?? [];
        if (!term)
            return options;
        const fields = this.filterBy()
            ?.split(',')
            .map((field) => field.trim())
            .filter(Boolean);
        return options.filter((option) => fields?.length
            ? fields.some((field) => String(this.readField(option, field) ?? '')
                .toLowerCase()
                .includes(term))
            : this.optionText(option).toLowerCase().includes(term));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []));
    selectedLabel = computed(() => {
        const selected = (this.options() ?? []).find((option) => this.optionValueOf(option) === this.value());
        return selected === undefined ? '' : this.optionText(selected);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const requested = this.visible();
            this.dropdownPanel();
            if (requested && !this.isOpen())
                this.open();
            if ((!requested || this.disabled() || this.cvaDisabled()) &&
                this.isOpen())
                this.close();
        });
    }
    ngAfterViewInit() {
        this.portal = new TemplatePortal(this.dropdownPanel(), this.viewContainerRef);
    }
    open() {
        if (this.isOpen() || this.disabled() || this.cvaDisabled())
            return;
        const template = this.dropdownPanel();
        if (!template)
            return;
        this.portal ??= new TemplatePortal(template, this.viewContainerRef);
        this.returnFocus = this.document.activeElement;
        const positionStrategy = this.createPositionStrategy();
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
            scrollStrategy: this.overlay.scrollStrategies.reposition(),
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        this.overlayRef.backdropClick().subscribe(() => this.close());
        this.overlayRef.keydownEvents().subscribe((event) => {
            if (event.key === 'Escape') {
                event.preventDefault();
                this.close(true);
                event.stopPropagation();
            }
        });
        this.overlayRef.attach(this.portal);
        this.isOpen.set(true);
        this.visible.set(true);
        this.onShow.emit();
        this.layerCleanup = registerOverlay(this.overlayRef.overlayElement, {
            anchor: this.hostEl.nativeElement,
            onParentClose: () => this.close(),
        });
        this.outsideCleanup = listenForOutsideInteraction(this.document, () => [this.hostEl.nativeElement, this.overlayRef?.overlayElement], () => this.close());
        this.focusTimer = setTimeout(() => {
            this.focusTimer = undefined;
            const panel = this.overlayRef?.overlayElement;
            (panel?.querySelector('input') ??
                panel?.querySelector('[aria-selected="true"]:not([disabled])') ??
                panel?.querySelector('[role="menuitem"]:not([disabled]), [role="option"]:not([disabled])'))?.focus();
        });
    }
    close(restoreFocus = false) {
        if (!this.isOpen())
            return;
        this.disposeOverlay();
        this.overlayRef = null;
        this.isOpen.set(false);
        this.visible.set(false);
        if (this.resetFilterOnHide())
            this.filterValue.set('');
        this.onTouched();
        this.onHide.emit();
        if (restoreFocus && this.returnFocus?.isConnected)
            this.returnFocus.focus();
    }
    toggle() {
        this.isOpen() ? this.close() : this.open();
    }
    onItemClick(item, $event) {
        if (item.disabled || this.disabled() || this.cvaDisabled()) {
            $event.stopPropagation();
            return;
        }
        if (item.children?.length) {
            return;
        }
        this.itemSelect.emit(item);
        item.action?.();
        this.close(true);
    }
    readField(option, path) {
        return path
            .split('.')
            .reduce((value, key) => value !== null && typeof value === 'object'
            ? value[key]
            : undefined, option);
    }
    optionText(option) {
        const key = this.optionLabel();
        return String(key
            ? (this.readField(option, key) ?? '')
            : (this.readField(option, 'label') ?? option ?? ''));
    }
    optionValueOf(option) {
        const key = this.optionValue();
        return key
            ? this.readField(option, key)
            : (this.readField(option, 'value') ?? option);
    }
    isOptionDisabled(option) {
        const rule = this.optionDisabled();
        return typeof rule === 'function'
            ? rule(option)
            : Boolean(this.readField(option, rule || 'disabled'));
    }
    selectOption(option, event) {
        if (this.disabled() ||
            this.cvaDisabled() ||
            this.loading() ||
            this.isOptionDisabled(option))
            return;
        const value = this.optionValueOf(option);
        this.value.set(value);
        this.onModelChange(value);
        this.onChange.emit({ originalEvent: event, value });
        this.close(true);
    }
    clearValue(event) {
        if (this.disabled() || this.cvaDisabled() || this.loading())
            return;
        this.onTouched();
        this.value.set(null);
        this.onModelChange(null);
        this.onChange.emit({ originalEvent: event, value: null });
        this.onClear.emit(event);
    }
    onFilterInput(event) {
        const value = event.target.value;
        this.filterValue.set(value);
        this.filterChange.emit(value);
    }
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) {
        this.cvaDisabled.set(disabled);
    }
    onItemKeydown(event) {
        const current = event.currentTarget;
        const menu = current.closest('[role="menu"], [role="listbox"]');
        const buttons = Array.from(menu?.querySelectorAll('[role="menuitem"]:not([disabled]), [role="option"]:not([disabled])') ?? []);
        const index = buttons.indexOf(current);
        if (!buttons.length || index < 0)
            return;
        const target = event.key === 'ArrowDown'
            ? buttons[(index + 1) % buttons.length]
            : event.key === 'ArrowUp'
                ? buttons[(index - 1 + buttons.length) % buttons.length]
                : event.key === 'Home'
                    ? buttons[0]
                    : event.key === 'End'
                        ? buttons[buttons.length - 1]
                        : undefined;
        if (target) {
            event.preventDefault();
            target.focus();
        }
    }
    createPositionStrategy() {
        const positions = this.getConnectedPositions();
        const modal = nativeModalFor(this.hostEl.nativeElement);
        return this.overlay
            .position()
            .flexibleConnectedTo(this.hostEl)
            .withPopoverLocation(modal ? { type: 'parent', element: modal } : 'global')
            .withPositions(positions)
            .withFlexibleDimensions(false)
            .withPush(true);
    }
    getConnectedPositions() {
        switch (this.placement()) {
            case 'bottom-end':
                return [
                    {
                        originX: 'end',
                        originY: 'bottom',
                        overlayX: 'end',
                        overlayY: 'top',
                    },
                ];
            case 'top-start':
                return [
                    {
                        originX: 'start',
                        originY: 'top',
                        overlayX: 'start',
                        overlayY: 'bottom',
                    },
                ];
            case 'top-end':
                return [
                    {
                        originX: 'end',
                        originY: 'top',
                        overlayX: 'end',
                        overlayY: 'bottom',
                    },
                ];
            default:
                return [
                    {
                        originX: 'start',
                        originY: 'bottom',
                        overlayX: 'start',
                        overlayY: 'top',
                    },
                ];
        }
    }
    onTriggerKeydown(event) {
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            this.open();
        }
    }
    onPanelKeydown(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            event.stopPropagation();
            this.close(true);
        }
        else if (event.key === 'Tab') {
            // Restore the trigger before default Tab advances to the next control.
            this.close(true);
        }
        else if (event.target.matches('input') &&
            event.key === 'ArrowDown') {
            event.preventDefault();
            this.overlayRef?.overlayElement
                .querySelector('[role="option"]:not([disabled])')
                ?.focus();
        }
    }
    disposeOverlay() {
        if (this.focusTimer !== undefined)
            clearTimeout(this.focusTimer);
        this.focusTimer = undefined;
        this.outsideCleanup?.();
        this.outsideCleanup = undefined;
        this.layerCleanup?.();
        this.layerCleanup = undefined;
        this.overlayRef?.dispose();
        this.overlayRef = null;
    }
    ngOnDestroy() {
        this.disposeOverlay();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: DropdownComponent, isStandalone: true, selector: "orc-dropdown", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, filterAriaLabel: { classPropertyName: "filterAriaLabel", publicName: "filterAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, optionsAriaLabel: { classPropertyName: "optionsAriaLabel", publicName: "optionsAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, loadingMessage: { classPropertyName: "loadingMessage", publicName: "loadingMessage", isSignal: true, isRequired: false, transformFunction: null }, filterBy: { classPropertyName: "filterBy", publicName: "filterBy", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, resetFilterOnHide: { classPropertyName: "resetFilterOnHide", publicName: "resetFilterOnHide", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", itemSelect: "itemSelect", onChange: "onChange", onShow: "onShow", onHide: "onHide", onClear: "onClear", onFocus: "onFocus", onBlur: "onBlur", filterChange: "filterChange", visible: "visibleChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => DropdownComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "dropdownPanel", first: true, predicate: ["dropdownPanel"], descendants: true, isSignal: true }], ngImport: i0, template: "@if (formMode()) {\n  <div\n    class=\"p-select p-component orc-dropdown-field\"\n    [class]=\"'p-select p-component orc-dropdown-field ' + styleClass()\"\n    [style]=\"style()\"\n    [class.is-disabled]=\"disabled() || cvaDisabled()\"\n    [attr.data-pc-name]=\"'select'\"\n  >\n    @if (label()) {\n      <label class=\"orc-dropdown-label\" [for]=\"effectiveId()\">{{\n        label()\n      }}</label>\n    }\n    <button\n      type=\"button\"\n      class=\"p-select-label p-select-trigger orc-dropdown-trigger\"\n      [id]=\"effectiveId()\"\n      [disabled]=\"disabled() || cvaDisabled()\"\n      [attr.aria-expanded]=\"isOpen()\"\n      aria-haspopup=\"listbox\"\n      [attr.aria-controls]=\"isOpen() ? effectiveId() + '-options' : null\"\n      (click)=\"toggle()\"\n      (keydown)=\"onTriggerKeydown($event)\"\n      (focus)=\"onFocus.emit($event)\"\n      (blur)=\"onTouched(); onBlur.emit($event)\"\n    >\n      <span>{{ selectedLabel() || placeholder() }}</span>\n      <span aria-hidden=\"true\">\u2304</span>\n    </button>\n    @if (showClear() && value() !== null && value() !== undefined) {\n      <button\n        type=\"button\"\n        class=\"orc-dropdown-clear\"\n        [disabled]=\"disabled() || cvaDisabled() || loading()\"\n        [attr.aria-label]=\"clearAriaLabel() || 'Clear selection'\"\n        (click)=\"clearValue($event)\"\n      >\n        \u00D7\n      </button>\n    }\n  </div>\n} @else {\n  <ng-content></ng-content>\n}\n\n<ng-template #dropdownPanel>\n  <div\n    class=\"p-select-overlay p-component orc-dropdown-menu\"\n    [id]=\"effectiveId() + '-panel'\"\n    [style.max-height]=\"scrollHeight()\"\n    [attr.role]=\"formMode() ? null : 'menu'\"\n    [attr.aria-label]=\"formMode() ? null : label() || 'Actions'\"\n    (keydown)=\"onPanelKeydown($event)\"\n  >\n    @if (formMode()) {\n      @if (filter()) {\n        <input\n          class=\"p-select-filter\"\n          type=\"search\"\n          [attr.placeholder]=\"filterPlaceholder() || null\"\n          [value]=\"filterValue()\"\n          (input)=\"onFilterInput($event)\"\n          [attr.aria-label]=\"filterAriaLabel() || 'Filter options'\"\n        />\n      }\n      @if (loading() && loadingMessage()) {\n        <div role=\"status\">{{ loadingMessage() }}</div>\n      }\n      <div\n        role=\"listbox\"\n        [id]=\"effectiveId() + '-options'\"\n        [attr.aria-label]=\"optionsAriaLabel() || label() || 'Options'\"\n        [attr.aria-busy]=\"loading()\"\n      >\n        @for (option of filteredOptions(); track optionValueOf(option)) {\n          <button\n            type=\"button\"\n            role=\"option\"\n            class=\"orc-dropdown-item\"\n            [disabled]=\"loading() || isOptionDisabled(option)\"\n            [attr.aria-selected]=\"optionValueOf(option) === value()\"\n            (click)=\"selectOption(option, $event)\"\n            (keydown)=\"onItemKeydown($event)\"\n          >\n            {{ optionText(option) }}\n          </button>\n        } @empty {\n          @if (!loading() && emptyMessage()) {\n            <div role=\"status\">{{ emptyMessage() }}</div>\n          }\n        }\n      </div>\n    } @else {\n      @for (item of items(); track item.id || item.label) {\n        @if (item.divider) {\n          <div class=\"orc-dropdown-divider\" role=\"separator\"></div>\n        } @else {\n          <button\n            type=\"button\"\n            class=\"orc-dropdown-item\"\n            [class.orc-dropdown-item--danger]=\"item.danger\"\n            [class.orc-dropdown-item--disabled]=\"item.disabled\"\n            [disabled]=\"item.disabled\"\n            role=\"menuitem\"\n            (click)=\"onItemClick(item, $event)\"\n            (keydown)=\"onItemKeydown($event)\"\n          >\n            @if (item.icon) {\n              <span\n                class=\"orc-dropdown-item__icon\"\n                [innerHTML]=\"item.icon\"\n              ></span>\n            }\n            <span class=\"orc-dropdown-item__label\">{{ item.label }}</span>\n            @if (item.shortcut) {\n              <span class=\"orc-dropdown-item__shortcut\">{{\n                item.shortcut\n              }}</span>\n            }\n          </button>\n        }\n      }\n    }\n  </div>\n</ng-template>\n", styles: [":host{display:inline-block}.orc-dropdown-menu{display:flex;flex-direction:column;min-width:180px;background-color:var(--orc-bg);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-1);z-index:var(--z-dropdown);overflow:auto;box-sizing:border-box}.orc-dropdown-item{display:flex;align-items:center;gap:var(--space-2);width:100%;padding:var(--space-2) var(--space-3);font-family:var(--font-sans);font-size:.875rem;color:var(--text-primary);background:transparent;border:none;border-radius:var(--radius-sm);cursor:pointer;text-align:left;transition:background-color var(--transition-fast),color var(--transition-fast)}.orc-dropdown-item:hover:not(:disabled){background-color:var(--bg-muted)}.orc-dropdown-item--danger{color:var(--color-error)}.orc-dropdown-item--danger:hover:not(:disabled){background-color:color-mix(in srgb,var(--orc-danger, var(--color-error, #fb2c36)) 10%,transparent)}.orc-dropdown-item--disabled,.orc-dropdown-item:disabled{opacity:.5;cursor:not-allowed}.orc-dropdown-item__icon{display:flex;align-items:center;justify-content:center;width:16px;height:16px}.orc-dropdown-item__label{flex:1}.orc-dropdown-item__shortcut{font-size:.75rem;color:var(--text-muted);font-family:var(--font-mono)}.orc-dropdown-divider{height:1px;margin:var(--space-1) 0;background-color:var(--border-default)}.orc-dropdown-field{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-2, .5rem)}.orc-dropdown-label{flex-basis:100%}.orc-dropdown-trigger{display:inline-flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem);min-height:2.5rem;padding:var(--space-2, .5rem) var(--space-3, .75rem);border:1px solid var(--orc-border-default, #888);border-radius:var(--radius-md, .375rem);background:var(--orc-surface, white);color:var(--orc-text, #141414);font:inherit;cursor:pointer}.orc-dropdown-clear{min-width:2rem;min-height:2rem;background:transparent;border:0;color:inherit;cursor:pointer}.orc-dropdown-trigger:disabled,.orc-dropdown-clear:disabled{cursor:not-allowed;opacity:.6}.orc-dropdown-trigger:focus-visible,.orc-dropdown-clear:focus-visible,.orc-dropdown-item:focus-visible,.p-select-filter:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:2px}.p-select-filter{box-sizing:border-box;width:100%;padding:var(--space-2, .5rem)}@media(prefers-reduced-motion:reduce){.orc-dropdown-item{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-dropdown', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DropdownComponent),
                            multi: true,
                        },
                    ], template: "@if (formMode()) {\n  <div\n    class=\"p-select p-component orc-dropdown-field\"\n    [class]=\"'p-select p-component orc-dropdown-field ' + styleClass()\"\n    [style]=\"style()\"\n    [class.is-disabled]=\"disabled() || cvaDisabled()\"\n    [attr.data-pc-name]=\"'select'\"\n  >\n    @if (label()) {\n      <label class=\"orc-dropdown-label\" [for]=\"effectiveId()\">{{\n        label()\n      }}</label>\n    }\n    <button\n      type=\"button\"\n      class=\"p-select-label p-select-trigger orc-dropdown-trigger\"\n      [id]=\"effectiveId()\"\n      [disabled]=\"disabled() || cvaDisabled()\"\n      [attr.aria-expanded]=\"isOpen()\"\n      aria-haspopup=\"listbox\"\n      [attr.aria-controls]=\"isOpen() ? effectiveId() + '-options' : null\"\n      (click)=\"toggle()\"\n      (keydown)=\"onTriggerKeydown($event)\"\n      (focus)=\"onFocus.emit($event)\"\n      (blur)=\"onTouched(); onBlur.emit($event)\"\n    >\n      <span>{{ selectedLabel() || placeholder() }}</span>\n      <span aria-hidden=\"true\">\u2304</span>\n    </button>\n    @if (showClear() && value() !== null && value() !== undefined) {\n      <button\n        type=\"button\"\n        class=\"orc-dropdown-clear\"\n        [disabled]=\"disabled() || cvaDisabled() || loading()\"\n        [attr.aria-label]=\"clearAriaLabel() || 'Clear selection'\"\n        (click)=\"clearValue($event)\"\n      >\n        \u00D7\n      </button>\n    }\n  </div>\n} @else {\n  <ng-content></ng-content>\n}\n\n<ng-template #dropdownPanel>\n  <div\n    class=\"p-select-overlay p-component orc-dropdown-menu\"\n    [id]=\"effectiveId() + '-panel'\"\n    [style.max-height]=\"scrollHeight()\"\n    [attr.role]=\"formMode() ? null : 'menu'\"\n    [attr.aria-label]=\"formMode() ? null : label() || 'Actions'\"\n    (keydown)=\"onPanelKeydown($event)\"\n  >\n    @if (formMode()) {\n      @if (filter()) {\n        <input\n          class=\"p-select-filter\"\n          type=\"search\"\n          [attr.placeholder]=\"filterPlaceholder() || null\"\n          [value]=\"filterValue()\"\n          (input)=\"onFilterInput($event)\"\n          [attr.aria-label]=\"filterAriaLabel() || 'Filter options'\"\n        />\n      }\n      @if (loading() && loadingMessage()) {\n        <div role=\"status\">{{ loadingMessage() }}</div>\n      }\n      <div\n        role=\"listbox\"\n        [id]=\"effectiveId() + '-options'\"\n        [attr.aria-label]=\"optionsAriaLabel() || label() || 'Options'\"\n        [attr.aria-busy]=\"loading()\"\n      >\n        @for (option of filteredOptions(); track optionValueOf(option)) {\n          <button\n            type=\"button\"\n            role=\"option\"\n            class=\"orc-dropdown-item\"\n            [disabled]=\"loading() || isOptionDisabled(option)\"\n            [attr.aria-selected]=\"optionValueOf(option) === value()\"\n            (click)=\"selectOption(option, $event)\"\n            (keydown)=\"onItemKeydown($event)\"\n          >\n            {{ optionText(option) }}\n          </button>\n        } @empty {\n          @if (!loading() && emptyMessage()) {\n            <div role=\"status\">{{ emptyMessage() }}</div>\n          }\n        }\n      </div>\n    } @else {\n      @for (item of items(); track item.id || item.label) {\n        @if (item.divider) {\n          <div class=\"orc-dropdown-divider\" role=\"separator\"></div>\n        } @else {\n          <button\n            type=\"button\"\n            class=\"orc-dropdown-item\"\n            [class.orc-dropdown-item--danger]=\"item.danger\"\n            [class.orc-dropdown-item--disabled]=\"item.disabled\"\n            [disabled]=\"item.disabled\"\n            role=\"menuitem\"\n            (click)=\"onItemClick(item, $event)\"\n            (keydown)=\"onItemKeydown($event)\"\n          >\n            @if (item.icon) {\n              <span\n                class=\"orc-dropdown-item__icon\"\n                [innerHTML]=\"item.icon\"\n              ></span>\n            }\n            <span class=\"orc-dropdown-item__label\">{{ item.label }}</span>\n            @if (item.shortcut) {\n              <span class=\"orc-dropdown-item__shortcut\">{{\n                item.shortcut\n              }}</span>\n            }\n          </button>\n        }\n      }\n    }\n  </div>\n</ng-template>\n", styles: [":host{display:inline-block}.orc-dropdown-menu{display:flex;flex-direction:column;min-width:180px;background-color:var(--orc-bg);border:1px solid var(--border-default);border-radius:var(--radius-md);box-shadow:var(--shadow-md);padding:var(--space-1);z-index:var(--z-dropdown);overflow:auto;box-sizing:border-box}.orc-dropdown-item{display:flex;align-items:center;gap:var(--space-2);width:100%;padding:var(--space-2) var(--space-3);font-family:var(--font-sans);font-size:.875rem;color:var(--text-primary);background:transparent;border:none;border-radius:var(--radius-sm);cursor:pointer;text-align:left;transition:background-color var(--transition-fast),color var(--transition-fast)}.orc-dropdown-item:hover:not(:disabled){background-color:var(--bg-muted)}.orc-dropdown-item--danger{color:var(--color-error)}.orc-dropdown-item--danger:hover:not(:disabled){background-color:color-mix(in srgb,var(--orc-danger, var(--color-error, #fb2c36)) 10%,transparent)}.orc-dropdown-item--disabled,.orc-dropdown-item:disabled{opacity:.5;cursor:not-allowed}.orc-dropdown-item__icon{display:flex;align-items:center;justify-content:center;width:16px;height:16px}.orc-dropdown-item__label{flex:1}.orc-dropdown-item__shortcut{font-size:.75rem;color:var(--text-muted);font-family:var(--font-mono)}.orc-dropdown-divider{height:1px;margin:var(--space-1) 0;background-color:var(--border-default)}.orc-dropdown-field{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:var(--space-2, .5rem)}.orc-dropdown-label{flex-basis:100%}.orc-dropdown-trigger{display:inline-flex;align-items:center;justify-content:space-between;gap:var(--space-2, .5rem);min-height:2.5rem;padding:var(--space-2, .5rem) var(--space-3, .75rem);border:1px solid var(--orc-border-default, #888);border-radius:var(--radius-md, .375rem);background:var(--orc-surface, white);color:var(--orc-text, #141414);font:inherit;cursor:pointer}.orc-dropdown-clear{min-width:2rem;min-height:2rem;background:transparent;border:0;color:inherit;cursor:pointer}.orc-dropdown-trigger:disabled,.orc-dropdown-clear:disabled{cursor:not-allowed;opacity:.6}.orc-dropdown-trigger:focus-visible,.orc-dropdown-clear:focus-visible,.orc-dropdown-item:focus-visible,.p-select-filter:focus-visible{outline:2px solid var(--orc-interactive, #1c6aed);outline-offset:2px}.p-select-filter{box-sizing:border-box;width:100%;padding:var(--space-2, .5rem)}@media(prefers-reduced-motion:reduce){.orc-dropdown-item{transition:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], placement: [{ type: i0.Input, args: [{ isSignal: true, alias: "placement", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], filterAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterAriaLabel", required: false }] }], optionsAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionsAriaLabel", required: false }] }], loadingMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingMessage", required: false }] }], filterBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterBy", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], resetFilterOnHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetFilterOnHide", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], itemSelect: [{ type: i0.Output, args: ["itemSelect"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], filterChange: [{ type: i0.Output, args: ["filterChange"] }], dropdownPanel: [{ type: i0.ViewChild, args: ['dropdownPanel', { isSignal: true }] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DropdownComponent };
//# sourceMappingURL=ciag-orchestra-dropdown.mjs.map
