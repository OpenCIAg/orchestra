export * from '@ciag/orchestra/dynamic-dialog';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-dynamicdialog.mjs.map
