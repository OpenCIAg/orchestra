export * from '@ciag/orchestra/input-textarea';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-inputtextarea.mjs.map
