export { ModalComponent as Dialog, ModalComponent as DialogComponent, ModalRef as DialogRef, ModalService as DialogService } from '@ciag/orchestra/modal';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-dialog.mjs.map
