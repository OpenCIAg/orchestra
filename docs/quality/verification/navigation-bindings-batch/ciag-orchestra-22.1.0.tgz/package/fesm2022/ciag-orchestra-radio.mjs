import * as i0 from '@angular/core';
import { InjectionToken, input, booleanAttribute, output, viewChild, inject, computed, signal, ChangeDetectionStrategy, Component, model, forwardRef } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const ORC_RADIO_GROUP = new InjectionToken('ORC_RADIO_GROUP');

let nextUniqueId = 0;
class RadioButtonComponent {
    // Inputs (Signals API)
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    description = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    error = input(false, { ...(ngDevMode ? { debugName: "error" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    binary = input(false, { ...(ngDevMode ? { debugName: "binary" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    // Outputs (Signals API)
    select = output();
    onClick = output();
    onFocus = output();
    onBlur = output();
    // Element reference ao input nativo para foco acessível
    inputElement = viewChild('nativeInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    // ID interno único
    uniqueId = `orc-radio-${++nextUniqueId}`;
    // Injeção desacoplada via InjectionToken
    radioGroup = inject(ORC_RADIO_GROUP, { optional: true });
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    effectiveName = computed(() => {
        if (this.name())
            return this.name();
        if (this.radioGroup)
            return this.radioGroup.name();
        return this.uniqueId;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveName" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => {
        return this.disabled() || (this.radioGroup ? this.radioGroup.isDisabled() : false);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isError = computed(() => {
        return this.error() || (this.radioGroup ? this.radioGroup.isError() : false);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isError" }] : /* istanbul ignore next */ []));
    standaloneChecked = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "standaloneChecked" }] : /* istanbul ignore next */ []));
    isChecked = computed(() => {
        if (this.radioGroup) {
            return this.radioGroup.value() === this.value();
        }
        return this.checked() ?? this.standaloneChecked();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isChecked" }] : /* istanbul ignore next */ []));
    checked = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    // Roving tabindex para acessibilidade WCAG
    tabIndex = computed(() => {
        if (this.isDisabled())
            return -1;
        if (!this.radioGroup)
            return 0;
        if (this.isChecked())
            return 0;
        if (!this.radioGroup.hasSelectedRadio() && this.radioGroup.isFirstEnabled(this)) {
            return 0;
        }
        return -1;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabIndex" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        if (this.radioGroup) {
            this.radioGroup.registerRadio(this);
        }
    }
    ngOnDestroy() {
        if (this.radioGroup) {
            this.radioGroup.unregisterRadio(this);
        }
    }
    onSelect(event) {
        if (this.isDisabled()) {
            event?.preventDefault();
            return;
        }
        if (this.radioGroup) {
            this.radioGroup.select(this.value(), event);
        }
        else {
            this.standaloneChecked.set(true);
            this.checked.set(true);
        }
        this.select.emit(this.value());
        this.onClick.emit({ originalEvent: event, value: this.binary() ? true : this.value() });
    }
    onKeyDown(event) {
        if (this.radioGroup) {
            this.radioGroup.handleKeydown(event, this);
        }
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    onFocusEvent(event) { this.onFocus.emit(event); }
    onBlurEvent(event) { this.onBlur.emit(event); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: RadioButtonComponent, isStandalone: true, selector: "orc-radio-button", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, binary: { classPropertyName: "binary", publicName: "binary", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { select: "select", onClick: "onClick", onFocus: "onFocus", onBlur: "onBlur" }, viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["nativeInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<label\n  class=\"p-radiobutton p-component orc-radio\"\n  [class.orc-radio--checked]=\"isChecked()\"\n  [class.orc-radio--disabled]=\"isDisabled()\"\n  [class.orc-radio--error]=\"isError()\"\n  [class.orc-radio--filled]=\"variant() === 'filled'\"\n  [class.orc-radio--small]=\"size() === 'small'\"\n  [class.orc-radio--large]=\"size() === 'large'\"\n  [class.p-radiobutton-checked]=\"isChecked()\"\n  [class.p-radiobutton-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'radiobutton'\"\n  [attr.for]=\"effectiveId()\"\n>\n  <!-- Visually hidden native radio input for complete a11y and form integration -->\n  <input\n    #nativeInput\n    type=\"radio\"\n    class=\"p-radiobutton-input orc-radio__native-input\"\n    [id]=\"effectiveId()\"\n  [name]=\"effectiveName()\"\n  [value]=\"value()\"\n  [checked]=\"isChecked()\"\n  [disabled]=\"isDisabled()\"\n  [tabindex]=\"tabindex() ?? tabIndex()\"\n  [autofocus]=\"autofocus()\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n  [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n    [attr.aria-checked]=\"isChecked()\"\n    [attr.aria-disabled]=\"isDisabled()\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onSelect($event)\"\n    (focus)=\"onFocusEvent($event)\"\n    (blur)=\"onBlurEvent($event)\"\n    (keydown)=\"onKeyDown($event)\"\n  />\n\n  <!-- Visual Custom Radio matching Figma 32:18402 -->\n  <span class=\"p-radiobutton-box orc-radio__box\" aria-hidden=\"true\">\n    <span class=\"orc-radio__circle\">\n      <span class=\"orc-radio__dot\"></span>\n    </span>\n  </span>\n\n  <!-- Label and Description -->\n  <span class=\"orc-radio__content\" *ngIf=\"label() || description()\">\n    <span class=\"orc-radio__label\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-radio__description\" *ngIf=\"description()\">\n      {{ description() }}\n    </span>\n  </span>\n  <span class=\"orc-radio__content\" *ngIf=\"!label() && !description()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-radio{display:inline-flex;align-items:flex-start;gap:var(--space-2, .5rem);position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.4}.orc-radio__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-radio__box{display:flex;align-items:center;justify-content:center;width:24px;height:24px;flex-shrink:0;position:relative;border-radius:var(--radius-full, 9999px);transition:background-color var(--transition-fast, .12s ease)}.orc-radio__circle{display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:var(--radius-full, 9999px);border:2px solid var(--orc-border-strong, #58595b);background-color:transparent;transition:border-color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease);position:relative;box-sizing:border-box}.orc-radio__dot{width:10px;height:10px;border-radius:var(--radius-full, 9999px);background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));transform:scale(0);opacity:0;transition:transform var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease)}.orc-radio__content{display:flex;flex-direction:column;padding-top:1.5px}.orc-radio__label{font-size:.875rem;font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));line-height:1.45;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-radio__description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));line-height:1.4;margin-top:2px}.orc-radio:hover:not(.orc-radio--disabled) .orc-radio__circle{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-radio .orc-radio__native-input:focus-visible+.orc-radio__box{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-radio--checked .orc-radio__circle{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-radio--checked .orc-radio__dot{transform:scale(1);opacity:1}.orc-radio--checked .orc-radio__label{font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-radio--error .orc-radio__circle{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-radio--error .orc-radio__dot{background-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-radio--error .orc-radio__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-radio--error .orc-radio__native-input:focus-visible+.orc-radio__box{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-radio--disabled{cursor:not-allowed;opacity:.45}.orc-radio--disabled .orc-radio__circle{border-color:var(--orc-border-default, var(--orc-border, #d9d9d9));background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.orc-radio--disabled .orc-radio__dot{background-color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-radio--disabled .orc-radio__label,.orc-radio--disabled .orc-radio__description{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-radio-button', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<label\n  class=\"p-radiobutton p-component orc-radio\"\n  [class.orc-radio--checked]=\"isChecked()\"\n  [class.orc-radio--disabled]=\"isDisabled()\"\n  [class.orc-radio--error]=\"isError()\"\n  [class.orc-radio--filled]=\"variant() === 'filled'\"\n  [class.orc-radio--small]=\"size() === 'small'\"\n  [class.orc-radio--large]=\"size() === 'large'\"\n  [class.p-radiobutton-checked]=\"isChecked()\"\n  [class.p-radiobutton-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'radiobutton'\"\n  [attr.for]=\"effectiveId()\"\n>\n  <!-- Visually hidden native radio input for complete a11y and form integration -->\n  <input\n    #nativeInput\n    type=\"radio\"\n    class=\"p-radiobutton-input orc-radio__native-input\"\n    [id]=\"effectiveId()\"\n  [name]=\"effectiveName()\"\n  [value]=\"value()\"\n  [checked]=\"isChecked()\"\n  [disabled]=\"isDisabled()\"\n  [tabindex]=\"tabindex() ?? tabIndex()\"\n  [autofocus]=\"autofocus()\"\n  [attr.aria-label]=\"ariaLabel() || null\"\n  [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n    [attr.aria-checked]=\"isChecked()\"\n    [attr.aria-disabled]=\"isDisabled()\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onSelect($event)\"\n    (focus)=\"onFocusEvent($event)\"\n    (blur)=\"onBlurEvent($event)\"\n    (keydown)=\"onKeyDown($event)\"\n  />\n\n  <!-- Visual Custom Radio matching Figma 32:18402 -->\n  <span class=\"p-radiobutton-box orc-radio__box\" aria-hidden=\"true\">\n    <span class=\"orc-radio__circle\">\n      <span class=\"orc-radio__dot\"></span>\n    </span>\n  </span>\n\n  <!-- Label and Description -->\n  <span class=\"orc-radio__content\" *ngIf=\"label() || description()\">\n    <span class=\"orc-radio__label\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-radio__description\" *ngIf=\"description()\">\n      {{ description() }}\n    </span>\n  </span>\n  <span class=\"orc-radio__content\" *ngIf=\"!label() && !description()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-radio{display:inline-flex;align-items:flex-start;gap:var(--space-2, .5rem);position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.4}.orc-radio__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-radio__box{display:flex;align-items:center;justify-content:center;width:24px;height:24px;flex-shrink:0;position:relative;border-radius:var(--radius-full, 9999px);transition:background-color var(--transition-fast, .12s ease)}.orc-radio__circle{display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:var(--radius-full, 9999px);border:2px solid var(--orc-border-strong, #58595b);background-color:transparent;transition:border-color var(--transition-fast, .12s ease),background-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease);position:relative;box-sizing:border-box}.orc-radio__dot{width:10px;height:10px;border-radius:var(--radius-full, 9999px);background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));transform:scale(0);opacity:0;transition:transform var(--transition-fast, .12s ease),opacity var(--transition-fast, .12s ease)}.orc-radio__content{display:flex;flex-direction:column;padding-top:1.5px}.orc-radio__label{font-size:.875rem;font-weight:400;color:var(--orc-text, var(--orc-font-main, #141414));line-height:1.45;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-radio__description{font-size:.75rem;color:var(--orc-text-secondary, var(--orc-font-secondary, #666666));line-height:1.4;margin-top:2px}.orc-radio:hover:not(.orc-radio--disabled) .orc-radio__circle{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-radio .orc-radio__native-input:focus-visible+.orc-radio__box{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-radio--checked .orc-radio__circle{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-radio--checked .orc-radio__dot{transform:scale(1);opacity:1}.orc-radio--checked .orc-radio__label{font-weight:500;color:var(--orc-text, var(--orc-font-main, #141414))}.orc-radio--error .orc-radio__circle{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-radio--error .orc-radio__dot{background-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-radio--error .orc-radio__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-radio--error .orc-radio__native-input:focus-visible+.orc-radio__box{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-radio--disabled{cursor:not-allowed;opacity:.45}.orc-radio--disabled .orc-radio__circle{border-color:var(--orc-border-default, var(--orc-border, #d9d9d9));background-color:var(--orc-surface-muted, var(--orc-highlight-cinza-claro, #ededed))}.orc-radio--disabled .orc-radio__dot{background-color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}.orc-radio--disabled .orc-radio__label,.orc-radio--disabled .orc-radio__description{color:var(--orc-text-secondary, var(--orc-font-secondary, #666666))}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], binary: [{ type: i0.Input, args: [{ isSignal: true, alias: "binary", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], select: [{ type: i0.Output, args: ["select"] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], inputElement: [{ type: i0.ViewChild, args: ['nativeInput', { isSignal: true }] }] } });

let nextGroupUniqueId = 0;
class RadioGroupComponent {
    // Inputs (Signals API)
    name = input(`orc-radio-group-${++nextGroupUniqueId}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    layout = input('vertical', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    error = input(false, { ...(ngDevMode ? { debugName: "error" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    hint = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    // Model & Outputs (Signals API)
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    onChange = output();
    // Estado interno
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    radios = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "radios" }] : /* istanbul ignore next */ []));
    // Identificadores de acessibilidade
    groupId = `orc-radio-group-${nextGroupUniqueId}`;
    labelId = `${this.groupId}-label`;
    hintId = `${this.groupId}-hint`;
    errorId = `${this.groupId}-error`;
    isDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isError = computed(() => this.error() || !!this.errorMessage(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isError" }] : /* istanbul ignore next */ []));
    // Callbacks do ControlValueAccessor
    onModelChange = () => { };
    onTouched = () => { };
    writeValue(val) {
        this.value.set(val);
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    registerRadio(radio) {
        this.radios.update((list) => [...list, radio]);
    }
    unregisterRadio(radio) {
        this.radios.update((list) => list.filter((r) => r !== radio));
    }
    select(val, originalEvent) {
        if (this.isDisabled())
            return;
        if (this.value() !== val) {
            this.value.set(val);
            this.onModelChange(val);
            this.onChange.emit({ originalEvent, value: val });
        }
        this.onTouched();
    }
    hasSelectedRadio() {
        const currentVal = this.value();
        return this.radios().some((r) => r.value() === currentVal);
    }
    isFirstEnabled(radio) {
        const enabledRadios = this.radios().filter((r) => !r.isDisabled());
        return enabledRadios.length > 0 && enabledRadios[0] === radio;
    }
    // Navegação WCAG por setas do teclado
    handleKeydown(event, currentRadio) {
        const enabledRadios = this.radios().filter((r) => !r.isDisabled());
        if (enabledRadios.length <= 1)
            return;
        const currentIndex = enabledRadios.indexOf(currentRadio);
        if (currentIndex === -1)
            return;
        let nextIndex = -1;
        switch (event.key) {
            case 'ArrowDown':
            case 'ArrowRight':
                nextIndex = (currentIndex + 1) % enabledRadios.length;
                break;
            case 'ArrowUp':
            case 'ArrowLeft':
                nextIndex = (currentIndex - 1 + enabledRadios.length) % enabledRadios.length;
                break;
            default:
                return;
        }
        event.preventDefault();
        const targetRadio = enabledRadios[nextIndex];
        if (targetRadio) {
            this.select(targetRadio.value());
            targetRadio.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: RadioGroupComponent, isStandalone: true, selector: "orc-radio-group", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", onChange: "onChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => RadioGroupComponent),
                multi: true,
            },
            {
                provide: ORC_RADIO_GROUP,
                useExisting: forwardRef(() => RadioGroupComponent),
            },
        ], ngImport: i0, template: "<div\n  class=\"p-radiogroup p-component orc-radio-group\"\n  [class.orc-radio-group--horizontal]=\"layout() === 'horizontal'\"\n  [class.orc-radio-group--vertical]=\"layout() === 'vertical'\"\n  [class.orc-radio-group--disabled]=\"isDisabled()\"\n  [class.orc-radio-group--error]=\"isError()\"\n  [class.p-radiogroup-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'radiogroup'\"\n  role=\"radiogroup\"\n  [attr.aria-labelledby]=\"label() ? labelId : null\"\n  [attr.aria-label]=\"!label() && ariaLabel() ? ariaLabel() : null\"\n  [attr.aria-describedby]=\"isError() && errorMessage() ? errorId : (hint() ? hintId : null)\"\n  [attr.aria-invalid]=\"isError()\"\n>\n  <!-- Group Label / Header -->\n  <div *ngIf=\"label()\" class=\"orc-radio-group__label\" [id]=\"labelId\">\n    {{ label() }}\n  </div>\n\n  <!-- Optional Hint -->\n  <p *ngIf=\"hint()\" class=\"orc-radio-group__hint\" [id]=\"hintId\">\n    {{ hint() }}\n  </p>\n\n  <!-- Options Container with Column or Row layout -->\n  <div class=\"orc-radio-group__options\">\n    <ng-content></ng-content>\n  </div>\n\n  <!-- Error Message -->\n  <div\n    *ngIf=\"isError() && errorMessage()\"\n    class=\"orc-radio-group__error-message\"\n    [id]=\"errorId\"\n    role=\"alert\"\n  >\n    {{ errorMessage() }}\n  </div>\n</div>\n", styles: [":host{display:block}.orc-radio-group{display:flex;flex-direction:column;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-radio-group__label{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__hint{font-size:.8125rem;color:var(--orc-font-secondary, #666666);margin-top:calc(-1 * var(--space-1, .25rem));margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__options{display:flex;flex-direction:column;gap:10px}.orc-radio-group--horizontal .orc-radio-group__options{flex-direction:row;flex-wrap:wrap;align-items:center;gap:var(--space-6, 1.5rem)}.orc-radio-group__error-message{font-size:.8125rem;font-weight:500;color:var(--color-error, #fb2c36);margin-top:var(--space-2, .5rem);display:flex;align-items:center;gap:var(--space-1, .25rem)}.orc-radio-group--disabled .orc-radio-group__label{color:var(--orc-font-secondary, #666666)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-radio-group', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => RadioGroupComponent),
                            multi: true,
                        },
                        {
                            provide: ORC_RADIO_GROUP,
                            useExisting: forwardRef(() => RadioGroupComponent),
                        },
                    ], template: "<div\n  class=\"p-radiogroup p-component orc-radio-group\"\n  [class.orc-radio-group--horizontal]=\"layout() === 'horizontal'\"\n  [class.orc-radio-group--vertical]=\"layout() === 'vertical'\"\n  [class.orc-radio-group--disabled]=\"isDisabled()\"\n  [class.orc-radio-group--error]=\"isError()\"\n  [class.p-radiogroup-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'radiogroup'\"\n  role=\"radiogroup\"\n  [attr.aria-labelledby]=\"label() ? labelId : null\"\n  [attr.aria-label]=\"!label() && ariaLabel() ? ariaLabel() : null\"\n  [attr.aria-describedby]=\"isError() && errorMessage() ? errorId : (hint() ? hintId : null)\"\n  [attr.aria-invalid]=\"isError()\"\n>\n  <!-- Group Label / Header -->\n  <div *ngIf=\"label()\" class=\"orc-radio-group__label\" [id]=\"labelId\">\n    {{ label() }}\n  </div>\n\n  <!-- Optional Hint -->\n  <p *ngIf=\"hint()\" class=\"orc-radio-group__hint\" [id]=\"hintId\">\n    {{ hint() }}\n  </p>\n\n  <!-- Options Container with Column or Row layout -->\n  <div class=\"orc-radio-group__options\">\n    <ng-content></ng-content>\n  </div>\n\n  <!-- Error Message -->\n  <div\n    *ngIf=\"isError() && errorMessage()\"\n    class=\"orc-radio-group__error-message\"\n    [id]=\"errorId\"\n    role=\"alert\"\n  >\n    {{ errorMessage() }}\n  </div>\n</div>\n", styles: [":host{display:block}.orc-radio-group{display:flex;flex-direction:column;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-radio-group__label{font-size:.875rem;font-weight:500;color:var(--orc-font-main, #141414);margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__hint{font-size:.8125rem;color:var(--orc-font-secondary, #666666);margin-top:calc(-1 * var(--space-1, .25rem));margin-bottom:var(--space-2, .5rem);line-height:1.4}.orc-radio-group__options{display:flex;flex-direction:column;gap:10px}.orc-radio-group--horizontal .orc-radio-group__options{flex-direction:row;flex-wrap:wrap;align-items:center;gap:var(--space-6, 1.5rem)}.orc-radio-group__error-message{font-size:.8125rem;font-weight:500;color:var(--color-error, #fb2c36);margin-top:var(--space-2, .5rem);display:flex;align-items:center;gap:var(--space-1, .25rem)}.orc-radio-group--disabled .orc-radio-group__label{color:var(--orc-font-secondary, #666666)}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], onChange: [{ type: i0.Output, args: ["onChange"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ORC_RADIO_GROUP, RadioButtonComponent, RadioGroupComponent };
//# sourceMappingURL=ciag-orchestra-radio.mjs.map
