import * as i0 from '@angular/core';
import { inject, ElementRef, DestroyRef, signal, viewChild, input, numberAttribute, booleanAttribute, model, output, computed, effect, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { overlayAttachmentTarget, registerOverlay, listenForOutsideInteraction, isTopOverlay } from '@ciag/orchestra/internal';

let nextAutocompleteId = 0;
class AutocompleteComponent {
    host = inject((ElementRef));
    document = inject(DOCUMENT);
    destroyRef = inject(DestroyRef);
    uniqueId = `orc-autocomplete-${++nextAutocompleteId}`;
    lastValue = null;
    editing = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []));
    blurTimeout = null;
    openTimeout = null;
    composing = false;
    panel = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []));
    outsideCleanup = null;
    layerCleanup = null;
    positionCleanup = null;
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    suggestions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suggestions" }] : /* istanbul ignore next */ []));
    minChars = input(0, { ...(ngDevMode ? { debugName: "minChars" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    minLength = input(undefined, { ...(ngDevMode ? { debugName: "minLength" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    clearable = input(true, { ...(ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(undefined, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dropdown = input(false, { ...(ngDevMode ? { debugName: "dropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    emptyMessage = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    loadingMessage = input('Loading…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingMessage" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    dropdownAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownAriaLabel" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    panelStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    panelStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    delay = input(300, { ...(ngDevMode ? { debugName: "delay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    forceSelection = input(false, { ...(ngDevMode ? { debugName: "forceSelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoHighlight = input(false, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showEmptyMessage = input(true, { ...(ngDevMode ? { debugName: "showEmptyMessage" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    query = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    filterQuery = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterQuery" }] : /* istanbul ignore next */ []));
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    activeIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    optionSelected = output();
    onChange = output();
    onClear = output();
    onShow = output();
    onHide = output();
    onFocusEvent = output();
    onBlurEvent = output();
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    listId = computed(() => `${this.effectiveId()}-list`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    effectiveReadonly = computed(() => this.readonly() && !this.effectiveDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveReadonly" }] : /* istanbul ignore next */ []));
    effectiveOptions = computed(() => this.suggestions() ?? this.options(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveOptions" }] : /* istanbul ignore next */ []));
    effectiveMinLength = computed(() => this.minLength() ?? this.minChars(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveMinLength" }] : /* istanbul ignore next */ []));
    effectiveShowClear = computed(() => this.showClear() ?? this.clearable(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveShowClear" }] : /* istanbul ignore next */ []));
    selectedLabel = computed(() => this.effectiveOptions().find((option) => option.value === this.value())
        ?.label ?? '', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []));
    displayText = computed(() => this.editing()
        ? this.query()
        : this.selectedLabel() || this.value() || this.query(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    panelVisible = computed(() => this.isOpen() &&
        (this.filteredOptions().length > 0 ||
            this.loading() ||
            this.showEmptyMessage()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelVisible" }] : /* istanbul ignore next */ []));
    filteredOptions = computed(() => {
        const query = this.filterQuery().trim().toLocaleLowerCase();
        if (query.length < this.effectiveMinLength())
            return [];
        return this.effectiveOptions().filter((option) => option.label.toLocaleLowerCase().includes(query) ||
            option.value.toLocaleLowerCase().includes(query));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []));
    describedBy = computed(() => this.errorMessage()
        ? `${this.effectiveId()}-error`
        : this.helperText()
            ? `${this.effectiveId()}-helper`
            : null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
    cvaChange = () => { };
    onTouched = () => { };
    constructor() {
        effect(() => {
            const value = this.value();
            if (value !== this.lastValue) {
                this.lastValue = value;
                this.editing.set(false);
                this.query.set('');
                this.filterQuery.set('');
                this.activeIndex.set(-1);
            }
        });
        effect((onCleanup) => {
            const panel = this.panel()?.nativeElement;
            const open = this.isOpen();
            const unavailable = this.effectiveDisabled() || this.readonly();
            const requestedParent = this.appendTo();
            if (unavailable) {
                this.clearOpenTimeout();
                if (open)
                    this.closeDropdown();
                return;
            }
            if (!panel || !open)
                return;
            const parent = overlayAttachmentTarget(this.host.nativeElement, requestedParent, this.host.nativeElement);
            if (parent !== this.host.nativeElement && panel.parentElement !== parent)
                parent.appendChild(panel);
            this.positionPanel(panel, parent);
            this.layerCleanup = registerOverlay(panel, {
                anchor: this.host.nativeElement,
                onParentClose: () => this.closeDropdown(),
            });
            this.outsideCleanup = listenForOutsideInteraction(this.document, () => [this.host.nativeElement, panel], () => {
                if (isTopOverlay(panel))
                    this.closeDropdown();
            });
            const reposition = () => this.positionPanel(panel, parent);
            const resize = typeof ResizeObserver === 'undefined'
                ? null
                : new ResizeObserver(reposition);
            resize?.observe(panel);
            resize?.observe(this.host.nativeElement);
            this.document.addEventListener('scroll', reposition, true);
            this.document.defaultView?.addEventListener('resize', reposition);
            this.positionCleanup = () => {
                resize?.disconnect();
                this.document.removeEventListener('scroll', reposition, true);
                this.document.defaultView?.removeEventListener('resize', reposition);
            };
            onCleanup(() => {
                this.positionCleanup?.();
                this.positionCleanup = null;
                this.outsideCleanup?.();
                this.outsideCleanup = null;
                this.layerCleanup?.();
                this.layerCleanup = null;
                this.resetPanelPosition(panel);
                // Angular tracks the view, but cannot remove a root moved out of its
                // original parent during every destruction path.
                if (parent !== this.host.nativeElement)
                    panel.remove();
            });
        });
        this.destroyRef.onDestroy(() => {
            this.clearBlurTimeout();
            this.clearOpenTimeout();
            this.outsideCleanup?.();
            this.layerCleanup?.();
            this.positionCleanup?.();
        });
    }
    writeValue(value) {
        this.setInternalValue(value === null || value === undefined ? null : String(value));
        this.query.set('');
        this.filterQuery.set('');
        this.editing.set(false);
        this.activeIndex.set(-1);
    }
    registerOnChange(fn) {
        this.cvaChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(disabled) {
        this.cvaDisabled.set(disabled);
    }
    onInput(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        const text = event.target.value;
        if (this.composing) {
            // Keep the native composition text visible and searchable only after the
            // IME has committed it. Committing intermediate input events can clear a
            // valid selection or open a panel for an incomplete grapheme.
            this.editing.set(true);
            this.query.set(text);
            this.activeIndex.set(-1);
            return;
        }
        this.applyInputValue(text);
    }
    onCompositionStart() {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.composing = true;
        this.clearOpenTimeout();
        this.activeIndex.set(-1);
    }
    onCompositionEnd(event) {
        if (!this.composing)
            return;
        this.composing = false;
        if (this.effectiveDisabled() || this.readonly())
            return;
        const target = event.target;
        this.applyInputValue(target?.value ?? this.query());
    }
    applyInputValue(text) {
        this.clearOpenTimeout();
        this.filterQuery.set(text);
        const selectedLabel = this.selectedLabel();
        this.editing.set(true);
        this.query.set(text);
        const nextValue = this.forceSelection()
            ? text === selectedLabel
                ? this.value()
                : null
            : text || null;
        if (nextValue !== this.value()) {
            this.setInternalValue(nextValue);
            this.cvaChange(nextValue);
            this.onChange.emit({ value: nextValue });
        }
        this.activeIndex.set(-1);
        if (text.trim().length >= this.effectiveMinLength()) {
            const open = () => {
                this.openTimeout = null;
                this.openDropdown();
                this.activeIndex.set(this.autoHighlight() ? this.firstEnabledIndex() : -1);
            };
            const delay = Number(this.delay());
            if (Number.isFinite(delay) && delay > 0)
                this.openTimeout = setTimeout(open, delay);
            else
                open();
        }
        else {
            this.closeDropdown();
            this.activeIndex.set(-1);
        }
    }
    onFocus(event) {
        this.clearBlurTimeout();
        if (!this.effectiveDisabled() &&
            !this.readonly() &&
            (this.dropdown() ||
                this.query().trim().length >= this.effectiveMinLength())) {
            this.openDropdown();
            if (this.autoHighlight())
                this.activeIndex.set(this.firstEnabledIndex());
        }
        if (event)
            this.onFocusEvent.emit(event);
    }
    toggleDropdown(event) {
        event?.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.clearOpenTimeout();
        this.clearBlurTimeout();
        if (this.isOpen()) {
            this.closeDropdown();
            return;
        }
        this.openDropdown();
        this.activeIndex.set(this.firstEnabledIndex());
    }
    onBlur(event) {
        this.clearOpenTimeout();
        this.onTouched();
        if (this.forceSelection() && !this.composing) {
            const query = this.query();
            const selected = this.effectiveOptions().find((option) => !option.disabled &&
                (query ? option.label === query : option.value === this.value()));
            if (selected && selected.value !== this.value())
                this.select(selected);
            else if (!selected && (this.value() !== null || query))
                this.clear();
        }
        this.editing.set(false);
        this.clearBlurTimeout();
        this.blurTimeout = setTimeout(() => {
            this.blurTimeout = null;
            this.closeDropdown();
        }, 120);
        if (event)
            this.onBlurEvent.emit(event);
    }
    select(option) {
        if (option.disabled || this.effectiveDisabled() || this.readonly())
            return;
        this.clearBlurTimeout();
        this.setInternalValue(option.value);
        this.editing.set(false);
        this.query.set(option.label);
        this.filterQuery.set(option.label);
        this.closeDropdown();
        this.cvaChange(option.value);
        this.onChange.emit({ value: option.value });
        this.onTouched();
        this.optionSelected.emit(option);
    }
    clear(event) {
        event?.preventDefault();
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.clearBlurTimeout();
        this.setInternalValue(null);
        this.editing.set(false);
        this.query.set('');
        this.filterQuery.set('');
        this.closeDropdown();
        this.cvaChange(null);
        this.onChange.emit({ value: null });
        this.onClear.emit();
        this.onTouched();
    }
    onDocumentClick(event) {
        this.clearBlurTimeout();
        const panel = this.panel()?.nativeElement;
        if (!this.host.nativeElement.contains(event.target) &&
            !panel?.contains(event.target) &&
            (!panel || isTopOverlay(panel)))
            this.closeDropdown();
    }
    onKeydown(event) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        if (this.composing || event.isComposing || event.keyCode === 229)
            return;
        const options = this.filteredOptions();
        if (event.key === 'Escape' && this.closeOnEscape() && this.isOpen()) {
            const panel = this.panel()?.nativeElement;
            if (panel && !isTopOverlay(panel))
                return;
            event.preventDefault();
            event.stopPropagation();
            this.closeDropdown();
            return;
        }
        if (event.key === 'ArrowDown') {
            if (this.moveActive(1))
                event.preventDefault();
            return;
        }
        if (event.key === 'ArrowUp') {
            if (this.moveActive(-1))
                event.preventDefault();
            return;
        }
        if (event.key === 'Home' && this.isOpen()) {
            if (this.moveToBoundary('first'))
                event.preventDefault();
            return;
        }
        if (event.key === 'End' && this.isOpen()) {
            if (this.moveToBoundary('last'))
                event.preventDefault();
            return;
        }
        if (event.key === 'Enter' && this.isOpen() && this.activeIndex() >= 0) {
            const option = options[this.activeIndex()];
            if (option && !option.disabled) {
                event.preventDefault();
                this.select(option);
            }
        }
    }
    optionId(index) {
        return `${this.effectiveId()}-option-${index}`;
    }
    moveActive(direction) {
        const options = this.filteredOptions();
        if (!options.length)
            return false;
        let index = this.activeIndex();
        if (index < 0)
            index = direction === 1 ? -1 : 0;
        for (let i = 0; i < options.length; i += 1) {
            index = (index + direction + options.length) % options.length;
            if (!options[index]?.disabled) {
                this.activeIndex.set(index);
                this.openDropdown();
                return true;
            }
        }
        return false;
    }
    moveToBoundary(direction) {
        const options = this.filteredOptions();
        let index = -1;
        if (direction === 'first') {
            index = options.findIndex((option) => !option.disabled);
        }
        else {
            for (let i = options.length - 1; i >= 0; i -= 1) {
                if (!options[i]?.disabled) {
                    index = i;
                    break;
                }
            }
        }
        if (index < 0)
            return false;
        this.activeIndex.set(index);
        this.openDropdown();
        return true;
    }
    firstEnabledIndex() {
        return this.filteredOptions().findIndex((option) => !option.disabled);
    }
    openDropdown() {
        if (this.effectiveDisabled() || this.readonly() || this.isOpen())
            return;
        this.isOpen.set(true);
        this.onShow.emit();
    }
    closeDropdown() {
        this.clearOpenTimeout();
        if (!this.isOpen()) {
            this.activeIndex.set(-1);
            return;
        }
        this.isOpen.set(false);
        this.activeIndex.set(-1);
        if (!this.destroyRef.destroyed)
            this.onHide.emit();
    }
    setInternalValue(value) {
        this.lastValue = value;
        this.value.set(value);
    }
    clearBlurTimeout() {
        if (this.blurTimeout) {
            clearTimeout(this.blurTimeout);
            this.blurTimeout = null;
        }
    }
    clearOpenTimeout() {
        if (this.openTimeout) {
            clearTimeout(this.openTimeout);
            this.openTimeout = null;
        }
    }
    positionPanel(panel, parent) {
        if (parent === this.host.nativeElement)
            return;
        const anchor = this.host.nativeElement
            .querySelector('.orc-autocomplete__control')
            .getBoundingClientRect();
        const isBody = parent === this.document.body;
        panel.classList.add('orc-autocomplete__list--detached');
        panel.style.inset = 'auto';
        panel.style.position = isBody ? 'fixed' : 'absolute';
        panel.style.width = `${anchor.width}px`;
        // A custom append target can be statically positioned. Absolute coordinates
        // belong to the actual containing block, not necessarily the DOM parent.
        const containingBlock = panel.offsetParent;
        const parentRect = containingBlock?.getBoundingClientRect();
        const rootBlock = !containingBlock ||
            containingBlock === this.document.body ||
            containingBlock === this.document.documentElement;
        const offsetLeft = isBody
            ? 0
            : rootBlock
                ? -(this.document.defaultView?.scrollX ?? 0)
                : parentRect.left +
                    containingBlock.clientLeft -
                    containingBlock.scrollLeft;
        const offsetTop = isBody
            ? 0
            : rootBlock
                ? -(this.document.defaultView?.scrollY ?? 0)
                : parentRect.top +
                    containingBlock.clientTop -
                    containingBlock.scrollTop;
        const viewportHeight = this.document.documentElement.clientHeight;
        const viewportWidth = this.document.documentElement.clientWidth;
        const height = panel.getBoundingClientRect().height;
        const top = anchor.bottom + height > viewportHeight - 8 && anchor.top >= height + 8
            ? anchor.top - height
            : anchor.bottom - 1;
        const left = Math.max(8, Math.min(anchor.left, viewportWidth - panel.getBoundingClientRect().width - 8));
        panel.style.left = `${left - offsetLeft}px`;
        panel.style.top = `${Math.max(8, top) - offsetTop}px`;
    }
    resetPanelPosition(panel) {
        panel.classList.remove('orc-autocomplete__list--detached');
        panel.style.removeProperty('position');
        panel.style.removeProperty('left');
        panel.style.removeProperty('top');
        panel.style.removeProperty('width');
        panel.style.removeProperty('right');
        panel.style.removeProperty('inset');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutocompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: AutocompleteComponent, isStandalone: true, selector: "orc-autocomplete", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, suggestions: { classPropertyName: "suggestions", publicName: "suggestions", isSignal: true, isRequired: false, transformFunction: null }, minChars: { classPropertyName: "minChars", publicName: "minChars", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, dropdown: { classPropertyName: "dropdown", publicName: "dropdown", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, loadingMessage: { classPropertyName: "loadingMessage", publicName: "loadingMessage", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, dropdownAriaLabel: { classPropertyName: "dropdownAriaLabel", publicName: "dropdownAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, delay: { classPropertyName: "delay", publicName: "delay", isSignal: true, isRequired: false, transformFunction: null }, forceSelection: { classPropertyName: "forceSelection", publicName: "forceSelection", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, showEmptyMessage: { classPropertyName: "showEmptyMessage", publicName: "showEmptyMessage", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", optionSelected: "optionSelected", onChange: "onChange", onClear: "onClear", onShow: "onShow", onHide: "onHide", onFocusEvent: "onFocusEvent", onBlurEvent: "onBlurEvent" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => AutocompleteComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-autocomplete p-component orc-autocomplete\"\n  [class]=\"'p-autocomplete p-component orc-autocomplete ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-autocomplete--disabled]=\"effectiveDisabled()\"\n  [class.orc-autocomplete--readonly]=\"effectiveReadonly()\"\n  [attr.data-pc-name]=\"'autocomplete'\"\n>\n  @if (label()) {\n    <label class=\"orc-autocomplete__label\" [for]=\"effectiveId()\"\n      >{{ label() }}\n      @if (required()) {\n        <span aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"orc-autocomplete__control\">\n    <input\n      class=\"orc-autocomplete__input\"\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      type=\"text\"\n      role=\"combobox\"\n      aria-autocomplete=\"list\"\n      [value]=\"displayText()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"effectiveReadonly()\"\n      [required]=\"required()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-expanded]=\"panelVisible()\"\n      [attr.aria-controls]=\"panelVisible() ? listId() : null\"\n      [attr.aria-readonly]=\"effectiveReadonly() ? 'true' : null\"\n      [attr.aria-activedescendant]=\"\n        panelVisible() &&\n        activeIndex() >= 0 &&\n        activeIndex() < filteredOptions().length\n          ? optionId(activeIndex())\n          : null\n      \"\n      [attr.aria-invalid]=\"errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      autocomplete=\"off\"\n      (input)=\"onInput($event)\"\n      (compositionstart)=\"onCompositionStart()\"\n      (compositionend)=\"onCompositionEnd($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      (keydown)=\"onKeydown($event)\"\n    />\n    @if (effectiveShowClear() && (query() || value())) {\n      <button\n        type=\"button\"\n        class=\"orc-autocomplete__clear\"\n        (mousedown)=\"$event.preventDefault()\"\n        (click)=\"clear($event)\"\n        [disabled]=\"effectiveDisabled() || readonly()\"\n        [attr.aria-label]=\"clearAriaLabel() || 'Clear selection'\"\n      >\n        \u00D7\n      </button>\n    }\n    @if (dropdown()) {\n      <button\n        type=\"button\"\n        class=\"p-autocomplete-dropdown\"\n        (mousedown)=\"$event.preventDefault()\"\n        (click)=\"toggleDropdown($event)\"\n        [disabled]=\"effectiveDisabled() || readonly()\"\n        [attr.aria-label]=\"dropdownAriaLabel() || 'Show options'\"\n      >\n        \u2304\n      </button>\n    }\n  </div>\n  @if (panelVisible()) {\n    <ul\n      #panel\n      class=\"p-autocomplete-panel p-component orc-autocomplete__list\"\n      [class]=\"\n        'p-autocomplete-panel p-component orc-autocomplete__list ' +\n        panelStyleClass()\n      \"\n      [style]=\"panelStyle()\"\n      [id]=\"listId()\"\n      role=\"listbox\"\n      [attr.aria-busy]=\"loading()\"\n      [attr.aria-label]=\"ariaLabel() || label() || 'Options'\"\n    >\n      @if (loading()) {\n        <li class=\"orc-autocomplete__option\" role=\"status\">\n          {{ loadingMessage() }}\n        </li>\n      }\n      @for (option of filteredOptions(); track option.value) {\n        <li\n          class=\"orc-autocomplete__option\"\n          [class.orc-autocomplete__option--active]=\"activeIndex() === $index\"\n          [class.orc-autocomplete__option--disabled]=\"option.disabled\"\n          [id]=\"optionId($index)\"\n          role=\"option\"\n          [attr.aria-selected]=\"value() === option.value\"\n          [attr.aria-disabled]=\"option.disabled ? 'true' : null\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"select(option)\"\n        >\n          <span>{{ option.label }}</span>\n          @if (option.description) {\n            <small>{{ option.description }}</small>\n          }\n        </li>\n      }\n      @if (!loading() && !filteredOptions().length && showEmptyMessage()) {\n        <li class=\"orc-autocomplete__option\" role=\"status\">\n          {{ emptyMessage() || 'No results' }}\n        </li>\n      }\n    </ul>\n  }\n  @if (errorMessage() || helperText()) {\n    <p\n      class=\"orc-autocomplete__message\"\n      [class.orc-autocomplete__message--error]=\"!!errorMessage()\"\n      [id]=\"describedBy()\"\n    >\n      {{ errorMessage() || helperText() }}\n    </p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-autocomplete{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-autocomplete__label{font-size:13px;font-weight:600;color:var(--orc-text, var(--text-primary, #141414))}.orc-autocomplete__label span{color:var(--orc-danger, #fb2c36)}.orc-autocomplete__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-control-surface, var(--fill-input, #fff))}.orc-autocomplete__control:focus-within{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-autocomplete__input{flex:1;min-width:0;padding:10px 12px;border:0;outline:0;background:transparent;color:var(--orc-text, var(--text-primary, #141414));font:inherit}.orc-autocomplete--readonly .orc-autocomplete__input{cursor:default}.orc-autocomplete__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:20px;cursor:pointer}.orc-autocomplete__clear:hover{background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-autocomplete__list{position:absolute;z-index:var(--z-dropdown, 1000);inset:calc(100% - 1px) 0 auto;max-height:240px;overflow:auto;margin:0;padding:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:0 0 var(--radius-md, 10px) var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff));box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12));list-style:none}.orc-autocomplete__list--detached{box-sizing:border-box;max-width:calc(100vw - 16px)}.orc-autocomplete__option{display:grid;gap:2px;padding:9px 10px;border-radius:var(--radius-sm, 6px);color:var(--orc-text, var(--text-primary, #141414));cursor:pointer}.orc-autocomplete__option small{color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-autocomplete__option:hover,.orc-autocomplete__option--active{background:var(--orc-interactive-soft);color:var(--orc-interactive-hover, var(--orc-interactive, #1c6aed))}.orc-autocomplete__option--disabled{opacity:.45;cursor:not-allowed}.orc-autocomplete--disabled{opacity:.55}.orc-autocomplete__message{margin:0;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px}.orc-autocomplete__message--error{color:var(--orc-danger, #fb2c36)}.p-autocomplete-dropdown{display:grid;place-items:center;flex:0 0 36px;align-self:stretch;padding:0;border:0;border-inline-start:1px solid var(--orc-border-default);border-radius:0 var(--radius-md, 10px) var(--radius-md, 10px) 0;background:transparent;color:var(--orc-text-secondary);font:inherit;cursor:pointer}.p-autocomplete-dropdown:hover:not(:disabled){background:var(--orc-surface-subtle)}.orc-autocomplete__clear:disabled,.p-autocomplete-dropdown:disabled{cursor:default}.orc-autocomplete__clear:focus-visible,.p-autocomplete-dropdown:focus-visible{outline:2px solid var(--orc-interactive);outline-offset:-2px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutocompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-autocomplete', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => AutocompleteComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-autocomplete p-component orc-autocomplete\"\n  [class]=\"'p-autocomplete p-component orc-autocomplete ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-autocomplete--disabled]=\"effectiveDisabled()\"\n  [class.orc-autocomplete--readonly]=\"effectiveReadonly()\"\n  [attr.data-pc-name]=\"'autocomplete'\"\n>\n  @if (label()) {\n    <label class=\"orc-autocomplete__label\" [for]=\"effectiveId()\"\n      >{{ label() }}\n      @if (required()) {\n        <span aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"orc-autocomplete__control\">\n    <input\n      class=\"orc-autocomplete__input\"\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      type=\"text\"\n      role=\"combobox\"\n      aria-autocomplete=\"list\"\n      [value]=\"displayText()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"effectiveReadonly()\"\n      [required]=\"required()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-expanded]=\"panelVisible()\"\n      [attr.aria-controls]=\"panelVisible() ? listId() : null\"\n      [attr.aria-readonly]=\"effectiveReadonly() ? 'true' : null\"\n      [attr.aria-activedescendant]=\"\n        panelVisible() &&\n        activeIndex() >= 0 &&\n        activeIndex() < filteredOptions().length\n          ? optionId(activeIndex())\n          : null\n      \"\n      [attr.aria-invalid]=\"errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      autocomplete=\"off\"\n      (input)=\"onInput($event)\"\n      (compositionstart)=\"onCompositionStart()\"\n      (compositionend)=\"onCompositionEnd($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      (keydown)=\"onKeydown($event)\"\n    />\n    @if (effectiveShowClear() && (query() || value())) {\n      <button\n        type=\"button\"\n        class=\"orc-autocomplete__clear\"\n        (mousedown)=\"$event.preventDefault()\"\n        (click)=\"clear($event)\"\n        [disabled]=\"effectiveDisabled() || readonly()\"\n        [attr.aria-label]=\"clearAriaLabel() || 'Clear selection'\"\n      >\n        \u00D7\n      </button>\n    }\n    @if (dropdown()) {\n      <button\n        type=\"button\"\n        class=\"p-autocomplete-dropdown\"\n        (mousedown)=\"$event.preventDefault()\"\n        (click)=\"toggleDropdown($event)\"\n        [disabled]=\"effectiveDisabled() || readonly()\"\n        [attr.aria-label]=\"dropdownAriaLabel() || 'Show options'\"\n      >\n        \u2304\n      </button>\n    }\n  </div>\n  @if (panelVisible()) {\n    <ul\n      #panel\n      class=\"p-autocomplete-panel p-component orc-autocomplete__list\"\n      [class]=\"\n        'p-autocomplete-panel p-component orc-autocomplete__list ' +\n        panelStyleClass()\n      \"\n      [style]=\"panelStyle()\"\n      [id]=\"listId()\"\n      role=\"listbox\"\n      [attr.aria-busy]=\"loading()\"\n      [attr.aria-label]=\"ariaLabel() || label() || 'Options'\"\n    >\n      @if (loading()) {\n        <li class=\"orc-autocomplete__option\" role=\"status\">\n          {{ loadingMessage() }}\n        </li>\n      }\n      @for (option of filteredOptions(); track option.value) {\n        <li\n          class=\"orc-autocomplete__option\"\n          [class.orc-autocomplete__option--active]=\"activeIndex() === $index\"\n          [class.orc-autocomplete__option--disabled]=\"option.disabled\"\n          [id]=\"optionId($index)\"\n          role=\"option\"\n          [attr.aria-selected]=\"value() === option.value\"\n          [attr.aria-disabled]=\"option.disabled ? 'true' : null\"\n          (mousedown)=\"$event.preventDefault()\"\n          (click)=\"select(option)\"\n        >\n          <span>{{ option.label }}</span>\n          @if (option.description) {\n            <small>{{ option.description }}</small>\n          }\n        </li>\n      }\n      @if (!loading() && !filteredOptions().length && showEmptyMessage()) {\n        <li class=\"orc-autocomplete__option\" role=\"status\">\n          {{ emptyMessage() || 'No results' }}\n        </li>\n      }\n    </ul>\n  }\n  @if (errorMessage() || helperText()) {\n    <p\n      class=\"orc-autocomplete__message\"\n      [class.orc-autocomplete__message--error]=\"!!errorMessage()\"\n      [id]=\"describedBy()\"\n    >\n      {{ errorMessage() || helperText() }}\n    </p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-autocomplete{position:relative;display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-autocomplete__label{font-size:13px;font-weight:600;color:var(--orc-text, var(--text-primary, #141414))}.orc-autocomplete__label span{color:var(--orc-danger, #fb2c36)}.orc-autocomplete__control{display:flex;align-items:center;min-height:44px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-control-surface, var(--fill-input, #fff))}.orc-autocomplete__control:focus-within{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow)}.orc-autocomplete__input{flex:1;min-width:0;padding:10px 12px;border:0;outline:0;background:transparent;color:var(--orc-text, var(--text-primary, #141414));font:inherit}.orc-autocomplete--readonly .orc-autocomplete__input{cursor:default}.orc-autocomplete__clear{width:30px;height:30px;margin-right:6px;border:0;border-radius:50%;background:transparent;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:20px;cursor:pointer}.orc-autocomplete__clear:hover{background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-autocomplete__list{position:absolute;z-index:var(--z-dropdown, 1000);inset:calc(100% - 1px) 0 auto;max-height:240px;overflow:auto;margin:0;padding:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:0 0 var(--radius-md, 10px) var(--radius-md, 10px);background:var(--orc-surface-raised, var(--fill-modal, #fff));box-shadow:var(--shadow-md, 0 4px 12px rgba(0, 0, 0, .12));list-style:none}.orc-autocomplete__list--detached{box-sizing:border-box;max-width:calc(100vw - 16px)}.orc-autocomplete__option{display:grid;gap:2px;padding:9px 10px;border-radius:var(--radius-sm, 6px);color:var(--orc-text, var(--text-primary, #141414));cursor:pointer}.orc-autocomplete__option small{color:var(--orc-text-secondary, var(--text-secondary, #666))}.orc-autocomplete__option:hover,.orc-autocomplete__option--active{background:var(--orc-interactive-soft);color:var(--orc-interactive-hover, var(--orc-interactive, #1c6aed))}.orc-autocomplete__option--disabled{opacity:.45;cursor:not-allowed}.orc-autocomplete--disabled{opacity:.55}.orc-autocomplete__message{margin:0;color:var(--orc-text-secondary, var(--text-secondary, #666));font-size:12px}.orc-autocomplete__message--error{color:var(--orc-danger, #fb2c36)}.p-autocomplete-dropdown{display:grid;place-items:center;flex:0 0 36px;align-self:stretch;padding:0;border:0;border-inline-start:1px solid var(--orc-border-default);border-radius:0 var(--radius-md, 10px) var(--radius-md, 10px) 0;background:transparent;color:var(--orc-text-secondary);font:inherit;cursor:pointer}.p-autocomplete-dropdown:hover:not(:disabled){background:var(--orc-surface-subtle)}.orc-autocomplete__clear:disabled,.p-autocomplete-dropdown:disabled{cursor:default}.orc-autocomplete__clear:focus-visible,.p-autocomplete-dropdown:focus-visible{outline:2px solid var(--orc-interactive);outline-offset:-2px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { panel: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], suggestions: [{ type: i0.Input, args: [{ isSignal: true, alias: "suggestions", required: false }] }], minChars: [{ type: i0.Input, args: [{ isSignal: true, alias: "minChars", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], dropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdown", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], loadingMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingMessage", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], dropdownAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownAriaLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], delay: [{ type: i0.Input, args: [{ isSignal: true, alias: "delay", required: false }] }], forceSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceSelection", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], showEmptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "showEmptyMessage", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], optionSelected: [{ type: i0.Output, args: ["optionSelected"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onFocusEvent: [{ type: i0.Output, args: ["onFocusEvent"] }], onBlurEvent: [{ type: i0.Output, args: ["onBlurEvent"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AutocompleteComponent };
//# sourceMappingURL=ciag-orchestra-autocomplete.mjs.map
