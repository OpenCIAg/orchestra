import * as i0 from '@angular/core';
import { viewChild, input, numberAttribute, booleanAttribute, model, output, signal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

let nextNumberInputId = 0;
class NumberInputComponent {
    uniqueId = `orc-number-input-${++nextNumberInputId}`;
    nativeInput = viewChild('nativeInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeInput" }] : /* istanbul ignore next */ []));
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    status = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    min = input(undefined, { ...(ngDevMode ? { debugName: "min" } : /* istanbul ignore next */ {}), transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    max = input(undefined, { ...(ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {}), transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    step = input(1, { ...(ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    precision = input(undefined, { ...(ngDevMode ? { debugName: "precision" } : /* istanbul ignore next */ {}), transform: (value) => value === undefined || value === null || value === '' ? undefined : numberAttribute(value) });
    prefix = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefix" }] : /* istanbul ignore next */ []));
    suffix = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffix" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showControls = input(true, { ...(ngDevMode ? { debugName: "showControls" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showButtons = input(true, { ...(ngDevMode ? { debugName: "showButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    format = input(true, { ...(ngDevMode ? { debugName: "format" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    buttonLayout = input('stacked', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "buttonLayout" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    inputStyle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputStyle" }] : /* istanbul ignore next */ []));
    inputStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputStyleClass" }] : /* istanbul ignore next */ []));
    incrementButtonClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "incrementButtonClass" }] : /* istanbul ignore next */ []));
    decrementButtonClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "decrementButtonClass" }] : /* istanbul ignore next */ []));
    incrementButtonIcon = input('+', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "incrementButtonIcon" }] : /* istanbul ignore next */ []));
    decrementButtonIcon = input('−', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "decrementButtonIcon" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaDescribedBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedBy" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    allowEmpty = input(true, { ...(ngDevMode ? { debugName: "allowEmpty" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    locale = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    mode = input('decimal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    currency = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currency" }] : /* istanbul ignore next */ []));
    currencyDisplay = input('symbol', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currencyDisplay" }] : /* istanbul ignore next */ []));
    useGrouping = input(true, { ...(ngDevMode ? { debugName: "useGrouping" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    minFractionDigits = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minFractionDigits" }] : /* istanbul ignore next */ []));
    maxFractionDigits = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxFractionDigits" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    incrementButtonAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "incrementButtonAriaLabel" }] : /* istanbul ignore next */ []));
    decrementButtonAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "decrementButtonAriaLabel" }] : /* istanbul ignore next */ []));
    ariaRequired = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaRequired" }] : /* istanbul ignore next */ []));
    title = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    maxlength = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxlength" }] : /* istanbul ignore next */ []));
    autocomplete = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    localeMatcher = input('best fit', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "localeMatcher" }] : /* istanbul ignore next */ []));
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    blur = output();
    onInput = output();
    onFocus = output();
    onBlur = output();
    onKeyDown = output();
    onClear = output();
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    displayValue = computed(() => {
        const value = this.value();
        if (value === null || value === undefined)
            return '';
        if (!this.format())
            return this.precision() === undefined ? String(value) : value.toFixed(this.precision());
        try {
            return new Intl.NumberFormat(this.locale(), { style: this.mode() === 'currency' ? 'currency' : 'decimal', currency: this.currency(), currencyDisplay: this.currencyDisplay(), useGrouping: this.useGrouping(), minimumFractionDigits: this.minFractionDigits() ?? this.precision(), maximumFractionDigits: this.maxFractionDigits() ?? this.precision(), localeMatcher: this.localeMatcher() }).format(value);
        }
        catch {
            return this.precision() === undefined ? String(value) : value.toFixed(this.precision());
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []));
    helperId = computed(() => `${this.effectiveId()}-helper`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    describedBy = computed(() => this.errorMessage() ? this.errorId() : this.helperText() ? this.helperId() : null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        const parsed = value === null || value === undefined || value === '' ? null : Number(value);
        this.value.set(parsed !== null && Number.isFinite(parsed) ? this.clamp(parsed) : null);
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(disabled) { this.cvaDisabled.set(disabled); }
    handleInput(event) {
        const raw = event.target.value;
        if (raw.trim() === '') {
            if (this.allowEmpty())
                this.update(null);
            this.onInput.emit({ originalEvent: event, value: this.value() });
            return;
        }
        const numericText = raw.replace(/[^0-9+,\-.]/g, '');
        const normalized = numericText.includes(',') && !numericText.includes('.')
            ? numericText.replace(',', '.')
            : numericText.replace(/,/g, '');
        const parsed = Number(normalized);
        if (Number.isFinite(parsed))
            this.update(this.clamp(parsed));
        this.onInput.emit({ originalEvent: event, value: this.value() });
    }
    handleBlur(event) {
        const input = event.target;
        if (this.value() !== null)
            input.value = this.displayValue();
        this.onTouched();
        this.blur.emit(event);
        this.onBlur.emit(event);
    }
    onKeydown(event) {
        this.onKeyDown.emit(event);
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.increment();
        }
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.decrement();
        }
    }
    clear() { if (this.effectiveDisabled() || this.readonly())
        return; this.update(null); this.onTouched(); this.onClear.emit(); }
    increment() { this.update(this.clamp((this.value() ?? this.min() ?? 0) + this.safeStep())); }
    decrement() { this.update(this.clamp((this.value() ?? this.min() ?? 0) - this.safeStep())); }
    focus() { this.nativeInput()?.nativeElement.focus(); }
    update(value) {
        if (this.effectiveDisabled() || this.readonly())
            return;
        this.value.set(value);
        this.onChange(value);
    }
    clamp(value) {
        const min = this.min();
        const max = this.max();
        let next = min === undefined ? value : Math.max(min, value);
        if (max !== undefined)
            next = Math.min(max, next);
        const precision = this.precision();
        return precision === undefined ? next : Number(next.toFixed(precision));
    }
    safeStep() {
        const step = this.step();
        return Number.isFinite(step) && step > 0 ? step : 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: NumberInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: NumberInputComponent, isStandalone: true, selector: "orc-number-input, orc-input-number", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, precision: { classPropertyName: "precision", publicName: "precision", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, showControls: { classPropertyName: "showControls", publicName: "showControls", isSignal: true, isRequired: false, transformFunction: null }, showButtons: { classPropertyName: "showButtons", publicName: "showButtons", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null }, buttonLayout: { classPropertyName: "buttonLayout", publicName: "buttonLayout", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, inputStyle: { classPropertyName: "inputStyle", publicName: "inputStyle", isSignal: true, isRequired: false, transformFunction: null }, inputStyleClass: { classPropertyName: "inputStyleClass", publicName: "inputStyleClass", isSignal: true, isRequired: false, transformFunction: null }, incrementButtonClass: { classPropertyName: "incrementButtonClass", publicName: "incrementButtonClass", isSignal: true, isRequired: false, transformFunction: null }, decrementButtonClass: { classPropertyName: "decrementButtonClass", publicName: "decrementButtonClass", isSignal: true, isRequired: false, transformFunction: null }, incrementButtonIcon: { classPropertyName: "incrementButtonIcon", publicName: "incrementButtonIcon", isSignal: true, isRequired: false, transformFunction: null }, decrementButtonIcon: { classPropertyName: "decrementButtonIcon", publicName: "decrementButtonIcon", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedBy: { classPropertyName: "ariaDescribedBy", publicName: "ariaDescribedBy", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, allowEmpty: { classPropertyName: "allowEmpty", publicName: "allowEmpty", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, currency: { classPropertyName: "currency", publicName: "currency", isSignal: true, isRequired: false, transformFunction: null }, currencyDisplay: { classPropertyName: "currencyDisplay", publicName: "currencyDisplay", isSignal: true, isRequired: false, transformFunction: null }, useGrouping: { classPropertyName: "useGrouping", publicName: "useGrouping", isSignal: true, isRequired: false, transformFunction: null }, minFractionDigits: { classPropertyName: "minFractionDigits", publicName: "minFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, maxFractionDigits: { classPropertyName: "maxFractionDigits", publicName: "maxFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, incrementButtonAriaLabel: { classPropertyName: "incrementButtonAriaLabel", publicName: "incrementButtonAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, decrementButtonAriaLabel: { classPropertyName: "decrementButtonAriaLabel", publicName: "decrementButtonAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaRequired: { classPropertyName: "ariaRequired", publicName: "ariaRequired", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, maxlength: { classPropertyName: "maxlength", publicName: "maxlength", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, localeMatcher: { classPropertyName: "localeMatcher", publicName: "localeMatcher", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", blur: "blur", onInput: "onInput", onFocus: "onFocus", onBlur: "onBlur", onKeyDown: "onKeyDown", onClear: "onClear" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => NumberInputComponent), multi: true }], viewQueries: [{ propertyName: "nativeInput", first: true, predicate: ["nativeInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"p-inputnumber p-component orc-number-input\" [class]=\"'p-inputnumber p-component orc-number-input ' + styleClass()\" [style]=\"style()\" [class.orc-number-input--disabled]=\"effectiveDisabled()\" [class.orc-number-input--readonly]=\"readonly()\" [class.orc-inputnumber-fluid]=\"fluid()\" [attr.data-pc-name]=\"'inputnumber'\">\n  @if (label()) { <label class=\"orc-number-input__label\" [for]=\"effectiveId()\">{{ label() }} @if (required()) { <span aria-hidden=\"true\">*</span> }</label> }\n  <div class=\"orc-number-input__box\" [class.orc-number-input__box--error]=\"status() === 'error' || !!errorMessage()\" [class.orc-number-input__box--success]=\"status() === 'success'\">\n    @if (prefix()) { <span class=\"orc-number-input__affix\">{{ prefix() }}</span> }\n    @if (showControls() && showButtons()) { <button type=\"button\" [class]=\"'p-inputnumber-button p-inputnumber-button-down orc-number-input__control ' + decrementButtonClass()\" (click)=\"decrement()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"decrementButtonAriaLabel()\">{{ decrementButtonIcon() }}</button> }\n    <input #nativeInput [class]=\"'p-inputnumber-input orc-number-input__native ' + inputStyleClass()\" [style]=\"inputStyle()\" [id]=\"effectiveId()\" [name]=\"name()\" type=\"text\" inputmode=\"decimal\" role=\"spinbutton\" [value]=\"displayValue()\" [attr.placeholder]=\"placeholder() || null\" [min]=\"min() ?? null\" [max]=\"max() ?? null\" [step]=\"step()\" [disabled]=\"effectiveDisabled()\" [readOnly]=\"readonly()\" [required]=\"required()\" [autofocus]=\"autofocus()\" [attr.maxlength]=\"maxlength()\" [attr.title]=\"title()\" [attr.autocomplete]=\"autocomplete()\" [attr.tabindex]=\"tabindex()\" [attr.aria-label]=\"ariaLabel() || null\" [attr.aria-labelledby]=\"ariaLabelledBy() || null\" [attr.aria-required]=\"ariaRequired() ?? (required() ? 'true' : null)\" [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\" [attr.aria-describedby]=\"ariaDescribedBy() || describedBy()\" [attr.aria-valuenow]=\"value()\" [attr.aria-valuemin]=\"min()\" [attr.aria-valuemax]=\"max()\" (focus)=\"onFocus.emit($event)\" (input)=\"handleInput($event)\" (blur)=\"handleBlur($event)\" (keydown)=\"onKeydown($event)\" />\n    @if (showClear() && value() !== null) { <button type=\"button\" class=\"orc-number-input__control\" (click)=\"clear()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"clearAriaLabel() || null\">\u00D7</button> }\n    @if (suffix()) { <span class=\"orc-number-input__affix\">{{ suffix() }}</span> }\n    @if (showControls() && showButtons()) { <button type=\"button\" [class]=\"'p-inputnumber-button p-inputnumber-button-up orc-number-input__control ' + incrementButtonClass()\" (click)=\"increment()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"incrementButtonAriaLabel()\">{{ incrementButtonIcon() }}</button> }\n  </div>\n  @if (errorMessage() || helperText()) { <p class=\"orc-number-input__message\" [class.orc-number-input__message--error]=\"!!errorMessage()\" [id]=\"errorMessage() ? errorId() : helperId()\">{{ errorMessage() || helperText() }}</p> }\n</div>\n", styles: [":host{display:block;width:100%}.orc-number-input{display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-number-input__label{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-number-input__label span{color:var(--color-error, #fb2c36)}.orc-number-input__box{display:flex;align-items:center;min-height:44px;overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);transition:border-color .2s,box-shadow .2s}.orc-number-input__box:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-number-input__box--error{border-color:var(--color-error, #fb2c36)}.orc-number-input__box--success{border-color:var(--color-success, #006f4a)}.orc-number-input__native{flex:1;min-width:0;height:100%;padding:0 8px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:center}.orc-number-input__native::-webkit-inner-spin-button,.orc-number-input__native::-webkit-outer-spin-button{margin:0;-webkit-appearance:none}.orc-number-input__native[type=number]{-moz-appearance:textfield}.orc-number-input__control{align-self:stretch;min-width:38px;padding:0 10px;border:0;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);font-size:20px;cursor:pointer}.orc-number-input__control:hover:not(:disabled){background:var(--orc-border, #d9d9d9)}.orc-number-input__control:disabled{opacity:.4;cursor:not-allowed}.orc-number-input__control:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-number-input__affix{padding:0 10px;color:var(--orc-font-secondary, #666);font-size:13px}.orc-number-input--disabled{opacity:.55}.orc-number-input__message{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-number-input__message--error{color:var(--color-error, #fb2c36)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: NumberInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-number-input, orc-input-number', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => NumberInputComponent), multi: true }], template: "<div class=\"p-inputnumber p-component orc-number-input\" [class]=\"'p-inputnumber p-component orc-number-input ' + styleClass()\" [style]=\"style()\" [class.orc-number-input--disabled]=\"effectiveDisabled()\" [class.orc-number-input--readonly]=\"readonly()\" [class.orc-inputnumber-fluid]=\"fluid()\" [attr.data-pc-name]=\"'inputnumber'\">\n  @if (label()) { <label class=\"orc-number-input__label\" [for]=\"effectiveId()\">{{ label() }} @if (required()) { <span aria-hidden=\"true\">*</span> }</label> }\n  <div class=\"orc-number-input__box\" [class.orc-number-input__box--error]=\"status() === 'error' || !!errorMessage()\" [class.orc-number-input__box--success]=\"status() === 'success'\">\n    @if (prefix()) { <span class=\"orc-number-input__affix\">{{ prefix() }}</span> }\n    @if (showControls() && showButtons()) { <button type=\"button\" [class]=\"'p-inputnumber-button p-inputnumber-button-down orc-number-input__control ' + decrementButtonClass()\" (click)=\"decrement()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"decrementButtonAriaLabel()\">{{ decrementButtonIcon() }}</button> }\n    <input #nativeInput [class]=\"'p-inputnumber-input orc-number-input__native ' + inputStyleClass()\" [style]=\"inputStyle()\" [id]=\"effectiveId()\" [name]=\"name()\" type=\"text\" inputmode=\"decimal\" role=\"spinbutton\" [value]=\"displayValue()\" [attr.placeholder]=\"placeholder() || null\" [min]=\"min() ?? null\" [max]=\"max() ?? null\" [step]=\"step()\" [disabled]=\"effectiveDisabled()\" [readOnly]=\"readonly()\" [required]=\"required()\" [autofocus]=\"autofocus()\" [attr.maxlength]=\"maxlength()\" [attr.title]=\"title()\" [attr.autocomplete]=\"autocomplete()\" [attr.tabindex]=\"tabindex()\" [attr.aria-label]=\"ariaLabel() || null\" [attr.aria-labelledby]=\"ariaLabelledBy() || null\" [attr.aria-required]=\"ariaRequired() ?? (required() ? 'true' : null)\" [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\" [attr.aria-describedby]=\"ariaDescribedBy() || describedBy()\" [attr.aria-valuenow]=\"value()\" [attr.aria-valuemin]=\"min()\" [attr.aria-valuemax]=\"max()\" (focus)=\"onFocus.emit($event)\" (input)=\"handleInput($event)\" (blur)=\"handleBlur($event)\" (keydown)=\"onKeydown($event)\" />\n    @if (showClear() && value() !== null) { <button type=\"button\" class=\"orc-number-input__control\" (click)=\"clear()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"clearAriaLabel() || null\">\u00D7</button> }\n    @if (suffix()) { <span class=\"orc-number-input__affix\">{{ suffix() }}</span> }\n    @if (showControls() && showButtons()) { <button type=\"button\" [class]=\"'p-inputnumber-button p-inputnumber-button-up orc-number-input__control ' + incrementButtonClass()\" (click)=\"increment()\" [disabled]=\"effectiveDisabled() || readonly()\" [attr.aria-label]=\"incrementButtonAriaLabel()\">{{ incrementButtonIcon() }}</button> }\n  </div>\n  @if (errorMessage() || helperText()) { <p class=\"orc-number-input__message\" [class.orc-number-input__message--error]=\"!!errorMessage()\" [id]=\"errorMessage() ? errorId() : helperId()\">{{ errorMessage() || helperText() }}</p> }\n</div>\n", styles: [":host{display:block;width:100%}.orc-number-input{display:grid;gap:6px;width:100%;font-family:var(--font-sans, system-ui, sans-serif)}.orc-number-input__label{font-size:13px;font-weight:600;color:var(--orc-font-main, #141414)}.orc-number-input__label span{color:var(--color-error, #fb2c36)}.orc-number-input__box{display:flex;align-items:center;min-height:44px;overflow:hidden;border:1px solid var(--orc-border, #d9d9d9);border-radius:var(--radius-md, 10px);background:var(--fill-modal, #fff);transition:border-color .2s,box-shadow .2s}.orc-number-input__box:focus-within{border-color:var(--orc-color-azul-eletrico, #1c6aed);box-shadow:0 0 0 3px #1c6aed24}.orc-number-input__box--error{border-color:var(--color-error, #fb2c36)}.orc-number-input__box--success{border-color:var(--color-success, #006f4a)}.orc-number-input__native{flex:1;min-width:0;height:100%;padding:0 8px;border:0;outline:0;background:transparent;color:var(--orc-font-main, #141414);font:inherit;text-align:center}.orc-number-input__native::-webkit-inner-spin-button,.orc-number-input__native::-webkit-outer-spin-button{margin:0;-webkit-appearance:none}.orc-number-input__native[type=number]{-moz-appearance:textfield}.orc-number-input__control{align-self:stretch;min-width:38px;padding:0 10px;border:0;background:var(--orc-th, #f7f8fa);color:var(--orc-font-main, #141414);font-size:20px;cursor:pointer}.orc-number-input__control:hover:not(:disabled){background:var(--orc-border, #d9d9d9)}.orc-number-input__control:disabled{opacity:.4;cursor:not-allowed}.orc-number-input__control:focus-visible{outline:2px solid var(--orc-color-azul-eletrico, #1c6aed);outline-offset:-2px}.orc-number-input__affix{padding:0 10px;color:var(--orc-font-secondary, #666);font-size:13px}.orc-number-input--disabled{opacity:.55}.orc-number-input__message{margin:0;color:var(--orc-font-secondary, #666);font-size:12px}.orc-number-input__message--error{color:var(--color-error, #fb2c36)}\n"] }]
        }], propDecorators: { nativeInput: [{ type: i0.ViewChild, args: ['nativeInput', { isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], precision: [{ type: i0.Input, args: [{ isSignal: true, alias: "precision", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], showControls: [{ type: i0.Input, args: [{ isSignal: true, alias: "showControls", required: false }] }], showButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtons", required: false }] }], format: [{ type: i0.Input, args: [{ isSignal: true, alias: "format", required: false }] }], buttonLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonLayout", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], inputStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyle", required: false }] }], inputStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyleClass", required: false }] }], incrementButtonClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "incrementButtonClass", required: false }] }], decrementButtonClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "decrementButtonClass", required: false }] }], incrementButtonIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "incrementButtonIcon", required: false }] }], decrementButtonIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "decrementButtonIcon", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaDescribedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedBy", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], allowEmpty: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowEmpty", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], currency: [{ type: i0.Input, args: [{ isSignal: true, alias: "currency", required: false }] }], currencyDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "currencyDisplay", required: false }] }], useGrouping: [{ type: i0.Input, args: [{ isSignal: true, alias: "useGrouping", required: false }] }], minFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "minFractionDigits", required: false }] }], maxFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFractionDigits", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], incrementButtonAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "incrementButtonAriaLabel", required: false }] }], decrementButtonAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "decrementButtonAriaLabel", required: false }] }], ariaRequired: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaRequired", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], maxlength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxlength", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }], localeMatcher: [{ type: i0.Input, args: [{ isSignal: true, alias: "localeMatcher", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], blur: [{ type: i0.Output, args: ["blur"] }], onInput: [{ type: i0.Output, args: ["onInput"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onKeyDown: [{ type: i0.Output, args: ["onKeyDown"] }], onClear: [{ type: i0.Output, args: ["onClear"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { NumberInputComponent };
//# sourceMappingURL=ciag-orchestra-number-input.mjs.map
