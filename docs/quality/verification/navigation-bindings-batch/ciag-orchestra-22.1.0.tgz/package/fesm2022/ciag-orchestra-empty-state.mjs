import * as i0 from '@angular/core';
import { input, output, ChangeDetectionStrategy, Component } from '@angular/core';

class EmptyStateComponent {
    title = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    icon = input('∅', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    actionLabel = input('', { ...(ngDevMode ? { debugName: "actionLabel" } : /* istanbul ignore next */ {}), transform: (value) => value ?? '' });
    action = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: EmptyStateComponent, isStandalone: true, selector: "orc-empty-state", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, actionLabel: { classPropertyName: "actionLabel", publicName: "actionLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action" }, ngImport: i0, template: `<section
    class="orc-empty-state orc-p2-empty-state"
    [attr.aria-label]="title()"
  >
    <div class="orc-empty-state__icon icon" aria-hidden="true">
      {{ icon() }}
    </div>
    @if (title()) {
      <h2>{{ title() }}</h2>
    }
    @if (description()) {
      <p>{{ description() }}</p>
    }
    @if (actionLabel()) {
      <button type="button" (click)="action.emit()">{{ actionLabel() }}</button>
    }
    <ng-content />
  </section>`, isInline: true, styles: [":host{display:block}.orc-empty-state{display:grid;justify-items:center;gap:.6rem;padding:3rem 1.5rem;border:1px dashed var(--orc-border-strong,#cbd5e1);border-radius:.75rem;text-align:center;color:var(--orc-text,#0f172a)}.orc-empty-state__icon{font-size:2rem}.orc-empty-state h2,.orc-empty-state p{margin:0}.orc-empty-state p{max-width:36rem;color:var(--orc-text-muted,#64748b)}button{border:0;border-radius:.5rem;padding:.55rem .85rem;background:var(--orc-interactive,#2563eb);color:var(--orc-on-interactive,#fff);font:inherit;cursor:pointer}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-empty-state', standalone: true, template: `<section
    class="orc-empty-state orc-p2-empty-state"
    [attr.aria-label]="title()"
  >
    <div class="orc-empty-state__icon icon" aria-hidden="true">
      {{ icon() }}
    </div>
    @if (title()) {
      <h2>{{ title() }}</h2>
    }
    @if (description()) {
      <p>{{ description() }}</p>
    }
    @if (actionLabel()) {
      <button type="button" (click)="action.emit()">{{ actionLabel() }}</button>
    }
    <ng-content />
  </section>`, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}.orc-empty-state{display:grid;justify-items:center;gap:.6rem;padding:3rem 1.5rem;border:1px dashed var(--orc-border-strong,#cbd5e1);border-radius:.75rem;text-align:center;color:var(--orc-text,#0f172a)}.orc-empty-state__icon{font-size:2rem}.orc-empty-state h2,.orc-empty-state p{margin:0}.orc-empty-state p{max-width:36rem;color:var(--orc-text-muted,#64748b)}button{border:0;border-radius:.5rem;padding:.55rem .85rem;background:var(--orc-interactive,#2563eb);color:var(--orc-on-interactive,#fff);font:inherit;cursor:pointer}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], actionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "actionLabel", required: false }] }], action: [{ type: i0.Output, args: ["action"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { EmptyStateComponent };
//# sourceMappingURL=ciag-orchestra-empty-state.mjs.map
