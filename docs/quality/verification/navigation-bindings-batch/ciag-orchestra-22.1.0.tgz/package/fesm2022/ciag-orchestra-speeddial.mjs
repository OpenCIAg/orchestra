export * from '@ciag/orchestra/speed-dial';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-speeddial.mjs.map
