export { FileUploaderComponent as FileUpload, FileUploaderComponent as FileUploadComponent } from '@ciag/orchestra/file-uploader';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-file-upload.mjs.map
