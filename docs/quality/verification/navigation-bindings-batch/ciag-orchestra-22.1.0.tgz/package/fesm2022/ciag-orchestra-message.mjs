export { AlertComponent as MessageComponent } from '@ciag/orchestra/alert';
export { MessagesComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-message.mjs.map
