export { RadioButtonComponent as RadioButton, RadioButtonComponent } from '@ciag/orchestra/radio';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-radio-button.mjs.map
