export { DrawerComponent as SidebarComponent } from '@ciag/orchestra/drawer';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-sidebar.mjs.map
