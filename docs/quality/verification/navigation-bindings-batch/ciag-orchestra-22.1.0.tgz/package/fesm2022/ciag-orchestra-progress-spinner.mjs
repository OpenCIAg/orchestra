export { ProgressSpinnerComponent as ProgressSpinner, ProgressSpinnerComponent } from '@ciag/orchestra/progress';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-progress-spinner.mjs.map
