import * as i0 from '@angular/core';
import { input, booleanAttribute, Directive, HostListener, ContentChildren, ChangeDetectionStrategy, Component } from '@angular/core';

class ToolbarItemDirective {
    elementRef;
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    constructor(elementRef) {
        this.elementRef = elementRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarItemDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ToolbarItemDirective, isStandalone: true, selector: "[orcToolbarItem]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.tabindex": "disabled() ? -1 : -1", "attr.aria-disabled": "disabled() ? \"true\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarItemDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[orcToolbarItem]',
                    standalone: true,
                    host: {
                        '[attr.tabindex]': 'disabled() ? -1 : -1',
                        '[attr.aria-disabled]': 'disabled() ? "true" : null',
                    },
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class ToolbarComponent {
    items;
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    loop = input(true, { ...(ngDevMode ? { debugName: "loop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ngAfterContentInit() { this.updateTabStops(0); }
    updateTabStops(activeIndex) {
        const enabled = this.items?.toArray().filter(item => !item.disabled()) ?? [];
        enabled.forEach((item, index) => item.elementRef.nativeElement.setAttribute('tabindex', index === activeIndex ? '0' : '-1'));
    }
    onFocusIn() {
        const enabled = this.items?.toArray().filter(item => !item.disabled()) ?? [];
        const index = enabled.findIndex(item => item.elementRef.nativeElement === document.activeElement);
        if (index >= 0)
            this.updateTabStops(index);
    }
    onKeydown(event) {
        const forward = this.orientation() === 'horizontal' ? event.key === 'ArrowRight' : event.key === 'ArrowDown';
        const backward = this.orientation() === 'horizontal' ? event.key === 'ArrowLeft' : event.key === 'ArrowUp';
        if (!forward && !backward && event.key !== 'Home' && event.key !== 'End')
            return;
        const items = this.items?.toArray().filter(item => !item.disabled()) ?? [];
        if (!items.length)
            return;
        const active = document.activeElement;
        let index = items.findIndex(item => item.elementRef.nativeElement === active);
        if (event.key === 'Home')
            index = 0;
        else if (event.key === 'End')
            index = items.length - 1;
        else {
            if (index < 0)
                index = forward ? -1 : items.length;
            const next = index + (forward ? 1 : -1);
            if (next >= 0 && next < items.length)
                index = next;
            else if (this.loop())
                index = (next + items.length) % items.length;
            else
                return;
        }
        event.preventDefault();
        this.updateTabStops(index);
        items[index].elementRef.nativeElement.focus();
    }
    handleKeydown(event) { this.onKeydown(event); }
    handleFocusIn() { this.onFocusIn(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: ToolbarComponent, isStandalone: true, selector: "orc-toolbar", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, loop: { classPropertyName: "loop", publicName: "loop", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "keydown": "handleKeydown($event)", "focusin": "handleFocusIn()" } }, queries: [{ propertyName: "items", predicate: ToolbarItemDirective, descendants: true }], ngImport: i0, template: "<div class=\"orc-toolbar\" [class]=\"styleClass()\" [class.orc-toolbar--vertical]=\"orientation() === 'vertical'\" role=\"toolbar\" [attr.aria-label]=\"label() || null\" [attr.aria-labelledby]=\"ariaLabelledBy()\" [attr.aria-orientation]=\"orientation()\"><ng-content /></div>\n", styles: [":host{display:block}.orc-toolbar{display:flex;align-items:center;gap:6px;width:fit-content;max-width:100%;padding:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-toolbar--vertical{flex-direction:column;align-items:stretch}.orc-toolbar ::ng-deep [orcToolbarItem]{min-height:34px;padding:6px 10px;border:0;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-text, var(--text-primary, #141414));font:inherit;cursor:pointer}.orc-toolbar ::ng-deep [orcToolbarItem]:hover{background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-toolbar ::ng-deep [orcToolbarItem]:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:1px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-toolbar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-toolbar\" [class]=\"styleClass()\" [class.orc-toolbar--vertical]=\"orientation() === 'vertical'\" role=\"toolbar\" [attr.aria-label]=\"label() || null\" [attr.aria-labelledby]=\"ariaLabelledBy()\" [attr.aria-orientation]=\"orientation()\"><ng-content /></div>\n", styles: [":host{display:block}.orc-toolbar{display:flex;align-items:center;gap:6px;width:fit-content;max-width:100%;padding:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:var(--radius-md, 10px);background:var(--orc-surface-subtle, var(--bg-subtle, #f7f8fa))}.orc-toolbar--vertical{flex-direction:column;align-items:stretch}.orc-toolbar ::ng-deep [orcToolbarItem]{min-height:34px;padding:6px 10px;border:0;border-radius:var(--radius-sm, 6px);background:transparent;color:var(--orc-text, var(--text-primary, #141414));font:inherit;cursor:pointer}.orc-toolbar ::ng-deep [orcToolbarItem]:hover{background:var(--orc-surface-raised, var(--fill-modal, #fff))}.orc-toolbar ::ng-deep [orcToolbarItem]:focus-visible{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:1px}\n"] }]
        }], propDecorators: { items: [{
                type: ContentChildren,
                args: [ToolbarItemDirective, { descendants: true }]
            }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], loop: [{ type: i0.Input, args: [{ isSignal: true, alias: "loop", required: false }] }], handleKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], handleFocusIn: [{
                type: HostListener,
                args: ['focusin']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ToolbarComponent, ToolbarItemDirective };
//# sourceMappingURL=ciag-orchestra-toolbar.mjs.map
