export * from '@ciag/orchestra/use-style';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-usestyle.mjs.map
