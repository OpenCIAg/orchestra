export { ScrollTopComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-scroll-top.mjs.map
