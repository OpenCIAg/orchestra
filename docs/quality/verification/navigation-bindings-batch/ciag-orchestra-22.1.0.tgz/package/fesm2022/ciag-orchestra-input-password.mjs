export { PasswordComponent as InputPassword, PasswordComponent as InputPasswordComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-input-password.mjs.map
