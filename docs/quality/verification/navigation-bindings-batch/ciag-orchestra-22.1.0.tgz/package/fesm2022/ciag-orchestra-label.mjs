export { FormFieldComponent as LabelComponent } from '@ciag/orchestra/form-field';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-label.mjs.map
