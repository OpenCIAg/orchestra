export { ProgressBarComponent } from '@ciag/orchestra/progress';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-progress-bar.mjs.map
