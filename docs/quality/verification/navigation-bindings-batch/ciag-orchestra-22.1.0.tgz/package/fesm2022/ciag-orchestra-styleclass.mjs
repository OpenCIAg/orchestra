export * from '@ciag/orchestra/style-class';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-styleclass.mjs.map
