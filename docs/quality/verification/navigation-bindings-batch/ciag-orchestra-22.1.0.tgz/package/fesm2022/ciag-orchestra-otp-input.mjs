import * as i0 from '@angular/core';
import { InjectionToken, input, booleanAttribute, viewChild, inject, computed, ChangeDetectionStrategy, Component, model, output, signal, viewChildren, effect, forwardRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const ORC_OTP_INPUT = new InjectionToken('ORC_OTP_INPUT');

class OtpSlotComponent {
    index = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []));
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    isFirst = input(false, { ...(ngDevMode ? { debugName: "isFirst" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    isLast = input(false, { ...(ngDevMode ? { debugName: "isLast" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inputElement = viewChild('slotInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    parentContext = inject(ORC_OTP_INPUT, { optional: true });
    value = computed(() => {
        if (!this.parentContext)
            return '';
        const values = this.parentContext.inputValues();
        return values[this.index()] || '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    inputMode = computed(() => {
        return this.parentContext ? this.parentContext.inputMode() : 'numeric';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputMode" }] : /* istanbul ignore next */ []));
    effectivePlaceholder = computed(() => {
        return this.placeholder() || (this.parentContext ? this.parentContext.placeholder() : '');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePlaceholder" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => {
        return this.disabled() || (this.parentContext ? this.parentContext.isDisabled() : false);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isReadonly = computed(() => this.parentContext?.readonly() ?? false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isReadonly" }] : /* istanbul ignore next */ []));
    isMasked = computed(() => this.parentContext?.mask() ?? false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isMasked" }] : /* istanbul ignore next */ []));
    slotTabIndex = computed(() => this.parentContext?.tabindex() ?? 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "slotTabIndex" }] : /* istanbul ignore next */ []));
    isAutofocus = computed(() => this.parentContext?.autofocus() && this.index() === 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isAutofocus" }] : /* istanbul ignore next */ []));
    ariaLabel = computed(() => {
        const label = this.parentContext?.ariaLabel();
        return label ? `${label} ${this.index() + 1}` : `OTP digit ${this.index() + 1}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    onInput(event) {
        this.parentContext?.onSlotInput(event, this.index());
    }
    onKeyDown(event) {
        this.parentContext?.onSlotKeyDown(event, this.index());
    }
    onPaste(event) {
        this.parentContext?.onSlotPaste(event, this.index());
    }
    onFocus() {
        this.parentContext?.onSlotFocus(this.index());
    }
    onFocusEvent(event) {
        this.onFocus();
        this.parentContext?.onSlotFocusEvent(event);
    }
    onBlur(event) {
        this.parentContext?.onSlotBlur(event);
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpSlotComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: OtpSlotComponent, isStandalone: true, selector: "orc-otp-slot", inputs: { index: { classPropertyName: "index", publicName: "index", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, isFirst: { classPropertyName: "isFirst", publicName: "isFirst", isSignal: true, isRequired: false, transformFunction: null }, isLast: { classPropertyName: "isLast", publicName: "isLast", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["slotInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<input\n  #slotInput\n  [type]=\"isMasked() ? 'password' : 'text'\"\n  [attr.inputmode]=\"inputMode()\"\n  [pattern]=\"inputMode() === 'numeric' ? '[0-9]*' : '.*'\"\n  [placeholder]=\"effectivePlaceholder()\"\n  [value]=\"value()\"\n  [disabled]=\"isDisabled()\"\n  [readonly]=\"isReadonly()\"\n  [tabindex]=\"slotTabIndex()\"\n  [autofocus]=\"isAutofocus()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [attr.autocomplete]=\"index() === 0 ? 'one-time-code' : 'off'\"\n  maxlength=\"1\"\n  class=\"otp-input\"\n  [class.otp-input--first]=\"isFirst()\"\n  [class.otp-input--last]=\"isLast()\"\n  (input)=\"onInput($event)\"\n  (keydown)=\"onKeyDown($event)\"\n  (paste)=\"onPaste($event)\"\n  (focus)=\"onFocusEvent($event)\"\n  (blur)=\"onBlur($event)\"\n/>\n", styles: [":host{display:inline-flex}.otp-input{width:36px;height:36px;text-align:center;font-family:var(--font-sans);font-size:.9375rem;font-weight:600;color:var(--orc-text, var(--text-primary));background-color:var(--orc-surface-muted, var(--orc-secondary-bg));border:1px solid transparent;border-radius:0;outline:none;transition:background-color var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast)}.otp-input--first{border-top-left-radius:8px;border-bottom-left-radius:8px}.otp-input--last{border-top-right-radius:8px;border-bottom-right-radius:8px}.otp-input:focus{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));background-color:var(--orc-control-surface, var(--orc-fill-input));box-shadow:0 0 0 2px var(--orc-interactive-shadow);z-index:2}.otp-input::placeholder{color:var(--text-muted);opacity:.5}.otp-input[disabled]{opacity:.5;cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpSlotComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-otp-slot', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input\n  #slotInput\n  [type]=\"isMasked() ? 'password' : 'text'\"\n  [attr.inputmode]=\"inputMode()\"\n  [pattern]=\"inputMode() === 'numeric' ? '[0-9]*' : '.*'\"\n  [placeholder]=\"effectivePlaceholder()\"\n  [value]=\"value()\"\n  [disabled]=\"isDisabled()\"\n  [readonly]=\"isReadonly()\"\n  [tabindex]=\"slotTabIndex()\"\n  [autofocus]=\"isAutofocus()\"\n  [attr.aria-label]=\"ariaLabel()\"\n  [attr.autocomplete]=\"index() === 0 ? 'one-time-code' : 'off'\"\n  maxlength=\"1\"\n  class=\"otp-input\"\n  [class.otp-input--first]=\"isFirst()\"\n  [class.otp-input--last]=\"isLast()\"\n  (input)=\"onInput($event)\"\n  (keydown)=\"onKeyDown($event)\"\n  (paste)=\"onPaste($event)\"\n  (focus)=\"onFocusEvent($event)\"\n  (blur)=\"onBlur($event)\"\n/>\n", styles: [":host{display:inline-flex}.otp-input{width:36px;height:36px;text-align:center;font-family:var(--font-sans);font-size:.9375rem;font-weight:600;color:var(--orc-text, var(--text-primary));background-color:var(--orc-surface-muted, var(--orc-secondary-bg));border:1px solid transparent;border-radius:0;outline:none;transition:background-color var(--transition-fast),border-color var(--transition-fast),box-shadow var(--transition-fast)}.otp-input--first{border-top-left-radius:8px;border-bottom-left-radius:8px}.otp-input--last{border-top-right-radius:8px;border-bottom-right-radius:8px}.otp-input:focus{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));background-color:var(--orc-control-surface, var(--orc-fill-input));box-shadow:0 0 0 2px var(--orc-interactive-shadow);z-index:2}.otp-input::placeholder{color:var(--text-muted);opacity:.5}.otp-input[disabled]{opacity:.5;cursor:not-allowed}\n"] }]
        }], propDecorators: { index: [{ type: i0.Input, args: [{ isSignal: true, alias: "index", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], isFirst: [{ type: i0.Input, args: [{ isSignal: true, alias: "isFirst", required: false }] }], isLast: [{ type: i0.Input, args: [{ isSignal: true, alias: "isLast", required: false }] }], inputElement: [{ type: i0.ViewChild, args: ['slotInput', { isSignal: true }] }] } });

class OtpSeparatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpSeparatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: OtpSeparatorComponent, isStandalone: true, selector: "orc-otp-separator", ngImport: i0, template: `
    <div class="otp-separator" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round">
        <line x1="6" y1="12" x2="18" y2="12" />
      </svg>
    </div>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center}.otp-separator{display:flex;align-items:center;justify-content:center;width:24px;height:36px;color:var(--text-secondary)}.otp-separator svg{width:14px;height:14px;opacity:.8}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpSeparatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-otp-separator', standalone: true, imports: [CommonModule], template: `
    <div class="otp-separator" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round">
        <line x1="6" y1="12" x2="18" y2="12" />
      </svg>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex;align-items:center;justify-content:center}.otp-separator{display:flex;align-items:center;justify-content:center;width:24px;height:36px;color:var(--text-secondary)}.otp-separator svg{width:14px;height:14px;opacity:.8}\n"] }]
        }] });

class OtpGroupComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: OtpGroupComponent, isStandalone: true, selector: "orc-otp-group", ngImport: i0, template: `
    <div class="otp-group">
      <ng-content></ng-content>
    </div>
  `, isInline: true, styles: [":host{display:inline-flex}.otp-group{display:flex;gap:4px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-otp-group', standalone: true, imports: [CommonModule], template: `
    <div class="otp-group">
      <ng-content></ng-content>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex}.otp-group{display:flex;gap:4px}\n"] }]
        }] });

class OtpInputComponent {
    // Inputs
    length = input(6, { ...(ngDevMode ? { debugName: "length" } : /* istanbul ignore next */ {}), transform: (value) => Math.max(1, Number.isFinite(Number(value)) ? Math.floor(Number(value)) : 6) });
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tabindex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    mask = input(false, { ...(ngDevMode ? { debugName: "mask" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    integerOnly = input(false, { ...(ngDevMode ? { debugName: "integerOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    inputMode = input('numeric', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputMode" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    // Computed halves for grouped design
    firstHalfIndices = computed(() => {
        const half = Math.ceil(this.length() / 2);
        return Array.from({ length: half }, (_, i) => i);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstHalfIndices" }] : /* istanbul ignore next */ []));
    secondHalfIndices = computed(() => {
        const half = Math.ceil(this.length() / 2);
        const len = this.length();
        return Array.from({ length: len - half }, (_, i) => half + i);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "secondHalfIndices" }] : /* istanbul ignore next */ []));
    // Model & Outputs
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    completed = output();
    onChange = output();
    onFocus = output();
    onBlur = output();
    // Internal state
    inputValues = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputValues" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    // View children slots to manage focus
    slots = viewChildren(OtpSlotComponent, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "slots" }] : /* istanbul ignore next */ []));
    // Callbacks for ControlValueAccessor
    onModelChange = () => { };
    onTouched = () => { };
    constructor() {
        // Sync external length change to inputValues array size
        effect(() => {
            const len = this.length();
            const currentVal = this.value() || '';
            const newValues = Array.from({ length: len }, (_, i) => currentVal[i] || '');
            this.inputValues.set(newValues);
        });
        // Sync model value changes to inputValues array
        effect(() => {
            const val = this.value() || '';
            const len = this.length();
            const newValues = Array.from({ length: len }, (_, i) => val[i] || '');
            const currentValuesStr = this.inputValues().join('');
            const newValStr = newValues.join('');
            if (currentValuesStr !== newValStr) {
                this.inputValues.set(newValues);
            }
        });
    }
    // ControlValueAccessor implementation
    writeValue(value) {
        const val = value || '';
        this.value.set(val);
        const len = this.length();
        const newValues = Array.from({ length: len }, (_, i) => val[i] || '');
        this.inputValues.set(newValues);
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // Handle Input Changes from Slots
    onSlotInput(event, index) {
        const target = event.target;
        let val = target.value;
        if (this.inputMode() === 'numeric' || this.integerOnly()) {
            val = val.replace(/\D/g, '');
        }
        const currentValues = [...this.inputValues()];
        if (val.length > 1) {
            this.pasteCode(val, index);
            return;
        }
        currentValues[index] = val;
        this.updateValues(currentValues);
        if (val && index < this.length() - 1) {
            this.focusInput(index + 1);
        }
    }
    // Handle key events from Slots
    onSlotKeyDown(event, index) {
        const target = event.target;
        switch (event.key) {
            case 'Backspace':
                if (!target.value && index > 0) {
                    const currentValues = [...this.inputValues()];
                    currentValues[index - 1] = '';
                    this.updateValues(currentValues);
                    this.focusInput(index - 1);
                    event.preventDefault();
                }
                else if (target.value) {
                    const currentValues = [...this.inputValues()];
                    currentValues[index] = '';
                    this.updateValues(currentValues);
                }
                break;
            case 'ArrowLeft':
                if (index > 0) {
                    this.focusInput(index - 1);
                    event.preventDefault();
                }
                break;
            case 'ArrowRight':
                if (index < this.length() - 1) {
                    this.focusInput(index + 1);
                    event.preventDefault();
                }
                break;
        }
    }
    onSlotFocus(index) {
        this.onTouched();
    }
    onSlotPaste(event, index) {
        event.preventDefault();
        const clipboardData = event.clipboardData;
        if (!clipboardData)
            return;
        let pastedText = clipboardData.getData('text') || '';
        if (this.inputMode() === 'numeric' || this.integerOnly()) {
            pastedText = pastedText.replace(/\D/g, '');
        }
        this.pasteCode(pastedText, index);
    }
    pasteCode(code, startIndex) {
        if (!code)
            return;
        const currentValues = [...this.inputValues()];
        const len = this.length();
        let pasteIndex = startIndex;
        for (let i = 0; i < code.length && pasteIndex < len; i++) {
            currentValues[pasteIndex] = code[i];
            pasteIndex++;
        }
        this.updateValues(currentValues);
        const nextFocusIndex = Math.min(pasteIndex, len - 1);
        this.focusInput(nextFocusIndex);
    }
    updateValues(newValues) {
        this.inputValues.set(newValues);
        const combinedValue = newValues.join('');
        this.value.set(combinedValue);
        this.onModelChange(combinedValue);
        this.onChange.emit({ value: combinedValue });
        if (combinedValue.length === this.length()) {
            this.completed.emit(combinedValue);
        }
    }
    focusInput(index) {
        const slotRefs = this.slots();
        const slot = slotRefs[index];
        if (slot) {
            slot.focus();
        }
    }
    onSlotFocusEvent(event) { this.onFocus.emit(event); }
    onSlotBlur(event) { this.onBlur.emit(event); this.onTouched(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OtpInputComponent, isStandalone: true, selector: "orc-otp-input, orc-input-otp", inputs: { length: { classPropertyName: "length", publicName: "length", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, mask: { classPropertyName: "mask", publicName: "mask", isSignal: true, isRequired: false, transformFunction: null }, integerOnly: { classPropertyName: "integerOnly", publicName: "integerOnly", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, inputMode: { classPropertyName: "inputMode", publicName: "inputMode", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", completed: "completed", onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => OtpInputComponent),
                multi: true,
            },
            {
                provide: ORC_OTP_INPUT,
                useExisting: forwardRef(() => OtpInputComponent),
            },
        ], viewQueries: [{ propertyName: "slots", predicate: OtpSlotComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"otp-container\" role=\"group\" [attr.aria-label]=\"ariaLabel() || 'One-time password'\" [class.otp-container--disabled]=\"isDisabled()\" [class]=\"styleClass()\" [class.otp-container--filled]=\"variant() === 'filled'\" [class.otp-container--small]=\"size() === 'small'\" [class.otp-container--large]=\"size() === 'large'\">\n  <!-- Grupo 1 -->\n  <orc-otp-group>\n    @for (idx of firstHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === 0\"\n        [isLast]=\"idx === firstHalfIndices().length - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n\n  <!-- Separador -->\n  <orc-otp-separator></orc-otp-separator>\n\n  <!-- Grupo 2 -->\n  <orc-otp-group>\n    @for (idx of secondHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === secondHalfIndices()[0]\"\n        [isLast]=\"idx === length() - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n</div>\n", styles: [":host{display:inline-flex}.otp-container{display:flex;gap:var(--space-2);align-items:center;width:fit-content}.otp-container--disabled{opacity:.6;pointer-events:none}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: OtpSlotComponent, selector: "orc-otp-slot", inputs: ["index", "placeholder", "disabled", "isFirst", "isLast"] }, { kind: "component", type: OtpSeparatorComponent, selector: "orc-otp-separator" }, { kind: "component", type: OtpGroupComponent, selector: "orc-otp-group" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OtpInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-otp-input, orc-input-otp', standalone: true, imports: [
                        CommonModule,
                        OtpSlotComponent,
                        OtpSeparatorComponent,
                        OtpGroupComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => OtpInputComponent),
                            multi: true,
                        },
                        {
                            provide: ORC_OTP_INPUT,
                            useExisting: forwardRef(() => OtpInputComponent),
                        },
                    ], template: "<div class=\"otp-container\" role=\"group\" [attr.aria-label]=\"ariaLabel() || 'One-time password'\" [class.otp-container--disabled]=\"isDisabled()\" [class]=\"styleClass()\" [class.otp-container--filled]=\"variant() === 'filled'\" [class.otp-container--small]=\"size() === 'small'\" [class.otp-container--large]=\"size() === 'large'\">\n  <!-- Grupo 1 -->\n  <orc-otp-group>\n    @for (idx of firstHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === 0\"\n        [isLast]=\"idx === firstHalfIndices().length - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n\n  <!-- Separador -->\n  <orc-otp-separator></orc-otp-separator>\n\n  <!-- Grupo 2 -->\n  <orc-otp-group>\n    @for (idx of secondHalfIndices(); track idx) {\n      <orc-otp-slot\n        [index]=\"idx\"\n        [isFirst]=\"idx === secondHalfIndices()[0]\"\n        [isLast]=\"idx === length() - 1\"\n      ></orc-otp-slot>\n    }\n  </orc-otp-group>\n</div>\n", styles: [":host{display:inline-flex}.otp-container{display:flex;gap:var(--space-2);align-items:center;width:fit-content}.otp-container--disabled{opacity:.6;pointer-events:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { length: [{ type: i0.Input, args: [{ isSignal: true, alias: "length", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], mask: [{ type: i0.Input, args: [{ isSignal: true, alias: "mask", required: false }] }], integerOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "integerOnly", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], inputMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputMode", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], completed: [{ type: i0.Output, args: ["completed"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], slots: [{ type: i0.ViewChildren, args: [i0.forwardRef(() => OtpSlotComponent), { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ORC_OTP_INPUT, OtpGroupComponent, OtpInputComponent, OtpSeparatorComponent, OtpSlotComponent };
//# sourceMappingURL=ciag-orchestra-otp-input.mjs.map
