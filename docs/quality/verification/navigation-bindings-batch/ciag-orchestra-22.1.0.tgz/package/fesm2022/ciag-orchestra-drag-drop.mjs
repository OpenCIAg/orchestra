import * as i0 from '@angular/core';
import { input, booleanAttribute, output, effect, HostListener, Directive } from '@angular/core';

const SCOPE_MIME = 'application/x-orc-drag-scope';
function scopeMatches(target, transfer) {
    if (!target)
        return true;
    const source = transfer?.getData(SCOPE_MIME);
    if (!source)
        return false;
    const left = Array.isArray(target) ? target : [target];
    const right = source.split(',').map(value => value.trim()).filter(Boolean);
    return left.some(value => right.includes(value));
}
class DraggableDirective {
    element;
    scope = input(undefined, { ...(ngDevMode ? { debugName: "scope" } : /* istanbul ignore next */ {}), alias: 'orcDraggable' });
    pScope = input(undefined, { ...(ngDevMode ? { debugName: "pScope" } : /* istanbul ignore next */ {}), alias: 'pDraggable' });
    dragEffect = input('move', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dragEffect" }] : /* istanbul ignore next */ []));
    dragHandle = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dragHandle" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), alias: 'orcDraggableDisabled', transform: booleanAttribute });
    pDisabled = input(false, { ...(ngDevMode ? { debugName: "pDisabled" } : /* istanbul ignore next */ {}), alias: 'pDraggableDisabled', transform: booleanAttribute });
    onDragStart = output();
    onDragEnd = output();
    onDrag = output();
    constructor(element) {
        this.element = element;
        effect(() => {
            this.element.nativeElement.draggable = !this.isDisabled();
        });
    }
    ngAfterViewInit() { this.element.nativeElement.draggable = !this.isDisabled(); }
    isDisabled() { return this.disabled() || this.pDisabled(); }
    dragStart(event) {
        if (this.isDisabled()) {
            event.preventDefault();
            return;
        }
        if (this.dragHandle() && !event.target?.closest(this.dragHandle())) {
            event.preventDefault();
            return;
        }
        if (event.dataTransfer)
            event.dataTransfer.effectAllowed = this.dragEffect();
        const scopes = this.scope() ?? this.pScope();
        if (event.dataTransfer && scopes) {
            event.dataTransfer.setData(SCOPE_MIME, (Array.isArray(scopes) ? scopes : [scopes]).join(','));
        }
        this.onDragStart.emit(event);
    }
    drag(event) { if (!this.isDisabled())
        this.onDrag.emit(event); }
    dragEnd(event) { if (!this.isDisabled())
        this.onDragEnd.emit(event); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DraggableDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: DraggableDirective, isStandalone: true, selector: "[orcDraggable], [pDraggable]", inputs: { scope: { classPropertyName: "scope", publicName: "orcDraggable", isSignal: true, isRequired: false, transformFunction: null }, pScope: { classPropertyName: "pScope", publicName: "pDraggable", isSignal: true, isRequired: false, transformFunction: null }, dragEffect: { classPropertyName: "dragEffect", publicName: "dragEffect", isSignal: true, isRequired: false, transformFunction: null }, dragHandle: { classPropertyName: "dragHandle", publicName: "dragHandle", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "orcDraggableDisabled", isSignal: true, isRequired: false, transformFunction: null }, pDisabled: { classPropertyName: "pDisabled", publicName: "pDraggableDisabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onDragStart: "onDragStart", onDragEnd: "onDragEnd", onDrag: "onDrag" }, host: { listeners: { "dragstart": "dragStart($event)", "drag": "drag($event)", "dragend": "dragEnd($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DraggableDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[orcDraggable], [pDraggable]', standalone: true }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { scope: [{ type: i0.Input, args: [{ isSignal: true, alias: "orcDraggable", required: false }] }], pScope: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDraggable", required: false }] }], dragEffect: [{ type: i0.Input, args: [{ isSignal: true, alias: "dragEffect", required: false }] }], dragHandle: [{ type: i0.Input, args: [{ isSignal: true, alias: "dragHandle", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "orcDraggableDisabled", required: false }] }], pDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDraggableDisabled", required: false }] }], onDragStart: [{ type: i0.Output, args: ["onDragStart"] }], onDragEnd: [{ type: i0.Output, args: ["onDragEnd"] }], onDrag: [{ type: i0.Output, args: ["onDrag"] }], dragStart: [{
                type: HostListener,
                args: ['dragstart', ['$event']]
            }], drag: [{
                type: HostListener,
                args: ['drag', ['$event']]
            }], dragEnd: [{
                type: HostListener,
                args: ['dragend', ['$event']]
            }] } });
class DroppableDirective {
    element;
    scope = input(undefined, { ...(ngDevMode ? { debugName: "scope" } : /* istanbul ignore next */ {}), alias: 'orcDroppable' });
    pScope = input(undefined, { ...(ngDevMode ? { debugName: "pScope" } : /* istanbul ignore next */ {}), alias: 'pDroppable' });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), alias: 'orcDroppableDisabled', transform: booleanAttribute });
    pDisabled = input(false, { ...(ngDevMode ? { debugName: "pDisabled" } : /* istanbul ignore next */ {}), alias: 'pDroppableDisabled', transform: booleanAttribute });
    dropEffect = input('move', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropEffect" }] : /* istanbul ignore next */ []));
    onDragEnter = output();
    onDragLeave = output();
    onDrop = output();
    active = false;
    constructor(element) {
        this.element = element;
        effect(() => {
            this.element.nativeElement.setAttribute('aria-dropeffect', this.dropEffect());
        });
    }
    ngAfterViewInit() { this.element.nativeElement.setAttribute('aria-dropeffect', this.dropEffect()); }
    isDisabled() { return this.disabled() || this.pDisabled(); }
    dragOver(event) { if (this.isDisabled() || !scopeMatches(this.scope() ?? this.pScope(), event.dataTransfer))
        return; event.preventDefault(); if (event.dataTransfer)
        event.dataTransfer.dropEffect = this.dropEffect(); }
    dragEnter(event) { if (this.isDisabled() || !scopeMatches(this.scope() ?? this.pScope(), event.dataTransfer))
        return; event.preventDefault(); this.active = true; this.onDragEnter.emit(event); }
    dragLeave(event) { if (this.isDisabled())
        return; this.active = false; this.onDragLeave.emit(event); }
    drop(event) { if (this.isDisabled())
        return; event.preventDefault(); this.active = false; this.onDrop.emit(event); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DroppableDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: DroppableDirective, isStandalone: true, selector: "[orcDroppable], [pDroppable]", inputs: { scope: { classPropertyName: "scope", publicName: "orcDroppable", isSignal: true, isRequired: false, transformFunction: null }, pScope: { classPropertyName: "pScope", publicName: "pDroppable", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "orcDroppableDisabled", isSignal: true, isRequired: false, transformFunction: null }, pDisabled: { classPropertyName: "pDisabled", publicName: "pDroppableDisabled", isSignal: true, isRequired: false, transformFunction: null }, dropEffect: { classPropertyName: "dropEffect", publicName: "dropEffect", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onDragEnter: "onDragEnter", onDragLeave: "onDragLeave", onDrop: "onDrop" }, host: { listeners: { "dragover": "dragOver($event)", "dragenter": "dragEnter($event)", "dragleave": "dragLeave($event)", "drop": "drop($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DroppableDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[orcDroppable], [pDroppable]', standalone: true }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { scope: [{ type: i0.Input, args: [{ isSignal: true, alias: "orcDroppable", required: false }] }], pScope: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDroppable", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "orcDroppableDisabled", required: false }] }], pDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDroppableDisabled", required: false }] }], dropEffect: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropEffect", required: false }] }], onDragEnter: [{ type: i0.Output, args: ["onDragEnter"] }], onDragLeave: [{ type: i0.Output, args: ["onDragLeave"] }], onDrop: [{ type: i0.Output, args: ["onDrop"] }], dragOver: [{
                type: HostListener,
                args: ['dragover', ['$event']]
            }], dragEnter: [{
                type: HostListener,
                args: ['dragenter', ['$event']]
            }], dragLeave: [{
                type: HostListener,
                args: ['dragleave', ['$event']]
            }], drop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DraggableDirective, DroppableDirective };
//# sourceMappingURL=ciag-orchestra-drag-drop.mjs.map
