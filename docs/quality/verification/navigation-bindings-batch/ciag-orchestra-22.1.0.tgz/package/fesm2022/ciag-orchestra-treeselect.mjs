export * from '@ciag/orchestra/tree-select';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-treeselect.mjs.map
