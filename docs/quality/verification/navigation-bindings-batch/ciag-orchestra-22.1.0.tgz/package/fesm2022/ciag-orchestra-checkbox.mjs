import * as i0 from '@angular/core';
import { input, booleanAttribute, model, output, viewChild, signal, computed, effect, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

let nextCheckboxUniqueId = 0;
class CheckboxComponent {
    // Inputs (Signals API)
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    value = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    description = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    error = input(false, { ...(ngDevMode ? { debugName: "error" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledby = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledby" }] : /* istanbul ignore next */ []));
    ariaDescribedby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedby" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    binary = input(false, { ...(ngDevMode ? { debugName: "binary" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    trueValue = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trueValue" }] : /* istanbul ignore next */ []));
    falseValue = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "falseValue" }] : /* istanbul ignore next */ []));
    variant = input('outlined', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    // Two-way Models (Signals API)
    checked = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    indeterminate = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indeterminate" }] : /* istanbul ignore next */ []));
    // Outputs (Signals API)
    change = output();
    onChange = output();
    onFocus = output();
    onBlur = output();
    // Element reference ao input nativo para controle de foco
    inputElement = viewChild('nativeInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    // ID interno único
    uniqueId = `orc-checkbox-${++nextCheckboxUniqueId}`;
    // Estado interno para ControlValueAccessor
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    cvaValue = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaValue" }] : /* istanbul ignore next */ []));
    // Identificadores e estados derivados (Signals)
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    labelId = computed(() => `${this.effectiveId()}-label`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelId" }] : /* istanbul ignore next */ []));
    descriptionId = computed(() => `${this.effectiveId()}-desc`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "descriptionId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isError = computed(() => this.error() || !!this.errorMessage(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isError" }] : /* istanbul ignore next */ []));
    // Acessibilidade WCAG: aria-checked com suporte a "mixed" para indeterminate
    ariaChecked = computed(() => {
        if (this.indeterminate()) {
            return 'mixed';
        }
        return this.checked() ? 'true' : 'false';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaChecked" }] : /* istanbul ignore next */ []));
    computedAriaDescribedBy = computed(() => {
        if (this.ariaDescribedby())
            return this.ariaDescribedby();
        if (this.errorMessage())
            return this.errorId();
        if (this.description())
            return this.descriptionId();
        return null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaDescribedBy" }] : /* istanbul ignore next */ []));
    hasContent = computed(() => {
        return !!this.label() || !!this.description() || !!this.errorMessage();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasContent" }] : /* istanbul ignore next */ []));
    // Callbacks do ControlValueAccessor
    onModelChange = () => { };
    onTouched = () => { };
    constructor() {
        effect(() => {
            const native = this.inputElement()?.nativeElement;
            if (native)
                native.indeterminate = this.indeterminate();
        });
    }
    // ── ControlValueAccessor Implementation ───────────────────
    writeValue(val) {
        this.cvaValue.set(val);
        this.checked.set(this.binary() ? val === this.trueValue() : Array.isArray(val) ? val.some(item => item === this.value()) : Boolean(val));
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Event Handlers ────────────────────────────────────────
    onNativeChange(event) {
        // The component emits a structured change output below. Prevent the
        // native event from reaching a host listener a second time.
        event.stopPropagation();
        if (this.isDisabled()) {
            event.preventDefault();
            return;
        }
        const input = event.target;
        // Native checkboxes do not implement readonly behavior themselves. Keep
        // the input focusable, but restore its visual state and suppress updates.
        if (this.readonly()) {
            event.preventDefault();
            input.checked = this.checked();
            input.indeterminate = this.indeterminate();
            return;
        }
        // Se estava em estado indeterminado, alternar limpa o indeterminado e marca como checado
        if (this.indeterminate()) {
            this.indeterminate.set(false);
            this.checked.set(true);
        }
        else {
            this.checked.set(input.checked);
        }
        const newChecked = this.checked();
        const emittedValue = this.nextModelValue(newChecked);
        this.cvaValue.set(emittedValue);
        this.onModelChange(emittedValue);
        this.onTouched();
        const eventValue = { checked: newChecked, indeterminate: this.indeterminate(), value: this.value() };
        this.change.emit(eventValue);
        this.onChange.emit(eventValue);
    }
    handleBlur(event) {
        this.onTouched();
        if (event)
            this.onBlur.emit(event);
    }
    handleFocus(event) { this.onFocus.emit(event); }
    /*
      The output value follows PrimeNG's binary/trueValue/falseValue contract,
      while `checked` remains the visual boolean state used by Orchestra.
    */
    modelValue() { return this.nextModelValue(this.checked()); }
    /* legacy method retained for callers that used the old boolean-only API */
    onLegacyBlur() { this.onTouched(); }
    // ── Public API Methods ────────────────────────────────────
    toggle() {
        if (this.isDisabled() || this.readonly())
            return;
        if (this.indeterminate()) {
            this.indeterminate.set(false);
            this.checked.set(true);
        }
        else {
            this.checked.update((c) => !c);
        }
        const newChecked = this.checked();
        const emittedValue = this.nextModelValue(this.checked());
        this.cvaValue.set(emittedValue);
        this.onModelChange(emittedValue);
        this.onTouched();
        const eventValue = {
            checked: newChecked,
            indeterminate: this.indeterminate(),
            value: this.value(),
        };
        this.change.emit(eventValue);
        this.onChange.emit(eventValue);
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    nextModelValue(checked) {
        if (this.binary())
            return checked ? this.trueValue() : this.falseValue();
        const current = this.cvaValue();
        if (!Array.isArray(current) || this.value() === undefined)
            return checked;
        return checked
            ? current.some(item => item === this.value()) ? current : [...current, this.value()]
            : current.filter(item => item !== this.value());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: CheckboxComponent, isStandalone: true, selector: "orc-checkbox", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledby: { classPropertyName: "ariaLabelledby", publicName: "ariaLabelledby", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "ariaDescribedby", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, binary: { classPropertyName: "binary", publicName: "binary", isSignal: true, isRequired: false, transformFunction: null }, trueValue: { classPropertyName: "trueValue", publicName: "trueValue", isSignal: true, isRequired: false, transformFunction: null }, falseValue: { classPropertyName: "falseValue", publicName: "falseValue", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange", indeterminate: "indeterminateChange", change: "change", onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CheckboxComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["nativeInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<label\n  class=\"p-checkbox p-component orc-checkbox\"\n  [class]=\"'p-checkbox p-component orc-checkbox ' + styleClass()\"\n  [class.orc-checkbox--checked]=\"checked() && !indeterminate()\"\n  [class.orc-checkbox--indeterminate]=\"indeterminate()\"\n  [class.orc-checkbox--disabled]=\"isDisabled()\"\n  [class.orc-checkbox--error]=\"isError()\"\n  [class.p-checkbox-checked]=\"checked() && !indeterminate()\"\n  [class.p-checkbox-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'checkbox'\"\n    [attr.for]=\"inputId() || effectiveId()\"\n>\n  <!-- Visually hidden native checkbox input for complete a11y, keyboard navigation (Space key) and Form bindings -->\n  <input\n    #nativeInput\n    type=\"checkbox\"\n    class=\"p-checkbox-input orc-checkbox__native-input\"\n    [id]=\"inputId() || effectiveId()\"\n    [name]=\"name() || null\"\n    [checked]=\"checked()\"\n    [disabled]=\"isDisabled()\"\n    [readOnly]=\"readonly()\"\n    [required]=\"required()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || ariaLabelledby() || null\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-checked]=\"ariaChecked()\"\n    [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onNativeChange($event)\"\n    (focus)=\"handleFocus($event)\"\n    (blur)=\"handleBlur($event)\"\n  />\n\n  <!-- Visual Custom Checkbox matching Figma 382:5024 (16x16px, 4px border radius) -->\n  <span class=\"p-checkbox-box orc-checkbox__box\" aria-hidden=\"true\">\n    <!-- Checked Checkmark Icon -->\n    <svg\n      *ngIf=\"checked() && !indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--check\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8.2L6.5 11.2L12.5 4.8\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.8\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n\n    <!-- Indeterminate Dash Icon -->\n    <svg\n      *ngIf=\"indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--dash\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8H12.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n      />\n    </svg>\n  </span>\n\n  <!-- Label, Description / Error & Content Projection -->\n  <span class=\"orc-checkbox__content\" *ngIf=\"hasContent()\">\n    <span class=\"orc-checkbox__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-checkbox__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-checkbox__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </span>\n\n  <span class=\"orc-checkbox__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-checkbox{display:inline-flex;align-items:flex-start;gap:11px;position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428}.orc-checkbox__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-checkbox__box{display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-top:2px;flex-shrink:0;position:relative;border-radius:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-on-interactive, #ffffff);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-checkbox__icon{width:12px;height:12px;display:block;animation:orc-checkbox-appear var(--transition-fast, .12s ease)}.orc-checkbox__icon--check,.orc-checkbox__icon--dash{stroke:currentColor}.orc-checkbox__content{display:flex;flex-direction:column}.orc-checkbox__label{font-size:.875rem;font-weight:400;color:var(--orc-text, var(--text-primary, #141414));line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-checkbox__description{font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));line-height:1.4;margin-top:2px}.orc-checkbox__error{font-size:.75rem;color:var(--orc-danger, var(--color-error, #fb2c36));line-height:1.4;margin-top:2px;font-weight:500}.orc-checkbox:hover:not(.orc-checkbox--disabled) .orc-checkbox__box{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-checkbox--checked .orc-checkbox__box{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox--checked .orc-checkbox__label{font-weight:500;color:var(--orc-text, var(--text-primary, #141414))}.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox--indeterminate .orc-checkbox__label{font-weight:500;color:var(--orc-text, var(--text-primary, #141414))}.orc-checkbox--error .orc-checkbox__box{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-checkbox--error.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--error.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-danger, var(--color-error, #fb2c36))!important;border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-checkbox--error .orc-checkbox__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-checkbox--error .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-checkbox--disabled{cursor:not-allowed;opacity:.5}.orc-checkbox--disabled .orc-checkbox__box{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-checkbox--disabled.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--disabled.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-text-secondary, var(--text-secondary, #666666));border-color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-checkbox--disabled .orc-checkbox__label,.orc-checkbox--disabled .orc-checkbox__description{color:var(--orc-text-secondary, var(--text-secondary, #666666))}@keyframes orc-checkbox-appear{0%{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-checkbox', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CheckboxComponent),
                            multi: true,
                        },
                    ], template: "<label\n  class=\"p-checkbox p-component orc-checkbox\"\n  [class]=\"'p-checkbox p-component orc-checkbox ' + styleClass()\"\n  [class.orc-checkbox--checked]=\"checked() && !indeterminate()\"\n  [class.orc-checkbox--indeterminate]=\"indeterminate()\"\n  [class.orc-checkbox--disabled]=\"isDisabled()\"\n  [class.orc-checkbox--error]=\"isError()\"\n  [class.p-checkbox-checked]=\"checked() && !indeterminate()\"\n  [class.p-checkbox-disabled]=\"isDisabled()\"\n  [attr.data-pc-name]=\"'checkbox'\"\n    [attr.for]=\"inputId() || effectiveId()\"\n>\n  <!-- Visually hidden native checkbox input for complete a11y, keyboard navigation (Space key) and Form bindings -->\n  <input\n    #nativeInput\n    type=\"checkbox\"\n    class=\"p-checkbox-input orc-checkbox__native-input\"\n    [id]=\"inputId() || effectiveId()\"\n    [name]=\"name() || null\"\n    [checked]=\"checked()\"\n    [disabled]=\"isDisabled()\"\n    [readOnly]=\"readonly()\"\n    [required]=\"required()\"\n    [attr.aria-label]=\"ariaLabel() || null\"\n    [attr.aria-labelledby]=\"ariaLabelledBy() || ariaLabelledby() || null\"\n    [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n    [attr.aria-checked]=\"ariaChecked()\"\n    [attr.aria-readonly]=\"readonly() ? 'true' : null\"\n    [attr.aria-invalid]=\"isError()\"\n    (change)=\"onNativeChange($event)\"\n    (focus)=\"handleFocus($event)\"\n    (blur)=\"handleBlur($event)\"\n  />\n\n  <!-- Visual Custom Checkbox matching Figma 382:5024 (16x16px, 4px border radius) -->\n  <span class=\"p-checkbox-box orc-checkbox__box\" aria-hidden=\"true\">\n    <!-- Checked Checkmark Icon -->\n    <svg\n      *ngIf=\"checked() && !indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--check\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8.2L6.5 11.2L12.5 4.8\"\n        stroke=\"currentColor\"\n        stroke-width=\"1.8\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n\n    <!-- Indeterminate Dash Icon -->\n    <svg\n      *ngIf=\"indeterminate()\"\n      class=\"orc-checkbox__icon orc-checkbox__icon--dash\"\n      viewBox=\"0 0 16 16\"\n      fill=\"none\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <path\n        d=\"M3.5 8H12.5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n      />\n    </svg>\n  </span>\n\n  <!-- Label, Description / Error & Content Projection -->\n  <span class=\"orc-checkbox__content\" *ngIf=\"hasContent()\">\n    <span class=\"orc-checkbox__label\" [id]=\"labelId()\" *ngIf=\"label()\">{{ label() }}</span>\n    <ng-content></ng-content>\n    <span class=\"orc-checkbox__description\" [id]=\"descriptionId()\" *ngIf=\"description() && !errorMessage()\">\n      {{ description() }}\n    </span>\n    <span class=\"orc-checkbox__error\" [id]=\"errorId()\" *ngIf=\"errorMessage()\">\n      {{ errorMessage() }}\n    </span>\n  </span>\n\n  <span class=\"orc-checkbox__content\" *ngIf=\"!hasContent()\">\n    <ng-content></ng-content>\n  </span>\n</label>\n", styles: [":host{display:inline-flex}.orc-checkbox{display:inline-flex;align-items:flex-start;gap:11px;position:relative;cursor:pointer;-webkit-user-select:none;user-select:none;font-family:var(--font-sans, \"Poppins\", sans-serif);line-height:1.428}.orc-checkbox__native-input{position:absolute;opacity:0;width:0;height:0;margin:0;padding:0;pointer-events:none}.orc-checkbox__box{display:flex;align-items:center;justify-content:center;width:16px;height:16px;margin-top:2px;flex-shrink:0;position:relative;border-radius:4px;border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));background-color:var(--orc-control-surface, var(--orc-fill-input, #ffffff));color:var(--orc-on-interactive, #ffffff);box-sizing:border-box;transition:background-color var(--transition-fast, .12s ease),border-color var(--transition-fast, .12s ease),box-shadow var(--transition-fast, .12s ease)}.orc-checkbox__icon{width:12px;height:12px;display:block;animation:orc-checkbox-appear var(--transition-fast, .12s ease)}.orc-checkbox__icon--check,.orc-checkbox__icon--dash{stroke:currentColor}.orc-checkbox__content{display:flex;flex-direction:column}.orc-checkbox__label{font-size:.875rem;font-weight:400;color:var(--orc-text, var(--text-primary, #141414));line-height:1.428;transition:color var(--transition-fast, .12s ease),font-weight var(--transition-fast, .12s ease)}.orc-checkbox__description{font-size:.75rem;color:var(--orc-text-secondary, var(--text-secondary, #666666));line-height:1.4;margin-top:2px}.orc-checkbox__error{font-size:.75rem;color:var(--orc-danger, var(--color-error, #fb2c36));line-height:1.4;margin-top:2px;font-weight:500}.orc-checkbox:hover:not(.orc-checkbox--disabled) .orc-checkbox__box{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline:2px solid var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));outline-offset:2px}.orc-checkbox--checked .orc-checkbox__box{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox--checked .orc-checkbox__label{font-weight:500;color:var(--orc-text, var(--text-primary, #141414))}.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-checkbox--indeterminate .orc-checkbox__label{font-weight:500;color:var(--orc-text, var(--text-primary, #141414))}.orc-checkbox--error .orc-checkbox__box{border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-checkbox--error.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--error.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-danger, var(--color-error, #fb2c36))!important;border-color:var(--orc-danger, var(--color-error, #fb2c36))!important}.orc-checkbox--error .orc-checkbox__label{color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-checkbox--error .orc-checkbox__native-input:focus-visible+.orc-checkbox__box{outline-color:var(--orc-danger, var(--color-error, #fb2c36))}.orc-checkbox--disabled{cursor:not-allowed;opacity:.5}.orc-checkbox--disabled .orc-checkbox__box{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-checkbox--disabled.orc-checkbox--checked .orc-checkbox__box,.orc-checkbox--disabled.orc-checkbox--indeterminate .orc-checkbox__box{background-color:var(--orc-text-secondary, var(--text-secondary, #666666));border-color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-checkbox--disabled .orc-checkbox__label,.orc-checkbox--disabled .orc-checkbox__description{color:var(--orc-text-secondary, var(--text-secondary, #666666))}@keyframes orc-checkbox-appear{0%{transform:scale(.6);opacity:0}to{transform:scale(1);opacity:1}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledby", required: false }] }], ariaDescribedby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedby", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], binary: [{ type: i0.Input, args: [{ isSignal: true, alias: "binary", required: false }] }], trueValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "trueValue", required: false }] }], falseValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "falseValue", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], indeterminate: [{ type: i0.Input, args: [{ isSignal: true, alias: "indeterminate", required: false }] }, { type: i0.Output, args: ["indeterminateChange"] }], change: [{ type: i0.Output, args: ["change"] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], inputElement: [{ type: i0.ViewChild, args: ['nativeInput', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CheckboxComponent };
//# sourceMappingURL=ciag-orchestra-checkbox.mjs.map
