import * as i0 from '@angular/core';
import { viewChild, input, booleanAttribute, numberAttribute, model, output, signal, linkedSignal, computed, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

/**
 * Utilitário de máscara leve e sem dependências externas.
 * Suporta tokens padrão:
 * - `0` ou `9`: Apenas dígitos numéricos (0-9)
 * - `A` ou `a`: Apenas letras (a-z, A-Z)
 * - `*`: Alfanumérico (letras e números)
 */
function applyMask(rawVal, maskPattern) {
    if (!rawVal || !maskPattern)
        return rawVal;
    const rawChars = String(rawVal).split('');
    let formatted = '';
    let rawIdx = 0;
    for (let mIdx = 0; mIdx < maskPattern.length && rawIdx < rawChars.length; mIdx++) {
        const maskChar = maskPattern[mIdx];
        const rawChar = rawChars[rawIdx];
        if (maskChar === '0' || maskChar === '9') {
            if (/\d/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                // Ignora caractere não numérico da entrada bruta e tenta o próximo
                rawIdx++;
                mIdx--; // repete a posição da máscara
            }
        }
        else if (maskChar === 'A' || maskChar === 'a') {
            if (/[a-zA-Z]/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                rawIdx++;
                mIdx--;
            }
        }
        else if (maskChar === '*') {
            if (/[a-zA-Z0-9]/.test(rawChar)) {
                formatted += rawChar;
                rawIdx++;
            }
            else {
                rawIdx++;
                mIdx--;
            }
        }
        else {
            // Caractere literal da máscara (ex: '.', '-', '(', ')', '/', ' ')
            formatted += maskChar;
            if (rawChar === maskChar) {
                rawIdx++;
            }
        }
    }
    return formatted;
}
function cleanMask(formattedVal, maskPattern) {
    if (!formattedVal || !maskPattern)
        return formattedVal;
    // Extrai apenas os caracteres que correspondem aos tokens dinâmicos da máscara
    let clean = '';
    const specialChars = new Set(maskPattern.replace(/[09Aa*]/g, '').split(''));
    for (const ch of String(formattedVal)) {
        if (!specialChars.has(ch)) {
            clean += ch;
        }
    }
    return clean;
}

let nextInputUniqueId = 0;
class InputComponent {
    uniqueId = `orc-input-${++nextInputUniqueId}`;
    // ── Native Input Element Reference ────────────────────────
    nativeInputRef = viewChild('nativeInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeInputRef" }] : /* istanbul ignore next */ []));
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    type = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    status = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    /** Optional consumer-provided hint. The library never invents placeholder copy. */
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    clearable = input(false, { ...(ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mask = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mask" }] : /* istanbul ignore next */ []));
    unmaskValue = input(false, { ...(ngDevMode ? { debugName: "unmaskValue" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maxLength = input(undefined, { ...(ngDevMode ? { debugName: "maxLength" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    minLength = input(undefined, { ...(ngDevMode ? { debugName: "minLength" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    min = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    step = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    showCharCount = input(false, { ...(ngDevMode ? { debugName: "showCharCount" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    prefixText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixText" }] : /* istanbul ignore next */ []));
    suffixText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffixText" }] : /* istanbul ignore next */ []));
    autocomplete = input('off', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // Acessibilidade WCAG
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    clearAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    showPasswordAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPasswordAriaLabel" }] : /* istanbul ignore next */ []));
    hidePasswordAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hidePasswordAriaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaDescribedby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedby" }] : /* istanbul ignore next */ []));
    // ── Two-Way Model ─────────────────────────────────────────
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // ── Outputs (Signals API) ─────────────────────────────────
    inputChange = output();
    blur = output();
    focus = output();
    clear = output();
    // ── Estado Interno ────────────────────────────────────────
    isFocused = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFocused" }] : /* istanbul ignore next */ []));
    isPasswordVisible = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isPasswordVisible" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    /**
     * Keeps browser editing state independent from the public model input.
     * Angular may re-apply a parent model value during the same input event;
     * binding the native control to this writable state prevents keystrokes
     * from being visually rolled back before the parent receives valueChange.
     */
    viewValue = linkedSignal(() => this.value(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewValue" }] : /* istanbul ignore next */ []));
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    helperId = computed(() => `${this.effectiveId()}-helper`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    currentType = computed(() => {
        if (this.type() === 'password') {
            return this.isPasswordVisible() ? 'text' : 'password';
        }
        return this.type();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentType" }] : /* istanbul ignore next */ []));
    stringValue = computed(() => {
        const v = this.viewValue();
        const str = v !== null && v !== undefined ? String(v) : '';
        if (this.mask()) {
            return applyMask(str, this.mask());
        }
        return str;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stringValue" }] : /* istanbul ignore next */ []));
    charCount = computed(() => this.stringValue().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "charCount" }] : /* istanbul ignore next */ []));
    effectiveMaxLength = computed(() => {
        if (this.mask()) {
            return this.mask().length;
        }
        return this.maxLength();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveMaxLength" }] : /* istanbul ignore next */ []));
    isClearVisible = computed(() => {
        const hasVal = this.stringValue().length > 0;
        const canClear = this.clearable() || this.type() === 'search';
        return hasVal && canClear && !this.effectiveDisabled() && !this.readonly();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isClearVisible" }] : /* istanbul ignore next */ []));
    isPasswordToggleVisible = computed(() => {
        return this.type() === 'password' && !this.effectiveDisabled();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isPasswordToggleVisible" }] : /* istanbul ignore next */ []));
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby()) {
            ids.push(this.ariaDescribedby());
        }
        if ((this.status() === 'error' || this.errorMessage()) && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaDescribedBy" }] : /* istanbul ignore next */ []));
    // ── ControlValueAccessor ──────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        const val = value ?? '';
        if (this.mask() && val) {
            const masked = applyMask(String(val), this.mask());
            const nextValue = this.unmaskValue() ? cleanMask(masked, this.mask()) : masked;
            this.viewValue.set(nextValue);
            this.value.set(nextValue);
        }
        else {
            this.viewValue.set(val);
            this.value.set(val);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Handlers de Eventos ───────────────────────────────────
    onInput(event) {
        const target = event.target;
        let rawVal = target.value;
        if (this.mask()) {
            const maskedVal = applyMask(rawVal, this.mask());
            target.value = maskedVal;
            const emittedVal = this.unmaskValue() ? cleanMask(maskedVal, this.mask()) : maskedVal;
            this.viewValue.set(emittedVal);
            this.value.set(emittedVal);
            this.onChange(emittedVal);
            this.inputChange.emit(emittedVal);
            return;
        }
        const val = this.type() === 'number' && rawVal !== ''
            ? (target.valueAsNumber || rawVal)
            : rawVal;
        this.viewValue.set(val);
        this.value.set(val);
        this.onChange(val);
        this.inputChange.emit(val);
    }
    onFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
    }
    onBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
    }
    onClear(event) {
        event.preventDefault();
        event.stopPropagation();
        this.viewValue.set('');
        this.value.set('');
        this.onChange('');
        this.onTouched();
        this.inputChange.emit('');
        this.clear.emit();
        this.focusNative();
    }
    togglePasswordVisibility(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isPasswordVisible.update(visible => !visible);
    }
    focusNative() {
        this.nativeInputRef()?.nativeElement.focus();
    }
    select() {
        this.nativeInputRef()?.nativeElement.select();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: InputComponent, isStandalone: true, selector: "orc-input, orc-input-text", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, clearable: { classPropertyName: "clearable", publicName: "clearable", isSignal: true, isRequired: false, transformFunction: null }, mask: { classPropertyName: "mask", publicName: "mask", isSignal: true, isRequired: false, transformFunction: null }, unmaskValue: { classPropertyName: "unmaskValue", publicName: "unmaskValue", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, showCharCount: { classPropertyName: "showCharCount", publicName: "showCharCount", isSignal: true, isRequired: false, transformFunction: null }, prefixText: { classPropertyName: "prefixText", publicName: "prefixText", isSignal: true, isRequired: false, transformFunction: null }, suffixText: { classPropertyName: "suffixText", publicName: "suffixText", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, showPasswordAriaLabel: { classPropertyName: "showPasswordAriaLabel", publicName: "showPasswordAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, hidePasswordAriaLabel: { classPropertyName: "hidePasswordAriaLabel", publicName: "hidePasswordAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "ariaDescribedby", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", inputChange: "inputChange", blur: "blur", focus: "focus", clear: "clear" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => InputComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "nativeInputRef", first: true, predicate: ["nativeInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-inputtext p-component orc-input-container\"\n  [class]=\"'p-inputtext p-component orc-input-container ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-input-container--disabled]=\"effectiveDisabled()\"\n  [class.orc-input-container--readonly]=\"readonly()\"\n  [class.p-input-filled]=\"variant() === 'filled'\"\n  [class.p-input-outlined]=\"variant() === 'outlined'\"\n  [class.p-input-fluid]=\"fluid()\"\n  [attr.data-pc-name]=\"'inputtext'\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-input__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-input__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Input com Prefixos, Sufixos e A\u00E7\u00F5es \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-input-box\"\n    [class.orc-input-box--sm]=\"size() === 'sm'\"\n    [class.orc-input-box--md]=\"size() === 'md'\"\n    [class.orc-input-box--lg]=\"size() === 'lg'\"\n    [class.orc-input-box--focused]=\"isFocused()\"\n    [class.orc-input-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-input-box--readonly]=\"readonly()\"\n    [class.orc-input-box--error]=\"status() === 'error' || !!errorMessage()\"\n    [class.orc-input-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <!-- Prefixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--prefix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[prefix], [orcPrefix]\" />\n      @if (prefixText()) {\n        <span class=\"orc-input__affix-text\">{{ prefixText() }}</span>\n      }\n    </div>\n\n    <!-- Input Nativo -->\n    <input\n      #nativeInput\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [type]=\"currentType()\"\n      [value]=\"stringValue()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [attr.maxlength]=\"effectiveMaxLength() ?? null\"\n      [attr.minlength]=\"minLength() ?? null\"\n      [attr.min]=\"min() ?? null\"\n      [attr.max]=\"max() ?? null\"\n      [attr.step]=\"step() ?? null\"\n      [autocomplete]=\"autocomplete()\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n      [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"p-inputtext p-component orc-input__native\"\n    />\n\n    <!-- Bot\u00E3o de Limpar (Search / Clearable) -->\n    @if (isClearVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__clear-btn\"\n        (click)=\"onClear($event)\"\n        [attr.aria-label]=\"clearAriaLabel() || null\"\n        tabindex=\"0\"\n      >\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\">\n          <path d=\"M4 4l8 8M12 4l-8 8\" />\n        </svg>\n      </button>\n    }\n\n    <!-- Bot\u00E3o de Alternar Senha (Password Toggle) -->\n    @if (isPasswordToggleVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__password-btn\"\n        (click)=\"togglePasswordVisibility($event)\"\n        [attr.aria-label]=\"isPasswordVisible() ? (hidePasswordAriaLabel() || null) : (showPasswordAriaLabel() || null)\"\n        tabindex=\"0\"\n      >\n        @if (isPasswordVisible()) {\n          <!-- \u00CDcone Olho Fechado / Eye Off -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24\" />\n            <line x1=\"1\" y1=\"1\" x2=\"23\" y2=\"23\" />\n          </svg>\n        } @else {\n          <!-- \u00CDcone Olho Aberto / Eye -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z\" />\n            <circle cx=\"12\" cy=\"12\" r=\"3\" />\n          </svg>\n        }\n      </button>\n    }\n\n    <!-- Sufixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--suffix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[suffix], [orcSuffix]\" />\n      @if (suffixText()) {\n        <span class=\"orc-input__affix-text\">{{ suffixText() }}</span>\n      }\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (errorMessage() || helperText() || showCharCount()) {\n    <div class=\"orc-input__footer\">\n      <div class=\"orc-input__message-area\">\n        @if (errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-input__message orc-input__message--error\" role=\"alert\">\n            <svg class=\"orc-input__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-input__message orc-input__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-input__char-count\" [class.orc-input__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-input-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-input-container--disabled{cursor:not-allowed}.orc-input__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-input__required-marker{color:var(--orc-danger, #fb2c36);margin-left:3px;font-weight:700}.orc-input-box{display:flex;align-items:center;width:100%;background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:10px;box-sizing:border-box;gap:8px;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-input-box:hover:not(.orc-input-box--focused):not(.orc-input-box--disabled):not(.orc-input-box--error):not(.orc-input-box--success){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-input-box--focused{background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow),0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-input-box--disabled{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9));opacity:.5;cursor:not-allowed}.orc-input-box--disabled .orc-input__native{cursor:not-allowed}.orc-input-box--readonly{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));cursor:default}.orc-input-box--readonly .orc-input__native{cursor:default}.orc-input-box--error{border-color:var(--orc-danger, #fb2c36)!important}.orc-input-box--error.orc-input-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-danger, #fb2c36) 15%,transparent)!important}.orc-input-box--success{border-color:var(--orc-status-success-fg, var(--color-success, #00c950))!important}.orc-input-box--success.orc-input-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-status-success-fg, var(--color-success, #00c950)) 15%,transparent)!important}.orc-input-box--sm{min-height:36px;padding:0 10px;font-size:13px}.orc-input-box--sm .orc-input__native{font-size:13px}.orc-input-box--md{min-height:44px;padding:0 12px;font-size:14px}.orc-input-box--md .orc-input__native{font-size:14px}.orc-input-box--lg{min-height:52px;padding:0 16px;font-size:15px}.orc-input-box--lg .orc-input__native{font-size:15px}.orc-input__native{flex:1;min-width:0;width:100%;height:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-text, var(--text-primary, #141414));line-height:normal;padding:0;margin:0}.orc-input__native::placeholder{color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;opacity:1}.orc-input__native[type=number]::-webkit-inner-spin-button,.orc-input__native[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.orc-input__native[type=number]{-moz-appearance:textfield}.orc-input__native[type=search]::-webkit-search-cancel-button,.orc-input__native[type=search]::-webkit-search-decoration{-webkit-appearance:none}.orc-input__slot{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-text-secondary, var(--text-secondary, #666666));flex-shrink:0;-webkit-user-select:none;user-select:none}.orc-input__slot:empty{display:none}.orc-input__slot svg{width:16px;height:16px}.orc-input__affix-text{font-size:13px;font-weight:500;color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-input__action-btn{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-text-secondary, var(--text-secondary, #666666));cursor:pointer;outline:none;flex-shrink:0;transition:color var(--transition-fast, .15s ease),background-color var(--transition-fast, .15s ease)}.orc-input__action-btn:hover{color:var(--orc-text, var(--text-primary, #141414));background-color:color-mix(in srgb,var(--orc-text, #141414) 8%,transparent)}.orc-input__action-btn:focus-visible{box-shadow:0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-input__action-btn svg{width:16px;height:16px}.orc-input__clear-btn svg{width:14px;height:14px}.orc-input__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-input__message-area{flex:1;min-width:0}.orc-input__message{margin:0;line-height:1.4}.orc-input__message--helper{color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-input__message--error{color:var(--orc-danger, #fb2c36);display:flex;align-items:center;gap:4px;font-weight:500}.orc-input__message-icon{width:14px;height:14px;flex-shrink:0}.orc-input__char-count{font-size:11px;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-input__char-count--limit{color:var(--orc-danger, #fb2c36);font-weight:600}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-input, orc-input-text', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => InputComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-inputtext p-component orc-input-container\"\n  [class]=\"'p-inputtext p-component orc-input-container ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-input-container--disabled]=\"effectiveDisabled()\"\n  [class.orc-input-container--readonly]=\"readonly()\"\n  [class.p-input-filled]=\"variant() === 'filled'\"\n  [class.p-input-outlined]=\"variant() === 'outlined'\"\n  [class.p-input-fluid]=\"fluid()\"\n  [attr.data-pc-name]=\"'inputtext'\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-input__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-input__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Input com Prefixos, Sufixos e A\u00E7\u00F5es \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-input-box\"\n    [class.orc-input-box--sm]=\"size() === 'sm'\"\n    [class.orc-input-box--md]=\"size() === 'md'\"\n    [class.orc-input-box--lg]=\"size() === 'lg'\"\n    [class.orc-input-box--focused]=\"isFocused()\"\n    [class.orc-input-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-input-box--readonly]=\"readonly()\"\n    [class.orc-input-box--error]=\"status() === 'error' || !!errorMessage()\"\n    [class.orc-input-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <!-- Prefixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--prefix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[prefix], [orcPrefix]\" />\n      @if (prefixText()) {\n        <span class=\"orc-input__affix-text\">{{ prefixText() }}</span>\n      }\n    </div>\n\n    <!-- Input Nativo -->\n    <input\n      #nativeInput\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [type]=\"currentType()\"\n      [value]=\"stringValue()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [attr.maxlength]=\"effectiveMaxLength() ?? null\"\n      [attr.minlength]=\"minLength() ?? null\"\n      [attr.min]=\"min() ?? null\"\n      [attr.max]=\"max() ?? null\"\n      [attr.step]=\"step() ?? null\"\n      [autocomplete]=\"autocomplete()\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n      [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"p-inputtext p-component orc-input__native\"\n    />\n\n    <!-- Bot\u00E3o de Limpar (Search / Clearable) -->\n    @if (isClearVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__clear-btn\"\n        (click)=\"onClear($event)\"\n        [attr.aria-label]=\"clearAriaLabel() || null\"\n        tabindex=\"0\"\n      >\n        <svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\">\n          <path d=\"M4 4l8 8M12 4l-8 8\" />\n        </svg>\n      </button>\n    }\n\n    <!-- Bot\u00E3o de Alternar Senha (Password Toggle) -->\n    @if (isPasswordToggleVisible()) {\n      <button\n        type=\"button\"\n        class=\"orc-input__action-btn orc-input__password-btn\"\n        (click)=\"togglePasswordVisibility($event)\"\n        [attr.aria-label]=\"isPasswordVisible() ? (hidePasswordAriaLabel() || null) : (showPasswordAriaLabel() || null)\"\n        tabindex=\"0\"\n      >\n        @if (isPasswordVisible()) {\n          <!-- \u00CDcone Olho Fechado / Eye Off -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24\" />\n            <line x1=\"1\" y1=\"1\" x2=\"23\" y2=\"23\" />\n          </svg>\n        } @else {\n          <!-- \u00CDcone Olho Aberto / Eye -->\n          <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z\" />\n            <circle cx=\"12\" cy=\"12\" r=\"3\" />\n          </svg>\n        }\n      </button>\n    }\n\n    <!-- Sufixo via ng-content -->\n    <div class=\"orc-input__slot orc-input__slot--suffix\" (click)=\"$event.stopPropagation()\">\n      <ng-content select=\"[suffix], [orcSuffix]\" />\n      @if (suffixText()) {\n        <span class=\"orc-input__affix-text\">{{ suffixText() }}</span>\n      }\n    </div>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (errorMessage() || helperText() || showCharCount()) {\n    <div class=\"orc-input__footer\">\n      <div class=\"orc-input__message-area\">\n        @if (errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-input__message orc-input__message--error\" role=\"alert\">\n            <svg class=\"orc-input__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-input__message orc-input__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-input__char-count\" [class.orc-input__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-input-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-input-container--disabled{cursor:not-allowed}.orc-input__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-input__required-marker{color:var(--orc-danger, #fb2c36);margin-left:3px;font-weight:700}.orc-input-box{display:flex;align-items:center;width:100%;background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:10px;box-sizing:border-box;gap:8px;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-input-box:hover:not(.orc-input-box--focused):not(.orc-input-box--disabled):not(.orc-input-box--error):not(.orc-input-box--success){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-input-box--focused{background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow),0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-input-box--disabled{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9));opacity:.5;cursor:not-allowed}.orc-input-box--disabled .orc-input__native{cursor:not-allowed}.orc-input-box--readonly{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));cursor:default}.orc-input-box--readonly .orc-input__native{cursor:default}.orc-input-box--error{border-color:var(--orc-danger, #fb2c36)!important}.orc-input-box--error.orc-input-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-danger, #fb2c36) 15%,transparent)!important}.orc-input-box--success{border-color:var(--orc-status-success-fg, var(--color-success, #00c950))!important}.orc-input-box--success.orc-input-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-status-success-fg, var(--color-success, #00c950)) 15%,transparent)!important}.orc-input-box--sm{min-height:36px;padding:0 10px;font-size:13px}.orc-input-box--sm .orc-input__native{font-size:13px}.orc-input-box--md{min-height:44px;padding:0 12px;font-size:14px}.orc-input-box--md .orc-input__native{font-size:14px}.orc-input-box--lg{min-height:52px;padding:0 16px;font-size:15px}.orc-input-box--lg .orc-input__native{font-size:15px}.orc-input__native{flex:1;min-width:0;width:100%;height:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-text, var(--text-primary, #141414));line-height:normal;padding:0;margin:0}.orc-input__native::placeholder{color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;opacity:1}.orc-input__native[type=number]::-webkit-inner-spin-button,.orc-input__native[type=number]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.orc-input__native[type=number]{-moz-appearance:textfield}.orc-input__native[type=search]::-webkit-search-cancel-button,.orc-input__native[type=search]::-webkit-search-decoration{-webkit-appearance:none}.orc-input__slot{display:inline-flex;align-items:center;justify-content:center;color:var(--orc-text-secondary, var(--text-secondary, #666666));flex-shrink:0;-webkit-user-select:none;user-select:none}.orc-input__slot:empty{display:none}.orc-input__slot svg{width:16px;height:16px}.orc-input__affix-text{font-size:13px;font-weight:500;color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-input__action-btn{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;padding:0;background:transparent;border:none;border-radius:var(--radius-sm, 4px);color:var(--orc-text-secondary, var(--text-secondary, #666666));cursor:pointer;outline:none;flex-shrink:0;transition:color var(--transition-fast, .15s ease),background-color var(--transition-fast, .15s ease)}.orc-input__action-btn:hover{color:var(--orc-text, var(--text-primary, #141414));background-color:color-mix(in srgb,var(--orc-text, #141414) 8%,transparent)}.orc-input__action-btn:focus-visible{box-shadow:0 0 0 2px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-input__action-btn svg{width:16px;height:16px}.orc-input__clear-btn svg{width:14px;height:14px}.orc-input__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-input__message-area{flex:1;min-width:0}.orc-input__message{margin:0;line-height:1.4}.orc-input__message--helper{color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-input__message--error{color:var(--orc-danger, #fb2c36);display:flex;align-items:center;gap:4px;font-weight:500}.orc-input__message-icon{width:14px;height:14px;flex-shrink:0}.orc-input__char-count{font-size:11px;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-input__char-count--limit{color:var(--orc-danger, #fb2c36);font-weight:600}\n"] }]
        }], propDecorators: { nativeInputRef: [{ type: i0.ViewChild, args: ['nativeInput', { isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], clearable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearable", required: false }] }], mask: [{ type: i0.Input, args: [{ isSignal: true, alias: "mask", required: false }] }], unmaskValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "unmaskValue", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], showCharCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCharCount", required: false }] }], prefixText: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefixText", required: false }] }], suffixText: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffixText", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], showPasswordAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPasswordAriaLabel", required: false }] }], hidePasswordAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "hidePasswordAriaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaDescribedby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedby", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], inputChange: [{ type: i0.Output, args: ["inputChange"] }], blur: [{ type: i0.Output, args: ["blur"] }], focus: [{ type: i0.Output, args: ["focus"] }], clear: [{ type: i0.Output, args: ["clear"] }] } });

let nextTextareaUniqueId = 0;
class TextareaComponent {
    uniqueId = `orc-textarea-${++nextTextareaUniqueId}`;
    // ── Native Textarea Element Reference ─────────────────────
    nativeTextareaRef = viewChild('nativeTextarea', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nativeTextareaRef" }] : /* istanbul ignore next */ []));
    // ── Inputs (Signals API) ──────────────────────────────────
    id = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    inputId = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    status = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    /** Optional consumer-provided hint. The library never invents placeholder copy. */
    placeholder = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helperText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(false, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    rows = input(4, { ...(ngDevMode ? { debugName: "rows" } : /* istanbul ignore next */ {}), transform: (val) => numberAttribute(val, 4) });
    cols = input(undefined, { ...(ngDevMode ? { debugName: "cols" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    resize = input('vertical', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resize" }] : /* istanbul ignore next */ []));
    autoResize = input(false, { ...(ngDevMode ? { debugName: "autoResize" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maxLength = input(undefined, { ...(ngDevMode ? { debugName: "maxLength" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    minLength = input(undefined, { ...(ngDevMode ? { debugName: "minLength" } : /* istanbul ignore next */ {}), transform: (val) => (val !== undefined && val !== null ? numberAttribute(val) : undefined) });
    showCharCount = input(false, { ...(ngDevMode ? { debugName: "showCharCount" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // Acessibilidade WCAG
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaDescribedby = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaDescribedby" }] : /* istanbul ignore next */ []));
    // ── Two-Way Model ─────────────────────────────────────────
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // ── Outputs (Signals API) ─────────────────────────────────
    inputChange = output();
    blur = output();
    focus = output();
    // ── Estado Interno ────────────────────────────────────────
    isFocused = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFocused" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    /** Writable browser state that cannot be rolled back mid-keystroke. */
    viewValue = linkedSignal(() => this.value(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewValue" }] : /* istanbul ignore next */ []));
    // ── Computeds ─────────────────────────────────────────────
    effectiveId = computed(() => this.inputId() || this.id() || this.uniqueId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveId" }] : /* istanbul ignore next */ []));
    helperId = computed(() => `${this.effectiveId()}-helper`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "helperId" }] : /* istanbul ignore next */ []));
    errorId = computed(() => `${this.effectiveId()}-error`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorId" }] : /* istanbul ignore next */ []));
    effectiveDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveDisabled" }] : /* istanbul ignore next */ []));
    stringValue = computed(() => {
        const v = this.viewValue();
        return v !== null && v !== undefined ? String(v) : '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stringValue" }] : /* istanbul ignore next */ []));
    charCount = computed(() => this.stringValue().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "charCount" }] : /* istanbul ignore next */ []));
    computedAriaDescribedBy = computed(() => {
        const ids = [];
        if (this.ariaDescribedby()) {
            ids.push(this.ariaDescribedby());
        }
        if ((this.status() === 'error' || this.errorMessage()) && this.errorMessage()) {
            ids.push(this.errorId());
        }
        else if (this.helperText()) {
            ids.push(this.helperId());
        }
        return ids.length ? ids.join(' ') : null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedAriaDescribedBy" }] : /* istanbul ignore next */ []));
    // ── ControlValueAccessor ──────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    writeValue(value) {
        const nextValue = value ?? '';
        this.viewValue.set(nextValue);
        this.value.set(nextValue);
        this.adjustHeight();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    ngAfterViewInit() {
        this.adjustHeight();
    }
    // ── Handlers de Eventos ───────────────────────────────────
    onInput(event) {
        const target = event.target;
        const val = target.value;
        this.viewValue.set(val);
        this.value.set(val);
        this.onChange(val);
        this.inputChange.emit(val);
        this.adjustHeight();
    }
    onFocus(event) {
        this.isFocused.set(true);
        this.focus.emit(event);
    }
    onBlur(event) {
        this.isFocused.set(false);
        this.onTouched();
        this.blur.emit(event);
    }
    adjustHeight() {
        if (!this.autoResize())
            return;
        const textarea = this.nativeTextareaRef()?.nativeElement;
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = `${textarea.scrollHeight}px`;
        }
    }
    focusNative() {
        this.nativeTextareaRef()?.nativeElement.focus();
    }
    select() {
        this.nativeTextareaRef()?.nativeElement.select();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TextareaComponent, isStandalone: true, selector: "orc-textarea, orc-input-textarea", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helperText: { classPropertyName: "helperText", publicName: "helperText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, cols: { classPropertyName: "cols", publicName: "cols", isSignal: true, isRequired: false, transformFunction: null }, resize: { classPropertyName: "resize", publicName: "resize", isSignal: true, isRequired: false, transformFunction: null }, autoResize: { classPropertyName: "autoResize", publicName: "autoResize", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, showCharCount: { classPropertyName: "showCharCount", publicName: "showCharCount", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "ariaDescribedby", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", inputChange: "inputChange", blur: "blur", focus: "focus" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => TextareaComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "nativeTextareaRef", first: true, predicate: ["nativeTextarea"], descendants: true, isSignal: true }], ngImport: i0, template: "<div\n  class=\"p-inputtextarea p-component orc-textarea-container\"\n  [class]=\"'p-inputtextarea p-component orc-textarea-container ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-textarea-container--disabled]=\"effectiveDisabled()\"\n    [class.orc-textarea-container--readonly]=\"readonly()\"\n    [class.p-inputtextarea-fluid]=\"fluid()\"\n    [attr.data-pc-name]=\"'textarea'\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-textarea__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-textarea__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Textarea \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-textarea-box\"\n    [class.orc-textarea-box--sm]=\"size() === 'sm'\"\n    [class.orc-textarea-box--md]=\"size() === 'md'\"\n    [class.orc-textarea-box--lg]=\"size() === 'lg'\"\n    [class.orc-textarea-box--focused]=\"isFocused()\"\n    [class.orc-textarea-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-textarea-box--readonly]=\"readonly()\"\n      [class.orc-textarea-box--error]=\"status() === 'error' || !!errorMessage()\"\n    [class.orc-textarea-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <textarea\n      #nativeTextarea\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [value]=\"stringValue()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [rows]=\"rows()\"\n      [attr.cols]=\"cols()\"\n      [attr.maxlength]=\"maxLength() ?? null\"\n      [attr.minlength]=\"minLength() ?? null\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n      [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      [style.resize]=\"autoResize() ? 'none' : resize()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"p-inputtextarea p-component orc-textarea__native\"\n    ></textarea>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (errorMessage() || helperText() || showCharCount()) {\n    <div class=\"orc-textarea__footer\">\n      <div class=\"orc-textarea__message-area\">\n        @if (errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-textarea__message orc-textarea__message--error\" role=\"alert\">\n            <svg class=\"orc-textarea__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-textarea__message orc-textarea__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-textarea__char-count\" [class.orc-textarea__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-textarea-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-textarea-container--disabled{cursor:not-allowed}.orc-textarea__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-textarea__required-marker{color:var(--orc-danger, #fb2c36);margin-left:3px;font-weight:700}.orc-textarea-box{display:flex;width:100%;background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:10px;box-sizing:border-box;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-textarea-box:hover:not(.orc-textarea-box--focused):not(.orc-textarea-box--disabled):not(.orc-textarea-box--error):not(.orc-textarea-box--success){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-textarea-box--focused{background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow),0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-textarea-box--disabled{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9));opacity:.5;cursor:not-allowed}.orc-textarea-box--disabled .orc-textarea__native{cursor:not-allowed}.orc-textarea-box--readonly{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));cursor:default}.orc-textarea-box--readonly .orc-textarea__native{cursor:default}.orc-textarea-box--error{border-color:var(--orc-danger, #fb2c36)!important}.orc-textarea-box--error.orc-textarea-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-danger, #fb2c36) 15%,transparent)!important}.orc-textarea-box--success{border-color:var(--orc-status-success-fg, var(--color-success, #00c950))!important}.orc-textarea-box--success.orc-textarea-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-status-success-fg, var(--color-success, #00c950)) 15%,transparent)!important}.orc-textarea-box--sm{padding:8px 10px;font-size:13px}.orc-textarea-box--sm .orc-textarea__native{font-size:13px;min-height:80px}.orc-textarea-box--md{padding:10px 12px;font-size:14px}.orc-textarea-box--md .orc-textarea__native{font-size:14px;min-height:120px}.orc-textarea-box--lg{padding:12px 16px;font-size:15px}.orc-textarea-box--lg .orc-textarea__native{font-size:15px;min-height:160px}.orc-textarea__native{width:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-text, var(--text-primary, #141414));line-height:1.5;padding:0;margin:0}.orc-textarea__native::placeholder{color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;opacity:1}.orc-textarea__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-textarea__message-area{flex:1;min-width:0}.orc-textarea__message{margin:0;line-height:1.4}.orc-textarea__message--helper{color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-textarea__message--error{color:var(--orc-danger, #fb2c36);display:flex;align-items:center;gap:4px;font-weight:500}.orc-textarea__message-icon{width:14px;height:14px;flex-shrink:0}.orc-textarea__char-count{font-size:11px;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-textarea__char-count--limit{color:var(--orc-danger, #fb2c36);font-weight:600}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-textarea, orc-input-textarea', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => TextareaComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-inputtextarea p-component orc-textarea-container\"\n  [class]=\"'p-inputtextarea p-component orc-textarea-container ' + styleClass()\"\n  [style]=\"style()\"\n  [class.orc-textarea-container--disabled]=\"effectiveDisabled()\"\n    [class.orc-textarea-container--readonly]=\"readonly()\"\n    [class.p-inputtextarea-fluid]=\"fluid()\"\n    [attr.data-pc-name]=\"'textarea'\"\n>\n  <!-- \u2500\u2500 R\u00F3tulo / Label \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (label()) {\n    <label [for]=\"effectiveId()\" class=\"orc-textarea__label\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"orc-textarea__required-marker\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n\n  <!-- \u2500\u2500 Caixa do Textarea \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div\n    class=\"orc-textarea-box\"\n    [class.orc-textarea-box--sm]=\"size() === 'sm'\"\n    [class.orc-textarea-box--md]=\"size() === 'md'\"\n    [class.orc-textarea-box--lg]=\"size() === 'lg'\"\n    [class.orc-textarea-box--focused]=\"isFocused()\"\n    [class.orc-textarea-box--disabled]=\"effectiveDisabled()\"\n    [class.orc-textarea-box--readonly]=\"readonly()\"\n      [class.orc-textarea-box--error]=\"status() === 'error' || !!errorMessage()\"\n    [class.orc-textarea-box--success]=\"status() === 'success'\"\n    (click)=\"focusNative()\"\n  >\n    <textarea\n      #nativeTextarea\n      [id]=\"effectiveId()\"\n      [name]=\"name()\"\n      [value]=\"stringValue()\"\n      [attr.placeholder]=\"placeholder() || null\"\n      [disabled]=\"effectiveDisabled()\"\n      [readOnly]=\"readonly()\"\n      [required]=\"required()\"\n      [rows]=\"rows()\"\n      [attr.cols]=\"cols()\"\n      [attr.maxlength]=\"maxLength() ?? null\"\n      [attr.minlength]=\"minLength() ?? null\"\n      [autofocus]=\"autofocus()\"\n      [attr.aria-label]=\"ariaLabel() || null\"\n      [attr.aria-labelledby]=\"ariaLabelledBy() || null\"\n      [attr.aria-invalid]=\"status() === 'error' || errorMessage() ? 'true' : null\"\n      [attr.aria-describedby]=\"computedAriaDescribedBy()\"\n      [style.resize]=\"autoResize() ? 'none' : resize()\"\n      (input)=\"onInput($event)\"\n      (focus)=\"onFocus($event)\"\n      (blur)=\"onBlur($event)\"\n      class=\"p-inputtextarea p-component orc-textarea__native\"\n    ></textarea>\n  </div>\n\n  <!-- \u2500\u2500 Mensagens de Ajuda, Erro e Contador de Caracteres \u2500\u2500\u2500\u2500\u2500\u2500 -->\n  @if (errorMessage() || helperText() || showCharCount()) {\n    <div class=\"orc-textarea__footer\">\n      <div class=\"orc-textarea__message-area\">\n        @if (errorMessage()) {\n          <p [id]=\"errorId()\" class=\"orc-textarea__message orc-textarea__message--error\" role=\"alert\">\n            <svg class=\"orc-textarea__message-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\">\n              <path d=\"M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 4.75a.75.75 0 00-1.5 0v3.5a.75.75 0 001.5 0v-3.5z\" />\n            </svg>\n            <span>{{ errorMessage() }}</span>\n          </p>\n        } @else if (helperText()) {\n          <p [id]=\"helperId()\" class=\"orc-textarea__message orc-textarea__message--helper\">\n            {{ helperText() }}\n          </p>\n        }\n      </div>\n\n      @if (showCharCount()) {\n        <span class=\"orc-textarea__char-count\" [class.orc-textarea__char-count--limit]=\"maxLength() && charCount() >= maxLength()!\">\n          {{ charCount() }}@if (maxLength()) { / {{ maxLength() }} }\n        </span>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-textarea-container{display:flex;flex-direction:column;width:100%;box-sizing:border-box;font-family:var(--font-sans, \"Poppins\", sans-serif)}.orc-textarea-container--disabled{cursor:not-allowed}.orc-textarea__label{display:inline-flex;align-items:center;font-size:14px;font-weight:500;color:var(--orc-text, var(--text-primary, #141414));margin-bottom:6px;-webkit-user-select:none;user-select:none;cursor:pointer}.orc-textarea__required-marker{color:var(--orc-danger, #fb2c36);margin-left:3px;font-weight:700}.orc-textarea-box{display:flex;width:100%;background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border:1px solid var(--orc-border-default, var(--border-default, #d9d9d9));border-radius:10px;box-sizing:border-box;cursor:text;transition:background-color var(--transition-fast, .2s ease),border-color var(--transition-fast, .2s ease),box-shadow var(--transition-fast, .2s ease)}.orc-textarea-box:hover:not(.orc-textarea-box--focused):not(.orc-textarea-box--disabled):not(.orc-textarea-box--error):not(.orc-textarea-box--success){background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));border-color:var(--orc-border-default, var(--border-default, #d9d9d9))}.orc-textarea-box--focused{background-color:var(--orc-control-surface, var(--fill-input, #ffffff));border-color:var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed));box-shadow:0 0 0 3px var(--orc-interactive-shadow),0 0 0 1px var(--orc-interactive, var(--orc-color-azul-eletrico, #1c6aed))}.orc-textarea-box--disabled{background-color:var(--orc-surface-muted, var(--bg-muted, #ededed));border-color:var(--orc-border-default, var(--border-default, #d9d9d9));opacity:.5;cursor:not-allowed}.orc-textarea-box--disabled .orc-textarea__native{cursor:not-allowed}.orc-textarea-box--readonly{background-color:var(--orc-surface-subtle, var(--bg-subtle, #f9f9f9));cursor:default}.orc-textarea-box--readonly .orc-textarea__native{cursor:default}.orc-textarea-box--error{border-color:var(--orc-danger, #fb2c36)!important}.orc-textarea-box--error.orc-textarea-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-danger, #fb2c36) 15%,transparent)!important}.orc-textarea-box--success{border-color:var(--orc-status-success-fg, var(--color-success, #00c950))!important}.orc-textarea-box--success.orc-textarea-box--focused{box-shadow:0 0 0 3px color-mix(in srgb,var(--orc-status-success-fg, var(--color-success, #00c950)) 15%,transparent)!important}.orc-textarea-box--sm{padding:8px 10px;font-size:13px}.orc-textarea-box--sm .orc-textarea__native{font-size:13px;min-height:80px}.orc-textarea-box--md{padding:10px 12px;font-size:14px}.orc-textarea-box--md .orc-textarea__native{font-size:14px;min-height:120px}.orc-textarea-box--lg{padding:12px 16px;font-size:15px}.orc-textarea-box--lg .orc-textarea__native{font-size:15px;min-height:160px}.orc-textarea__native{width:100%;background:transparent;border:none;outline:none;font-family:inherit;color:var(--orc-text, var(--text-primary, #141414));line-height:1.5;padding:0;margin:0}.orc-textarea__native::placeholder{color:var(--orc-text-secondary, var(--text-secondary, #666666));font-weight:400;opacity:1}.orc-textarea__footer{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-top:6px;font-size:12px}.orc-textarea__message-area{flex:1;min-width:0}.orc-textarea__message{margin:0;line-height:1.4}.orc-textarea__message--helper{color:var(--orc-text-secondary, var(--text-secondary, #666666))}.orc-textarea__message--error{color:var(--orc-danger, #fb2c36);display:flex;align-items:center;gap:4px;font-weight:500}.orc-textarea__message-icon{width:14px;height:14px;flex-shrink:0}.orc-textarea__char-count{font-size:11px;color:var(--orc-text-secondary, var(--text-secondary, #666666));white-space:nowrap;margin-left:auto;font-variant-numeric:tabular-nums}.orc-textarea__char-count--limit{color:var(--orc-danger, #fb2c36);font-weight:600}\n"] }]
        }], propDecorators: { nativeTextareaRef: [{ type: i0.ViewChild, args: ['nativeTextarea', { isSignal: true }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helperText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], cols: [{ type: i0.Input, args: [{ isSignal: true, alias: "cols", required: false }] }], resize: [{ type: i0.Input, args: [{ isSignal: true, alias: "resize", required: false }] }], autoResize: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoResize", required: false }] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], showCharCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCharCount", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaDescribedby: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedby", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], inputChange: [{ type: i0.Output, args: ["inputChange"] }], blur: [{ type: i0.Output, args: ["blur"] }], focus: [{ type: i0.Output, args: ["focus"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { InputComponent, TextareaComponent, applyMask, cleanMask };
//# sourceMappingURL=ciag-orchestra-input.mjs.map
