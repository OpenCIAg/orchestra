import * as i0 from '@angular/core';
import { input, numberAttribute, signal, computed, output, ChangeDetectionStrategy, Component, booleanAttribute, inject, forwardRef, HostListener, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { ProgressBarComponent } from '@ciag/orchestra/progress';
import { ButtonComponent } from '@ciag/orchestra/button';

class FileItemComponent {
    // ── Inputs ──────────────────────────────────────────────────
    fileData = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fileData" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    removeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeAriaLabel" }] : /* istanbul ignore next */ []));
    uploadingLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadingLabel" }] : /* istanbul ignore next */ []));
    uploadedLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadedLabel" }] : /* istanbul ignore next */ []));
    errorLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorLabel" }] : /* istanbul ignore next */ []));
    pendingLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pendingLabel" }] : /* istanbul ignore next */ []));
    previewWidth = input(100, { ...(ngDevMode ? { debugName: "previewWidth" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    removeStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeStyleClass" }] : /* istanbul ignore next */ []));
    failedPreview = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "failedPreview" }] : /* istanbul ignore next */ []));
    showPreview = computed(() => this.isImage() &&
        !!this.fileData().previewUrl &&
        this.failedPreview() !== this.fileData().previewUrl, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPreview" }] : /* istanbul ignore next */ []));
    effectivePreviewWidth = computed(() => Number.isFinite(this.previewWidth())
        ? Math.max(1, this.previewWidth())
        : 100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectivePreviewWidth" }] : /* istanbul ignore next */ []));
    // ── Outputs ─────────────────────────────────────────────────
    remove = output();
    imageError = output();
    // ── Computeds ───────────────────────────────────────────────
    isImage = computed(() => {
        return this.fileData().type.startsWith('image/');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isImage" }] : /* istanbul ignore next */ []));
    badgeVariant = computed(() => {
        switch (this.fileData().status) {
            case 'success':
                return 'soft';
            case 'error':
                return 'soft';
            default:
                return 'outline';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "badgeVariant" }] : /* istanbul ignore next */ []));
    badgeStatus = computed(() => {
        switch (this.fileData().status) {
            case 'success':
                return 'success';
            case 'error':
                return 'danger';
            case 'uploading':
                return 'primary';
            default:
                return 'neutral';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "badgeStatus" }] : /* istanbul ignore next */ []));
    showProgress = computed(() => {
        return (this.fileData().status === 'uploading' || this.fileData().progress > 0);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showProgress" }] : /* istanbul ignore next */ []));
    // ── Handlers ────────────────────────────────────────────────
    onRemove() {
        if (this.disabled())
            return;
        this.remove.emit(this.fileData().id);
    }
    onImageError(event) {
        this.failedPreview.set(this.fileData().previewUrl);
        this.imageError.emit({ file: this.fileData().file, originalEvent: event });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FileItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: FileItemComponent, isStandalone: true, selector: "orc-file-item", inputs: { fileData: { classPropertyName: "fileData", publicName: "fileData", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, removeAriaLabel: { classPropertyName: "removeAriaLabel", publicName: "removeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, uploadingLabel: { classPropertyName: "uploadingLabel", publicName: "uploadingLabel", isSignal: true, isRequired: false, transformFunction: null }, uploadedLabel: { classPropertyName: "uploadedLabel", publicName: "uploadedLabel", isSignal: true, isRequired: false, transformFunction: null }, errorLabel: { classPropertyName: "errorLabel", publicName: "errorLabel", isSignal: true, isRequired: false, transformFunction: null }, pendingLabel: { classPropertyName: "pendingLabel", publicName: "pendingLabel", isSignal: true, isRequired: false, transformFunction: null }, previewWidth: { classPropertyName: "previewWidth", publicName: "previewWidth", isSignal: true, isRequired: false, transformFunction: null }, removeStyleClass: { classPropertyName: "removeStyleClass", publicName: "removeStyleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { remove: "remove", imageError: "imageError" }, ngImport: i0, template: "<div class=\"orc-file-item\" role=\"listitem\">\n  <!-- \u00CDcone (20x20) -->\n  <div\n    class=\"orc-file-item__icon-wrapper\"\n    [class.orc-file-item__icon-wrapper--preview]=\"showPreview()\"\n    [style.width.px]=\"showPreview() ? effectivePreviewWidth() : null\"\n  >\n    <div class=\"orc-file-item__icon\">\n      @if (showPreview()) {\n        <img\n          [src]=\"fileData().previewUrl\"\n          [alt]=\"fileData().name\"\n          (error)=\"onImageError($event)\"\n        />\n      } @else if (fileData().type.includes('pdf')) {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path\n            d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n          ></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n          <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n          <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n          <polyline points=\"10 9 9 9 8 9\"></polyline>\n        </svg>\n      } @else if (fileData().type.includes('image')) {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"2\" ry=\"2\"></rect>\n          <circle cx=\"8.5\" cy=\"8.5\" r=\"1.5\"></circle>\n          <polyline points=\"21 15 16 10 5 21\"></polyline>\n        </svg>\n      } @else {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path\n            d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n          ></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n        </svg>\n      }\n    </div>\n  </div>\n\n  <!-- Conte\u00FAdo -->\n  <div class=\"orc-file-item__content\">\n    <!-- Linha 1: T\u00EDtulo e Bot\u00E3o de Remover -->\n    <div class=\"orc-file-item__header\">\n      <span class=\"orc-file-item__name\" [title]=\"fileData().name\">{{\n        fileData().name\n      }}</span>\n      <div class=\"orc-file-item__remove\">\n        <orc-button\n          variant=\"ghost\"\n          size=\"sm\"\n          [iconOnly]=\"true\"\n          [disabled]=\"disabled()\"\n          [styleClass]=\"removeStyleClass()\"\n          (click)=\"onRemove()\"\n          [ariaLabel]=\"removeAriaLabel() || 'Remove ' + fileData().name\"\n        >\n          <svg\n            iconLeft\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          >\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      </div>\n    </div>\n\n    <!-- Linha 2: Status / Progresso -->\n    @if (\n      fileData().status === 'uploading' ||\n      (fileData().progress > 0 &&\n        fileData().status !== 'success' &&\n        fileData().status !== 'error')\n    ) {\n      <div class=\"orc-file-item__progress-container\">\n        <div class=\"orc-file-item__progress-text-row\">\n          <span class=\"orc-file-item__meta\"\n            >{{ fileData().formattedSize }}\n            @if (uploadingLabel()) {\n              | {{ uploadingLabel() }}\n            }\n          </span>\n          <span class=\"orc-file-item__meta\">{{ fileData().progress }}%</span>\n        </div>\n\n        <!-- Figma uses black progress bar (accent) -->\n        <orc-progress-bar\n          [value]=\"fileData().progress\"\n          variant=\"neutral\"\n          size=\"md\"\n        >\n        </orc-progress-bar>\n      </div>\n    } @else {\n      <!-- Estado de Sucesso ou Erro -->\n      <div class=\"orc-file-item__meta\">\n        {{ fileData().formattedSize }} |\n        {{ fileData().status === 'success' ? 100 : fileData().progress }}%\n        @if (fileData().status === 'success') {\n          @if (uploadedLabel()) {\n            | {{ uploadedLabel() }}\n          }\n        } @else if (fileData().status === 'error') {\n          <span class=\"orc-file-item__error\">\n            |\n            {{\n              fileData().errorMessage || errorLabel() || 'Upload failed'\n            }}</span\n          >\n        } @else if (pendingLabel()) {\n          | {{ pendingLabel() }}\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-item{display:flex;align-items:center;gap:15px;padding:10px;background-color:var(--bg-app);border-radius:var(--radius-md)}.orc-file-item__icon-wrapper{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center}.orc-file-item__icon-wrapper--preview{height:auto;max-width:25%}.orc-file-item__icon-wrapper--preview img{display:block;width:100%;max-height:100px;object-fit:contain}.orc-file-item__icon{width:100%;height:100%;color:var(--text-secondary)}.orc-file-item__icon svg{width:100%;height:100%}.orc-file-item__content{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}.orc-file-item__header{display:flex;align-items:flex-start;justify-content:space-between;min-height:32px;gap:var(--spacing-2, 8px)}.orc-file-item__name{font-weight:500;font-size:.875rem;line-height:20px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-file-item__remove{flex-shrink:0;display:flex;align-items:center;justify-content:center}.orc-file-item__progress-container{display:flex;flex-direction:column;gap:4px}.orc-file-item__progress-text-row{display:flex;justify-content:space-between;align-items:center;min-height:16px;gap:var(--spacing-2, 8px)}.orc-file-item__meta{font-size:.75rem;color:var(--text-secondary);line-height:16px;overflow-wrap:anywhere}.orc-file-item__error{color:var(--orc-danger)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ProgressBarComponent, selector: "orc-progress-bar", inputs: ["value", "mode", "variant", "size", "label", "showValue", "unit", "color", "styleClass", "valueStyleClass", "style", "valuePrefix", "valueSuffix", "rounded", "segments", "currentSegment", "customHeight", "customColor", "customTrackColor", "markers", "ariaLabel", "ariaValueText"] }, { kind: "component", type: ButtonComponent, selector: "orc-button", inputs: ["variant", "severity", "size", "disabled", "loading", "fullWidth", "text", "outlined", "raised", "rounded", "plain", "fluid", "link", "icon", "iconPos", "loadingIcon", "id", "tabindex", "ariaLabelledBy", "ariaExpanded", "ariaControls", "form", "styleClass", "style", "badge", "badgeClass", "iconLeft", "iconRight", "iconOnly", "type", "ariaLabel"], outputs: ["clicked", "onFocus", "onBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FileItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-file-item', standalone: true, imports: [CommonModule, ProgressBarComponent, ButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"orc-file-item\" role=\"listitem\">\n  <!-- \u00CDcone (20x20) -->\n  <div\n    class=\"orc-file-item__icon-wrapper\"\n    [class.orc-file-item__icon-wrapper--preview]=\"showPreview()\"\n    [style.width.px]=\"showPreview() ? effectivePreviewWidth() : null\"\n  >\n    <div class=\"orc-file-item__icon\">\n      @if (showPreview()) {\n        <img\n          [src]=\"fileData().previewUrl\"\n          [alt]=\"fileData().name\"\n          (error)=\"onImageError($event)\"\n        />\n      } @else if (fileData().type.includes('pdf')) {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path\n            d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n          ></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n          <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n          <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n          <polyline points=\"10 9 9 9 8 9\"></polyline>\n        </svg>\n      } @else if (fileData().type.includes('image')) {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"2\" ry=\"2\"></rect>\n          <circle cx=\"8.5\" cy=\"8.5\" r=\"1.5\"></circle>\n          <polyline points=\"21 15 16 10 5 21\"></polyline>\n        </svg>\n      } @else {\n        <svg\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path\n            d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n          ></path>\n          <polyline points=\"14 2 14 8 20 8\"></polyline>\n        </svg>\n      }\n    </div>\n  </div>\n\n  <!-- Conte\u00FAdo -->\n  <div class=\"orc-file-item__content\">\n    <!-- Linha 1: T\u00EDtulo e Bot\u00E3o de Remover -->\n    <div class=\"orc-file-item__header\">\n      <span class=\"orc-file-item__name\" [title]=\"fileData().name\">{{\n        fileData().name\n      }}</span>\n      <div class=\"orc-file-item__remove\">\n        <orc-button\n          variant=\"ghost\"\n          size=\"sm\"\n          [iconOnly]=\"true\"\n          [disabled]=\"disabled()\"\n          [styleClass]=\"removeStyleClass()\"\n          (click)=\"onRemove()\"\n          [ariaLabel]=\"removeAriaLabel() || 'Remove ' + fileData().name\"\n        >\n          <svg\n            iconLeft\n            viewBox=\"0 0 24 24\"\n            fill=\"none\"\n            stroke=\"currentColor\"\n            stroke-width=\"2\"\n            stroke-linecap=\"round\"\n            stroke-linejoin=\"round\"\n          >\n            <line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"></line>\n            <line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"></line>\n          </svg>\n        </orc-button>\n      </div>\n    </div>\n\n    <!-- Linha 2: Status / Progresso -->\n    @if (\n      fileData().status === 'uploading' ||\n      (fileData().progress > 0 &&\n        fileData().status !== 'success' &&\n        fileData().status !== 'error')\n    ) {\n      <div class=\"orc-file-item__progress-container\">\n        <div class=\"orc-file-item__progress-text-row\">\n          <span class=\"orc-file-item__meta\"\n            >{{ fileData().formattedSize }}\n            @if (uploadingLabel()) {\n              | {{ uploadingLabel() }}\n            }\n          </span>\n          <span class=\"orc-file-item__meta\">{{ fileData().progress }}%</span>\n        </div>\n\n        <!-- Figma uses black progress bar (accent) -->\n        <orc-progress-bar\n          [value]=\"fileData().progress\"\n          variant=\"neutral\"\n          size=\"md\"\n        >\n        </orc-progress-bar>\n      </div>\n    } @else {\n      <!-- Estado de Sucesso ou Erro -->\n      <div class=\"orc-file-item__meta\">\n        {{ fileData().formattedSize }} |\n        {{ fileData().status === 'success' ? 100 : fileData().progress }}%\n        @if (fileData().status === 'success') {\n          @if (uploadedLabel()) {\n            | {{ uploadedLabel() }}\n          }\n        } @else if (fileData().status === 'error') {\n          <span class=\"orc-file-item__error\">\n            |\n            {{\n              fileData().errorMessage || errorLabel() || 'Upload failed'\n            }}</span\n          >\n        } @else if (pendingLabel()) {\n          | {{ pendingLabel() }}\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-item{display:flex;align-items:center;gap:15px;padding:10px;background-color:var(--bg-app);border-radius:var(--radius-md)}.orc-file-item__icon-wrapper{flex-shrink:0;width:20px;height:20px;display:flex;align-items:center;justify-content:center}.orc-file-item__icon-wrapper--preview{height:auto;max-width:25%}.orc-file-item__icon-wrapper--preview img{display:block;width:100%;max-height:100px;object-fit:contain}.orc-file-item__icon{width:100%;height:100%;color:var(--text-secondary)}.orc-file-item__icon svg{width:100%;height:100%}.orc-file-item__content{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}.orc-file-item__header{display:flex;align-items:flex-start;justify-content:space-between;min-height:32px;gap:var(--spacing-2, 8px)}.orc-file-item__name{font-weight:500;font-size:.875rem;line-height:20px;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.orc-file-item__remove{flex-shrink:0;display:flex;align-items:center;justify-content:center}.orc-file-item__progress-container{display:flex;flex-direction:column;gap:4px}.orc-file-item__progress-text-row{display:flex;justify-content:space-between;align-items:center;min-height:16px;gap:var(--spacing-2, 8px)}.orc-file-item__meta{font-size:.75rem;color:var(--text-secondary);line-height:16px;overflow-wrap:anywhere}.orc-file-item__error{color:var(--orc-danger)}\n"] }]
        }], propDecorators: { fileData: [{ type: i0.Input, args: [{ isSignal: true, alias: "fileData", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], removeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeAriaLabel", required: false }] }], uploadingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadingLabel", required: false }] }], uploadedLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadedLabel", required: false }] }], errorLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorLabel", required: false }] }], pendingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pendingLabel", required: false }] }], previewWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "previewWidth", required: false }] }], removeStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeStyleClass", required: false }] }], remove: [{ type: i0.Output, args: ["remove"] }], imageError: [{ type: i0.Output, args: ["imageError"] }] } });

class FileUploaderComponent {
    fileInputRef;
    // ── Inputs ──────────────────────────────────────────────────
    accept = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ [])); // e.g., 'image/*,.pdf'
    name = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    url = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    method = input('post', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "method" }] : /* istanbul ignore next */ []));
    headers = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headers" }] : /* istanbul ignore next */ []));
    multiple = input(true, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    auto = input(false, { ...(ngDevMode ? { debugName: "auto" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    withCredentials = input(false, { ...(ngDevMode ? { debugName: "withCredentials" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    maxFiles = input(10, { ...(ngDevMode ? { debugName: "maxFiles" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    fileLimit = input(undefined, { ...(ngDevMode ? { debugName: "fileLimit" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    maxFileSize = input(5 * 1024 * 1024, { ...(ngDevMode ? { debugName: "maxFileSize" } : /* istanbul ignore next */ {}), transform: numberAttribute }); // PrimeNG-compatible bytes
    invalidFileSizeMessageSummary = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileSizeMessageSummary" }] : /* istanbul ignore next */ []));
    invalidFileSizeMessageDetail = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileSizeMessageDetail" }] : /* istanbul ignore next */ []));
    invalidFileTypeMessageSummary = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileTypeMessageSummary" }] : /* istanbul ignore next */ []));
    invalidFileTypeMessageDetail = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileTypeMessageDetail" }] : /* istanbul ignore next */ []));
    invalidFileLimitMessageSummary = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileLimitMessageSummary" }] : /* istanbul ignore next */ []));
    invalidFileLimitMessageDetail = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalidFileLimitMessageDetail" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    subLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subLabel" }] : /* istanbul ignore next */ []));
    dropzoneAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropzoneAriaLabel" }] : /* istanbul ignore next */ []));
    chooseLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "chooseLabel" }] : /* istanbul ignore next */ []));
    uploadLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadLabel" }] : /* istanbul ignore next */ []));
    cancelLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelLabel" }] : /* istanbul ignore next */ []));
    removeAriaLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeAriaLabel" }] : /* istanbul ignore next */ []));
    uploadingLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadingLabel" }] : /* istanbul ignore next */ []));
    uploadedLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadedLabel" }] : /* istanbul ignore next */ []));
    errorLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorLabel" }] : /* istanbul ignore next */ []));
    pendingLabel = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pendingLabel" }] : /* istanbul ignore next */ []));
    previewWidth = input(100, { ...(ngDevMode ? { debugName: "previewWidth" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    styleClass = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    style = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []));
    chooseIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "chooseIcon" }] : /* istanbul ignore next */ []));
    uploadIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadIcon" }] : /* istanbul ignore next */ []));
    cancelIcon = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelIcon" }] : /* istanbul ignore next */ []));
    showUploadButton = input(true, { ...(ngDevMode ? { debugName: "showUploadButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCancelButton = input(true, { ...(ngDevMode ? { debugName: "showCancelButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mode = input('advanced', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    customUpload = input(false, { ...(ngDevMode ? { debugName: "customUpload" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    uploadStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploadStyleClass" }] : /* istanbul ignore next */ []));
    cancelStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelStyleClass" }] : /* istanbul ignore next */ []));
    chooseStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "chooseStyleClass" }] : /* istanbul ignore next */ []));
    removeStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "removeStyleClass" }] : /* istanbul ignore next */ []));
    forceDragover = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "forceDragover" }] : /* istanbul ignore next */ []));
    onSelect = output();
    onRemove = output();
    onClear = output();
    onUpload = output();
    onError = output();
    onProgress = output();
    onBeforeUpload = output();
    uploadHandler = output();
    onSend = output();
    onImageError = output();
    onRemoveUploadedFile = output();
    // ── Internal State (Signals) ────────────────────────────────
    files = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "files" }] : /* istanbul ignore next */ []));
    isDragging = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDragging" }] : /* istanbul ignore next */ []));
    cvaDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cvaDisabled" }] : /* istanbul ignore next */ []));
    http = inject(HttpClient, { optional: true });
    uploadSubscription;
    ownedPreviewUrls = new Set();
    validationMessage = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "validationMessage" }] : /* istanbul ignore next */ []));
    uploading = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uploading" }] : /* istanbul ignore next */ []));
    // ── CVA callbacks ───────────────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    // ── Computeds ───────────────────────────────────────────────
    isDisabled = computed(() => this.disabled() || this.cvaDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    effectiveFileLimit = computed(() => {
        const configured = this.fileLimit() ?? this.maxFiles();
        const limit = Number.isFinite(configured)
            ? Math.max(0, Math.floor(configured))
            : 10;
        return this.multiple() ? limit : Math.min(1, limit);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveFileLimit" }] : /* istanbul ignore next */ []));
    hasReachedMaxFiles = computed(() => this.files().length >= this.effectiveFileLimit(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasReachedMaxFiles" }] : /* istanbul ignore next */ []));
    canUpload = computed(() => !this.isDisabled() &&
        !this.uploading() &&
        this.files().some((item) => item.status === 'pending' || item.status === 'error'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canUpload" }] : /* istanbul ignore next */ []));
    // ── CVA Methods ─────────────────────────────────────────────
    writeValue(value) {
        this.cancelUpload();
        const next = value || [];
        const nextPreviewUrls = new Set(next.map((item) => item.previewUrl).filter(Boolean));
        this.files().forEach((item) => {
            if (item.previewUrl && !nextPreviewUrls.has(item.previewUrl))
                this.revokePreview(item);
        });
        this.files.set(next);
        this.validationMessage.set('');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.cvaDisabled.set(isDisabled);
    }
    // ── Drag & Drop Handlers ────────────────────────────────────
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        this.isDragging.set(true);
    }
    onDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        const droppedFiles = event.dataTransfer?.files;
        if (droppedFiles && droppedFiles.length > 0) {
            this.handleFiles(Array.from(droppedFiles), event);
        }
    }
    // ── User Actions ────────────────────────────────────────────
    onAreaClick() {
        if (this.isDisabled() || this.hasReachedMaxFiles())
            return;
        this.fileInputRef?.nativeElement.click();
        this.onTouched();
    }
    onAreaKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.onAreaClick();
        }
    }
    onFileSelected(event) {
        const input = event.target;
        if (input.files && input.files.length > 0) {
            this.handleFiles(Array.from(input.files), event);
            input.value = ''; // Reset input to allow re-selecting same file
        }
    }
    onRemoveFile(id, originalEvent = new Event('remove')) {
        if (this.isDisabled())
            return;
        const removed = this.files().find((f) => f.id === id);
        if (!removed || removed.status === 'uploading')
            return;
        this.files.update((list) => list.filter((f) => f.id !== id));
        this.onChange(this.files());
        this.onTouched();
        if (removed) {
            this.revokePreview(removed);
            this.onRemove.emit({ originalEvent, file: removed.file });
            if (removed.status === 'success')
                this.onRemoveUploadedFile.emit({ originalEvent, file: removed.file });
        }
    }
    clear(originalEvent = new Event('clear')) {
        if (this.isDisabled())
            return;
        this.cancelUpload();
        this.files().forEach((item) => this.revokePreview(item));
        this.files.set([]);
        this.validationMessage.set('');
        this.onChange([]);
        this.onTouched();
        this.onClear.emit(originalEvent);
    }
    upload() {
        if (!this.canUpload())
            return;
        const selected = this.files().filter((item) => item.status === 'pending' || item.status === 'error');
        const files = selected.map((item) => item.file);
        if (!this.customUpload() && (!this.url() || !this.http)) {
            this.emitValidationError(files, !this.url()
                ? 'Configure an upload URL or use customUpload.'
                : 'Provide HttpClient to upload files.');
            return;
        }
        this.validationMessage.set('');
        const form = new FormData();
        files.forEach((file) => form.append(this.name() || 'files', file, file.name));
        this.onBeforeUpload.emit({ formData: form });
        if (this.customUpload()) {
            this.uploadHandler.emit({ files });
            return;
        }
        const ids = new Set(selected.map((item) => item.id));
        const update = (status, progress, errorMessage) => {
            this.files.update((items) => items.map((item) => ids.has(item.id) ? { ...item, status, progress, errorMessage } : item));
            this.onChange(this.files());
        };
        this.uploading.set(true);
        update('uploading', 0);
        const request = this.http.request(this.method(), this.url(), {
            body: form,
            headers: this.headers(),
            withCredentials: this.withCredentials(),
            reportProgress: true,
            observe: 'events',
        });
        const subscription = new Subscription();
        this.uploadSubscription = subscription;
        subscription.add(request.subscribe({
            next: (event) => {
                if (event.type === HttpEventType.Sent)
                    this.onSend.emit({ originalEvent: event, formData: form });
                if (event.type === HttpEventType.UploadProgress && event.total) {
                    const progress = Math.min(100, Math.max(0, Math.round((event.loaded / event.total) * 100)));
                    update('uploading', progress);
                    this.onProgress.emit({ originalEvent: event, progress });
                }
                if (event.type === HttpEventType.Response) {
                    update('success', 100);
                    this.uploading.set(false);
                    this.onProgress.emit({ originalEvent: event, progress: 100 });
                    this.onUpload.emit({ originalEvent: event, files });
                }
            },
            error: (error) => {
                this.uploading.set(false);
                const message = error.message || 'Upload failed. Try again.';
                update('error', 0, message);
                this.emitValidationError(files, message, error);
            },
            complete: () => {
                if (this.uploadSubscription !== subscription)
                    return;
                this.uploading.set(false);
                if (this.auto() &&
                    this.files().some((item) => item.status === 'pending'))
                    this.upload();
            },
        }));
    }
    cancelUpload() {
        this.uploadSubscription?.unsubscribe();
        this.uploadSubscription = undefined;
        this.uploading.set(false);
    }
    choose() {
        this.onAreaClick();
    }
    uploader() {
        this.upload();
    }
    // ── Logic ───────────────────────────────────────────────────
    handleFiles(newFiles, originalEvent = new Event('select')) {
        if (!newFiles.length || this.isDisabled())
            return;
        this.validationMessage.set('');
        const currentFiles = this.files();
        const existingKeys = new Set(currentFiles.map((item) => this.fileKey(item.file)));
        const seenKeys = new Set();
        const duplicateFiles = [];
        const duplicateFreeFiles = newFiles.filter((file) => {
            const key = this.fileKey(file);
            if (existingKeys.has(key) || seenKeys.has(key)) {
                duplicateFiles.push(file);
                return false;
            }
            seenKeys.add(key);
            return true;
        });
        this.emitValidationError(duplicateFiles, 'Duplicate file');
        const candidates = duplicateFreeFiles.map((file) => this.createFileItem(file));
        const invalidCandidates = candidates.filter((item) => item.status === 'error');
        if (invalidCandidates.length) {
            this.emitValidationError(invalidCandidates.map((item) => item.file), invalidCandidates
                .map((item) => item.errorMessage)
                .filter(Boolean)
                .join('; ') || 'Invalid file');
        }
        const validCandidates = candidates.filter((item) => item.status !== 'error');
        const remainingSlots = Math.max(0, this.effectiveFileLimit() - currentFiles.length);
        const validItems = validCandidates.slice(0, remainingSlots);
        this.emitLimitError(validCandidates.slice(remainingSlots).map((item) => item.file));
        // Allocate previews only after validation and capacity checks succeed.
        validItems.forEach((item) => {
            if (item.type.startsWith('image/')) {
                item.previewUrl = URL.createObjectURL(item.file);
                this.ownedPreviewUrls.add(item.previewUrl);
            }
        });
        if (!this.multiple()) {
            if (validItems.length) {
                currentFiles.forEach((item) => this.revokePreview(item));
                this.files.set(validItems);
            }
        }
        else {
            this.files.update((list) => [...list, ...validItems]);
        }
        if (!validItems.length)
            return;
        this.onChange(this.files());
        this.onTouched();
        if (validItems.length)
            this.onSelect.emit({
                originalEvent,
                files: validItems.map((item) => item.file),
                currentFiles: this.files().map((item) => item.file),
            });
        if (this.auto())
            this.upload();
    }
    createFileItem(file) {
        const isOverSize = file.size > this.maxFileSize();
        // Follow native accept tokens: case-insensitive extensions, MIME types and MIME wildcards.
        let isInvalidType = false;
        if (this.accept()) {
            const allowedTypes = this.accept()
                .split(',')
                .map((t) => t.trim().toLowerCase())
                .filter(Boolean);
            if (allowedTypes.length > 0 && !allowedTypes.includes('*/*')) {
                const fileType = file.type.toLowerCase();
                isInvalidType = !allowedTypes.some((type) => {
                    if (type.startsWith('.'))
                        return file.name.toLowerCase().endsWith(type);
                    if (type.endsWith('/*'))
                        return fileType.startsWith(type.slice(0, -1));
                    return fileType === type;
                });
            }
        }
        let status = 'pending';
        let errorMessage = '';
        if (isOverSize) {
            status = 'error';
            const summary = this.invalidFileSizeMessageSummary();
            const detail = this.invalidFileSizeMessageDetail()?.replace('{0}', this.formatBytes(this.maxFileSize()));
            errorMessage =
                [summary, detail].filter(Boolean).join(': ') ||
                    `File exceeds ${this.formatBytes(this.maxFileSize())}.`;
        }
        else if (isInvalidType) {
            status = 'error';
            const summary = this.invalidFileTypeMessageSummary();
            const detail = this.invalidFileTypeMessageDetail()?.replace('{0}', this.accept());
            errorMessage =
                [summary, detail].filter(Boolean).join(': ') ||
                    `File type must match ${this.accept()}.`;
        }
        const item = {
            id: Math.random().toString(36).substring(2, 11),
            file,
            name: file.name,
            size: file.size,
            formattedSize: this.formatBytes(file.size),
            type: file.type,
            progress: 0,
            status,
            errorMessage,
        };
        return item;
    }
    fileKey(file) {
        return `${file.name}\u0000${file.size}\u0000${file.lastModified}\u0000${file.type}`;
    }
    emitValidationError(files, message, error) {
        if (!files.length)
            return;
        this.validationMessage.update((current) => current ? `${current} ${message}` : message);
        this.onError.emit({
            files,
            error: new ErrorEvent('error', { message, error }),
        });
    }
    emitLimitError(files) {
        if (!files.length)
            return;
        const summary = this.invalidFileLimitMessageSummary();
        const detail = this.invalidFileLimitMessageDetail();
        const configured = this.effectiveFileLimit();
        const message = summary && detail
            ? `${summary}: ${detail.replace('{0}', String(configured))}`
            : summary || detail || `Maximum of ${configured} files allowed`;
        this.emitValidationError(files, message);
    }
    revokePreview(item) {
        if (item.previewUrl && this.ownedPreviewUrls.delete(item.previewUrl))
            URL.revokeObjectURL(item.previewUrl);
    }
    formatBytes(bytes, decimals = 2) {
        if (bytes === 0)
            return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
    ngOnDestroy() {
        this.cancelUpload();
        this.ownedPreviewUrls.forEach((url) => URL.revokeObjectURL(url));
        this.ownedPreviewUrls.clear();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FileUploaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: FileUploaderComponent, isStandalone: true, selector: "orc-file-uploader, orc-file-upload", inputs: { accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: false, transformFunction: null }, method: { classPropertyName: "method", publicName: "method", isSignal: true, isRequired: false, transformFunction: null }, headers: { classPropertyName: "headers", publicName: "headers", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, auto: { classPropertyName: "auto", publicName: "auto", isSignal: true, isRequired: false, transformFunction: null }, withCredentials: { classPropertyName: "withCredentials", publicName: "withCredentials", isSignal: true, isRequired: false, transformFunction: null }, maxFiles: { classPropertyName: "maxFiles", publicName: "maxFiles", isSignal: true, isRequired: false, transformFunction: null }, fileLimit: { classPropertyName: "fileLimit", publicName: "fileLimit", isSignal: true, isRequired: false, transformFunction: null }, maxFileSize: { classPropertyName: "maxFileSize", publicName: "maxFileSize", isSignal: true, isRequired: false, transformFunction: null }, invalidFileSizeMessageSummary: { classPropertyName: "invalidFileSizeMessageSummary", publicName: "invalidFileSizeMessageSummary", isSignal: true, isRequired: false, transformFunction: null }, invalidFileSizeMessageDetail: { classPropertyName: "invalidFileSizeMessageDetail", publicName: "invalidFileSizeMessageDetail", isSignal: true, isRequired: false, transformFunction: null }, invalidFileTypeMessageSummary: { classPropertyName: "invalidFileTypeMessageSummary", publicName: "invalidFileTypeMessageSummary", isSignal: true, isRequired: false, transformFunction: null }, invalidFileTypeMessageDetail: { classPropertyName: "invalidFileTypeMessageDetail", publicName: "invalidFileTypeMessageDetail", isSignal: true, isRequired: false, transformFunction: null }, invalidFileLimitMessageSummary: { classPropertyName: "invalidFileLimitMessageSummary", publicName: "invalidFileLimitMessageSummary", isSignal: true, isRequired: false, transformFunction: null }, invalidFileLimitMessageDetail: { classPropertyName: "invalidFileLimitMessageDetail", publicName: "invalidFileLimitMessageDetail", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, subLabel: { classPropertyName: "subLabel", publicName: "subLabel", isSignal: true, isRequired: false, transformFunction: null }, dropzoneAriaLabel: { classPropertyName: "dropzoneAriaLabel", publicName: "dropzoneAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, chooseLabel: { classPropertyName: "chooseLabel", publicName: "chooseLabel", isSignal: true, isRequired: false, transformFunction: null }, uploadLabel: { classPropertyName: "uploadLabel", publicName: "uploadLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, removeAriaLabel: { classPropertyName: "removeAriaLabel", publicName: "removeAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, uploadingLabel: { classPropertyName: "uploadingLabel", publicName: "uploadingLabel", isSignal: true, isRequired: false, transformFunction: null }, uploadedLabel: { classPropertyName: "uploadedLabel", publicName: "uploadedLabel", isSignal: true, isRequired: false, transformFunction: null }, errorLabel: { classPropertyName: "errorLabel", publicName: "errorLabel", isSignal: true, isRequired: false, transformFunction: null }, pendingLabel: { classPropertyName: "pendingLabel", publicName: "pendingLabel", isSignal: true, isRequired: false, transformFunction: null }, previewWidth: { classPropertyName: "previewWidth", publicName: "previewWidth", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, chooseIcon: { classPropertyName: "chooseIcon", publicName: "chooseIcon", isSignal: true, isRequired: false, transformFunction: null }, uploadIcon: { classPropertyName: "uploadIcon", publicName: "uploadIcon", isSignal: true, isRequired: false, transformFunction: null }, cancelIcon: { classPropertyName: "cancelIcon", publicName: "cancelIcon", isSignal: true, isRequired: false, transformFunction: null }, showUploadButton: { classPropertyName: "showUploadButton", publicName: "showUploadButton", isSignal: true, isRequired: false, transformFunction: null }, showCancelButton: { classPropertyName: "showCancelButton", publicName: "showCancelButton", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, customUpload: { classPropertyName: "customUpload", publicName: "customUpload", isSignal: true, isRequired: false, transformFunction: null }, uploadStyleClass: { classPropertyName: "uploadStyleClass", publicName: "uploadStyleClass", isSignal: true, isRequired: false, transformFunction: null }, cancelStyleClass: { classPropertyName: "cancelStyleClass", publicName: "cancelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, chooseStyleClass: { classPropertyName: "chooseStyleClass", publicName: "chooseStyleClass", isSignal: true, isRequired: false, transformFunction: null }, removeStyleClass: { classPropertyName: "removeStyleClass", publicName: "removeStyleClass", isSignal: true, isRequired: false, transformFunction: null }, forceDragover: { classPropertyName: "forceDragover", publicName: "forceDragover", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onSelect: "onSelect", onRemove: "onRemove", onClear: "onClear", onUpload: "onUpload", onError: "onError", onProgress: "onProgress", onBeforeUpload: "onBeforeUpload", uploadHandler: "uploadHandler", onSend: "onSend", onImageError: "onImageError", onRemoveUploadedFile: "onRemoveUploadedFile" }, host: { listeners: { "dragover": "onDragOver($event)", "dragleave": "onDragLeave($event)", "drop": "onDrop($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FileUploaderComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "fileInputRef", first: true, predicate: ["fileInput"], descendants: true }], ngImport: i0, template: "<div\n  class=\"p-fileupload p-component orc-file-uploader\"\n  [class]=\"'p-fileupload p-component orc-file-uploader ' + (styleClass() || '')\"\n  [class.orc-file-uploader--disabled]=\"isDisabled()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'fileupload'\"\n>\n  <input\n    #fileInput\n    type=\"file\"\n    class=\"orc-file-uploader__input\"\n    [accept]=\"accept()\"\n    [multiple]=\"multiple()\"\n    [disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n    (change)=\"onFileSelected($event)\"\n    hidden\n    aria-hidden=\"true\"\n  />\n\n  @if (mode() === 'basic') {\n    <button\n      type=\"button\"\n      class=\"orc-file-uploader__basic-trigger\"\n      [class]=\"'orc-file-uploader__basic-trigger ' + chooseStyleClass()\"\n      [disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n      [attr.aria-label]=\"\n        dropzoneAriaLabel() || chooseLabel() || label() || 'Choose files'\n      \"\n      (click)=\"onAreaClick()\"\n    >\n      @if (chooseIcon()) {\n        <span\n          class=\"orc-file-uploader__button-icon\"\n          [class]=\"chooseIcon()\"\n          aria-hidden=\"true\"\n        ></span>\n      }\n      {{ chooseLabel() || label() || 'Choose files' }}\n    </button>\n  } @else {\n    <div\n      class=\"p-fileupload-content orc-file-uploader__dropzone\"\n      [class.orc-file-uploader__dropzone--dragover]=\"\n        isDragging() || forceDragover()\n      \"\n      [class.orc-file-uploader__dropzone--disabled]=\"isDisabled()\"\n      role=\"button\"\n      [attr.tabindex]=\"isDisabled() || hasReachedMaxFiles() ? -1 : 0\"\n      (click)=\"onAreaClick()\"\n      (keydown)=\"onAreaKeyDown($event)\"\n      [attr.aria-disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n      [attr.aria-label]=\"\n        dropzoneAriaLabel() || chooseLabel() || label() || 'Choose files'\n      \"\n    >\n      <div class=\"orc-file-uploader__dropzone-content\">\n        <div class=\"orc-file-uploader__icon\">\n          @if (chooseIcon()) {\n            <span [class]=\"chooseIcon()\" aria-hidden=\"true\"></span>\n          } @else {\n            <svg\n              viewBox=\"0 0 24 24\"\n              fill=\"none\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n              aria-hidden=\"true\"\n            >\n              <path\n                d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n              ></path>\n              <polyline points=\"14 2 14 8 20 8\"></polyline>\n              <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n              <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n              <polyline points=\"10 9 9 9 8 9\"></polyline>\n            </svg>\n          }\n        </div>\n        <div class=\"orc-file-uploader__text\">\n          <span class=\"orc-file-uploader__label\">{{\n            label() || chooseLabel() || 'Choose files'\n          }}</span>\n          @if (subLabel()) {\n            <span class=\"orc-file-uploader__sublabel\">{{ subLabel() }}</span>\n          }\n        </div>\n      </div>\n    </div>\n  }\n\n  @if (files().length > 0) {\n    <div class=\"orc-file-uploader__list\" role=\"list\" aria-live=\"polite\">\n      @for (file of files(); track file.id) {\n        <orc-file-item\n          [fileData]=\"file\"\n          [disabled]=\"isDisabled() || file.status === 'uploading'\"\n          [removeAriaLabel]=\"removeAriaLabel()\"\n          [uploadingLabel]=\"uploadingLabel()\"\n          [uploadedLabel]=\"uploadedLabel()\"\n          [errorLabel]=\"errorLabel()\"\n          [pendingLabel]=\"pendingLabel()\"\n          [previewWidth]=\"previewWidth()\"\n          [removeStyleClass]=\"removeStyleClass()\"\n          (remove)=\"onRemoveFile($event)\"\n          (imageError)=\"onImageError.emit($event)\"\n        >\n        </orc-file-item>\n      }\n    </div>\n    @if (!auto()) {\n      <div class=\"orc-file-uploader__actions\">\n        @if (showUploadButton()) {\n          <button\n            type=\"button\"\n            [class]=\"'orc-file-uploader__upload ' + uploadStyleClass()\"\n            (click)=\"upload()\"\n            [disabled]=\"!canUpload()\"\n          >\n            @if (uploadIcon()) {\n              <span\n                class=\"orc-file-uploader__button-icon\"\n                [class]=\"uploadIcon()\"\n                aria-hidden=\"true\"\n              ></span>\n            }\n            {{ uploadLabel() || 'Upload' }}\n          </button>\n        }\n        @if (showCancelButton()) {\n          <button\n            type=\"button\"\n            [class]=\"'orc-file-uploader__cancel ' + cancelStyleClass()\"\n            (click)=\"clear()\"\n            [disabled]=\"isDisabled()\"\n          >\n            @if (cancelIcon()) {\n              <span\n                class=\"orc-file-uploader__button-icon\"\n                [class]=\"cancelIcon()\"\n                aria-hidden=\"true\"\n              ></span>\n            }\n            {{ cancelLabel() || 'Cancel' }}\n          </button>\n        }\n      </div>\n    }\n  }\n  @if (validationMessage()) {\n    <p class=\"orc-file-uploader__error\" role=\"alert\">\n      {{ validationMessage() }}\n    </p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-uploader{display:flex;flex-direction:column;gap:var(--space-4)}.orc-file-uploader--disabled{opacity:.6;pointer-events:none}.orc-file-uploader__dropzone{border:3px dashed var(--orc-border-default, var(--border-default));border-radius:16px;background-color:var(--orc-surface, var(--bg-app));padding:var(--space-8);cursor:pointer;transition:all var(--transition-fast);outline:none}.orc-file-uploader__dropzone:hover,.orc-file-uploader__dropzone:focus-visible{border-color:var(--orc-interactive, var(--color-accent));background-color:var(--orc-surface-subtle, var(--bg-subtle))}.orc-file-uploader__dropzone--dragover{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));background-color:color-mix(in srgb,var(--orc-interactive) 4%,transparent)}.orc-file-uploader__dropzone--disabled{cursor:not-allowed;border-color:var(--orc-border-default, var(--border-default))!important;background-color:var(--orc-surface-subtle, var(--bg-subtle))!important}.orc-file-uploader__basic-trigger,.orc-file-uploader__upload,.orc-file-uploader__cancel{border:1px solid var(--orc-border-default, var(--border-default));border-radius:var(--radius-md, 8px);background:var(--orc-surface, var(--bg-app));color:var(--orc-text, var(--text-primary));cursor:pointer;font:inherit;padding:var(--space-2) var(--space-4)}.orc-file-uploader__basic-trigger:hover:not(:disabled),.orc-file-uploader__basic-trigger:focus-visible:not(:disabled),.orc-file-uploader__upload:hover:not(:disabled),.orc-file-uploader__upload:focus-visible:not(:disabled),.orc-file-uploader__cancel:hover:not(:disabled),.orc-file-uploader__cancel:focus-visible:not(:disabled){border-color:var(--orc-interactive, var(--color-accent))}.orc-file-uploader__basic-trigger:disabled,.orc-file-uploader__upload:disabled,.orc-file-uploader__cancel:disabled{cursor:not-allowed;opacity:.6}.orc-file-uploader__basic-trigger{align-self:flex-start}.orc-file-uploader__button-icon{display:inline-block;margin-right:var(--space-2)}.orc-file-uploader__actions{display:flex;gap:var(--space-3)}.orc-file-uploader__dropzone-content{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--space-6)}.orc-file-uploader__icon{width:70px;height:70px;color:var(--orc-text-secondary, var(--text-secondary));display:flex;align-items:center;justify-content:center}.orc-file-uploader__icon svg{width:100%;height:100%}.orc-file-uploader__text{display:flex;flex-direction:column;gap:var(--space-3)}.orc-file-uploader__label{font-size:1rem;font-weight:400;color:var(--orc-text, var(--text-primary))}.orc-file-uploader__sublabel{font-size:1rem;font-weight:400;color:var(--orc-text-secondary, var(--text-secondary))}.orc-file-uploader__list{display:flex;flex-direction:column;gap:var(--space-3);max-height:260px;overflow-y:auto;padding-right:4px}.orc-file-uploader__list::-webkit-scrollbar{width:6px}.orc-file-uploader__list::-webkit-scrollbar-track{background:var(--orc-surface-subtle, var(--bg-subtle));border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb{background:var(--orc-border-default, var(--border-default));border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb:hover{background:var(--orc-text-secondary, var(--text-secondary))}:host .orc-file-uploader__error{margin:0;color:var(--orc-danger);font-size:.875rem;overflow-wrap:anywhere}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: FileItemComponent, selector: "orc-file-item", inputs: ["fileData", "disabled", "removeAriaLabel", "uploadingLabel", "uploadedLabel", "errorLabel", "pendingLabel", "previewWidth", "removeStyleClass"], outputs: ["remove", "imageError"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FileUploaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'orc-file-uploader, orc-file-upload', standalone: true, imports: [CommonModule, FileItemComponent], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FileUploaderComponent),
                            multi: true,
                        },
                    ], template: "<div\n  class=\"p-fileupload p-component orc-file-uploader\"\n  [class]=\"'p-fileupload p-component orc-file-uploader ' + (styleClass() || '')\"\n  [class.orc-file-uploader--disabled]=\"isDisabled()\"\n  [style]=\"style()\"\n  [attr.data-pc-name]=\"'fileupload'\"\n>\n  <input\n    #fileInput\n    type=\"file\"\n    class=\"orc-file-uploader__input\"\n    [accept]=\"accept()\"\n    [multiple]=\"multiple()\"\n    [disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n    (change)=\"onFileSelected($event)\"\n    hidden\n    aria-hidden=\"true\"\n  />\n\n  @if (mode() === 'basic') {\n    <button\n      type=\"button\"\n      class=\"orc-file-uploader__basic-trigger\"\n      [class]=\"'orc-file-uploader__basic-trigger ' + chooseStyleClass()\"\n      [disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n      [attr.aria-label]=\"\n        dropzoneAriaLabel() || chooseLabel() || label() || 'Choose files'\n      \"\n      (click)=\"onAreaClick()\"\n    >\n      @if (chooseIcon()) {\n        <span\n          class=\"orc-file-uploader__button-icon\"\n          [class]=\"chooseIcon()\"\n          aria-hidden=\"true\"\n        ></span>\n      }\n      {{ chooseLabel() || label() || 'Choose files' }}\n    </button>\n  } @else {\n    <div\n      class=\"p-fileupload-content orc-file-uploader__dropzone\"\n      [class.orc-file-uploader__dropzone--dragover]=\"\n        isDragging() || forceDragover()\n      \"\n      [class.orc-file-uploader__dropzone--disabled]=\"isDisabled()\"\n      role=\"button\"\n      [attr.tabindex]=\"isDisabled() || hasReachedMaxFiles() ? -1 : 0\"\n      (click)=\"onAreaClick()\"\n      (keydown)=\"onAreaKeyDown($event)\"\n      [attr.aria-disabled]=\"isDisabled() || hasReachedMaxFiles()\"\n      [attr.aria-label]=\"\n        dropzoneAriaLabel() || chooseLabel() || label() || 'Choose files'\n      \"\n    >\n      <div class=\"orc-file-uploader__dropzone-content\">\n        <div class=\"orc-file-uploader__icon\">\n          @if (chooseIcon()) {\n            <span [class]=\"chooseIcon()\" aria-hidden=\"true\"></span>\n          } @else {\n            <svg\n              viewBox=\"0 0 24 24\"\n              fill=\"none\"\n              stroke=\"currentColor\"\n              stroke-width=\"2\"\n              stroke-linecap=\"round\"\n              stroke-linejoin=\"round\"\n              aria-hidden=\"true\"\n            >\n              <path\n                d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"\n              ></path>\n              <polyline points=\"14 2 14 8 20 8\"></polyline>\n              <line x1=\"16\" y1=\"13\" x2=\"8\" y2=\"13\"></line>\n              <line x1=\"16\" y1=\"17\" x2=\"8\" y2=\"17\"></line>\n              <polyline points=\"10 9 9 9 8 9\"></polyline>\n            </svg>\n          }\n        </div>\n        <div class=\"orc-file-uploader__text\">\n          <span class=\"orc-file-uploader__label\">{{\n            label() || chooseLabel() || 'Choose files'\n          }}</span>\n          @if (subLabel()) {\n            <span class=\"orc-file-uploader__sublabel\">{{ subLabel() }}</span>\n          }\n        </div>\n      </div>\n    </div>\n  }\n\n  @if (files().length > 0) {\n    <div class=\"orc-file-uploader__list\" role=\"list\" aria-live=\"polite\">\n      @for (file of files(); track file.id) {\n        <orc-file-item\n          [fileData]=\"file\"\n          [disabled]=\"isDisabled() || file.status === 'uploading'\"\n          [removeAriaLabel]=\"removeAriaLabel()\"\n          [uploadingLabel]=\"uploadingLabel()\"\n          [uploadedLabel]=\"uploadedLabel()\"\n          [errorLabel]=\"errorLabel()\"\n          [pendingLabel]=\"pendingLabel()\"\n          [previewWidth]=\"previewWidth()\"\n          [removeStyleClass]=\"removeStyleClass()\"\n          (remove)=\"onRemoveFile($event)\"\n          (imageError)=\"onImageError.emit($event)\"\n        >\n        </orc-file-item>\n      }\n    </div>\n    @if (!auto()) {\n      <div class=\"orc-file-uploader__actions\">\n        @if (showUploadButton()) {\n          <button\n            type=\"button\"\n            [class]=\"'orc-file-uploader__upload ' + uploadStyleClass()\"\n            (click)=\"upload()\"\n            [disabled]=\"!canUpload()\"\n          >\n            @if (uploadIcon()) {\n              <span\n                class=\"orc-file-uploader__button-icon\"\n                [class]=\"uploadIcon()\"\n                aria-hidden=\"true\"\n              ></span>\n            }\n            {{ uploadLabel() || 'Upload' }}\n          </button>\n        }\n        @if (showCancelButton()) {\n          <button\n            type=\"button\"\n            [class]=\"'orc-file-uploader__cancel ' + cancelStyleClass()\"\n            (click)=\"clear()\"\n            [disabled]=\"isDisabled()\"\n          >\n            @if (cancelIcon()) {\n              <span\n                class=\"orc-file-uploader__button-icon\"\n                [class]=\"cancelIcon()\"\n                aria-hidden=\"true\"\n              ></span>\n            }\n            {{ cancelLabel() || 'Cancel' }}\n          </button>\n        }\n      </div>\n    }\n  }\n  @if (validationMessage()) {\n    <p class=\"orc-file-uploader__error\" role=\"alert\">\n      {{ validationMessage() }}\n    </p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.orc-file-uploader{display:flex;flex-direction:column;gap:var(--space-4)}.orc-file-uploader--disabled{opacity:.6;pointer-events:none}.orc-file-uploader__dropzone{border:3px dashed var(--orc-border-default, var(--border-default));border-radius:16px;background-color:var(--orc-surface, var(--bg-app));padding:var(--space-8);cursor:pointer;transition:all var(--transition-fast);outline:none}.orc-file-uploader__dropzone:hover,.orc-file-uploader__dropzone:focus-visible{border-color:var(--orc-interactive, var(--color-accent));background-color:var(--orc-surface-subtle, var(--bg-subtle))}.orc-file-uploader__dropzone--dragover{border-color:var(--orc-interactive, var(--orc-color-azul-eletrico));background-color:color-mix(in srgb,var(--orc-interactive) 4%,transparent)}.orc-file-uploader__dropzone--disabled{cursor:not-allowed;border-color:var(--orc-border-default, var(--border-default))!important;background-color:var(--orc-surface-subtle, var(--bg-subtle))!important}.orc-file-uploader__basic-trigger,.orc-file-uploader__upload,.orc-file-uploader__cancel{border:1px solid var(--orc-border-default, var(--border-default));border-radius:var(--radius-md, 8px);background:var(--orc-surface, var(--bg-app));color:var(--orc-text, var(--text-primary));cursor:pointer;font:inherit;padding:var(--space-2) var(--space-4)}.orc-file-uploader__basic-trigger:hover:not(:disabled),.orc-file-uploader__basic-trigger:focus-visible:not(:disabled),.orc-file-uploader__upload:hover:not(:disabled),.orc-file-uploader__upload:focus-visible:not(:disabled),.orc-file-uploader__cancel:hover:not(:disabled),.orc-file-uploader__cancel:focus-visible:not(:disabled){border-color:var(--orc-interactive, var(--color-accent))}.orc-file-uploader__basic-trigger:disabled,.orc-file-uploader__upload:disabled,.orc-file-uploader__cancel:disabled{cursor:not-allowed;opacity:.6}.orc-file-uploader__basic-trigger{align-self:flex-start}.orc-file-uploader__button-icon{display:inline-block;margin-right:var(--space-2)}.orc-file-uploader__actions{display:flex;gap:var(--space-3)}.orc-file-uploader__dropzone-content{display:flex;flex-direction:column;align-items:center;text-align:center;gap:var(--space-6)}.orc-file-uploader__icon{width:70px;height:70px;color:var(--orc-text-secondary, var(--text-secondary));display:flex;align-items:center;justify-content:center}.orc-file-uploader__icon svg{width:100%;height:100%}.orc-file-uploader__text{display:flex;flex-direction:column;gap:var(--space-3)}.orc-file-uploader__label{font-size:1rem;font-weight:400;color:var(--orc-text, var(--text-primary))}.orc-file-uploader__sublabel{font-size:1rem;font-weight:400;color:var(--orc-text-secondary, var(--text-secondary))}.orc-file-uploader__list{display:flex;flex-direction:column;gap:var(--space-3);max-height:260px;overflow-y:auto;padding-right:4px}.orc-file-uploader__list::-webkit-scrollbar{width:6px}.orc-file-uploader__list::-webkit-scrollbar-track{background:var(--orc-surface-subtle, var(--bg-subtle));border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb{background:var(--orc-border-default, var(--border-default));border-radius:4px}.orc-file-uploader__list::-webkit-scrollbar-thumb:hover{background:var(--orc-text-secondary, var(--text-secondary))}:host .orc-file-uploader__error{margin:0;color:var(--orc-danger);font-size:.875rem;overflow-wrap:anywhere}\n"] }]
        }], propDecorators: { fileInputRef: [{
                type: ViewChild,
                args: ['fileInput']
            }], accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], url: [{ type: i0.Input, args: [{ isSignal: true, alias: "url", required: false }] }], method: [{ type: i0.Input, args: [{ isSignal: true, alias: "method", required: false }] }], headers: [{ type: i0.Input, args: [{ isSignal: true, alias: "headers", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], auto: [{ type: i0.Input, args: [{ isSignal: true, alias: "auto", required: false }] }], withCredentials: [{ type: i0.Input, args: [{ isSignal: true, alias: "withCredentials", required: false }] }], maxFiles: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFiles", required: false }] }], fileLimit: [{ type: i0.Input, args: [{ isSignal: true, alias: "fileLimit", required: false }] }], maxFileSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFileSize", required: false }] }], invalidFileSizeMessageSummary: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileSizeMessageSummary", required: false }] }], invalidFileSizeMessageDetail: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileSizeMessageDetail", required: false }] }], invalidFileTypeMessageSummary: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileTypeMessageSummary", required: false }] }], invalidFileTypeMessageDetail: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileTypeMessageDetail", required: false }] }], invalidFileLimitMessageSummary: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileLimitMessageSummary", required: false }] }], invalidFileLimitMessageDetail: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalidFileLimitMessageDetail", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], subLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "subLabel", required: false }] }], dropzoneAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropzoneAriaLabel", required: false }] }], chooseLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "chooseLabel", required: false }] }], uploadLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadLabel", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], removeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeAriaLabel", required: false }] }], uploadingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadingLabel", required: false }] }], uploadedLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadedLabel", required: false }] }], errorLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorLabel", required: false }] }], pendingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pendingLabel", required: false }] }], previewWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "previewWidth", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], chooseIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "chooseIcon", required: false }] }], uploadIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadIcon", required: false }] }], cancelIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelIcon", required: false }] }], showUploadButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showUploadButton", required: false }] }], showCancelButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCancelButton", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], customUpload: [{ type: i0.Input, args: [{ isSignal: true, alias: "customUpload", required: false }] }], uploadStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "uploadStyleClass", required: false }] }], cancelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelStyleClass", required: false }] }], chooseStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "chooseStyleClass", required: false }] }], removeStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeStyleClass", required: false }] }], forceDragover: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceDragover", required: false }] }], onSelect: [{ type: i0.Output, args: ["onSelect"] }], onRemove: [{ type: i0.Output, args: ["onRemove"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onUpload: [{ type: i0.Output, args: ["onUpload"] }], onError: [{ type: i0.Output, args: ["onError"] }], onProgress: [{ type: i0.Output, args: ["onProgress"] }], onBeforeUpload: [{ type: i0.Output, args: ["onBeforeUpload"] }], uploadHandler: [{ type: i0.Output, args: ["uploadHandler"] }], onSend: [{ type: i0.Output, args: ["onSend"] }], onImageError: [{ type: i0.Output, args: ["onImageError"] }], onRemoveUploadedFile: [{ type: i0.Output, args: ["onRemoveUploadedFile"] }], onDragOver: [{
                type: HostListener,
                args: ['dragover', ['$event']]
            }], onDragLeave: [{
                type: HostListener,
                args: ['dragleave', ['$event']]
            }], onDrop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { FileItemComponent, FileUploaderComponent };
//# sourceMappingURL=ciag-orchestra-file-uploader.mjs.map
