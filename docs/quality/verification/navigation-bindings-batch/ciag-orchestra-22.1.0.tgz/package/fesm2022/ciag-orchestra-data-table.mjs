export { DataTableComponent } from '@ciag/orchestra/p2';

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ciag-orchestra-data-table.mjs.map
